# professional security operations engineer

133 / 133 preguntas. Cobertura completa: True.

Respuestas de la fuente; revisión técnica pendiente. Las imágenes permanecen en sus campos de origen.

133 respuestas conservadas; 0 pendientes.

<a id="topics-107"></a>
## Contexto topics:107
name:
Topic 1


## Pregunta 1

Contexto: [topics:107](#topics-107)
You are responsible for identifying suspicious activity and security events at your organization. You have been asked to search in Google Security Operations (SecOps) for network traffic associated with an active HTTP backdoor that runs on TCP port 5555. You want to use the most effective approach to identify traffic originating from the server that is running the backdoor. What should you do?

**A.** Detect on events where network.ApplicationProtocol is HTTP.

**B.** Detect on events where target.port is 5555.

**C.** Detect on events where principal.port is 5555.

**D.** Detect on events where network.ip_protocol is TCP.

**Respuesta de la fuente:** C

**Explicación:** In Google Security Operations (SecOps) Unified Data Model (UDM), the 'principal' attribute represents the source of the event, while 'target' represents the destination.
Since the question asks to identify traffic originating from the server running the backdoor, you must filter by the source port.
Therefore, detecting events where principal.port is 5555 correctly identifies outbound connections initiated by that specific server.

## Pregunta 2

Contexto: [topics:107](#topics-107)
You are an incident responder at your organization using Google Security Operations (SecOps) for monitonng and investigation. You discover that a critical production server, which handles financial transactions, shows signs of unauthorized file changes and network scanning from a suspicious IP address. You suspect that persistence mechanisms may have been installed. You need to use Google SecOps to immediately contain the threat while ensuring that forensic data remains available for investigation. What should you do first?

**A.** Use the firewall integration to submit the IP address to a network block list to inhibit internet access from that machine.

**B.** Deploy emergency patches, and reboot the server to remove malicious persistence.

**C.** Use the EDR integration to quarantine the compromised asset.

**D.** Use VirusTotal to enrich the IP address and retrieve the domain. Add the domain to the proxy block list.

**Respuesta de la fuente:** C

**Explicación:** Quarantining the asset via EDR integration isolates the compromised server to prevent lateral movement and further unauthorized activity without destroying volatile memory. Rebooting or patching (Option B) would erase forensic evidence, while blocking network traffic alone (Options A and D) does not fully contain threats that may already have local persistence.

## Pregunta 3

Contexto: [topics:107](#topics-107)
Your organization uses Google Security Operations (SecOps). You discover frequent file downloads from a shared workspace within a short time window. You need to configure a rule in Google SecOps that identifies these suspicious events and assigns higher risk scores to repeated anomalies. What should you do?

**A.** Configure a rule that flags file download events with the highest risk score, regardless of time frame.

**B.** Create a frequency-based YARA-L detection rule that assigns a risk outcome score and is triggered when multiple suspicious downloads occur within a defined time frame.

**C.** Configure a single-event YARA-L detection rule that assigns a risk outcome score and is triggered when a user downloads a large number of files in 24 hours.

**D.** Enable default curated detections, and use automatic alerting for single file download events.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it utilizes YARA-L's multi-event capabilities to correlate frequent file downloads within a specific time window, directly addressing the 'frequent... within a short time window' requirement.

This approach allows for dynamic risk scoring based on the volume and frequency of anomalies, whereas other options either ignore the temporal aspect (A), focus on single large events rather than frequency (C), or rely on static default rules (D).

## Pregunta 4

Contexto: [topics:107](#topics-107)
You are implementing Google Security Operations (SecOps) at your organization. You discover that the current detection rules are too noisy. Due to the high volume of alerts, some true positives might be missed. You want to ingest additional context sources to reduce false positives in your security detections and to improve the overall positive ratio of the alerts. What should you do?

**A.** Ingest high-value asset (HVA) data from your configuration management database (CMDB) system to increase the priority of the alerts based on the sensitivity of the assets found in the detection rules.

**B.** Ingest dark web forum handlers from your threat intelligence system to match dark web principals within the detection rules.

**C.** Ingest IOCs from your threat intelligence system to validate the IP addresses, domains and hashes with the detection rules.

**D.** Ingest tactics, techniques, and procedures (TTPs) from your threat intelligence system to validate the processes and tools with the detection rules.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 5

Contexto: [topics:107](#topics-107)
You are developing a new detection rule in Google Security Operations (SecOps). You are defining the YARA-L logic that includes complex event, match, and condition sections. You need to develop and test the rule to ensure that the detections are accurate before the rule is migrated to production. You want to minimize impact to production processes. What should you do?

**A.** Develop the rule logic in the UDM search, review the search output to inform changes to filters and logic, and copy the rule into the Rules Editor.

**B.** Use Gemini in Google SecOps to develop the rule by providing a description of the parameters and conditions, and transfer the rule into the Rules Editor.

**C.** Develop the rule in the Rules Editor, define the sections the rule logic, and test the rule using the test rule feature.

**D.** Develop the rule in the Rules Editor, define the sections of the rule logic, and test the rule by setting it to live but not alerting. Run a YARA-L retrohunt from the rules dashboard.

**Respuesta de la fuente:** C

**Explicación:** The Google Security Operations Rules Editor includes a built-in 'test rule' feature that allows you to validate YARA-L logic against sample data or historical events.
This method ensures detection accuracy without consuming live processing resources or generating alerts, thereby minimizing impact on production systems.

## Pregunta 6

Contexto: [topics:107](#topics-107)
Your organization has recently acquired Company A, which has its own SOC and security tooling. You have already configured ingestion of Company A's security telemetry and migrated their detection rules to Google Security Operations (SecOps). You now need to enable Company A's analysts to work their cases in Google SecOps. You need to ensure that Company A's analysts: do not have access to any case data originating from outside of Company A. are able to re-purpose playbooks previously developed by your organization's employees.
You need to minimize effort to implement your solution. What is the first step you should take?

**A.** Acquire a second Google SecOps SOAR tenant for Company A.

**B.** Provision a new service account for Company A.

**C.** Define a new SOC role for Company A.

**D.** Create a Google SecOps SOAR environment for Company A.

**Respuesta de la fuente:** D

**Explicación:** Creating a Google SecOps SOAR environment enables data segregation within a single tenant, ensuring Company A analysts only see their specific case data. This approach minimizes effort by avoiding the complexity of managing separate tenants (Option A) while still allowing access to shared organizational playbooks.

## Pregunta 7

Contexto: [topics:107](#topics-107)
You have identified and isolated a new malware sample installed by an advanced threat group that you believe was developed specifically for an attack against your organization. You want to quickly and efficiently analyze this malware to get IOCs without alerting the threat group. What should you do?

**A.** Search for the threat group in Google Threat Intelligence.

**B.** Upload the malware to Google Threat Intelligence by using VirusTotal.

**C.** Upload the malware to Google Threat Intelligence by using Private Scanning.

**D.** Calculate the file checksum for the malware, and search for the checksum in GoogleThreat Intelligence by using VirusTotal.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 8

Contexto: [topics:107](#topics-107)
Your organization uses Cloud Identity as their identity provider (IdP) and is a Google Security Operations (SecOps) customer You need to grant a group of users access to the Google SecOps instance with read-only access to all resources, including detection engine rules. How should this be configured?

**A.** Create a Google Group and add the required users. Grant the roles/chronicle.Viewer IAM role to the group on the project associated with your Google SecOps Instance.

**B.** Create a Google Group and add the required users. Grant the roles/chronicle.limitedViewer IAM role to the group on the project associated with your Google SecOps instance.

**C.** Create a workforce identity pool at the organization level. Grant the roles/chronicle.editor IAM role to the principalSet://iam.googleapis.com/locations/global/workforcePools/POOL_ID/group/GROUP_ID principal set on the project associated with your Google SecOps instance.

**D.** Create a workforce identity pool at the organization level Grant the roles/chronicle.limitedViewer IAM role to the principalSet://iam.googleapis.com/locations/global/workforcePools/POOL_ID/group/GROUP_ID principal set on the project associated with your Google SecOps Instance.

**Respuesta de la fuente:** A

**Explicación:** Cloud Identity manages user accounts that act as Google Workspace users, so they are granted access via standard Google Groups rather than Workforce Identity Federation (WFIF). The Chronicle Viewer role provides the required read-only access to all resources, including detection engine rules, whereas the Limited Viewer role excludes access to investigation and configuration features.

## Pregunta 9

Contexto: [topics:107](#topics-107)
Your team is responsible for cybersecurity for a large multinational corporation. You have been tasked with identifying unknown command and control nodes (C2s) that are potentially active in your organization's environment. You need to generate a list of potential matches within the next 24 hours. What should you do?

**A.** Write a rule in Google Security Operations (SecOps) that scans historic network outbound connections against ingested threat intelligence Run the rule in a retrohunt against the full tenant.

**B.** Load network records into BigQuery to identify endpoints that are communicating with domains outside three standard deviations of normal.

**C.** Review Security Health Analytics (SHA) findings in Security Command Center (SCC).

**D.** Write a YARA-L rule in Google Security Operations (SecOps) that compares network traffic of endpoints to low prevalence domains against recent WHOIS registrations.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it uses YARA-L to identify unknown C2 nodes by correlating network traffic with low-prevalence domains and recent WHOIS registrations, which are strong indicators of newly registered malicious infrastructure.
Unlike option A, this approach does not rely on existing threat intelligence feeds, allowing it to detect novel or custom-developed C2 channels that have not yet been cataloged.

## Pregunta 10

Contexto: [topics:107](#topics-107)
You received an alert from Container Threat Detection that an added binary has been executed in a business critical workload. You need to investigate and respond to this incident. What should you do? (Choose two.)

**A.** Notify the workload owner. Follow the response playbook, and ask the threat hunting team to identify the root cause of the incident.

**B.** Review the finding, investigate the pod and related resources, and research the related attack and response methods.

**C.** Review the finding, quarantine the cluster containing the running pod, and delete the running pod to prevent further compromise.

**D.** Silence the alert in the Security Command Center (SCC) console, as the alert is a low severity finding.

**E.** Keep the cluster and pod running, and investigate the behavior to determine whether the activity is malicious.

**Respuesta de la fuente:** A, B

**Explicación:** No conservada en esta captura.

## Pregunta 11

Contexto: [topics:107](#topics-107)
You are reviewing the security analyst team's playbook action process. Currently, security analysts navigate to the Playbooks tab in Google Security Operations (SecOps) for each alert and manually run steps assigned to a user. You need to present all actions from alerts awaiting user input in one location for the analyst to execute. What should you do?

**A.** Enable approval links in the manual action and display them as clickable links to the user in a HTML widget in the Default Case View tab.

**B.** Add a general insight in your playbook to display manual action details to the user.

**C.** Use the Pending Actions widget in the Default Case View in settings.

**D.** Create an Alert View with the playbook that incorporates the Pending Actions widget.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 12

Contexto: [topics:107](#topics-107)
You are managing a Google Security Operations (SecOps) implementation for a regional customer. Your customer informs you that logs are appearing in the platform after a consistent six-hour delay. After some research, you determine that there is a log time zone issue. You want to fix this problem. What should you do?

**A.** Modify the default parser and include a default time zone.

**B.** Create a parser extension to correct the time zone.

**C.** Create a custom parser to correct the time zone.

**D.** Modify the UI settings to correct the time zone.

**Respuesta de la fuente:** B

**Explicación:** In Google SecOps (formerly Chronicle), parser extensions are designed to modify or enrich fields from existing parsers without replacing them entirely. Specifically, a time zone correction is handled by creating a parser extension that adjusts the timestamp field relative to the source data's original interpretation.

Modifying default parsers directly is not permitted, custom parsers are for new log types, and UI settings do not affect ingested data timestamps.

## Pregunta 13

Contexto: [topics:107](#topics-107)
Your organization uses Google Security Operations (SecOps). You need to identify the most commonly occurring processes and applications across your organization's large number of servers so you can implement baselines and exclusion lists on a regular basis. You want to use the most efficient approach. What should you do?

**A.** Use the UDM lookup feature to identify relevant process-related UDM fields and values.

**B.** Run a UDM search, and review aggregations for relevant process-related UDM fields.

**C.** Review the Google SecOps SIEM Rules & Detections, and identify the most common processes appearing in alerts that are marked as false positives.

**D.** Generate a Google SecOps SIEM dashboard based on relevant UDM fields, such as processes, that provides the counts for process names and files.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 14

Contexto: [topics:107](#topics-107)
You work for an organization that uses Security Command Center (SCC) with Event Threat Detection (ETD) enabled. You need to enable ETD detections for data exfiltration attempts from designated sensitive Cloud Storage buckets and BigQuery datasets. You want to minimize Cloud Logging costs. What should you do?

**A.** Enable "data read" audit logs only for the designated sensitive Cloud Storage buckets and BigQuery datasets.

**B.** Enable "data read" and "data write" audit logs only for the designated sensitive Cloud Storage buckets and BigQuery datasets.

**C.** Enable "data read" and "data write" audit logs for all Cloud Storage buckets and BigQuery datasets throughout the organization.

**D.** Enable VPC Flow Logs for the VPC networks containing resources that access the sensitive Cloud Storage buckets and BigQuery datasets.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 15

Contexto: [topics:107](#topics-107)
Your company uses Security Command Center (SCC) and Google Security Operations (SecOps). Last week, an attacker attempted to establish persistence by generating a key for an unused service account. You need to confirm that you are receiving alerts when keys are created for unused service accounts and that newly created keys are automatically deleted. You want to minimize the amount of manual effort required. What should you do?

**A.** Generate a YARA-L rule in Google SecOps that detects when a service account key is created. Using the built-in IDE, create a custom action in Google SecOps SOAR that deletes the service account key.

**B.** Use the Initial Access: Dormant Service Account Key Created finding from SCC, and ingest this finding into Google SecOps. Create a custom action in Google SecOps SOAR that is triggered on this finding. Use the built-in IDE to build code to delete the service account key.

**C.** Configure a Cloud Logging sink to write logs to a Pub/Sub topic that filters for the methodName: "google.iam.admin.v1.CreateServiceAccountKey" field. Create a Cloud Run function that subscribes to the Pub/Sub topic and deletes the service account key.

**D.** Use the Initial Access: Dormant Service Account Key Created finding from SCC, and write this finding to a Pub/Sub topic. Create a Cloud Run function that subscribes to the Pub/Sub topic and deletes the service account key.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 16

Contexto: [topics:107](#topics-107)
Your company recently adopted Security Command Center (SCC) but is not using Google Security Operations (SecOps). Your organization has thousands of active projects. You need to detect anomalous behavior in your Google Cloud environment by windowing and aggregating data over a given time period, based on specific log events or advanced calculations. You also need to provide an interface for analysts to triage the alerts. How should you build this capability?

**A.** Send the logs to Cloud SQL, and run a scheduled query against these events using a Cloud Run scheduled job. Configure an aggregated log filter to stream event-driven logs to a Pub/Sub topic. Configure a trigger to send an email alert when new events are sent to this feed.

**B.** Sink the logs to BigQuery, and configure Cloud Run functions to execute a periodic job and generate normalized alerts in a Pub/Sub topic for findings. Use log-based metrics to generate event-driven alerts and send these alerts to the Pub/Sub topic. Write the alerts as findings using the SCC API.

**C.** Use log-based metrics to generate event-driven alerts for the detection scenarios. Configure a Cloud Monitoring alert policy to send email alerts to your security operations team.

**D.** Create a series of aggregated log sinks for each required finding, and send the normalized findings as JSON files to Cloud Storage. Use the write event to generate an alert.

**Respuesta de la fuente:** B

**Explicación:** BigQuery is the appropriate service for complex log analysis, windowing, and aggregation due to its powerful SQL engine and scalability with large datasets.
The Security Command Center (SCC) API allows custom findings to be written directly into SCC, integrating them with the native triage interface mentioned in the requirement.
Option B correctly combines BigQuery for detection logic and the SCC API for centralized alert management, whereas other options rely on less scalable storage or lack SCC integration.

## Pregunta 17

Contexto: [topics:107](#topics-107)
Your organization is a Google Security Operations (SecOps) customer and monitors critical assets using a SIEM dashboard. You need to dynamically monitor the assets based on a specific asset tag. What should you do?

**A.** Ask Cloud Customer Care to add a custom filter to the dashboard.

**B.** Add a custom filter to the dashboard.

**C.** Copy an existing dashboard and add a custom filter.

**D.** Export the dashboard configuration to a file, modify the file to add a custom filter, and import the file into Google SecOps.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 18

Contexto: [topics:107](#topics-107)
A business unit in your organization plans to use Vertex AI to develop models within Google Cloud. The security team needs to implement detective and preventative guardrails to ensure that the environment meets internal security control requirements. How should you secure this environment?

**A.** Implement Assured Workloads by creating a folder for the business unit and assigning the relevant control package.

**B.** Implement preconfigured and custom organization policies to meet the control requirements. Apply these policies to the business unit folder.

**C.** Create a policy bundle representing the control requirements using Rego. Implement these policies using Workload Manager. Scope this scan to the business unit folder.

**D.** Create a posture consisting of predefined and custom organization policies and predefined and Security Health Analytics (SHA) custom modules. Scope this posture to the business unit folder.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 19

Contexto: [topics:107](#topics-107)
You are implementing Google Security Operations (SecOps) with multiple log sources. You want to closely monitor the health of the ingestion pipeline's forwarders and collection agents, and detect silent sources within five minutes. What should you do?

**A.** Create a notification in Cloud Monitoring using a metric-absence condition based on sample policy for each collector_id.

**B.** Create a Google SecOps SIEM dashboard to show the ingestion metrics for each log_type and collector_id.

**C.** Create an ingestion notification for health metrics in Cloud Monitoring based on the total ingested log count for each collector_id.

**D.** Create a Looker dashboard that queries the BigQuery ingestion metrics schema for each log_type and collector_id.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 20

Contexto: [topics:107](#topics-107)
A Google Security Operations (SecOps) detection rule is generating frequent false positive alerts. The rule was designed to detect suspicious Cloud Storage enumeration by triggering an alert whenever the storage.objects.list API operation is called using the api.operation UDM field. However, a legitimate backup automation tool that uses the same API, causing the rule to fire unnecessarily. You need to reduce these false positives from this trusted backup tool while still detecting potentially malicious usage. How should you modify the rule to improve its accuracy?

**A.** Add principal.user.email != "backup-bot@foobaa.com" to the rule condition to exclude the automation account.

**B.** Replace api.operation with api.service_name = "storage.googleapis.com" to narrow the detection scope.

**C.** Convert the rule into a multi-event rule that looks for repeated API calls across multiple buckets.

**D.** Adjust the rule severity to LOW to deprioritize alerts from automation tools.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 21

Contexto: [topics:107](#topics-107)
Your company uses Google Security Operations (SecOps) Enterprise and is ingesting various logs. You need to proactively identify potentially compromised user accounts. Specifically, you need to detect when a user account downloads an unusually large volume of data compared to the user's established baseline activity. You want to detect this anomalous data access behavior using the least amount of effort. What should you do?

**A.** Inspect Security Command Center (SCC) default findings for data exfiltration in Google SecOps.

**B.** Create a log-based metric in Cloud Monitoring, and configure an alert to trigger if the data downloaded per user exceeds a predefined limit. Identify users who exceed the predefined limit in Google SecOps.

**C.** Develop a custom YARA-L detection rule in Google SecOps that counts download bytes per user per hour and triggers an alert if a threshold is exceeded.

**D.** Enable curated detection rules for User and Endpoint Behavioral Analytics (UEBA), and use the Risk Analytics dashboard in Google SecOps to identify metrics associated with the anomalous activity.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 22

Contexto: [topics:107](#topics-107)
Your organization uses Security Command Center (SCC) and relies on Compute Engine instances to run business-critical workloads. SCC has flagged a particular instance for exhibiting a high volume of outbound network connections to geographically diverse and unknown IP addresses. You need to determine whether the instance has been compromised by malware. What should you do?

**A.** Examine the IAM roles assigned to the service account that are associated with the instance. Revoke any permissions that could have facilitated malware installation.

**B.** Review the Google Cloud Service Health dashboard to identify any ongoing Google Cloud platform incidents that could be causing unusual network traffic from the instance.

**C.** Disable and re-enable the instances' network interface and determine whether the unusual network behavior is resolved.

**D.** Analyze Event Threat Detection findings. Review the events and the outbound network connections associated with the instance.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 23

Contexto: [topics:107](#topics-107)
Your company wants to enhance its detection capabilities to prevent insider threat incidents. You need to be alerted when a privileged Google Group is modified to allow access to the general public. You need to identify and enable the optimal log source, and configure the alert. What should you do?

**A.** Enable Google Drive log events. Create a reporting rule that triggers when a file sharing event occurs with the visibility set to anyone with the link.

**B.** Enable VPC Flow Logs for the default VPC network. Configure a log-based alert in Cloud Logging to detect anomalous traffic patterns associated with Google Groups API endpoints.

**C.** Enable IAM Admin Activity audit logs, and export the logs to Google Security Operations (SecOps). Write a YARA-L rule in Google SecOps to capture any changes to relevant IAM policies.

**D.** Enable data sharing for Google Workspace Admin Audit logs, and ensure that Event Threat Detection is enabled for your organization.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 24

Contexto: [topics:107](#topics-107)
You are using Google Security Operations (SecOps) to investigate suspicious activity linked to a specific user. You want to identify all assets the user has interacted with over the past seven days to assess potential impact. Your need to understand the user's relationships to endpoints, service accounts, and cloud resources. How should you identify user-to-asset relationships in Google SecOps?

**A.** Use the Raw Log Scan view to group events by asset ID.

**B.** Query for hostnames in UDM Search and filter the results by user.

**C.** Generate an ingestion report to identify sources where the user appeared in the last seven days.

**D.** Run a retrohunt to find rule matches triggered by the user.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 25

Contexto: [topics:107](#topics-107)
Your organization recently acquired a Google Security Operations (SecOps) Enterprise Plus license. Your organization is already ingesting Cloud Audit Logs, firewall logs, proxy logs and endpoint logs, but there are no threat intelligence feeds being ingested into your Google SecOps environment. You need to design and deploy a solution that alerts your team quickly if an IOC of an active breach is observed in your environment. What should you do?

**A.** Write, enable, and configure alerting on a custom multi-event rule.

**B.** Write, enable, and configure alerting on a custom single-event rule.

**C.** Enable and configure alerting for relevant curated detection rule sets.

**D.** Create and schedule a dashboard to send periodic summaries of the active breach IOCs and their associated events.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 26

Contexto: [topics:107](#topics-107)
Your company has deployed two on-premises firewalls. You need to configure the firewalls to send logs to Google Security Operations (SecOps) using Syslog. What should you do?

**A.** Pull the firewall logs by using a Google SecOps feed integration.

**B.** Set the Google SecOps URL instance as the Syslog destination.

**C.** Deploy a third-party agent (e.g Bindplane, NXLog) on your on-premises environment, and set the agent as the Syslog destination.

**D.** Deploy a Google Ops Agent on your on-premises environment, and set the agent as the Syslog destination.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 27

Contexto: [topics:107](#topics-107)
You are a platform engineer at an organization that is migrating from a third-party SIEM product to Google Security Operations (SecOps). You previously manually exported context data from Active Directory (AD) and imported the data into your previous SIEM as a watchlist when there were changes in AD's user/asset context data. You want to improve this process using Google SecOps. What should you do?

**A.** Configure a Google SecOps SOAR integration for AD to enrich user/asset information in your security alerts.

**B.** Create a reference list that contains the AD context data. Use the reference list in your YARA-L rule to find user/asset information for each security event.

**C.** Create a data table that contains AD context data. Use the data table in your YARA-L rule to find user/asset data that can be correlated within each security event.

**D.** Ingest AD organizational context data as user/asset context to enrich user/asset information in your security events.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 28

Contexto: [topics:107](#topics-107)
You manage a large fleet of Compute Engine instances. Security Health Analytics (SHA) has generated a CONFIDENTIAL_COMPUTING_DISABLED finding within Security Command Center (SCC). You need to quickly remediate this finding. What should you do?

**A.** Delete the offending VM instance, and mute the finding.

**B.** Delete the offending VM instance, and disable the SHA detector.

**C.** Delete the offending VM instance, and manually mark the finding as inactive.

**D.** Delete the offending VM instance, and allow the finding to be automatically marked as inactive.

**Respuesta de la fuente:** C

**Explicación:** Deleting the VM instance eliminates the root cause of the finding. Since the question asks for quick remediation, manually marking the finding as inactive provides immediate closure in Security Command Center, whereas waiting for automatic re-scanning (auto-correction) introduces unnecessary delay.

## Pregunta 29

Contexto: [topics:107](#topics-107)
Your company's SOC recently responded to a ransomware incident that began with the execution of a malicious document. EDR tools contained the initial infection. However, multiple privileged service accounts continued to exhibit anomalous behavior, including credential dumping and scheduled task creation. You need to design an automated playbook in Google Security Operations (SecOps) SOAR to minimize dwell time and accelerate containment for future similar attacks. Which action should you take in your Google SecOps SOAR playbook to support containment and escalation?

**A.** Configure a step that revokes OAuth tokens and suspends sessions for high-privilege accounts based on entity risk.

**B.** Add an approval step that requires an analyst to validate the alert before executing a containment action.

**C.** Create an external API call to VirusTotal to submit hashes from forensic artifacts.

**D.** Add a YARA-L rule that sends an alert when a document is executed using a scripting engine such as wscript.exe.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 30

Contexto: [topics:107](#topics-107)
Your organization uses Google Security Operations (SecOps) for security analysis and investigation. Your organization has decided that all security cases related to Data Loss Prevention (DLP) events must be categorized with a defined root cause specific to one of five DLP event types when the case is closed in Google SecOps. How should you achieve this?

**A.** Customize the Close Case dialog and add the five DLP event types as root cause options.

**B.** Customize the Case Name format to include the DLP event type.

**C.** Create a Google SecOps SOAR playbook that automatically assigns case tags where each tag contains the unique definition of one of the five DLP event types.

**D.** Create case tags in Google SecOps SOAR where each tag contains a unique definition of each of the five DLP event types, and have analysts assign them to cases manually.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 31

Contexto: [topics:107](#topics-107)
You are investigating an alert in Google Security Operations (SecOps). You want to view previous enrichment attributes and relevant historical cases for an entity using the fewest number of steps. What should you do?

**A.** Initiate a SIEM Search to query the entity.

**B.** Initiate a SOAR Search to query the entity.

**C.** Select View Details for the entity in the Entity Highlights widget.

**D.** Select the entity identifier in the Entity Highlights widget to open Entity Explorer.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 32

Contexto: [topics:107](#topics-107)
During a proactive threat hunting exercise, you discover that a critical production project has an external identity with a highly privileged IAM role. You suspect that this is part of a larger intrusion, and it is unknown how long this identity has had access. All logs are enabled and routed to a centralized organization-level Cloud Logging bucket, and historical logs have been exported to BigQuery datasets. You need to determine whether any actions were taken by this external identity in your environment. What should you do?

**A.** Use Policy Analyzer to identity the resources that are accessible by the external identity. Examine the logs related to these resources in the centralized Cloud Logging bucket and the BigQuery dataset.

**B.** Analyze VPC Flow Logs exported to BigQuery, and correlate source IP addresses with potential login events for the external identity.

**C.** Analyze IAM recommender insights and Security Command Center (SCC) findings associated with the external identity.

**D.** Execute queries against the centralized Cloud Logging bucket and the BigQuery dataset to filter for logs for where the principal email matches the external identity.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 33

Contexto: [topics:107](#topics-107)
You are a security analyst at an organization that uses Google Security Operations (SecOps). You notice suspicious login attempts on several user accounts. You need to determine whether these attempts are part of a coordinated attack as quickly as possible. What action should you take first?

**A.** Enable default curated detections to automatically block suspicious IP addresses.

**B.** Use UDM Search to query historical logs for recent IOCs associated with the suspicious login attempts.

**C.** Remove user accounts that have repeated invalid login attempts.

**D.** Look for correlations across impacted users in the Risk Analytics dashboard.

**Respuesta de la fuente:** B

**Explicación:** To determine if the attempts are a coordinated attack, you must first investigate the data to identify common indicators of compromise (IOCs) like source IPs or user agents across multiple accounts.

Universal Data Model (UDM) Search allows for this rapid querying and correlation of historical log events, providing the evidence needed before taking blocking actions or relying on automated dashboards.

## Pregunta 34

Contexto: [topics:107](#topics-107)
Your Google Security Operations (SecOps) instance is generating a high volume of alerts related to an IP address that recently appeared in a threat intelligence feed. The IP address is flagged as a known command and control (C2) server by multiple vendors. The IP address appears in repeated DNS queries originating from a sandboxing system and test environment used by your malware analysis team. You want to avoid alert fatigue while preserving visibility in the event that the IOC reappears in real production telemetry. What should you do?

**A.** Temporarily disable the rule to avoid unnecessary alerts until the IOC expires in the threat feed.

**B.** Add the IP address to a Google SecOps reference list, and configure the rule to suppress alerts for that list.

**C.** Reduce the severity score in the rule configuration when the IOC match occurs in any internal IP address range.

**D.** Add an exception in the detection rule to exclude matches originating from specific asset groups.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 35

Contexto: [topics:107](#topics-107)
You are threat hunting for an advanced threat group known for targeted, novel attacks by deploying campaign-specific infrastructure. You want to develop detections based on the threat group's behaviors so you can effectively detect whether the threat group has attacked your organization. What should you do?

**A.** Identify exposed technologies and products used by your organization, and develop detections to search for signs of exploitation.

**B.** Find intelligence reports in Google Threat Intelligence that relate to the threat actor, identify their behavior in previous campaigns, and use the past behavior to design detections in Google Security Operations (SecOps).

**C.** Search for the threat actor in Google Threat Intelligence, export the IOCs associated with the threat actor into a Google Security Operations (SecOps) list, and develop detections that reference this list.

**D.** Search for the threat actor in Google Threat Intelligence, review the threat actor's tactics, techniques, and procedures (TTPs), and design detections based on the TTPs in Google Security Operations (SecOps).

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 36

Contexto: [topics:107](#topics-107)
You work for a large international company that has several Compute Engine instances running in production. You need to configure monitoring and alerting for Compute Engine instances tagged with compliance=pci that have an external IP address assigned. What should you do?

**A.** Create a custom Event Threat Detection module that alerts when a Compute Engine instance with the compliance=pci tag is assigned an external IP address.

**B.** Deploy the compute.vmExternalIpAccess organization policy constraint to prevent specific projects or folders with the compliance=pci tag from creating Compute Engine instances with external IP addresses.

**C.** Create a custom Security Health Analytics (SHA) module. Configure the detection logic to scan Cloud Asset Inventory data for compute.googleapis.com/Instance assets, and Search for the compliance=pci tag.

**D.** Use the PUBLIC_IP_ADDRESS Security Health Analytics (SHA) detector to identify Compute Engine instances with external IP addresses. Determine whether the compliance=pci tag exists on the instances.

**Respuesta de la fuente:** C

**Explicación:** Custom Security Health Analytics (SHA) modules allow you to define specific detection logic by scanning Cloud Asset Inventory data. By filtering for `compute.googleapis.com/Instance` assets and checking for the `compliance=pci` tag alongside external IP assignment, you create targeted alerts for the exact compliance violation described. Other options either block creation (Organization Policy) rather than alerting on existing state, or use generic detectors that lack the specific tag-based filtering required.

## Pregunta 37

Contexto: [topics:107](#topics-107)
Your company's analyst team uses a playbook to make necessary changes to external systems that are integrated with the Google Security Operations (SecOps) platform. You need to automate the task to run once every day at a specific time. You want your solution to minimize maintenance overhead. What should you do?

**A.** Write a custom Google SecOps SOAR job in the IDE using the code from the existing playbook actions.

**B.** Create a Google SecOps SOAR request and a playbook trigger to match the request from the user to start the playbook with the relevant actions.

**C.** Create a Cron Scheduled Connector for this use case Configure a playbook trigger to match the cases created by the connector that runs the playbook with the relevant actions.

**D.** Use a VM to host a script that runs a playbook via an API call.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 38

Contexto: [topics:107](#topics-107)
You have discovered that a server that hosts an internal web application has been accidentally exposed to the internet for 48 hours. Logging is enabled on the server. You want to use Google Security Operations (SecOps) to run a UDM search against the server logs to identify whether there have been any successful exploitations against it. What event field search should you use?

**A.** Perform a search for antimalware or endpoint security events by using the product_event_type UDM field.

**B.** Perform a search for sign-on activity for user accounts that are not expected on the server by using the principal.user.userid UDM field.

**C.** Perform a search for network traffic where the principal is rarely seen by using the principal.ip UDM field.

**D.** Perform a search for process launches and commands that are rarely seen by using the metadata.event_type UDM field.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 39

Contexto: [topics:107](#topics-107)
You have been tasked with creating a YARA-L detection rule in Google Security Operations (SecOps). The rule should identify when an internal host initiates a network connection to an external IP address that the Applied Threat Intelligence Fusion Feed associates with indicators attributed to a specific Advanced Persistent Threat 41 (APT41) threat group. You need to ensure that the external IP address is flagged if it has a documented relationship to other APT41 indicators within the Fusion Feed. How should you configure this YARA-L rule?

**A.** Configure the rule to detect outbound network connections to the external IP address. Create a Google SecOps SOAR playbook that queries the Fusion Feed to determine if the IP address has an APT41 relationship.

**B.** Configure the rule to establish a join between the live network connection event and Fusion Feed data for the common external IP address. Filter the joined Fusion Feed data for explicit associations with the APT41 threat group or related indicators.

**C.** Configure the rule to check whether the external IP address from the network connection event has a high confidence score across any enabled threat intelligence feed.

**D.** Configure the rule to trigger when the external IP address from the network connection event matches an entry in a manually pre-curated reference list of all APT41-related IP addresses.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 40

Contexto: [topics:107](#topics-107)
You are writing a detection rule in Google Security Operations (SecOps) SIEM that sends a risk score to the alert. You have access to Google Threat Intelligence (GTI) data through your Google SecOps subscription. You need to ensure that the threat score output in the detection logic informs the alert's risk score and is available for future detections. What should you do?

**A.** Use the outcomes section of your detection logic to pull UDM enrichment fields from the event data. Apply logic to determine the total risk outcome, and store the risk score as the risk_score variable

**B.** Use the match section of your detection logic to filter out irrelevant entities. Store the remaining entities as the risk_score variable.

**C.** Configure a feed in Google SecOps SIEM to ingest GTI data to automatically enrich the appropriate entities.

**D.** Create a Google SecOps SOAR playbook to query GTI that uses the VirusTotal integration to enrich the alert. Modify the risk_score context value to match.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 41

Contexto: [topics:107](#topics-107)
You are a SOC manager, and your company recently migrated to Google Security Operations (SecOps). As the team grows, you want to monitor all audit logs related to data feeds in Google SecOps. What should you do?

**A.** Enable Data Access and Admin Activity audit logs in Cloud Logging, and ingest those logs into Google SecOps SIEM.

**B.** Ingest the Google SecOps audit logs into Google SecOps SIEM for monitoring.

**C.** Monitor Google SecOps SOAR user activity logs for administrative activity.

**D.** Configure the Cloud Logging filter to ingest audit logs related to data feeds into Google SecOps for monitoring.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 42

Contexto: [topics:107](#topics-107)
Your company is taking a more proactive approach to security. You want to generate an alert when a binary hash first appears in your environment. What should you do?

**A.** Enable the Applied Threat Intelligence - Curated Prioritization rule set in curated detections.

**B.** Navigate to the Alerts & IOCs page in Google Security Operations (SecOps). Create a filter that targets hashes and specifies a first_seen_time value excluding the current date.

**C.** Write a rule to examine file-related events that join with derived context for hashes in the entity graph. Compare the timestamp of the hash with the first_seen_time field.

**D.** Create a table by using the Google Security Operations (SecOps) statistics in search to examine file-related events for the current day. Verify that the first_seen_time value predates the current day.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 43

Contexto: [topics:107](#topics-107)
You are a SOC manager guiding an implementation of your existing incident response plan (IRP) into Google Security Operations (SecOps). You need to capture time duration data for each of the case stages. You want your solution to minimize maintenance overhead. What should you do?

**A.** Configure a detection rule in SIEM Rules & Detections to include logic to capture the event fields for each case with the relevant stage metrics.

**B.** Write a job in the IDE that runs frequently to check the progress of each case and updates the notes with timestamps to reflect when these changes were identified.

**C.** Configure Case Stages in the Google SecOps SOAR settings, and use the Change Case Stage action in your playbooks that captures time metrics when the stage changes.

**D.** Create a Google SecOps SOAR dashboard that displays specific actions that have been run, identifies which stage a case is in, and calculates the time elapsed since the start of the case.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 44

Contexto: [topics:107](#topics-107)
Your organization recently implemented Google Security Operations (SecOps) with Applied Threat Intelligence enabled. You were notified by the networking team about potentially anomalous communications to external domains in the last 30 days. You plan to start your threat hunting by looking at communications to external domains. You are ingesting the following logs into Google SecOps:

Firewall logs -

Proxy logs -

DNS logs -

DHCP logs -
What should you do? (Choose two.)

**A.** Perform a UDM search across the logs for domains with geolocations that were first seen in the last 30 days.

**B.** Perform a UDM search across the logs for domains with low prevalence that were first seen in the last 30 days.

**C.** Perform a raw log search across the logs for domains with low prevalence that were first seen in the last 30 days.

**D.** Identify the domains with the higher normalized risk in Risk Analytics. Drill down into those entities to determine their prevalence and if they were first seen in the last 30 days.

**E.** Navigate to the IOC Matches page and filter based on domain type over the last 30 days. Look for the first seen and last seen timestamps for the reported domains. Investigate these domains using the IOC drilldown link.

**Respuesta de la fuente:** B, E

**Explicación:** Option B is correct because Unified Data Model (UDM) searches allow you to correlate low-prevalence domains across different log types, a key indicator of potential malicious activity.

Option E is the best complementary action because the IOC Matches page leverages Applied Threat Intelligence to identify known bad indicators and provides drill-down capabilities for detailed investigation.

## Pregunta 45

Contexto: [topics:107](#topics-107)
Your company recently started pulling JSON logs from a third-party system into Google Security Operations (SecOps). You noticed that some fields are missing, and you want to parse them into UDM fields as quickly as possible. What should you do?

**A.** Configure auto extraction to add the additional fields.

**B.** Create parser extensions using the no-code approach.

**C.** Create parser extensions using the code snippet approach.

**D.** Submit a parser improvement request to Cloud Customer Care.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 46

Contexto: [topics:107](#topics-107)
You are a security engineer at a managed security service provider (MSSP) that is onboarding to Google Security Operations (SecOps). You need to ensure that cases for each customer are logically separated. How should you configure this logical separation?

**A.** In Google SecOps SOAR settings, create a new environment for each customer.

**B.** In Google SecOps SOAR settings, create a role for each customer.

**C.** In Google SecOps SOAR settings, create a permissions group for each customer.

**D.** In Google SecOps Playbooks, create a playbook for each customer.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 47

Contexto: [topics:107](#topics-107)
Your organization recently conducted a penetration test on their environment. You have been tasked with identifying a successful attack chain. The required log sources have been ingested into Google Security Operations (SecOps). You discover anomalous outbound traffic to external domains. You suspect that the finding is a communication to a command and control (C2) infrastructure. You need to identify the least common network communications over the last 14 days. What should you do?

**A.** Perform a Google SecOps SIEM UDM search that looks for NETWORK_CONNECTION or NETWORK_HTTP events with low rolling prevalence for target domains over the last 14 days.

**B.** Perform a Google SecOps SIEM UDM search that looks for NETWORK_CONNECTION or NETWORK_HTTP events with low rolling prevalence for principal domains over the last 14 days.

**C.** Perform a Google SecOps SOAR search that looks for cases with low rolling prevalence of NETWORK_CONNECTION or NETWORK_HTTP events over the last 14 days.

**D.** Perform a Google SecOps SIEM raw log search that looks for low rolling prevalence domains with NETWORK_CONNECTION or NETWORK_HTTP in the firewall and proxy logs over the last 14 days.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 48

Contexto: [topics:107](#topics-107)
Your organization is conducting a penetration test. The CISO has asked you to implement a real-time method to track cases that originate from the penetration test, and clearly differentiate these cases from other security incidents. You need to recommend the most effective and efficient approach to achieve this goal in Google Security Operations (SecOps). What should you do?

**A.** Implement case tagging within Google SecOps and apply a unique tag (e.g., PenTest) to all cases related to the penetration test entities. Use this tag for filtering and monitoring.

**B.** Create a dashboard that is connected to the Google SecOps data lake. Use pre-built templates to visualize case status based on the penetration testing IP address range.

**C.** Create a custom Google SecOps SOAR playbook that automatically extracts case metadata, including key findings and risk scores, and sends an email summary to the CISO.

**D.** Configure a custom alert rule that triggers a high-severity alert for all activity originating from the penetration testing team's source IP addresses and sends a notification for potential critical vulnerabilities. Verify that these alerts are immediately visible in the alert queue.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 49

Contexto: [topics:107](#topics-107)
You are tasked with building a workflow in Google Security Operations (SecOps) SOAR. The documentation you are using requires a logical split that has eight different possible paths. You need to break the workflow into eight separate workflows using an automatic and efficient approach. What should you do?

**A.** Create eight playbooks for each workflow. Configure the triggered playbook to end on an instruction action that tells the analyst to pick a workflow from the playbooks tab and attach that workflow to the alert.

**B.** Create eight playbooks for each workflow. Create a job that identifies your recently opened cases, applies the needed logic to determine which of the eight workflows should be attached, and attaches that workflow to the alert.

**C.** Create a playbook that uses a flow condition. Add four more branches to have a total of five branches and an "Else" branch. On the "Else" branch, include another flow condition. Include the remaining three branches with the logic required.

**D.** Create a playbook that uses a Multi-Choice Question flow and a second Multi-Choice Question for the additional answer choices. Add instructions describing which logic to use in the instruction or question fields. Have the analyst select the appropriate answer to move the flow into the right branch.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google Security Operations (formerly SOAR) playbook flow conditions support a maximum of four branches plus an Else branch. To achieve eight logical paths automatically, you must nest additional flow conditions within the Else branch to expand the branching capability beyond the initial limit. Options A and D are incorrect as they require manual analyst intervention, violating the requirement for an automatic approach. Option B is inefficient and architecturally unsound compared to native conditional logic.

## Pregunta 50

Contexto: [topics:107](#topics-107)
You are a member of the incident response team working in a global enterprise. You need to identify all potential Google Threat Intelligence IOCs within your organization's data using Google Security Operations (SecOps). What should you do?

**A.** Use the Cases page in Google SecOps.

**B.** Create YARA-L rules to detect and alert when Google Threat Intelligence identifies potential threats.

**C.** Use Gemini to perform a search for potential cybersecurity threats against your organization's data.

**D.** Use the Alerts & IOCs page in Google SecOps.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 51

Contexto: [topics:107](#topics-107)
You are a security operations engineer in an enterprise that uses Google Security Operations (SecOps). Your organization recently faced a cybersecurity breach. You need to increase the threat analytics as quickly as possible. What should you do?

**A.** Enable curated detections to identify threats.

**B.** Design YARA-L detection rules based on Google SecOps Marketplace use cases.

**C.** Develop YARA-L detection rules that focus on threat intelligence.

**D.** Ingest data from a threat intelligence platform (TIP) into Google SecOps.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 52

Contexto: [topics:107](#topics-107)
You are investigating whether an advanced persistent threat (APT) actor has operated in your organization's environment undetected. You have received threat intelligence that includes:
A SHA256 hash for a malicious DLL
A known command and control (C2) domain
A behavior pattern where rundll32.exe spawns powershell.exe with obfuscated arguments
Your Google Security Operations (SecOps) instance includes logs from EDR, DNS, and Windows Sysmon. However, you have recently discovered that process hashes are not reliably captured across all endpoints due to an inconsistent Sysmon configuration. You need to use Google SecOps to develop a detection mechanism that identifies the associated activities. What should you do?

**A.** Write a multi-event YARA-L detection rule that correlates the process relationship and hash, and run a retrohunt based on this rule.

**B.** Build a reference list that contains the hash and domain, and link the list to a high-frequency rule for near real-time alerting.

**C.** Create a single-event YARA-L detection rule based on the file hash, and run the rule against historical and incoming telemetry to detect the DLL execution.

**D.** Use Google SecOps search to identify recent uses of rundll32.exe, and tag affected assets for watchlisting.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 53

Contexto: [topics:107](#topics-107)
You are a SOC manager at an organization that recently implemented Google Security Operations (SecOps). You need to monitor your organization's data ingestion health in Google SecOps. Data is ingested with Bindplane collection agents. You want to configure the following:
Receive a notification when data sources go silent within 15 minutes.
Visualize ingestion throughput and parsing errors.
What should you do?

**A.** Configure notifications in Cloud Monitoring when ingestion sources become silent in Bindplane. Monitor and visualize Google SecOps data ingestion metrics using Bindplane Observability Pipeline (OP).

**B.** Configure silent source notifications for Google SecOps collection agents in Cloud Monitoring. Create a Cloud Monitoring dashboard to visualize data ingestion metrics.

**C.** Configure silent source alerts based on rule detections for anomalous data ingestion activity in Risk Analytics. Monitor and visualize the alert metrics in the Risk Analytics dashboard.

**D.** Configure automated scheduled delivery of an ingestion health report in the Data Ingestion and Health dashboard. Monitor and visualize data ingestion metrics in this dashboard.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 54

Contexto: [topics:107](#topics-107)
Your organization has recently onboarded to Google Cloud with Security Command Center Enterprise (SCCE) and is now integrating it with your organization's SOC. You want to automate the response process and integrate with the existing SOW ticketing system. How should you implement this functionality?

**A.** Evaluate each event within the SCC console. Create a ticket for each finding in the ticketing system, and include the remediation steps.

**B.** Use the SCC notifications feed to send alerts to Pub/Sub. Ingest these feeds using the relevant SIEM connector.

**C.** Configure the SCC notifications feed to use Pub/Sub for alerts. Create a Cloud Run function to trigger when an event arrives in the topic and generate a ticket by calling the API endpoint in the SOC ticketing system.

**D.** Disable the generic posture finding playbook in Google Security Operations (SecOps) SOAR and enable the playbook for the ticketing system. Add a step in your Google SecOps SOAR playbook to generate a ticket based on the event type.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 55

Contexto: [topics:107](#topics-107)
You are creating a playbook for the SOC. The SOC requires that each Google Security Operations (SecOps) role sees different information for the alert that the playbook runs on. You need to ensure that the playbook presents the relevant information for each Google SecOps role. What should you do?

**A.** Add a view to the playbook for each Google SecOps role.

**B.** Add the Case Comment action to the playbook for each Google SecOps role.

**C.** Add the Create Siemplify Task action to the playbook to assign a task to each Google SecOps role.

**D.** Add the Add General insight action to the playbook for each Google SecOps role.

**Respuesta de la fuente:** A

**Explicación:** Google Security Operations uses Views to customize the interface layout and widget visibility based on user roles.
By creating a specific View for each SOC role within the playbook, you ensure that analysts only see the alert information and tools relevant to their specific function.
This prevents information overload and aligns with the principle of least privilege for data exposure.

## Pregunta 56

Contexto: [topics:107](#topics-107)
You are responsible for evaluating the level of effort required to integrate a new third-party endpoint detection tool with Google Security Operations (SecOps). Your organization's leadership wants to minimize customization for the new tool for faster deployment. You need to verify that the Google SecOps SOAR and SIEM support the expected workflows for the new third-party tool. You must recommend a tool to your leadership team as quickly as possible. What should you do? (Choose two.)

**A.** Develop a custom integration that uses Python scripts and Cloud Run functions to forward logs and orchestrate actions between the third-party tool and Google SecOps.

**B.** Configure a Pub/Sub topic to ingest raw logs from the third-party tool and build custom YARA-L rules in Google SecOps to extract relevant security events.

**C.** Review the architecture of the tool to identify the cloud provider that hosts the tool.

**D.** Review' the documentation to identify if default parsers exist for the tool, and determine whether the logs are supported and able to be ingested.

**E.** Identify the tool in the Google SecOps Marketplace and verify support for the necessary actions in the workflow.

**Respuesta de la fuente:** D, E

**Explicación:** No conservada en esta captura.

## Pregunta 57

Contexto: [topics:107](#topics-107)
You are the SOC manager at a large enterprise that uses Google Security Operations (SecOps). You need to create a report that shows the Return on Investment (ROI) attributed to analyst activities in Google SecOps SOAR for the previous month. The report should include the time saved and efficiency gains from using SOAR's features. You need to generate this report using the most efficient and accurate approach while providing the required level of detail. What should you do?

**A.** Create a custom Google SecOps SOAR search query that filters for all cases handled by specific analysts in the last month. Export the results to a spreadsheet for analysis and ROI calculation.

**B.** Use the ROI - Analysts Benchmark report in SOAR Reports. Configure the report to display data for the desired time period, and filter by individual analysts.

**C.** Use the filters and visualizations in the Management - SOC Status report in SOAR Reports to extract case-specific performance data.

**D.** Develop a Google SecOps SOAR playbook that automatically aggregates analyst performance metrics, incorporates custom weighted factors for different case types, calculates ROI based on predefined formulas, and generates a PDF report on a monthly schedule.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 58

Contexto: [topics:107](#topics-107)
Your company works with an external Managed Service Provider (MSP) that requires its users to have the ability to list findings from Security Command Center (SCC) using the Google Cloud SDK. You need to configure the required access for the managed service provider while minimizing your involvement in their external user lifecycle management processes. What should you do?

**A.** Create a user account in your Cloud Identity instance using a subdomain indicating they are external to your organization. Grant this user account the appropriate IAM role at the organization level.

**B.** Create a service account in a SCC project. Grant the MSP user permission to impersonate this account. Grant this service account the appropriate IAM role at the organization level.

**C.** Create a workload identity pool in a SCC project. Grant the MSP user the permission to impersonate a service account from this pool, and grant the service account the appropriate IAM role at the organization level.

**D.** Create a workforce identity pool and federate with the identity provider (IdP) of the managed service provider. Grant users of the MSP the appropriate IAM role at the organization level.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 59

Contexto: [topics:107](#topics-107)
You are conducting a proactive threat hunt in Google Security Operations (SecOps). You observe multiple login events with the same principal.user.userid field that originate from different countries within a short time window. You need to validate whether the account has been compromised. What should you do?

**A.** Use the entity graph to correlate the user's risk score with linked assets, and review any active alerts.

**B.** Perform a YARA-L 2.0 search for login events and their associated principal.location.country field. Use an outcome field to aggregate the number of failed logins.

**C.** Perform a UDM search for login events, and pivot to group results by user and country of origin.

**D.** Run a YARA-L retrohunt rule that detects users who are logging in from multiple regions using multiple entity contexts.

**Respuesta de la fuente:** A

**Explicación:** The goal is to validate compromise, which requires context beyond the initial observation of impossible travel.
Using the entity graph (Option A) allows you to correlate the suspicious user activity with their aggregated risk score and review linked alerts or assets, providing immediate evidence of malicious intent or impact.
Options B, C, and D primarily focus on re-querying raw event data or historical patterns, which confirms the anomaly but does not inherently validate whether it constitutes a compromise without additional risk context.

## Pregunta 60

Contexto: [topics:107](#topics-107)
You are using a Google-managed image on a Compute Engine instance in Google Cloud to run an application. You need to ingest the application's log output into Google Security Operations (SecOps). The log output is standard and has a valid label and parser in Google SecOps. Your solution must minimize the cost and time required to move this data into Google SecOps. What should you do?

**A.** Use the Ops Agent embedded in the Compute Engine image to pull the logs into Cloud Logging. Use the direct ingestion mechanism to ingest the logs from Google Cloud into Google SecOps.

**B.** Deploy a Bindplane agent on the image to collect and send the logs to Google SecOps.

**C.** Create a script on the workload that reads the logs and uses the Google SecOps Ingestion API to push them to Google SecOps.

**D.** Use the Ops Agent embedded in the Compute Engine image to pull the logs into a Cloud Storage bucket. Create a feed in Google SecOps to ingest the logs.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 61

Contexto: [topics:107](#topics-107)
You are a security analyst at a company that uses Google Security Operations (SecOps) Enterprise. Security Command Center Enterprise (SCCE), and Google Threat Intelligence (GTI). You need to leverage threat intelligence to improve threat hunting capabilities to proactively identify novel and emerging attack patterns targeting your Google Cloud environment in near real-time. What should you do?

**A.** Use the built-in threat intelligence of Event Threat Detection in SCCE to detect relevant threats.

**B.** Configure an Applied Threat Intelligence Fusion Feed in Google SecOps, and develop YARA-L detection rules to search ingested Google Cloud telemetry for patterns matching this intelligence.

**C.** Route all Google Cloud logs to a dedicated BigQuery dataset, and use scheduled queries with curated open-source threat intelligence feeds.

**D.** Configure Google Cloud Armor security policies with preconfigured web application firewall (WAF) rule sets, and enable Adaptive Protection to use GTI.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 62

Contexto: [topics:107](#topics-107)
You are developing a playbook to respond to phishing reports from users at your company. You configured a UDM query action to identify all users who have connected to a malicious domain. You need to extract the users from the UDM query and add them as entities in an alert so the playbook can reset the password for those users. You want to minimize the amount of effort required by the SOC analyst. What should you do?

**A.** Use the Create Entity action from the Siemplify integration. Use the Expression Builder to create a placeholder with the usernames in the Entities Identifier parameter.

**B.** Create a case for each identified user with the user designated as the entity.

**C.** Implement an Instruction action from the Flow integration that instructs the analyst to add the entities in the Google SecOps user interface.

**D.** Configure a manual Create Entity action from the Siemplify integration that instructs the analyst to input the Entities Identifier parameter based on the results of the action.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 63

Contexto: [topics:107](#topics-107)
You are a security engineer at a financial technology company. You need to create a centralized dashboard to provide security posture visibility for your leadership team. The dashboard must meet these requirements:
Provide insights from Security Command Center (SCC) findings and security-related events captured in Cloud Logging.
Support large volumes of historical data.
Be able to join SCC findings and audit logs.
You want to use the most effective visualization solution that uses Google Cloud managed services. What should you do?

**A.** Ingest the SCC findings and Cloud Audit Logs into a Cloud Storage bucket. Write a Python script that reads the data and uses Matplotlib to create the visualizations.

**B.** Create custom metrics in Cloud Monitoring based on the SCC findings, and configure log-based metrics for security-related events. Build Cloud Monitoring dashboards to visualize these custom and log-based metrics.

**C.** Export SCC findings and Cloud Audit Logs to BigQuery. Connect Looker Studio to the BigQuery datasets, and create the visualizations and filters.

**D.** Use the built-in SCC dashboard to visualize the SCC finding, and extract log counts for specific log events from Cloud Audit Logs.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 64

Contexto: [topics:107](#topics-107)
Your organization has mission-critical production Compute Engine VMS that you monitor daily. While performing a UDM search in Google Security Operations (SecOps), you discover several outbound network connections from one of the production VMs to an unfamiliar external IP address occurring over the last 48 hours. You need to use Google SecOps to quickly gather more context and assess the reputation of the external IP address. What should you do?

**A.** Examine the Google SecOps Asset view details for the production VM.

**B.** Create a new detection rule to alert on future traffic from the external IP address.

**C.** Search for the external IP address in the Alerts & IOCs page in Google SecOps.

**D.** Perform a UDM search to identify the specific user account that was logged into the production VM when the connections occurred.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 65

Contexto: [topics:107](#topics-107)
You are responsible for identifying suspicious activity and security events in your organization's environment. You discover that some detection rules are being triggered for internal IP addresses in the 192.0.2.0/8 subnet that are causing false positive alerts. You want to improve these detection rules. What should you add to the YARA-L detection rules?

**A.** net.ip_in_range_cidr(all Se.principal.ip, "192.0.2.0/8")

**B.** net.ip_in_range_cidr(any Se.principal.ip, "192.0.2.0/8")

**C.** not net.ip_in_range_cidr(all Se.principal.ip, "192.0.2.0/8")

**D.** not net.ip_in_range_cidr(any Se.principal.ip, "192.0.2.0/8")

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 66

Contexto: [topics:107](#topics-107)
Your team has onboarded a new log source from a third-party DNS filtering solution. After ingestion, you observe that key UDM fields such as network.dns.questions.name and metadata.product_event_type are missing from the parsed events in Google Security Operations (SecOps). You suspect that the default parser does not fully align with the source format. You need to ensure these fields are available for downstream detection rules that rely on DNS query telemetry and event categorization. What should you do?

**A.** Modify the ingestion source definition to remap raw fields directly to UDM by using the UDM sample output.

**B.** Enable asset enrichment for the log source to infer missing fields based on correlated host activity.

**C.** Use a custom parser that outputs all fields as raw JSON for detection.

**D.** Create a parser extension that maps the missing source fields to the correct UDM fields and attach it to the existing parser.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 67

Contexto: [topics:107](#topics-107)
You are ingesting and parsing logs from an SSO provider and an on-premises appliance using Google Security Operations (SecOps). Users are tagged as "restricted” by an internal process. Restrictions last five days from the most recent flagging time. You need to create a rule to detect when restricted users log into the appliance. Your solution must be quickly implemented and easily maintained. What should you do?

**A.** Use a Google SecOps SOAR global context value to store a list of flagged users with their corresponding time to live values. Use a SOAR job to dynamically build and deploy a new version of the detection rule with the updated list of flagged users.

**B.** Store the identifiers of the flagged users in the detection rule logic. Actively monitor for newly flagged users, and add them to the detection rule logic.

**C.** Ingest the user flags as custom enrichment data using a feed. Use a multi-event detection rule to find logins from users flagged in the entity graph.

**D.** Store the flagged users in a data table column with their corresponding time to live values in a second column. Use row-based comparisons in your detection rule.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 68

Contexto: [topics:107](#topics-107)
You are receiving security alerts from multiple connectors in your Google Security Operations (SecOps) instance. You need to identify which IP address entities are internal to your network and label each entity with its specific network name. This network name will be used as the trigger for the playbook. What should you do?

**A.** Configure each network in the Google SecOps SOAR settings.

**B.** Enrich the IP address entities as the initial step of the playbook.

**C.** Modify the entity attribute in the alert overview.

**D.** Create an outcome variable in the rule to assign the network name.

**Respuesta de la fuente:** A

**Explicación:** Google SecOps SOAR uses a centralized configuration to define internal IP ranges and their associated network names.
By configuring these networks in the SOAR settings, the platform automatically identifies and labels IP address entities as internal during alert processing.
This pre-defined labeling allows playbooks to trigger based on the specific network name without requiring manual enrichment steps.

## Pregunta 69

Contexto: [topics:107](#topics-107)
You have identified a common malware variant on a potentially infected computer. You need to find reliable IOCs and malware behaviors as quickly as possible to confirm whether the computer is infected and search for signs of infection on other computers. What should you do?

**A.** Create a Compute Engine VM, and perform dynamic and static malware analysis.

**B.** Perform a UDM search for the file checksum in Google Security Operations (SecOps). Review activities that are associated with, or attributed to the malware.

**C.** Run a Google Web Search for the malware hash, and review the results.

**D.** Search for the malware hash in Google Threat Intelligence, and review the results.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 70

Contexto: [topics:107](#topics-107)
Your Google Security Operations (SecOps) SOAR integration with Security Command Center (SCC) uses a service account that currently has read access to the findings at the organization level. Google SecOps SOAR successfully reads SCC finding data, but actions attempting to update the finding states consistently fail with a permission denied error. You need to resolve this error while following the principle of least privilege. What should you do?

**A.** Grant the service account the roles/securitycenter.findingsBulkMuteEditor IAM role at the organization level.

**B.** Grant the service account the roles/securitycenter.findingsEditor IAM role at the organization level.

**C.** Grant the service account the roles/iam.serviceAccountUser IAM role to itself.

**D.** Regenerate the service account key, and update the credentials in Google SecOps SOAR.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 71

Contexto: [topics:107](#topics-107)
You need to augment your organization's existing Security Command Center (SCC) implementation with additional detectors. You have a list of known IOCs and would like to include external signals for this capability to ensure broad detection coverage. What should you do?

**A.** Create an Event Threat Detection custom module using the "Configurable Bad IP" template.

**B.** Create a Security Health Analytics (SHA) custom module using the compute address resource.

**C.** Create a custom posture for your organization that combines the prebuilt Event Threat Detection and Security Health Analytics (SHA) detectors.

**D.** Create a custom log sink with internal and external IP addresses from threat intelligence. Use the SCC API to generate a finding for each event.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 72

Contexto: [topics:107](#topics-107)
Your organization recently implemented Google Security Operations (SecOps). You need to create a solution that allows the security team to monitor data ingestion into Google SecOps in real time. You also need to configure a solution that automatically sends a notification if one of the data sources stops ingesting data. You need to minimize the cost of these configurations. What should you do?

**A.** Create Looker dashboards to visualize the data ingestion, and configure an alerting policy in Looker to send a notification in case of failure.

**B.** Create Looker dashboards to visualize the data ingestion, and configure an alerting policy in Cloud Monitoring to send a notification in case of failure.

**C.** Use Google SecOps SIEM dashboards to visualize the data ingestion and configure an alerting policy in Cloud Logging to send a notification in case of failure.

**D.** Use Google SecOps SIEM dashboards to visualize the data ingestion, and configure an alerting policy in Cloud Monitoring to send a notification in case of failure.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 73

Contexto: [topics:107](#topics-107)
Your company's Google Security Operations (SecOps) instance has three roles: Tier 1, Tier 2, and Tier 3. Currently, analysts in all tiers can access all cases in Google SecOps. Your company's SOC has a new requirement to restrict access to cases assigned to the Tier 3 role from the other tiers. You need to ensure cases that are assigned to the Tier 3 role can only be accessed by Tier 3 analysts. What should you do?

**A.** Instruct analysts in Tier 1 and Tier 2 to create a case queue filter to exclude cases assigned to the Tier 3 role.

**B.** Revoke additional role access from Tier 1 and Tier 2 analysts.

**C.** Configure the Cross Environment Policy to allow users to move cases between environments. Move Tier 3 cases to an environment that only Tier 3 analysts can access.

**D.** Assign the cases to a user in the Tier 3 role.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 74

Contexto: [topics:107](#topics-107)
You are the lead engineer on your organization's incident response team. You are running CrowdStrike Falcon and SentinelOne to protect the Windows devices in different regions of your organization. You are ingesting the following logs into Google Security Operations (SecOps):
Azure AD Directory Audit (AZURE_AD_AUDIT)
Crowdstrike Falcon (CS_EDR)
Microsoft Sysmon (WINDOWS_SYSMON)
SentinelOne (SENTINEL_EDR)
Windows Event (WINEVTLOG)
You notice that a high volume of ransomware incidents are impacting your team's SLAs. You need to automate the response to ransomware on Windows devices. How should you automate the detection and containment of ransomware incidents? (Choose two.)

**A.** Enable the Windows Threats category in curated detections to detect the latest Windows threats.

**B.** Enable the Risk Analytics for User and Endpoint Behavioral Analytics (UEBA) category in curated detections to detect peer group-based anomalous behavior and suspicious actions.

**C.** Install SOAR EDR integrations for endpoint containment actions. Create a playbook to contain impacted Windows devices based on curated detections.

**D.** Install SOAR EDR jobs to execute remote endpoint containment actions. Create a playbook to contain impacted Windows devices based on curated detections.

**E.** Install a SOAR remote agent on each Windows device for endpoint containment actions. Create a playbook to contain impacted Windows devices based on curated detections.

**Respuesta de la fuente:** A, C

**Explicación:** No conservada en esta captura.

## Pregunta 75

Contexto: [topics:107](#topics-107)
You need to ingest audit logs from your organization's entire Google Cloud environment into Google Security Operations (SecOps). This process must include Cloud NAT logs for workloads within a designated folder. You need to configure this ingestion while minimizing integration complexity. You have already enabled Google Cloud data ingestion into Google SecOps. What should you do next?

**A.** Create a custom filter to export the folder-level Cloud NAT logs.

**B.** Create a custom filter to export the project-level Cloud NAT logs for each project in the environment folder.

**C.** Configure an aggregated log sink at the folder level, and route the Cloud NAT logs to Pub/Sub. Enable the Pub/Sub connector for Google SecOps.

**D.** Configure an aggregated log sink at the organization level, and route the Cloud NAT logs to a Cloud Storage bucket. Configure the Cloud Storage connector for Google SecOps.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 76

Contexto: [topics:107](#topics-107)
You work for an organization that operates an ecommerce platform. You have identified a remote shell on your company's web host. The existing incident response playbook is outdated and lacks specific procedures for handling this attack. You want to create a new, functional playbook that can be deployed as soon as possible by junior analysts. You plan to use available tools in Google Security Operations (SecOps) to streamline the playbook creation process. What should you do?

**A.** Add instruction actions to the existing incident response playbook that include updated procedures with steps that should be completed. Have a senior analyst build out the playbook to include those new procedures.

**B.** Use the playbook creation feature in Gemini, and enter details about the intended objectives. Add the necessary customizations for your environment, and test the generated playbook against a simulated remote shell alert.

**C.** Use Gemini to generate a playbook based on a template from a standard incident response plan and implement automated scripts to filter network traffic based on known malicious IP addresses.

**D.** Create a new custom playbook based on industry best practices, and work with an offensive security team to test the playbook against a simulated remote shell alert.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 77

Contexto: [topics:107](#topics-107)
You recently joined a company that uses Google Security Operations (SecOps) with Applied Threat Intelligence enabled. You have alert fatigue from a recent red team exercise, and you want to reduce the amount of time spent sifting through noise. You need to filter out IOCs that you suspect were generated due to the exercise. What should you do?

**A.** Ask Gemini to provide a list of IOCs from the red team exercise.

**B.** Filter IOCs with an ingestion time that matches the time period of the red team exercise.

**C.** Navigate to the IOC Matches page. Identify and mute the IOCs from the red team exercise.

**D.** Navigate to the IOC Matches page. Review IOCs with an Indicator Confidence Score (IC-Score) label >= 80%.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 78

Contexto: [topics:107](#topics-107)
You are managing the integration of Security Command Center (SCC) with downstream tooling. You need to pull security findings from SCC and import those findings as part of Google Security Operations (SecOps) SOAR actions. You need to configure the connection between SCC and Google SecOps. What should you do?

**A.** Install the Google Rapid Response integration from the Google SecOps Marketplace. Gather information about the findings from the appropriate server.

**B.** Install the SCC integration from the Google SecOps Marketplace. Grant the SCC API the appropriate IAM roles to integrate with the Google SecOps instance. Configure this integration using a generated API key scoped to the SCC API.

**C.** Create a Pub/Sub topic with a NotificationConfig object and a push subscription for the desired finding types. Grant the Google SecOps service account the appropriate IAM roles to read from this subscription.

**D.** Create a Pub/Sub topic with a NotificationConfig object and a push subscription for the desired finding types. Create a new Google SecOps service account in the Google Cloud project, and grant this service account the appropriate IAM roles to read from this subscription. Export the credentials from IAM and import the credentials into Google SecOps SOAR.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 79

Contexto: [topics:107](#topics-107)
You are configuring a new integration in Google Security Operations (SecOps) to perform enrichment actions in playbooks. This enrichment technology is located in a private data center that does not allow inbound network connections. You need to connect your Google SecOps instance to the integration. What should you do?

**A.** Create a forwarder in the private data center. Configure an instance of the integration to run on the forwarder.

**B.** Query the enrichment source in the private data center and upload the results to the case wall in Google SecOps.

**C.** Create a network route in Google Cloud to the private data center.

**D.** Create a remote agent in the private data center. Configure an instance of the integration to run on a remote agent in Google SecOps.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 80

Contexto: [topics:107](#topics-107)
You use Google Security Operations (SecOps) curated detections and YARA-L rules to detect suspicious activity on Windows endpoints. Your source telemetry uses EDR and Windows Events logs. Your rules match on the principal.user.userid UDM field. You need to ingest an additional log source for this field to match all possible log entries from your EDR and Windows Event logs. What should you do?

**A.** Ingest logs from Windows Sysmon.

**B.** Ingest logs from Microsoft Entra ID.

**C.** Ingest logs from Windows PowerShell.

**D.** Ingest logs from Windows Procmon.

**Respuesta de la fuente:** B

**Explicación:** The principal.user.userid UDM field maps to the user's unique identifier (such as ObjectId or UPN) within the identity provider.
Microsoft Entra ID logs provide this authoritative identity context, ensuring that user actions in EDR and Windows Event logs can be correctly attributed even when local log entries lack explicit user identifiers.

## Pregunta 81

Contexto: [topics:107](#topics-107)
You are an incident response engineer at an organization that uses Google Security Operations (SecOps). You recently started monitoring IOCs in Applied Threat Intelligence using YARA-L rules. You have discovered that there are more false positive alerts than expected, which is causing noise for the SOC team. You need to reduce the number of false positive alerts. What should you do?

**A.** Modify the YARA-L rules to use an indicator confidence score (IC-Score) of 60% and above.

**B.** Configure alert grouping for the most repetitive alerts.

**C.** Implement curated detections instead of custom YARA-L rules.

**D.** Create a playbook that automatically tunes the IOC source if its indicator confidence score (IC-Score) is between 60% and 80%.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 82

Contexto: [topics:107](#topics-107)
You scheduled a Google Security Operations (SecOps) report to export results to a BigQuery dataset in your Google Cloud project. The report executes successfully in Google SecOps, but no data appears in the dataset. You confirmed that the dataset exists. How should you address this export failure?

**A.** Grant the Google SecOps service account the roles/iam.serviceAccountUser IAM role to itself.

**B.** Set a retention period for the BigQuery export.

**C.** Grant the user account that scheduled the report the roles/bigquery.dataEditor IAM role on the project.

**D.** Grant the Google SecOps service account the roles/bigquery.dataEditor IAM role on the dataset.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 83

Contexto: [topics:107](#topics-107)
Your organization's Google Security Operations (SecOps) tenant is ingesting a vendor's firewall logs in its default JSON format using the Google-provided parser for that log. The vendor recently released a patch that introduces a new field and renames an existing field in the logs. The parser does not recognize these two fields and they remain available only in the raw logs, while the rest of the log is parsed normally. You need to resolve this logging issue as soon as possible while minimizing the overall change management impact. What should you do?

**A.** Write a code snippet, and deploy it in a parser extension to map both fields to UDM.

**B.** Use the web interface-based custom parser feature in Google SecOps to copy the parser, and modify it to map both fields to UDM.

**C.** Deploy a third-party data pipeline management tool to ingest the logs, and transform the updated fields into fields supported by the default parser.

**D.** Use the Extract Additional Fields tool in Google SecOps to convert the raw log entries to additional fields.

**Respuesta de la fuente:** A

**Explicación:** Parser extensions allow you to write code (typically Python or Jinja) to handle specific parsing logic that the default parser misses.
This approach directly addresses the need to map new and renamed fields to UDM with minimal change management impact compared to rewriting parsers or using external tools.

## Pregunta 84

Contexto: [topics:107](#topics-107)
Your company uses Cloud Identity to manage employee identities and has Google Security Operations (SecOps) linked to your Google Cloud project. You have assigned the roles/chronicle.viewer IAM role at the project level to a specific Google Group that contains users with external Google accounts. Users in this external group authenticate successfully to Google Cloud, but are unable to access Google SecOps. Internal users granted the same role can access Google SecOps. What Google Cloud configuration is most likely preventing the external users from accessing Google SecOps?

**A.** External users must be synchronized to Cloud Identity using Google Cloud Directory Sync (GCDS) for IAM roles to take effect.

**B.** Google SecOps inherently blocks sign-ins from identities outside the organization's primary domain.

**C.** The constraints/iam.allowedPolicyMemberDomains organization policy is restricting IAM role assignments to identities within your company domain only.

**D.** The roles/chronicle.viewer IAM role does not apply correctly when granted to Google Groups containing external identities.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 85

Contexto: [topics:107](#topics-107)
Your company's SOC analysts frequently submit manual change requests to a system administrator to make changes to the firewall rules on a specific router. You have the integration for the firewall installed and configured with credentials. You want to use the integration to trigger firewall rule changes directly from the Google Security Operations (SecOps) SOAR. Your system administrator requires the ability to manually approve the requested changes prior to deployment. How should you implement the workflow for analysts to trigger on demand?

**A.** Create an email template for the analyst to get approval for the change from the system administrator. Have the analyst fill out the needed fields, and send the email for approval. Once approved, use a manual action to make the change to the firewall rule from any open case.

**B.** Create an account for the system administrator in your Google SecOps instance to allow the system administrator to make the changes from Google SecOps directly. Add an escalation step to enable the analyst to assign the case to the system administrator.

**C.** Create a playbook where the firewall rule change is a manual step, allowing the analyst to edit the firewall rule as a pending action. Have the analyst email the system administrator with the change. Once approved, the analyst lets the playbook continue.

**D.** Create a request in the Google SecOps SOAR settings that includes a field for the firewall rule. Create a playbook that is triggered by this request. Configure the playbook step that makes the firewall rule change to send an approval request from the system administrator. The approval request must include the parameter being changed.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 86

Contexto: [topics:107](#topics-107)
You are conducting proactive threat hunting in your company's Google Cloud environment. You suspect that an attacker compromised a developer's credentials and is attempting to move laterally from a development Google Kubernetes Engine (GKE) cluster to critical production systems. You need to identify IOCs and prioritize investigative actions by using Google Cloud's security tools before analyzing raw logs in detail. What should you do next?

**A.** In the Security Command Center (SCC) console, apply filters for the cluster and analyze the resulting aggregated findings' timeline and details for IOCs. Examine the attack path simulations associated with attack exposure scores to prioritize subsequent actions.

**B.** Review threat intelligence feeds within Google Security Operations (SecOps), and enrich any anomalies with context on known IOCs, attacker tactics, techniques, and procedures (TTPs), and campaigns.

**C.** Investigate Virtual Machine (VM) Threat Detection findings in Security Command Center (SCC). Filter for VM Threat Detection findings to target the Compute Engine instances that serve as the nodes for the cluster, and look for malware or rootkits on the nodes.

**D.** Create a Google SecOps SOAR playbook that automatically isolates any GKE resources exhibiting unusual network connections to production environments and triggers an alert to the incident response team.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 87

Contexto: [topics:107](#topics-107)
During a high-priority phishing incident at your company, Google Security Operations (SecOps) created and assigned the case to a Tier 1 analyst. The analyst added email headers and attached the malicious file as evidence but failed to escalate the case, violating an internal SLA of 30 minutes for a phishing response. The delay led to multiple users opening the file before containment actions were initiated. You want to optimize the case management workflow for future high-priority incidents. What should you do?

**A.** Build a playbook that automatically ingests reported phishing emails, enriches entities with threat intelligence, determines the impact and assigns the case for review.

**B.** Change the default case assignment logic to route all phishing alerts to the Tier 2 team.

**C.** Configure a SOAR notification loop that sends escalating email alerts to the Tier 1 analysts, the Tier 2 analysts, and the SOC manager every five minutes until the case is manually reassigned.

**D.** Update the playbook to automatically close phishing cases after 60 minutes if no manual response has occurred.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it automates the ingestion, enrichment, and assignment process, eliminating the manual steps where the analyst previously failed to escalate.
Automation ensures that high-priority phishing cases are immediately enriched with threat intelligence and assigned according to policy, directly addressing the SLA violation caused by human delay.

## Pregunta 88

Contexto: [topics:107](#topics-107)
You are writing a Google Security Operations (SecOps) SOAR playbook that uses the VirusTotal v3 integration to look up a URL that was reported by a threat hunter in an email. You need to use the results to make a preliminary recommendation on the maliciousness of the URL and set the severity of the alert based on the output. What should you do? (Choose two.)

**A.** Create a widget that translates the JSON output to a severity score.

**B.** Use the number of detections from the response JSON in a conditional statement to set the severity.

**C.** Verify that the response is accurate by manually checking the URL in VirusTotal

**D.** Pass the response back to the SIEM.

**E.** Use a conditional statement to determine whether to treat the URL as suspicious or benign.

**Respuesta de la fuente:** B, E

**Explicación:** No conservada en esta captura.

## Pregunta 89

Contexto: [topics:107](#topics-107)
You are using Google Security Operations (SecOps) to hunt for signs of lateral movement through Remote Desktop Protocol (RDP) in your organization. You suspect that a compromised account was used to access multiple internal systems within a short time window. You want to construct a UDM-based search to identify this activity. How should you build this query? (Choose two.)

**A.** Filter for RDP connections with non-standard ports.

**B.** Filter for events using protocol-level attributes that indicate RDP connections.

**C.** Group events by user identity and time to identify repeated access patterns.

**D.** Correlate events based on the asset role or classification such as database or user workstation.

**E.** Use a saved search to identify all events with the LATERAL_MOVEMENT tag over the past 30 days.

**Respuesta de la fuente:** B, C

**Explicación:** No conservada en esta captura.

## Pregunta 90

Contexto: [topics:107](#topics-107)
You are configuring role-based data access controls for two groups of users in Google Security Operations (SecOps). Group A requires access to all data, and Group B requires access to all data except data from the "restricted" namespace. You need to configure access for these two groups. What should you do? (Choose two.)

**A.** Create a custom label with a UDM query to include all labels for Group Assign this data label to Group A in IAM.

**B.** Create a custom label with a UDM query to include all data except the "restricted" namespace data for Group Assign this data label to Group B in IAM.

**C.** Create a new data access scope to allow access to the "restricted" namespace data for Group A. Assign this data scope to Group A in IAM.

**D.** Create a new data access scope in the Google SecOps SIEM settings to allow access to all data for Group A. Assign this data access scope to Group A in IAM.

**E.** Create a new data access scope in the Google SecOps SIEM settings to allow access to all data and exclude the "restrict" namespace data for Group B. Assign this data access scope to Group B in IAM.

**Respuesta de la fuente:** D, E

**Explicación:** No conservada en esta captura.

## Pregunta 91

Contexto: [topics:107](#topics-107)
You are responsible for developing and configuring data ingestion in Google Security Operations (SecOps) for your organization. Your organization is using a prebuilt parser to parse a complex but stable and common log source. The parser is working correctly. However, your organization now wants you to change the configuration to parse additional fields from the raw logs and map them to UDM fields. What should you do?

**A.** Design and develop a custom parser.

**B.** Apply any pending updates to the prebuilt parser.

**C.** Implement a parser extension on top of the prebuilt parser.

**D.** Implement middleware to modify the underlying data structure.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 92

Contexto: [topics:107](#topics-107)
Your company's risk management and compliance team requires regular reporting on compliance with industry standard control frameworks for a regulated business unit that continuously adds projects. You need to create a report that includes evidence of non-compliant resources found in this environment. How should you generate this report?

**A.** Run an audit using the compliance framework in Audit Manager. Export the evaluation for consumption by the second-line team.

**B.** Run queries for the required controls using the Cloud Asset Inventory data stored in BigQuery. Schedule this report to run regularly.

**C.** Implement the control framework using Rego, and deploy this framework in Workload Manager. Schedule a regular report in Workload Manager.

**D.** Implement the built-in posture for the compliance framework within the Security Command Center (SCC) posture.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Audit Manager is specifically designed to generate formal compliance reports with evidence of non-compliant resources against industry standards. While Security Command Center (SCC) detects misconfigurations, it does not produce the structured audit reports required for regulatory compliance; Audit Manager consumes SCC data to create these reports.

## Pregunta 93

Contexto: [topics:107](#topics-107)
Your team hunts for threats in a large multinational corporation. You have subscriptions to threat intelligence feeds from third-party sources. You want to implement a solution to continuously compare DNS calls on endpoints to your threat intelligence feeds. What should you do?

**A.** Use custom modules in Event Threat Detection in Security Command Center (SCC) to correlate feed data with Google Cloud logs.

**B.** Push endpoint logs to BigQuery and use scripts to compare entries to Google Threat intelligence by using a Google Threat Intelligence API key.

**C.** Create a YARA-L rule in Google Security Operations (SecOps) to track matches between the ingested EDR log entries and the entity graph.

**D.** Create a YARA-L rule in Google Security Operations (SecOps) to track matches between the ingested EDR log entries and the VirusTotal table in the entity graph.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 94

Contexto: [topics:107](#topics-107)
Your company is adopting a multi-cloud environment. You need to configure comprehensive monitoring of threats using Google Security Operations (SecOps). You want to start identifying threats as soon as possible. What should you do?

**A.** Use Gemini to generate YARA-L rules for multi-cloud use cases.

**B.** Use curated detections from the Cloud Threats category to monitor your cloud environment.

**C.** Use curated detections for Applied Threat Intelligence to monitor your company's cloud environment.

**D.** Ask Cloud Customer Care to provide a set of rules recommended by Google to monitor your company's cloud environment.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 95

Contexto: [topics:107](#topics-107)
You have a close relationship with a vendor who reveals to you privately that they have discovered a vulnerability in their web application that can be exploited in an XSS attack. This application is running on servers in the cloud and on-premises. Before the CVE is released, you want to look for signs of the vulnerability being exploited in your environment. What should you do?

**A.** Create a YARA-L 2.0 rule to detect a time-ordered series of events where an external inbound connection to a server was followed by a process on the server that spawned subprocesses previously not seen in the environment.

**B.** Create a YARA-L 2.0 rule to detect high-prevalence binaries on your web server architecture communicating with known command and control (C2) nodes. Review inbound traffic from those C2 domains that have only started appearing recently.

**C.** Ask the Gemini Agent in Google Security Operations (SecOps) to search for the latest vulnerabilities in the environment.

**D.** Activate a new Web Security Scanner scan in Security Command Center (SCC), and look for findings related to XSS.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 96

Contexto: [topics:107](#topics-107)
You have identified a new threat actor group that has several IOCs in Google Threat Intelligence. You want to use some of these IOCs in several detection rules in Google Security Operations (SecOps) to help identify suspicious activity. You want to use the most effective approach. What should you do?

**A.** Identify the detection rules that apply to the new IOCs, and update the YARA-L logic to reference the threat actor group.

**B.** Add the IOCs to a new or existing reference list, and update the YARA-L logic of detection rules to include the reference list.

**C.** Save the IOCs in a new collection in Google Threat Intelligence. Share this list with other members of the security team to facilitate their searches and rule creation.

**D.** Configure a new data feed in Google SecOps that includes the IOCs. Update the YARA-L logic to reference the new IOCs against applicable UDM fields.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 97

Contexto: [topics:107](#topics-107)
You have noticed that a Google Security Operations (SecOps) detection rule that detects excessive network connections is triggering too frequently and creating too many false positive alerts. You want to improve the rule to reduce the noise without reducing the effectiveness of the rule. What change to the detection rule should you implement?

**A.** Add a threshold in the YARA-L condition: section to ensure that the rule only alerts after a certain number of connections.

**B.** Assign a risk score in the YARA-L outcome: section to prioritize alerts more effectively in the alert queue.

**C.** Include a 10 minute timeframe for the same source and destination of network connections in the YARA-L match: section to aggregate the alerts.

**D.** Update the YARA-L events: section to exclude the most common IP addresses involved in the network connection alerts to reduce the number of alerts.

**Respuesta de la fuente:** C

**Explicación:** In Google Chronicle SecOps, detection rules generate an alert for every distinct match unless aggregation is explicitly defined. By adding a timeframe in the `match:` section (Option C), you instruct the engine to group related events occurring within that window into a single alert instance. This technique significantly reduces alert volume (noise) caused by repetitive events while preserving the rule's ability to detect the underlying malicious behavior (effectiveness).

## Pregunta 98

Contexto: [topics:107](#topics-107)
You are a SOC analyst at an organization that uses Google Security Operations (SecOps). You are investigating suspicious activity in your organization's environment. Alerts in Google SecOps indicate repeated PowerShell activity on a set of endpoints. Outbound connections are made to a domain that does not appear in your threat intelligence feeds. The activity occurs across multiple systems and user accounts. You need to search across impacted systems and user identities to identify the malicious user and understand the scope of the compromise. What should you do?

**A.** Perform a YARA-L 2.0 search to correlate activity across impacted systems and users.

**B.** Perform a raw log search for the suspicious domain string, and manually pivot to related user activity.

**C.** Use the User Sign-In Overview dashboard to monitor authentication trends and anomalies across all users.

**D.** Use the Behavioral Analytics dashboard in Risk Analytics to identify abnormal IP-based activity and high-risk user behavior.

**Respuesta de la fuente:** D

**Explicación:** The goal is to identify the malicious user and understand the scope of compromise by correlating activity across multiple systems and identities. Risk Analytics (specifically Behavioral Analytics) is designed to detect deviations from baseline behavior and calculate risk scores for users and assets, making it the appropriate tool for identifying high-risk user behavior associated with this widespread anomalous activity. While YARA-L can correlate data, Risk Analytics provides the specific behavioral insights needed to pinpoint the compromised identity among many.

## Pregunta 99

Contexto: [topics:107](#topics-107)
Your company requires PCI DSS v4.0 compliance for its cardholder data environment (CDE) in Google Cloud. You use a Security Command Center (SCC) security posture deployment based on the PCI DSS v4.0 template to monitor for configuration drift. This posture generates a finding indicating that a Compute Engine VM within the CDE scope has been configured with an external IP address. You need to take an immediate action to remediate the compliance drift identified by this specific SCC posture finding. What should you do?

**A.** Enable and enforce the constraints/compute.vmExternalIpAccess organization policy constraint at the project level for the project where the VM resides.

**B.** Reconfigure the network interface settings for the VM to explicitly remove the assigned external IP address.

**C.** Remove the CDE-specific tag from the VM to exclude the tag from this particular PCI DSS posture evaluation scan.

**D.** Navigate to the underlying Security Health Analytics (SHA) finding for PUBLIC_IP_ADDRESS on the VM, and mark this finding as fixed.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 100

Contexto: [topics:107](#topics-107)
You are responsible for managing threat intelligence and IOC lists in your organization. You have compiled a list of IOCs from recent incidents. You want to quickly and efficiently share the IOCs with other teams for collaboration and integration into their operational processes. What should you do?

**A.** Create a list in Google Security Operations (SecOps), and grant the required access to the other teams.

**B.** Export the IOCs from Google Threat Intelligence in CSV or JSON format, and email the file to the other teams.

**C.** Add the IOCs to a collection in Google Threat Intelligence, and share the collection with the other teams.

**D.** Create a new threat graph in Google Threat Intelligence, and share the graph with the other teams.

**Respuesta de la fuente:** C

**Explicación:** Google Threat Intelligence (GTI) Collections are specifically designed as curated, manageable groupings of IOCs that facilitate secure sharing and collaboration with other teams. This approach is superior to exporting files via email or using SecOps lists because it maintains a centralized, up-to-date source of truth that integrates directly with operational workflows.

## Pregunta 101

Contexto: [topics:107](#topics-107)
You are planning log onboarding for a Google Security Operations (SecOps) SIEM deployment in a cloud-heavy enterprise environment. The detection engineering team is requesting log sources that support visibility into:

User identity behavior -

Lateral movement -

Privilege escalation attempts -
You need to determine which telemetry sources are ingested first. Which log source should you prioritize?

**A.** Cloud access security broker (CASB) logs

**B.** EDR logs

**C.** IAM logs

**D.** Network firewall logs

**Respuesta de la fuente:** C

**Explicación:** In a cloud-heavy environment, Identity and Access Management (IAM) logs are the primary source for tracking user identity behavior, as they record authentication events, role assignments, and permission changes.
These logs are essential for detecting lateral movement and privilege escalation, which manifest as unauthorized access attempts or elevation of privileges within cloud services.

## Pregunta 102

Contexto: [topics:107](#topics-107)
You are responsible for selecting and prioritizing potential sources of data to integrate with Google Security Operations (SecOps). Your company has recently started using several Google Cloud services to increase security in its Google Cloud organization. You need to determine which logs should be ingested into Google SecOps to reduce the effort required to write detections. What should you do?

**A.** Ingest Google Cloud Armor logs by using Cloud Logging.

**B.** Deploy a Bindplane agent to ingest event logs from Compute Engine VMs that provide endpoint visibility.

**C.** Integrate Security Command Center (SCC) into Google SecOps to ingest logs originating from the Google Cloud services.

**D.** Use Google Threat Intelligence to gain insight about threat group behavior and support threat hunting activities.

**Respuesta de la fuente:** C

**Explicación:** Integrating Security Command Center (SCC) into Google SecOps allows for the automatic ingestion of findings and logs from native Google Cloud services.
This integration leverages built-in detections and reduces the manual effort required to write custom detection rules compared to manually configuring log sinks or agents.

## Pregunta 103

Contexto: [topics:107](#topics-107)
You are developing a security strategy for your organization. You are planning to use Google Security Operations (SecOps) and Google Threat Intelligence (GTI). You need to enhance the detection and response across multi-cloud and on-premises systems. How should you integrate these products? (Choose two.)

**A.** Ingest GTI IOCs into Google SecOps as security events.

**B.** Ingest on-premises and cloud security logs into Google SecOps SIEM as events.

**C.** Ingest on-premises and cloud security logs into Google SecOps SIEM as entities.

**D.** Use Google SecOps SOAR integrations with GTI for event enrichment.

**E.** Use Google SecOps SOAR integrations with GTI for entity enrichment.

**Respuesta de la fuente:** B, D

**Explicación:** No conservada en esta captura.

## Pregunta 104

Contexto: [topics:107](#topics-107)
Your organization is a Google Security Operations (SecOps) customer. The compliance team requires a weekly export of case resolutions and SLA metrics of high and critical severity cases over the past week. The compliance team's post-processing scripts require this data to be formatted as tabular data in CSV files, zipped, and delivered to their email each Monday morning. What should you do?

**A.** Generate a report in SOAR Reports, and schedule delivery of the report.

**B.** Use statistics in search, and configure a Google SecOps SOAR job to format and send the report.

**C.** Build an Advanced Report in SOAR Reports, and schedule delivery of the report.

**D.** Build a detection rule with outcomes, and configure a Google SecOps SOAR job to format and send the report.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Advanced Reports in Google SecOps SOAR allow you to define custom data fields, including case resolutions and SLA metrics.
The platform supports scheduling these reports for automated delivery as zipped CSV files via email on a recurring basis, such as every Monday morning.
Basic statistics (Option B) lack the granular case data needed, and detection rules (Option D) are for alerting, not reporting.

## Pregunta 105

Contexto: [topics:107](#topics-107)
You are reviewing the results of a UDM search in Google Security Operations (SecOps). The UDM fields shown in the default view are not relevant to your search. You want to be able to quickly view the relevant data for your analysis. What should you do?

**A.** Download the search results as a CSV file, and manipulate the data to display relevant data in a spreadsheet.

**B.** Create a Google SecOps SIEM dashboard based on the search you have run, and visualize the data in an appropriate table or graphical format.

**C.** Select the events of interest, and choose the relevant UDM fields from the event view using the checkboxes. Copy, extract, and analyze the UDM fields, and refine the search query.

**D.** Use the columns feature to select or remove columns that are relevant to your analysis.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 106

Contexto: [topics:107](#topics-107)
Your organization uses the curated detection rule set in Google Security Operations (SecOps) for high priority network indicators. You are finding a vast number of false positives coming from your on-premises proxy servers. You need to reduce the number of alerts. What should you do?

**A.** Configure a rule exclusion for the network.asset.ip field.

**B.** Configure a rule exclusion for the principal.ip field.

**C.** Configure a rule exclusion for the target.domain field.

**D.** Configure a rule exclusion for the target.ip field.

**Respuesta de la fuente:** B

**Explicación:** In Google Security Operations (SecOps) using Chronicle, the `principal.ip` field represents the source IP address of a connection. Since the false positives originate from traffic generated by or passing through on-premises proxy servers, excluding the proxy server's IP from the `principal.ip` field prevents these specific sources from triggering alerts. This directly addresses the root cause without suppressing legitimate detections for other internal assets.

## Pregunta 107

Contexto: [topics:107](#topics-107)
Your third-party application data is published in a Pub/Sub topic located in a separate Google Cloud project from your Google Security Operations (SecOps) instance. Your attempts to push data from the Pub/Sub topic to Google SecOps have failed. You need to send this data into Google SecOps in a low-latency, robust way. What should you do?

**A.** Push the data to Cloud Logging, and modify the export filter in direct ingestion.

**B.** Enable the Chronicle API in the project that owns the Pub/Sub topic to push the subscription to Google SecOps.

**C.** Create a Cloud Run function that is subscribed to the Pub/Sub topic and uses a Google SecOps Ingestion API key to push the data into Google SecOps.

**D.** Send Pub/Sub messages to a Cloud Storage bucket. Create an ingestion feed in Google SecOps to read from the bucket. Grant Storage Admin IAM access to the service account.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 108

Contexto: [topics:107](#topics-107)
Your organization requires the SOC director to be notified by email of escalated incidents and their results before a case is closed. You need to create a process that automatically sends the email when an escalated case is closed. You need to ensure the email is reliably sent for the appropriate cases. What process should you use?

**A.** Use the Close Case button in the UI to close the case. If the case is marked as an incident, export the case from the UI and email it to the director.

**B.** Write a job to check closed cases for incident escalation status, pull the case status details if a case has been escalated, and send an email to the director.

**C.** Navigate to the Alert Overview tab to close the Alert. Run a manual action to gather the case details. If the case was escalated, email the notes to the director Use the Close Case action in the UI to close the case.

**D.** Create a playbook block that includes a condition to identify cases that have been escalated. The two resulting branches either close the alert and email the notes to the director, or close the alert without sending an email.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 109

Contexto: [topics:107](#topics-107)
You are a security analyst at an organization that uses Google Security Operations (SecOps). You have identified a new IP address that is known to be used by a malicious threat actor to launch network attacks. You need to search for this IP address in Google SecOps using all normalized logs to determine whether any malicious activity has occurred. You want to use the most effective approach. What should you do?

**A.** Write a YARA-L 2.0 detection rule that searches for events with the IP address.

**B.** Run raw log searches using the IP address as a search term.

**C.** On the Alerts & IOCs page, review results and entries where the IP address appears.

**D.** Write UDM searches using YARA-L 2.0 syntax to find events where the IP address appears.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 110

Contexto: [topics:107](#topics-107)
You have been tasked with developing a new response process in a playbook to contain an endpoint. The new process should take the following actions:
Send an email to users who do not have a Google Security Operations (SecOps) account to request approval for endpoint containment
Automatically continue executing its logic after the user responds
You plan to implement this process in the playbook by using the Gmail integration. You want to minimize the amount of effort required by the SOC analyst. What should you do?

**A.** Set the containment action to 'Manual' and assign the action to the user to execute or skip the containment action.

**B.** Set the containment action to 'Manual' and assign the action to the appropriate tier. Contact the user by email to request approval. The analyst chooses to execute or skip the containment action.

**C.** Use the 'Send Email' action to send an email requesting approval to contain the endpoint, and use the 'Wait For Thread Reply' action to receive the result. The analyst manually contains the endpoint.

**D.** Generate an approval link for the containment action and include the placeholder in the body of the 'Send Email' action. Configure additional playbook logic to manage approved or denied containment actions.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 111

Contexto: [topics:107](#topics-107)
Your organization plans to ingest logs from an on-premises MySQL database as a new log source into its Google Security Operations (SecOps) instance. You need to create a solution that minimizes effort. What should you do?

**A.** Configure a third-party API feed in Google SecOps.

**B.** Configure direct ingestion from your Google Cloud organization.

**C.** Configure and deploy a Google SecOps forwarder.

**D.** Configure and deploy a Bindplane collection agent.

**Respuesta de la fuente:** D

**Explicación:** Bindplane is the designated data collection platform for Google Security Operations, specifically designed to simplify ingesting logs from on-premises and hybrid sources.
Using a Bindplane collection agent minimizes effort by handling log collection, parsing, and secure forwarding without requiring complex custom integrations or third-party API feeds.

## Pregunta 112

Contexto: [topics:107](#topics-107)
Your organization is a Google Security Operations (SecOps) customer. You use Google Threat Intelligence to identify cyber threats within your organization's threat profile. You believe your organization may have been targeted by a cyber crime group. You need to identify whether your organization has been the victim of an attack. What should you do?

**A.** Implement monitors in the Digital Threat Monitoring feature to identify new compromised credentials, dark web mentions, or data leaks.

**B.** In the Reports & Analysis feature, extract the IOCs from the recent reports, and implement detection rules and lists in Google SecOps to identify whether they are present in your organization's environment.

**C.** Review the Threat Landscape feature to identify threat groups that are active in your industry, research their known MITRE ATT&CK tactics, techniques, and procedures (TTPs) and implement detection rules in Google SecOps.

**D.** In the Vulnerability Intelligence feature, identify new high and critical vulnerabilities in products or technologies that your organization uses so they can be patched.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 113

Contexto: [topics:107](#topics-107)
You are implementing Google Security Operations (SecOps) for your organization. Your organization has their own threat intelligence feed that has been ingested to Google SecOps by using a native integration with a Malware Information Sharing Platform (MISP). You are working on the following detection rule to leverage the command and control (C2) indicators that were ingested into the entity graph.
[Imagen: sin descripción]
What code should you add in the detection rule to filter for the domain IOCs?
Imagen · question_text · sin descripción
![Imagen original](imagenes/39af8b76ebe52fcdf9cd.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
rule ioc_domain_C2 {
meta:
author = Google
5	1	1	1	3	4	273	74	59	13	96.730324	Cloud
5	1	1	1	3	5	345	74	105	17	64.393379	Security
description = Detect
5	1	1	1	4	4	333	100	34	12	96.884117	DNS
5	1	1	1	4	5	381	100	70	12	96.688187	events
5	1	1	1	4	6	465	99	46	13	96.872215	that
5	1	1	1	4	7	525	99	94	13	96.772316	indicate
5	1	1	1	4	8	633	99	155	13	96.447853	communication
5	1	1	1	4	9	801	100	22	12	96.458038	to
2	1	2	0	0	0	45	150	539	92	-1	
3	1	2	1	0	0	45	150	539	92	-1	
4	1	2	1	1	0	45	150	79	12	-1	
5	1	2	1	1	1	45	150	79	12	96.693863	events:
4	1	2	1	2	0	69	174	477	18	-1	
5	1	2	1	2	1	69	174	286	18	55.136215	$dns.metadata.event_type
5	1	2	1	2	2	368	179	12	4	93.205536	=
5	1	2	1	2	3	394	174	152	18	88.780838	NETWORK_DNS"
$dns.network.dns.questions.name =$dns_query
$ioc.graph.metadata.product_name = MISP
<< Add code>>
$ioc.graph.metadata.threat.summary = C2
5	1	4	1	1	4	561	324	93	13	88.952217	domains
$ioc.graph.entity.hostname = $dns_query
match:
$dns_query over 5m
condition:
$dns and Sioc
a C2 domain"
```

**A.** $ioc.graph.metadata.entity_type = "DOMAIN_NAME"
$ioc.graph.metadata.source_type = "ENTITY_CONTEXT"

**B.** $ioc.graph.metadata.entity_type = "DOMAIN_NAME"
$ioc.graph.metadata.source_type = "GLOBAL_CONTEXT"

**C.** $ioc.graph.metadata.entity_type = "DOMAIN_NAME"
$ioc.graph.metadata.source_type = "DERIVED_CONTEXT"

**D.** $ioc.graph.metadata.entity_type = "DOMAIN_NAME"
$ioc.graph.metadata.source_type = "SOURCE_TYPE_UNSPECIFIED"

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 114

Contexto: [topics:107](#topics-107)
You are using Google Security Operations (SecOps) to identify and report a repetitive sequence of brute force SSH login attempts on a Compute Engine image that did not result in a successful login. You need to gain visibility into this activity while minimizing impact on your ingestion quota. Which log type should you ingest into Google SecOps?

**A.** VPC Flow Logs

**B.** Security Command Center Premium (SCCP) findings

**C.** Cloud IDS logs

**D.** Cloud Audit Logs

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 115

Contexto: [topics:107](#topics-107)
You are a SOC analyst working a case in Google Security Operations (SecOps). The case contains a file hash that your playbooks have automatically enriched with VirusTotal context and categorized as likely malicious. You need to quickly identify devices and users in your organization who have interacted with this file. What should you do?

**A.** Build a playbook to perform a UDM search matching on the file hash in Google SecOps SIEM.

**B.** Build a playbook to query your threat intelligence platform (TIP) for the presence of the file hash.

**C.** Use a manual action in Google SecOps SOAR to perform a UDM search matching on the file hash in Google SecOps SIEM.

**D.** Use a manual action in Google SecOps SOAR to query your threat intelligence platform (TIP) for the presence of the file hash.

**Respuesta de la fuente:** C

**Explicación:** To identify devices and users who interacted with a specific file hash, you must search historical security logs ingested into the Google SecOps SIEM, which uses the Unified Data Model (UDM) for normalized data.
Using a manual action within the SOAR case allows for immediate, targeted querying without the delay of designing or executing a full automated playbook.

## Pregunta 116

Contexto: [topics:107](#topics-107)
You are responsible for monitoring the ingestion of critical Windows server logs to Google Security Operations (SecOps) by using the Bindplane agent. You want to receive an immediate notification when no logs have been ingested for over 30 minutes. You want to use the most efficient notification solution. What should you do?

**A.** Create a new YARA-L rule in Google SecOps SIEM to detect the absence of logs from the server within a 30-minute window.

**B.** Configure a Bindplane agent to send a heartbeat signal to Google SecOps every 15 minutes, and create an alert if two heartbeats are missed.

**C.** Create a new alert policy in Cloud Monitoring that triggers a notification based on the absence of logs from the server's hostname.

**D.** Configure the Windows server to send an email notification if there is an error in the Bindplane process.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 117

Contexto: [topics:107](#topics-107)
You observe several distinct, low-severity suspicious activities associated with a single internal server. You determine that no single event is a high-confidence IOC. You need to create a solution that ensures ongoing and heightened scrutiny for this server. What should you do?

**A.** Schedule a daily Google Security Operations (SecOps) report detailing all activity on this server.

**B.** Develop a YARA-L detection rule specific to this server.

**C.** Add the server to a Google Security Operations (SecOps) watchlist, and monitor the watchlist closely for the next few weeks.

**D.** Create a case, isolate the server from the network, and escalate the case for forensic investigation.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 118

Contexto: [topics:107](#topics-107)
Your organization recently adopted Google Security Operations (SecOps), and has configured ingestion, parsing and rules for their log sources. The security operations team is currently triaging alerts one at a time using several external product dashboards with alerts and enrichment data. You want to use the case management functionality in Google SecOps to reduce the amount of pivoting between products your SOC analysts are required to do. You want to minimize development effort. What should you do first?

**A.** Build a playbook for each detection rule to enrich and remediate alerts relative to the particular threat each rule is designed to detect.

**B.** Build a playbook for each of the noisiest alert sources to gather additional context on the case from the source product.

**C.** Build a job to periodically iterate over recent cases, determine relevant context, and enrich alerts.

**D.** Build a low-priority, catch-all playbook for enrichment of entities in a case using threat intelligence sources.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 119

Contexto: [topics:107](#topics-107)
You were recently hired as a SOC manager at an organization with an existing Google Security Operations (SecOps) implementation. You need to understand the current performance by calculating the mean time to respond or remediate (MTTR) for your cases. What should you do?

**A.** Create a multi-event detection rule to calculate the response metrics in the outcome section based on the entity graph. Create a dashboard based on these metrics.

**B.** Create a dashboard table widget that displays the average case handling times by analyst, case priority, and environment.

**C.** Create a playbook block that can be re-used in all alert playbooks to write timestamps in the case wall after each change to the case. Write a job to calculate the case metrics.

**D.** Use the playbooks' case stages to capture metrics for each stage change. Create a dashboard based on these metrics.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 120

Contexto: [topics:107](#topics-107)
You received an IOC from your threat intelligence feed that is identified as a suspicious domain used for command and control (C2). You want to use Google Security Operations (SecOps) to investigate whether this domain appeared in your environment. You want to search for this IOC using the most efficient approach. What should you do?

**A.** Run a raw log search to search for the domain string.

**B.** Configure a UDM search that queries the DNS section of the network noun.

**C.** Enable Group by Field in scan view to cluster events by hostname.

**D.** Enter the IOC into the IOC Search feature, and wait for detections with this domain to appear in the Case view.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 121

Contexto: [topics:107](#topics-107)
You are a senior SOC analyst in your organization. You are receiving alerts of traffic to a command and control (C2) IP address. You want to use Google Security Operations (SecOps) to investigate the IP address associated with the C2 IP address. What should you do?

**A.** Use Google SecOps SOAR Search to run a playbook designed to investigate the suspicious IP address and identify related outbound and inbound traffic.

**B.** Use Google SecOps SOAR Search to identify the cases where the suspicious IP address exists.

**C.** Conduct a Google SecOps SIEM Search that uses src.ip and target.ip to identify outbound and inbound traffic associated with the suspicious IP address.

**D.** Use Google SecOps SIEM Search to query against the grouped ip field, and use the enriched field from the suspicious events to identify related activity.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Google SecOps (formerly Chronicle) utilizes the 'grouped ip' field in SIEM Search to aggregate traffic across multiple IP attributes, providing a comprehensive view of all activity associated with the suspicious address. This approach is more effective than querying only src.ip and target.ip individually, as it ensures no related inbound or outbound connections are missed. SOAR playbooks (Options A and B) are automation tools for response rather than primary investigation queries within the SIEM.

## Pregunta 122

Contexto: [topics:107](#topics-107)
You are working with your company's analyst team to automate the investigation of phishing alerts ingested directly into Google Security Operations (SecOps) SOAR from an email inbox. The analyst team currently uses a SIEM query to search for related information. You need to design a solution to automatically include the query results in the Google SecOps case without writing any new code. What should you do?

**A.** Create a custom action in Google SecOps IDE that runs the SIEM query from a playbook through an API call and returns the results.

**B.** Modify the detection rule in the SIEM to include the query results as part of the detection.

**C.** Add a widget to the Default Case View in Google SecOps SOAR that allows the analyst team to query directly from the widget.

**D.** Add an action to the playbook that runs the SIEM query and returns the results.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 123

Contexto: [topics:107](#topics-107)
Your Google Security Operations (SecOps) instance is generating alerts for unusual login times from multiple user accounts. Your SOC analysts are reporting a high number of the alerts are false positives involving service accounts used by scheduled automation tasks. You want to refine the detection logic using entity-level context available in Google SecOps. You want to use the most effective approach. What should you do?

**A.** Use asset tags to group known automation systems, and exclude them from the alert logic.

**B.** Modify the rule to include the principal.user.type != "service_account" condition.

**C.** Update the rule to only alert when the principal.user.email and principal.user.userid fields match in the same event.

**D.** Add a reference list of all service accounts, and suppress alerts for any matches on the principal.user.email field.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 124

Contexto: [topics:107](#topics-107)
You are building a detection rule in Google Security Operations (SecOps) to alert on requests to potentially malicious domains. You are planning to use the logs from your network detection and response (NDR) solution but you need to reduce noise and narrow the scope of detections. You want to minimize cost and deploy the solution quickly. What should you do?

**A.** Ingest logs from a domain monitoring service, and build a multi-event rule that correlates the domains found in your NDR logs with your domain monitoring data.

**B.** Build a Google SecOps SOAR playbook that enriches domain entities in alerts with VirusTotal information and auto-closes cases when no domains are classified as malicious.

**C.** Build a multi-event rule that correlates the domains found in your NDR logs with WHOIS context in the entity graph and sets the risk score based on domain creation time.

**D.** Ingest logs from your threat intelligence platform (TIP), and build a multi-event rule that correlates the domains found in your NDR logs with your threat intelligence data.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 125

Contexto: [topics:107](#topics-107)
You are helping a new Google Security Operations (SecOps) customer configure access for their SOC team. The Google SecOps administrators currently have access to the instance. The customer is reporting that new Google SecOps users are not getting authorized to access the instance, but they are able to authenticate to the third-party identity provider (IdP). How should you fix the issue? (Choose two.)

**A.** Link Google SecOps to a Google Cloud project with the Chronicle API.

**B.** Integrate Google SecOps with the third-party IdP using Workforce Identity Federation.

**C.** Grant the appropriate data access scope to the SOC team's IdP group in IAM.

**D.** Grant the roles/chronicle.viewer role to the SOC team's IdP group in IAM.

**E.** Grant the Basic permission to the appropriate IdP groups in the Google SecOps SOAR Advanced Settings.

**Respuesta de la fuente:** D, E

**Explicación:** No conservada en esta captura.

## Pregunta 126

Contexto: [topics:107](#topics-107)
You are a security analyst at an organization that uses Google Security Operations (SecOps). Google SecOps triggered a medium severity alert of Unusual Cloud Storage Access - High Volume Download for user1@securecloudservices.com from the internal-project-code-repository bucket. This user is a senior developer within your organization who has legitimate access, but their download volume is unusually high and occurs outside working hours. You need to investigate this alert. What should you do first?

**A.** Run a Google SecOps SOAR playbook to suspend user1's bucket access, and review their user timeline.

**B.** Enrich the bucket entity with sensitivity labels and access control list (ACL) data.

**C.** Create a default detection rule in Google SecOps to monitor future high-volume downloads from the bucket, and add user1 to a high-risk watchlist.

**D.** Review user1's timeline in Google SecOps, focusing on network events and resource access immediately preceding the download anomaly.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 127

Contexto: [topics:107](#topics-107)
Your company uses Google-managed images on Compute Engine VM instances extensively and has deployed Security Command Center Enterprise (SCCE) at the organization level Due to a recent increase in vulnerability exploits, you want to improve visibility into operating system (OS) risks for all VMs in your organization. You want to use managed services to enhance security detection capabilities related to these vulnerabilities using minimal effort. What should you do?

**A.** Enable VM Manager across your projects, and allow VM Manager to write findings to SCCE.

**B.** Enable Virtual Machine Threat Detection in SCCE, and allow it to generate findings.

**C.** Set up Google Open Source Vulnerability (OSV)-Scanner to scan all Compute Engine VMs. Configure a Google Security Operations (SecOps) forwarder to write logs to your Google SecOps instance.

**D.** Create a custom Security Health Analytics (SHA) scanner to check the sourceImage of the compute disk. Check for matches in a vulnerability database.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 128

Contexto: [topics:107](#topics-107)
You work at a financial services company. You need to detect in near real-time when a Cloud Run functions service agent modifies the IAM policy of an Artifact Registry repository. You plan to use Security Command Center (SCC). You want to follow the Google-recommended approach. What should you do?

**A.** Create a custom Security Health Analytics (SHA) detector that scans Artifact Registry repositories for IAM policy changes. When a change is detected identify the principal that made the change.

**B.** Configure a Cloud Logging log sink to export all IAM policy changes to BigQuery, and create a custom dashboard in SCC to visualize the data.

**C.** Use Event Threat Detection in SCC with a custom unexpected Cloud API call rule that detects when a specified principal calls a method against a resource.

**D.** Implement a Cloud Run function that is triggered by IAM policy changes within the project and sends an alert to SCC using the Security Command Center API.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 129

Contexto: [topics:107](#topics-107)
Your Google Security Operations (SecOps) case queue contains a case with IP address entities. You need to determine whether the entities are internal or external assets and ensure that internal IP address entities are marked accordingly upon ingestion into Google SecOps SOAR. What should you do?

**A.** Indicate your organization's known internal CIDR ranges in the Environment Networks list in the settings.

**B.** Modify the connector logic to perform a secondary lookup against your CMDB and flag incoming entities as internal or external.

**C.** Configure a feed to ingest enrichment data about the networks, and include these fields into your detection outcome.

**D.** Create a custom action to ping the IP address entity from your Remote Agent. If successful, the custom action designates the IP address entity as internal.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 130

Contexto: [topics:107](#topics-107)
Your organization has a standard set of Google Security Operations (SecOps) playbooks that are applied to alerts in different circumstances. One playbook uses an "All" trigger that should always be applied if no other more specific playbooks have triggered. You need to ensure that the more specific playbook is attached and not the generic "All" playbook when multiple triggers match. What should you do?

**A.** Set the priority of the "All" playbook to a higher value than the priority of the specific playbook to ensure the "All" trigger is evaluated after the previous priorities.

**B.** Change the "All" trigger to be more precise so that it doesn't trigger when the other playbook is needed.

**C.** In the Outcomes section of the detection rule that is firing your alert, add a specific field to search for the specific playbook to base the trigger on.

**D.** Create a tagging rule in the Google SecOps SOAR settings, and use a tag trigger to trigger the specific playbook.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 131

Contexto: [topics:107](#topics-107)
You work for a telecommunications company that wants to monitor their multi-region 5G network logs in Google Security Operations (SecOps). The logs are currently only available on-premises and are stored in a standalone network-attached storage (NAS) located in four different regions. You need to ingest the logs into Google SecOps and tag each NAS as a specific log source to avoid IP address aliasing. What should you do?

**A.** Configure feed management to pull data from each log's location, and configure a namespace for each log source.

**B.** Configure feed management to pull data from each log's location, and configure an ingestion label for each log source.

**C.** Configure a Bindplane agent that collects Syslog from each log's location, and configure a namespace for each log source.

**D.** Configure a Bindplane agent that collects Syslog from each log's location and configure an ingestion label for each log source.

**Respuesta de la fuente:** D

**Explicación:** Feed management in Google Security Operations is designed for pulling data from external cloud providers or APIs, not directly from on-premises standalone storage like NAS devices. To ingest logs from on-premises infrastructure, you must deploy a Bindplane agent (formerly Chronicle Agent) to collect and forward the data.

Regarding the requirement to tag each NAS as a specific log source to avoid IP address aliasing: Ingestion labels are the correct mechanism for tagging data at ingestion time based on its source. While namespaces can segregate environments, ingestion labels provide the granular, flexible tagging needed to distinguish between identical IP addresses across different physical locations (regions). Therefore, configuring Bindplane agents for collection and using ingestion labels for sourcing is the correct approach.

## Pregunta 132

Contexto: [topics:107](#topics-107)
Your organization has recently experienced an increase in security incidents. You need to create a near real-time visualization of activity within the last hour for users and assets that have triggered alerts, categorized by the highest risk scores. What should you do?

**A.** Navigate to the Alerts & IOCs panel in Google Security Operations (SecOps). Set the showing time to the last hour, and sort by risk score.

**B.** Create a dashboard to display all alerts from the last hour, broken down by entity type and sorted by risk score.

**C.** Navigate to the Risk Analytics dashboard in Google Security Operations (SecOps). Sort the entities by normalized change.

**D.** Create a report using the events table in the BigQuery export that shows all alerts over the last hour broken out by entity type and ordered by risk score.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 133

Contexto: [topics:107](#topics-107)
You are a security operations engineer in an enterprise that uses Google Security Operations (SecOps). You need to improve your detection coverage and reduce the false positive detection ratio as quickly as possible. What should you do?

**A.** Enable curated detections to identify threats.

**B.** Develop YARA-L detection rules that focus on threat intelligence.

**C.** Ingest data from your threat intelligence platform (TIP) into Google SecOps.

**D.** Design YARA-L detection rules based on Google SecOps Marketplace use cases.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.