# professional cloud network engineer

316 / 316 preguntas. Cobertura completa: True.

Respuestas de la fuente; revisión técnica pendiente. Las imágenes permanecen en sus campos de origen.

316 respuestas conservadas; 0 pendientes.

<a id="topics-725"></a>
## Contexto topics:725
name:
Topic 1


## Pregunta 1

Contexto: [topics:725](#topics-725)
You need to restrict access to your Google Cloud load-balanced application so that only specific IP addresses can connect.
What should you do?

**A.** Create a secure perimeter using the Access Context Manager feature of VPC Service Controls and restrict access to the source IP range of the allowed clients and Google health check IP ranges.

**B.** Create a secure perimeter using VPC Service Controls, and mark the load balancer as a service restricted to the source IP range of the allowed clients and Google health check IP ranges.

**C.** Tag the backend instances "application," and create a firewall rule with target tag "application" and the source IP range of the allowed clients and Google health check IP ranges.

**D.** Label the backend instances "application," and create a firewall rule with the target label "application" and the source IP range of the allowed clients and Google health check IP ranges.

**Respuesta de la fuente:** C

**Explicación:** VPC Service Controls are not supported for Google Cloud Load Balancers, making options A and B invalid.
Between the remaining firewall options, network tags (Option C) are the standard mechanism for defining firewall rule targets in this context, whereas labels are primarily used for resource organization and billing rather than access control enforcement.

## Pregunta 2

Contexto: [topics:725](#topics-725)
Your end users are located in close proximity to us-east1 and europe-west1. Their workloads need to communicate with each other. You want to minimize cost and increase network efficiency.
How should you design this topology?

**A.** Create 2 VPCs, each with their own regions and individual subnets. Create 2 VPN gateways to establish connectivity between these regions.

**B.** Create 2 VPCs, each with their own region and individual subnets. Use external IP addresses on the instances to establish connectivity between these regions.

**C.** Create 1 VPC with 2 regional subnets. Create a global load balancer to establish connectivity between the regions.

**D.** Create 1 VPC with 2 regional subnets. Deploy workloads in these subnets and have them communicate using private RFC1918 IP addresses.

**Respuesta de la fuente:** D

**Explicación:** In Google Cloud, a VPC is a global resource, meaning instances in different regional subnets within the same VPC can communicate directly using private RFC1918 IPs over Google's global network backbone. This design minimizes cost by avoiding egress charges associated with external IPs or inter-VPC traffic and maximizes efficiency by eliminating the need for additional networking components like VPN gateways or load balancers.

Option A is incorrect because using multiple VPCs introduces unnecessary complexity and potential latency/cost from connectivity mechanisms, while Option B incurs higher costs due to public IP egress fees.

## Pregunta 3

Contexto: [topics:725](#topics-725)
Your organization is deploying a single project for 3 separate departments. Two of these departments require network connectivity between each other, but the third department should remain in isolation. Your design should create separate network administrative domains between these departments. You want to minimize operational overhead.
How should you design the topology?

**A.** Create a Shared VPC Host Project and the respective Service Projects for each of the 3 separate departments.

**B.** Create 3 separate VPCs, and use Cloud VPN to establish connectivity between the two appropriate VPCs.

**C.** Create 3 separate VPCs, and use VPC peering to establish connectivity between the two appropriate VPCs.

**D.** Create a single project, and deploy specific firewall rules. Use network tags to isolate access between the departments.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because VPC peering allows you to maintain separate network administrative domains (3 distinct VPCs) while establishing direct Layer 3 connectivity between the two departments that require it, without requiring overlapping IP ranges. This approach minimizes operational overhead compared to managing complex firewall rules across a single shared network space or setting up Cloud VPN, which involves additional encryption overhead and internet/interconnect transit. Option D is the most tempting alternative but is incorrect because using a single VPC with firewall rules does not create separate administrative domains; instead, it increases operational complexity by requiring meticulous tag management and rule maintenance to ensure isolation, whereas separate VPCs provide inherent administrative boundaries.

## Pregunta 4

Contexto: [topics:725](#topics-725)
You are migrating to Cloud DNS and want to import your BIND zone file.
Which command should you use?

**A.** gcloud dns record-sets import ZONE_FILE --zone MANAGED_ZONE

**B.** gcloud dns record-sets import ZONE_FILE --replace-origin-ns --zone MANAGED_ZONE

**C.** gcloud dns record-sets import ZONE_FILE --zone-file-format --zone MANAGED_ZONE

**D.** gcloud dns record-sets import ZONE_FILE --delete-all-existing --zone MANAGED ZONE

**Respuesta de la fuente:** C

**Explicación:** The --zone-file-format flag is required to explicitly specify that the input file is in BIND zone format, as the default expectation for this command is YAML. Without this flag, the import will fail because the parser expects YAML syntax rather than standard BIND text records.

## Pregunta 5

Contexto: [topics:725](#topics-725)
You created a VPC network named Retail in auto mode. You want to create a VPC network named Distribution and peer it with the Retail VPC.
How should you configure the Distribution VPC?

**A.** Create the Distribution VPC in auto mode. Peer both the VPCs via network peering.

**B.** Create the Distribution VPC in custom mode. Use the CIDR range 10.0.0.0/9. Create the necessary subnets, and then peer them via network peering.

**C.** Create the Distribution VPC in custom mode. Use the CIDR range 10.128.0.0/9. Create the necessary subnets, and then peer them via network peering.

**D.** Rename the default VPC as "Distribution" and peer it via network peering.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because GCP auto-mode VPCs automatically create subnets in the RFC 1918 range, specifically using 10.128.0.0/9 for some regions, which would cause an IP collision with Option C. Using custom mode with a non-overlapping CIDR like 10.0.0.0/9 ensures no conflict with the Retail VPC's auto-generated subnets.

## Pregunta 6

Contexto: [topics:725](#topics-725)
You are using a third-party next-generation firewall to inspect traffic. You created a custom route of 0.0.0.0/0 to route egress traffic to the firewall. You want to allow your VPC instances without public IP addresses to access the BigQuery and Cloud Pub/Sub APIs, without sending the traffic through the firewall.
Which two actions should you take? (Choose two.)

**A.** Turn on Private Google Access at the subnet level.

**B.** Turn on Private Google Access at the VPC level.

**C.** Turn on Private Services Access at the VPC level.

**D.** Create a set of custom static routes to send traffic to the external IP addresses of Google APIs and services via the default internet gateway.

**E.** Create a set of custom static routes to send traffic to the internal IP addresses of Google APIs and services via the default internet gateway.

**Respuesta de la fuente:** A, D

**Explicación:** Option A is required because Private Google Access must be enabled at the subnet level to allow instances without external IPs to reach Google API external IP addresses. Option D is necessary because, without explicit static routes to the Google API IP ranges pointing to the default internet gateway, the custom 0.0.0.0/0 route would incorrectly force this traffic through the firewall. Option C is incorrect because Private Services Access is for third-party services and does not cover standard Google APIs. Option E is incorrect because Google APIs are addressed via their external IP space, not internal private IP addresses.

## Pregunta 7

Contexto: [topics:725](#topics-725)
All the instances in your project are configured with the custom metadata enable-oslogin value set to FALSE and to block project-wide SSH keys. None of the instances are set with any SSH key, and no project-wide SSH keys have been configured. Firewall rules are set up to allow SSH sessions from any IP address range. You want to SSH into one instance.
What should you do?

**A.** Open the Cloud Shell SSH into the instance using gcloud compute ssh.

**B.** Set the custom metadata enable-oslogin to TRUE, and SSH into the instance using a third-party tool like putty or ssh.

**C.** Generate a new SSH key pair. Verify the format of the private key and add it to the instance. SSH into the instance using a third-party tool like putty or ssh.

**D.** Generate a new SSH key pair. Verify the format of the public key and add it to the project. SSH into the instance using a third-party tool like putty or ssh.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because `gcloud compute ssh` automatically handles key generation and injection into the instance's metadata at runtime, bypassing the need for pre-configured static keys or project-wide settings.
Options C and D are incorrect because the instance explicitly blocks SSH keys (via metadata configuration), meaning manually adding keys to the instance or project metadata will not grant access.
Option B is unnecessary overhead since OS Login is a more complex management system than needed when `gcloud` provides a simpler, built-in mechanism for key-less authentication.

## Pregunta 8

Contexto: [topics:725](#topics-725)
You work for a university that is migrating to GCP.
These are the cloud requirements:
"¢ On-premises connectivity with 10 Gbps
"¢ Lowest latency access to the cloud
"¢ Centralized Networking Administration Team
New departments are asking for on-premises connectivity to their projects. You want to deploy the most cost-efficient interconnect solution for connecting the campus to Google Cloud.
What should you do?

**A.** Use Shared VPC, and deploy the VLAN attachments and Interconnect in the host project.

**B.** Use Shared VPC, and deploy the VLAN attachments in the service projects. Connect the VLAN attachment to the Shared VPC's host project.

**C.** Use standalone projects, and deploy the VLAN attachments in the individual projects. Connect the VLAN attachment to the standalone projects' Interconnects.

**D.** Use standalone projects and deploy the VLAN attachments and Interconnects in each of the individual projects.

**Respuesta de la fuente:** A

**Explicación:** In a Shared VPC architecture with Dedicated Interconnect, VLAN attachments and Cloud Routers must be deployed exclusively in the host project to maintain centralized network administration. Service projects cannot contain these networking resources; they simply utilize subnets within the shared VPC network accessed via the host's interconnect configuration.

Choice B is incorrect because VLAN attachments cannot be created in service projects. Choice C and D are less cost-efficient and violate the requirement for centralized administration by fragmenting connectivity management across multiple standalone projects.

## Pregunta 9

Contexto: [topics:725](#topics-725)
You have deployed a new internal application that provides HTTP and TFTP services to on-premises hosts. You want to be able to distribute traffic across multiple
Compute Engine instances, but need to ensure that clients are sticky to a particular instance across both services.
Which session affinity should you choose?

**A.** None

**B.** Client IP

**C.** Client IP and protocol

**D.** Client IP, port and protocol

**Respuesta de la fuente:** B

**Explicación:** The requirement is to ensure clients remain sticky to a single instance 'across both services' (HTTP and TFTP). Since these services operate on different ports and protocols, using 'Client IP' alone (Option B) ensures that all traffic from a specific client source IP is directed to the same backend instance, regardless of the destination port or protocol. In contrast, options involving port or protocol would create separate affinity sessions for each service, violating the cross-service stickiness requirement.

## Pregunta 10

Contexto: [topics:725](#topics-725)
You created a new VPC network named Dev with a single subnet. You added a firewall rule for the network Dev to allow HTTP traffic only and enabled logging.
When you try to log in to an instance in the subnet via Remote Desktop Protocol, the login fails. You look for the Firewall rules logs in Stackdriver Logging, but you do not see any entries for blocked traffic. You want to see the logs for blocked traffic.
What should you do?

**A.** Check the VPC flow logs for the instance.

**B.** Try connecting to the instance via SSH, and check the logs.

**C.** Create a new firewall rule to allow traffic from port 22, and enable logs.

**D.** Create a new firewall rule with priority 65500 to deny all traffic, and enable logs.

**Respuesta de la fuente:** D

**Explicación:** By default, GCP VPC has an implicit deny-all rule that does not support logging, which is why blocked RDP traffic isn't appearing in logs. Creating a custom deny-all rule with a high priority (65500) ensures it matches after your allow rules but before the implicit deny, capturing and logging all denied packets.
Option A is incorrect because VPC Flow Logs only sample traffic that passes ingress firewall checks; they do not log packets dropped by firewall denials.

## Pregunta 11

Contexto: [topics:725](#topics-725)
You are trying to update firewall rules in a shared VPC for which you have been assigned only Network Admin permissions. You cannot modify the firewall rules.
Your organization requires using the least privilege necessary.
Which level of permissions should you request?

**A.** Security Admin privileges from the Shared VPC Admin.

**B.** Service Project Admin privileges from the Shared VPC Admin.

**C.** Shared VPC Admin privileges from the Organization Admin.

**D.** Organization Admin privileges from the Organization Admin.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because the 'Security Admin' role (compute.securityAdmin) specifically grants permissions to manage firewall rules and SSL certificates within a Shared VPC host project, adhering to the principle of least privilege. Options C and D are incorrect as they grant excessive administrative privileges beyond what is needed for firewall management. Option B is incorrect because Service Project Admin focuses on service project lifecycle rather than network security configuration.

## Pregunta 12

Contexto: [topics:725](#topics-725)
You want to create a service in GCP using IPv6.
What should you do?

**A.** Create the instance with the designated IPv6 address.

**B.** Configure a TCP Proxy with the designated IPv6 address.

**C.** Configure a global load balancer with the designated IPv6 address.

**D.** Configure an internal load balancer with the designated IPv6 address.

**Respuesta de la fuente:** C

**Explicación:** In Google Cloud Platform, IPv6 support for external services is provided through Global External Application Load Balancers (HTTP/S or HTTPS).
While TCP proxies and internal load balancers do not currently support global IPv6 addresses, configuring a global load balancer allows you to assign a designated IPv6 address to your service.
Option A is incorrect because assigning an IPv6 address directly to a VM instance requires prior subnet configuration and does not inherently create the 'service' endpoint described; Option C represents the correct architectural pattern for exposing IPv6-enabled services.

## Pregunta 13

Contexto: [topics:725](#topics-725)
You want to deploy a VPN Gateway to connect your on-premises network to GCP. You are using a non BGP-capable on-premises VPN device. You want to minimize downtime and operational overhead when your network grows. The device supports only IKEv2, and you want to follow Google-recommended practices.
What should you do?

**A.** "¢ Create a Cloud VPN instance. "¢ Create a policy-based VPN tunnel per subnet. "¢ Configure the appropriate local and remote traffic selectors to match your local and remote networks. "¢ Create the appropriate static routes.

**B.** "¢ Create a Cloud VPN instance. "¢ Create a policy-based VPN tunnel. "¢ Configure the appropriate local and remote traffic selectors to match your local and remote networks. "¢ Configure the appropriate static routes.

**C.** "¢ Create a Cloud VPN instance. "¢ Create a route-based VPN tunnel. "¢ Configure the appropriate local and remote traffic selectors to match your local and remote networks. "¢ Configure the appropriate static routes.

**D.** "¢ Create a Cloud VPN instance. "¢ Create a route-based VPN tunnel. "¢ Configure the appropriate local and remote traffic selectors to 0.0.0.0/0. "¢ Configure the appropriate static routes.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because route-based VPNs automatically set traffic selectors to 0.0.0.0/0, allowing the tunnel to accept traffic for any subnet defined in the custom static routes.
This aligns with Google-recommended practices for scalability, as traffic selectors cannot be modified after tunnel creation; using specific selectors (Options A, B, C) would require deleting and recreating the tunnel whenever new subnets are added, increasing downtime and operational overhead.

## Pregunta 14

Contexto: [topics:725](#topics-725)
Your company just completed the acquisition of Altostrat (a current GCP customer). Each company has a separate organization in GCP and has implemented a custom DNS solution. Each organization will retain its current domain and host names until after a full transition and architectural review is done in one year.
These are the assumptions for both GCP environments.
"¢ Each organization has enabled full connectivity between all of its projects by using Shared VPC.
"¢ Both organizations strictly use the 10.0.0.0/8 address space for their instances, except for bastion hosts (for accessing the instances) and load balancers for serving web traffic.
"¢ There are no prefix overlaps between the two organizations.
"¢ Both organizations already have firewall rules that allow all inbound and outbound traffic from the 10.0.0.0/8 address space.
"¢ Neither organization has Interconnects to their on-premises environment.
You want to integrate networking and DNS infrastructure of both organizations as quickly as possible and with minimal downtime.
Which two steps should you take? (Choose two.)

**A.** Provision Cloud Interconnect to connect both organizations together.

**B.** Set up some variant of DNS forwarding and zone transfers in each organization.

**C.** Connect VPCs in both organizations using Cloud VPN together with Cloud Router.

**D.** Use Cloud DNS to create A records of all VMs and resources across all projects in both organizations.

**E.** Create a third organization with a new host project, and attach all projects from your company and Altostrat to it using shared VPC.

**Respuesta de la fuente:** B, C

**Explicación:** Cloud VPN (C) is the correct networking choice because it allows interconnection between separate organizations without IP overlap constraints that would block VPC Peering, and it can be deployed faster than Cloud Interconnect (A).
Since both organizations use custom DNS solutions rather than managed Cloud DNS, they must rely on their own infrastructure's capabilities for name resolution integration, making DNS forwarding or zone transfers (B) the appropriate method instead of creating new Cloud DNS records (D).

## Pregunta 15

Contexto: [topics:725](#topics-725)
Your on-premises data center has 2 routers connected to your Google Cloud environment through a VPN on each router. All applications are working correctly; however, all of the traffic is passing across a single VPN instead of being load-balanced across the 2 connections as desired.
During troubleshooting you find:
"¢ Each on-premises router is configured with a unique ASN.
"¢ Each on-premises router is configured with the same routes and priorities.
"¢ Both on-premises routers are configured with a VPN connected to a single Cloud Router.
"¢ BGP sessions are established between both on-premises routers and the Cloud Router.
"¢ Only 1 of the on-premises router's routes are being added to the routing table.
What is the most likely cause of this problem?

**A.** The on-premises routers are configured with the same routes.

**B.** A firewall is blocking the traffic across the second VPN connection.

**C.** You do not have a load balancer to load-balance the network traffic.

**D.** The ASNs being used on the on-premises routers are different.

**Respuesta de la fuente:** D

**Explicación:** In Google Cloud's legacy BGP route selection mode (the default behavior often tested), Cloud Router does not perform Equal-Cost Multi-Path (ECMP) routing across peers with different Autonomous System Numbers (ASNs). Instead, it prefers the route learned from the peer with the lowest ASN, ignoring routes from higher ASNs even if they represent identical prefixes. To enable load balancing across both VPN tunnels, the on-premises routers must be configured with the same ASN so that Cloud Router treats them as equal-cost paths.

## Pregunta 16

Contexto: [topics:725](#topics-725)
You have ordered Dedicated Interconnect in the GCP Console and need to give the Letter of Authorization/Connecting Facility Assignment (LOA-CFA) to your cross-connect provider to complete the physical connection.
Which two actions can accomplish this? (Choose two.)

**A.** Open a Cloud Support ticket under the Cloud Interconnect category.

**B.** Download the LOA-CFA from the Hybrid Connectivity section of the GCP Console.

**C.** Run gcloud compute interconnects describe <interconnect>.

**D.** Check the email for the account of the NOC contact that you specified during the ordering process.

**E.** Contact your cross-connect provider and inform them that Google automatically sent the LOA/CFA to them via email, and to complete the connection.

**Respuesta de la fuente:** B, D

**Explicación:** Google automatically sends the Letter of Authorization/Connecting Facility Assignment (LOA-CFA) via email to both the billing account owner and the specified Network Operations Center (NOC) contact, making checking that inbox (Option D) a primary method. Alternatively, users can manually retrieve the LOA-CFA by navigating to the Hybrid Connectivity section in the Google Cloud Console and downloading it directly (Option B).

Options A and C are incorrect because opening a support ticket is an unnecessary step for retrieving standard documentation, and while `gcloud` commands can retrieve resource metadata, they do not provide the official PDF LOA-CFA document required by the provider.

## Pregunta 17

Contexto: [topics:725](#topics-725)
Your company offers a popular gaming service. Your instances are deployed with private IP addresses, and external access is granted through a global load balancer. You believe you have identified a potential malicious actor, but aren't certain you have the correct client IP address. You want to identify this actor while minimizing disruption to your legitimate users.
What should you do?

**A.** Create a Cloud Armor Policy rule that denies traffic and review necessary logs.

**B.** Create a Cloud Armor Policy rule that denies traffic, enable preview mode, and review necessary logs.

**C.** Create a VPC Firewall rule that denies traffic, enable logging and set enforcement to disabled, and review necessary logs.

**D.** Create a VPC Firewall rule that denies traffic, enable logging and set enforcement to enabled, and review necessary logs.

**Respuesta de la fuente:** B

**Explicación:** Cloud Armor supports a preview mode that logs matches without enforcing the deny action, allowing investigation of suspected malicious IPs without blocking legitimate traffic. VPC firewall rules lack this non-enforcement logging capability and generally operate at layer 3/4 rather than the application layer required for precise client identification in proxy load balancing scenarios.

## Pregunta 18

Contexto: [topics:725](#topics-725)
Your company's web server administrator is migrating on-premises backend servers for an application to GCP. Libraries and configurations differ significantly across these backend servers. The migration to GCP will be lift-and-shift, and all requests to the servers will be served by a single network load balancer frontend.
You want to use a GCP-native solution when possible.
How should you deploy this service in GCP?

**A.** Create a managed instance group from one of the images of the on-premises servers, and link this instance group to a target pool behind your load balancer.

**B.** Create a target pool, add all backend instances to this target pool, and deploy the target pool behind your load balancer.

**C.** Deploy a third-party virtual appliance as frontend to these servers that will accommodate the significant differences between these backend servers.

**D.** Use GCP's ECMP capability to load-balance traffic to the backend servers by installing multiple equal-priority static routes to the backend servers.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Target Pools are the legacy backend configuration type specifically designed for External TCP/UDP Network Load Balancing and can accommodate heterogeneous instances that differ in libraries and configurations. Option A is incorrect because Managed Instance Groups require homogeneous instances based on a single template, making them unsuitable for servers with significant configuration differences.

## Pregunta 19

Contexto: [topics:725](#topics-725)
You decide to set up Cloud NAT. After completing the configuration, you find that one of your instances is not using the Cloud NAT for outbound NAT.
What is the most likely cause of this problem?

**A.** The instance has been configured with multiple interfaces.

**B.** An external IP address has been configured on the instance.

**C.** You have created static routes that use RFC1918 ranges.

**D.** The instance is accessible by a load balancer external IP address.

**Respuesta de la fuente:** B

**Explicación:** Cloud NAT is designed to provide outbound internet access for instances that do not have external IP addresses. If an instance is configured with an external IP address, that external IP always takes precedence for outbound traffic, performing one-to-one NAT instead of using the Cloud NAT gateway.
Therefore, the presence of an external IP on the instance causes it to bypass Cloud NAT.

## Pregunta 20

Contexto: [topics:725](#topics-725)
You want to set up two Cloud Routers so that one has an active Border Gateway Protocol (BGP) session, and the other one acts as a standby.
Which BGP attribute should you use on your on-premises router?

**A.** AS-Path

**B.** Community

**C.** Local Preference

**D.** Multi-exit Discriminator

**Respuesta de la fuente:** D

**Explicación:** The Multi-exit Discriminator (MED) is the correct attribute because it is evaluated by neighboring autonomous systems to determine the best entry point into your network. By assigning a lower MED value to the preferred Cloud Router, you influence GCP's inbound traffic selection to favor that specific active path over the standby.
Local Preference (Choice C) is incorrect in this context because it affects outbound traffic decisions within your own AS, whereas MED influences how the neighbor (GCP) sends traffic back to you.

## Pregunta 21

Contexto: [topics:725](#topics-725)
You are increasing your usage of Cloud VPN between on-premises and GCP, and you want to support more traffic than a single tunnel can handle. You want to increase the available bandwidth using Cloud VPN.
What should you do?

**A.** Double the MTU on your on-premises VPN gateway from 1460 bytes to 2920 bytes.

**B.** Create two VPN tunnels on the same Cloud VPN gateway that point to the same destination VPN gateway IP address.

**C.** Add a second on-premises VPN gateway with a different public IP address. Create a second tunnel on the existing Cloud VPN gateway that forwards the same IP range, but points at the new on-premises gateway IP.

**D.** Add a second Cloud VPN gateway in a different region than the existing VPN gateway. Create a new tunnel on the second Cloud VPN gateway that forwards the same IP range, but points to the existing on-premises VPN gateway IP address.

**Respuesta de la fuente:** C

**Explicación:** To increase Cloud VPN throughput beyond the limit of a single tunnel (up to 1.25 Gbps), you must scale horizontally by adding more tunnels. Option C is correct because it implements the recommended high-availability and scalable topology: adding a second on-premises gateway and creating a corresponding second tunnel from the existing Cloud VPN gateway, allowing traffic to load balance across both tunnels (up to 5 Gbps total).

Option B is incorrect because creating multiple tunnels between the same two IP endpoints does not provide additional bandwidth; it typically results in failover rather than aggregation or increased capacity. Option D is less optimal because Cloud VPN gateways are regional resources, and scaling within the same region using the existing gateway infrastructure (as in C) is the standard approach for increasing bandwidth before considering multi-region redundancy.

## Pregunta 22

Contexto: [topics:725](#topics-725)
You are disabling DNSSEC for one of your Cloud DNS-managed zones. You removed the DS records from your zone file, waited for them to expire from the cache, and disabled DNSSEC for the zone. You receive reports that DNSSEC validating resolves are unable to resolve names in your zone.
What should you do?

**A.** Update the TTL for the zone.

**B.** Set the zone to the TRANSFER state.

**C.** Disable DNSSEC at your domain registrar.

**D.** Transfer ownership of the domain to a new registrar.

**Respuesta de la fuente:** C

**Explicación:** Disabling DNSSEC in Cloud DNS only removes the cryptographic signatures from the zone responses but does not automatically remove the Delegation Signer (DS) records published at the parent zone (the domain registrar).
Validating resolvers still see these DS records and attempt to validate unsigned responses, resulting in BOGUS failures.
To fully disable DNSSEC, you must delete the DS records via your domain registrar so that the chain of trust is severed upstream.

## Pregunta 23

Contexto: [topics:725](#topics-725)
You have an application hosted on a Compute Engine virtual machine instance that cannot communicate with a resource outside of its subnet. When you review the flow and firewall logs, you do not see any denied traffic listed.
During troubleshooting you find:
"¢ Flow logs are enabled for the VPC subnet, and all firewall rules are set to log.
"¢ The subnetwork logs are not excluded from Stackdriver.
"¢ The instance that is hosting the application can communicate outside the subnet.
"¢ Other instances within the subnet can communicate outside the subnet.
"¢ The external resource initiates communication.
What is the most likely cause of the missing log lines?

**A.** The traffic is matching the expected ingress rule.

**B.** The traffic is matching the expected egress rule.

**C.** The traffic is not matching the expected ingress rule.

**D.** The traffic is not matching the expected egress rule.

**Respuesta de la fuente:** C

**Explicación:** The external resource initiates the connection, meaning the traffic is ingress to the VM. Since no denied traffic appears in the logs despite logging being enabled for all firewall rules, the traffic must be dropping due to an implicit deny rule rather than an explicit logged rule. Implicit deny rules are never logged, which occurs when traffic fails to match any allow rule (i.e., it is not matching the expected ingress rule). Option B/D is incorrect because egress traffic from GCE VMs is allowed by default and would typically be logged if matching a specific rule, but here the initiation comes from outside.

## Pregunta 24

Contexto: [topics:725](#topics-725)
You have configured Cloud CDN using HTTP(S) load balancing as the origin for cacheable content. Compression is configured on the web servers, but responses served by Cloud CDN are not compressed.
What is the most likely cause of the problem?

**A.** You have not configured compression in Cloud CDN.

**B.** You have configured the web servers and Cloud CDN with different compression types.

**C.** The web servers behind the load balancer are configured with different compression types.

**D.** You have to configure the web servers to compress responses even if the request has a Via header.

**Respuesta de la fuente:** D

**Explicación:** Cloud CDN itself does not perform compression; it relies on the origin server to send compressed responses. The HTTP Load Balancer adds a 'Via' header to requests forwarded to the backend, and many web servers disable compression by default when this header is present to avoid double-compression issues with older proxies.
Therefore, you must configure the web servers to ignore the 'Via' header and compress responses anyway. Option A is incorrect because Cloud CDN configuration does not include compression settings.

## Pregunta 25

Contexto: [topics:725](#topics-725)
You have a web application that is currently hosted in the us-central1 region. Users experience high latency when traveling in Asia. You've configured a network load balancer, but users have not experienced a performance improvement. You want to decrease the latency.
What should you do?

**A.** Configure a policy-based route rule to prioritize the traffic.

**B.** Configure an HTTP load balancer, and direct the traffic to it.

**C.** Configure Dynamic Routing for the subnet hosting the application.

**D.** Configure the TTL for the DNS zone to decrease the time between updates.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Google Cloud Network Load Balancers are regional services, meaning traffic from Asian users must still traverse the public internet to the us-central1 region, preserving high latency. In contrast, an HTTP (Application) Load Balancer is a global service with a single anycast IP address; it uses Google's internal global network to route requests to the nearest available backend instance, thereby reducing latency for remote users. Option A is incorrect because policy-based routing primarily optimizes traffic within GCP VPCs or on-premises connections, not public internet latency from distant regions.

## Pregunta 26

Contexto: [topics:725](#topics-725)
You have an application running on Compute Engine that uses BigQuery to generate some results that are stored in Cloud Storage. You want to ensure that none of the application instances have external IP addresses.
Which two methods can you use to accomplish this? (Choose two.)

**A.** Enable Private Google Access on all the subnets.

**B.** Enable Private Google Access on the VPC.

**C.** Enable Private Services Access on the VPC.

**D.** Create network peering between your VPC and BigQuery.

**E.** Create a Cloud NAT, and route the application traffic via NAT gateway.

**Respuesta de la fuente:** A, E

**Explicación:** Private Google Access (A) allows instances without external IPs to reach Google APIs and services like BigQuery. Cloud NAT (E) enables those same instances to initiate outbound connections to the internet or other GCP services while remaining behind a firewall with no public IP assigned. Option C is incorrect because Private Services Access is used for VPC Service Controls and private service connections, not general egress routing.

## Pregunta 27

Contexto: [topics:725](#topics-725)
You are designing a shared VPC architecture. Your network and security team has strict controls over which routes are exposed between departments. Your
Production and Staging departments can communicate with each other, but only via specific networks. You want to follow Google-recommended practices.
How should you design this topology?

**A.** Create 2 shared VPCs within the shared VPC Host Project, and enable VPC peering between them. Use firewall rules to filter access between the specific networks.

**B.** Create 2 shared VPCs within the shared VPC Host Project, and create a Cloud VPN/Cloud Router between them. Use Flexible Route Advertisement (FRA) to filter access between the specific networks.

**C.** Create 2 shared VPCs within the shared VPC Service Project, and create a Cloud VPN/Cloud Router between them. Use Flexible Route Advertisement (FRA) to filter access between the specific networks.

**D.** Create 1 VPC within the shared VPC Host Project, and share individual subnets with the Service Projects to filter access between the specific networks.

**Respuesta de la fuente:** D

**Explicación:** Google Cloud architecture best practices recommend using a single Shared VPC in the Host Project to centralize network resource management (subnets, routes, firewalls) while delegating compute resource management to Service Projects.
Choices A, B, and C are technically invalid because a Host Project can contain only one VPC that is shared; you cannot create multiple 'Shared VPCs' within a single Host Project.

## Pregunta 28

Contexto: [topics:725](#topics-725)
You are adding steps to a working automation that uses a service account to authenticate. You need to drive the automation the ability to retrieve files from a
Cloud Storage bucket. Your organization requires using the least privilege possible.
What should you do?

**A.** Grant the compute.instanceAdmin to your user account.

**B.** Grant the iam.serviceAccountUser to your user account.

**C.** Grant the read-only privilege to the service account for the Cloud Storage bucket.

**D.** Grant the cloud-platform privilege to the service account for the Cloud Storage bucket.

**Respuesta de la fuente:** C

**Explicación:** To adhere to the principle of least privilege, you must grant only the specific permissions required for the task. Since the automation needs to retrieve (read) files, granting a read-only role to the service account provides exactly that access without unnecessary write or administrative capabilities.
Option D is incorrect because 'cloud-platform' implies broad, often administrator-level access, which violates the least privilege requirement.

## Pregunta 29

Contexto: [topics:725](#topics-725)
You converted an auto mode VPC network to custom mode. Since the conversion, some of your Cloud Deployment Manager templates are no longer working.
You want to resolve the problem.
What should you do?

**A.** Apply an additional IAM role to the Google API's service account to allow custom mode networks.

**B.** Update the VPC firewall to allow the Cloud Deployment Manager to access the custom mode networks.

**C.** Explicitly reference the custom mode networks in the Cloud Armor whitelist.

**D.** Explicitly reference the custom mode networks in the Deployment Manager templates.

**Respuesta de la fuente:** D

**Explicación:** When a VPC is in auto mode, GCP automatically creates default subnets in each region, allowing Deployment Manager templates to implicitly use them. Switching to custom mode disables this automatic subnet creation, so resources can no longer rely on implicit defaults. Therefore, you must explicitly define or reference the specific subnets within your Deployment Manager templates to ensure resources are provisioned correctly.
Option B is incorrect because this issue concerns resource configuration definitions, not network access control.

## Pregunta 30

Contexto: [topics:725](#topics-725)
You have recently been put in charge of managing identity and access management for your organization. You have several projects and want to use scripting and automation wherever possible. You want to grant the editor role to a project member.
Which two methods can you use to accomplish this? (Choose two.)

**A.** GetIamPolicy() via REST API

**B.** setIamPolicy() via REST API

**C.** gcloud pubsub add-iam-policy-binding Sprojectname --member user:Susername --role roles/editor

**D.** gcloud projects add-iam-policy-binding Sprojectname --member user:Susername --role roles/editor

**E.** Enter an email address in the Add members field, and select the desired role from the drop-down menu in the GCP Console.

**Respuesta de la fuente:** B, D

**Explicación:** The question requires methods suitable for scripting and automation to grant the editor role.
Option B (setIamPolicy via REST API) is correct because it allows programmatic updates to IAM policies.
Option D (gcloud projects add-iam-policy-binding) is correct because the gcloud CLI is designed for automation and correctly targets the project resource.
Option E is incorrect because manual Console interactions are not automated, while Option A is read-only and does not grant access.

## Pregunta 31

Contexto: [topics:725](#topics-725)
You are using a 10-Gbps direct peering connection to Google together with the gsutil tool to upload files to Cloud Storage buckets from on-premises servers. The on-premises servers are 100 milliseconds away from the Google peering point. You notice that your uploads are not using the full 10-Gbps bandwidth available to you. You want to optimize the bandwidth utilization of the connection.
What should you do on your on-premises servers?

**A.** Tune TCP parameters on the on-premises servers.

**B.** Compress files using utilities like tar to reduce the size of data being sent.

**C.** Remove the -m flag from the gsutil command to enable single-threaded transfers.

**D.** Use the perfdiag parameter in your gsutil command to enable faster performance: gsutil perfdiag gs://[BUCKET NAME].

**Respuesta de la fuente:** A

**Explicación:** The 100ms round-trip time creates a high Bandwidth-Delay Product (BDP), requiring a large TCP window size to fully utilize the 10-Gbps link. If default TCP buffer sizes are too small, the sender must wait for ACKs frequently, creating gaps in data flow and limiting throughput; tuning these parameters resolves this bottleneck.

Compressing files (B) adds CPU overhead without addressing the network latency constraint, removing multi-threading (C) would reduce parallelism and likely lower performance further, and perfdiag (D) is a diagnostic tool rather than a performance optimization setting.

## Pregunta 32

Contexto: [topics:725](#topics-725)
You work for a multinational enterprise that is moving to GCP.
These are the cloud requirements:
"¢ An on-premises data center located in the United States in Oregon and New York with Dedicated Interconnects connected to Cloud regions us-west1 (primary
HQ) and us-east4 (backup)
"¢ Multiple regional offices in Europe and APAC
"¢ Regional data processing is required in europe-west1 and australia-southeast1
"¢ Centralized Network Administration Team
Your security and compliance team requires a virtual inline security appliance to perform L7 inspection for URL filtering. You want to deploy the appliance in us- west1.
What should you do?

**A.** "¢ Create 2 VPCs in a Shared VPC Host Project. "¢ Configure a 2-NIC instance in zone us-west1-a in the Host Project. "¢ Attach NIC0 in VPC #1 us-west1 subnet of the Host Project. "¢ Attach NIC1 in VPC #2 us-west1 subnet of the Host Project. "¢ Deploy the instance. "¢ Configure the necessary routes and firewall rules to pass traffic through the instance.

**B.** "¢ Create 2 VPCs in a Shared VPC Host Project. "¢ Configure a 2-NIC instance in zone us-west1-a in the Service Project. "¢ Attach NIC0 in VPC #1 us-west1 subnet of the Host Project. "¢ Attach NIC1 in VPC #2 us-west1 subnet of the Host Project. "¢ Deploy the instance. "¢ Configure the necessary routes and firewall rules to pass traffic through the instance.

**C.** "¢ Create 1 VPC in a Shared VPC Host Project. "¢ Configure a 2-NIC instance in zone us-west1-a in the Host Project. "¢ Attach NIC0 in us-west1 subnet of the Host Project. "¢ Attach NIC1 in us-west1 subnet of the Host Project "¢ Deploy the instance. "¢ Configure the necessary routes and firewall rules to pass traffic through the instance.

**D.** "¢ Create 1 VPC in a Shared VPC Service Project. "¢ Configure a 2-NIC instance in zone us-west1-a in the Service Project. "¢ Attach NIC0 in us-west1 subnet of the Service Project. "¢ Attach NIC1 in us-west1 subnet of the Service Project "¢ Deploy the instance. "¢ Configure the necessary routes and firewall rules to pass traffic through the instance.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Google Cloud does not support attaching multiple network interfaces to the same VPC network; therefore, two distinct VPC networks are required for a multi-NIC inline appliance.
Additionally, for centralized network administration within a Shared VPC architecture, network infrastructure components like security appliances must be deployed in the Host Project to ensure the central team retains control over routing and firewall rules.

## Pregunta 33

Contexto: [topics:725](#topics-725)
You are designing a Google Kubernetes Engine (GKE) cluster for your organization. The current cluster size is expected to host 10 nodes, with 20 Pods per node and 150 services. Because of the migration of new services over the next 2 years, there is a planned growth for 100 nodes, 200 Pods per node, and 1500 services. You want to use VPC-native clusters with alias IP ranges, while minimizing address consumption.
How should you design this topology?

**A.** Create a subnet of size/25 with 2 secondary ranges of: /17 for Pods and /21 for Services. Create a VPC-native cluster and specify those ranges.

**B.** Create a subnet of size/28 with 2 secondary ranges of: /24 for Pods and /24 for Services. Create a VPC-native cluster and specify those ranges. When the services are ready to be deployed, resize the subnets.

**C.** Use gcloud container clusters create [CLUSTER NAME]--enable-ip-alias to create a VPC-native cluster.

**D.** Use gcloud container clusters create [CLUSTER NAME] to create a VPC-native cluster.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it correctly calculates the required IP ranges for future growth: 20,000 Pods fit within a /17 range (32,768 addresses), and 1,500 Services fit within a /21 range (2,048 addresses).

Option B is incorrect because secondary CIDR ranges cannot be resized after creation, and a /24 range only supports up to 256 IPs, which is insufficient for the planned 1,500 services.

## Pregunta 34

Contexto: [topics:725](#topics-725)
Your company has recently expanded their EMEA-based operations into APAC. Globally distributed users report that their SMTP and IMAP services are slow.
Your company requires end-to-end encryption, but you do not have access to the SSL certificates.
Which Google Cloud load balancer should you use?

**A.** SSL proxy load balancer

**B.** Network load balancer

**C.** HTTPS load balancer

**D.** TCP proxy load balancer

**Respuesta de la fuente:** D

**Explicación:** The TCP Proxy Load Balancer is the correct choice because it supports global distribution and passes encrypted traffic directly to backend instances without terminating SSL, satisfying the 'no access to certificates' constraint.
SSL Proxy requires uploading certificates for termination, which is impossible here, while Network Load Balancer lacks global anycast IP capabilities needed for low-latency global access.

## Pregunta 35

Contexto: [topics:725](#topics-725)
Your company is working with a partner to provide a solution for a customer. Both your company and the partner organization are using GCP. There are applications in the partner's network that need access to some resources in your company's VPC. There is no CIDR overlap between the VPCs.
Which two solutions can you implement to achieve the desired results without compromising the security? (Choose two.)

**A.** VPC peering

**B.** Shared VPC

**C.** Cloud VPN

**D.** Dedicated Interconnect

**E.** Cloud NAT

**Respuesta de la fuente:** A, C

**Explicación:** VPC Peering (A) is a valid solution as it allows private IP communication between VPCs in different organizations without requiring public internet access, provided no CIDR overlap exists.
Cloud VPN (C) is also correct because it establishes an encrypted tunnel over the internet, ensuring data security when connecting resources across organizational boundaries.
Shared VPC (B) is incorrect because it only supports resource sharing within projects under the same Google Cloud organization, not between separate partner organizations.

## Pregunta 36

Contexto: [topics:725](#topics-725)
You have a storage bucket that contains the following objects:
[1]
[1]
[1]
[1]
Cloud CDN is enabled on the storage bucket, and all four objects have been successfully cached. You want to remove the cached copies of all the objects with the prefix folder-a, using the minimum number of commands.
What should you do?

**A.** Add an appropriate lifecycle rule on the storage bucket.

**B.** Issue a cache invalidation command with pattern /folder-a/*.

**C.** Make sure that all the objects with prefix folder-a are not shared publicly.

**D.** Disable Cloud CDN on the storage bucket. Wait 90 seconds. Re-enable Cloud CDN on the storage bucket.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Cloud CDN supports cache invalidation via path patterns, allowing you to target specific prefixes like /folder-a/* to remove cached copies immediately without affecting other objects or bucket configuration.

Option A is incorrect because lifecycle rules manage object retention in the storage bucket itself, not the CDN cache state.

Option D is incorrect because disabling and re-enabling Cloud CDN is a disruptive operation that invalidates the entire cache for the bucket, which is far more than the minimum number of commands or scope required.

## Pregunta 37

Contexto: [topics:725](#topics-725)
Your company is running out of network capacity to run a critical application in the on-premises data center. You want to migrate the application to GCP. You also want to ensure that the Security team does not lose their ability to monitor traffic to and from Compute Engine instances.
Which two products should you incorporate into the solution? (Choose two.)

**A.** VPC flow logs

**B.** Firewall logs

**C.** Cloud Audit logs

**D.** Stackdriver Trace

**E.** Compute Engine instance system logs

**Respuesta de la fuente:** A, B

**Explicación:** VPC Flow Logs record network flows entering and exiting Compute Engine instances, providing essential visibility into traffic patterns for security monitoring. Firewall Rules Logging captures details of allowed or denied connections at the firewall layer, ensuring auditability of access controls.
Together, these two products offer comprehensive network-level traffic monitoring required by the Security team.
Cloud Audit logs track administrative API activity rather than data plane traffic, making them unsuitable for this specific requirement.

## Pregunta 38

Contexto: [topics:725](#topics-725)
You want to apply a new Cloud Armor policy to an application that is deployed in Google Kubernetes Engine (GKE). You want to find out which target to use for your Cloud Armor policy.
Which GKE resource should you use?

**A.** GKE Node

**B.** GKE Pod

**C.** GKE Cluster

**D.** GKE Ingress

**Respuesta de la fuente:** D

**Explicación:** Cloud Armor security policies are attached to external HTTP(S) load balancers, which serve as the entry point for traffic in GKE.
In Google Kubernetes Engine, the Ingress resource is the standard mechanism that creates and manages these external load balancers.
Therefore, you must configure or reference the GKE Ingress resource to apply the Cloud Armor policy effectively.
Alternatives like Nodes (A), Pods (B), or Clusters (C) do not expose the necessary load balancer targets required for Cloud Armor attachment.

## Pregunta 39

Contexto: [topics:725](#topics-725)
You need to establish network connectivity between three Virtual Private Cloud networks, Sales, Marketing, and Finance, so that users can access resources in all three VPCs. You configure VPC peering between the Sales VPC and the Finance VPC. You also configure VPC peering between the Marketing VPC and the
Finance VPC. After you complete the configuration, some users cannot connect to resources in the Sales VPC and the Marketing VPC. You want to resolve the problem.
What should you do?

**A.** Configure VPC peering in a full mesh.

**B.** Alter the routing table to resolve the asymmetric route.

**C.** Create network tags to allow connectivity between all three VPCs.

**D.** Delete the legacy network and recreate it to allow transitive peering.

**Respuesta de la fuente:** A

**Explicación:** VPC peering connections are strictly non-transitive, meaning that traffic cannot route through an intermediate VPC (e.g., Sales -> Finance -> Marketing).
Therefore, to ensure full connectivity between all three VPCs, you must create direct peering connections between every pair of VPCs (Sales-Marketing, Sales-Finance, and Marketing-Finance), forming a full mesh topology.
Option B is incorrect because altering routing tables cannot overcome the fundamental limitation that transitive peering is not supported by the platform.

## Pregunta 40

Contexto: [topics:725](#topics-725)
You create multiple Compute Engine virtual machine instances to be used at TFTP servers.
Which type of load balancer should you use?

**A.** HTTP(S) load balancer

**B.** SSL proxy load balancer

**C.** TCP proxy load balancer

**D.** Network load balancer

**Respuesta de la fuente:** D

**Explicación:** TFTP (Trivial File Transfer Protocol) operates over UDP, not TCP. In Google Cloud, the External Network Load Balancer is the only external load balancer capable of handling both TCP and UDP traffic at Layer 4. HTTP(S), SSL proxy, and TCP proxy load balancers are layer-7 or layer-5 proxies that strictly support TCP-based protocols and cannot forward UDP packets.

## Pregunta 41

Contexto: [topics:725](#topics-725)
You want to configure load balancing for an internet-facing, standard voice-over-IP (VOIP) application.
Which type of load balancer should you use?

**A.** HTTP(S) load balancer

**B.** Network load balancer

**C.** Internal TCP/UDP load balancer

**D.** TCP/SSL proxy load balancer

**Respuesta de la fuente:** B

**Explicación:** VoIP applications primarily rely on UDP for real-time voice and video streams (RTP) to minimize latency, which only the Network Load Balancer supports among internet-facing options.
Option C is incorrect because it is internal-only, failing the "internet-facing" requirement, while Option A is unsuitable as VoIP does not typically operate over standard HTTP/HTTPS protocols.

## Pregunta 42

Contexto: [topics:725](#topics-725)
You want to configure a NAT to perform address translation between your on-premises network blocks and GCP.
Which NAT solution should you use?

**A.** Cloud NAT

**B.** An instance with IP forwarding enabled

**C.** An instance configured with iptables DNAT rules

**D.** An instance configured with iptables SNAT rules

**Respuesta de la fuente:** A

**Explicación:** Cloud NAT is the managed service provided by Google Cloud specifically designed to enable private IP instances to initiate outbound connections to the internet or on-premises networks via public IPs.
While manual configurations using VMs with iptables (options B, C, and D) can technically achieve NAT, they require significant operational overhead for maintenance, scaling, and high availability, making them inferior to the purpose-built managed service in a certification context.

## Pregunta 43

Contexto: [topics:725](#topics-725)
You need to ensure your personal SSH key works on every instance in your project. You want to accomplish this as efficiently as possible.
What should you do?

**A.** Upload your public ssh key to the project Metadata.

**B.** Upload your public ssh key to each instance Metadata.

**C.** Create a custom Google Compute Engine image with your public ssh key embedded.

**D.** Use gcloud compute ssh to automatically copy your public ssh key to the instance.

**Respuesta de la fuente:** A

**Explicación:** Uploading the SSH key to project-level metadata applies it to all current and future instances in the project by default, making it the most efficient method for broad access.
Instance-level metadata (B) requires manual configuration for each instance, while custom images (C) are static and do not propagate to existing or new instances dynamically.

## Pregunta 44

Contexto: [topics:725](#topics-725)
In order to provide subnet level isolation, you want to force instance-A in one subnet to route through a security appliance, called instance-B, in another subnet.
What should you do?

**A.** Create a more specific route than the system-generated subnet route, pointing the next hop to instance-B with no tag.

**B.** Create a more specific route than the system-generated subnet route, pointing the next hop to instance-B with a tag applied to instance-A.

**C.** Delete the system-generated subnet route and create a specific route to instance-B with a tag applied to instance-A.

**D.** Move instance-B to another VPC and, using multi-NIC, connect instance-B's interface to instance-A's network. Configure the appropriate routes to force traffic through to instance-A.

**Respuesta de la fuente:** B

**Explicación:** In Google Cloud VPC, you cannot create a custom static route that is more specific than an existing system-generated subnet route for the same destination CIDR. However, the restriction applies to overlapping destinations; by using network tags, you can define a static route that targets only instance-A (the source) without violating the specificity rule relative to the default subnet route's scope for other instances. Option B correctly utilizes this mechanism: it creates a route pointing to instance-B as the next hop and applies a tag to restrict the route's applicability strictly to instance-A, thereby forcing its traffic through the security appliance.

Option A is incorrect because without a tag, the custom route would apply to all instances in the network, likely conflicting with or overriding existing default routes for other traffic, which is not the goal of isolating just instance-A. Options C and D are incorrect because you cannot delete system-generated subnet routes, and moving VPCs is an unnecessarily complex architectural change when static routing with tags achieves the same isolation.

## Pregunta 45

Contexto: [topics:725](#topics-725)
You create a Google Kubernetes Engine private cluster and want to use kubectl to get the status of the pods. In one of your instances you notice the master is not responding, even though the cluster is up and running.
What should you do to solve the problem?

**A.** Assign a public IP address to the instance.

**B.** Create a route to reach the Master, pointing to the default internet gateway.

**C.** Create the appropriate firewall policy in the VPC to allow traffic from Master node IP address to the instance.

**D.** Create the appropriate master authorized network entries to allow the instance to communicate to the master.

**Respuesta de la fuente:** D

**Explicación:** In a GKE private cluster, the control plane endpoint is restricted to specific IP ranges defined by Master Authorized Networks (MANs). To allow an internal instance running kubectl to communicate with the master, its IP address must be explicitly included in these MAN entries. Option C is incorrect because VPC firewall rules govern traffic between nodes and workloads, not access to the managed control plane endpoint.

## Pregunta 46

Contexto: [topics:725](#topics-725)
Your company has a security team that manages firewalls and SSL certificates. It also has a networking team that manages the networking resources. The networking team needs to be able to read firewall rules, but should not be able to create, modify, or delete them.
How should you set up permissions for the networking team?

**A.** Assign members of the networking team the compute.networkUser role.

**B.** Assign members of the networking team the compute.networkAdmin role.

**C.** Assign members of the networking team a custom role with only the compute.networks.* and the compute.firewalls.list permissions.

**D.** Assign members of the networking team the compute.networkViewer role, and add the compute.networks.use permission.

**Respuesta de la fuente:** B

**Explicación:** The compute.networkAdmin role is explicitly designed for shared responsibility scenarios where one team manages general network resources while another manages firewalls. This role grants full control over network resources but intentionally excludes permissions to manage firewall rules and SSL certificates, satisfying the requirement that the networking team can read (but not modify) firewall configurations managed by security.
Option A (networkUser) only allows using existing networks for instances, lacking administrative oversight needed by a 'networking team'. Option C suggests an overly complex custom role when a predefined role exists for this exact separation of duties. Option D provides only view access, which is insufficient for a team that manages networking resources.

## Pregunta 47

Contexto: [topics:725](#topics-725)
You have created an HTTP(S) load balanced service. You need to verify that your backend instances are responding properly.
How should you configure the health check?

**A.** Set request-path to a specific URL used for health checking, and set proxy-header to PROXY_V1.

**B.** Set request-path to a specific URL used for health checking, and set host to include a custom host header that identifies the health check.

**C.** Set request-path to a specific URL used for health checking, and set response to a string that the backend service will always return in the response body.

**D.** Set proxy-header to the default value, and set host to include a custom host header that identifies the health check.

**Respuesta de la fuente:** C

**Explicación:** To verify that backend instances are responding properly in an HTTP(S) load balancer, content-based health checks provide the most robust verification. By setting the request-path to a specific health check URL and configuring the response field to expect a specific string (e.g., "OK") in the response body, you ensure that the backend is not only up but also serving correct content.

Option A is incorrect because PROXY_V1 headers are used for passing client IP information via the PROXY protocol, not for standard HTTP health checks. Option B and D rely solely on headers or host identification without verifying the actual response content, which is less reliable for confirming application-level health.

## Pregunta 48

Contexto: [topics:725](#topics-725)
You need to give each member of your network operations team least-privilege access to create, modify, and delete Cloud Interconnect VLAN attachments.
What should you do?

**A.** Assign each user the editor role.

**B.** Assign each user the compute.networkAdmin role.

**C.** Give each user the following permissions only: compute.interconnectAttachments.create, compute.interconnectAttachments.get.

**D.** Give each user the following permissions only: compute.interconnectAttachments.create, compute.interconnectAttachments.get, compute.routers.create, compute.routers.get, compute.routers.update.

**Respuesta de la fuente:** B

**Explicación:** The requirement is to grant least-privilege access specifically for creating, modifying, and deleting Cloud Interconnect VLAN attachments. The `compute.networkAdmin` role includes the necessary `compute.interconnectAttachments.create`, `compute.interconnectAttachments.update`, and `compute.interconnectAttachments.delete` permissions, along with other required network management permissions.

While custom roles (like option D) might seem like a candidate for least privilege, option D explicitly lacks the `delete` permission for interconnect attachments (`compute.interconnectAttachments.delete`) and only provides router permissions, making it insufficient for the stated goal. Option A is too broad (Editor role), and Option C lacks modification and deletion capabilities.

## Pregunta 49

Contexto: [topics:725](#topics-725)
You have an application that is running in a managed instance group. Your development team has released an updated instance template which contains a new feature which was not heavily tested. You want to minimize impact to users if there is a bug in the new template.
How should you update your instances?

**A.** Manually patch some of the instances, and then perform a rolling restart on the instance group.

**B.** Using the new instance template, perform a rolling update across all instances in the instance group. Verify the new feature once the rollout completes.

**C.** Deploy a new instance group and canary the updated template in that group. Verify the new feature in the new canary instance group, and then update the original instance group.

**D.** Perform a canary update by starting a rolling update and specifying a target size for your instances to receive the new template. Verify the new feature on the canary instances, and then roll forward to the rest of the instances.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it utilizes a canary update within the existing managed instance group, allowing you to limit exposure of the untested template to a small, specified subset of instances for validation before proceeding. This approach minimizes user impact by containing potential bugs to only those few canary instances rather than affecting the entire service or requiring complex external load balancing configurations.

Option C is incorrect because creating a separate instance group introduces unnecessary architectural complexity and traffic routing configuration that is not required when the native canary update feature exists.

## Pregunta 50

Contexto: [topics:725](#topics-725)
You have deployed a proof-of-concept application by manually placing instances in a single Compute Engine zone. You are now moving the application to production, so you need to increase your application availability and ensure it can autoscale.
How should you provision your instances?

**A.** Create a single managed instance group, specify the desired region, and select Multiple zones for the location.

**B.** Create a managed instance group for each region, select Single zone for the location, and manually distribute instances across the zones in that region.

**C.** Create an unmanaged instance group in a single zone, and then create an HTTP load balancer for the instance group.

**D.** Create an unmanaged instance group for each zone, and manually distribute the instances across the desired zones.

**Respuesta de la fuente:** A

**Explicación:** Managed Instance Groups (MIGs) are required to enable autoscaling and automated instance distribution across zones, making unmanaged groups (C and D) incorrect for this requirement.
Option A is the correct approach because creating a single regional MIG with multiple zones ensures high availability by distributing instances automatically within the region while simplifying management compared to handling multiple separate groups.

## Pregunta 51

Contexto: [topics:725](#topics-725)
You have a storage bucket that contains two objects. Cloud CDN is enabled on the bucket, and both objects have been successfully cached. Now you want to make sure that one of the two objects will not be cached anymore, and will always be served to the internet directly from the origin.
What should you do?

**A.** Ensure that the object you don't want to be cached anymore is not shared publicly.

**B.** Create a new storage bucket, and move the object you don't want to be checked anymore inside it. Then edit the bucket setting and enable the private attribute.

**C.** Add an appropriate lifecycle rule on the storage bucket containing the two objects.

**D.** Add a Cache-Control entry with value private to the metadata of the object you don't want to be cached anymore. Invalidate all the previously cached copies.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because the `Cache-Control: private` header explicitly instructs Cloud CDN not to cache the object, ensuring it is always served directly from the origin. Additionally, invalidating the previously cached copies is necessary to remove the existing cached version and enforce the new no-cache behavior immediately.

Option C is the most tempting alternative but is incorrect because lifecycle rules manage object retention and deletion (e.g., transitioning to cold storage or deleting old files), not HTTP caching behavior for active content delivery.

## Pregunta 52

Contexto: [topics:725](#topics-725)
Your company offers a popular gaming service. Your instances are deployed with private IP addresses, and external access is granted through a global load balancer. You have recently engaged a traffic-scrubbing service and want to restrict your origin to allow connections only from the traffic-scrubbing service.
What should you do?

**A.** Create a Cloud Armor Security Policy that blocks all traffic except for the traffic-scrubbing service.

**B.** Create a VPC Firewall rule that blocks all traffic except for the traffic-scrubbing service.

**C.** Create a VPC Service Control Perimeter that blocks all traffic except for the traffic-scrubbing service.

**D.** Create IPTables firewall rules that block all traffic except for the traffic-scrubbing service.

**Respuesta de la fuente:** A

**Explicación:** Cloud Armor Security Policies are applied at the Global HTTP(S) Load Balancer edge, allowing you to filter traffic before it reaches backend instances.
VPC Firewall rules inspect traffic after the load balancer proxy, where source IPs are translated to Google Frontend Endpoints (GFE), making IP-based allow-listing of the scrubbing service impossible.

## Pregunta 53

Contexto: [topics:725](#topics-725)
Your software team is developing an on-premises web application that requires direct connectivity to Compute Engine Instances in GCP using the RFC 1918 address space. You want to choose a connectivity solution from your on-premises environment to GCP, given these specifications:
✑ Your ISP is a Google Partner Interconnect provider.
✑ Your on-premises VPN device's internet uplink and downlink speeds are 10 Gbps.
✑ A test VPN connection between your on-premises gateway and GCP is performing at a maximum speed of 500 Mbps due to packet losses.
✑ Most of the data transfer will be from GCP to the on-premises environment.
✑ The application can burst up to 1.5 Gbps during peak transfers over the Interconnect.
✑ Cost and the complexity of the solution should be minimal.
How should you provision the connectivity solution?

**A.** Provision a Partner Interconnect through your ISP.

**B.** Provision a Dedicated Interconnect instead of a VPN.

**C.** Create multiple VPN tunnels to account for the packet losses, and increase bandwidth using ECMP.

**D.** Use network compression over your VPN to increase the amount of data you can send over your VPN.

**Respuesta de la fuente:** A

**Explicación:** Partner Interconnect (A) is the optimal choice because it provides a private, dedicated connection that avoids the public internet, thereby eliminating the packet loss and bandwidth limitations (500 Mbps cap) observed with the current VPN setup.
It supports the required 1.5 Gbps burst capability with lower complexity and potentially better egress cost structures than Dedicated Interconnect or multiple VPN tunnels.

Option C (multiple VPN tunnels) is incorrect because adding more tunnels does not resolve the underlying packet loss on the internet uplink, nor does it guarantee the consistent bandwidth and stability required for a production application.

## Pregunta 54

Contexto: [topics:725](#topics-725)
Your company has just launched a new critical revenue-generating web application. You deployed the application for scalability using managed instance groups, autoscaling, and a network load balancer as frontend. One day, you notice severe bursty traffic that the caused autoscaling to reach the maximum number of instances, and users of your application cannot complete transactions. After an investigation, you think it as a DDOS attack. You want to quickly restore user access to your application and allow successful transactions while minimizing cost.
Which two steps should you take? (Choose two.)

**A.** Use Cloud Armor to blacklist the attacker's IP addresses.

**B.** Increase the maximum autoscaling backend to accommodate the severe bursty traffic.

**C.** Create a global HTTP(s) load balancer and move your application backend to this load balancer.

**D.** Shut down the entire application in GCP for a few hours. The attack will stop when the application is offline.

**E.** SSH into the backend compute engine instances, and view the auth logs and syslogs to further understand the nature of the attack.

**Respuesta de la fuente:** A, C

**Explicación:** Option C is required because Cloud Armor (Option A) only integrates with global HTTP(S) load balancers, not the current Network Load Balancer. Moving to an HTTP(S) LB enables DDoS mitigation features and allows Cloud Armor to filter malicious traffic, restoring service while minimizing backend costs compared to autoscaling against an attack (Option B).

## Pregunta 55

Contexto: [topics:725](#topics-725)
You are creating a new application and require access to Cloud SQL from VPC instances without public IP addresses.
Which two actions should you take? (Choose two.)

**A.** Activate the Service Networking API in your project.

**B.** Activate the Cloud Datastore API in your project.

**C.** Create a private connection to a service producer.

**D.** Create a custom static route to allow the traffic to reach the Cloud SQL API.

**E.** Enable Private Google Access.

**Respuesta de la fuente:** A, C

**Explicación:** To enable private IP access to Cloud SQL for VPC instances without public IPs, you must use Private Services Access. This requires activating the Service Networking API (A) and creating a private connection between your consumer network and the Google service producer's network (C). Option E is incorrect because Private Google Access allows VMs to reach Google APIs via external IP addresses using internal IPs; it does not provide private IP connectivity to Cloud SQL instances.

## Pregunta 56

Contexto: [topics:725](#topics-725)
You want to use Cloud Interconnect to connect your on-premises network to a GCP VPC. You cannot meet Google at one of its point-of-presence (POP) locations, and your on-premises router cannot run a Border Gateway Protocol (BGP) configuration.
Which connectivity model should you use?

**A.** Direct Peering

**B.** Dedicated Interconnect

**C.** Partner Interconnect with a layer 2 partner

**D.** Partner Interconnect with a layer 3 partner

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Partner Interconnect with a Layer 3 partner allows the service provider to establish the BGP session between their edge routers and Google Cloud Routers, eliminating the need for BGP configuration on your on-premises router. This model is ideal when you cannot physically meet Google at a POP location, as partners provide transit services from your existing network infrastructure.

Option C (Layer 2 partner) is incorrect because Layer 2 connections require you to configure and maintain the BGP session directly between your on-premises router and Google Cloud Routers, which violates the constraint that your router cannot run BGP configuration.

## Pregunta 57

Contexto: [topics:725](#topics-725)
You have configured a Compute Engine virtual machine instance as a NAT gateway. You execute the following command: gcloud compute routes create no-ip-internet-route \
--network custom-network1 \
--destination-range 0.0.0.0/0 \
--next-hop instance nat-gateway \
--next-hop instance-zone us-central1-a \
--tags no-ip --priority 800
You want existing instances to use the new NAT gateway.
Which command should you execute?

**A.** sudo sysctl -w net.ipv4.ip_forward=1

**B.** gcloud compute instances add-tags [existing-instance] --tags no-ip

**C.** gcloud builds submit --config=cloudbuild.waml --substitutions=TAG_NAME=no-ip

**D.** gcloud compute instances create example-instance --network custom-network1 \ --subnet subnet-us-central \ --no-address \ --zone us-central1-a \ --image-family debian-9 \ --image-project debian-cloud \ --tags no-ip

**Respuesta de la fuente:** B

**Explicación:** The custom route created in the prompt includes the flag --tags no-ip, which restricts the route's applicability to instances bearing that specific network tag. To enable existing instances to use this new NAT gateway route, you must append the 'no-ip' tag to those instances using gcloud compute instances add-tags.
Option A configures OS-level IP forwarding on the gateway itself, which is a prerequisite for the gateway instance but does not affect routing decisions for client instances. Option D creates a new instance rather than modifying existing ones.

## Pregunta 58

Contexto: [topics:725](#topics-725)
You need to configure a static route to an on-premises resource behind a Cloud VPN gateway that is configured for policy-based routing using the gcloud command.
Which next hop should you choose?

**A.** The default internet gateway

**B.** The IP address of the Cloud VPN gateway

**C.** The name and region of the Cloud VPN tunnel

**D.** The IP address of the instance on the remote side of the VPN tunnel

**Respuesta de la fuente:** C

**Explicación:** In Google Cloud, when creating a static route via gcloud for traffic to traverse a Classic (policy-based) VPN, the next hop is specified by referencing the specific Cloud VPN tunnel resource.

The command flags --next-hop-vpn-tunnel and --next-hop-vpn-tunnel-region require the name and region of the tunnel, making option C technically correct for the gcloud syntax.

Option B is incorrect because the gateway IP address is not used as the next hop identifier in gcloud route creation commands; instead, the specific tunnel resource is designated to ensure traffic enters the correct encrypted path.

## Pregunta 59

Contexto: [topics:725](#topics-725)
You need to enable Cloud CDN for all the objects inside a storage bucket. You want to ensure that all the object in the storage bucket can be served by the CDN.
What should you do in the GCP Console?

**A.** Create a new cloud storage bucket, and then enable Cloud CDN on it.

**B.** Create a new TCP load balancer, select the storage bucket as a backend, and then enable Cloud CDN on the backend.

**C.** Create a new SSL proxy load balancer, select the storage bucket as a backend, and then enable Cloud CDN on the backend.

**D.** Create a new HTTP load balancer, select the storage bucket as a backend, enable Cloud CDN on the backend, and make sure each object inside the storage bucket is shared publicly.

**Respuesta de la fuente:** D

**Explicación:** Cloud CDN requires an HTTP(S) load balancer to act as the point of presence for caching content from a Cloud Storage bucket; TCP and SSL proxy load balancers do not support Cloud CDN.
Additionally, while the bucket itself can be private, the individual objects must have public read permissions (or use Signed URLs/CORS configurations) for the CDN to cache and serve them to end users.
Option A is incorrect because you cannot enable Cloud CDN directly on a bucket; it must be served through a load balancer backend.

## Pregunta 60

Contexto: [topics:725](#topics-725)
Your company's Google Cloud-deployed, streaming application supports multiple languages. The application development team has asked you how they should support splitting audio and video traffic to different backend Google Cloud storage buckets. They want to use URL maps and minimize operational overhead. They are currently using the following directory structure:
/fr/video
/en/video
/es/video
/../video
/fr/audio
/en/audio
/es/audio
/../audio
Which solution should you recommend?

**A.** Rearrange the directory structure, create a URL map and leverage a path rule such as /video/* and /audio/*.

**B.** Rearrange the directory structure, create DNS hostname entries for video and audio and leverage a path rule such as /video/* and /audio/*.

**C.** Leave the directory structure as-is, create a URL map and leverage a path rule such as \/[a-z]{2}\/video and \/[a-z]{2}\/audio.

**D.** Leave the directory structure as-is, create a URL map and leverage a path rule such as /*/video and /*/audio.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Google Cloud URL maps only support wildcard characters (*) at the end of a path rule (e.g., /video/*), not in the middle.
Option C is incorrect because URL map path rules do not support regular expressions like [a-z]{2}.
Option D is invalid because it places the wildcard before the final slash, violating the syntax constraint that the wildcard must follow the last forward slash.

## Pregunta 61

Contexto: [topics:725](#topics-725)
You want to establish a dedicated connection to Google that can access Cloud SQL via a public IP address and that does not require a third-party service provider.
Which connection type should you choose?

**A.** Carrier Peering

**B.** Direct Peering

**C.** Dedicated Interconnect

**D.** Partner Interconnect

**Respuesta de la fuente:** B

**Explicación:** Direct Peering is the correct choice because it enables connectivity to Google services via public IP addresses without requiring a third-party service provider. Dedicated Interconnect (C) requires private IP addressing and typically involves physical cross-connects, while Partner Interconnect (D) relies on a Cloud Interconnect partner, violating the 'no third-party' constraint.

## Pregunta 62

Contexto: [topics:725](#topics-725)
You are configuring a new instance of Cloud Router in your Organization's Google Cloud environment to allow connection across a new Dedicated Interconnect to your data center Sales, Marketing, and IT each have a service project attached to the Organization's host project.
Where should you create the Cloud Router instance?

**A.** VPC network in all projects

**B.** VPC network in the IT Project

**C.** VPC network in the Host Project

**D.** VPC network in the Sales, Marketing, and IT Projects

**Respuesta de la fuente:** C

**Explicación:** In a Shared VPC architecture, infrastructure resources like Cloud Routers and Dedicated Interconnects must be created in the Host project to centralize management and enable connectivity for all attached Service projects. Creating them in individual service projects (A, B, or D) violates the separation of duties model where networking is centralized in the host.

## Pregunta 63

Contexto: [topics:725](#topics-725)
You created a new VPC for your development team. You want to allow access to the resources in this VPC via SSH only.
How should you configure your firewall rules?

**A.** Create two firewall rules: one to block all traffic with priority 0, and another to allow port 22 with priority 1000.

**B.** Create two firewall rules: one to block all traffic with priority 65536, and another to allow port 3389 with priority 1000.

**C.** Create a single firewall rule to allow port 22 with priority 1000.

**D.** Create a single firewall rule to allow port 3389 with priority 1000.

**Respuesta de la fuente:** C

**Explicación:** In Google Cloud VPC networks, ingress traffic is denied by default, so you only need to create a firewall rule that explicitly allows SSH (TCP port 22).
Option A is incorrect because creating an explicit deny-all rule is redundant when the default network behavior already denies all ingress traffic not matched by an allow rule.

## Pregunta 64

Contexto: [topics:725](#topics-725)
Your on-premises data center has 2 routers connected to your GCP through a VPN on each router. All applications are working correctly; however, all of the traffic is passing across a single VPN instead of being load-balanced across the 2 connections as desired.
During troubleshooting you find:
"¢ Each on-premises router is configured with the same ASN.
"¢ Each on-premises router is configured with the same routes and priorities.
"¢ Both on-premises routers are configured with a VPN connected to a single Cloud Router.
"¢ The VPN logs have no-proposal-chosen lines when the VPNs are connecting.
"¢ BGP session is not established between one on-premises router and the Cloud Router.
What is the most likely cause of this problem?

**A.** One of the VPN sessions is configured incorrectly.

**B.** A firewall is blocking the traffic across the second VPN connection.

**C.** You do not have a load balancer to load-balance the network traffic.

**D.** BGP sessions are not established between both on-premises routers and the Cloud Router.

**Respuesta de la fuente:** A

**Explicación:** The "no-proposal-chosen" error in the VPN logs explicitly indicates that IKE negotiation failed due to mismatched cryptographic proposals or settings, confirming a configuration error on one of the tunnels.
Because the IPsec tunnel cannot be established, the dependent BGP session also fails; therefore, the missing BGP session is a symptom of the underlying VPN misconfiguration rather than the root cause.

## Pregunta 65

Contexto: [topics:725](#topics-725)
You need to define an address plan for a future new GKE cluster in your VPC. This will be a VPC native cluster, and the default Pod IP range allocation will be used. You must pre-provision all the needed VPC subnets and their respective IP address ranges before cluster creation. The cluster will initially have a single node, but it will be scaled to a maximum of three nodes if necessary. You want to allocate the minimum number of Pod IP addresses.
Which subnet mask should you use for the Pod IP address range?

**A.** /21

**B.** /22

**C.** /23

**D.** /25

**Respuesta de la fuente:** B

**Explicación:** In GKE VPC-native clusters with default settings, Kubernetes allocates a /24 CIDR block to each node to support up to 110 pods.
Since the cluster scales to a maximum of 3 nodes, you need three separate /24 blocks (3 * 256 addresses = 768 total IPs required).
A /23 subnet provides only 512 addresses, which is insufficient, while a /22 subnet provides 1024 addresses, accommodating the requirement.
Therefore, /22 is the smallest valid subnet mask that meets the capacity needs.

## Pregunta 66

Contexto: [topics:725](#topics-725)
You have created a firewall with rules that only allow traffic over HTTP, HTTPS, and SSH ports. While testing, you specifically try to reach the server over multiple ports and protocols; however, you do not see any denied connections in the firewall logs. You want to resolve the issue.
What should you do?

**A.** Enable logging on the default Deny Any Firewall Rule.

**B.** Enable logging on the VM Instances that receive traffic.

**C.** Create a logging sink forwarding all firewall logs with no filters.

**D.** Create an explicit Deny Any rule and enable logging on the new rule.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because GCP firewall logging specifications explicitly state that you cannot enable logging for the implied deny ingress rules. Therefore, to capture logs for denied traffic, you must create an explicit 'Deny Any' rule and enable logging on it.

Option A is incorrect because the default (implied) deny rule does not support logging configuration.

## Pregunta 67

Contexto: [topics:725](#topics-725)
In your company, two departments with separate GCP projects (code-dev and data-dev) in the same organization need to allow full cross-communication between all of their virtual machines in GCP. Each department has one VPC in its project and wants full control over their network. Neither department intends to recreate its existing computing resources. You want to implement a solution that minimizes cost.
Which two steps should you take? (Choose two.)

**A.** Connect both projects using Cloud VPN.

**B.** Connect the VPCs in project code-dev and data-dev using VPC Network Peering.

**C.** Enable Shared VPC in one project (e. g., code-dev), and make the second project (e. g., data-dev) a service project.

**D.** Enable firewall rules to allow all ingress traffic from all subnets of project code-dev to all instances in project data-dev, and vice versa.

**E.** Create a route in the code-dev project to the destination prefixes in project data-dev and use nexthop as the default gateway, and vice versa.

**Respuesta de la fuente:** B, D

**Explicación:** VPC Network Peering (B) is the optimal choice for cost-effective, low-latency connectivity between VPCs in different projects while maintaining separate network control, whereas Shared VPC (C) requires migrating resources and Cloud VPN (A) incurs higher costs and complexity.
Because VPC peering does not automatically share firewall rules or allow traffic by default, you must explicitly configure ingress firewall rules in both projects to permit traffic from the peer's subnets (D).

## Pregunta 68

Contexto: [topics:725](#topics-725)
You need to create a GKE cluster in an existing VPC that is accessible from on-premises. You must meet the following requirements:
✑ IP ranges for pods and services must be as small as possible.
✑ The nodes and the master must not be reachable from the internet.
✑ You must be able to use kubectl commands from on-premises subnets to manage the cluster.
How should you create the GKE cluster?

**A.** "¢ Create a private cluster that uses VPC advanced routes. "¢ Set the pod and service ranges as /24. "¢ Set up a network proxy to access the master.

**B.** "¢ Create a VPC-native GKE cluster using GKE-managed IP ranges. "¢ Set the pod IP range as /21 and service IP range as /24. "¢ Set up a network proxy to access the master.

**C.** "¢ Create a VPC-native GKE cluster using user-managed IP ranges. "¢ Enable a GKE cluster network policy, set the pod and service ranges as /24. "¢ Set up a network proxy to access the master. "¢ Enable master authorized networks.

**D.** "¢ Create a VPC-native GKE cluster using user-managed IP ranges. "¢ Enable privateEndpoint on the cluster master. "¢ Set the pod and service ranges as /24. "¢ Set up a network proxy to access the master. "¢ Enable master authorized networks.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it satisfies all requirements: VPC-native with user-managed ranges allows precise /24 CIDR blocks for minimal IP usage, while enabling the privateEndpoint and Master Authorized Networks (MAN) ensures the master is isolated from the public internet yet accessible via on-premises connections through a network proxy. Option C is incorrect because it omits the privateEndpoint configuration; without a private endpoint, the master would have a public IP (even if restricted by MAN), failing the requirement that nodes and masters must not be reachable from the internet.

## Pregunta 69

Contexto: [topics:725](#topics-725)
You are creating an instance group and need to create a new health check for HTTP(s) load balancing.
Which two methods can you use to accomplish this? (Choose two.)

**A.** Create a new health check using the gcloud command line tool.

**B.** Create a new health check using the VPC Network section in the GCP Console.

**C.** Create a new health check, or select an existing one, when you complete the load balancer's backend configuration in the GCP Console.

**D.** Create a new legacy health check using the gcloud command line tool.

**E.** Create a new legacy health check using the Health checks section in the GCP Console.

**Respuesta de la fuente:** A, C

**Explicación:** For HTTP(S) load balancing, you should use standard health checks rather than legacy ones, which are reserved for target pool-based Network LBs. Therefore, options D and E are incorrect because they specify creating legacy health checks. Option A is correct because the `gcloud` CLI allows the creation of standard health checks via `compute health-checks create`. Option C is correct because the GCP Console workflow for configuring load balancer backends explicitly allows you to create or select a health check during that specific configuration step.

## Pregunta 70

Contexto: [topics:725](#topics-725)
You are in the early stages of planning a migration to GCP. You want to test the functionality of your hybrid cloud design before you start to implement it in production. The design includes services running on a Compute Engine Virtual Machine instance that need to communicate to on-premises servers using private
IP addresses. The on-premises servers have connectivity to the internet, but you have not yet established any Cloud Interconnect connections. You want to choose the lowest cost method of enabling connectivity between your instance and on-premises servers and complete the test in 24 hours.
Which connectivity method should you choose?

**A.** Cloud VPN

**B.** 50-Mbps Partner VLAN attachment

**C.** Dedicated Interconnect with a single VLAN attachment

**D.** Dedicated Interconnect, but don't provision any VLAN attachments

**Respuesta de la fuente:** A

**Explicación:** Cloud VPN is the correct choice because it can be provisioned rapidly within hours to meet the 24-hour deadline and operates at a significantly lower cost for temporary testing compared to interconnect options. Dedicated or Partner Interconnects require physical provisioning and circuit establishment, which typically take weeks or months, making them unsuitable for a quick test.

## Pregunta 71

Contexto: [topics:725](#topics-725)
You want to implement an IPSec tunnel between your on-premises network and a VPC via Cloud VPN. You need to restrict reachability over the tunnel to specific local subnets, and you do not have a device capable of speaking Border Gateway Protocol (BGP).
Which routing option should you choose?

**A.** Dynamic routing using Cloud Router

**B.** Route-based routing using default traffic selectors

**C.** Policy-based routing using a custom local traffic selector

**D.** Policy-based routing using the default local traffic selector

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because policy-based routing allows you to define custom local traffic selectors (specific IP ranges) to restrict tunnel reachability, which satisfies the requirement without needing a BGP-capable device.
Option A is incorrect because dynamic routing requires BGP support on both sides, which is explicitly unavailable in this scenario.

## Pregunta 72

Contexto: [topics:725](#topics-725)
You have enabled HTTP(S) load balancing for your application, and your application developers have reported that HTTP(S) requests are not being distributed correctly to your Compute Engine Virtual Machine instances. You want to find data about how the request are being distributed.
Which two methods can accomplish this? (Choose two.)

**A.** On the Load Balancer details page of the GCP Console, click on the Monitoring tab, select your backend service, and look at the graphs.

**B.** In Stackdriver Error Reporting, look for any unacknowledged errors for the Cloud Load Balancers service.

**C.** In Stackdriver Monitoring, select Resources > Metrics Explorer and search for https/request_bytes_count metric.

**D.** In Stackdriver Monitoring, select Resources > Google Cloud Load Balancers and review the Key Metrics graphs in the dashboard.

**E.** In Stackdriver Monitoring, create a new dashboard and track the https/backend_request_count metric for the load balancer.

**Respuesta de la fuente:** A, E

**Explicación:** Option A is correct because the Load Balancer details page provides pre-built graphs for backend services, directly visualizing request distribution and health. Option E is correct because the https/backend_request_count metric specifically tracks requests forwarded to backends, allowing you to verify if traffic is being distributed as expected across instances.

Option C is incorrect because request_bytes_count measures data volume, not request count or distribution. Option D is incorrect because Stackdriver Monitoring does not have a 'Google Cloud Load Balancers' resource type; metrics are accessed via the Metrics Explorer or predefined dashboards.

## Pregunta 73

Contexto: [topics:725](#topics-725)
You want to use Partner Interconnect to connect your on-premises network with your VPC. You already have an Interconnect partner.
What should you first?

**A.** Log in to your partner's portal and request the VLAN attachment there.

**B.** Ask your Interconnect partner to provision a physical connection to Google.

**C.** Create a Partner Interconnect type VLAN attachment in the GCP Console and retrieve the pairing key.

**D.** Run gcloud compute interconnect attachments partner update <attachment> / --region <region> --admin-enabled.

**Respuesta de la fuente:** C

**Explicación:** The correct first step in the Partner Interconnect provisioning process is to create a VLAN attachment in the GCP Console, which generates a unique pairing key required for the service provider to link their resources to your VPC.
Option B is incorrect because, by definition, an Interconnect partner already maintains existing physical connections to Google's network edge; you do not need to request new physical provisioning from them.

## Pregunta 74

Contexto: [topics:725](#topics-725)
You need to centralize the Identity and Access Management permissions and email distribution for the WebServices Team as efficiently as possible.
What should you do?

**A.** Create a Google Group for the WebServices Team.

**B.** Create a G Suite Domain for the WebServices Team.

**C.** Create a new Cloud Identity Domain for the WebServices Team.

**D.** Create a new Custom Role for all members of the WebServices Team.

**Respuesta de la fuente:** A

**Explicación:** Creating a Google Group (Choice A) is the most efficient solution because it serves as a single identity that can be assigned IAM roles and used for email distribution, satisfying both requirements simultaneously.

A Custom Role (Choice D) manages permissions but does not handle email distribution, while creating separate Domains (Choices B and C) is an unnecessarily complex administrative overhead for a single team within an existing organization.

## Pregunta 75

Contexto: [topics:725](#topics-725)
You are using the gcloud command line tool to create a new custom role in a project by coping a predefined role. You receive this error message:
INVALID_ARGUMENT: Permission resourcemanager.projects.list is not valid
What should you do?

**A.** Add the resourcemanager.projects.get permission, and try again.

**B.** Try again with a different role with a new name but the same permissions.

**C.** Remove the resourcemanager.projects.list permission, and try again.

**D.** Add the resourcemanager.projects.setIamPolicy permission, and try again.

**Respuesta de la fuente:** C

**Explicación:** The error occurs because `resourcemanager.projects.list` is an organization-level permission that cannot be included in a project-level custom role. To resolve the `INVALID_ARGUMENT` error, you must remove this unsupported permission from the role definition before creation.
Option A is incorrect because adding a different permission does not address the invalid permission already present.

## Pregunta 76

Contexto: [topics:725](#topics-725)
One instance in your VPC is configured to run with a private IP address only. You want to ensure that even if this instance is deleted, its current private IP address will not be automatically assigned to a different instance.
In the GCP Console, what should you do?

**A.** Assign a public IP address to the instance.

**B.** Assign a new reserved internal IP address to the instance.

**C.** Change the instance's current internal IP address to static.

**D.** Add custom metadata to the instance with key internal-address and value reserved.

**Respuesta de la fuente:** C

**Explicación:** To prevent an ephemeral internal IP address from being reassigned after an instance is deleted, you must reserve it as a static internal IP address. In Google Cloud Platform, this is achieved by promoting the current ephemeral IP to a static state while keeping the same address value.
Option B is incorrect because reserving a 'new' address typically implies creating a reservation for a different IP or during initial provisioning, whereas the requirement is to preserve the specific *current* private IP already in use.

## Pregunta 77

Contexto: [topics:725](#topics-725)
After a network change window one of your company's applications stops working. The application uses an on-premises database server that no longer receives any traffic from the application. The database server IP address is 10.2.1.25. You examine the change request, and the only change is that 3 additional VPC subnets were created. The new VPC subnets created are 10.1.0.0/16, 10.2.0.0/16, and 10.3.1.0/24/ The on-premises router is advertising 10.0.0.0/8.
What is the most likely cause of this problem?

**A.** The less specific VPC subnet route is taking priority.

**B.** The more specific VPC subnet route is taking priority.

**C.** The on-premises router is not advertising a route for the database server.

**D.** A cloud firewall rule that blocks traffic to the on-premises database server was created during the change.

**Respuesta de la fuente:** B

**Explicación:** Routing follows the longest-prefix match rule, meaning the most specific route in the table takes precedence over less specific ones. The newly created VPC subnet 10.2.0.0/16 is a more specific route than the on-premises router's advertisement of 10.0.0.0/8, causing traffic destined for 10.2.1.25 to be routed locally within the VPC instead of toward the on-premises database server.

Choice A is incorrect because it incorrectly suggests that the less specific route would take priority, which violates standard routing principles.

## Pregunta 78

Contexto: [topics:725](#topics-725)
You need to create a new VPC network that allows instances to have IP addresses in both the 10.1.1.0/24 network and the 172.16.45.0/24 network.
What should you do?

**A.** Configure global load balancing to point 172.16.45.0/24 to the correct instance.

**B.** Create unique DNS records for each service that sends traffic to the desired IP address.

**C.** Configure an alias-IP range of 172.16.45.0/24 on the virtual instances within the VPC subnet of 10.1.1.0/24.

**D.** Use VPC peering to allow traffic to route between the 10.1.0.0/24 network and the 172.16.45.0/24 network.

**Respuesta de la fuente:** C

**Explicación:** In Google Cloud, to assign multiple IP ranges to a single subnet for instances, you configure the primary range (10.1.1.0/24) and add the secondary range (172.16.45.0/24). You then assign addresses from both ranges as alias IPs on the virtual machine's network interface.
Option D is incorrect because VPC peering connects two separate VPC networks, not multiple IP ranges within a single subnet.

## Pregunta 79

Contexto: [topics:725](#topics-725)
You are deploying a global external TCP load balancing solution and want to preserve the source IP address of the original layer 3 payload.
Which type of load balancer should you use?

**A.** HTTP(S) load balancer

**B.** Network load balancer

**C.** Internal load balancer

**D.** TCP/SSL proxy load balancer

**Respuesta de la fuente:** D

**Explicación:** The question specifies a **global** external TCP load balancing solution. In Google Cloud, Network Load Balancers (Option B) are regional only and cannot span multiple regions globally, making them incorrect for this specific requirement.

TCP/SSL Proxy Load Balancers (Option D) are the only type that provides global reachability for Layer 4 traffic. Although they do not preserve the source IP by default, they support the PROXY protocol feature to preserve the original client IP address, satisfying the prompt's condition to 'want to preserve' it.

## Pregunta 80

Contexto: [topics:725](#topics-725)
Your company has a single Virtual Private Cloud (VPC) network deployed in Google Cloud with access from your on-premises network using Cloud Interconnect. You must configure access only to Google APIs and services that are supported by VPC Service Controls through hybrid connectivity with a service level agreement (SLA) in place. What should you do?

**A.** Configure the existing Cloud Routers to advertise the Google API's public virtual IP addresses.

**B.** Use Private Google Access for on-premises hosts with restricted.googleapis.com virtual IP addresses.

**C.** Configure the existing Cloud Routers to advertise a default route, and use Cloud NAT to translate traffic from your on-premises network.

**D.** Add Direct Peering links, and use them for connectivity to Google APIs that use public virtual IP addresses.

**Respuesta de la fuente:** B

**Explicación:** The question requires hybrid connectivity (on-premises to GCP) for Google APIs using VPC Service Controls. The specific feature designed to allow on-premises networks connected via Cloud Interconnect or VPN to access Google APIs over private IP addresses (specifically the restricted.googleapis.com range) is Private Google Access configured for hybrid connectivity. This ensures traffic stays within the Google network, satisfying security and service control requirements without traversing the public internet. Option D is incorrect because Direct Peering is for general internet/GCP egress and does not inherently provide the private IP path to APIs required by VPC Service Controls in this context; Option A is incorrect as advertising public IPs doesn't enable the private access mechanism.

## Pregunta 81

Contexto: [topics:725](#topics-725)
Your company's security team tends to use managed services when possible. You need to build a dashboard to show the number of deny hits that occur against configured firewall rules without increasing operational overhead. What should you do?

**A.** Configure Firewall Rules Logging. Use Firewall Insights to display the number of hits.

**B.** Configure Firewall Rules Logging. View the logs in Cloud Logging, and create a custom dashboard in Cloud Monitoring to display the number of hits.

**C.** Configure a firewall appliance from the Google Cloud Marketplace. Route all traffic through this appliance, and apply the firewall rules at this layer. Use the firewall appliance to display the number of hits.

**D.** Configure Packet Mirroring on the VPC. Apply a filter with an IP address list of the Denied Firewall rules. Configure an intrusion detection system (IDS) appliance as the receiver to display the number of hits.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 82

Contexto: [topics:725](#topics-725)
You are configuring your Google Cloud environment to connect to your on-premises network. Your configuration must be able to reach Cloud Storage APIs and your Google Kubernetes Engine nodes across your private Cloud Interconnect network. You have already configured a Cloud Router with your Interconnect VLAN attachments. You now need to set up the appropriate router advertisement configuration on the Cloud Router. What should you do?

**A.** Configure the route advertisement to the default setting.

**B.** On the on-premises router, configure a static route for the storage API virtual IP address which points to the Cloud Router's link-local IP address.

**C.** Configure the route advertisement to the custom setting, and manually add prefix 199.36.153.8/30 to the list of advertisements. Leave all other options as their default settings.

**D.** Configure the route advertisement to the custom setting, and manually add prefix 199.36.153.8/30 to the list of advertisements. Advertise all visible subnets to the Cloud Router.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Private Google Access requires the specific virtual IP prefix (199.36.153.8/30) to be advertised, while communicating with GKE nodes requires that all internal VPC subnets are visible to the on-premises network via BGP.
Option C is incorrect because it only advertises the private Google access prefix and excludes the necessary GKE subnet routes, preventing connectivity to the cluster nodes.

## Pregunta 83

Contexto: [topics:725](#topics-725)
You are configuring load balancing for a standard three-tier (web, application, and database) application. You have configured an external HTTP(S) load balancer for the web servers. You need to configure load balancing for the application tier of servers. What should you do?

**A.** Configure a forwarding rule on the existing load balancer for the application tier.

**B.** Configure equal cost multi-path routing on the application servers.

**C.** Configure a new internal HTTP(S) load balancer for the application tier.

**D.** Configure a URL map on the existing load balancer to route traffic to the application tier.

**Respuesta de la fuente:** C

**Explicación:** In a standard three-tier architecture on Google Cloud, the application tier is internal and should be protected from direct external exposure.
An Internal HTTP(S) Load Balancer is designed specifically to distribute traffic among instances within a VPC network, keeping communication between the web and application tiers private and secure.
Option A is incorrect because forwarding rules are global resources tied to specific backend services; adding one for a different tier on an external LB would mix traffic types and violate security best practices.

## Pregunta 84

Contexto: [topics:725](#topics-725)
Your organization has a new security policy that requires you to monitor all egress traffic payloads from your virtual machines in region us-west2. You deployed an intrusion detection system (IDS) virtual appliance in the same region to meet the new policy. You now need to integrate the IDS into the environment to monitor all egress traffic payloads from us-west2. What should you do?

**A.** Enable firewall logging, and forward all filtered egress firewall logs to the IDS.

**B.** Enable VPC Flow Logs. Create a sink in Cloud Logging to send filtered egress VPC Flow Logs to the IDS.

**C.** Create an internal TCP/UDP load balancer for Packet Mirroring, and add a packet mirroring policy filter for egress traffic.

**D.** Create an internal HTTP(S) load balancer for Packet Mirroring, and add a packet mirroring policy filter for egress traffic.

**Respuesta de la fuente:** C

**Explicación:** To monitor traffic payloads, the IDS requires actual network packets, which are provided by Packet Mirroring rather than summary logs like VPC Flow Logs or Firewall logs. Since egress traffic encompasses all TCP/UDP protocols (not just HTTP/S), an internal TCP/UDP load balancer is the correct target to handle this broad range of mirrored traffic efficiently.

## Pregunta 85

Contexto: [topics:725](#topics-725)
You are developing an HTTP API hosted on a Compute Engine virtual machine instance that must be invoked only by multiple clients within the same Virtual Private Cloud (VPC). You want clients to be able to get the IP address of the service. What should you do?

**A.** Reserve a static external IP address and assign it to an HTTP(S) load balancing service's forwarding rule. Clients should use this IP address to connect to the service.

**B.** Ensure that clients use Compute Engine internal DNS by connecting to the instance name with the url https://[INSTANCE_NAME].[ZONE].c.[PROJECT_ID].internal/.

**C.** Reserve a static external IP address and assign it to an HTTP(S) load balancing service's forwarding rule. Then, define an A record in Cloud DNS. Clients should use the name of the A record to connect to the service.

**D.** Ensure that clients use Compute Engine internal DNS by connecting to the instance name with the url https://[API_NAME]/[API_VERSION]/.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it utilizes Compute Engine's internal DNS service (ending in .internal), which allows instances within the same VPC to resolve each other by name without exposing an external IP address. This directly satisfies the requirement for internal-only access while providing clients with a resolvable endpoint to obtain the service's IP.

Options A and C are incorrect because they involve assigning static external IP addresses, which violates the security constraint of restricting access exclusively to clients within the same VPC.

## Pregunta 86

Contexto: [topics:725](#topics-725)
You recently deployed Cloud VPN to connect your on-premises data canter to Google Cloud. You need to monitor the usage of this VPN and set up alerts in case traffic exceeds the maximum allowed. You need to be able to quickly decide whether to add extra links or move to a Dedicated Interconnect. What should you do?

**A.** In the Network Intelligence Canter, check for the number of packet drops on the VPN.

**B.** In the Google Cloud Console, use Monitoring Query Language to create a custom alert for bandwidth utilization.

**C.** In the Monitoring section of the Google Cloud Console, use the Dashboard section to select a default dashboard for VPN usage.

**D.** In the VPN section of the Google Cloud Console, select the VPN under hybrid connectivity, and then select monitoring to display utilization on the dashboard.

**Respuesta de la fuente:** B

**Explicación:** The question explicitly requires setting up alerts for bandwidth utilization to trigger capacity decisions. Option B is correct because Monitoring Query Language (MQL) is the standard tool in Cloud Monitoring for creating custom alerting policies based on metrics like bytes per second.
Option C is incorrect because viewing a default dashboard provides passive visibility but does not actively generate alerts when thresholds are exceeded.

## Pregunta 87

Contexto: [topics:725](#topics-725)
You have applications running in the us-west1 and us-east1 regions. You want to build a highly available VPN that provides 99.99% availability to connect your applications from your project to the cloud services provided by your partner's project while minimizing the amount of infrastructure required. Your partner's services are also in the us-west1 and us-east1 regions. You want to implement the simplest solution. What should you do?

**A.** Create one Cloud Router and one HA VPN gateway in each region of your VPC and your partner's VPC. Connect your VPN gateways to the partner's gateways. Enable global dynamic routing in each VPC.

**B.** Create one Cloud Router and one HA VPN gateway in the us-west1 region of your VPC. Create one OpenVPN Access Server in each region of your partner's VPC. Connect your VPN gateway to your partner's servers.

**C.** Create one OpenVPN Access Server in each region of your VPC and your partner's VPConnect your servers to the partner's servers.

**D.** Create one Cloud Router and one HA VPN gateway in the us-west1 region of your VPC and your partner's VPC. Connect your VPN gateways to the partner's gateways with a pair of tunnels. Enable global dynamic routing in each VPC.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because a single HA VPN gateway with two tunnels provides the required 99.99% availability SLA while minimizing infrastructure complexity compared to multi-region deployments.
Option A is incorrect as it suggests deploying gateways in both regions, which increases cost and management overhead unnecessarily for this specific availability target.
The 'simplest solution' requirement favors a single regional HA VPN setup over the redundant regional deployment implied in A.

## Pregunta 88

Contexto: [topics:725](#topics-725)
You need to create the network infrastructure to deploy a highly available web application in the us-east1 and us-west1 regions. The application runs on Compute Engine instances, and it does not require the use of a database. You want to follow Google-recommended practices. What should you do?

**A.** Create one VPC with one subnet in each region.
Create a regional network load balancer in each region with a static IP address.
Enable Cloud CDN on the load balancers.
Create an A record in Cloud DNS with both IP addresses for the load balancers.

**B.** Create one VPC with one subnet in each region.
Create a global load balancer with a static IP address.
Enable Cloud CDN and Google Cloud Armor on the load balancer.
Create an A record using the IP address of the load balancer in Cloud DNS.

**C.** Create one VPC in each region, and peer both VPCs.
Create a global load balancer.
Enable Cloud CDN on the load balancer.
Create a CNAME for the load balancer in Cloud DNS.

**D.** Create one VPC with one subnet in each region.
Create an HTTP(S) load balancer with a static IP address.
Choose the standard tier for the network.
Enable Cloud CDN on the load balancer.
Create a CNAME record using the load balancer’s IP address in Cloud DNS.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it uses a Global Application Load Balancer, which is required to distribute traffic across multiple regions (us-east1 and us-west1) with a single anycast IP. Enabling Cloud CDN and Google Cloud Armor on this global load balancer follows recommended practices for performance and security.

Option A is incorrect because Regional Network Load Balancers only serve traffic within their specific region, failing the multi-region high-availability requirement. Option D is incorrect because it specifies the Standard network tier, which restricts load balancing to regional scope rather than providing the global connectivity needed here.

## Pregunta 89

Contexto: [topics:725](#topics-725)
You are the network administrator responsible for hybrid connectivity at your organization. Your developer team wants to use Cloud SQL in the us-west1 region in your Shared VPC. You configured a Dedicated Interconnect connection and a Cloud Router in us-west1, and the connectivity between your Shared VPC and on-premises data center is working as expected. You just created the private services access connection required for Cloud SQL using the reserved IP address range and default settings. However, your developers cannot access the Cloud SQL instance from on-premises. You want to resolve the issue. What should you do?

**A.** 1. Modify the VPC Network Peering connection used for Cloud SQL, and enable the import and export of routes.
2. Create a custom route advertisement in your Cloud Router to advertise the Cloud SQL IP address range.

**B.** 1. Change the VPC routing mode to global.
2. Create a custom route advertisement in your Cloud Router to advertise the Cloud SQL IP address range.

**C.** 1. Create an additional Cloud Router in us-west2.
2. Create a new Border Gateway Protocol (BGP) peering connection to your on-premises data center.
3. Modify the VPC Network Peering connection used for Cloud SQL, and enable the import and export of routes.

**D.** 1. Change the VPC routing mode to global.
2. Modify the VPC Network Peering connection used for Cloud SQL, and enable the import and export of routes.

**Respuesta de la fuente:** A

**Explicación:** Private Services Access (PSA) establishes a VPC peering connection between your consumer network and Google's service producer network. By default, this peering only exchanges subnet routes; custom or dynamic routes from your on-premises interconnect are not shared with the producer network, causing connectivity failures.
Option A correctly enables the import/export of these custom routes on the peering connection and ensures the Cloud Router advertises the specific Cloud SQL IP range to the on-premises site via BGP.
Option B is incorrect because simply changing the VPC routing mode does not force the propagation of dynamic/custom routes into the Google-managed service network through the PSA peering link.

## Pregunta 90

Contexto: [topics:725](#topics-725)
Your company has separate Virtual Private Cloud (VPC) networks in a single region for two departments: Sales and Finance. The Sales department's VPC network already has connectivity to on-premises locations using HA VPN, and you have confirmed that the subnet ranges do not overlap. You plan to peer both VPC networks to use the same HA tunnels for on-premises connectivity, while providing internet connectivity for the Google Cloud workloads through Cloud NAT. Internet access from the on-premises locations should not flow through Google Cloud. You need to propagate all routes between the Finance department and on-premises locations. What should you do?

**A.** Peer the two VPCs, and use the default configuration for the Cloud Routers.

**B.** Peer the two VPCs, and use Cloud Router’s custom route advertisements to announce the peered VPC network ranges to the on-premises locations.

**C.** Peer the two VPCs. Configure VPC Network Peering to export custom routes from Sales and import custom routes on Finance's VPC network. Use Cloud Router’s custom route advertisements to announce a default route to the on-premises locations.

**D.** Peer the two VPCs. Configure VPC Network Peering to export custom routes from Sales and import custom routes on Finance's VPC network. Use Cloud Router’s custom route advertisements to announce the peered VPC network ranges to the on-premises locations.

**Respuesta de la fuente:** D

**Explicación:** By default, Cloud Routers do not propagate VPC Network Peering routes to connected VPN tunnels.
Therefore, you must explicitly configure the Cloud Router in the Sales VPC to use custom route advertisements to announce the Finance VPC's subnet ranges to on-premises.
Additionally, ensuring that custom routes are exported from Sales and imported by Finance guarantees proper route propagation between the peered networks for internal connectivity.

## Pregunta 91

Contexto: [topics:725](#topics-725)
You recently noticed a recurring daily spike in network usage in your Google Cloud project. You need to identify the virtual machine (VM) instances and type of traffic causing the spike in traffic utilization while minimizing the cost and management overhead required. What should you do?

**A.** Enable VPC Flow Logs and send the output to BigQuery for analysis.

**B.** Enable Firewall Rules Logging for all allowed traffic and send the output to BigQuery for analysis.

**C.** Configure Packet Mirroring to send all traffic to a VM. Use Wireshark on the VM to identity traffic utilization for each VM in the VPC.

**D.** Deploy a third-party network appliance and configure it as the default gateway. Use the third-party network appliance to identify users with high network traffic.

**Respuesta de la fuente:** A

**Explicación:** VPC Flow Logs are the native Google Cloud solution for monitoring network traffic flow metadata at scale without requiring additional infrastructure. Sending logs to BigQuery allows for efficient, SQL-based analysis of traffic patterns per VM with minimal management overhead.
Option B is incorrect because firewall logs only capture packets matching specific rules and do not provide comprehensive traffic visibility. Options C and D involve deploying and managing additional VMs or third-party appliances, which significantly increases cost and operational complexity.

## Pregunta 92

Contexto: [topics:725](#topics-725)
You need to enable Private Google Access for use by some subnets within your Virtual Private Cloud (VPC). Your security team set up the VPC to send all internet-bound traffic back to the on- premises data center for inspection before egressing to the internet, and is also implementing VPC Service Controls in the environment for API-level security control. You have already enabled the subnets for Private Google Access. What configuration changes should you make to enable Private Google Access while adhering to your security team’s requirements?

**A.** 1. Create a private DNS zone with a CNAME record for *.googleapis.com to restricted.googleapis.com, with an A record pointing to Google's restricted API address range.
2. Create a custom route that points Google's restricted API address range to the default internet gateway as the next hop.

**B.** 1. Create a private DNS zone with a CNAME record for *.googleapis.com to restricted.googleapis.com, with an A record pointing to Google's restricted API address range.
2. Change the custom route that points the default route (0/0) to the default internet gateway as the next hop.

**C.** 1. Create a private DNS zone with a CNAME record for *.googleapis.com to private.googleapis.com, with an A record painting to Google's private AP address range.
2. Change the custom route that points the default route (0/0) to the default internet gateway as the next hop.

**D.** 1. Create a private DNS zone with a CNAME record for *.googleapis.com to private.googleapis.com, with an A record pointing to Google's private API address range.
2. Create a custom route that points Google's private API address range to the default internet gateway as the next hop.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because VPC Service Controls require using the `restricted.googleapis.com` domain and its specific IP range (199.36.153.4/30) to ensure API traffic is subject to security policies, unlike the standard private endpoint which may bypass these controls for certain services. Additionally, you must create a custom route pointing this restricted IP range to the default internet gateway as the next hop; this ensures that while DNS resolves to the internal Google network, the actual egress packets are routed via the gateway where they can be intercepted and inspected by the on-premises security appliance before leaving GCP. Option B is incorrect because changing the default 0/0 route would disrupt general internet connectivity and does not specifically target the API traffic required for VPC-SC compliance.

## Pregunta 93

Contexto: [topics:725](#topics-725)
You have deployed an HTTP(s) load balancer, but health checks to port 80 on the Compute Engine virtual machine instance are failing, and no traffic is sent to your instances. You want to resolve the problem. Which commands should you run?

**A.** gcloud compute instances add-access-config instance-1

**B.** gcloud compute firewall-rules create allow-lb --network load-balancer --allow tcp --destination-ranges 130.211.0.0/22,35.191.0.0/16 --direction EGRESS

**C.** gcloud compute firewall-rules create allow-lb --network load-balancer --allow tcp --source-ranges 130.211.0.0/22,35.191.0.0/16 --direction INGRESS

**D.** gcloud compute health-checks update http health-check --unhealthy-threshold 10

**Respuesta de la fuente:** C

**Explicación:** Health checks from Google Cloud load balancers originate from specific IP ranges (130.211.0.0/22 and 35.191.0.0/16). To allow these checks to reach the backend instances, you must create an INGRESS firewall rule that permits traffic from these source ranges on the required ports.
Option B is incorrect because it specifies EGRESS direction and destination ranges, which blocks outbound traffic from the VM rather than allowing inbound health check traffic.

## Pregunta 94

Contexto: [topics:725](#topics-725)
You deployed a hub-and-spoke architecture in your Google Cloud environment that uses VPC Network Peering to connect the spokes to the hub. For security reasons, you deployed a private Google Kubernetes Engine (GKE) cluster in one of the spoke projects with a private endpoint for the control plane. You configured authorized networks to be the subnet range where the GKE nodes are deployed. When you attempt to reach the GKE control plane from a different spoke project, you cannot access it. You need to allow access to the GKE control plane from the other spoke projects. What should you do?

**A.** Add a firewall rule that allows port 443 from the other spoke projects.

**B.** Enable Private Google Access on the subnet where the GKE nodes are deployed.

**C.** Configure the authorized networks to be the subnet ranges of the other spoke projects.

**D.** Deploy a proxy in the spoke project where the GKE nodes are deployed and connect to the control plane through the proxy.

**Respuesta de la fuente:** D

**Explicación:** VPC Network Peering is non-transitive, meaning traffic cannot flow directly between two spoke VPCs via the hub. Therefore, IP addresses in other spokes are not reachable directly and cannot be added to authorized networks (making C invalid). Deploying a proxy within the authorized subnet of the target spoke allows external spokes to route requests through this local entry point to reach the private control plane securely.

## Pregunta 95

Contexto: [topics:725](#topics-725)
You recently deployed your application in Google Cloud. You need to verify your Google Cloud network configuration before deploying your on-premises workloads. You want to confirm that your Google Cloud network configuration allows traffic to flow from your cloud resources to your on- premises network. This validation should also analyze and diagnose potential failure points in your Google Cloud network configurations without sending any data plane test traffic. What should you do?

**A.** Use Network Intelligence Center's Connectivity Tests.

**B.** Enable Packet Mirroring on your application and send test traffic.

**C.** Use Network Intelligence Center's Network Topology visualizations.

**D.** Enable VPC Flow Logs and send test traffic.

**Respuesta de la fuente:** A

**Explicación:** The requirement explicitly states that the validation must occur "without sending any data plane test traffic." Network Intelligence Center's Connectivity Tests (Option A) perform control-plane simulation to analyze network configurations and predict reachability without generating live traffic, satisfying this constraint. Options B and D are incorrect because they involve generating or observing actual data plane traffic. Option C is incorrect because Topology visualizations provide a structural overview of resources but do not actively diagnose path-specific failure points or simulate traffic flow.

## Pregunta 96

Contexto: [topics:725](#topics-725)
In your Google Cloud organization, you have two folders: Dev and Prod. You want a scalable and consistent way to enforce the following firewall rules for all virtual machines (VMs) with minimal cost:

•	Port 8080 should always be open for VMs in the projects in the Dev folder.
•	Any traffic to port 8080 should be denied for all VMs in your projects in the Prod folder.

What should you do?

**A.** Create and associate a firewall policy with the Dev folder with a rule to open port 8080. Create and associate a firewall policy with the Prod folder with a rule to deny traffic to port 8080.

**B.** Create a Shared VPC for the Dev projects and a Shared VPC for the Prod projects. Create a VPC firewall rule to open port 8080 in the Shared VPC for Dev. Create a firewall rule to deny traffic to port 8080 in the Shared VPC for Prod. Deploy VMs to those Shared VPCs.

**C.** In all VPCs for the Dev projects, create a VPC firewall rule to open port 8080. In all VPCs for the Prod projects, create a VPC firewall rule to deny traffic to port 8080.

**D.** Use Anthos Config Connector to enforce a security policy to open port 8080 on the Dev VMs and deny traffic to port 8080 on the Prod VMs.

**Respuesta de la fuente:** A

**Explicación:** Hierarchical firewall policies allow you to attach network-level security rules directly to organization or folder nodes, ensuring they propagate consistently to all descendant projects and VPC networks.
This approach is scalable and cost-effective because it avoids the manual overhead of managing individual VPC firewall rules in every project (Option C) or the architectural complexity and potential costs of Shared VPCs (Option B).
Option A correctly leverages the resource hierarchy to enforce distinct policies for Dev (allow port 8080) and Prod (deny port 8080) with minimal administrative effort.

## Pregunta 97

Contexto: [topics:725](#topics-725)
You need to configure the Border Gateway Protocol (BGP) session for a VPN tunnel you just created between two Google Cloud VPCs, 10.1.0.0/16 and 172.16.0.0/16. You have a Cloud Router (router-1) in the 10.1.0.0/16 network and a second Cloud Router (router-2) in the 172.16.0.0/16 network. Which configuration should you use for the BGP session?

**A.** [Imagen: sin descripción]
Imagen · choices[0].text · sin descripción
![Imagen original](imagenes/b9ac226e1d5432a36598.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Router [BGP Interface Name | Bi
router-t |if-tunnel-a-to-bif-0
router-2 | ittunnel-b-to-a-it-0
[168.254 0.254] 169.254.0.254|
169.254.0.254 | 169.254.0.254
```

**B.** [Imagen: sin descripción]
Imagen · choices[1].text · sin descripción
![Imagen original](imagenes/b7e18d42b5d9fa7e8ec7.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Router |BGP Interface Name BGP IP | BGP Peer IP| Peer ASN
router-t|ittunnel-ato-bit-0 [10.101 |172.160.1 |15052
router-2/it-tunnel-b-to-ai-0 _|172.16.0.1/10.1.0.1 | 18501
```

**C.** [Imagen: sin descripción]
Imagen · choices[2].text · sin descripción
![Imagen original](imagenes/ac278460e24ce5e13bc1.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Router |BGP Interface Name BGP IP | BGP Peer IP_ Peer ASN
router-1 /ittunnel-a-to-bit0 | 169.254.20.1 | 169.254.20.2| 65002
router-2 |if-tunnel-b-to-a-if-0 | 169.254.20.2 | 169.254 20.1 65001
```

**D.** [Imagen: sin descripción]
Imagen · choices[3].text · sin descripción
![Imagen original](imagenes/2d6006ff1623dbd4bc5d.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Router |BGP Interface Name BGP IP | BGP Peer IP| Peer ASN
router-1|if-tunnel-a-to-bt-0 | 172.16.0.254/ 10.1.0.254 | 16552
router-2 |if-tunnel-b-to-a-if-0 | 10.1.0.254 | 172.16.0.254| 16551
```

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google Cloud BGP sessions strictly require link-local IP addresses (from the 169.254.0.0/16 range) and valid Autonomous System Numbers (ASNs).
Specifically, the peer ASN must fall within the private range of 64512-65534 or the public range supported by Cloud Routers, and the BGP interface IPs must be unique link-local addresses in a common /30 subnet.
Options A, B, and D are incorrect because they either use non-link-local IP addresses, duplicate IP addresses for peers, or ASNs outside the allowed valid ranges.

## Pregunta 98

Contexto: [topics:725](#topics-725)
Your company’s on-premises network is connected to a VPC using a Cloud VPN tunnel. You have a static route of 0.0.0.0/0 with the VPN tunnel as its next hop defined in the VPC. All internet bound traffic currently passes through the on-premises network. You configured Cloud NAT to translate the primary IP addresses of Compute Engine instances in one region. Traffic from those instances will now reach the internet directly from their VPC and not from the on-premises network. Traffic from the virtual machines (VMs) is not translating addresses as expected. What should you do?

**A.** Lower the TCP Established Connection Idle Timeout for the NAT gateway.

**B.** Add firewall rules that allow ingress and egress of the external NAT IP address, have a target tag that is on the Compute Engine instances, and have a priority value higher than the priority value of the default route to the VPN gateway.

**C.** Add a default static route to the VPC with the default internet gateway as the next hop, the network tag associated with the Compute Engine instances, and a higher priority than the priority of the default route to the VPN tunnel.

**D.** Increase the default min-ports-per-vm setting for the Cloud NAT gateway.

**Respuesta de la fuente:** C

**Explicación:** The issue is caused by routing precedence: the existing static route (0.0.0.0/0 via VPN) has lower priority (higher numeric value in GCP, but logically 'default' beats specific unless overridden) and captures all internet-bound traffic before Cloud NAT can process it.
Option C creates a more specific default route for tagged instances pointing to the default internet gateway with higher priority, ensuring their egress traffic bypasses the VPN tunnel and is handled by Cloud NAT.
Option B is incorrect because firewall rules filter traffic but do not change routing paths; without changing the route, traffic still goes through the VPN where NAT is not configured.

## Pregunta 99

Contexto: [topics:725](#topics-725)
You are designing a Partner Interconnect hybrid cloud connectivity solution with geo-redundancy across two metropolitan areas. You want to follow Google-recommended practices to set up the following region/metro pairs:

•	(region 1/metro 1)
•	(region 2/metro 2)

What should you do?

**A.** Create a Cloud Router in region 1 with two VLAN attachments connected to metro1-zone1-x.
Create a Cloud Router in region 2 with two VLAN attachments connected to metro1-zone2-x.

**B.** Create a Cloud Router in region 1 with one VLAN attachment connected to metro1-zone1-x.
Create a Cloud Router in region 2 with two VLAN attachments connected to metro2-zone2-x.

**C.** Create a Cloud Router in region 1 with one VLAN attachment connected to metro1-zone2-x.
Create a Cloud Router in region 2 with one VLAN attachment connected to metro2-zone2-x.

**D.** Create a Cloud Router in region 1 with one VLAN attachment connected to metro1-zone1-x and one VLAN attachment connected to metro1-zone2-x.
Create a Cloud Router in region 2 with one VLAN attachment connected to metro2-zone1-x and one VLAN attachment to metro2-zone2-x.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Google Cloud Partner Interconnect best practices for 99.99% availability require four VLAN attachments across two metros and two regions to ensure full geo-redundancy.
Specifically, you need one Cloud Router per region, each attached to both metropolitan areas (one attachment per metro) so that traffic can fail over if an entire metro goes down.
Option A is incorrect because it connects both attachments for Region 1 to Metro 1, meaning Region 1 loses all connectivity if Metro 1 fails, violating the geo-redundancy requirement.

## Pregunta 100

Contexto: [topics:725](#topics-725)
You are designing the network architecture for your organization. Your organization has three developer teams: Web, App, and Database. All of the developer teams require access to Compute Engine instances to perform their critical tasks. You are part of a small network and security team that needs to provide network access to the developers. You need to maintain centralized control over network resources, including subnets, routes, and firewalls. You want to minimize operational overhead. How should you design this topology?

**A.** Configure a host project with a Shared VPC. Create service projects for Web, App, and Database.

**B.** Configure one VPC for Web, one VPC for App, and one VPC for Database. Configure HA VPN between each VPC.

**C.** Configure three Shared VPC host projects, each with a service project: one for Web, one for App, and one for Database.

**D.** Configure one VPC for Web, one VPC for App, and one VPC for Database. Use VPC Network Peering to connect all VPCs in a full mesh.

**Respuesta de la fuente:** A

**Explicación:** Shared VPC allows the centralized network team to manage subnets, routes, and firewalls in a host project while granting specific teams (service projects) access to deploy workloads. This design minimizes operational overhead by avoiding the complexity of managing multiple VPCs or peering configurations, directly satisfying the requirement for centralized control without duplicating network infrastructure.

## Pregunta 101

Contexto: [topics:725](#topics-725)
Your company has 10 separate Virtual Private Cloud (VPC) networks, with one VPC per project in a single region in Google Cloud. Your security team requires each VPC network to have private connectivity to the main on-premises location via a Partner Interconnect connection in the same region. To optimize cost and operations, the same connectivity must be shared with all projects. You must ensure that all traffic between different projects, on-premises locations, and the internet can be inspected using the same third-party appliances. What should you do?

**A.** Configure the third-party appliances with multiple interfaces and specific Partner Interconnect VLAN attachments per project. Create the relevant routes on the third-party appliances and VPC networks.

**B.** Configure the third-party appliances with multiple interfaces, with each interface connected to a separate VPC network. Create separate VPC networks for on-premises and internet connectivity. Create the relevant routes on the third-party appliances and VPC networks.

**C.** Consolidate all existing projects’ subnetworks into a single VPCreate separate VPC networks for on-premises and internet connectivity. Configure the third-party appliances with multiple interfaces, with each interface connected to a separate VPC network. Create the relevant routes on the third-party appliances and VPC networks.

**D.** Configure the third-party appliances with multiple interfaces. Create a hub VPC network for all projects, and create separate VPC networks for on-premises and internet connectivity. Create the relevant routes on the third-party appliances and VPC networks. Use VPC Network Peering to connect all projects’ VPC networks to the hub VPC. Export custom routes from the hub VPC and import on all projects’ VPC networks.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it uses a central hub VPC with appliances connected to only three interfaces (Hub, On-Prem, Internet), adhering to the Google Cloud limit of 8 network interfaces per appliance while enabling traffic inspection from all peered spokes. Option B is incorrect as it attempts to connect one interface to each of the 10 project VPCs plus on-prem and internet links, exceeding the maximum allowed NIC count.

## Pregunta 102

Contexto: [topics:725](#topics-725)
You have just deployed your infrastructure on Google Cloud. You now need to configure the DNS to meet the following requirements:

•	Your on-premises resources should resolve your Google Cloud zones.
•	Your Google Cloud resources should resolve your on-premises zones.
•	You need the ability to resolve “.internal” zones provisioned by Google Cloud.

What should you do?

**A.** Configure an outbound server policy, and set your alternative name server to be your on-premises DNS resolver. Configure your on-premises DNS resolver to forward Google Cloud zone queries to Google's public DNS 8.8.8.8.

**B.** Configure both an inbound server policy and outbound DNS forwarding zones with the target as the on-premises DNS resolver. Configure your on-premises DNS resolver to forward Google Cloud zone queries to Google Cloud's DNS resolver.

**C.** Configure an outbound DNS server policy, and set your alternative name server to be your on-premises DNS resolver. Configure your on-premises DNS resolver to forward Google Cloud zone queries to Google Cloud's DNS resolver.

**D.** Configure Cloud DNS to DNS peer with your on-premises DNS resolver. Configure your on-premises DNS resolver to forward Google Cloud zone queries to Google's public DNS 8.8.8.8.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it establishes the necessary bidirectional resolution: outbound forwarding zones send on-premises queries from GCP to your local resolver, while inbound server policies allow your on-premises resolver to query GCP's internal DNS (including .internal zones) directly. Option C is incorrect because using an alternative name server configuration disables the resolution of Cloud DNS private zones and other internal records for VMs in the VPC, failing the requirement to resolve '.internal' zones.

## Pregunta 103

Contexto: [topics:725](#topics-725)
Your organization uses a hub-and-spoke architecture with critical Compute Engine instances in your Virtual Private Clouds (VPCs). You are responsible for the design of Cloud DNS in Google Cloud. You need to be able to resolve Cloud DNS private zones from your on-premises data center and enable on-premises name resolution from your hub-and-spoke VPC design. What should you do?

**A.** 1. Configure a private DNS zone in the hub VPC, and configure DNS forwarding to the on-premises server.
2. Configure DNS peering from the spoke VPCs to the hub VPC.

**B.** 1. Configure a DNS policy in the hub VPC to allow inbound query forwarding from the spoke VPCs.
2. Configure the spoke VPCs with a private zone, and set up DNS peering to the hub VPC.

**C.** 1. Configure a DNS policy in the spoke VPCs, and configure your on-premises DNS as an alternate DNS server.
2. Configure the hub VPC with a private zone, and set up DNS peering to each of the spoke VPCs.

**D.** 1. Configure a DNS policy in the hub VPC, and configure the on-premises DNS as an alternate DNS server.
2. Configure the spoke VPCs with a private zone, and set up DNS peering to the hub VPC.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it aligns with Google Cloud's recommended hybrid DNS architecture using a hub VPC.
By configuring a private DNS zone in the hub and enabling DNS forwarding to on-premises servers, you centralize name resolution management.
DNS peering from spoke VPCs to the hub allows instances in spokes to resolve names defined in the hub (and consequently forwarded to on-premises), satisfying the requirement for cross-VPC resolution.
The tempting alternative B is incorrect because DNS policies are not required to enable inbound queries via DNS Peering; peering handles the forwarding automatically without explicit policy configuration for this purpose.

## Pregunta 104

Contexto: [topics:725](#topics-725)
You have a Cloud Storage bucket in Google Cloud project XYZ. The bucket contains sensitive data. You need to design a solution to ensure that only instances belonging to VPCs under project XYZ can access the data stored in this Cloud Storage bucket. What should you do?

**A.** Configure Private Google Access to privately access the Cloud Storage service using private IP addresses.

**B.** Configure a VPC Service Controls perimeter around project XYZ, and include storage.googleapis.com as a restricted service in the service perimeter.

**C.** Configure Cloud Storage with projectPrivate Access Control List (ACL) that gives permission to the project team based on their roles.

**D.** Configure Private Service Connect to privately access Cloud Storage from all VPCs under project XYZ.

**Respuesta de la fuente:** B

**Explicación:** VPC Service Controls is the primary mechanism in Google Cloud designed to prevent data exfiltration by restricting access to sensitive services like Cloud Storage based on network boundaries (service perimeters). By defining a perimeter around project XYZ, you ensure that only resources within that specific network boundary can access the restricted storage.googleapis.com service, fulfilling the requirement to limit access to instances under project XYZ.

Option A is incorrect because Private Google Access allows VPCs to reach Google APIs via private IPs but does not enforce access restrictions based on project ownership or perimeter membership.

## Pregunta 105

Contexto: [topics:725](#topics-725)
You are maintaining a Shared VPC in a host project. Several departments within your company have infrastructure in different service projects attached to the Shared VPC and use Identity and Access Management (IAM) permissions to manage the cloud resources in those projects. VPC Network Peering is also set up between the Shared VPC and a common services VPC that is not in a service project. Several users are experiencing failed connectivity between certain instances in different Shared VPC service projects and between certain instances and the internet. You need to validate the network configuration to identify whether a misconfiguration is the root cause of the problem. What should you do?

**A.** Review the VPC audit logs in Cloud Logging for the affected instances.

**B.** Use Secure Shell (SSH) to connect to the affected Compute Engine instances, and run a series of PING tests to the other affected endpoints and the 8.8.8.8 IPv4 address.

**C.** Run Connectivity Tests from Network Intelligence Center to check connectivity between the affected endpoints in your network and the internet.

**D.** Enable VPC Flow Logs for all VPCs, and review the logs in Cloud Logging for the affected instances.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Network Intelligence Center (NIC) Connectivity Tests are specifically designed to validate network configuration by simulating traffic and identifying misconfigurations such as firewall rules or routing errors without generating live traffic noise. This provides a deterministic way to verify if the network setup itself is flawed, which aligns with the goal of validating configuration rather than just observing symptoms.

Option D (Enabling VPC Flow Logs) is tempting but less optimal because it enables logging for *all* VPCs, which can generate excessive data and incur significant costs before analysis even begins; it captures traffic after it occurs rather than proactively validating the configuration logic itself.

## Pregunta 106

Contexto: [topics:725](#topics-725)
Your organization has Compute Engine instances in us-east1, us-west2, and us-central1. Your organization also has an existing Cloud Interconnect physical connection in the East Coast of the United States with a single VLAN attachment and Cloud Router in us-east1. You need to provide a design with high availability and ensure that if a region goes down, you still have access to all your other Virtual Private Cloud (VPC) subnets. You need to accomplish this in the most cost-effective manner possible. What should you do?

**A.** 1. Configure your VPC routing in regional mode.
2. Add an additional Cloud Interconnect VLAN attachment in the us-east1 region, and configure a Cloud Router in us-east1.

**B.** 1. Configure your VPC routing in global mode.
2. Add an additional Cloud Interconnect VLAN attachment in the us-east1 region, and configure a Cloud Router in us-east1.

**C.** 1. Configure your VPC routing in global mode.
2. Add an additional Cloud Interconnect VLAN attachment in the us-west2 region, and configure a Cloud Router in us-west2.

**D.** 1. Configure your VPC routing in regional mode.
2. Add additional Cloud Interconnect VLAN attachments in the us-west2 and us-central1 regions, and configure Cloud Routers in us-west2 and us-central1.

**Respuesta de la fuente:** C

**Explicación:** To ensure high availability across regions, you must configure VPC routing in Global mode so that dynamic routes from Cloud Routers in different regions are advertised and usable organization-wide. Adding a second Cloud Interconnect attachment in us-west2 provides geographic redundancy; if the us-east1 region fails, traffic can still reach on-premises via us-west2, maintaining access to all VPC subnets. Option B is incorrect because adding a second link in the same region (us-east1) does not protect against a regional outage, which violates the core requirement.

## Pregunta 107

Contexto: [topics:725](#topics-725)
You recently configured Google Cloud Armor security policies to manage traffic to your application. You discover that Google Cloud Armor is incorrectly blocking some traffic to your application. You need to identity the web application firewall (WAF) rule that is incorrectly blocking traffic. What should you do?

**A.** Enable firewall logs, and view the logs in Firewall Insights.

**B.** Enable HTTP(S) Load Balancing logging with sampling rate equal to 1, and view the logs in Cloud Logging.

**C.** Enable VPC Flow Logs, and view the logs in Cloud Logging.

**D.** Enable Google Cloud Armor audit logs, and view the logs on the Activity page in the Google Cloud Console.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Armor is integrated with HTTP(S) Load Balancing, and its traffic logs are emitted within the HTTP(S) Load Balancer access logs rather than as standalone audit or firewall logs. Setting the sampling rate to 1 ensures that every request, including those blocked by WAF rules, is captured in Cloud Logging for detailed analysis of which specific rule triggered the block. Other options like VPC Flow Logs (Layer 3/4) lack application-layer WAF details, and Firewall Insights pertains to VPC firewall rules, not Cloud Armor policies.

## Pregunta 108

Contexto: [topics:725](#topics-725)
You are the Organization Admin for your company. One of your engineers is responsible for setting up multiple host projects across multiple folders and sharing subnets with service projects. You need to enable the engineer's Identity and Access Management (IAM) configuration to complete their task in the fewest number of steps. What should you do?

**A.** Set up the engineer with Compute Shared VPC Admin IAM role at the folder level.

**B.** Set up the engineer with Compute Shared VPC Admin IAM role at the organization level.

**C.** Set up the engineer with Compute Shared VPC Admin IAM role and Project IAM Admin role at the folder level.

**D.** Set up the engineer with Compute Shared VPC Admin IAM role and Project IAM Admin role at the organization level.

**Respuesta de la fuente:** B

**Explicación:** The task requires configuring Shared VPC host projects across multiple folders, so applying the role at the organization level minimizes the number of steps by covering all relevant scopes with a single assignment.
The Compute Shared VPC Admin (roles/compute.xpnAdmin) role provides the specific permissions to enable host projects and associate service projects; adding the Project IAM Admin role violates the principle of least privilege as it grants unnecessary access to manage IAM policies on projects.
Therefore, assigning only the Compute Shared VPC Admin role at the organization level is the most efficient and secure solution.

## Pregunta 109

Contexto: [topics:725](#topics-725)
You recently deployed Compute Engine instances in regions us-west1 and us-east1 in a Virtual Private Cloud (VPC) with default routing configurations. Your company security policy mandates that virtual machines (VMs) must not have public IP addresses attached to them. You need to allow your instances to fetch updates from the internet while preventing external access. What should you do?

**A.** Create a Cloud NAT gateway and Cloud Router in both us-west1 and us-east1.

**B.** Create a single global Cloud NAT gateway and global Cloud Router in the VPC.

**C.** Change the instances’ network interface external IP address from None to Ephemeral.

**D.** Create a firewall rule that allows egress to destination 0.0.0.0/0.

**Respuesta de la fuente:** A

**Explicación:** Cloud NAT and Cloud Router are regional resources in Google Cloud, meaning a single instance of either cannot serve VMs across different regions.
Therefore, you must create separate Cloud Router and Cloud NAT configurations for each region (us-west1 and us-east1) to allow outbound internet access without assigning public IPs.
Option B is incorrect because global NAT/Router resources do not exist for this purpose, and Option C violates the security policy by attaching external IPs.

## Pregunta 110

Contexto: [topics:725](#topics-725)
You are designing a new global application using Compute Engine instances that will be exposed by a global HTTP(S) load balancer. You need to secure your application from distributed denial-of-service and application layer (layer 7) attacks. What should you do?

**A.** Configure VPC Service Controls and create a secure perimeter. Define fine-grained perimeter controls and enforce that security posture across your Google Cloud services and projects.

**B.** Configure a Google Cloud Armor security policy in your project, and attach it to the backend service to secure the application.

**C.** Configure VPC firewall rules to protect the Compute Engine instances against distributed denial-of-service attacks.

**D.** Configure hierarchical firewall rules for the global HTTP(S) load balancer public IP address at the organization level.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Armor is the specific security service designed to protect load-balanced applications against Layer 7 DDoS and other web-based attacks by configuring security policies attached to backend services.
VPC firewall rules (Option C) operate at Layer 3/4 and are insufficient for mitigating application-layer (Layer 7) attacks, which require the advanced filtering capabilities provided by Cloud Armor.

## Pregunta 111

Contexto: [topics:725](#topics-725)
Your organization's security policy requires that all internet-bound traffic return to your on-premises data center through HA VPN tunnels before egressing to the internet, while allowing virtual machines (VMs) to leverage private Google APIs using private virtual IP addresses 199.36.153.4/30. You need to configure the routes to enable these traffic flows. What should you do?

**A.** Configure a custom route 0.0.0.0/0 with a priority of 500 whose next hop is the default internet gateway. Configure another custom route 199.36.153.4/30 with priority of 1000 whose next hop is the VPN tunnel back to the on-premises data center.

**B.** Configure a custom route 0.0.0.0/0 with a priority of 1000 whose next hop is the internet gateway. Configure another custom route 199.36.153.4/30 with a priority of 500 whose next hop is the VPN tunnel back to the on-premises data center.

**C.** Announce a 0.0.0.0/0 route from your on-premises router with a MED of 1000. Configure a custom route 199.36.153.4/30 with a priority of 1000 whose next hop is the default internet gateway.

**D.** Announce a 0.0.0.0/0 route from your on-premises router with a MED of 500. Configure another custom route 199.36.153.4/30 with a priority of 1000 whose next hop is the VPN tunnel back to the on-premises data center.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because announcing a default route (0.0.0.0/0) via BGP with a higher MED (1000) ensures that general internet traffic prefers the lower-priority path back to on-premises for inspection, while explicitly configuring a custom static route for Google APIs (199.36.153.4/30) to use the Default Internet Gateway keeps API traffic within GCP as required by Private Google Access policies.

Option D is incorrect because it directs Google API traffic through the VPN tunnel, which violates the requirement for VMs to leverage private virtual IP addresses locally and bypasses the efficient internal path.

## Pregunta 112

Contexto: [topics:725](#topics-725)
Your company has defined a resource hierarchy that includes a parent folder with subfolders for each department. Each department defines their respective project and VPC in the assigned folder and has the appropriate permissions to create Google Cloud firewall rules. The VPCs should not allow traffic to flow between them. You need to block all traffic from any source, including other VPCs, and delegate only the intra-VPC firewall rules to the respective departments. What should you do?

**A.** Create a VPC firewall rule in each VPC to block traffic from any source, with priority 0.

**B.** Create a VPC firewall rule in each VPC to block traffic from any source, with priority 1000.

**C.** Create two hierarchical firewall policies per department's folder with two rules in each: a high-priority rule that matches traffic from the private CIDRs assigned to the respective VPC and sets the action to allow, and another lower-priority rule that blocks traffic from any other source.

**D.** Create two hierarchical firewall policies per department's folder with two rules in each: a high-priority rule that matches traffic from the private CIDRs assigned to the respective VPC and sets the action to goto_next, and another lower-priority rule that blocks traffic from any other source.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because hierarchical firewall policies support the `goto_next` action, which explicitly delegates connection evaluation to lower levels in the resource hierarchy (i.e., the department folders).
This mechanism allows the organization-level policy to handle inter-VPC isolation while granting departments the authority to define intra-VPC rules, satisfying the requirement to 'delegate only the intra-VPC firewall rules'.
Option C is incorrect because using a standard `allow` action at the organization level would not delegate control; it would finalize the decision for that specific traffic match, preventing departments from managing their own internal rule granularity effectively.

## Pregunta 113

Contexto: [topics:725](#topics-725)
You have two Google Cloud projects in a perimeter to prevent data exfiltration. You need to move a third project inside the perimeter; however, the move could negatively impact the existing environment. You need to validate the impact of the change. What should you do?

**A.** Enable Firewall Rules Logging inside the third project.

**B.** Modify the existing VPC Service Controls policy to include the new project in dry run mode.

**C.** Monitor the Resource Manager audit logs inside the perimeter.

**D.** Enable VPC Flow Logs inside the third project, and monitor the logs for negative impact.

**Respuesta de la fuente:** B

**Explicación:** VPC Service Controls Dry Run mode is specifically designed to simulate perimeter changes without actively enforcing them, allowing administrators to validate the impact of adding a project before committing to the change.
This feature logs violations that would have occurred under enforced mode, ensuring existing services remain unaffected during validation.
Firewall rules (A) and VPC Flow Logs (D) operate at the network layer and cannot assess cross-project access control policies defined by VPC Service Controls.

## Pregunta 114

Contexto: [topics:725](#topics-725)
You are configuring an HA VPN connection between your Virtual Private Cloud (VPC) and on-premises network. The VPN gateway is named VPN_GATEWAY_1. You need to restrict VPN tunnels created in the project to only connect to your on-premises VPN public IP address: 203.0.113.1/32. What should you do?

**A.** Configure a firewall rule accepting 203.0.113.1/32, and set a target tag equal to VPN_GATEWAY_1.

**B.** Configure the Resource Manager constraint constraints/compute.restrictVpnPeerIPs to use an allowList consisting of only the 203.0.113.1/32 address.

**C.** Configure a Google Cloud Armor security policy, and create a policy rule to allow 203.0.113.1/32.

**D.** Configure an access control list on the peer VPN gateway to deny all traffic except 203.0.113.1/32, and attach it to the primary external interface.

**Respuesta de la fuente:** B

**Explicación:** Answer B is correct because the `constraints/compute.restrictVpnPeerIPs` organization policy constraint is specifically designed to restrict the set of valid IP addresses that can be configured as VPN peer IPs, ensuring only authorized on-premises gateways can initiate connections. Option A (firewall rule) is incorrect because firewalls control traffic flow into instances or subnets but do not enforce configuration restrictions on which IPs users are allowed to specify when creating VPN tunnel resources.

## Pregunta 115

Contexto: [topics:725](#topics-725)
Your company has recently installed a Cloud VPN tunnel between your on-premises data center and your Google Cloud Virtual Private Cloud (VPC). You need to configure access to the Cloud Functions API for your on-premises servers. The configuration must meet the following requirements:

•	Certain data must stay in the project where it is stored and not be exfiltrated to other projects.
•	Traffic from servers in your data center with RFC 1918 addresses do not use the internet to access Google Cloud APIs.
•	All DNS resolution must be done on-premises.
•	The solution should only provide access to APIs that are compatible with VPC Service Controls.

What should you do?

**A.** 1. Create an A record for private.googleapis.com using the 199.36.153.8/30 address range.
2. Create a CNAME record for *.googleapis.com that points to the A record.
3. Configure your on-premises routers to use the Cloud VPN tunnel as the next hop for the addresses you used in the A record.
4. Remove the default internet gateway from the VPC where your Cloud VPN tunnel terminates.

**B.** 1. Create an A record for restricted.googleapis.com using the 199.36.153.4/30 address range.
2. Create a CNAME record for *.googleapis.com that points to the A record.
3. Configure your on-premises routers to use the Cloud VPN tunnel as the next hop for the addresses you used in the A record.
4. Configure your on-premises firewalls to allow traffic to the restricted.googleapis.com addresses.

**C.** 1. Create an A record for restricted.googleapis.com using the 199.36.153.4/30 address range.
2. Create a CNAME record for *.googleapis.com that points to the A record.
3. Configure your on-premises routers to use the Cloud VPN tunnel as the next hop for the addresses you used in the A record.
4. Remove the default internet gateway from the VPC where your Cloud VPN tunnel terminates.

**D.** 1. Create an A record for private.googleapis.com using the 199.36.153.8/30 address range.
2. Create a CNAME record for *.googleapis.com that points to the A record.
3. Configure your on-premises routers to use the Cloud VPN tunnel as the next hop for the addresses you used in the A record.
4. Configure your on-premises firewalls to allow traffic to the private.googleapis.com addresses.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it uses the restricted.googleapis.com domain and its associated 199.36.153.4/30 IP range, which are specifically designed for VPC Service Controls compatibility and prevent data exfiltration to other projects. Routing this traffic through the Cloud VPN tunnel via on-premises routers ensures that RFC 1918 address traffic does not traverse the public internet, satisfying the connectivity requirement.
The most tempting alternative, Option C, is incorrect because removing the default internet gateway from the VPC is an unnecessary and disruptive action that does not directly enforce the requirement for on-premises DNS resolution or control the path of traffic originating from the on-premises data center.

## Pregunta 116

Contexto: [topics:725](#topics-725)
You need to configure a Google Kubernetes Engine (GKE) cluster. The initial deployment should have 5 nodes with the potential to scale to 10 nodes. The maximum number of Pods per node is 8. The number of services could grow from 100 to up to 1024. How should you design the IP schema to optimally meet this requirement?

**A.** Configure a /28 primary IP address range for the node IP addresses. Configure a /25 secondary IP range for the Pods. Configure a /22 secondary IP range for the Services.

**B.** Configure a /28 primary IP address range for the node IP addresses. Configure a /25 secondary IP range for the Pods. Configure a /21 secondary IP range for the Services.

**C.** Configure a /28 primary IP address range for the node IP addresses. Configure a /28 secondary IP range for the Pods. Configure a /21 secondary IP range for the Services.

**D.** Configure a /28 primary IP address range for the node IP addresses. Configure a /24 secondary IP range for the Pads. Configure a /22 secondary IP range for the Services.

**Respuesta de la fuente:** D

**Explicación:** Answer D is correct because GKE enforces a minimum CIDR block size of /24 for Pod secondary IP ranges, regardless of the total number of pods needed. While options A and B use smaller subnets (/28 and /25) that mathematically fit the pod count, they violate this technical constraint and would cause cluster creation to fail. The /22 range for services is sufficient for 1024 services because secondary alias IP ranges in GKE do not reserve addresses for network or broadcast usage, allowing all 1024 IPs to be utilized.

## Pregunta 117

Contexto: [topics:725](#topics-725)
You are migrating a three-tier application architecture from on-premises to Google Cloud. As a first step in the migration, you want to create a new Virtual Private Cloud (VPC) with an external HTTP(S) load balancer. This load balancer will forward traffic back to the on-premises compute resources that run the presentation tier. You need to stop malicious traffic from entering your VPC and consuming resources at the edge, so you must configure this policy to filter IP addresses and stop cross-site scripting (XSS) attacks. What should you do?

**A.** Create a Google Cloud Armor policy, and apply it to a backend service that uses an unmanaged instance group backend.

**B.** Create a hierarchical firewall ruleset, and apply it to the VPC's parent organization resource node.

**C.** Create a Google Cloud Armor policy, and apply it to a backend service that uses an internet network endpoint group (NEG) backend.

**D.** Create a VPC firewall ruleset, and apply it to all instances in unmanaged instance groups.

**Respuesta de la fuente:** C

**Explicación:** Google Cloud Armor is the required service for filtering malicious traffic based on IP addresses and protecting against cross-site scripting (XSS) attacks at the edge. To forward traffic from the load balancer back to on-premises resources, you must use an Internet Network Endpoint Group (Internet NEG) as the backend, which supports external endpoints by IP address or hostname.
Option A is incorrect because unmanaged instance groups are designed for Google Compute Engine instances within a specific project and zone, not for on-premises infrastructure.

## Pregunta 118

Contexto: [topics:725](#topics-725)
You just finished your company’s migration to Google Cloud and configured an architecture with 3 Virtual Private Cloud (VPC) networks: one for Sales, one for Finance, and one for Engineering. Every VPC contains over 100 Compute Engine instances, and now developers using instances in the Sales VPC and the Finance VPC require private connectivity between each other. You need to allow communication between Sales and Finance without compromising performance or security. What should you do?

**A.** Configure an HA VPN gateway between the Finance VPC and the Sales VPC.

**B.** Configure the instances that require communication between each other with an external IP address.

**C.** Create a VPC Network Peering connection between the Finance VPC and the Sales VPC.

**D.** Configure Cloud NAT and a Cloud Router in the Sales and Finance VPCs.

**Respuesta de la fuente:** C

**Explicación:** VPC Network Peering is the correct solution because it establishes a low-latency, private Layer 3 connection between two VPCs within the same project or across projects without routing traffic through the public internet. This directly satisfies the requirement for private connectivity while maintaining optimal performance and security.

Option A (HA VPN) is incorrect because it is designed to connect on-premises networks or external clouds, not internal GCP VPCs, and introduces unnecessary complexity and latency. Option B exposes instances to the public internet, violating security best practices, and Option D enables outbound internet access rather than private inter-VPC communication.

## Pregunta 119

Contexto: [topics:725](#topics-725)
You have provisioned a Partner Interconnect connection to extend connectivity from your on-premises data center to Google Cloud. You need to configure a Cloud Router and create a VLAN attachment to connect to resources inside your VPC. You need to configure an Autonomous System number (ASN) to use with the associated Cloud Router and create the VLAN attachment.

What should you do?

**A.** Use a 4-byte private ASN 4200000000-4294967294.

**B.** Use a 2-byte private ASN 64512-65535.

**C.** Use a public Google ASN 15169.

**D.** Use a public Google ASN 16550.

**Respuesta de la fuente:** D

**Explicación:** For Partner Interconnect connections in Google Cloud, the Cloud Router must be configured with the specific public Google ASN of 16550.
This is a mandatory requirement documented by Google for establishing BGP peering with partner edge routers.
Option C (ASN 15169) is incorrect because it is Google's general internet-facing ASN, not the one assigned for Partner Interconnect routing.

## Pregunta 120

Contexto: [topics:725](#topics-725)
You are configuring a new application that will be exposed behind an external load balancer with both IPv4 and IPv6 addresses and support TCP pass-through on port 443. You will have backends in two regions: us-west1 and us-east1. You want to serve the content with the lowest possible latency while ensuring high availability and autoscaling. Which configuration should you use?

**A.** Use global SSL Proxy Load Balancing with backends in both regions.

**B.** Use global TCP Proxy Load Balancing with backends in both regions.

**C.** Use global external HTTP(S) Load Balancing with backends in both regions.

**D.** Use Network Load Balancing in both regions, and use DNS-based load balancing to direct traffic to the closest region.

**Respuesta de la fuente:** D

**Explicación:** The requirement for TCP pass-through on port 443 explicitly excludes SSL Proxy (A) and HTTP(S) Load Balancing (C), as these proxies terminate TLS connections rather than passing raw TCP traffic.
Although Global TCP Proxy (B) supports multi-region backends, it terminates the connection at the proxy edge before forwarding to the backend, which is technically 'proxy' mode, not true layer-4 pass-through.
Network Load Balancing (NLB) operates at Layer 4 with true TCP pass-through capabilities; configuring regional NLBs in both us-west1 and us-east1 alongside DNS-based routing policies (or Cloud DNS geo-routing) satisfies the need for low latency by directing users to the nearest region while maintaining high availability.

## Pregunta 121

Contexto: [topics:725](#topics-725)
In your project my-project, you have two subnets in a Virtual Private Cloud (VPC): subnet-a with IP range 10.128.0.0/20 and subnet-b with IP range 172.16.0.0/24. You need to deploy database servers in subnet-a. You will also deploy the application servers and web servers in subnet-b. You want to configure firewall rules that only allow database traffic from the application servers to the database servers. What should you do?

**A.** Create network tag app-server and service account sa-db@my-project.iam.gserviceaccount.com. Add the tag to the application servers, and associate the service account with the database servers. Run the following command: gcloud compute firewall-rules create app-db-firewall-rule \
--action allow \
--direction ingress \
--rules top:3306 \
--source-tags app-server \
--target-service-accounts sa-db@my-
project.iam.gserviceaccount.com

**B.** Create service accounts sa-app@my-project.iam.gserviceaccount.com and sa-db@my-project.iam.gserviceaccount.com. Associate service account sa-app with the application servers, and associate the service account sa-db with the database servers. Run the following command: gcloud compute firewall-rules create app-db-firewall-ru
--allow TCP:3306 \
--source-service-accounts sa-app@democloud-idp-
demo.iam.gserviceaccount.com \
--target-service-accounts sa-db@my-
project.iam.gserviceaccount.com

**C.** Create service accounts sa-app@my-project.iam.gserviceaccount.com and sa-db@my-project.iam.gserviceaccount.com. Associate the service account sa-app with the application servers, and associate the service account sa-db with the database servers. Run the following command: gcloud compute firewall-rules create app-db-firewall-ru
--allow TCP:3306 \
--source-ranges 10.128.0.0/20 \
--source-service-accounts sa-app@my-
project.iam.gserviceaccount.com \
--target-service-accounts sa-db@my-
project.iam.gserviceaccount.com

**D.** Create network tags app-server and db-server. Add the app-server tag to the application servers, and add the db-server tag to the database servers. Run the following command: gcloud compute firewall-rules create app-db-firewall-rule \
--action allow \
--direction ingress \
--rules tcp:3306 \
--source-ranges 10.128.0.0/20 \
--source-tags app-server \
--target-tags db-server

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it correctly identifies the source (application servers in subnet-b) and uses service accounts for both source and target filtering, which is a valid and secure method. Options C and D are incorrect because they specify `--source-ranges` as 10.128.0.0/20, which is subnet-a where the database servers reside; the traffic originates from subnet-b (172.16.0.0/24). Option A is invalid because GCP firewall rules do not allow mixing source tags with target service accounts in the same rule.

## Pregunta 122

Contexto: [topics:725](#topics-725)
You are planning a large application deployment in Google Cloud that includes on-premises connectivity. The application requires direct connectivity between workloads in all regions and on-premises locations without address translation, but all RFC 1918 ranges are already in use in the on-premises locations. What should you do?

**A.** Use multiple VPC networks with a transit network using VPC Network Peering.

**B.** Use overlapping RFC 1918 ranges with multiple isolated VPC networks.

**C.** Use overlapping RFC 1918 ranges with multiple isolated VPC networks and Cloud NAT.

**D.** Use non-RFC 1918 ranges with a single global VPC.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because using non-RFC 1918 address space avoids IP overlap with the on-premises network entirely, enabling direct connectivity without NAT.
Overlapping RFC 1918 ranges (Options A, B, and C) create routing conflicts that prevent direct communication between identical subnets in Google Cloud and on-premises environments without address translation.

## Pregunta 123

Contexto: [topics:725](#topics-725)
Your company's security team wants to limit the type of inbound traffic that can reach your web servers to protect against security threats. You need to configure the firewall rules on the web servers within your Virtual Private Cloud (VPC) to handle HTTP and HTTPS web traffic for TCP only. What should you do?

**A.** Create an allow on match ingress firewall rule with the target tag “web-server” to allow all IP addresses for TCP port 80.

**B.** Create an allow on match egress firewall rule with the target tag “web-server” to allow all IP addresses for TCP port 80.

**C.** Create an allow on match ingress firewall rule with the target tag “web-server” to allow all IP addresses for TCP ports 80 and 443.

**D.** Create an allow on match egress firewall rule with the target tag “web-server" to allow web server IP addresses for TCP ports 80 and 443.

**Respuesta de la fuente:** C

**Explicación:** The requirement specifies limiting inbound traffic (ingress) to handle both HTTP (port 80) and HTTPS (port 443). Option C is correct because it correctly targets the 'web-server' tag for ingress rules and includes both necessary TCP ports. Option A is incorrect because it only opens port 80, failing to allow secure HTTPS traffic on port 443.

## Pregunta 124

Contexto: [topics:725](#topics-725)
You successfully provisioned a single Dedicated Interconnect. The physical connection is at a colocation facility closest to us-west2. Seventy-five percent of your workloads are in us-east4, and the remaining twenty-five percent of your workloads are in us-central1. All workloads have the same network traffic profile. You need to minimize data transfer costs when deploying VLAN attachments. What should you do?

**A.** Keep the existing Dedicated interconnect. Deploy a VLAN attachment to a Cloud Router in us-west2, and use VPC global routing to access workloads in us-east4 and us-central1.

**B.** Keep the existing Dedicated Interconnect. Deploy a VLAN attachment to a Cloud Router in us-east4, and deploy another VLAN attachment to a Cloud Router in us-central1.

**C.** Order a new Dedicated Interconnect for a colocation facility closest to us-east4, and use VPC global routing to access workloads in us-central1.

**D.** Order a new Dedicated Interconnect for a colocation facility closest to us-central1, and use VPC global routing to access workloads in us-east4.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it utilizes Regional Routing, which eliminates region-to-region egress charges between the on-premises connection point and the workload regions. By attaching VLANs in both us-east4 and us-central1, traffic exits the interconnect locally for each region, avoiding the costly cross-region data transfer fees that would incur if using a single attachment with Global Routing (as in Option A) or moving the physical connection (Options C/D). Option A is the most tempting alternative but is incorrect because Global Routing forces all traffic through us-west2, incurring significant region-to-region egress charges for the 75% of traffic destined for us-east4.

## Pregunta 125

Contexto: [topics:725](#topics-725)
You are designing a hybrid cloud environment. Your Google Cloud environment is interconnected with your on-premises network using HA VPN and Cloud Router in a central transit hub VPC. The Cloud Router is configured with the default settings. Your on-premises DNS server is located at 192.168.20.88. You need to ensure that your Compute Engine resources in multiple spoke VPCs can resolve on-premises private hostnames using the domain corp.altostrat.com while also resolving Google Cloud hostnames. You want to follow Google-recommended practices. What should you do?

**A.** 1. Create a private forwarding zone in Cloud DNS for ‘corp.altostrat.com’ called corp-altostrat-com that points to 192.168.20.88. Associate the zone with the hub VPC.
2. Create a private peering zone in Cloud DNS for ‘corp.altostrat.com’ called corp-altostrat-com associated with the spoke VPCs, with the hub VPC as the target.
3. Set a custom route advertisement on the Cloud Router for 35.199.192.0/19.
4. Configure VPC peering in the spoke VPCs to peer with the hub VPC.

**B.** 1. Create a private forwarding zone in Cloud DNS for ‘corp.altostrat.com’ called corp-altostrat-com that points to 192.168.20.88.
2. Associate the zone with the hub VPC. Create a private peering zone in Cloud DNS for ‘corp.altostrat.com’ called corp-altostrat-com associated with the spoke PCs, with the hub VPC as the target.
3. Set a custom route advertisement on the Cloud Router for 35.199.192.0/19.

**C.** 1. Create a private forwarding zone in Cloud DNS for ‘corp.altostrat.com’ called corp-altostrat-com that points to 192.168.20.88. Associate the zone with the hub VPC.
2. Create a private peering zone in Cloud DNS for ‘corp.altostrat.com’ called corp-altostrat-com associated with the spoke VPCs, with the hub VPC as the target.
3. Set a custom route advertisement on the Cloud Router for 35.199.192.0/19.
4. Create a hub-and-spoke VPN deployment in each spoke VPC to connect back to the on-premises network directly.

**D.** 1. Create a private forwarding zone in Cloud DNS for ‘corp altostrat.com’ called corp-altostrat-com that points to 192. 168.20.88. Associate the zone with the hub VPC.
2. Create a private peering zone in Cloud DNS for ‘corp.altostrat.com’ called corp-altostrat-com associated with the spoke VPCs, with the hub VPC as the target.
3. Sat a custom route advertisement on the Cloud Router for 35.199.192.0/19.
4. Create a hub and spoke VPN deployment in each spoke VPC to connect back to the hub VPC.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Google-recommended hybrid cloud best practices use VPC Network Peering to enable connectivity between spoke and hub VPCs, allowing Cloud DNS Private Forwarding Zones in the hub to resolve on-premises hostnames for spoke resources.
While DNS Peering alone can propagate DNS records (making B tempting), it does not provide the necessary network routing for Compute Engine instances to reach the on-premises DNS server; thus, VPC peering is required for end-to-end resolution in this architecture.

## Pregunta 126

Contexto: [topics:725](#topics-725)
You have the following firewall ruleset applied to all instances in your Virtual Private Cloud (VPC):

[Imagen: sin descripción]

You need to update the firewall rule to add the following rule to the ruleset:

[Imagen: sin descripción]

You are using a new user account. You must assign the appropriate identity and Access Management (IAM) user roles to this new user account before updating the firewall rule. The new user account must be able to apply the update and view firewall logs. What should you do?
Imagen · question_text · sin descripción
![Imagen original](imagenes/0a67d06eb4e8c6a5db2b.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Direction Action | Address range Port Priority
egress: deny 192.0.2.0/24 80 100
egress: deny 198.51.100.0/24 | 80 200
ingress allow 203.0.113.0/24 80 300
```
Imagen · question_text · sin descripción
![Imagen original](imagenes/59163e7125c73ba55738.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Direction
Action
Address range
Port
Logging
egress:
deny
192.0.2.42/32
80
true
```

**A.** Assign the compute.securityAdmin and logging.viewer rule to the new user account. Apply the new firewall rule with a priority of 50.

**B.** Assign the compute.securityAdmin and logging.bucketWriter role to the new user account. Apply the new firewall rule with a priority of 150.

**C.** Assign the compute.orgSecurityPolicyAdmin and logging.viewer role to the new user account. Apply the new firewall rule with a priority of 50.

**D.** Assign the compute.orgSecurityPolicyAdmin and logging.bucketWriter role to the new user account. Apply the new firewall rule with a priority of 150.

**Respuesta de la fuente:** A

**Explicación:** The rule must have a priority of 50 (lower number = higher priority) to ensure the specific /32 deny-allow logging rule takes precedence over the broader 192.0.2.0/24 allow-all rule, which eliminates options B and D. Between A and C, `compute.securityAdmin` is the correct role for managing VPC firewall rules within a project/network scope, whereas `compute.orgSecurityPolicyAdmin` is for Organization Policy constraints, making A the appropriate choice under least privilege. Additionally, `logging.viewer` allows the user to view logs, satisfying the requirement without granting unnecessary write permissions like `logging.bucketWriter`.

## Pregunta 127

Contexto: [topics:725](#topics-725)
Your organization has a single project that contains multiple Virtual Private Clouds (VPCs). You need to secure API access to your Cloud Storage buckets and BigQuery datasets by allowing API access only from resources in your corporate public networks. What should you do?

**A.** Create an access context policy that allows your VPC and corporate public network IP ranges, and then attach the policy to Cloud Storage and BigQuery.

**B.** Create a VPC Service Controls perimeter for your project with an access context policy that allows your corporate public network IP ranges.

**C.** Create a firewall rule to block API access to Cloud Storage and BigQuery from unauthorized networks.

**D.** Create a VPC Service Controls perimeter for each VPC with an access context policy that allows your corporate public network IP ranges.

**Respuesta de la fuente:** B

**Explicación:** VPC Service Controls are the correct mechanism to restrict data access to Cloud Storage and BigQuery based on source identity or network location, as standard firewall rules (Option C) cannot control API-level access to these managed services. Option B is superior to Option D because defining a single perimeter at the project level automatically encompasses all resources within that project, including all its VPCs, whereas creating perimeters for each VPC (Option D) creates unnecessary management overhead and complexity.

## Pregunta 128

Contexto: [topics:725](#topics-725)
Your company has provisioned 2000 virtual machines (VMs) in the private subnet of your Virtual Private Cloud (VPC) in the us-east1 region. You need to configure each VM to have a minimum of 128 TCP connections to a public repository so that users can download software updates and packages over the internet. You need to implement a Cloud NAT gateway so that the VMs are able to perform outbound NAT to the internet. You must ensure that all VMs can simultaneously connect to the public repository and download software updates and packages. Which two methods can you use to accomplish this? (Choose two.)

**A.** Configure the NAT gateway in manual allocation mode, allocate 2 NAT IP addresses, and update the minimum number of ports per VM to 256.

**B.** Create a second Cloud NAT gateway with the default minimum number of ports configured per VM to 64.

**C.** Use the default Cloud NAT gateway's NAT proxy to dynamically scale using a single NAT IP address.

**D.** Use the default Cloud NAT gateway to automatically scale to the required number of NAT IP addresses, and update the minimum number of ports per VM to 128.

**E.** Configure the NAT gateway in manual allocation mode, allocate 4 NAT IP addresses, and update the minimum number of ports per VM to 128.

**Respuesta de la fuente:** D, E

**Explicación:** Option E is correct because 4 NAT IPs × 64,512 ports/IP ÷ 128 ports/VM = 2,016 concurrent VMs, which satisfies the requirement for 2,000 VMs. Option D is correct because Cloud NAT automatically scales IP addresses when manual allocation is insufficient or not specified, ensuring all 2,000 VMs have the required 128 ports each.
Option C is incorrect because a single NAT IP supports only ~504 VMs (64,512 ÷ 128), which is far below the 2,000 needed.

## Pregunta 129

Contexto: [topics:725](#topics-725)
You have the following routing design. You discover that Compute Engine instances in Subnet-2 in the asia-southeast1 region cannot communicate with compute resources on-premises. What should you do?

[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/dd1b633fee61453cae90.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
‘2 Google Cloud
vPc
On-premises inTSINeSTT
Router BGP Subnet-1
Session Cloud
Subnet-a =I — Co)
= VPN Gateway 9!
4	1	2	1	7	0	123	223	159	15	-1	
5	1	2	1	7	1	123	223	32	12	95.648346	VPN
5	1	2	1	7	2	161	223	60	15	85.330162	Gateway
5	1	2	1	7	3	237	225	45	12	85.330162	Tunnel
4	1	2	1	8	0	335	248	119	12	-1	
5	1	2	1	8	1	335	248	119	12	31.878729	asia-southeast!
4	1	2	1	9	0	457	263	68	12	-1	
5	1	2	1	9	1	457	263	68	12	63.840340	Subnet-2
4	1	2	1	10	0	471	322	69	15	-1	
5	1	2	1	10	1	471	322	69	15	96.216400	Compute
2	1	3	0	0	0	479	343	53	15	-1	
3	1	3	1	0	0	479	343	53	15	-1	
4	1	3	1	1	0	479	343	53	15	-1	
5	1	3	1	1	1	479	343	53	15	96.348030	Engine

```

**A.** Configure a custom route advertisement on the Cloud Router.

**B.** Enable IP forwarding in the asia-southeast1 region.

**C.** Change the VPC dynamic routing mode to Global.

**D.** Add a second Border Gateway Protocol (BGP) session to the Cloud Router.

**Respuesta de la fuente:** C

**Explicación:** The VPC network currently uses a 'Regional' dynamic routing mode, which limits BGP route propagation to routers within the same region. Changing the mode to 'Global' allows Cloud Router instances in asia-southeast1 to exchange routes with on-premises peers across regions, resolving the connectivity issue. Options A and B are incorrect because default advertisements usually suffice for VPC subnets, and IP forwarding is an instance-level setting, not a regional one.

## Pregunta 130

Contexto: [topics:725](#topics-725)
You are designing a hybrid cloud environment for your organization. Your Google Cloud environment is interconnected with your on-premises network using Cloud HA VPN and Cloud Router. The Cloud Router is configured with the default settings. Your on-premises DNS server is located at 192.168.20.88 and is protected by a firewall, and your Compute Engine resources are located at 10.204.0.0/24. Your Compute Engine resources need to resolve on-premises private hostnames using the domain corp.altostrat.com while still resolving Google Cloud hostnames. You want to follow Google-recommended practices. What should you do?

**A.** 1. Create a private forwarding zone in Cloud DNS for ‘corp.altostrat.com’ called corp-altostrat-com that points to 192.168.20.88.
2. Configure your on-premises firewall to accept traffic from 10.204.0.0/24.
3. Set a custom route advertisement on the Cloud Router for 10.204.0.0/24

**B.** 1. Create a private forwarding zone in Cloud DNS for ‘corp.altostrat.com’ called corp-altostrat-com that points to 192.168 20.88.
2. Configure your on-premises firewall to accept traffic from 35.199.192.0/19
3. Set a custom route advertisement on the Cloud Router for 35.199.192.0/19.

**C.** 1. Create a private forwarding zone in Cloud DNS for ‘corp .altostrat.com’ called corp-altostrat-com that points to 192.168.20.88.
2. Configure your on-premises firewall to accept traffic from 10.204.0.0/24.
3. Modify the /etc/resolv conf file on your Compute Engine instances to point to 192.168.20 88

**D.** 1. Create a private zone in Cloud DNS for ‘corp altostrat.com’ called corp-altostrat-com.
2. Configure DNS Server Policies and create a policy with Alternate DNS servers to 192.168.20.88.
3. Configure your on-premises firewall to accept traffic from 35.199.192.0/19.
4. Set a custom route advertisement on the Cloud Router for 35.199.192.0/19.

**Respuesta de la fuente:** B

**Explicación:** Answer B is correct because Cloud DNS forwarding zones use the reserved source IP range 35.199.192.0/19 for queries, not the VPC's internal IP range (eliminating A and C).
To allow these queries to reach the on-premises DNS server, you must configure the firewall to accept traffic from 35.199.192.0/19 and advertise this specific route via Cloud Router so GCP knows how to reach it. Option D is incorrect because it suggests creating a private (authoritative) zone instead of a forwarding zone, which would require managing records manually rather than forwarding them.

## Pregunta 131

Contexto: [topics:725](#topics-725)
Your company has a single Virtual Private Cloud (VPC) network deployed in Google Cloud with on-premises connectivity already in place. You are deploying a new application using Google Kubernetes Engine (GKE), which must be accessible only from the same VPC network and on-premises locations. You must ensure that the GKE control plane is exposed to a predefined list of on-premises subnets through private connectivity only. What should you do?

**A.** Create a GKE private cluster with a private endpoint for the control plane. Configure VPC Networking Peering export/import routes and custom route advertisements on the Cloud Routers. Configure authorized networks to specify the desired on-premises subnets.

**B.** Create a GKE private cluster with a public endpoint for the control plane. Configure VPC Networking Peering export/import routes and custom route advertisements on the Cloud Routers.

**C.** Create a GKE private cluster with a private endpoint for the control plane. Configure authorized networks to specify the desired on-premises subnets.

**D.** Create a GKE public cluster. Configure authorized networks to specify the desired on-premises subnets.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because a GKE private cluster places the control plane in a Google-managed VPC that peers with your project's VPC; to allow on-premises subnets (via Cloud Router) to reach this private endpoint, you must enable custom route export/import on the peering connection and specify those subnets in authorized networks.
Option C is incorrect because it omits the necessary configuration of VPC peering route exchange, meaning the control plane would not know how to route responses back to the on-premises networks through the Cloud Router.

## Pregunta 132

Contexto: [topics:725](#topics-725)
You built a web application with several containerized microservices. You want to run those microservices on Cloud Run. You must also ensure that the services are highly available to your customers with low latency. What should you do?

**A.** Deploy the Cloud Run services to multiple availability zones. Create a global TCP load balancer. Add the Cloud Run endpoints to its backend service.

**B.** Deploy the Cloud Run services to multiple regions. Create serverless network endpoint groups (NEGs) that point to the services. Create a global HTTPS load balancer, and attach the serverless NEGs as backend services of the load balancer.

**C.** Deploy the Cloud Run services to multiple availability zones. Create Cloud Endpoints that point to the services. Create a global HTTPS load balancer, and attach the Cloud Endpoints to its backend

**D.** Deploy the Cloud Run services to multiple regions. Configure a round-robin A record in Cloud DNS.

**Respuesta de la fuente:** B

**Explicación:** Deploying to multiple regions ensures high availability and low latency by routing users to the nearest data center. Serverless Network Endpoint Groups (NEGs) are the required backend configuration for Cloud Run services in an HTTP(S) Load Balancer, enabling proper traffic distribution.
Option A is incorrect because deploying only across Availability Zones within a single region does not provide global low-latency access, and TCP load balancing is generally not used for standard web application traffic.

## Pregunta 133

Contexto: [topics:725](#topics-725)
You have an HA VPN connection with two tunnels running in active/passive mode between your Virtual Private Cloud (VPC) and on-premises network. Traffic over the connection has recently increased from 1 gigabit per second (Gbps) to 4 Gbps, and you notice that packets are being dropped. You need to configure your VPN connection to Google Cloud to support 4 Gbps. What should you do?

**A.** Configure the remote autonomous system number (ASN) to 4096.

**B.** Configure a second Cloud Router to scale bandwidth in and out of the VPC.

**C.** Configure the maximum transmission unit (MTU) to its highest supported value.

**D.** Configure a second set of active/passive VPN tunnels.

**Respuesta de la fuente:** D

**Explicación:** A single Cloud VPN tunnel supports up to 3 Gbps for the sum of ingress and egress traffic. Since the requirement is 4 Gbps, a single active/passive pair (effectively one tunnel path) cannot handle the load. Configuring a second set of tunnels provides additional bandwidth capacity to meet the 4 Gbps threshold.

Changing the ASN (A) affects routing policy, not throughput. Adding another Cloud Router (B) is unnecessary if existing routers can handle the BGP sessions, and MTU adjustments (C) only resolve fragmentation issues, not bandwidth saturation.

## Pregunta 134

Contexto: [topics:725](#topics-725)
You recently deployed two network virtual appliances in us-central1. Your network appliances provide connectivity to your on-premises network, 10.0.0.0/8. You need to configure the routing for your Virtual Private Cloud (VPC). Your design must meet the following requirements:

•	All access to your on-premises network must go through the network virtual appliances.
•	Allow on-premises access in the event of a single network virtual appliance failure.
•	Both network virtual appliances must be used simultaneously.

Which method should you use to accomplish this?

**A.** Configure two routes for 10.0.0.0/8 with different priorities, each pointing to separate network virtual appliances.

**B.** Configure an internal HTTP(S) load balancer with the two network virtual appliances as backends. Configure a route for 10.0.0.0/8 with the internal HTTP(S) load balancer as the next hop.

**C.** Configure a network load balancer for the two network virtual appliances. Configure a route for 10.0.0.0/8 with the network load balancer as the next hop.

**D.** Configure an internal TCP/UDP load balancer with the two network virtual appliances as backends. Configure a route for 10.0.0.0/8 with the internal load balancer as the next hop.

**Respuesta de la fuente:** D

**Explicación:** Option D is the correct answer because an Internal TCP/UDP Load Balancer (ILB) is designed to distribute traffic to backend instances within a VPC and supports dynamic routing as a next-hop target. This setup ensures that both virtual appliances are utilized simultaneously for load sharing and provides high availability if one appliance fails, meeting all specified requirements.

Option C is incorrect because while Network Load Balancers can serve as next hops, the standard recommendation for centralized network appliances within a VPC specifically cites the Internal TCP/UDP Load Balancer (or Internal Passthrough NLB) to ensure proper layer-3 forwarding and internal traffic handling without exposing services externally. Option A fails the simultaneous usage requirement due to static priority routing, and Option B is unsuitable as HTTP(S) LBs operate at Layer 7, altering headers and potentially breaking generic network appliance functions.

## Pregunta 135

Contexto: [topics:725](#topics-725)
You are responsible for enabling Private Google Access for the virtual machine (VM) instances in your Virtual Private Cloud (VPC) to access Google APIs. All VM instances have only a private IP address and need to access Cloud Storage. You need to ensure that all VM traffic is routed back to your on-premises data center for traffic scrubbing via your existing Cloud Interconnect connection. However, VM traffic to Google APIs should remain in the VPC. What should you do?

**A.** 1. Delete the default route in your VPC.
2. Create a private Cloud DNS zone for googleapis.com, create a CNAME for *.googleapis.com to restricted googleapis.com, and create an A record for restricted googleapis com that resolves to the addresses in 199.36.153.4/30.
3. Create a static route in your VPC for the range 199.36.153.4/30 with the default internet gateway as the next hop.

**B.** 1. Delete the default route in your VPC and configure your on-premises router to advertise 0.0.0.0/0 via Border Gateway Protocol (BGP).
2. Create a public Cloud DNS zone with a CNAME for *.google.com to private googleapis com, create a CNAME for * googleapis.com to private googleapis com, and create an A record for Private googleapis.com that resolves to the addresses in 199.36.153 8/30.
3. Create a static route in your VPC for the range 199 .36.153.8/30 with the default internet gateway as the next hop.

**C.** 1. Configure your on-premises router to advertise 0.0.0.0/0 via Border Gateway Protocol (BGP) with a lower priority (MED) than the default VPC route.
2. Create a private Cloud DNS zone for googleapis.com, create a CNAME for * googieapis.com to private googleapis com, and create an A record for private.googleapis.com that resolves to the addresses in 199 .36.153.8/30.
3. Create a static route in your VPC for the range 199.36. 153.8/30 with the default internet gateway as the next hop.

**D.** 1. Delete the default route in your VPC and configure your on-premises router to advertise 0.0.0.0/0 via Border Gateway Protocol (BGP).
2. Create a private Cloud DNS zone for googleapis.com, create a CNAME for * googieapis.com to Private googleapis.com, and create an A record for private.googleapis.com that resolves to the addresses in 199.36.153.8/30.
3. Create a static route in your VPC for the range 199.36.153.8/30 with the default internet gateway as the next hop.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it explicitly deletes the default route pointing to the Internet Gateway and replaces it with a BGP-advertised 0.0.0.0/0 from on-premises, ensuring all non-API traffic is forced back through Cloud Interconnect for scrubbing. Meanwhile, the specific static route for the Private Google Access IP range (199.36.153.8/30) remains with the Internet Gateway next hop, allowing API traffic to stay in the VPC.

Option C is incorrect because it attempts to manipulate BGP priority via MED, which does not reliably override the default VPC route’s precedence compared to simply removing the conflicting default route. Additionally, Option A uses the incorrect IP range for Private Google Access (199.36.153.4/30 instead of .8/30) and fails to establish the on-premises return path via BGP.

## Pregunta 136

Contexto: [topics:725](#topics-725)
You are designing a hub-and-spoke network architecture for your company’s cloud-based environment. You need to make sure that all spokes are peered with the hub. The spokes must use the hub's virtual appliance for internet access. The virtual appliance is configured in high-availability mode with two instances using an internal load balancer with IP address 10.0.0.5. What should you do?

**A.** 1. Create a default route in the hub VPC that points to IP address 10.0.0.5.
2. Delete the default internet gateway route in the hub VPC, and create a new higher-priority route that is tagged only to the appliances with a next hop of the default internet gateway.
3. Export the custom routes in the hub.
4. Import the custom routes in the spokes.

**B.** 1. Create a default route in the hub VPC that points to IP address 10.0.0.5.
2. Delete the default internet gateway route in the hub VPC, and create a new higher-priority route that is tagged only to the appliances with a next hop of the default internet gateway.
3. Export the custom routes in the hub. Import the custom routes in the spokes.
4. Delete the default internet gateway route of the spokes.

**C.** 1. Create two default routes in the hub VPC that point to the next hop instances of the virtual appliances.
2. Delete the default internet gateway route in the hub VPC, and create a new higher-priority route that is tagged only to the appliances with a next hop of the default internet gateway.
3. Export the custom routes in the hub. Import the custom routes in the spokes.

**D.** 1. Create a default route in the hub VPC that points to IP address 10.0.0.5.
2. Delete the default internet gateway route in the hub VPC, and create a new higher-priority route that is tagged only to the appliances with a next hop of the default internet gateway.
3. Create a new route in the spoke VPC that points to IP address 10.0.0.5.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it properly configures the hub to route internet traffic through the virtual appliance (via the internal load balancer IP) and propagates these custom routes to the spokes. Crucially, it mandates deleting the default internet gateway route in the spoke VPCs; without this deletion, Google Cloud's shortest-prefix-match rule would cause direct-to-internet traffic to bypass the hub appliance, violating the security requirement.

Option A is incorrect because it fails to delete the default internet gateway route in the spokes. Even if custom routes are imported, the default route (0.0.0.0/0) pointing directly to the Internet Gateway would still take precedence for general internet traffic, allowing spokes to bypass the hub's virtual appliance.

## Pregunta 137

Contexto: [topics:725](#topics-725)
You configured Cloud VPN with dynamic routing via Border Gateway Protocol (BGP). You added a custom route to advertise a network that is reachable over the VPN tunnel. However, the on-premises clients still cannot reach the network over the VPN tunnel. You need to examine the logs in Cloud Logging to confirm that the appropriate routers are being advertised over the VPN tunnel. Which filter should you use in Cloud Logging to examine the logs?

**A.** resource.type= “gce_router”

**B.** resource.type= “gce_network_region”

**C.** resource.type= “vpn_tunnel”

**D.** resource.type= “vpn_gateway”

**Respuesta de la fuente:** A

**Explicación:** In Cloud VPN with dynamic routing, the Cloud Router (Cloud Router) manages BGP sessions and is responsible for advertising routes.
Therefore, to verify which routes are being advertised over the VPN tunnel, you must query logs from the 'gce_router' resource type.
The 'vpn_gateway' and 'vpn_tunnel' resources log connection status and traffic metrics, but not specific BGP route advertisements.

## Pregunta 138

Contexto: [topics:725](#topics-725)
Your company has a single Virtual Private Cloud (VPC) network deployed in Google Cloud with access from on-premises locations using Cloud Interconnect connections. Your company must be able to send traffic to Cloud Storage only through the Interconnect links while accessing other Google APIs and services over the public internet. What should you do?

**A.** Use the default public domains for all Google APIs and services.

**B.** Use Private Service Connect to access Cloud Storage, and use the default public domains for all other Google APIs and services.

**C.** Use Private Google Access, with restricted.googleapis.com virtual IP addresses for Cloud Storage and private.googleapis.com for all other Google APIs and services.

**D.** Use Private Google Access, with private.googleapis.com virtual IP addresses for Cloud Storage and restricted.googleapis.com virtual IP addresses for all other Google APIs and services.

**Respuesta de la fuente:** B

**Explicación:** Option B is the correct choice because Private Service Connect (PSC) allows you to create private endpoints for specific Google services like Cloud Storage, ensuring that traffic to those services stays within the VPC and exits via Cloud Interconnect rather than the public internet. By using PSC for Cloud Storage and leaving other services on their default public domains, you achieve the required split-path routing: private/interconnect for storage and public internet for everything else.

The most tempting alternative, Option C, suggests using Private Google Access with restricted.googleapis.com, but this would route *all* specified Google API traffic (including other APIs if configured) through Interconnect or private networks, failing the requirement to access 'other Google APIs and services over the public internet.' Additionally, while Private Google Access can be scoped, PSC provides a more direct mechanism for forcing specific service traffic through a private endpoint while leaving other DNS resolutions (default public domains) untouched for public internet egress.

## Pregunta 139

Contexto: [topics:725](#topics-725)
Your organization has a Google Cloud Virtual Private Cloud (VPC) with subnets in us-east1, us-west4, and europe-west4 that use the default VPC configuration. Employees in a branch office in Europe need to access the resources in the VPC using HA VPN. You configured the HA VPN associated with the Google Cloud VPC for your organization with a Cloud Router deployed in europe-west4. You need to ensure that the users in the branch office can quickly and easily access all resources in the VPC. What should you do?

**A.** Create custom advertised routes for each subnet.

**B.** Configure each subnet’s VPN connections to use Cloud VPN to connect to the branch office.

**C.** Configure the VPC dynamic routing mode to Global.

**D.** Set the advertised routes to Global for the Cloud Router.

**Respuesta de la fuente:** C

**Explicación:** The Cloud Router is deployed in europe-west4, and by default, a VPC's dynamic routing mode is Regional. This means the router only learns and advertises routes for subnets within that specific region, preventing direct access to resources in us-east1 or us-west4 via HA VPN without complex manual configurations.

Setting the VPC dynamic routing mode to Global ensures that the Cloud Router automatically advertises routes for all subnets across all regions to the on-premises peer, allowing the branch office to access any resource in the VPC immediately and easily.

## Pregunta 140

Contexto: [topics:725](#topics-725)
Your organization uses a Shared VPC architecture with a host project and three service projects. You have Compute Engine instances that reside in the service projects. You have critical workloads in your on-premises data center. You need to ensure that the Google Cloud instances can resolve on-premises hostnames via the Dedicated Interconnect you deployed to establish hybrid connectivity. What should you do?

**A.** 1. Create a Cloud DNS private forwarding zone in the host project of the Shared VPC that forwards the private zone to the on-premises DNS servers.
2. In your Cloud Router, add a custom route advertisement for the IP 35.199.192.0/19 to the on-premises environment.

**B.** 1. Create a Cloud DNS private forwarding zone in the host project of the Shared VPC that forwards the Private zone to the on-premises DNS servers.
2. In your Cloud Router, add a custom route advertisement for the IP 169.254 169.254 to the on-premises environment.

**C.** 1. Configure a Cloud DNS private zone in the host project of the Shared VPC.
2. Set up DNS forwarding to your Google Cloud private zone on your on-premises DNS servers to point to the inbound forwarder IP address in your host project
3. In your Cloud Router, add a custom route advertisement for the IP 169.254 169 254 to the on-premises environment.

**D.** 1.Configure a Cloud DNS private zone in the host project of the Shared VPC.
2. Set up DNS forwarding to your Google Cloud private zone on your on-premises DNS servers to point to the inbound forwarder IP address in your host project.
3. Configure a DNS policy in the Shared VPC to allow inbound query forwarding with your on-premises DNS server as the alternative DNS server.

**Respuesta de la fuente:** A

**Explicación:** To resolve on-premises hostnames from Google Cloud instances, you must create a Cloud DNS private forwarding zone in the host project. This zone forwards queries for the specific domain to your on-premises DNS servers.

Crucially, for these forwarded queries to reach the on-premises network via Dedicated Interconnect, the source IP addresses of Cloud DNS (specifically 35.199.192.0/19) must be advertised into your on-premises routing table via Custom Route Advertisement in Cloud Router. This ensures return traffic for DNS responses is routed correctly back to Google Cloud.

## Pregunta 141

Contexto: [topics:725](#topics-725)
Your organization is implementing a new security policy to control how firewall rules are applied to control flows between virtual machines (VMs). Using Google-recommended practices, you need to set up a firewall rule to enforce strict control of traffic between VM A and VM B. You must ensure that communications flow only from VM A to VM B within the VPC, and no other communication paths are allowed. No other firewall rules exist in the VPC. Which firewall rule should you configure to allow only this communication path?

**A.** Firewall rule direction: ingress

Action: allow -

Target: VM B service account -
Source ranges: VM A service account
Priority: 1000

**B.** Firewall rule direction: ingress

Action: allow -

Target: specific VM B tag -
Source ranges: VM A tag and VM A source IP address
Priority: 1000

**C.** Firewall rule direction: ingress

Action: allow -

Target: VM A service account -
Source ranges: VM B service account and VM B source IP address
Priority: 100

**D.** Firewall rule direction: ingress

Action: allow -

Target: specific VM A tag -
Source ranges: VM B tag and VM B source IP address
Priority: 100

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because GCP best practices recommend using service accounts over network tags for stricter identity-based control of firewall rules. Additionally, an ingress rule must target the destination VM (VM B) to allow traffic arriving at it. Option B is incorrect because including a source IP address creates an OR condition with the tag filter, potentially allowing unintended sources if IPs are recycled or reassigned.

## Pregunta 142

Contexto: [topics:725](#topics-725)
You have configured a service on Google Cloud that connects to an on-premises service via a Dedicated Interconnect. Users are reporting recent connectivity issues. You need to determine whether the traffic is being dropped because of firewall rules or a routing decision. What should you do?

**A.** Use the Network Intelligence Center Connectivity Tests to test the connectivity between the VPC and the on-premises network.

**B.** Use Network Intelligence Center Network Topology to check the traffic flow, and replay the traffic from the time period when the connectivity issue occurred.

**C.** Configure VPC Flow Logs. Review the logs by filtering on the source and destination.

**D.** Configure a Compute Engine instance on the same VPC as the service running on Google Cloud to run a traceroute targeted at the on-premises service.

**Respuesta de la fuente:** A

**Explicación:** Network Intelligence Center (NIC) Connectivity Tests are the definitive tool for simulating traffic and determining if connectivity issues stem from firewall rules or routing decisions.
Unlike VPC Flow Logs, which require pre-configuration and only record past events, NIC provides on-demand simulation to isolate the specific cause of packet drops.
While Network Topology visualizes connections, it does not provide the granular failure analysis (e.g., specific firewall deny vs. route missing) required by the question.

## Pregunta 143

Contexto: [topics:725](#topics-725)
You are configuring a new HTTP application that will be exposed externally behind both IPv4 and IPv6 virtual IP addresses, using ports 80, 8080, and 443. You will have backends in two regions: us-west1 and us-east1. You want to serve the content with the lowest-possible latency while ensuring high availability and autoscaling, and create native content-based rules using the HTTP hostname and request path. The IP addresses of the clients that connect to the load balancer need to be visible to the backends. Which configuration should you use?

**A.** Use Network Load Balancing

**B.** Use TCP Proxy Load Balancing with PROXY protocol enabled

**C.** Use External HTTP(S) Load Balancing with URL Maps and custom headers

**D.** Use External HTTP(S) Load Balancing with URL Maps and an X-Forwarded-For header

**Respuesta de la fuente:** D

**Explicación:** External HTTP(S) Load Balancing is the correct choice because it supports Layer 7 features like URL maps for content-based routing and native IPv4/IPv6 dual-stack support. It automatically preserves client IP addresses via the X-Forwarded-For header, which backends can read to identify the original requester. Network or TCP load balancers (Options A and B) operate at Layer 4 and cannot perform HTTP-specific content-based routing using hostnames or paths.

## Pregunta 144

Contexto: [topics:725](#topics-725)
Your team is developing an application that will be used by consumers all over the world. Currently, the application sits behind a global external application load balancer. You need to protect the application from potential application-level attacks. What should you do?

**A.** Enable Cloud CDN on the backend service.

**B.** Create multiple firewall deny rules to block malicious users, and apply them to the global external application load balancer.

**C.** Create a Google Cloud Armor security policy with web application firewall rules, and apply the security policy to the backend service

**D.** Create a VPC Service Controls perimeter with the global external application load balancer as the protected service, and apply it to the backend service.

**Respuesta de la fuente:** C

**Explicación:** Google Cloud Armor is the dedicated Web Application Firewall (WAF) service designed to protect applications from application-layer attacks such as SQL injection and XSS by filtering malicious traffic before it reaches backend instances.
Firewall rules (Option B) operate at network/transport layers (L3/L4) and cannot inspect application payloads, while Cloud CDN (Option A) optimizes content delivery rather than providing security filtering.
VPC Service Controls (Option D) prevent data exfiltration between services but do not mitigate external web exploits.

## Pregunta 145

Contexto: [topics:725](#topics-725)
You are reviewing and tuning Secure Web Proxy at your organization, Mount Kirk Games. Users have reported that they are unable to reach the documents they need on the Terram Earth website (https://www.terramearth.com/docs/*). The Secure Web Proxy rules configuration is as follows:

[Imagen: sin descripción]

You need to enable access to these documents. What should you do?
Imagen · question_text · sin descripción
![Imagen original](imagenes/2631b17316bef0727f4f.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Rule Name PriorityActionTLS InspectionSession/Host Match
core-rulel 1000
updates-1 1002
updates-limiter1050
allow-tf-sre 1110
ALLOW FALSE
ALLOW FALSE
DENY FAL!
ALLOW TRUE
host () .contains (mountkirkgames.com')
host ().contains('terramearth.com') AND request.path.contains('/docs/')
host () contains ('terramearth.com')
host ().contains('github.com') AND request.path.contains('/fast/stages/')
```

**A.** Delete the updates-limiter rule.

**B.** Modify the updates-1 rule to perform the TLS inspection.

**C.** Review Cloud Logging for errors with Cloud NAT. If there are no errors, assign the VM a public IP address.

**D.** Modify the priority of the updates-limiter rule to 1000.

**Respuesta de la fuente:** B

**Explicación:** Secure Web Proxy rules are only evaluated for HTTPS traffic if the 'Perform TLS inspection' option is explicitly enabled for that rule. Since the target URL uses HTTPS and the 'updates-1' rule (which matches the domain) likely lacks this setting, it is being skipped entirely.
Therefore, modifying the rule to enable TLS inspection ensures the proxy evaluates the allow policy correctly.

## Pregunta 146

Contexto: [topics:725](#topics-725)
You are responsible for designing a new connectivity solution for your organization's enterprise network to access and use Google Workspace. You have an existing Shared VPC with Compute Engine instances in us-west1. Currently, you access Google Workspace via your service provider's internet access. You want to set up a direct connection between your network and Google. What should you do?

**A.** Order a Dedicated Interconnect connection in the same metropolitan area. Create a VLAN attachment, a Cloud Router in us-west1, and a Border Gateway Protocol (BGP) session between your Cloud Router and your router.

**B.** Order a Direct Peering connection in the same metropolitan area. Configure a Border Gateway Protocol (BGP) session between Google and your router.

**C.** Configure HA VPN in us-west1. Configure a Border Gateway Protocol (BGP) session between your Cloud Router and your on-premises data center.

**D.** Order a Carrier Peering connection in the same metropolitan area. Configure a Border Gateway Protocol (BGP) session between Google and your router.

**Respuesta de la fuente:** B

**Explicación:** Direct Peering is the recommended solution for connecting on-premises networks to SaaS applications like Google Workspace because it connects to Google's public infrastructure outside of the VPC. Dedicated Interconnect (A) is designed for private access to Google Cloud services (IaaS/PaaS), while HA VPN (C) uses the public internet, failing the requirement for a direct connection. Carrier Peering (D) is typically managed by ISPs rather than directly by the enterprise.

## Pregunta 147

Contexto: [topics:725](#topics-725)
You suspect that one of the virtual machines (VMs) in your default Virtual Private Cloud (VPC) is under a denial-of-service attack. You need to analyze the incoming traffic for the VM to understand where the traffic is coming from. What should you do?

**A.** Enable Data Access audit logs of the VPC. Analyze the logs and get the source IP addresses from the subnetworks.get field.

**B.** Enable VPC Flow Logs for the subnet. Analyze the logs and get the source IP addresses from the connection field.

**C.** Enable VPC Flow Logs for the VPAnalyze the logs and get the source IP addresses from the src_location field.

**D.** Enable Data Access audit logs of the subnet. Analyze the logs and get the source IP addresses from the networks.get field.

**Respuesta de la fuente:** B

**Explicación:** VPC Flow Logs capture network flow data, including source and destination IP addresses and ports, which is necessary to identify the origin of a DDoS attack.
Audit logs (Options A and D) track configuration changes or resource access, not network traffic patterns.
The 'connection' field in VPC Flow Logs contains the specific IP details required, whereas 'src_location' only provides geographic metadata.

## Pregunta 148

Contexto: [topics:725](#topics-725)
You are responsible for configuring firewall policies for your company in Google Cloud. Your security team has a strict set of requirements that must be met to configure firewall rules.

•	Always allow Secure Shell (SSH) from your corporate IP address.
•	Restrict SSH access from all other IP addresses.

There are multiple projects and VPCs in your Google Cloud organization. You need to ensure that other VPC firewall rules cannot bypass the security team’s requirements. What should you do?

**A.** 1. Configure a hierarchical firewall policy to the organization node to allow TCP port 22 for your corporate IP address with priority 0.
2. Configure a hierarchical firewall policy to the organization node to deny TCP port 22 for all IP addresses with priority 1.

**B.** 1. Configure a VPC firewall rule to allow TCP port 22 for your corporate IP address with priority 0.
2. Configure a VPC firewall rule to deny TCP port 22 for all IP addresses with priority 1.

**C.** 1. Configure a VPC firewall rule to allow TCP port 22 for your corporate IP address with priority 1.
2. Configure a VPC firewall rule to deny TCP port 22 for all IP addresses with priority 0.

**D.** 1. Configure a hierarchical firewall policy to the organization node to allow TCP port 22 for your corporate IP address with priority 1
2. Configure a hierarchical firewall policy to the organization node to deny TCP port 22 for all IP addresses with priority 0.

**Respuesta de la fuente:** A

**Explicación:** Hierarchical firewall policies are required to enforce rules across multiple projects and VPCs centrally, preventing local VPC rules from bypassing the security mandate. In GCP firewall evaluation, lower priority numbers take precedence; therefore, assigning priority 0 to the allow rule ensures corporate SSH access is permitted even if a higher-numbered deny-all rule (priority 1) exists.

## Pregunta 149

Contexto: [topics:725](#topics-725)
You are designing a new application that has backends internally exposed on port 800. The application will be exposed externally using both IPv4 and IPv6 via TCP on port 700. You want to ensure high availability for this application. What should you do?

**A.** Create a network load balancer that used backend services containing one instance group with two instances.

**B.** Create a network load balancer that uses a target pool backend with two instances.

**C.** Create a TCP proxy that uses a zonal network endpoint group containing one instance.

**D.** Create a TCP proxy that uses backend services containing an instance group with two instances.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because a TCP Proxy load balancer supports both IPv4 and IPv6 external traffic and allows port translation (forwarding from frontend port 700 to backend port 800), which a Network Load Balancer (Options A and B) cannot do as it is pass-through. Additionally, using an instance group with two instances satisfies the high availability requirement, whereas Option C uses a zonal endpoint group that may not provide sufficient redundancy compared to a managed instance group.

## Pregunta 150

Contexto: [topics:725](#topics-725)
You have several microservices running in a private subnet in an existing Virtual Private Cloud (VPC). You need to create additional serverless services that use Cloud Run and Cloud Functions to access the microservices. The network traffic volume between your serverless services and private microservices is low. However, each serverless service must be able to communicate with any of your microservices. You want to implement a solution that minimizes cost. What should you do?

**A.** Deploy your serverless services to the serverless VPC. Peer the serverless service VPC to the existing VPC. Configure firewall rules to allow traffic between the serverless services and your existing microservices.

**B.** Create a serverless VPC access connector for each serverless service. Configure the connectors to allow traffic between the serverless services and your existing microservices.

**C.** Deploy your serverless services to the existing VPConfigure firewall rules to allow traffic between the serverless services and your existing microservices.

**D.** Create a serverless VPC access connector. Configure the serverless service to use the connector for communication to the microservices.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because a Serverless VPC Access connector allows multiple serverless services to share a single connection point to the VPC, minimizing cost compared to creating separate connectors for each service (Option B).

Serverless platforms like Cloud Run and Cloud Functions cannot be directly deployed into a standard VPC subnet (Option C), making them incompatible with private microservices without a connector. Option A is incorrect because Serverless VPC Access replaces the older, more complex VPC peering approach for this specific use case.

## Pregunta 151

Contexto: [topics:725](#topics-725)
You have provisioned a Dedicated Interconnect connection of 20 Gbps with a VLAN attachment of 10 Gbps. You recently noticed a steady increase in ingress traffic on the Interconnect connection from the on-premises data center. You need to ensure that your end users can achieve the full 20 Gbps throughput as quickly as possible. Which two methods can you use to accomplish this? (Choose two.)

**A.** Configure an additional VLAN attachment of 10 Gbps in another region. Configure the on-premises router to advertise routes with the same multi-exit discriminator (MED).

**B.** Configure an additional VLAN attachment of 10 Gbps in the same region. Configure the on-premises router to advertise routes with the same multi-exit discriminator (MED).

**C.** From the Google Cloud Console, modify the bandwidth of the VLAN attachment to 20 Gbps.

**D.** From the Google Cloud Console, request a new Dedicated Interconnect connection of 20 Gbps, and configure a VLAN attachment of 10 Gbps.

**E.** Configure Link Aggregation Control Protocol (LACP) on the on-premises router to use the 20-Gbps Dedicated Interconnect connection.

**Respuesta de la fuente:** B, C

**Explicación:** Option B is correct because adding a second 10 Gbps VLAN attachment in the same region allows for Equal-Cost Multi-Path (ECMP) routing, aggregating the total throughput to 20 Gbps when routes have the same MED. Option C is correct because Google Cloud Dedicated Interconnect supports modifying an existing VLAN attachment's bandwidth capacity up to 50 Gbps without recreating the connection, enabling you to scale the single attachment to 20 Gbps. Option A is incorrect because cross-region attachments introduce latency and complexity that do not serve as a direct replacement for local throughput aggregation in this context.

## Pregunta 152

Contexto: [topics:725](#topics-725)
Your company has a Virtual Private Cloud (VPC) with two Dedicated Interconnect connections in two different regions: us-west1 and us-east1. Each Dedicated Interconnect connection is attached to a Cloud Router in its respective region by a VLAN attachment. You need to configure a high availability failover path. By default, all ingress traffic from the on-premises environment should flow to the VPC using the us-west1 connection. If us-west1 is unavailable, you want traffic to be rerouted to us-east1. How should you configure the multi-exit discriminator (MED) values to enable this failover path?

**A.** Use regional routing. Set the us-east1 Cloud Router to a base priority of 100, and set the us-west1 Cloud Router to a base priority of 1

**B.** Use global routing. Set the us-east1 Cloud Router to a base priority of 100, and set the us-west1 Cloud Router to a base priority of 1

**C.** Use regional routing. Set the us-east1 Cloud Router to a base priority of 1000, and set the us-west1 Cloud Router to a base priority of 1

**D.** Use global routing. Set the us-east1 Cloud Router to a base priority of 1000, and set the us-west1 Cloud Router to a base priority of 1

**Respuesta de la fuente:** D

**Explicación:** Global routing is required because the Cloud Routers are in different regions (us-west1 and us-east1), allowing routes to be shared across regions. To ensure traffic prefers us-west1, it must have a lower base priority (1). The backup path via us-east1 must have a higher priority to be selected only upon failure; since inter-region routing adds at least 200 to the local priority, setting us-east1's base priority to 1000 ensures its advertised route (1000 + 200 = 1200) is significantly less preferred than the direct us-west1 route (priority 1), creating a stable failover hierarchy.

## Pregunta 153

Contexto: [topics:725](#topics-725)
You have the following private Google Kubernetes Engine (GKE) cluster deployment:

[Imagen: sin descripción]

You have a virtual machine (VM) deployed in the same VPC in the subnetwork kubernetes-management with internal IP address 192.168.40 2/24 and no external IP address assigned. You need to communicate with the cluster master using kubectl. What should you do?
Imagen · question_text · sin descripción
![Imagen original](imagenes/d96a7005836cd900901b.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
gcloud container clusters describe customer-i-cluster --zone us-centrali-c
clusterIpvécidr: 192.168.36.0/24
endpoint: 192.168.38.2
ipAllocationPolicy:
clusterIpvécidr: 192.168.36.0/24
clusterIpv4CidrBlock: 192.168.36.0/24
clusterSecondaryRangeName: customer-1-pods
servicesipv4cidr: 192.168.37.0/24
servicesIp4CidrBlock: 192.168.37.0/24
servicesSecondaryRangeName: customer-1-svc
useIpAliases: true
masterAuthorizedNetworksConfig:
privateClusterConfi
enablePrivateEndpoint: true
enablePrivateNodes: true
masterIpv4CidrBlock: 192.168.38.0/28
privateEndpoint: 192.168.38.2
publicEndpoint: 35.224.37.17
subnetwork: customer-1-nodes
zone: us-centrall-c
```

**A.** Add the network 192.168.40.0/24 to the masterAuthorizedNetworksConfig. Configure kubectl to communicate with the endpoint 192.168.38.2.

**B.** Add the network 192.168.38.0/28 to the masterAuthorizedNetworksConfig. Configure kubectl to communicate with the endpoint 192.168.38.2

**C.** Add the network 192.168.36.0/24 to the masterAuthorizedNetworksConfig. Configure kubectl to communicate with the endpoint 192.168.38.2

**D.** Add an external IP address to the VM, and add this IP address in the masterAuthorizedNetworksConfig. Configure kubectl to communicate with the endpoint 35.224.37.17.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because `masterAuthorizedNetworksConfig` restricts access to the GKE control plane API server by IP address, requiring the client's source IP range (192.168.40.0/24) to be whitelisted. The endpoint for a private cluster is its internal IP address (192.168.38.2), allowing communication over the VPC without needing external IPs. Other options are incorrect because they either whitelist the wrong IP range or suggest using an external IP, which defeats the purpose of a private cluster.

## Pregunta 154

Contexto: [topics:725](#topics-725)
Your company's logo is published as an image file across multiple websites that are hosted by your company. You have implemented Cloud CDN; however, you want to improve the performance of the cache hit ratio associated with this image file. What should you do?

**A.** Configure custom cache keys for the backend service that holds the image file, and clear the Host and Protocol checkboxes.

**B.** Configure the default time to live (TTL) as 0 for the image file.

**C.** Configure versioned URLs for each domain to serve users the image file before the cache entry expires.

**D.** Configure Cloud Storage as a custom origin backend to host the image file, and select multi-region as the location type.

**Respuesta de la fuente:** A

**Explicación:** Cloud CDN defaults to using the full request URL (including Host and Protocol) as the cache key, which causes separate cache entries for the same resource served across different domains. By configuring custom cache keys and clearing the Host and Protocol checkboxes, you consolidate these requests into a single cache entry, significantly improving the cache hit ratio for shared assets like a company logo.
Option B is incorrect because setting TTL to 0 disables caching entirely; Option D addresses storage location rather than cache key logic.

## Pregunta 155

Contexto: [topics:725](#topics-725)
Your company recently migrated to Google Cloud in a single region. You configured separate Virtual Private Cloud (VPC) networks for two departments: Department A and Department B. Department A has requested access to resources that are part of Department B's VPC. You need to configure the traffic from private IP addresses to flow between the VPCs using multi-NIC virtual machines (VMs) to meet security requirements. Your configuration also must:

•	Support both TCP and UDP protocols
•	Provide fully automated failover
•	Include health-checks
•	Require minimal manual intervention in the client VMs

Which approach should you take?

**A.** Create the VMs in the same zone, and configure static routes with IP addresses as next hops.

**B.** Create the VMs in different zones, and configure static routes with instance names as next hops.

**C.** Create an instance template and a managed instance group. Configure a single internal load balancer, and define a custom static route with the internal TCP/UDP load balancer as the next hop.

**D.** Create an instance template and a managed instance group. Configure two separate internal TCP/UDP load balancers for each protocol (TCP/UDP), and configure the client VMs to use the internal load balancers’ virtual IP addresses.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because a single Internal TCP/UDP Load Balancer can be configured to support both TCP and UDP protocols simultaneously via its frontend settings, satisfying the protocol requirement without needing separate resources. Using a Managed Instance Group with this load balancer ensures automated failover, health checks, and minimal client-side intervention when combined with a custom static route pointing to the load balancer's IP.

Option D is incorrect because it proposes configuring two separate load balancers (one for TCP, one for UDP), which adds unnecessary complexity and deviates from the most efficient architecture that supports both protocols in a single instance.

## Pregunta 156

Contexto: [topics:725](#topics-725)
You are designing an IP address scheme for new private Google Kubernetes Engine (GKE) clusters. Due to IP address exhaustion of the RFC 1918 address space in your enterprise, you plan to use privately used public IP space for the new clusters. You want to follow Google-recommended practices. What should you do after designing your IP scheme?

**A.** Create the minimum usable RFC 1918 primary and secondary subnet IP ranges for the clusters. Re-use the secondary address range for the pods across multiple private GKE clusters.

**B.** Create the minimum usable RFC 1918 primary and secondary subnet IP ranges for the clusters, Re-use the secondary address range for the services across multiple private GKE clusters.

**C.** Create privately used public IP primary and secondary subnet ranges for the clusters. Create a private GKE cluster with the following options selected: --enable-ip-alias and --enable-private-nodes.

**D.** Create privately used public IP primary and secondary subnet ranges for the clusters. Create a private GKE cluster with the following options selected: --disable-default-snat, --enable-ip-alias, and --enable-private-nodes.

**Respuesta de la fuente:** D

**Explicación:** When using Privately Used Public IP (PUPIS) space in GKE, you must disable the default Source Network Address Translation (SNAT) to prevent traffic destined for these public IPs from being NATted by the nodes, which would break connectivity.
Option D correctly includes --disable-default-snat along with --enable-ip-alias and --enable-private-nodes, adhering to Google's best practices for this specific configuration.
Option C is incorrect because it omits the critical --disable-default-snat flag required when using PUPIS.

## Pregunta 157

Contexto: [topics:725](#topics-725)
You want Cloud CDN to serve the https://www.example.com/images/spacetime.png static image file that is hosted in a private Cloud Storage bucket. You are using the USE_ORIGIN_HEADERS cache mode. You receive an HTTP 403 error when opening the file in your browser, and you see that the HTTP response has a Cache-Control: private, max-age=0 header. How should you correct this issue?

**A.** Enable negative caching for the backend bucket.

**B.** Change the cache mode to Force cache all content.
C Configure a Cloud Storage bucket permission that gives allUsers the Storage Legacy Object Reader role.

**D.** Increase the default time-to-live (TTL) for the backend service.

**Respuesta de la fuente:** B

**Explicación:** The issue arises because Cloud CDN in USE_ORIGIN_HEADERS mode respects the Cache-Control: private header from the backend, which prevents caching and subsequent delivery for unauthorized requests or when headers explicitly forbid it. Changing the cache mode to 'Force cache all content' overrides these restrictive headers, allowing Cloud CDN to cache and serve the file regardless of the origin's Cache-Control directives.
Option C (granting public access) is incorrect because it exposes private data to the internet, violating security best practices and the requirement for a private bucket.

## Pregunta 158

Contexto: [topics:725](#topics-725)
You are deploying an application that runs on Compute Engine instances. You need to determine how to expose your application to a new customer. You must ensure that your application meets the following requirements:

•	Maps multiple existing reserved external IP addresses to the instance
•	Processes IP Encapsulating Security Payload (ESP) traffic

What should you do?

**A.** Configure a target pool, and create protocol forwarding rules for each external IP address.

**B.** Configure a backend service, and create an external network load balancer for each external IP address.

**C.** Configure a target instance, and create a protocol forwarding rule for each external IP address to be mapped to the instance.

**D.** Configure the Compute Engine instances’ network interface external IP address from None to Ephemeral. Add as many external IP addresses as required.

**Respuesta de la fuente:** C

**Explicación:** Protocol forwarding is the correct solution for mapping specific external IP addresses to a Compute Engine instance while preserving the original destination IP, which is required for handling ESP (IPsec) traffic. This configuration requires creating a target instance object that references the VM and establishing separate protocol forwarding rules for each reserved external IP address.

Option A is incorrect because protocol forwarding rules must point to a target instance, not a target pool, as they are designed to deliver packets to a single specific instance rather than distributing load across multiple backends.

## Pregunta 159

Contexto: [topics:725](#topics-725)
Your product team has web servers running on both us-east1 and us-west1 regions in the prod-servers project. Your security team plans to install an intrusion detection system (IDS) in their own Google Cloud project to inspect the incoming network traffic. What should you do?

**A.** Create a new project and a VPC for the security team.
Peer the new VPC with the web servers’ VPC in the prod-servers project.
Create an internal load balancer and the IDS system in both us-east1 and us-west1.
Enable Packet Mirroring, and create packet mirroring policies inside the new project.

**C.** Create a host project and a Sharad VPC for the security team.
Make prod-servers a service project, and relocate the web servers to shared subnets in both regions.
Enable IP forwarding on all the web servers.
Create the IDS system in a non-shared subnet of us-east1 or us-west1.
Configure the web servers to forward the packets to the IDS system.
C. Create a new project and a VPC for the security team.
Peer the new VPC with the web servers’ VPC in the prod-servers project.
Enable IP forwarding on all the web servers.
Install the IDS system in both us-east1 and us-west1.
Configure the web servers to forward the packets to the IDS system.

**D.** Create a host project and a Shared VPC for the security team.
Make prod-servers a service project, and relocate the web servers to shared subnets in both regions.
Create an internal load balancer and the IDS system in a subnet in either us-east1 or us-west1.
Enable Packet Mirroring, and create a packet mirroring policy inside the host project.

**Respuesta de la fuente:** A

**Explicación:** The requirement specifies that the security team will install the IDS in 'their own Google Cloud project,' which necessitates keeping the projects separate rather than using a Shared VPC setup where resources might be colocated or managed differently. Option A correctly creates a new independent project and uses VPC peering to allow the security team's IDS to inspect traffic via Packet Mirroring, satisfying the isolation requirement. Options involving Shared VPC (D) or manual packet forwarding (C) contradict the constraint of using a distinct project structure or introduce unnecessary complexity not aligned with standard GCP best practices for this specific scenario.

## Pregunta 160

Contexto: [topics:725](#topics-725)
You are in the process of deploying an internal HTTP(S) load balancer for your web server virtual machine (VM) instances. What two prerequisite tasks must be completed before creating the load balancer? (Choose two.)

**A.** Choose a region.

**B.** Create firewall rules for health checks.

**C.** Reserve a static IP address for the load balancer.

**D.** Determine the subnet mask for a proxy-only subnet.

**E.** Determine the subnet mask for Serverless VPC Access.

**Respuesta de la fuente:** B, D

**Explicación:** For an Internal HTTP(S) load balancer on Google Cloud, you must configure a proxy-only subnet in each region where the load balancer is deployed to host the proxy instances (D). Additionally, firewall rules are required to allow health check probes from Google’s health checking system and traffic from the proxy IPs to reach the backend VMs (B). Choosing a specific region (A) is not strictly a separate prerequisite task distinct from configuring the subnets within that VPC context, as the configuration inherently targets specific regions. Reserving a static IP (C) is optional, and Serverless VPC Access (E) is unrelated to standard HTTP(S) load balancing.

## Pregunta 161

Contexto: [topics:725](#topics-725)
You have the networking configuration shown in the diagram. A pair of redundant Dedicated Interconnect connections (int-Iga1 and int-Iga2) terminate on the same Cloud Router. The Interconnect connections terminate on two separate on-premises routers. You are advertising the same prefixes from the Border Gateway Protocol (BGP) sessions associated with the Dedicated Interconnect connections. You need to configure one connection as Active for both ingress and egress traffic. If the active Interconnect connection falls, you want the passive Interconnect connection to automatically begin routing all traffic. Which two actions should you take to meet this requirement? (Choose two.)

[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/b64f2bb88468f252e2c5.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
‘ ‘Colocation facility zone-1
'
vpc1(VPC network)! 4 ww Google Intigat On-premises
H Peering Edge router
us-centralt H a a
: ‘Colocation facility zone-2 | -—
i I
i | gg Google Int
i © Peering Edge :
'
```

**A.** Configure the advertised route priority as 200 for the BGP session associated with the active interconnect connection.

**B.** Configure the advertised route priority > 10,200 on the active Interconnect connection.

**C.** Advertise a lower MED on the active Interconnect connection from the on-premises router.

**D.** Advertise a lower MED on the passive Interconnect connection from the on-premises router.

**E.** Configure the advertised route priority as 200 for the BGP session associated with the passive Interconnect connection.

**Respuesta de la fuente:** C, E

**Explicación:** To control egress traffic (leaving Google Cloud), you must configure the BGP advertised route priority on the Cloud Router. A lower priority value is preferred, so keeping the active link at default 100 and setting the passive link to 200 (Option E) ensures the active path is used.
To control ingress traffic (entering Google Cloud from on-premises), you must manipulate the Multi-Exit Discriminator (MED). Since a lower MED is preferred by the remote router, advertising a lower MED on the active connection (Option C) directs inbound traffic to that link.

## Pregunta 162

Contexto: [topics:725](#topics-725)
You are a network administrator at your company planning a migration to Google Cloud and you need to finish the migration as quickly as possible. To ease the transition, you decided to use the same architecture as your on-premises network: a hub-and-spoke model. Your on-premises architecture consists of over 50 spokes. Each spoke does not have connectivity to the other spokes, and all traffic is sent through the hub for security reasons. You need to ensure that the Google Cloud architecture matches your on-premises architecture. You want to implement a solution that minimizes management overhead and cost, and uses default networking quotas and limits. What should you do?

**A.** Connect all the spokes to the hub with Cloud VPN.

**B.** Connect all the spokes to the hub with VPC Network Peering.

**C.** Connect all the spokes to the hub with Cloud VPN. Use a third-party network appliance as a default gateway to prevent connectivity between the spokes.

**D.** Connect all the spokes to the hub with VPC Network Peering. Use a third-party network appliance as a default gateway to prevent connectivity between the spokes.

**Respuesta de la fuente:** C

**Explicación:** The primary constraint is the VPC Network Peering limit of 25 connections per VPC network. Since the scenario requires connecting 50 spokes to the hub, VPC Peering (Options B and D) exceeds this quota and is technically infeasible without complex workarounds that increase overhead. Option C utilizes Cloud VPN, which scales beyond the peering limit, and employs a third-party appliance to enforce the required isolation between spokes, satisfying both the connectivity and security requirements within standard limits.

## Pregunta 163

Contexto: [topics:725](#topics-725)
You have the networking configuration shown in the diagram. Two VLAN attachments associated with two Dedicated Interconnect connections terminate on the same Cloud Router (mycloudrouter). The Interconnect connections terminate on two separate on-premises routers. You advertise the same prefixes from the Border Gateway Protocol (BGP) sessions associated with each of the VLAN attachments.

You notice an asymmetric traffic flow between the two Interconnect connections. Which of the following actions should you take to troubleshoot the asymmetric traffic flow?

[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/c833128504f16cc8dd00.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Google Cloud
' i
vpc1(VPC network)! \ gw Google Int-tga1) & On-premises *
us-central1 A a
' = User
guzCompute_ ye, Cloud
Engine ~ “* Router °
Colocation facility zone-2 '
i On-premises '
| gq Google tiga router |
|___:_ ™ Peering Edge
BGP session
```

**A.** From the Google Cloud console, navigate to Cloud Logging to view VPC Flow Logs and review the results.

**B.** From the Cloud CLI, run gcloud compute –-project PROJECT_ID routers get-status mycloudrouter –-region REGION and review the results.

**C.** From the Google Cloud console, navigate to the Hybrid Connectivity, select the Cloud Router, and view BGP sessions.

**D.** From the Cloud CLI, run gcloud compute routers describe mycloudrouter –-region REGION and review the results.

**Respuesta de la fuente:** C

**Explicación:** Asymmetric traffic in a multi-homed BGP setup is typically caused by route preference issues (e.g., AS_PATH, Local Preference) or session state anomalies. To troubleshoot this, you must inspect the detailed state of each BGP peer to see which prefixes are active and their attributes. Option C allows you to view these BGP session details directly in the Cloud Console under Hybrid Connectivity. Option A (VPC Flow Logs) shows traffic patterns but does not explain the routing decision causing asymmetry. Option B is syntactically incorrect in its command structure, and Option D only provides static configuration rather than dynamic session state.

## Pregunta 164

Contexto: [topics:725](#topics-725)
You are responsible for designing a new connectivity solution between your organization's on-premises data center and your Google Cloud Virtual Private Cloud (VPC) network. Currently, there is no end-to-end connectivity. You must ensure a service level agreement (SLA) of 99.99% availability. What should you do?

**A.** Use one Dedicated Interconnect connection in a single metropolitan area. Configure one Cloud Router and enable global routing in the VPC.

**B.** Use a Direct Peering connection between your on-premises data center and Google Cloud. Configure Classic VPN with two tunnels and one Cloud Router.

**C.** Use two Dedicated Interconnect connections in a single metropolitan area. Configure one Cloud Router and enable global routing in the VPC.

**D.** Use HA VPN. Configure one tunnel from each interface of the VPN gateway to connect to the corresponding interfaces on the peer gateway on-premises. Configure one Cloud Router and enable global routing in the VPC.

**Respuesta de la fuente:** D

**Explicación:** To achieve a 99.99% availability SLA for on-premises to Google Cloud connectivity, HA VPN is the correct solution among the choices because it provides redundant tunnels and gateways specifically designed to meet this higher reliability standard. Dedicated Interconnect options A and C do not meet the 99.99% SLA requirement; option C (two connections in a single metro) only provides 99.9% availability, while achieving 99.99% with Dedicated Interconnect requires four connections across two different metropolitan areas, which is not listed as an option.

## Pregunta 165

Contexto: [topics:725](#topics-725)
Your company is planning a migration to Google Kubernetes Engine. Your application team informed you that they require a minimum of 60 Pods per node and a maximum of 100 Pods per node. Which Pod per node CIDR range should you use?

**A.** /24

**B.** /25

**C.** /26

**D.** /28

**Respuesta de la fuente:** A

**Explicación:** In Google Kubernetes Engine with IP Aliases (default networking), the CIDR range per node must provide enough IP addresses for the maximum number of pods plus one IP for the node itself. With a maximum of 100 pods, you need at least 101 IPs. A /24 subnet provides 256 total IPs, which accommodates this requirement, whereas a /25 only provides 128 IPs, which might seem sufficient but is often paired with smaller pod counts in standard tables (33-64). However, looking at standard GKE documentation for `--max-pods`, a maximum of 100 pods falls into the range requiring a /24 subnet (supporting up to ~254 pods in modern configurations or specifically mapped ranges like 65-128 requiring /24 in older specific contexts depending on overhead). The most direct mapping from GKE documentation for high pod counts (up to ~200+) uses /24. Specifically, a /24 allows up to 254 usable addresses. A /25 allows 126 usable addresses. Since 100 pods + node IP = 101 IPs is less than 126, /25 *could* work mathematically, but GKE's specific configurable pod CIDR ranges often group 65-128 pods under /24 to allow for efficient block allocation or historical constraints. Actually, the comment table explicitly lists 65-128 pods as /24. Since 100 is in that range, /24 is the documented answer.

## Pregunta 166

Contexto: [topics:725](#topics-725)
You are designing a packet mirroring policy as part of your network security architecture for your gaming workload. Your infrastructure is located in the us-west2 region and deployed across several zones: us-west2-a, us-west2-b, and us-west2-c. The infrastructure is running a web-based application on TCP ports 80 and 443 with other game servers that utilize the UDP protocol. You need to deploy packet mirroring policies and collector instances to monitor web application traffic while minimizing inter-zonal network egress costs.

Following Google-recommended practices, how should you deploy the packet mirroring policies and collector instances?

**A.** Crate three packet mirroring policies: one for each zone. Create one group of collector instances for the us-west2 region. Configure each packet mirroring policy to match traffic for its zone based on instance-tags, and create a filter for TCP traffic.

**B.** Create one packet mirroring policy for the us-west2 region. Create one group of collector instances for the us-west2 region. Configure the packet mirroring policy to match traffic for web server instances based on instance-tags, and create a filter for TCP traffic.

**C.** Create three packet mirroring policies: one for each zone. Create three groups of collector instances: one group for each zone. Configure each policy to match traffic for its zone based on instance-tags, and create a filter for TCP traffic.

**D.** Create three packet mirroring policies: one for each zone. Create three groups of collector instances: one group for each zone. Configure each policy to match traffic for its zone based on subnets, and create a filter for TCP traffic.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because deploying collector instance groups within each specific zone ensures that mirrored traffic does not cross zone boundaries, thereby minimizing inter-zonal egress costs as required. It also correctly uses instance tags to identify web servers (TCP traffic) rather than subnets, providing precise targeting regardless of network topology.

Option B is the most tempting alternative but is incorrect because a single regional collector group would force mirrored traffic from other zones to traverse inter-zonal links, incurring higher egress costs contrary to the optimization goal.

## Pregunta 167

Contexto: [topics:725](#topics-725)
Your company recently migrated to Google Cloud. You configured separate Virtual Private Cloud (VPC) networks for Department A and Department B. You need to configure both VPC networks to have access to the same on-premises location through separate links with full isolation between the VPC networks. Your design must also query on-premises DNS servers from workloads in Google Cloud using conditional forwarding. You want to minimize operational overhead. What should you do?

**A.** Customize the operating system DNS configuration files to target the on-premises DNS servers.

**B.** Keep the different VPC networks from both departments isolated with different on-premises links, and separate Cloud DNS private zones and Cloud DNS forwarding zones.

**C.** Peer Department A's and Department B's VPC networks to have all on-premises connectivity via a single VPC network. Use separate Cloud DNS private zones and Cloud DNS forwarding zones.

**D.** Configure a Cloud DNS Peering zone in Department A's VPC network pointing to Department B's VPC and a Cloud DNS outbound forwarding zone in Department B's VPC network. Use separate on-premises links in each VPC network.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it adheres to Google Cloud best practices for minimizing DNS routing complexity by using a single outbound forwarding zone in one VPC (Department B) while leveraging Cloud DNS peering to share resolution with the other VPC (Department A). This avoids the critical issue where on-premises DNS responses cannot be routed correctly if multiple VPCs forward queries from the same IP range (35.199.192.0/19), as return traffic must match the originating VPC's network context.

## Pregunta 168

Contexto: [topics:725](#topics-725)
You are planning to use Terraform to deploy the Google Cloud infrastructure for your company. The design must meet the following requirements:

•	Each Google Cloud project must represent an internal project that your team will work on.
•	After an internal project is finished, the infrastructure must be deleted.
•	Each internal project must have its own Google Cloud project owner to manage the Google Cloud resources.
•	You have 10-100 projects deployed at a time.

While you are writing the Terraform code, you need to ensure that the deployment is simple and the code is reusable with centralized management.
What should you do?

**A.** Create a single project and single VPC for each internal project.

**B.** Create a single Shared VPC and attach each Google Cloud project as a service project.

**C.** Create a single project and additional VPCs for each internal project.
D.O Create a Shared VPC and service project for each internal project.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it leverages a Single Shared VPC Host Project to centralize network management while attaching multiple service projects for individual internal workloads. This architecture satisfies the requirement for centralized control of networking resources and allows each service project to have its own owner and be deleted independently upon completion.

Option A is incorrect because creating separate VPCs for every project fragments network management, violating the requirement for simple, centralized management across 10-100 projects.

## Pregunta 169

Contexto: [topics:725](#topics-725)
You have the following Shared VPC design. VPC Flow Logs is configured for Subnet-1 in the host VPC. You also want to monitor flow logs for Subnet-2. What should you do?

[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/fd3014f35e6f63a8aa78.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Y Google Cloud
Host project
```

**A.** Configure a VPC Flow Logs filter for Subnet-2 in the host project VPC.

**B.** Configure VPC Flow Logs in the service project VPC for Subnet-2.

**C.** Configure Packet Mirroring in both the host and service project VPCs.

**D.** Configure a firewall rule to permit Subnet-2 IP addresses outbound in the host project VPC.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 170

Contexto: [topics:725](#topics-725)
You are configuring your organization's Google Cloud environment to connect to your on-premises network, which does not support Border Gateway Protocol (BGP). Your on-premises network has 30 CIDR ranges that must be reachable from Google Cloud. Your VPN gateway creates a unique child security association (SA) per CIDR. You must ensure that the 30 CIDR ranges in your on-premises network are reachable from Google Cloud.

Following Google-recommended practices, which two methods can you use to accomplish this? (Choose two.)

**A.** Create a single Cloud VPN tunnel that uses route-based VPN.

**B.** Create a single Cloud VPN tunnel that uses policy-based routing with 30 CIDRs as the remote traffic selectors.

**C.** Create multiple Cloud VPN tunnels that use policy-based routing so that each tunnel has one CIDR block for its local traffic selector and one CIDR block for its remote traffic selector. Connect each tunnel to unique peer IP addresses.

**D.** Create multiple Cloud VPN tunnels that use policy-based routing with 10 CIDR per tunnel as the remote traffic selectors.

**E.** Create multiple Cloud VPN tunnels that use policy-based routing so that each tunnel has one CIDR block for its local traffic selector and one CIDR block for its remote traffic selector. Connect each tunnel to the same peer IP address.

**Respuesta de la fuente:** A, C

**Explicación:** Route-based VPN (Option A) is the recommended approach because it uses 0.0.0.0/0 traffic selectors and dynamically propagates routes, allowing all 30 CIDRs to be reachable without manual configuration of individual SAs.

If policy-based routing must be used due to on-premises limitations, Option C is correct because Google Cloud Classic VPN requires that tunnels connecting to the same gateway peer use unique external IP addresses; splitting the 30 CIDRs across multiple tunnels with one selector per tunnel ensures compatibility and avoids exceeding SA limits per tunnel.

Option B is incorrect because a single policy-based tunnel cannot handle 30 distinct remote traffic selectors efficiently or within standard SA creation logic for this scenario, and Option E is incorrect because multiple tunnels to the same peer IP address on Classic VPN are not supported.

## Pregunta 171

Contexto: [topics:725](#topics-725)
You have two VPCs: VPC A in Project A and VPC B in Project B. The VPCs are peered, and each VPC has VM instances in four zones. You are using the Network Intelligence Center Performance Dashboard to investigate the packet loss for traffic flows that start in VPC A and terminate in VPC B. You need the reported packet loss metric to have at least a 90% confidence level. What should you do?

**A.** Ensure that each zone in each of the VPC networks has at least 10 compute instances. Look in Project A for the reported metric.

**B.** Ensure that each zone in each of the VPC networks has at least 9 compute instances. Look in Project B for the reported metric.

**C.** Ensure that each zone in each of the VPC networks has at least 9 compute instances. Look in Project A for the reported metric.

**D.** Ensure that each zone in each of the VPC networks has at least 10 compute instances. Look in Project B for the reported metric.

**Respuesta de la fuente:** D

**Explicación:** To achieve a 90% confidence level in Network Intelligence Center metrics, the documentation requires at least 2.5 VMs per zone; with 4 zones, this equates to 10 instances (2.5 x 4). Furthermore, for peered VPCs located in different projects, packet loss metrics are reported in the destination project (Project B), not the source.

## Pregunta 172

Contexto: [topics:725](#topics-725)
You are designing a new network infrastructure for your customer in Google Cloud. Your customer requires a connection between two Google Cloud VPCs that must include a VPN tunnel. You want to follow Google-recommended practices while ensuring maximum availability of the connection. Which VPN configuration should you choose?

**A.** Policy-based VPN using Classic VPN between the two Google Cloud VPCs

**B.** Border Gateway Protocol (BGP)-based VPN using Classic VPN between the two Google Cloud VPCs

**C.** Route-based VPN using Classic VPN between the two Google Cloud VPCs

**D.** Border Gateway Protocol (BGP)-based VPN using HA VPN between the two Google Cloud VPCs

**Respuesta de la fuente:** D

**Explicación:** High-Availability (HA) VPN is the Google Cloud-recommended solution for production workloads because it provides active-active tunnels and a higher 99.95% SLA compared to Classic VPN's 99.9%. Using BGP within HA VPN enables dynamic routing, which simplifies network management and ensures automatic failover, thereby maximizing availability as requested. Classic VPN options are considered legacy or less robust for this specific high-availability requirement.

## Pregunta 173

Contexto: [topics:725](#topics-725)
Your company is moving to a hybrid cloud environment and needs to connect two on-premises data centers to Google Cloud. Your company has opted for no service level agreement (SLA) on the Dedicated Interconnect ports. You set up a single Dedicated Interconnect to connect each on-premises data center to Google Cloud: one Dedicated Interconnect in us-east1 and another Dedicated Interconnect in us-west1. You also configured a Cloud Router for each Dedicated Interconnect in each respective region. You now need to configure the Interconnect attachments to provide as much high availability diversity as possible based on this design. What should you do?

**A.** •	Build one VLAN attachment from each Dedicated Interconnect corresponding to the Cloud Router in that region.
•	Enable global routing at the VPC layer.

**B.** •	Build one VLAN attachment from each Dedicated Interconnect corresponding to the Cloud Router in that region.
•	Enable regional routing at the VPC layer.

**C.** •	Build two VLAN attachments from each Dedicated Interconnect: one connecting to the Cloud Router in us-east1, and one connecting to the Cloud Router in us-west1.
•	Enable regional routing at the VPC layer.

**D.** •	Build two VLAN attachments from each Dedicated Interconnect: one connecting to the Cloud Router in us-east1, and one connecting to the Cloud Router in us-west1.
•	Enable global routing at the VPC layer.

**Respuesta de la fuente:** D

**Explicación:** To achieve maximum high availability diversity, you must eliminate single points of failure at both the physical interconnect level and the routing configuration level. By creating two VLAN attachments per Dedicated Interconnect (one for each regional Cloud Router), you ensure that if one Cloud Router or its associated region fails, traffic can still be routed via the other. Enabling global routing ensures that BGP sessions are established with both Cloud Routers, allowing Google Cloud to aggregate routes and provide failover capability across regions, whereas regional routing would limit visibility and redundancy to a single region.

## Pregunta 174

Contexto: [topics:725](#topics-725)
Your company runs an enterprise platform on-premises using virtual machines (VMs). Your internet customers have created tens of thousands of DNS domains pointing to your public IP addresses allocated to the VMs. Typically, your customers hard-code your IP addresses in their DNS records. You are now planning to migrate the platform to Compute Engine and you want to use Bring Your Own IP. You want to minimize disruption to the platform. What should you do?

**A.** Create a VPC and request static external IP addresses from Google Cloud. Assign the IP addresses to the Compute Engine instances. Notify your customers of the new IP addresses so they can update their DNS records.

**B.** Verify ownership of your IP addresses. After the verification, Google Cloud advertises and provisions the IP prefix for you. Assign the IP addresses to the Compute Engine instances.

**C.** Create a VPC with the same IP address range as your on-premises network. Assign the IP addresses to the Compute Engine instances.

**D.** Verify ownership of your IP addresses. Use live migration to import the prefix. Assign the IP addresses to the Compute Engine instances.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 175

Contexto: [topics:725](#topics-725)
You need to create the technical architecture for hybrid connectivity from your data center to Google Cloud. This will be managed by a partner. You want to follow Google-recommended practices for production-level applications. What should you do?

**A.** Ask the partner to install two security appliances in the data center. Configure one VPN connection from each of these devices to Google Cloud, and ensure that the VPN devices on-premises are in separate racks on separate power and cooling systems.

**B.** Configure two Partner Interconnect connections in one metropolitan area (metro). Make sure the Interconnect connections are placed in different metro edge availability domains. Configure two VLAN attachments in a single region, and configure regional dynamic routing on the VPC.

**C.** Configure two Partner Interconnect connections in one metro and two connections in another metro. Make sure the Interconnect connections are placed in different metro edge availability domains. Configure two VLAN attachments in one region and two VLAN attachments in another region, and configure global dynamic routing on the VPC.

**D.** Configure two Partner Interconnect connections in one metro and two connections in another metro. Make sure the Interconnect connections are placed in different metro edge availability domains. Configure two VLAN attachments in one region and two VLAN attachments in another region, and configure regional dynamic routing on the VPC.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google recommends a multi-region architecture for production hybrid connectivity to maximize resilience against regional outages.
This setup achieves high availability by distributing Partner Interconnect connections across two different metros and utilizing VLAN attachments in two distinct regions, combined with global dynamic routing (BGP) to leverage all available paths.
In contrast, Option D fails because it uses regional dynamic routing, which cannot aggregate routes across multiple regions or provide the same level of global path redundancy as global dynamic routing.

## Pregunta 176

Contexto: [topics:725](#topics-725)
You are deploying your infrastructure in the us-central1 region. Your on-premises data center is located in New York City, and the Google Cloud region closest to New York City is us-east4. Your Cloud Interconnect is located in Ashburn, Virginia (VA), United States. You need to use Cloud Interconnect to connect your application infrastructure with backend systems in your data center location. You do not expect the application bandwidth to exceed 500 Mbps. You want to minimize latency and cost. What should you do?

**A.** Create a Cloud Router and VLAN attachments in the us-east4 region attached to your physical Interconnect in Ashburn, VEnable global routing in your VPC. Set the bandwidth on the VLAN attachments to 500 Mbps.

**B.** Create a Cloud Router and VLAN attachments in the us-east4 region attached to your physical Interconnect in Ashburn, VA. Enable global routing in your VPC.

**C.** Create a Cloud Router in the us-central1 region and VLAN attachments in the us-east4 region attached to your physical Interconnect in Ashburn, VA. Enable global routing in your VPC.

**D.** Create a Cloud Router and VLAN attachments in the us-central1 region attached to your physical Interconnect in Ashburn, VA.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Cloud Routers and VLAN attachments must reside in the same region as the physical Interconnect (us-east4/Ashburn), making C and D architecturally invalid. Global routing enables traffic from us-central1 to traverse the interconnect efficiently, satisfying latency requirements.

Option A is incorrect because explicitly setting the bandwidth on a VLAN attachment is not a required configuration step for establishing connectivity or minimizing costs in this context; it is an unnecessary addition that does not improve upon the core correct architecture of Option B.

## Pregunta 177

Contexto: [topics:725](#topics-725)
You have provisioned a Cloud Interconnect connection with a VLAN attachment. You configured Border Gateway Protocol (BGP) between your on-premises router and your Cloud Router. After deploying and testing the connection, you discover that the BGP session is not established between your on-premises router and the Cloud Router. Which two actions should you take to resolve this issue? (Choose two.)

**A.** From the Google Cloud console, run gcloud compute routers get-status <CLOUD_ROUTER_NAME> to verify the Address Resolution Protocol (ARP) learned.

**B.** Verify that you have configured the on-premises router's subinterface with a subnet mask of /31.

**C.** Verify that you have configured the on-premises router's eBGP multihop with a minimum hop length of 4.

**D.** Verify that you have configured the on-premises router's BGP security parameters to use MD5 authentication.

**E.** From the Google Cloud console, run gcloud compute interconnects get-diagnostics <INTERCONNECT_NAME> to verify the Address Resolution Protocol (ARP) learned.

**Respuesta de la fuente:** B, E

**Explicación:** To troubleshoot a BGP session failure on Cloud Interconnect, first verify Layer 2 connectivity by ensuring ARP resolution is successful. The correct tool for this verification is `gcloud compute interconnects get-diagnostics`, which checks if the Google side has learned your CPE router's MAC address (Option E).

Second, ensure the underlying IP subnet configuration is compatible. Cloud Interconnect VLAN attachments use /29 subnets. A common misconfiguration causing BGP adjacency failure is using an incorrect subnet mask (like /31 or /30) on the on-premises interface instead of the required /29, which prevents proper neighbor reachability and ARP exchange (Option B).

## Pregunta 178

Contexto: [topics:725](#topics-725)
Your company has a single on-premises data center that needs to be connected to a VPC in Google Cloud. The total bandwidth requirement is 10Gbps. The connection must be redundant and have a minimum SLA of 99.9%. Due to the sensitive nature of the workloads, you need to implement the solution with the lowest latency. What should you do?

**A.** Order a 10Gbps Partner Interconnect VLAN attachment. Create a Cloud Router in your Google Cloud VPC.

**B.** Order two 10Gbps Dedicated Interconnect connections in a single metropolitan area (metro). Distribute the connections across different edge availability domains. Create a Cloud Router and two 10Gbps VLAN attachments.

**C.** Create one HA VPN gateway. Create two tunnels-one tunnel for each of the two interfaces of the HA VPN gateway. Terminate each of the two tunnels on the single public IP address that is configured on the VPN termination device that is located on-premises.

**D.** Create one HA VPN gateway. Create two tunnels-one tunnel for each of the two interfaces of the HA VPN gateway. Terminate each of the two tunnels on different public IPs addresses that are configured on the VPN termination device that is located on-premises.

**Respuesta de la fuente:** B

**Explicación:** Dedicated Interconnect provides the lowest latency by connecting directly to Google's network without traversing the public internet or a third-party service provider, unlike VPNs or Partner Interconnect. Ordering two connections in the same metro but across different edge availability domains achieves the required 99.9% SLA for redundancy and meets the 10Gbps throughput requirement.

## Pregunta 179

Contexto: [topics:725](#topics-725)
Your company deployed a hub and spoke architecture in Google Cloud to host their workloads. They use VPC network peerings to connect the hub and the spokes. You need to replicate the design and use Network Connectivity Center. What should you do?

**A.** Choose a Network Connectivity Center star topology. Deploy the hub VPC in the center group. Deploy the spoke VPCs in the edge group.

**B.** Choose a Network Connectivity Center star topology. Deploy the spoke VPCs in the center group. Deploy the hub VPC in the edge group.

**C.** Choose a Network Connectivity Center mesh topology. Configure the hub and the spokes as Network Connectivity Center spokes.

**D.** Choose a Network Connectivity Center mesh topology. Configure the spokes as Network Connectivity Center spokes.

**Respuesta de la fuente:** A

**Explicación:** To replicate a hub-and-spoke architecture using Network Connectivity Center (NCC), you must use the Star topology, which enforces non-transitive routing similar to VPC peering. In this topology, the central 'hub' network is placed in the center spoke group to allow communication with all other networks, while the peripheral 'spoke' networks are placed in the edge spoke group to restrict direct inter-spoke communication.

## Pregunta 180

Contexto: [topics:725](#topics-725)
You are deploying HA VPN within Google Cloud. You need to exchange routes dynamically between your on-premises gateway and Google Cloud. You have already created a HA VPN gateway and a peer VPN gateway resource. What should you do?

**A.** Create a Cloud Router, add VPN tunnels, and configure BGP sessions.

**B.** Create a Cloud Router, add VPN tunnels, and configure static routes to your subnet ranges.

**C.** Create a second HA VPN gateway, add VPN tunnels, and create firewall rules to allow BGP traffic to the Cloud Router.

**D.** Create a second HA VPN gateway, add VPN tunnels, and enable global dynamic routing.

**Respuesta de la fuente:** A

**Explicación:** To achieve dynamic route exchange in Google Cloud HA VPN, you must use BGP. This requires a Cloud Router resource to handle the BGP protocol, which is then attached to the VPN tunnels and configured with BGP sessions.
Option B is incorrect because it specifies static routes, which do not fulfill the requirement for *dynamic* route exchange.

## Pregunta 181

Contexto: [topics:725](#topics-725)
You are implementing a VPC architecture for your organization by using a Network Connectivity Center hub and spoke topology:

•	There is one Network Connectivity Center hybrid spoke to receive on-premises routes.
•	There is one VPC spoke that needs to be added as a Network Connectivity Center spoke.

Your organization has limited routable IP space for their cloud environment (192.168.0.0/20). The Network Connectivity Center spoke VPC is connected to on-premises with a Cloud Interconnect connection in the us-east4 region. The on-premises IP range is 172.16.0.0/16. You need to reach on-premises resources from multiple Google Cloud regions (us-west1,europe-central1, and asia-southeast1) and minimize the IP addresses being used. What should you do?

**A.** 1. Configure a Private NAT gateway and NAT subnet in us-west1(192.168.1.0/24), europe-central1(192.168.2.0/24) and asia-southeast1(192.168.3.0/24).
2. Add the VPC as a spoke and configure an export include policy to advertise only 192.168.1.0/24, 192.168.2.0/24, and 192.168.3.0/24 to the hub.
3. Enable global dynamic routing to allow resources in us-west1, us-central1 and asia-southeast1 to reach the on-premises location through us-east4.

**B.** 1. Configure a Private NAT gateway instance in us-west1(172.16.1.0/24), europe-central1(172.16.2.0/24), and asia-southeast1(172.16.3.0/24).
2. Add the VPC as a spoke and configure an export include policy on the VPC spoke to advertise only the NAT subnets 172.16.1.0/24, 172.16.2.0/24, and 172.16.3.0/24 to the hub.
3. Enable global dynamic to allow resources in us-west1, us-central1, and asia-southeast1 to reach the on-premises location through us-east4.

**C.** 1. Configure a Private NAT gateway instance in us-east4(192.168.1.0/24).
2. Add the VPC as a spoke and configure an export include policy on the VPC spoke to advertise 192.168.1.0/24 to the hub.
3. Enable global dynamic routing to allow resources in us-west1, us-central1 and asia-southeast1 to reach the on-premises location through us-east4.

**D.** 1. Configure a Private NAT gateway instance in us-west1(192.168.1.0/24), europe-central1(192.168.2.0/24), and asia-southeast1(192.168.3.0/24).
2. Add the VPC as a spoke and configure an export exclude policy on the VPC spoke to advertise only the NAT subnets 192.168.1.0/24, 192.168.2.0/24, and 192.168.3.0/24 to the hub.
3. Enable global dynamic routing to allow resources in us-west1, us-central1, and asia-southeast1 to reach the on-premises location through us-east4.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it uses Private NAT gateways in each source region with distinct /24 subnets from the available cloud IP space, ensuring that on-premises routing tables only receive summarized routes for these NAT IPs rather than the entire VPC range. This satisfies the requirement to minimize advertised IP addresses while allowing global reachability via the NCC hub's dynamic routing. Option B is incorrect because it uses IP ranges (172.16.x.x) that conflict with the on-premises network, causing route conflicts and connectivity failures.

## Pregunta 182

Contexto: [topics:725](#topics-725)
You have several VMs across multiple VPCs in your cloud environment, which require access to internet endpoints. These VMs cannot have public IP addresses due to security policies, so you plan to use Cloud NAT to provide outbound internet access. Within your VPCs, you have several subnets in each region. You want to ensure that only specific subnets have access to the internet through Cloud NAT. You want to avoid any unintentional configuration issues caused by other administrators, and align to Google-recommended practices. What should you do?

**A.** Create a firewall rule in each VPC at priority 500 that targets all instances in the network and denies egress to the internet, 0.0.0.0/0. Create a firewall rule at priority 300 that targets all instances in the network, has a source filter that maps to the allowed subnets, and allows egress to the internet, 0.0.0.0/0. Deploy Cloud NAT, and configure all primary and secondary subnet source ranges.

**B.** Create a constraints/compute.restrictCloudNATUsage organizational policy constraint. Attach the constraint to a folder that contains the associated projects. Configure the allowedValues to only contain the subnets that should have internet access. Deploy Cloud NAT and select only the allowed subnets.

**C.** Create a firewall rule in each VPC at priority 500 that targets all instances in the network and denies egress to the internet, 0.0.0.0/0. Create a firewall rule at priority 300 that targets all instances in the network, has a source filter that maps to the allowed subnets, and allows egress to the internet, 0.0.0.0/0. Deploy Cloud NAT, and configure a custom source range that includes the allowed subnets.

**D.** Deploy Cloud NAT in each VPC, and configure a custom source range that includes the allowed subnets. Configure Cloud NAT rules to only permit the allowed subnets to egress through Cloud NAT.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because the Organizational Policy constraint `constraints/compute.restrictCloudNATUsage` provides a centralized, enforced mechanism to limit Cloud NAT source IP ranges, aligning with Google-recommended practices for multi-project security and preventing misconfiguration by other administrators.

While firewall rules (Options A and C) can control traffic flow, they do not prevent the underlying NAT configuration from being set incorrectly or broadly, whereas the policy constraint enforces the allowed subnets at the resource creation/modification level.

## Pregunta 183

Contexto: [topics:725](#topics-725)
Your organization has five different VPCs across different projects in y our Google Cloud organization that need high-throughput connectivity. You have performed an audit of the IP address utilization in each VPC, and there are two overlapping subnets that are used by two of the VPCs: 240.0.0.0/16 and 240.128.0.0/24. You have confirmed that no Class E subnets (240.0.0.0/4) will require inter-VPC connectivity, but all other subnets in the VPCs will need connectivity. You need to deploy a Google Cloud routing solution to meet the connectivity requirements. What should you do?

**A.** Create a full mesh of VPC Network Peering connections between all five VPCs. Make sure not to import or export subnet routes with public IP addresses. Add Cloud network firewall policy rules to allow traffic.

**B.** Create a Network Connectivity Center hub with a mesh topology. Add a VPC spoke for each of the five VPCs and configure an export exclude filter for 240.0.0.0/4. Add Cloud network firewall policy rules to allow traffic.

**C.** Create a series of multiple network interface VMs with an interface in each VPPlace the VMs in an instance group. Create an internal passthrough Network Load Balancer in each VPC with the backend of the instance group. Configure custom static routes in each VPC with the next hop of the respective load balancer. Add Cloud network firewall policy rules to allow traffic.

**D.** Create a full mesh of VPC Network Peering connections between all five VPCs with an export exclude filter for 240.0.0.0/4 on every side. Add Cloud network firewall policy rules to allow traffic.

**Respuesta de la fuente:** B

**Explicación:** Network Connectivity Center (NCC) with mesh topology is the recommended solution for multi-VPC connectivity in Google Cloud as it simplifies management and scales better than full-mesh VPC peering. NCC supports route filtering, allowing you to exclude the overlapping Class E ranges (240.0.0.0/4) from propagation, thus preventing routing conflicts while maintaining connectivity for all other subnets. Option A is incorrect because full-mesh VPC peering has a strict limit on the number of peerings per VPC and does not support transitive routing, making it less scalable and harder to manage for five VPCs.

## Pregunta 184

Contexto: [topics:725](#topics-725)
You are attempting to establish a HA VPN to your on-premises network; however, the VPN connection is not establishing successfully. You have full administrative control over the Google Cloud networking environment and the on-premises firewalls that are acting as the VPN devices. The Google Cloud console shows "Negotiation failure" and "BGP is down". You check Cloud Logging by using a query for resource.type="vpn_gateway" and resource.labels.gateway_id="TUNNEL_ID_NUMBER". Logs Explorer shows frequent log entries:

log name: …/logs/cloud.googleapis.com%2Fipsec_events"
type: "vpn_gateway"
textPayload: "received NO_PROPOSAL_CHOSEN notify, no CHILD_SA built"

You need to troubleshoot the VPN failure and take corrective action based on the Cloud Logging entries. What should you do?

**A.** Update the Google Cloud BGP session configuration to match the BGP peer ASN on the on-premises side.

**B.** Compare and review the Phase 2 settings on the on-premises firewall. Make sure the settings match one of the supported cipher suites for HA VPN.

**C.** Create a new Cloud VPN gateway in a region closer to the peer VPN gateway.

**D.** Compare the Phase 1 settings and recreate the Cloud VPN tunnel by choosing a different IKE version and pre-shared key.

**Respuesta de la fuente:** B

**Explicación:** The log message 'received NO_PROPOSAL_CHOSEN notify, no CHILD_SA built' specifically indicates a failure in IPsec Phase 2 negotiation, where the peers could not agree on encryption or authentication parameters for the data channel. Therefore, you must review and align the Phase 2 settings (such as cipher suites) on the on-premises firewall with Google Cloud's supported configurations. Option D is incorrect because it addresses Phase 1/IKE settings, which would result in different error messages related to SA establishment rather than CHILD_SA failure.

## Pregunta 185

Contexto: [topics:725](#topics-725)
Your team deployed two applications in GKE that are exposed through an external Application Load Balancer. When queries are sent to www.mountkirkgames.com/sales and www.mountkirkgames.com/get-an-analysis, the correct pages are displayed. However, you have received complaints that www.mountkirkgames.com yields a 404 error. You need to resolve this error. What should you do?

**A.** Review the Service YAML file. Add a new path rule for the * character that directs to the base service. Reapply the YAML.

**B.** Review the Ingress YAML file. Add a new path rule for the * character that directs to the base service. Reapply the YAML.

**C.** Review the Ingress YAML file. Define the default backend. Reapply the YAML.

**D.** Review the Service YAML file. Define a default backend. Reapply the YAML.

**Respuesta de la fuente:** C

**Explicación:** In GKE, the Ingress resource handles external traffic routing. If a request arrives without matching specific path rules (like accessing the root domain), it relies on the `defaultBackend` defined in the Ingress YAML to determine where to send the traffic. Without this definition, unmatched requests result in a 404 error. Option B is incorrect because adding a wildcard path rule is not the standard or correct method for handling default traffic in GKE Ingress configurations; the explicit `defaultBackend` field is required.

## Pregunta 186

Contexto: [topics:725](#topics-725)
Your multi-region VPC has had a long-standing HA VPN configured in "region 1" connected to your corporate network. You are planning to add two 10 Gbps Dedicated Interconnect connections and VLAN attachments in "region 2" to connect to the same corporate network. You need to plan for connectivity between your VPC and corporate network to ensure that traffic uses the Dedicated Interconnect connections as the primary path and the HA VPN as the secondary path. What should you do?

**A.** Enable regional dynamic routing mode on the VPC. Configure BGP associated with the HA VPN in "region 1" to use a base priority value of 100. Configure BGP associated with the VAN attachments to use a base priority of 20000. Configure your on-premises routers to use similar multi exit discriminator (MED) values.

**B.** Enable regional dynamic routing mode on the VPC. Configure BGP associated with the HA VPN in "region 1" to use a base priority value of 20000. Configure BGP associated with the VLAN attachments to use a base priority of 100. Configure your on-premises routers to use similar multi exit discriminator (MED) values.

**C.** Enable global dynamic routing mode on the VPConfigure BGP associated with the HA VPN in "region 1" to use a base priority value of 20000. Configure BGP associated with the VLAN attachments to use a base priority of 100. Configure your on-premises routers to use similar multi exit discriminator (MED) values.

**D.** Enable global dynamic routing mode on the VPC. Configure BGP associated with the HA VPN in "region 1" to use a base priority value of 100. Configure BGP associated with the VLAN attachments to use a base priority of 20000. Configure your on-premises routers to use similar multi exit discriminator (MED) values.

**Respuesta de la fuente:** C

**Explicación:** Global dynamic routing mode is required because the VPC connects to on-premises networks in multiple regions (Region 1 and Region 2), allowing a single Cloud Router instance to manage all BGP sessions. To ensure Dedicated Interconnect is primary, its BGP base priority must be lower (100) than the HA VPN's priority (20000), as Google Cloud selects routes with the lowest base priority value.
Reference: GCP Network Connectivity documentation on Dynamic Routing Modes and BGP Base Priority.

## Pregunta 187

Contexto: [topics:725](#topics-725)
Your organization is developing a landing zone architecture with the following requirements:

•	There should be no communication possible between production and non-production en-vironments.
•	Communication between applications within an environment may be necessary.
•	Network administrators should centrally manage all network resources, including subnets, routes, and firewall rules.
•	Each application should be billed separately.
•	Developers of an application within a project should have the autonomy to create their compute resources. They should not create or modify networking resources.
•	Up to 1000 applications are expected per environment.

You need to create a design that accommodates these requirements. What should you do?

**A.** Create a design that has one Shared VPC host project for the production environment, and another Shared VPC host project for the nonproduction environment. Associate the various applications' service projects with the corresponding environment's host project.

**B.** Create a design that has a Shared VPC for each project. Implement hierarchical firewall policies to apply micro-segmentation between VPCs.

**C.** Create a design that implements a single Shared VPUse VPC firewall rules with secure tags to enforce micro-segmentation between environments.

**D.** Create a design where each project in each environment has its own VPC with its own subnets, routes, and firewall rules. Ensure all VPCs are added as spokes to a Network Connectivity Center hub.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Shared VPC allows the network administrator to centrally manage network resources (subnets, routes) in host projects while granting developers access only to compute resources in associated service projects. This architecture inherently isolates production from non-production by using separate host projects and supports per-application billing through distinct service projects.

Option D is incorrect because assigning each project its own VPC prevents central management of network resources across the environment, violating the requirement that network administrators centrally manage subnets and routes.

## Pregunta 188

Contexto: [topics:725](#topics-725)
Your company uses Compute Engine instances that are exposed to the public internet. Each compute instance has a single network interface with a single public IP address. You need to block any connection attempt that originates from internet clients with IP addresses that belong to the BGP_ASN_TOBLOCK BGP ASN. What should you do?

**A.** Create a new Cloud Armor backend security policy, and use the --network-src-asns parameter.

**B.** Create a new Cloud Armor network edge security policy, and use the --network-src-asns parameter.

**C.** Create a new Cloud Armor edge security policy, and use the --network-src-asns parameter.

**D.** Create a new firewall policy ingress rule, and use the --network-src-asns parameter.

**Respuesta de la fuente:** B

**Explicación:** To block traffic based on source ASN for GCE instances with public IPs, you must use a Cloud Armor network edge security policy, as this specific feature applies directly to backend services and instances exposed to the internet at the network level. The --network-src-asns parameter is explicitly supported by network edge policies to filter traffic originating from specific BGP Autonomous System Numbers. Option A is incorrect because backend security policies are designed for HTTP(S) load balancers, not direct instance access. Option D is incorrect because standard firewall policies do not support ASN-based filtering rules.

## Pregunta 189

Contexto: [topics:725](#topics-725)
Your frontend application VMs and your backend database VMs are all deployed in the same VPC but across different subnets. Global network firewall policy rules are configured to allow traffic from the frontend VMs to the backend VMs. Based on a recent compliance requirement, this traffic must now be inspected by network virtual appliances (NVAs) firewalls that are deployed in the same VPC. The NVAs are configured to be full network proxies and will source NAT-allowed traffic. You need to configure VPC routing to allow the NVAs to inspect the traffic between subnets. What should you do?

**A.** Place your NVAs behind an internal passthrough Network Load Balancer named ILB1. Add the global network firewall policy rules to allow traffic through your NVAs. Create a policy-based route (PBR) with the source IP range of the backend VM subnet, destination IP range of the frontend VM subnet, and the next hop of ILB1. Scope the PBR to the VMs with the backend network tag. Add a backend network tag to your backend servers.

**B.** Place your NVAs behind an internal passthrough Network Load Balancer named ILB1. Add global network firewall policy rules to allow traffic through your NVAs. Create a custom static route with the destination IP range of the backend VM subnet, frontend instance tag, and the next hop of ILB1. Add a frontend network tag to your frontend VMs.

**C.** Create your NVA with multiple interfaces. Configure NIC0 for NVA in the backend subnet. Configure NIC1 for NVA in the frontend subnet. Place your NVAs behind an internal passthrough Network Load Balancer named ILB1. Add global network firewall policy rules to allow traffic through your NVAs. Create a custom static route with the destination IP range of the backend VM subnet, frontend instance tag, and the next hop of ILB1. Add a frontend network tag to your frontend VMs.

**D.** Place your NVAs behind an internal passthrough Network Load Balancer named ILB1. Add global network firewall policy rules to allow traffic through your NVAs. Create a policy-based route (PBR) with the source IP range of the frontend VM subnet, destination IP range of the backend VM subnet, and the next hop of ILB1. Scope the PBR to the VMs with the frontend network tag. Add a frontend network tag to your frontend servers.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Policy-Based Routing (PBR) allows for precise traffic steering without being shared across VPC peering or Cloud Interconnect, unlike static routes.
Since the NVAs perform Source NAT (SNAT), they handle the return path automatically; therefore, you only need to steer the initial outbound traffic from the frontend VMs via a PBR scoped to the frontend network tag with the Internal Load Balancer (ILB) as the next hop.
Option B is incorrect because static routes are propagated to connected networks (like peered VPCs), which violates the isolation requirement implied by using PBR for specific inspection needs, and it incorrectly targets the backend subnet destination rather than scoping the route to the initiating frontend traffic.

## Pregunta 190

Contexto: [topics:725](#topics-725)
Your organization wants to set up hybrid connectivity with VLAN attachments that terminate in a single Cloud Router with 99.9% uptime. You need to create a network design for your on-premises router that meets those requirements and has an active/passive configuration that uses only one VLAN attachment at a time. What should you do?

**A.** Create a design that uses the LOCAL_PREF BGP attribute to influence the egress path from Google Cloud to the on-premises environment.

**B.** Create a design that uses an equal-cost multipath (ECMP) with flow-based hashing on your on-premises devices.

**C.** Create a design that uses a BGP multi-exit discriminator (MED) attribute to influence the egress path from Google Cloud to the on-premises environment.

**D.** Create a design that uses the AS_PATH BGP attribute to influence the egress path from Google Cloud to the on-premises environment.

**Respuesta de la fuente:** C

**Explicación:** The question requires influencing traffic entering Google Cloud from the on-premises environment (egress from GCP to on-prem). MED is the standard BGP attribute used by neighboring ASes to influence inbound path selection, making it the correct choice for this active/passive setup.
Local Preference (Option A) influences outbound traffic within your own AS (on-prem), not how GCP sends traffic back to you.

## Pregunta 191

Contexto: [topics:725](#topics-725)
You are implementing firewall controls to protect your computer resources in a newly created VPC. To make the protection process easier to manage and control, you've defined the hierarchical firewall policies, global network firewall policies, and VPC firewall rules. The configuration of rules defines the following characteristics:

•	The hierarchical firewall policy, bound at the organization level, is allowing/denying spe-cific external traffic.
•	There is a global network firewall policy with rules that enforce intrusion prevention sys-tem (IPS) capabilities for specific external inbound/outbound traffic.
•	The VPC firewall rules allow internal communication from RFC 1918 defined subnets communications.
•	The VPC firewall contains an explicit deny rule with logs enabled.

This configuration was successful in multiple preexisting VF'Cs. However, you noticed that the logs were missing when you were reviewing a newly created VPC. All external communications are hanging, but internal traffic is working as expected. You want to fix the connectivity issue.

What should you do?

**A.** Create a new VPC and migrate existing resources to the new VPC. Delete the old VPC, and reapply the firewall policies and rules in the newVPC.

**B.** Raise the priority numbers of the firewall policy rules and lower the priority numbers of the VPC firewall rules.

**C.** Review the order in which the VPC firewall rules and policies are evaluated. If the VPC firewall rules are being evaluated before firewall policies, switch the order.

**D.** Lower the priority numbers of the firewall policy rules and raise the priority numbers of the VPC firewall rules.

**Respuesta de la fuente:** C

**Explicación:** In Google Cloud, the firewall evaluation order is hierarchical: Hierarchical Policies → Network Firewall Policies → VPC Firewall Rules. The issue arises because a higher-level policy (likely the global network policy or hierarchical policy) is matching and terminating external traffic before it reaches the VPC rule configured with logging, resulting in missing logs and blocked connectivity.

Option C is correct because it directs you to review this evaluation sequence to identify where the premature match occurs. While you cannot arbitrarily 'switch' the entire order, you must adjust priorities or rules within the higher-priority layers (Hierarchical/Network) so that traffic flows through to the VPC level as intended.

Option D is incorrect because lowering priority numbers makes firewall policy rules evaluate earlier, which would exacerbate the problem by ensuring they block traffic even sooner.

## Pregunta 192

Contexto: [topics:725](#topics-725)
You are configuring the intrusion prevention service (IPS) feature on Cloud Next Generation Firewall Enterprise. You deployed your firewall endpoints and you need to inspect the traffic of the VMs. What should you do?

**A.** Configure Packet Mirroring to match the source/destination IP addresses of the VMs.

**B.** Configure a firewall rule to match the source/destination IP addresses of the VMs, and use the goto_next action.

**C.** Configure a firewall rule to match the hostnames of the VMs, and use the apply_security_profile_group action.

**D.** Configure a firewall rule to match the source/destination IP addresses of the VMs, and use the apply_security_profile_group action.

**Respuesta de la fuente:** D

**Explicación:** In Cloud Next-Generation Firewall Enterprise, Layer 7 inspection features like IPS are enabled by associating a security profile group with a firewall rule using the apply_security_profile_group action. To inspect traffic from specific VMs, the rule must match their source/destination IP addresses to ensure the endpoints process that traffic.

## Pregunta 193

Contexto: [topics:725](#topics-725)
Your organization recently exposed a set of services through a global external Application Load Balancer. After conducting some testing, you observed that responses would intermittently yield HTTP 4xx or 5xx error response codes. You already enabled and reviewed the health check logs. You need to identify the error. What should you do?

**A.** Access a VM in the VPC through SSH to access the backend VM directly. If the request is successful from the VM, increase the quantity of backends.

**B.** Delete the load balancer and backend services. Create a new Passthrough Network Load Balancer. Configure a failover group of VMs for the backend.

**C.** Validate the health of the backend service. Enable logging for the backend service and identify the error response in Cloud Logging. Review the statusDetails log field.

**D.** Validate the health of the backend service. Disable any Cloud Armor policies on the backend service, and identify any error response in Cloud Logging. Review the statusDetails log field.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because the `statusDetails` field in Cloud Logging for HTTP(S) load balancers specifically indicates why a request failed (e.g., backend unreachable, timeout, or specific application errors), directly addressing the intermittent 4xx/5xx issues after health checks are reviewed.

Option D is incorrect because disabling Cloud Armor is an unnecessary and risky troubleshooting step; one should analyze logs first to determine if security policies are actually causing the errors rather than blindly removing them.

## Pregunta 194

Contexto: [topics:725](#topics-725)
Your company's current network architecture has two VPCs that are connected by a dual-NIC instance that acts as a bump-in-the-wire firewall between the two VPCs. Flows between pairs of subnets across the two VPCs are working correctly. Suddenly, you receive an alert that none of the flows between the two VPCs are working anymore. You need to troubleshoot the problem. What should you do? (Choose two.)

**A.** Verify that a VPC Service Controls perimeter has not been enabled for the project that contains the two VPCs and the dual-NIC instance.

**B.** Use Cloud Logging to verify that there were no modifications to the VPC firewall rules or policies that were applied to the two network interfaces of the dual-NIC instance.

**C.** Verify that a public IP address has not been assigned to any network interface of the dual-NIC instance.

**D.** Verify that the dual-NIC instance has the --can-Ip-Forward attribute enabled.

**E.** Verify that the dual-NIC instance has not been added to a backend service.

**Respuesta de la fuente:** B, D

**Explicación:** Option D is correct because a VM acting as a router or firewall must have IP forwarding enabled (--can-ip-forward) to pass traffic between its network interfaces; if this setting was lost or disabled, inter-VPC flows would cease immediately. Option B is correct because Cloud Logging provides an audit trail for VPC firewall rule changes, allowing you to confirm whether unauthorized modifications blocked the traffic paths on the dual-NIC instance's interfaces.

Option A is less likely because VPC Service Controls restrict cross-project resource access rather than direct network packet forwarding between subnets in the same project. Option C is incorrect because assigning a public IP does not inherently disable private routing functionality. Option E is irrelevant because adding an instance to a backend service affects load balancing, not its ability to route traffic as a bump-in-the-wire device.

## Pregunta 195

Contexto: [topics:725](#topics-725)
Your company deployed Cloud Next Generation Firewall Enterprise (Cloud NGFW Enterprise). You have already created a CA pool and a CA in Certificate Authority Service. You need to enable TLS inspection. What should you do?

**A.** Grant the network security service agent service account the privateca.certificateRequester role. Create a TLS inspection policy linking to the CA pool. Configure your VPC endpoint associations to use the TLS inspection policy. Flip the TLS inspection flag in your firewall policy rules to true.

**B.** Grant the network security service agent service account the privateca.poolReader role. Create a TLS inspection policy linking to the CA pool. Configure your VPC endpoint associations to use the TLS inspection policy. Flip the TLS inspection flag in your firewall policy rules to true.

**C.** Grant the network security service agent service account the privateca.certificateRequester role. Create a trust config in Certificate Manager Flip the TLS inspection flag in your firewall policy rules to true.

**D.** Grant the network security service agent service account the privateca.certificateRequester role. Create a trust config in Certificate Manager. Flip the TLS inspection flag in your firewall policy rules to true.

**Respuesta de la fuente:** A

**Explicación:** To enable TLS inspection on Google Cloud NGFW, the network security service agent requires the `privateca.certificateRequester` role to dynamically generate intermediate certificates from the CA pool. The process mandates creating a dedicated TLS inspection policy linked to that CA pool and attaching it via VPC endpoint associations before enabling the flag in firewall rules.
Option B is incorrect because the `poolReader` role only provides read access and does not permit the service agent to request or create the necessary certificates for decryption.

## Pregunta 196

Contexto: [topics:725](#topics-725)
You have recently taken over responsibility for your organization's Google Cloud network security configurations. You want to review your Cloud Next Generation Firewall (Cloud NGFW) configurations and ensure there are no rules that are allowing ingress traffic to your VMs and services from the internet. You want to avoid manual work. What should you do?

**A.** Review the firewall policy rules associated with the VPC, and filter for rules that allow ingress from 0.0.0.0/0.

**B.** Enable "Overly permissive rules insights" in Firewall Insights. Review results for rules that show allowed ingress traffic from internet sources.

**C.** Run Connectivity Tests from multiple external sources to double-check ingress traffic settings.

**D.** Enable the Network Analyzer API and review the "VPC Network" category insights.

**Respuesta de la fuente:** B

**Explicación:** The question explicitly asks for a method that avoids manual work. Firewall Insights is an automated tool that scans configurations and flags "Overly permissive rules," such as those allowing ingress from 0.0.0.0/0, without requiring manual review of each rule. Option A involves manually reviewing and filtering rules, which contradicts the requirement to avoid manual effort.

## Pregunta 197

Contexto: [topics:725](#topics-725)
Your company's cloud network has hybrid connectivity to an on-premises environment through Cloud Interconnect in two regions (us-east4 and us-west1). You received complaints that some on-premises destinations are no longer reachable from us-east4, after changes were made to advertise additional routes to us-west1. You need to troubleshoot to see if any routes were dropped. What should you do?

**A.** Query the dynamic_routes/learned_routes/dropped_unique_destinations metric and review the global routing_mode metric attribute.

**B.** Query the dynamic_routes/learned_routes/unique_destinations_limit metric and review the global routing_mode metric attribute.

**C.** Query the dynamic_routes/learned_routes/any_dropped_unique_destinations metric and review the regional routing_mode metric attribute.

**D.** Query the dynamic_routes/learned_routes/dropped_unique_destinations metric and review the regional routing_mode metric attribute.

**Respuesta de la fuente:** C

**Explicación:** The correct metric to identify if routes were dropped is `any_dropped_unique_destinations`, which acts as a boolean indicator for quota violations. Since the issue is isolated to specific regions (us-east4) within a hybrid setup, reviewing the `regional routing_mode` attribute is necessary to correlate drops with regional configuration states.

## Pregunta 198

Contexto: [topics:725](#topics-725)
Your organization has resources in two different VPCs, each in different Google Cloud projects, which require connectivity between them. You have already determined that there is no IP address overlap; however, one VPC uses privately used public IP (PUPI) ranges. You would like to enable connectivity between these resources by using a lower cost and higher performance method. What should you do?

**A.** Create a HA VPN between the two VPCs that includes the PUPI ranges in the Custom Route Advertisements of the Cloud Router. Create the necessary ingress VPC firewall rules that target the specific resources by using network tags as the source filter.

**B.** Create a HA VPN between the two VPCs that includes the PUPI ranges in the Custom Route Advertisements of the Cloud Router. Create the necessary ingress VPC firewall rules that target the specific resources by using IP ranges as the source filter.

**C.** Create a VPC Peering between the two VPCs that allows the export and import of custom routes. Create the necessary ingress VPC firewall rules that target the specific resources by using service accounts as the source filter.

**D.** Create a VPC Peering between the two VPCs that allows the export and import of subnet routes with public IP addresses. Create the necessary ingress VPC firewall rules that target the specific resources by using IP ranges as the source filter.

**Respuesta de la fuente:** D

**Explicación:** VPC Peering is the preferred method for intra-Google Cloud connectivity due to higher performance and lower cost compared to HA VPN. Since one VPC uses Privately Used Public IP (PUPI) ranges, standard subnet route exchange does not include these routes by default; you must explicitly enable 'Export subnet routes with privately used public IPv4 addresses' to allow reachability. Using IP ranges in firewall rules is the correct and most straightforward way to restrict access between peered VPC resources.

## Pregunta 199

Contexto: [topics:725](#topics-725)
Your organization recently re-architected your cloud environment to use Network Connectivity Center. However, an error occurred when you tried to add a new VPC, named vpc-dev, as a spoke. The error indicated that there was an issue with an existing spoke and the IP space of a VPC, named vpc-pre-prod. You must complete the migration quickly and efficiently. What should you do?

**A.** Delete the VMs associated with the conflicting subnets, then delete the conflicting subnets in vpc-dev. Recreate the subnets with a new IP range and redeploy the previously-deleted VMs in the new subnets. Add the VPC spoke for vpc-dev.

**B.** Exclude the conflicting IP range by using the --exclude-export-ranges flag when creating the VPC spoke for vpc-dev.

**C.** Exclude the conflicting IP range by using the --exclude-export-ranges flag in the hub when attaching the VPC spoke for vpc-dev.

**D.** Remove the conflicting VPC spoke for vpc-pre-prod from the set of VPC spokes in Network Connectivity Center. Add the VPC spoke for vpc-dev. Add the previously removed vpc-pre-prod as a VPC spoke.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because the --exclude-export-ranges flag allows you to exclude specific IP ranges from routing advertisements during spoke creation, directly resolving the conflict without requiring destructive changes or downtime.
Unlike Option A, which involves deleting VMs and subnets (disruptive), or Option D, which requires removing existing spokes (risky and inefficient), Option B addresses the issue at the point of configuration with minimal impact.

## Pregunta 200

Contexto: [topics:725](#topics-725)
Recently, your networking team enabled Cloud CDN for one of the external-facing services that is exposed through an external Application Load Balancer. The application team has already defined which content should be cached within the responses. Upon testing the load balancer, you did not observe any change in performance after the Cloud CDN enablement. You need to resolve the issue. What should you do?

**A.** Configure the CACHE_ALL_STATIC caching mode on Cloud CDN to ensure Cloud CDN caches all static content as well as content defined by the backends.

**B.** Configure the FORCE_CACHE_ALL caching mode on Cloud CDN to ensure all appropriate content is cached.

**C.** Configure the USE_ORIGIN_HEADERS caching mode on Cloud CDN to ensure Cloud CDN caches content depending on responses to requests from the backends.

**D.** Configure the CACHE_ALL_STATIC caching mode on Cloud CDN to ensure Cloud CDN cache content depending on responses to requests from the backends.

**Respuesta de la fuente:** C

**Explicación:** The correct action is to configure the USE_ORIGIN_HEADERS caching mode (C), which ensures Cloud CDN respects the cache-control directives sent by your backend servers. Since the application team has already defined which content should be cached within the responses, using this mode allows Cloud CDN to cache that specific content as intended, whereas default or forced modes might ignore these explicit backend instructions.

Reference: Google Cloud documentation on Caching modes for Cloud CDN.

## Pregunta 201

Contexto: [topics:725](#topics-725)
Your organization requires that all SMTP traffic to your cloud environment is blocked, except for traffic that originates from your corporate network. Your organization also requires that only specific VPCs across your Google Cloud projects will allow SMTP access from your corporate network. You need to configure a security policy that will enable this connectivity. What should you do?

**A.** 1. Configure an ingress hierarchical firewall rule with priority 10000 specifying the 0.0.0.0/0 source, TCP port 25, and the deny action.
2. Configure an egress hierarchical firewall rule with priority 10010 specifying the source of your corporate network as TCP port 25 and the goto_next action.
3. Associate the hierarchical firewall policy at the organization level.
4. Configure firewall policy rules allowing TCP port 25 in the firewall policies associated with the respective VPCs that require that access.

**B.** 1. Configure an ingress hierarchical firewall rule with priority 10000 specifying the 0.0.0.0/0 source, TCP port 25, and the allow action.
2. Associate the hierarchical firewall policy at the organization level.
3. Configure firewall policy rules to deny TCP port 25 in the firewall policies associated with the respective VPCs that do not require that access.

**C.** 1. Configure an ingress hierarchical firewall rule with priority 10000 specifying the source of your corporate network, TCP port 25, and the goto_next action.
2. Configure an ingress hierarchical firewall rule with priority 10010 specifying the 0.0.0.0/0 source, TCP port 25, and the deny action.
3. Associate the hierarchical firewall policy at the organization level.
4. Configure firewall policy rules allowing TCP port 25 in the firewall policies associated with the respective VPCs that require that access.

**D.** 1. Configure an ingress hierarchical firewall rule with priority 10000 specifying the 0.0.0.0/0 source, TCP port 25, and the deny action.
2. Associate the hierarchical firewall policy at the organization level.
3. Configure firewall policy rules allowing TCP port 25 in the firewall policies associated with the respective VPCs that require that access.

**Respuesta de la fuente:** C

**Explicación:** Option C correctly leverages hierarchical firewall rule precedence (lower number = higher priority) by placing a 'goto_next' rule for corporate IPs at priority 10000 before a broad 'deny all' at 10010. This setup defaults to blocking external SMTP traffic while allowing specific VPCs to define local allow rules for the corporate source without needing to override a higher-priority deny.
Option D is incorrect because it applies a blanket deny from 0.0.0.0/0 at the organization level without a preceding bypass mechanism, which would block the allowed corporate traffic unless the lower-level VPC rules have a higher priority than the hierarchical rule—a configuration that contradicts standard hierarchical firewall design where org-level policies are meant to set the baseline.

## Pregunta 202

Contexto: [topics:725](#topics-725)
Your organization has a subset of applications in multiple regions that require internet access. You need to control internet access from applications to URLs, including hostnames and paths. The compute instances that run these applications have an associated secure tag. What should you do?

**A.** Deploy a Cloud NAT gateway. Use fully qualified domain name (FQDN) objects in the firewall policy rules to filter outgoing traffic to specific domains from machines that match a service account.

**B.** Deploy a Cloud NAT gateway. Use fully qualified domain name (FQDN) objects in the firewall policy rules to filter outgoing traffic to specific domains from machines that match the secure tag.

**C.** Deploy a single Secure Web Proxy instance with global access enabled. Apply a Secure Web Proxy policy to allow access from machines that match the secure tag to the URLs defined in a URL list.

**D.** Deploy a Secure Web Proxy instance in each region. Apply a Secure Web Proxy policy to allow access from machines that match the secure tag to the URLs defined in a URL list.

**Respuesta de la fuente:** D

**Explicación:** Secure Web Proxy (SWP) is the correct service because it offers granular control over internet access using URL lists (including hostnames and paths), whereas Cloud NAT with FQDN rules lacks path-level filtering. SWP resources are regional, so deploying an instance in each region ensures local connectivity for applications distributed across multiple regions.

## Pregunta 203

Contexto: [topics:725](#topics-725)
You are implementing hybrid connectivity between your company's data center and Google Cloud. You've already deployed redundant Dedicated Interconnect connections, and are now deploying VLAN attachments in us-central1. You want to use an active/passive approach, where interconnect-1 is active and interconnect-2 is a passive backup. You need to deploy a Cloud Router to enable BGP connectivity. You want to follow Google-recommended practices. What should you do?

**A.** 1. Configure the primary interconnect-1 BGP session on the Cloud Router with priority 0 and ASN 65101.
2. Configure the secondary interconnect-2 BGP session on the Cloud Router with priority 200 and ASN 65102.
3. Configure the on-premises ASN as 65000.

**B.** 1. Configure the primary interconnect-1 BGP session on the Cloud Router with priority 0.
2. Configure the secondary interconnect-2 BGP session on the Cloud Router with priority 200.
3. Configure both Google-side BGP ASNs as 65100.
4. Configure the on-premises ASN as 65000.

**C.** 1. Configure the primary and secondary interconnects of the BGP sessions on the Cloud Router with priority 100 and ASN 16550.
2. Configure the on-premises ASN as 65001 for primary interconnect-1.
3. Configure the on-premises ASN as 65002 for secondary interconnect-2.

**D.** 1. Configure the primary and secondary interconnects of the BGP sessions on the Cloud Router with priority 100 and ASN 4200000001.
2. Configure the on-premises ASN as 4200000010.
3. Disable the BGP session on the on-premises router for the secondary interconnect-2.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it uses the standard Google ASN (65100) for both Cloud Router sessions and leverages priority values (0 for active, 200 for passive) to enforce the desired active/passive traffic flow within BGP.
Option A is incorrect because assigning different ASNs (65101 vs 65102) to the two sessions on the same Cloud Router violates best practices; Google recommends using a single consistent ASN per Cloud Router instance to simplify routing and avoid potential adjacency issues.

## Pregunta 204

Contexto: [topics:725](#topics-725)
Your organization has multiple VMs running on Google Cloud within a VPC. The VMs require connectivity to certain Google APIs. You need to enable Private Google Access for VM connectivity to Cloud Storage. What should you do?

**A.** Enable Private Google Access on the project, remove the default route that points to the default internet gateway, and enable the Cloud Storage API.

**B.** Enable Private Google Access on the VM, remove the default route that points to the default internet gateway, and enable the Cloud Storage API.

**C.** Enable Private Google Access on the VPC, create a default route that points to the default internet gateway, and enable the Cloud Storage API.

**D.** Enable Private Google Access on the subnet, create a default route that points to the default internet gateway, and enable the Cloud Storage API.

**Respuesta de la fuente:** D

**Explicación:** Private Google Access is configured at the subnet level, not on individual VMs or the VPC as a whole. To function correctly, it requires a default route pointing to the default internet gateway so traffic destined for Google APIs can be routed privately via internal IPs rather than through external NAT gateways.

## Pregunta 205

Contexto: [topics:725](#topics-725)
You are configuring the final elements of a migration effort where resources have been moved from on-premises to Google Cloud. While reviewing the deployed architecture, you noticed that DNS resolution is failing when queries are being sent to the on-premises environment. You login to a Compute Engine instance, try to resolve an on-premises hostname, and the query fails. DNS queries are not arriving at the on-premises DNS server. You need to use managed services to reconfigure Cloud DNS to resolve the DNS error. What should you do?

**A.** Ensure that the operating systems of the Compute Engine instances are configured to send DNS queries to the on-premises DNS servers directly.

**B.** Validate that there is network connectivity to the on-premises environment and that the Compute Engine instances can reach other on-premises resources. If errors persist, remove the VPC Network Peerings and recreate the peerings after validating the routes.

**C.** Validate that the Compute Engine instances are using the Metadata Service IP address as their resolver. Configure an outbound forwarding zone for the on-premises domain pointing to the on-premises DNS server. Configure Cloud Router to advertise the Cloud DNS proxy range to the on-premises network.

**D.** Review the existing Cloud DNS zones, and validate that there is a route in the VPC directing traffic destined to the IP address of the DNS servers. Recreate the existing DNS forwarding zones for . to forward all queries to the on-premises DNS servers.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it leverages managed services to resolve the connectivity gap: using the Metadata Server ensures instances use Cloud DNS, an outbound forwarding zone directs specific on-premises queries to the local server, and advertising the Cloud DNS proxy range via Cloud Router allows that traffic to traverse the hybrid connection.
Option A is incorrect because configuring OS-level resolvers bypasses managed Cloud DNS services, violating the requirement to use managed services and complicating DNS management across instances.

## Pregunta 206

Contexto: [topics:725](#topics-725)
Your organization's security team recently discovered that there is a high risk of malicious activities originating from some of your VMs connected to the internet. These malicious activities are currently undetected when TLS communication is used. You must ensure that encrypted traffic to the internet is inspected. What should you do?

**A.** Enable Cloud Armor TLS inspection policy, and associate the policy with the backend VMs.

**B.** Use Cloud NGFW Essentials. Create a firewall rule for egress traffic, and enable VPC Flow Logs with the TLS inspect option. Analyze the output logs content and block the outputs that have malicious activities.

**C.** Configure a TLS agent on every VM to intercept TLS traffic before it reaches the internet. Configure Sensitive Data Protection to analyze and allow/deny the content.

**D.** Use Cloud NGFW Enterprise. Create a firewall rule for egress traffic with the --tls-inspect flag, and associate the firewall rules with the VMs.

**Respuesta de la fuente:** D

**Explicación:** Cloud NGFW Enterprise is the correct choice because it natively supports Layer 7 inspection, including TLS decryption for egress traffic, which Cloud Armor and Essentials lack. Cloud Armor (Option A) only inspects ingress traffic at the load balancer, not outbound VM connections. Option B is incorrect because VPC Flow Logs only record metadata and cannot decrypt or inspect TLS content.

## Pregunta 207

Contexto: [topics:725](#topics-725)
Your organization has a hub and spoke architecture with VPC Network Peering, and hybrid connectivity is centralized at the hub. The Cloud Router in the hub VPC is advertising subnet routes, but the on-premises router does not appear to be receiving any subnet routes from the VPC spokes. You need to resolve this issue. What should you do?

**A.** Create custom routes at the Cloud Router in the spokes to advertise the subnets of the VPC spokes.

**B.** Create custom routes at the Cloud Router in the hub to advertise the subnets of the VPC spokes.

**C.** Create a BGP route policy at the Cloud Router, and ensure the subnets of the VPC spokes are being announced towards the on-premises environment.

**D.** Create custom learned routes at the Cloud Router in the hub to advertise the subnets of the VPC spokes.

**Respuesta de la fuente:** B

**Explicación:** In a hub-and-spoke architecture with centralized hybrid connectivity, the Hub Cloud Router learns spoke subnet routes via VPC peering but does not automatically advertise them to the on-premises environment. To resolve this, you must manually configure custom route advertisements on the Hub Cloud Router for each spoke subnet to ensure they are pushed to the on-premises router.

Option A is incorrect because advertising routes at the spoke level bypasses the centralized hub connectivity model and does not reach the on-premises network directly.

## Pregunta 208

Contexto: [topics:725](#topics-725)
Your organization has a legacy VPN device that uses IKEv1 and does not support BGP. Connectivity from your on-premises environment to Google Cloud needs to be established. You are using 172.16.100.0/24, 172.16.101.0/24, and 172.16.102.0/24 in your on-premises environment, and 192.168.100.0/24, 192.168.101.0/24, and 192.168.102.0/24 in your Google Cloud environment. You have configured a VPN gateway and you need to configure a policy-based VPN tunnel. What should you do?

**A.** Configure the tunnel with LOCAL_TS set to 172.16.100.0/22 and REMOTE_TS set to 192.168.100.0/22.

**B.** Configure the tunnel with LOCAL_TS set to 192.168.100.0/22 and REMOTE_TS set to 172.16.100.0/22.

**C.** Configure the tunnel with LOCAL_TS set to 172.16.100.0/24, 172.16.101.0/24, and 172.16.102.0/24, and REMOTE_TS set to 192.168.100.0/24,192.168.101.0/24, and 192.168.102.0/24.

**D.** Configure the tunnel with LOCAL_TS set to 172.16.100.0/24, 172.16.101.0/24, and 172.16.102.0/24, and REMOTE_TS set to 0.0.0.0/0.

**Respuesta de la fuente:** B

**Explicación:** For IKEv1 policy-based tunnels, the Google Cloud documentation explicitly states that you can only supply a single CIDR for the local traffic selector (LOCAL_TS) and a single CIDR for the remote traffic selector (REMOTE_TS); multiple Child SAs with separate CIDRs are not supported.

Therefore, options C and D are invalid because they attempt to define multiple CIDR blocks or use the default route 0.0.0.0/0 for REMOTE_TS, which violates the single-CIDR constraint for IKEv1 in this context.

Between A and B, the LOCAL_TS and REMOTE_TS must represent the network ranges that the Cloud VPN gateway considers "local" and the on-premises environment considers "remote" respectively. From the perspective of the Cloud VPN configuration (which is what you are setting up in the cloud console or API for the gateway), the networks defined in the Google Cloud VPC (192.168.100.0/22) are the local networks, and the on-premises networks (172.16.100.0/22) are the remote networks.

Thus, LOCAL_TS should be 192.168.100.0/22 and REMOTE_TS should be 172.16.100.0/22.

## Pregunta 209

Contexto: [topics:725](#topics-725)
You plan to deploy Google Cloud Armor web application firewall (WAF) policies that use the preconfigured WAF rules. You want all Google Cloud Armor logs to be sent to Cloud Logging with the highest level of detail possible. You have enabled Cloud Load Balancing logs for all the backend services where Cloud Armor WAF policies are applied. What should you do?

**A.** Set the sample rate of the Cloud Load Balancing logs to 0.5.

**B.** Set the Google Cloud Armor logging option to VERBOSE.

**C.** Enable Google Cloud Armor logging for all the backend services where Cloud Armor WAF policies are applied. Set the Google Cloud Armor logging option to VERBOSE.

**D.** Set the sample rate of the Cloud Load Balancing logs to 1.0.

**Respuesta de la fuente:** B

**Explicación:** To achieve the highest level of detail for Google Cloud Armor logs, you must set the logging option to VERBOSE, which provides detailed information about matched rules and request attributes.
Option C is incorrect because the question explicitly states that you have already enabled Cloud Load Balancing logs, making that part of the instruction redundant.

## Pregunta 210

Contexto: [topics:725](#topics-725)
Your organization has implemented Vertex AI online prediction in your Google Cloud environment, which is in the us-central1 region. Online prediction is available through private services access by using the IP CIDR range of 172.16.53.0/24. You need to configure access to Vertex AI without affecting the existing routes. You want to use the VLAN attachments that are located in the us-west1 region as primary. The interconnect VLAN attachments in the us-west2 region can only be used as a backup. What should you do?

**A.** Create a custom route advertisement on VLAN attachments in the us-west1 region for prefix 172.16.53.0/24. Create a custom route advertisement on VLAN attachments in the us-west2 region for prefix 172.16.53.0/24.

**B.** Create a custom learned route on VLAN attachments in the us-west1 region for prefix 172.16.53.0/24, and set the route priority on the BGP session as 100. Create a custom route advertisement on VLAN attachments in the us-west2 region for prefix 172.16.53.0/24, and set the route priority on the BGP session as 200.

**C.** Create a custom route advertisement on VLAN attachments in the us-west1 region for prefix 172.16.53.0/24, and set the route priority on the BGP session as 100. Create a custom route advertisement on VLAN attachments in the us-west2 region for prefix 172.16.53.0/24, and set the route priority on the BGP session as 200.

**D.** Create a custom route advertisement on VLAN attachments in the us-west1 region for prefix 172.16.53.0/24, and create a BGP route-policy to set the multi-exit discriminator (MED) to 100. Create a custom route advertisement on VLAN attachments in the us-west2 region for prefix 172.16.53.0/24, and create a BGP route-policy to set the multi-exit discriminator (MED) to 200.

**Respuesta de la fuente:** C

**Explicación:** To configure primary/backup routing without affecting existing routes, you must use Custom Route Advertisements to inject the specific prefix (172.16.53.0/24) into BGP.
In Google Cloud HCP/BGP contexts, a lower 'route priority' value indicates higher preference; setting us-west1 to 100 and us-west2 to 200 ensures traffic prefers the primary VLAN attachment.
Option D is incorrect because Multi-Exit Discriminator (MED) is an optional attribute that is not natively supported in this simplified configuration context, whereas route priority is the direct mechanism for path selection here.

## Pregunta 211

Contexto: [topics:725](#topics-725)
As part of your organization's modernization efforts, the application teams are migrating services to GKE on Google Cloud (GKE). The GKE clusters will live in service projects. The teams have validated the applications and configurations in their sandbox projects. When moving to production, you noticed that GKE nodes were not being created. Users were able to create Compute Engine instances, but the operation failed when they tried to create a GKE cluster. You need to enable the application teams so they can create said GKE clusters. What should you do?

**A.** Ensure that the service project's GKE service account has the compute.securityAdmin, container.hostServiceAgentUser and compute.networkUser IAM permissions in the host project.

**B.** Ensure that the service project's GKE service account has the compute.securityAdmin, container.hostserviceAgentUser and compute.networkUser IAM permissions in the service project.

**C.** Ensure that the service project's GKE service account has the compute.networkUser IAM permission in the service project.

**D.** Review the firewall rules configuration in the VPC. Identify what rule is blocking node creation.

**Respuesta de la fuente:** A

**Explicación:** In a Shared VPC architecture, GKE clusters reside in service projects but their nodes and network resources exist within the host project's VPC.
Therefore, the GKE service account in the service project requires specific IAM permissions (compute.securityAdmin, container.hostServiceAgentUser, and compute.networkUser) on the **host project** to successfully create and manage these resources.
Option B is incorrect because granting these permissions only within the service project does not allow access to the host project's infrastructure.

## Pregunta 212

Contexto: [topics:725](#topics-725)
You are implementing a Shared VPC network for your organization, which has distributed teams. One of the application developers works across several teams and notices that they can deploy applications in subnets that are reserved for another application's service projects. You want to ensure that developers can only deploy resources in the subnets that are reserved for their respective service project. What should you do?

**A.** Specify which Shared VPC subnets each application's service projects can access by using the constraints/compute.restrictSharedVpcSubnetworks organizational constraint.

**B.** Grant the compute.NetworkViewer role to the developer in the Shared VPC host project.

**C.** Restrict another application's project from accessing specific subnets in the host project by using the constraints/compute.restrictSharedVpcHostProject organizational constraint.

**D.** Grant the compute.NetworkUser role to the developer in the specific Shared VPC service project.

**Respuesta de la fuente:** A

**Explicación:** The constraints/compute.restrictSharedVpcSubnetworks organizational policy enforces subnet-level access controls at the organization or folder level, preventing service projects from attaching to unauthorized subnets regardless of user IAM permissions.
Granting specific roles like compute.NetworkUser (Option D) only permits resource creation but does not restrict which subnets a project can use if broader network access is already granted.

## Pregunta 213

Contexto: [topics:725](#topics-725)
You are configuring HA VPN for your organization to connect your on-premises environment to your Google Cloud network. Your on-premises environment is closest to the us-west1 Google Cloud region. You have Google Cloud resources in us-west2, which requires a throughput of 300,000 packets per second (PPS) and an approximate bandwidth of 4 Gbps. You need to have predictable bandwidth management and maintain an SLA of 99.99% with minimal costs. What should you do?

**A.** Create an HA VPN gateway with two tunnels. Configure BGP on both tunnels with tunnel 0 configured with a base routing priority metric of 100 and tunnel 1 with a base routing priority metric of 200. Configure the on-premises router with the corresponding multi-exit discriminator (MED) value.

**B.** Create two HA VPN gateways, each with two tunnels. Configure BGP on each of the gateways' tunnels with tunnel 0 configured with a base routing priority metric of 100 and tunnel 1 with a base routing priority metric of 100. Configure the on-premises router with the same corresponding multi-exit discriminator (MED) value.

**C.** Create an HA VPN gateway with two tunnels. Configure BGP on both tunnels with tunnel 0 configured with a base routing priority metric of 100 and tunnel 1 with a base routing priority metric of 100. Configure the on-premises router with the corresponding multi-exit discriminator (MED) value.

**D.** Create an HA VPN gateway with four tunnels. Configure BGP on four tunnels with tunnel 0 configured with a base routing priority metric of 100, tunnel 1 with a base routing priority metric of 200, tunnel 2 with a base routing priority of 300, and tunnel 3 with a base routing priority of 400. Configure the on-premises router with the corresponding multi-exit discriminator (MED) value.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because a single HA VPN gateway with two tunnels provides up to 3 Gbps per tunnel (6 Gbps total) and ~250k PPS per tunnel (500k total), which satisfies the 4 Gbps and 300k PPS requirements. Setting equal base routing priority metrics on both tunnels enables load balancing across them, while configuring corresponding MED values ensures predictable bandwidth management by allowing traffic distribution based on policy rather than just failover. Option B is incorrect because deploying two separate HA VPN gateways increases costs unnecessarily when a single gateway can meet the throughput requirements.

## Pregunta 214

Contexto: [topics:725](#topics-725)
Your organization mandates that all internal IP addresses used by all database VMs must be statically allocated. While analyzing your VPC IP address allocations, you observed that the database VMs do not have static IP addresses. You need to configure the VPC to follow your organization's mandate without causing any disruption to current operations. What should you do?

**A.** Promote the internal IP addresses to static assignments for all database VMs.

**B.** Create a firewall rule to allow only traffic to the IP addresses allocated to your database VMs.

**C.** Define a maintenance window to shut down the database VMs one at a time, promote the internal IP address to a static assignment, and restart the VM.

**D.** Define an organization policy to allow only statically allocated IP addresses for VMs. Ensure the prefix matches your database VMs.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because promoting an ephemeral internal IP address to a static assignment in Google Cloud is a non-disruptive operation that preserves the existing IP without requiring VM downtime or network reconfiguration. Option C suggests a maintenance window with shutdowns, which violates the requirement to avoid disruption, while Options B and D fail to actually change the IP allocation type from dynamic to static.

## Pregunta 215

Contexto: [topics:725](#topics-725)
Your organization deployed a mission critical application that is expected to be a new revenue source. As part of the planning and deployment process, you have recently implemented a security profile with the default set of threat signatures provided by Cloud Next Generation Firewall (Cloud NGFW). This application is the only application running on this project. You need to increase the security posture of the application to log the threat and drop the related packets. What should you do?

**A.** Configure a new default threat signature with Deny All to all severity options. Review the logs to understand the impact.

**B.** Set up a Linux VM as the frontend gateway for the application. Create iptables rules to drop all packets, excluding the application port.

**C.** For all severity options (critical, high, medium, low and informational) in the security profile, change the default override action to Deny.

**D.** Configure Cloud Scheduler to run a task that checks the Cloud NGFW logs to verify the threats. Configure the task to create a security profile with each signature ID set to override the default action.

**Respuesta de la fuente:** C

**Explicación:** To log threats and drop packets in Cloud NGFW, you must configure the action as 'Deny' for the threat signatures.
Option C is correct because it explicitly states changing the override action to 'Deny' for all severity levels, which achieves both logging (implicit in threat detection) and packet dropping.
Option A is incorrect because 'Configure a new default threat signature with Deny All' describes creating a rule or policy rather than modifying the specific signature actions within the existing security profile as required.

## Pregunta 216

Contexto: [topics:725](#topics-725)
You are configuring a Cross-Cloud Interconnect connection for your Google Cloud organization with two public cloud service providers (CSPs)–CSP 1 and CSP 2. The CSP 1 and CSP 2 environments are closest to Frankfurt, Germany. You can choose between two common colocation locations, Frankfurt and Munich. Your organization's Google Cloud infrastructure is deployed in the North American region, us-east4, which is located in Virginia, USA. The VPC dynamic routing mode has been set to GLOBAL. Your organization requires 20 Gbps of protected bandwidth with a 99.9% Google Cloud SLA. You want to minimize costs where possible. What should you do?

**A.** 1. Create two Cross-Cloud Interconnect connections to CSP 1, with 40 Gbps of total bandwidth (20 Gbps in zone 1 and 20 Gbps in zone 2) in a common co-location facility located in Frankfurt, Germany.
2. Create two Cross-Cloud Interconnect connections to CSP 2, with 40 Gbps of total bandwidth (20 Gbps in zone 1 and 20 Gbps in zone 2) in a common co-location facility located in Frankfurt, Germany.
3. Create a Cloud Router in europe-west3 (Frankfurt), and configure two VLAN attachments for CSP 1 and two VLAN attachments for CSP 2.

**B.** 1. Create two Cross-Cloud Interconnect connections to CSP 1, with 20 Gbps of total bandwidth (10 Gbps in zone 1 and 10 Gbps in zone 2) in a common co-location facility located in Frankfurt, Germany.
2. Create two Cross-Cloud Interconnect connections to CSP 2, with 20 Gbps of total bandwidth (10 Gbps in zone 1 and 10 Gbps in zone 2) in a common co-location facility located in Frankfurt, Germany.
3. Create a Cloud Router in europe-west3 (Frankfurt), and configure two VLAN attachments for CSP 1 and two VLAN attachments for CSP 2.

**C.** 1. Create two Cross-Cloud Interconnect connections to CSP 1, with 40 Gbps of total bandwidth (20 Gbps in zone 1) in a common co-location facility located in Frankfurt, Germany and (20 Gbps in zone 2) in a common co-location facility located in Munich, Germany.
2. Create two Cross-Cloud Interconnect connections to CSP 2, with 40 Gbps of total bandwidth (20 Gbps in zone 1) in a common co-location facility located in Frankfurt, Germany and (20 Gbps in zone 2) in a common co-location facility located in Munich, Germany.
3. Create a Cloud Router in europe-west3 (Frankfurt), and configure two VLAN attachments for CSP 1 and two VLAN attachments for CSP 2.

**D.** 1. Create two Cross-Cloud Interconnect connections to CSP 1, with 40 Gbps of total bandwidth (20 Gbps in zone 1 and 20 Gbps in zone 2) in a common co-location facility located in Frankfurt, Germany.
2. Create two Cross-Cloud Interconnect connections to CSP 2, with 40 Gbps of total bandwidth (20 Gbps in zone 1 and 20 Gbps in zone 2) in a common co-location facility located in Frankfurt, Germany.
3. Create a Cloud Router in us-east4 (Ashburn, Virginia, USA), and configure two VLAN attachments for CSP 1 and two VLAN attachments for CSP 2.

**Respuesta de la fuente:** B

**Explicación:** For a Cross-Cloud Interconnect (CCI) configuration requiring a 99.9% SLA, the connections must be deployed in High Availability (HA) pairs across different edge zones within the same region; this redundancy allows for 1:1 protection, meaning that if one 10 Gbps link fails, the other can handle the full 20 Gbps load. Therefore, provisioning 10 Gbps in each zone per CSP is sufficient to meet the 20 Gbps protected bandwidth requirement while minimizing costs compared to provisioning 40 Gbps total. Additionally, the Cloud Router must be located in the same region (europe-west3) as the interconnect attachments (Frankfurt), and since Global dynamic routing mode is enabled, the routes will automatically propagate to the us-east4 region, making a router in Virginia incorrect and unnecessary.

## Pregunta 217

Contexto: [topics:725](#topics-725)
Your organization's application is running on a VPC-native GKE Standard cluster with public IP addresses. You need to configure access to the remote address range 35.100.0.0/16 through Cloud NAT, instead of using the GKE nodes' external IP addresses. SNAT is enabled on the cluster and needs to be configured. What should you do?

**A.** Configure nonMasqueradeCIDRs in the ip-masq-agent ConfigMap. Include the 35.100.0.0/16 range in the list.

**B.** Configure nonMasqueradeCIDRs in the ip-masq-agent ConfigMap. Remove the 35.100.0.0/16 range from the list.

**C.** Configure Cloud NAT and create an exclusion rule for any SNAT address translation.

**D.** Configure Cloud NAT with nonMasqueradeCIDRs, and enable SNAT with the same configuration to allow traffic to 35.100.0.0/16.

**Respuesta de la fuente:** B

**Explicación:** The ip-masq-agent's nonMasqueradeCIDRs list defines destinations where SNAT is skipped, allowing traffic to exit with the Pod's private IP so Cloud NAT can process it.
To route traffic to 35.100.0.0/16 through Cloud NAT, this range must NOT be in the nonMasqueradeCIDRs list, ensuring the node performs SNAT correctly for Cloud NAT interception.
Therefore, you should remove the range from the list (or ensure it is absent) so that packets retain their private source IP until they reach the Cloud NAT gateway.

## Pregunta 218

Contexto: [topics:725](#topics-725)
Your organization has approximately 100 teams that need to manage their own environments. A central team must manage the network. You need to design a landing zone that provides separate projects for each team. You must also make sure the solution can scale. What should you do?

**A.** Configure Policy-based Routing for each team.

**B.** Configure a Shared VPC, and create a VPC network in the host project.

**C.** Configure VPC Network Peering, and peer one of the VPC's to the service project.

**D.** Configure a Shared VPC, and create a VPC network in the service project.

**Respuesta de la fuente:** B

**Explicación:** Shared VPC is the correct architecture for multi-project environments because it allows a central team to manage networking in a single host project while granting other teams access via service projects. This ensures scalability and centralized control, satisfying the requirement for separate projects per team with managed networks. Option D is incorrect because Shared VPC requires the network to be created in the host project, not the service project.

## Pregunta 219

Contexto: [topics:725](#topics-725)
You are using Network Connectivity Center and you already have the hub configured. All VPCs in your environment need to have network connectivity to each other. All the subnet ranges are unique. You need to configure your topology accordingly. What should you do?

**A.** Configure a star topology, add the VPC spokes to the hub, and specify all subnet ranges in the excludeExportRanges filter.

**B.** Configure a mesh topology, add the VPC spokes to the hub, and specify all subnet ranges in the excludeExportRanges filter.

**C.** Configure a mesh topology, and add the VPC spokes to the hub.

**D.** Configure a star topology, and add the VPC spokes to the hub.

**Respuesta de la fuente:** C

**Explicación:** A mesh topology in Network Connectivity Center automatically propagates routes between all attached VPC spokes, satisfying the requirement for full mutual connectivity without manual configuration.
Star topologies only connect spokes to the hub but do not enable spoke-to-spoke communication by default.
The excludeExportRanges filter is unnecessary because the scenario states that all subnet ranges are already unique.

## Pregunta 220

Contexto: [topics:725](#topics-725)
You are creating a design that will connect your single on-premises data center to a VPC in Google Cloud by using an IPsec VPN connection. The connection must have a minimum SLA of 99.99%. There is a single VPN termination device located in your on-premises data center. The VPN termination device can be configured only with a single public IP address. Your design must also have the least amount of setup effort. What should you do?

**A.** 1. Create two HA VPN gateways.
2. Create one tunnel on interface 0 of one gateway and create one tunnel on interface 1 of the other gateway.
3. Terminate each of the two tunnels on the single public IP address that is configured on the VPN termination device located in your on-premises data center.

**B.** 1. Create one Classic VPN gateway and one HA VPN gateway.
2. Create one tunnel on the interface of the Classic VPN gateway and one tunnel on interface 1 of the HA VPN gateway.
3. Terminate each of the two tunnels on the single public IP address that is configured on the VPN termination device located in your on-premises data center.

**C.** 1. Replace the existing on-premises VPN termination device with a new device that is configured with two different public IP addresses.
2. Create one HA VPN gateway.
3. Create one tunnel for each of the two HA VPN gateway interfaces.
4. Terminate each of the two tunnels on one of the two public IP addresses that is configured on the new VPN termination device located in your on-premises data center.

**D.** 1. Create one HA VPN gateway.
2. Create one tunnel for each of the two HA VPN gateway interfaces.
3. Terminate each of the two tunnels on the single public IP address that is configured on the VPN termination device located in your on-premises data center.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Google Cloud supports a 99.99% SLA for HA VPN when two tunnels are established to a single on-premises IP address, satisfying the redundancy requirement without changing on-premises hardware. This configuration minimizes setup effort by utilizing the existing single IP constraint while ensuring both interfaces of the HA VPN gateway are active. Option C is incorrect because replacing the on-premises device increases setup effort and contradicts the requirement to use the existing constraints.

## Pregunta 221

Contexto: [topics:725](#topics-725)
Your organization has a highly available application that is not HTTP-based. The application runs on multiple TCP ports and is hosted in multiple regions. You need to design a solution to load balance the application in the same Shared VPC where the service will be accessed. The IP address header must contain the client's true source IP address. No public internet access is required. What should you do?

**A.** Configure multiple regional internal proxy Network Load Balancers and enable global access. Use DNS routing policies to balance traffic across regions.

**B.** Configure multiple regional internal Application Load Balancers and enable global access. Use DNS routing policies to balance traffic across regions.

**C.** Configure a single cross region internal proxy Network Load Balancer.

**D.** Configure multiple regional internal passthrough Network Load Balancers and enable global access. Use DNS routing policies to balance traffic across regions.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Internal Passthrough Network Load Balancers operate at Layer 4 (TCP/UDP), supporting non-HTTP protocols while preserving the client's original source IP address without proxy translation. Using multiple regional instances with global access and DNS routing policies ensures high availability across regions within the Shared VPC, satisfying all requirements for internal, multi-region load balancing with true client IP preservation.

Option C is incorrect because Internal Proxy Network Load Balancers perform TCP connection reset/termination to the backend, which replaces the client source IP with the proxy's IP (unless specific header insertion is configured, but Passthrough is the standard method for native IP preservation). Option A uses Proxy NLBs which alter the source IP. Option B is invalid because Application Load Balancers are HTTP/HTTPS-based and do not support arbitrary TCP ports.

## Pregunta 222

Contexto: [topics:725](#topics-725)
Your organization is using a Shared VPC model. Service project owners want to independently manage their DNS zones in service projects. All service project workloads must be able to resolve all private zones that are defined in other service projects. You need to create a solution that meets these goals. What should you do?

**A.** Create a Cloud DNS private zone in each service project. Use a Cloud DNS forwarding zone to forward queries to the Shared VPC in the host project.

**B.** Create a Cloud DNS private zone in each service project. Use Cloud DNS peering zones that target the Shared VPC in the host project.

**C.** Create a Cloud DNS response policy zone in each service project. Use Cloud DNS peering zones that target the Shared VPC in the host project.

**D.** Create a Cloud DNS private zone in each service project. Use cross-project binding to associate the zones to the Shared VPC in the host project.

**Respuesta de la fuente:** D

**Explicación:** Cloud DNS supports cross-project bindings, allowing private zones created in service projects to be associated with a VPC network hosted in a different project (the Shared VPC host). This enables service project owners to maintain independent management of their own DNS zones while ensuring that workloads across the entire Shared VPC network can resolve names defined in any of those zones. Forwarding and peering are unnecessary because the zones are natively visible to the shared network via the binding, making option D the most direct and correct solution.

## Pregunta 223

Contexto: [topics:725](#topics-725)
Your organization wants to deploy HA VPN over Cloud Interconnect to ensure encryption-in-transit over the Cloud Interconnect connections. You have created a Cloud Router and two encrypted VLAN attachments that have a 5 Gbps capacity and a BGP configuration. The BGP sessions are operational. You need to complete the deployment of the HA VPN over Cloud Interconnect. What should you do?

**A.** Create an HA VPN gateway and associate the gateway with your two encrypted VLAN attachments. Configure the HA VPN Cloud Router, peer VPN gateway resources, and HA VPN tunnels. Use the same encrypted Cloud Router used for the Cloud Interconnect tier.

**B.** Enable MACsec on Partner Interconnect.

**C.** Enable MACsec for Cloud Interconnect on the VLAN attachments.

**D.** Create an HA VPN gateway and associate the gateway with your two encrypted VLAN attachments. Create a new dedicated HA VPN Cloud Router, peer VPN gateway resources, and HA VPN tunnels.

**Respuesta de la fuente:** D

**Explicación:** Google Cloud requires separate operational tiers for Cloud Interconnect and HA VPN to ensure isolation and proper routing control.
You must create a dedicated Cloud Router specifically for the HA VPN tier, distinct from the router used for the standard Cloud Interconnect VLAN attachments.
Option A is incorrect because it suggests reusing the existing Cloud Router, which violates the architectural separation required between the two tiers.

## Pregunta 224

Contexto: [topics:725](#topics-725)
You have recently taken over responsibility for your organization's Google Cloud network security configurations. You want to review your Cloud Next Generation Firewall (Cloud NGFW) configurations to ensure that there are no rules allowing ingress traffic to your VMs and services from the internet. You want to avoid manual work. What should you do?

**A.** Export all your Cloud NGFW rules into a CSV file and search for 0.0.0.0/0.

**B.** Use Firewall Insights, and enable insights for Overly permissive rules.

**C.** Run Connectivity Tests from multiple external sources to confirm that traffic is not allowed to ingress to your most critical services in Google Cloud.

**D.** Review Network Analyzer insights on the VPC network category.

**Respuesta de la fuente:** B

**Explicación:** Firewall Insights specifically analyzes firewall rules to identify security issues, such as overly permissive rules that allow ingress traffic from the internet (0.0.0.0/0). This provides an automated, targeted review without manual work, directly addressing the requirement to avoid manual effort.
Option A involves exporting and manually searching a CSV file, which contradicts the goal of avoiding manual work.

## Pregunta 225

Contexto: [topics:725](#topics-725)
Your organization is connecting their Shared VPC network to their on-premises data center by using Dedicated Interconnect to provide connectivity to all of its service projects. You need to create a design to configure your VLAN attachments and Cloud Routers. You also want to achieve a 99.9% Cloud Interconnect SLA based on Google Cloud s reference design. What should you do?

**A.** Create two Cloud Interconnect connections in different edge availability domains of two different co-location facilities in a project that will contain your connections. Create one VLAN attachment and Cloud Router for each physical interconnect in the Shared VPC host project.

**B.** Create two Interconnect connections in different edge availability domains of the co-location facility in a project that will contain your connections. Create one VLAN attachment for each physical Cloud Interconnect connection and a single Cloud Router in the Shared VPC host project.

**C.** Create two Cloud Interconnect connections in different edge availability domains of the co-location facility in a project that will contain your connections. Create one VLAN attachment for each physical interconnect and a single Cloud Router in the service projects.

**D.** Create two Cloud Interconnect connections in different edge availability domains of the co-location facility in a project that will contain your connections. Create a Cloud Router in the Shared VPC host project and the VLAN attachments in the Shared VPC service projects.

**Respuesta de la fuente:** B

**Explicación:** To achieve the 99.9% SLA, Google Cloud's reference design mandates two Dedicated Interconnect connections in different edge availability domains within the same facility to provide redundancy without requiring cross-facility complexity.
A single Cloud Router in the Shared VPC host project is sufficient to manage BGP sessions for both VLAN attachments, centralizing network management and adhering to Shared VPC best practices where networking resources reside in the host project rather than service projects.

## Pregunta 226

Contexto: [topics:725](#topics-725)
Your organization's on-premises networking team is reporting frequent BGP session flaps toward your Google Cloud environment. You need to review the BGP configuration. What should you do?

**A.** Switch to static routing.

**B.** Increase the BGP hold timer to 36000 seconds max.

**C.** Ensure that graceful restart is enabled on the on-premises router.

**D.** Ask the on-premises team to enable Bidirectional Forwarding Detection (BFD).

**Respuesta de la fuente:** C

**Explicación:** According to Google Cloud documentation on troubleshooting BGP sessions, enabling graceful restart on the on-premises router is the recommended step to mitigate frequent session flaps. Graceful restart allows the BGP neighbor to retain routing information during transient control plane interruptions, preventing unnecessary session resets.
Enabling BFD (Option D) is incorrect because it accelerates failure detection, which would exacerbate flapping by causing faster session drops rather than stabilizing the connection.

## Pregunta 227

Contexto: [topics:725](#topics-725)
Your organization has over 250 autonomous business units that currently operate in a decentralized manner. Due to the organization's maturity, there is limited routable private IP address space, which is insufficient to accommodate all of the necessary workloads. You need to create a cloud-first network design that uses the same IP address space across business unit workloads where possible. These business units require communication between units, and access to their on-premises data center. What should you do?

**A.** Create a hub and spoke model that incorporates VPC Network Peering with hybrid connectivity centralized within the hub.

**B.** Create a Network Connectivity Center design that incorporates Private NAT to facilitate communication between VPC spokes, and a Routing VPC to exchange dynamic routes from the on-premises environment.

**C.** Create a Network Connectivity Center design that incorporates Private Service Connect to provide bidirectional communication between VPC spokes, and a Routing VPC to exchange dynamic routes from the on-premises environment.

**D.** Create a hub and spoke design that incorporates a centralized network virtual appliance (NVA) in the hub to perform routing and NAT between spokes.

**Respuesta de la fuente:** B

**Explicación:** Network Connectivity Center (NCC) is the recommended architecture for large-scale deployments requiring overlapping IP address spaces across many VPCs.
Private NAT allows spokes with identical IP ranges to communicate without address conflicts, while a Routing VPC handles dynamic route exchange from on-premises.

## Pregunta 228

Contexto: [topics:725](#topics-725)
You are configuring an Application Load Balancer. The backend resides in your on-premises data center and is connected by Dedicated Interconnect. You need to ensure the load balancer can reference these on-premises resources. You do not want the traffic to traverse the internet at all. What should you do?

**A.** Configure an internet network endpoint group (NEG) as a backend service as part of the load balancer. Ensure firewalls are opened for the proxy-only subnet.

**B.** Configure a zonal network endpoint group (NEG) as a backend service as part of the load balancer. Ensure firewalls are opened for the client source IPs.

**C.** Configure a hybrid network endpoint group (NEG) as a backend service as part of the load balancer. Ensure firewalls are opened for the proxy-only subnet.

**D.** Configure a Private Service Connect network endpoint group (NEG) as a backend service as part of the load balancer. Ensure firewalls are opened for the client source IPs.

**Respuesta de la fuente:** C

**Explicación:** Hybrid Network Endpoint Groups (NEGs) are specifically designed to reference on-premises backend resources connected via Cloud Interconnect or VPN, keeping traffic off the public internet. Option A is incorrect because Internet NEGs require backends to be accessible via the public internet, which violates the security constraint.

## Pregunta 229

Contexto: [topics:725](#topics-725)
You are troubleshooting connectivity issues between Google Cloud and a public SaaS provider. Connectivity between the two environments is through the public internet. Your users are reporting intermittent connection errors when using TCP to connect; however, ICMP tests show no failures. According to users, errors occur around the same time every day. You want to troubleshoot and gather information by using Google Cloud tools that are most likely to provide insights to what is occurring within Google Cloud. What should you do?

**A.** Enable and review Cloud Logging for Cloud Armor. Look for logs with errors matching the destination IP address of the public SaaS provider.

**B.** Enable and review Cloud Logging on your Cloud NAT gateway. Look for logs with errors matching the destination IP address of the public SaaS provider.

**C.** Enable the Firewall Insights API. Set the deny rule insights observation period to one day. Review the insights to assure there are no firewall rules denying traffic.

**D.** Create a Connectivity Test by using TCP, the source IP address of your test VM, and the destination IP address of the public SaaS provider. Review the live data plane analysis and take the next steps based on the test results.

**Respuesta de la fuente:** B

**Explicación:** The symptoms of intermittent TCP failures with successful ICMP pings strongly suggest NAT port exhaustion, as TCP connections consume ephemeral ports while ICMP does not. Enabling Cloud Logging on the Cloud NAT gateway allows you to monitor connection counts and identify dropped packets due to resource limits, which aligns with the recurring daily timing indicating peak usage. Connectivity Tests (Option D) verify policy feasibility but do not detect runtime resource exhaustion like full NAT tables.

## Pregunta 230

Contexto: [topics:725](#topics-725)
You configured a single IPSec Cloud VPN tunnel for your organization to a third-party customer. You confirmed that the VPN tunnel is established. However, the BGP session status states that the BGP is not configured. The customer has provided you with their BGP settings:

•	Local BGP address: 169.254.11.1/30
•	Local ASN: 64515
•	Peer BGP address: 169.254.11.2
•	Peer ASN: 64517
•	Base MED: 1000
•	MD5 Authentication: Disabled

You need to configure the local BGP session for this tunnel based on the settings provided by the customer. You already associated the Cloud Router with the Cloud VPN Tunnel. What settings should you use for the BGP session?

**A.** Peer ASN: 64517 -
Advertised Route Priority (MED): 100

Local BGP IP: 169.254.11.2 -

Peer BGP IP: 169.254.11.1 -
MD5 Authentication: Disabled

**B.** Peer ASN: 64515 -
Advertised Route Priority (MED): 100

Local BGP IP: 169.254.11.1 -

Peer BGP IP: 169.254.11.2 -
MD5 Authentication: Disabled

**C.** Peer ASN: 64515 -
Advertised Route Priority (MED): 100

Local BGP IP: 169.254.11.2 -

Peer BGP IP: 169.254.11.1 -
MD5 Authentication: Disabled

**D.** Peer ASN: 64515 -
Advertised Route Priority (MED): 1000

Local BGP IP: 169.254.11.2 -

Peer BGP IP: 169.254.11.1 -
MD5 Authentication: Enabled

**Respuesta de la fuente:** C

**Explicación:** In a BGP peering configuration, the local and peer IP addresses must be mirrored between the two sides to establish a valid point-to-point link; since the customer's local IP is 169.254.11.1, the local IP on your side must be 169.254.11.2, and vice versa for the peer IP.
Additionally, the Peer ASN must correspond to the customer's local ASN (64515), and the MD5 authentication must remain disabled as specified in the provided settings, which eliminates options A, B, and D.

## Pregunta 231

Contexto: [topics:725](#topics-725)
Your organization's current architecture has one Shared VPC host project (SH_HOST_PRJ) that contains a single VPC (SH_VPC) and two Shared VPC service projects (SP_ONE_PRJ and SP_TWO_PRJ) that do not contain any VPCs. Each Shared VPC service project belongs to a different team: TEAM_ONE manages SP_ONE_PRJ and TEAM_TWO manages SP_TWO_PRJ.

You must design a solution that allows each team to create their own DNS private zones and DNS records only in their respective Shared VPC service projects. Workloads in SP_ONE_PRJ must be able to resolve all the DNS private zones defined in SP_TWO_PRJ and conversely. Your design must have the least amount of set up effort. What should you do?

**A.** 1. TEAM_ONE uses cross-project binding and creates Cloud DNS private zones and DNS records in SP_ONE_PRJ, and binds the zones to the Shared VPC host project (SH_HOST_PRJ).
2. TEAM_TWO creates Cloud DNS private zones and DNS records in SP_TWO_PRJ, and uses cross-project binding to connect the zones to the Shared VPC host project (SH_HOST_PRJ).

**B.** 1. TEAM_ONE uses cross-project binding and creates Cloud DNS private zones and DNS records in SP_ONE_PRJ, and binds the zones to the VPC (SH_VPC) in the Shared VPC host project (SH_HOST_PRJ).
2. TEAM_TWO creates DNS private zones and DNS records in SP_TWO_PRJ and uses cross-project binding to connect the zones to the VPC (SH_VPC) in the Shared VPC host project (SH_HOST_PRJ).

**C.** 1. TEAM_ONE creates a new VPC (SP_ONE_VPC) in the Shared VPC service projects (SP_ONE_PRJ). TEAM_ONE creates Cloud DNS private zones and DNS records in SP_ONE_PRJ, and binds the zones to the new VPC (SP_ONE_VPC). TEAM_ONE creates a Cloud DNS peering relationship between SP_ONE_VPC and the VPC (SH_VPC) in the Shared VPC host project (SH_HOST_PRJ).
2. TEAM_TWO completes the same actions for the SP_TWO_PRJ project.

**D.** 1. TEAM_ONE creates a new VPC (SP_ONE_VPC) in the Shared VPC service projects (SP_ONE_PRJ). TEAM_ONE creates Cloud DNS private zones and DNS records in SP_ONE_PRJ, and binds the zones to the new VPC (SP_ONE_VPC). TEAM_ONE creates a VPC Network Peering relationship between SP_ONE_VPC and the VPC (SH_VPC) in the Shared VPC host project (SH_HOST_PRJ).
2. TEAM_TWO completes the same actions for the SP_TWO_PRJ project.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Cloud DNS private zones are bound to VPC networks, not projects. In a Shared VPC architecture, service projects do not contain VPCs; the single VPC resides in the host project. Therefore, each team must create zones in their service project and use cross-project binding to associate those zones with the specific SH_VPC in the host project.

Option A is incorrect because it states binding to the 'host project' rather than the 'VPC', which is technically imprecise as DNS scope is network-level. Options C and D are wrong because Shared VPC service projects cannot create their own VPCs, making those steps invalid.

## Pregunta 232

Contexto: [topics:725](#topics-725)
You are troubleshooting an application in your organization's Google Cloud network that is not functioning as expected. You suspect that packets are getting lost somewhere. The application sends packets intermittently at a low volume from a Compute Engine VM to a destination on your on-premises network through a pair of Cloud Interconnect VLAN attachments. You validated that the Cloud Next Generation Firewall (Cloud NGFW) rules do not have any deny statements blocking egress traffic, and you do not have any explicit allow rules. Following Google-recommended practices, you need to analyze the flow to see if packets are being sent correctly out of the VM to isolate the issue. What should you do?

**A.** Create a packet mirroring policy that is configured with your VM as the source and destined to a collector. Analyze the packet captures.

**B.** Enable VPC Flow Logs on the subnet that the VM is deployed in with SAMPLE_RATE = 1.0, and run a query in Logs Explorer to analyze the packet flow.

**C.** Verify the network/attachment/egress_dropped_packets_count Cloud Interconnect VLAN attachment metric.

**D.** Enable Firewall Rules Logging on your firewall rules and review the logs.

**Respuesta de la fuente:** A

**Explicación:** Packet Mirroring (Option A) is the correct choice because it captures every packet from the specified source VM, ensuring no data loss during analysis. This is critical for low-volume, intermittent traffic where VPC Flow Logs might still miss flows due to sampling mechanisms or aggregation latency. While VPC Flow Logs provide metadata, they do not offer the full packet capture required to definitively troubleshoot packet loss at the application layer in this specific scenario.

## Pregunta 233

Contexto: [topics:725](#topics-725)
Your organization is launching a new video game that will be available to all users globally through Cloud CDN. During the earl y release phase, you discovered that the wrong binary version was uploaded from Cloud Storage and cached in Cloud CDN. Thousands of users have downloaded the wrong version. Your marketing department has notified users that this was the wrong version of the game and asked all users to download the updated version using the same URL. You need to ensure users are downloading the updated version of the game. What should you do?

**A.** Create a security policy to block all Cloud CON requests, review the logs, and filter which users are attempting to download the wrong game binary.

**B.** Create a new URL path for the updated game binary. Allow the cache to expire automatically through HTTP headers.

**C.** Upload the updated game binary to Cloud Storage. Invalidate the wrong game binary from the Cloud CDN cache.

**D.** Disable Cloud CDN. Reconfigure the load balancer with the updated game binary. Enable Cloud CDN.

**Respuesta de la fuente:** C

**Explicación:** Cloud CDN caches content based on origin server responses, and invalidation is the specific mechanism designed to immediately remove stale objects from the cache before their TTL expires.
By uploading the correct binary to Cloud Storage and then issuing a cache invalidation, you ensure that all subsequent requests for that URL are served the updated version globally without waiting for automatic expiration.
Option B is incorrect because relying on automatic expiration via HTTP headers could take an indeterminate amount of time, leaving thousands of users with the wrong version during that window.

## Pregunta 234

Contexto: [topics:725](#topics-725)
You recently reviewed the user behavior for your main application, which uses an external global Application Load Balancer, and found that the backend servers were overloaded due to erratic spikes in the rate of client requests. You need to limit the concurrent sessions and return an HTTP 429 Too Many Requests response back to the client while following Google-recommended practices. What should you do?

**A.** Create a Cloud Armor security policy, and associate the policy with the load balancer. Configure the security policy's settings as follows: action: throttle; conform action: allow; exceed action: deny-429.

**B.** Configure the load balancer to accept only the defined amount of requests per client IP address, increase the backend servers to support more traffic, and redirect traffic to a different backend to burst traffic.

**C.** Create a Cloud Armor security policy, and apply the predefined Open Worldwide Security Application Project (OWASP) rules to automatically implement the rate limit per client IP address.

**D.** Configure a VM with Linux, implement the rate limit through iptables, and use a firewall rule to send an HTTP 429 response to the client application.

**Respuesta de la fuente:** A

**Explicación:** Cloud Armor is the Google-recommended solution for rate limiting on Global Application Load Balancers.
Configuring the action as 'throttle' allows normal traffic to pass (conform action: allow) while enforcing limits on excessive requests.
Setting the exceed action to 'deny-429' specifically returns the HTTP 429 Too Many Requests status code required by the scenario.
Option C is incorrect because OWASP rules focus on known attack patterns (like SQL injection) rather than generic rate limiting based on concurrent sessions or request spikes.

## Pregunta 235

Contexto: [topics:725](#topics-725)
Your company uses web application firewall (WAF) capabilities from a third-party cloud WAF provider. This WAF provider proxies all the HTTPS connections from internet clients, applies security policies, and then opens a new HTTPS connection to the public IP address of your global Application Load Balancer in Google Cloud. Your Google Cloud workloads are the backend of this global Application Load Balancer. Currently, Cloud Am1or is not configured. You need to create a Cloud Armor security policy that blocks sessions that originate from internet clients with source IP addresses that belong to the IP_RANGE_BLOCK IP range. The block must be executed by the Cloud Armor security policy; it will not be done by the third-party cloud WAF provider. Whal should you do?

**A.** 1. Create a new Cloud Armor network edge security policy. In the policy, set the userIpRequestHeaders[] attribute.
2. Add a policy rule that denies traffic that matches inIpRange(origin.user_ip, 'IP_RANGE_BLOCK') statement.
3. Apply the policy to the backend service that includes all your Google Cloud workloads.

**B.** 1. Create a new Cloud Armor network edge security policy. In the policy, set the userIpRequestHeaders[] attribute.
2. Add a policy rule that denies traffic that matches the inIpRange(origin.ip, 'IP_RANGE_BLOCK') statement.
3. Apply the policy to the backend service that includes all your Google Cloud workloads.

**C.** 1. Create a new Cloud Armor backend security policy. In the policy, set the userIpRequestHeaders[] attribute.
2. Add a policy rule that denies traffic that matches the inIpRange(origin.user_ip, 'IP_RANGE_BLOCK') statement.
3. Apply the policy to the backend service that includes all your Google Cloud workloads.

**D.** 1. Create a new Cloud Armor backend security policy. In the policy, set the userIpRequestHeaders[] attribute.
2. Add a policy rule that denies traffic that matches the inIpRange(origin.ip, 'IP_RANGE_BLOCK') statement.
3. Apply the policy to the backend service that includes all your Google Cloud workloads.

**Respuesta de la fuente:** C

**Explicación:** A Cloud Armor backend security policy is required because it protects the backend service of the load balancer, whereas network edge policies are primarily for Cloud CDN or Cloud Storage.
Since the traffic originates from a third-party WAF proxy, the direct source IP (`origin.ip`) will be the WAF's address, not the client's; therefore, you must configure `userIpRequestHeaders` and use `origin.user_ip` to inspect the original client IP forwarded in headers.

## Pregunta 236

Contexto: [topics:725](#topics-725)
Your organization, TerramEarth, is launching a global application to manage credit card payments. There are some client VMs inside the same VPC as the application that need to access this application privately. Due to compliance requirements, the internal clients cannot use the global external IP address of the application. Currently, Cloud DNS only resolves myglobalapp.terramearth.com to the public IP address with a public zone. The clients will need to reach myglobalapp.example.com, without using its external IP address. You need to configure Cloud DNS to follow this requirement while following Google-recommended practices. What should you do?

**A.** Create a sub-domain named internal.terramearth.com. Add the new DNS entry (myglobalapp.internal.terramearth.com) to the sub-domain pointing to the internal IP address from the application VM.

**B.** Configure a query logic script inside Cloud DNS to check the source IP address from the VPC, and respond with a modified DNS record to include the internal IP address from the application VM.

**C.** Configure a private zone for the application record (myglobalapp.terramearth.com) and point to the internal IP address of the application VM. Bind this zone to the VPC.

**D.** Promote the ephemeral IP address from the application VM to static, add this static ip address to each internal client's host file, and change the myglobalapp.terramearth.com DNS record to this new static IP address.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it implements a Private DNS zone bound to the VPC, allowing internal clients to resolve the FQDN to an internal IP without traversing the public internet. This adheres to GCP best practices for Split-Horizon DNS, ensuring compliance with the requirement to avoid external IP usage while maintaining the same hostname. Option A is incorrect because creating a sub-domain introduces unnecessary complexity and deviates from the goal of resolving the existing myglobalapp.terramearth.com record internally without external exposure.

## Pregunta 237

Contexto: [topics:725](#topics-725)
You are setting up a Dedicated Interconnect connection from your organization’s on-premises data center in Frankfurt, Germany, towards the europe-west3 region, which is also in the Frankfurt metropolitan area. The AI team lead expressed their concern regarding connectivity to the europe-west4 region because their team wants to use Google Cloud TPUs for their workloads. You need to ensure that low latency network connectivity is established for this team’s workloads. You want to minimize costs and operational overhead. What should you do?

**A.** Set up the Dedicated Interconnect connection towards the europe-west4 region instead of the europe-west3 region.

**B.** Set up an additional Partner Interconnect connection between your data center and the europe-west4 region.

**C.** Set up a remote VLAN attachment to the europe-west4 region on the Dedicated Interconnect connection.

**D.** Use Cloud VPN instead of Dedicated Interconnect to send traffic over the internet.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because a remote VLAN attachment allows the existing Dedicated Interconnect to connect to multiple regions, providing low-latency backbone connectivity without the high cost and operational overhead of provisioning a second physical interconnect (Option B or A). Cloud VPN (Option D) traverses the public internet, which fails the low-latency requirement and is less reliable.

## Pregunta 238

Contexto: [topics:725](#topics-725)
Your company uses VPC firewall rules and denies all egress traffic. You need to allow some VMs to contact external websites based on their fully qualified domain name (FQDN). You apply the new configuration, but the traffic is still denied. You need to adjust your setup to apply the new configuration. What would you do?

**A.** Raise the priority of the network firewall policy rules.

**B.** Lower the priority of the network firewall policy rules.

**C.** Update the default policy and rule evaluation order to BEFORE_CLASSIC_FIREWALL.

**D.** Update the default policy and rule evaluation order to AFTER_CLASSIC_FIREWALL.

**Respuesta de la fuente:** C

**Explicación:** In Google Cloud, classic VPC firewall rules do not support FQDN matching; only network firewall policies do. Since the 'deny all' classic rule is evaluated before the new policy (default order), it blocks traffic before the allow rule can apply. Changing the evaluation order to BEFORE_CLASSIC_FIREWALL ensures the network firewall policy (with the FQDN allow rule) is processed first, permitting the specific traffic.

## Pregunta 239

Contexto: [topics:725](#topics-725)
Your VPC is configured with regional dynamic routing mode. You have deployed VMs and VLAN attachments in the europe-west2 region, and regional internal Application Load Balancers in us-east1. You need to ensure the VMs in the europe-west2 region have connectivity to the regional internal Application Load Balancers in the us-east1 region. What should you do?

**A.** Create the backend in us-east1, create multiple forwarding rules in each region, and then enable regional access.

**B.** Create the backend service in europe-west2, create the forwarding rule in us-east1, and then enable regional access.

**C.** Create the backend service in us-east1, create the forwarding rule in europe-west2, and then enable global access.

**D.** Create the backend service in us-east1, create the forwarding rule in us-east1, and then enable global access.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because creating both the backend service and forwarding rule in us-east1 aligns with regional Internal ALB requirements, while enabling 'Global Access' allows clients from other regions (like europe-west2) to connect despite routing mode constraints. Option B is incorrect because Internal ALB components (backend and frontend) must reside in the same region, preventing a backend in europe-west2 from serving a forwarding rule in us-east1.

## Pregunta 240

Contexto: [topics:725](#topics-725)
You are designing the architecture for your organization so that clients can connect to certain Google APIs. Your plan must include a way to connect to Cloud Storage and BigQuery. You also need to ensure the traffic does not traverse the internet. You want your solution to be cloud-first and require the least amount of configuration steps. What should you do?

**A.** Configure Private Google Access on the VPC resource. Create a default route to the internet.

**B.** Configure Private Google Access on the subnet resource. Create a default route to the internet.

**C.** Configure Cloud NAT, and remove the default route to the internet.

**D.** Configure a global Secure Web Proxy, and remove the default route to the internet.

**Respuesta de la fuente:** B

**Explicación:** Private Google Access must be configured at the subnet level, not the VPC level, making option A incorrect. Although traffic to Google APIs stays on the private network, the VPC still requires a default route pointing to the internet gateway to function correctly with Private Google Access, validating option B over C and D which remove it or use unnecessary components.

## Pregunta 241

Contexto: [topics:725](#topics-725)
You have configured a single IPSec Cloud VPN tunnel for your organization to one of your customers. The VPN Tunnel Status is showing as Established; however the BGP Session Status is showing as BGP not configured. Your customer’s BGP settings are:

•	Customer BGP address: 169.254.11.1/30
•	Customer ASN: 64515
•	Google Cloud BGP address: 169.254.11.2
•	Google Cloud ASN: 64517
•	MD5 Authentication: Disabled

You need to configure your local BGP session for this tunnel based on the settings provided by the third party customer. You have already associated the Cloud Router with the Cloud VPN Tunnel. What should you do?

**A.** Create a BGP session with these settings:
•	Peer ASN: 64517
•	Advertise Route Priority (MED): 100
•	Local BGP IP: 169.254.11.2
•	Peer BGP IP: 169.254.11.1
•	MD5 Authentication: Disabled.

**B.** Create a BGP session with these settings:
•	Peer ASN: 64515
•	Advertise Route Priority (MED): 100
•	Local BGP IP: 169.254.11.1
•	Peer BGP IP: 169.254.11.2
•	MD5 Authentication: Disabled.

**C.** Create a BGP session with these settings:
•	Peer ASN: 64515
•	Advertise Route Priority (MED): 100
•	Local BGP IP: 169.254.11.2
•	Peer BGP IP: 169.254.11.1
•	MD5 Authentication: Disabled.

**D.** Create a BGP session with these settings:
•	Peer ASN: 64515
•	Advertise Route Priority (MED): 1000
•	Local BGP IP: 169.254.11.2
•	Peer BGP IP: 169.254.11.1
•	MD5 Authentication: Enabled.

**Respuesta de la fuente:** C

**Explicación:** To establish the BGP session, you must configure your local Google Cloud Router with the peer's ASN (64515), your own local IP address (169.254.11.2), and the customer's peer IP address (169.254.11.1). Option C is correct because it accurately maps these roles: Peer ASN matches the customer's ASN, Local BGP IP is Google's address, and Peer BGP IP is the customer's address, while respecting the disabled MD5 setting. Option A is incorrect because it uses Google's ASN (64517) as the Peer ASN, which would prevent session establishment since peers must have different ASNs.

## Pregunta 242

Contexto: [topics:725](#topics-725)
Your organization has an on-premises data center. You need to provide connectivity from the on-premises data center to Google Cloud. Bandwidth must be at least 1 Gbps, and the traffic must not traverse the internet. What should you do?

**A.** Configure HA VPN by using high availability gateways and tunnels.

**B.** Configure Cross-Cloud Interconnect by creating a VLAN attachment, activate the connection, and then submit the pairing key to your service provider.

**C.** Configure Dedicated Interconnect by creating a VLAN attachment, activate the connection, and submit the pairing key to your service provider.

**D.** Configure Partner Interconnect by creating a VLAN attachment, submit the pairing key to your service provider, and activate the connection.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Partner Interconnect supports bandwidths starting at 1 Gbps and provides private connectivity that does not traverse the public internet, meeting both requirements.
Option C (Dedicated Interconnect) is incorrect primarily because it typically requires a minimum commitment of 10 Gbps, which exceeds the specific 'at least 1 Gbps' constraint more efficiently than Partner Interconnect, and involves direct physical cabling rather than the partner-mediated VLAN attachment process described.

## Pregunta 243

Contexto: [topics:725](#topics-725)
Your company’s web application was just deployed on Compute Engine VMS in multiple Google Cloud regions. You have created multiple instance groups and you need to distribute traffic between these VMs. You want your users to automatically connect to the backend that is located in the closest region while following Google-recommended practices. What should you do?

**A.** Create one global external Application Load Balancer and multiple backend services. Ensure that each backend service contains one backend. Point each backend to a different instance group.

**B.** Create one global external Application Load Balancer and one backend service with multiple backends. Point each backend to a different instance group.

**C.** Create two global external Application Load Balancers with one backend service and one backend. Point each back end to a different instance group.

**D.** Create two global external Application Load Balancers with multiple backend services. Ensure that each backend service contains one backend. Point each backend to a different instance group.

**Respuesta de la fuente:** B

**Explicación:** To distribute traffic across multiple regions while connecting users to the closest backend, you use a single global external Application Load Balancer.
According to Google Cloud architecture best practices, one backend service is configured with multiple backends, where each backend points to an instance group in a different region.
This setup allows the load balancer's internal routing logic (based on proximity and health checks) to direct traffic appropriately without needing separate ALB resources or multiple backend services.

## Pregunta 244

Contexto: [topics:725](#topics-725)
Your company uses Network Connectivity Center to connect its VPCs in Google Cloud. They plan to connect their on-premises data center to one of these VPCs by using HA VPN. The CIDR range of your on-premises network overlaps with the IP addresses in Google Cloud. You want your VMs in Google Cloud to connect directly to the IP address of the on-premises hosts. What should you do?

**A.** Configure a subnet of purpose REGIONAL_MANAGED_PROXY and use a Google Cloud application load balancer.

**C.** Configure a subnet of purpose REGIONAL_MANAGED_PROXY and use a Google Cloud TCP proxy load balancer.

**D.** Configure a subnet of purpose PRIVATE_NAT and use Private NAT for the Network Connectivity Center spokes.

**E.** Configure a subnet of purpose PRIVATE_NAT and use Hybrid NAT.

**Respuesta de la fuente:** E

**Explicación:** Hybrid NAT is the specific feature designed to resolve IP address conflicts between Google Cloud VPCs and on-premises networks connected via Network Connectivity Center (NCC) spokes, such as HA VPN.
It allows direct connectivity to original on-premises IP addresses by performing translation only for conflicting ranges, which aligns with the requirement to connect directly despite overlapping CIDRs.
Option D is incorrect because Private NAT for NCC spokes is a broader category or mislabeled concept; Hybrid NAT is the precise solution for cross-cloud/on-prem overlap scenarios.

## Pregunta 245

Contexto: [topics:725](#topics-725)
Your organization wants to deploy HA VPN over Cloud Interconnect to ensure encryption-in-transit over the Cloud Interconnect connections. You have created a Cloud Router and two VLAN attachments. The BGP sessions are operational. You need to complete the deployment of the HA VPN over Cloud Interconnect. What should you do?

**A.** Create an HA VPN gateway and associate the gateway with your two VLAN attachments. Use the existing Cloud Router for HA VPN, the peer VPN gateway resources, and the HA VPN tunnels.

**B.** Create an HA VPN gateway and associate the gateway with your two VLAN attachments. Create a new Cloud Router for HA VPN, the peer VPN gateway resources, and the HA VPN tunnels.

**C.** Enable MACsec on the VLAN attachments.

**D.** Enable MACsec on Partner Cloud Interconnect.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because deploying HA VPN over Cloud Interconnect requires two distinct operational tiers: a Cloud Interconnect tier and an HA VPN tier. Each tier must have its own dedicated Cloud Router to manage the specific BGP sessions for that tier, so you cannot reuse the existing Cloud Router created for the Cloud Interconnect VLAN attachments.
Option A is incorrect because it suggests using the existing Cloud Router for HA VPN, which violates the architectural requirement for separate routers per tier.

## Pregunta 246

Contexto: [topics:725](#topics-725)
Your organization wants to deploy an internal application named app-1 in VPC-1. The application will consume services from another internal application named app-2 in VPC-2. VPC Network Peering will connect both applications. You need to apply microsegmentation between these two applications and VPCs. What should you do?

**A.** Assign network tags to these applications: secure-tag-app-1 to app-1 and secure-tag-app-2 to app-2. Configure a hierarchical firewall policy with an ingress rule that allows traffic from secure-tag-app-1 to secure-tag-app-2. Leave the default deny ingress rule and the default allow egress rule.

**B.** Assign secure tags to these applications: secure-tag-app-1 to app-1 and secure-tag-app-2 to app-2. Configure a hierarchical firewall policy with an ingress rule that allows traffic from secure-tag-app-1 to secure-tag-app-2. Leave the default deny ingress rule and the default allow egress rule.

**C.** Assign network tags to these applications: secure-tag-app-1 to app-1 and secure-tag-app-2 to app-2. Configure an ingress VPC firewall rule that allows traffic from secure-tag-app-1 to secure-tag-app-2. Leave the default deny ingress rule and the default allow egress rule.

**D.** Assign secure tags to these applications: secure-tag-app-1 to app-1 and secure-tag-app-2 to app-2. Configure a network firewall policy that is attached to VPC-2 with an ingress rule that allows traffic from secure-tag-app-1 to secure-tag-app-2. Leave the default deny ingress rule and the default allow egress rule.

**Respuesta de la fuente:** D

**Explicación:** Secure Tags are required because they are IAM-governed and propagate across VPC peering connections, unlike Network Tags which do not.
Option D is correct because it uses Secure Tags with a Network Firewall Policy attached to the destination VPC (VPC-2) to filter ingress traffic, leveraging the default allow egress rule in VPC-1.
Option B is incorrect because while Hierarchical Policies can use Secure Tags, the specific scenario of applying policy at the individual VPC level via a Network Firewall Policy is the precise architectural fit described.

## Pregunta 247

Contexto: [topics:725](#topics-725)
You are troubleshooting connectivity issues between Google Cloud and a public SaaS provider. The connectivity between the two environments is through the public internet. Your users are reporting intermittent connection errors when using TCP to connect; however, ICMP tests show no failures. According to users, errors occur around the same time every day. You want to troubleshoot and gather information by using Google Cloud tools that are most likely to provide insights to what is occurring within Google Cloud. What should you do?

**A.** Create a Connectivity Test. Review the results for configuration issues in the VPC routing table.

**B.** Enable and review Cloud Logging for Cloud Armor. Look for logs with errors that match the destination IP address of the public SaaS provider.

**C.** Enable and review Cloud Logging on your Cloud NAT Gateway. Look for logs with errors that match the destination IP address of the public SaaS provider.

**D.** Enable the Firewall Insights API. Set the Deny rule insights observation period to one day. Review Insight results to assure there are no firewall rules denying traffic.

**Respuesta de la fuente:** C

**Explicación:** The discrepancy between successful ICMP tests and failing TCP connections, especially with a daily pattern, strongly suggests NAT port exhaustion rather than routing or firewall issues. Enabling Cloud Logging on the Cloud NAT Gateway provides specific metrics on translation entries and dropped packets due to limited ephemeral ports, directly addressing the symptom of TCP failure while other protocols work.
Option A is incorrect because successful ICMP tests generally confirm that basic routing paths are functional, making VPC routing table misconfiguration unlikely.

## Pregunta 248

Contexto: [topics:725](#topics-725)
You are designing a Google Kubernetes Engine cluster for your organization. The current cluster size is expected to host 10 nodes, with 20 Pods per node and 150 Services. Because of the migration of new Services over the next two years, there is a planned growth for 100 nodes, 200 Pods per node, and 1500 Services. You want to use VPC-native clusters with alias IP address ranges, while minimizing address consumption. How should you design this topology?

**A.** Create a subnet of size /28 with 2 secondary ranges of: /24 for Pods and /24 for Services. Create a VPC-native cluster and specify those ranges. When the Services are ready to be deployed, resize the subnets.

**B.** Use gcloud container clusters create [CLUSTER_NAME]--enable-ip-alias to create a VPC-native Cluster.

**C.** Create a subnet of size /25 with 2 secondary ranges of: /17 for Pods and /21 for Services. Create a VPC-native cluster and specify those ranges.

**D.** Use gcloud container clusters create [CLUSTER_NAME] to create a VPC-native Cluster.

**Respuesta de la fuente:** C

**Explicación:** Answer C is correct because it provisions subnet ranges large enough to accommodate the planned growth of 100 nodes (/25 provides 128 IPs), 20,000 pods (requiring a /17 since GKE assigns /24 per node by default), and 1,500 services (/21 provides 2,048 IPs). Option A is incorrect because its ranges (/24 for pods and services) are too small to support the future scale of 100 nodes or 1,500 services, and GKE secondary IP ranges cannot be resized after cluster creation.

## Pregunta 249

Contexto: [topics:725](#topics-725)
You are establishing a secure and resilient connection between your company’s on-premises data center and a Google Cloud VPC. You have two separate physical VPN gateways in your on-premises data center for redundancy. You need to ensure that there is no single point of failure in the design, and you must use dynamic routing to exchange prefixes. What should you do?

**A.** Deploy an HA VPN gateway and establish connection to one of the interfaces on-premises with multiple tunnels.

**B.** Deploy a single Classic VPN gateway in Google Cloud and create two tunnels, both pointing to the same primary on-premises VPN gateway to increase bandwidth.

**C.** Deploy an HA VPN gateway and connect its two interfaces to the two on-premises gateways. Use Cloud Router to establish a BGP session over each tunnel.

**D.** Deploy two Classic VPN gateways, each connected to a separate on-premises gateway. Configure matching static routes with different priorities on both sides to handle failover.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 250

Contexto: [topics:725](#topics-725)
You are designing a Google Kubernetes Engine (GKE) cluster for a highly sensitive application that processes confidential financial data in a single shared VPC. Your developers need to be able to securely access the Kubernetes API endpoint from their corporate network, which is connected to Google Cloud through Cloud VPN. You need to design the highest level of network security and ensure that the GKE control plane is not exposed to the internet. What should you do?

**A.** Create a GKE cluster with a public endpoint. Implement VPC Service Controls to prevent any unauthorized access to the Kubernetes API from the internet.

**B.** Deploy a private GKE cluster with the public endpoint disabled. Enable Private Service Connect to the control plane, allowing access only from within the VPC network or on-premises networks through Cloud VPN.

**C.** Deploy a private GKE cluster with a public endpoint disabled. Use an internal TCP/UDP load balancer with identity proxy as a backend to connect to the Kubernetes API within the VPC network.

**D.** Create a public GKE cluster, and configure authorized networks on the control plane to restrict access to the corporate network's external IP address.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 251

Contexto: [topics:725](#topics-725)
Your organization requires its cloud network environment to inspect and deny traffic through a third party virtual firewall appliance. You currently operate a single standalone appliance, which is the next-hop target of a custom static route. You have recently deployed a new redundant appliance for high availability and load-sharing. You need to route the cloud network traffic through these appliances in an active/active configuration, while avoiding asymmetric routing. You also need to deploy this configuration with minimal traffic disruption and follow Google-recommended practices. What should you do?

**A.** Configure an internal passthrough network load balancer to send traffic to the redundant appliance. Then configure a packet mirroring policy that mirrors all traffic from the pre-existing standalone appliance to the new redundant appliance.

**B.** Configure an internal passthrough network load balancer to balance traffic to both appliances. Create a route with this internal load balancer as a next hop at a higher priority than the existing route. Then remove the pre-existing route that directed traffic to the standalone appliance.

**C.** Create a route for the redundant appliance at the same priority as the pre-existing standalone appliance.

**D.** Create routes for both appliances at the same priority, but higher than the existing standalone appliance's route. Then remove the pre-existing route that directed traffic to the standalone appliance.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 252

Contexto: [topics:725](#topics-725)
Your organization uses Google Cloud’s Network Connectivity Center. One of the VPC spokes contains subnet-corp-prod (10.10.1.0/24) and subnet-corp-test (192.168.1.0/24). You need to ensure that only the subnet-corp-prod range is advertised to the Network Connectivity Center hub, even if new subnets are created in the VPC. You want to use the most direct and precise method to control route advertisements from this spoke. What should you do?

**A.** Create a custom static route in the Network Connectivity Center hub with the next hop as the VPC spoke for the 10.10.1.0/24 range.

**B.** Add 192.168.1.0/24 to the exclude export ranges filter in the VPC spoke configuration.

**C.** Set the include export ranges filter to 10.10.1.0/24 in the VPC Spoke configuration, and ensure no other ranges are included.

**D.** Create a VPC firewall rule with a DENY action for the 192.168.1.0/24 range.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 253

Contexto: [topics:725](#topics-725)
Your organization relies on a critical Dedicated Interconnect connection for its hybrid cloud strategy. You need to proactively monitor this connection's health and network connectivity to ensure its reliability. You want to be alerted if the light level for an optical transceiver drops below the recommended operational power, or if traffic through the connection suddenly stops. What should you do?

**A.** Create an alerting policy in Cloud Monitoring that triggers if the total byte count sent over the VLAN attachment drops to zero.

**B.** Configure a periodic connectivity test in the Network Intelligence Center to ping an on-premises host and alert based on its success rate.

**C.** Create alerting policies in Cloud Monitoring based on the metrics for both the optical power level of the physical link and the BGP session state of the VLAN attachment.

**D.** Build a log-based alert in Cloud Logging that parses Cloud Router logs to detect when BGP keepalive messages are no longer received.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 254

Contexto: [topics:725](#topics-725)
Your organization is migrating workloads from AWS to Google Cloud. Because a particularly critical workload will take longer to migrate, you need to set up Google Cloud CDN and point it to the existing application at AWS. What should you do?

**A.** • Create an internet NEG that points to the existing FQDN of the application.
• Map the NEG to an Application Load Balancer as a backend service.
• Enable Cloud CDN on the backend service.

**B.** • Create a hybrid NEG that points to the existing IP of the application.
• Map the NEG to a passthrough Network Load Balancer as a target pool.
• Enable Cloud CDN on the target pool.

**C.** • Create an internet NEG that points to the existing FQDN of the application.
• Map the NEG to a passthrough Network Load Balancer as a backend service.
• Enable Cloud CDN on the backend service.

**D.** • Create a hybrid NEG that points to the existing IP of the application.
• Map the NEG to an Application Load Balancer as a backend service.
• Enable Cloud CDN on the backend service.

**Respuesta de la fuente:** A

**Explicación:** To offload traffic to an external origin like AWS, you must create an Internet Network Endpoint Group (NEG) that points to the application's FQDN or public IP, as hybrid NEGs are for on-premises VMs and not applicable here.
Cloud CDN is strictly supported only when attached to a backend service behind an Application Load Balancer (ALB), making Option A the correct configuration while options involving Network Load Balancers are invalid.

## Pregunta 255

Contexto: [topics:725](#topics-725)
Your organization has deployed Google Kubernetes Engine (GKE) clusters in several different Virtual Private Clouds (VPCs) for the past year, one GKE cluster per VPC. While the GKE nodes leverage unique IP space between each cluster, the Pod IP ranges have been reused across VPCs. The VPCs are spokes of a Network Connectivity Center hub configured in mesh topology. The Pod IP ranges have been excluded from the Network Connectivity Center VPC spokes. While this process seems to work and Compute Engine instances in the VPCs can reach services, you notice that the Pods are unable to access services in other VPCs. You need to enable communication between Pods in different VPCs. What should you do?

**A.** Ensure that the IP masquerade agent is installed correctly and performing source NAT for Pod traffic destined to services outside of the cluster.

**B.** Delete the GKE clusters, create a new pair of VMs in the subnets used by the GKE clusters, and test the connectivity. Recreate the GKE clusters.

**C.** Delete the Network Connectivity Center hub and VPC spokes. Connect all VPCs by using Cloud VPNs.

**D.** Delete the Network Connectivity Center hub and VPC spokes. Peer all VPCs by using VPC Network Peering.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 256

Contexto: [topics:725](#topics-725)
Your company utilizes Network Connectivity Center (NCC) to facilitate communication between numerous spoke VPCs. A development team reports that their application instances in app-dev-spoke-vpc are unable to connect to a new database service located in db-dev-spoke-vpc. You need to diagnose this issue using an observability tool and determine the root cause. What should you do?

**A.** Use Firewall Insights to analyze the firewall rule configuration and modify the appropriate rule.

**B.** Check each firewall rule in both the app-dev-spoke-vpc and db-dev-spokevpc.

**C.** Verify that the application instances in app-dev-spoke-vpc connected to Network Connectivity Center are assigned external IP addresses to reach the database service.

**D.** Use Network Intelligence Center’s Connectivity Tests to perform a reachability analysis between an instance in app-dev-spoke-vpc and the database service in db-dev-spoke-vpc.

**Respuesta de la fuente:** D

**Explicación:** Network Intelligence Center (NIC) is the GCP observability tool designed to diagnose connectivity issues by performing reachability analysis. Option D correctly identifies using NIC's Connectivity Tests to pinpoint the root cause between specific resources, aligning with the prompt's requirement to use an observability tool.

Option A is incorrect because Firewall Insights is for analyzing rule utilization, not directly testing end-to-end reachability or identifying non-firewall connectivity failures.

## Pregunta 257

Contexto: [topics:725](#topics-725)
You are designing the network architecture for a hybrid environment where applications in Google Cloud and on-premises services must resolve DNS records for each other. You need a scalable and managed solution for seamless, bidirectional DNS resolution between your Google Cloud Virtual Private Cloud (VPC) and your on-premises network. You want to avoid manual DNS record synchronization and follow Google-recommended practices. What should you do?

**A.** •	Implement Cloud DNS private zones for your Google Cloud resources.
•	Configure an inbound server policy in your VPC for on-premises resolution.
•	Create a Cloud DNS forwarding zone to resolve on-premises domain names.

**B.** •	Establish Cloud DNS private zones within your Google Cloud project for all Google Cloud resources.
•	Configure all on-premises DNS servers to conditionally forward queries for Google Cloud domains to these private.
•	zones through an inbound server policy on your VPC.

**C.** •	Deploy a pair of custom DNS virtual machines in two Google Cloud regions of your VPC.
•	Configure the pair to replicate DNS records with on-premises DNS servers.
•	Update DHCP options for all cloud and on-premises instances.

**D.** •	Configure a Cloud DNS public zone, and import all on-premises DNS records into it.
•	Update all on-premises clients to use this Cloud DNS public zone as their primary DNS server.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 258

Contexto: [topics:725](#topics-725)
Your company acquired a new division. The new division's network team requires complete control over their networking infrastructure. You need to extend your existing Google Cloud network infrastructure, that consists of a single VPC, to allow workloads from all divisions to communicate with each other. You want to avoid incurring extra costs and granting unnecessary permissions to the new division's networking team. What should you do?

**A.** • Create a new project for the new division's network team.
• Create a new VPC within the new project.
• Establish a VPC peering between your existing VPC and the new division’s VPC.
• Create a new subnet dedicated to the new division's workloads.
• Grant roles/compute.networkUser on the new project to the new division’s network team group.

**B.** • Create a new project for the new division's network team.
• Create a new VPC within the new project.
• Establish a VPC peering between your existing VPC and the new division’s VPC.
• Grant roles/compute.networkAdmin on the newly created project to the new division's network team group.

**C.** • Ensure that the project hosting the existing network infrastructure is enabled as a host project.
• Create a new subnet dedicated to the new division's workloads in the existing VPC.
• Grant roles/compute.networkUser on the newly created subnet to the new division’s network team group.

**D.** • Create a new project for the new division's network team.
• Create a new VPC within the new project.
• Establish a VPN connection between your existing VPC and the new division's VPC.
• Grant roles/compute.networkAdmin on the newly created project to the new division's network team group.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it isolates the new division's network resources in a separate project and VPC, allowing you to grant them `compute.networkAdmin` for full control without exposing your existing infrastructure. This satisfies the requirement for complete autonomy while avoiding unnecessary permissions on the primary environment.

Option A is incorrect because granting only `compute.networkUser` prevents the team from managing firewalls or routes, violating the 'complete control' requirement.

## Pregunta 259

Contexto: [topics:725](#topics-725)
Your organization has a critical project that requires a highly secure connectivity tunnel attached to the on-premises network. A Google Cloud network availability of 99.99% must be maintained. The on-premises network has one device and two interfaces, each with their own external IP addresses. You need to configure the appropriate Cloud HA VPN to address the project requirements. What should you do?

**A.** Configure an HA VPN gateway with two VPN tunnel interfaces that connect to the on-premises device interface 0 and interface 1. Peer each tunnel to each external IP address. Set the REDUNDANCY_TYPE to TWO_IPS_REDUNDANCY.

**B.** Configure an HA VPN gateway with one VPN tunnel and two IP addresses that connect to the on-premises device interface 0. Use Cloud Router BGP MED and AS_PATH attributes to define redundancy with the on-premises device.

**C.** Configure an HA VPN gateways with two VPN tunnel interfaces that connect to the on-premises device interface 0 and interface 1. Peer each tunnel to each external IP address. Set the REDUNDANCY_TYPE to SINGLE_IP_INTERNALLY_REDUNDANT.

**D.** Configure an HA VPN gateway with one VPN tunnel and two interfaces that connect to the on-premises device interface 0 and interface 1. Peer each tunnel to each external IP address. Set the REDUNDANCY_TYPE to TWO_IPS_REDUNDANCY.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 260

Contexto: [topics:725](#topics-725)
You manage the static assets for your company’s global website. Users have been reporting slow load times when they visit the website. You need to develop a scalable solution to improve website load times for users worldwide. You also need to reduce direct access load on the Cloud Storage bucket where the website s static assets are stored. What should you do?

**A.** Configure an internal Application HTTPS Load Balancer in front of the Cloud Storage bucket and enable Cloud CDN on the storage bucket.

**B.** Deploy a Global external Application HTTPS Load Balancer, configure a backend bucket pointing to your Cloud Storage bucket, and enable Cloud CDN on the backend bucket.

**C.** Deploy a Global external Application HTTPS Load Balancer with a Private Service Connect backend pointing to the Cloud Storage API.

**D.** Create a new Compute Engine instance, host the static assets on it, frontend the VM with a load balancer and then enable Cloud CDN directly on the backend service of the load balancer.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 261

Contexto: [topics:725](#topics-725)
You are establishing a high-throughput, highly reliable, and private network link for a multinational corporation between its on-premises data center in Frankfurt. It is located within a Google-supported co-location facility, and its Google Cloud VPC in the europe-west3 region. You need a connection that supports large-scale data synchronization and real-time application traffic with a bandwidth of 10 Gbps or more. What should you do?

**A.** Configure a pair of HA VPN tunnels between the on-premises data center and the Google Cloud VPC.

**B.** Order a pair of Dedicated Interconnect circuits at the colocation facility to a Google edge location, then configure a VLAN attachment within your Google Cloud VPC.

**C.** Implement a Direct Peering connection from your co-location facility to Google's global network edge.

**D.** Engage with a Google Cloud Partner to establish a Partner Interconnect connection for your private network.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 262

Contexto: [topics:725](#topics-725)
Your company is implementing new rules for outbound internet traffic in your Google Cloud environment. You need to design a configuration that enables all outbound internet traffic from virtual machines tagged with production-critical to route through a Secure Web Proxy (SWP) for inspection while allowing all other virtual machines to egress directly to the internet. What should you do?

**A.** Deploy a Cloud NAT gateway configured to translate and forward traffic from production-critical VMs to the internet.

**B.** Configure a custom static route with a destination of 0.0.0.0/0 for the production-critical network tag with the SWP IP address as a next hop.

**C.** Configure a policy-based route with a destination of 0.0.0.0/0 for the production-critical network tag with the SWP IP as a next hop.

**D.** Configure a policy-based route with a source set as the subnets of the production-critical VMs and a destination of 0.0.0.0/0 with the SWP IP as the next hop.

**Respuesta de la fuente:** B

**Explicación:** In Google Cloud, custom static routes can be scoped to specific network tags. By defining a route with destination 0.0.0.0/0 for the 'production-critical' tag pointing to the Secure Web Proxy IP, traffic from those tagged VMs is redirected through the proxy while untagged VMs continue using the default internet gateway.

Option C is incorrect because Google Cloud does not support policy-based routing (PBR) via simple route configurations; PBR requires Cloud Router and BGP, which is unnecessary overhead for this static tagging scenario.

## Pregunta 263

Contexto: [topics:725](#topics-725)
You are securing a newly provisioned 10 Gbps Dedicated Interconnect that connects your on-premises data center to your Google Cloud VPC. Your company mandated that all IP traffic between your private on-premises network and the VPC must be secured with strong, end-to-end encryption at layer 3 in the Open Systems Interconnection (OSI) model. You need to implement the most direct and effective solution. What should you do?

**A.** Configure BGP sessions over the Dedicated Interconnect, and enable MD5 authentication.

**B.** Enable MACsec for Cloud Interconnect to encrypt all data frames between your on-premises router and Google's edge device.

**C.** Deploy HA VPN tunnels over the Dedicated Interconnect connections, and configure BGP sessions with on-premises routers to exchange routes.

**D.** Migrate your connection from Dedicated Interconnect to Partner Interconnect, and select a service provider that offers a private, encrypted connection.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 264

Contexto: [topics:725](#topics-725)
You manage a highly dynamic e-commerce website that uses Cloud CDN to improve content delivery speed for its global customer base. A new product launched on the website with updated images and pricing information, and these changes were pushed to your Cloud Storage and Compute Engine instances behind a load balancer. However, customers are still seeing the old product images and pricing on the website. You need to immediately and efficiently push the new content to users. What should you do?

**A.** Temporarily disable and then re-enable Cloud CDN on the backend services to force a cache reload.

**B.** Invalidate the specific URLs or URL prefixes corresponding to the updated product images and pricing information in Cloud CDN.

**C.** Configure a new backend service with the existing backends with Cloud CDN enabled to get the updated content.

**D.** Purge all cached content from Cloud CDN by performing a full cache flush for the entire CDN service.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 265

Contexto: [topics:725](#topics-725)
You manage your company's network security and have noticed unusual outbound traffic from a Compute Engine VM that is part of a production subnet. You suspect the VM may be compromised, because it is attempting to communicate with a malicious external IP address. You want to capture detailed metadata for every IP connection to and from this specific VM. including source/destination IP, port, protocol, and the amount of data transferred. What should you do?

**A.** •	Enable VPC Flow Logs on the subnet containing the VM.
•	Set the sampling rate to 1.0 for maximum detail, and filter the logs in Cloud Logging for the VM's IP address.

**B.** •	Navigate to Network Intelligence Center, and run a new connectivity test for the VM.
•	Analyze the report to see which configurations are allowing the traffic.

**C.** •	Use Packet Mirroring to create a real-time copy of all network packets from the suspected VM.
•	Forward the copies to a collector VM for analysis.

**D.** •	Create a new egress firewall rule with a priority of 65535 that allows all outbound traffic.
•	Enable Firewall Rules Logging on this new rule to capture all connection details.

**Respuesta de la fuente:** A

**Explicación:** VPC Flow Logs are designed to capture network connection metadata (source/destination IP, port, protocol, bytes transferred) without the high overhead and complexity of full packet inspection. Enabling them on the subnet with a sampling rate of 1.0 ensures every packet's metadata is recorded for the specific VM, directly satisfying the requirement for detailed connection logs.

Packet Mirroring (Option C) captures the entire packet payload, which is unnecessary for metadata analysis and significantly more complex to deploy, making it an overkill 'sledgehammer' approach.

## Pregunta 266

Contexto: [topics:725](#topics-725)
Your company runs shop.example.com. a global e-commerce application deployed in three Google Cloud regions: us-central1, europe-west1, and asia-east1. Each regional deployment is served by a regional external Application Load Balancer. You need to configure Cloud DNS to route users to the regional load balancer closest to their geographic location to minimize latency. What should you do?

**A.** Create a record set for shop.example.com using a Cloud DNS geolocation route policy that maps traffic originating from source geographies to the corresponding regional load balancer.

**B.** Configure a failover routing policy where the primary backend is dynamically set to the region with the lowest latency, with the other regions serving as hot standbys.

**C.** Use a weighted round-robin (WRR) policy to specify different weights per regional load balancer, assigning higher weights to the regional load balancers.

**D.** Create a single “A" record for shop.example.com with all three regional load balancer IP addresses.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 267

Contexto: [topics:725](#topics-725)
Your organization has two applications running in separate Google Cloud VPC networks (vpc-a and vpc-b) in different projects. You need to establish a secure, private, and encrypted connection between these two VPCs to allow for inter-VPC communication. You must ensure the solution provides high availability and uses dynamic routing. What should you do?

**A.** Configure VPC Network Peering between the two networks, and adjust firewall rules on both sides to allow the required traffic flow between specific subnets.

**B.** In vpc-a, deploy an internal Application Load Balancer for your application. Use Private Service Connect to publish this service in vpc-a and create a PSC consumer endpoint in vpc-b.

**C.** In each VPdeploy a Classic VPN gateway and use a pre-shared key for authentication. Configure static routes to direct traffic to the other VPC.

**D.** In each VPC. deploy an HA VPN gateway and a Cloud Router. Create two VPN tunnels on each gateway, and configure BGP sessions for dynamic routing.

**Respuesta de la fuente:** D

**Explicación:** The prompt explicitly requires dynamic routing and high availability. Option D is the only choice that deploys HA VPN gateways with Cloud Routers to establish BGP sessions, which provides both dynamic route exchange and redundant tunnels for high availability.

Option A (VPC Peering) uses static routes and does not support dynamic routing protocols like BGP, failing a key requirement of the question.

## Pregunta 268

Contexto: [topics:725](#topics-725)
You manage a Google Cloud VPC network that has multiple Cloud VPN tunnels connecting to a single branch office for redundancy. One tunnel is a new. high-performance link, while the other is an older, less reliable link. You need to configure dynamic routing to influence how your on-premises network routes traffic, ensuring it prefers sending traffic to Google Cloud over the new, high performance tunnel. The older tunnel must remain available as a backup. What should you do?

**A.** Adjust the Border Gateway Protocol (BGP) Multi-Exit Discriminator (MED) attribute advertised by the Cloud Router for the preferred VPN tunnel to a lower value.

**B.** Configure static routes with different priorities on your on-premises router to point to the two different Cloud VPN tunnel interfaces in Google Cloud.

**C.** On the Cloud Router, configure custom route advertisements to send a shorter prefix route over the new, high-performance tunnel.

**D.** For the BGP session associated with the new tunnel, configure a higher advertised route priority (a lower numerical value) on the Cloud Router.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 269

Contexto: [topics:725](#topics-725)
You are deploying an application on a fleet of Compute Engine virtual machines (VMs) that must process sensitive, financial data by communicating with the Cloud Storage API. The VMs currently have internal IP addresses. You need to enable this communication using the most secure method available. What should you do? (Choose two.)

**A.** Keep the VMs configured with only internal IP addresses. On the subnet, enable Private Google Access and configure the necessary private DNS records for private.googleapis.com.

**B.** Create a Cloud DNS private zone for googleapis.com that resolves to the restricted.googleapis.com IP addresses, and associate the private zone with the VMs' VPC network.

**C.** Modify the VMs to each have an external IP address. Create a restrictive egress firewall rule that only allows outbound traffic to the public IP ranges for Google APIs.

**D.** Create a Cloud NAT gateway, and configure it for the subnet housing the VMs. Remove the 0.0.0.0/0 route to the default internet gateway.

**E.** Create a regional Private Service Connect endpoint in your VPC that targets the Cloud Storage service. Configure the application on the VMs to send API requests to this endpoint.

**Respuesta de la fuente:** A, B

**Explicación:** No conservada en esta captura.

## Pregunta 270

Contexto: [topics:725](#topics-725)
Your company hosts a critical banking application in Google Cloud VPC. This application frequently interacts with a Cloud SQL for MySQL instance that stores sensitive customer data. Due to strict compliance and security requirements, all communication between your application’s VPC and the Cloud SQL instance must remain private without traversing the public internet. You need to conserve IP space as much as possible and establish a communication connection with minimal network overhead and complexity. What should you do?

**A.** Establish a Private Service Connect endpoint between your application's VPC and the Google-managed service producer network.

**B.** Deploy a private Compute Engine instance with a custom proxy server in your application's VPC, and route all Cloud SQL traffic through this proxy.

**C.** Establish a Private Service Access connection between your application’s VPC and the Google-managed service producer network.

**D.** Use Cloud SQL connector to connect to the Cloud SQL instance.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 271

Contexto: [topics:725](#topics-725)
You manage a Google Kubernetes Engine (GKE) cluster that needs to communicate with a legacy monitoring service running in your on-premises data center. The on-premises network uses the 192.168.10.0/24 address range and is connected to your VPC through Cloud VPN. The legacy monitoring service can only accept traffic from the GKE clusters’ node IP addresses, not from Pod IP addresses. You notice that traffic from Pods is failing. You need to ensure that traffic from Pods can seamlessly flow to the on-premises network. What should you do?

**A.** Configure a hybrid Cloud NAT gateway on the Cloud Router associated with the Cloud VPN tunnel.

**B.** Ensure that the ip-masq-agent is deployed and that 192.168.10.0/24 is not present in the nonMasqueradeCIDRs list in the GKE cluster.

**C.** Add 192.168.10.0/24 to the nonMasqueradeCIDRs list in the ip-masq-agent's ConfigMap in the GKE Cluster.

**D.** Configure a Public Cloud NAT gateway for the GKE cluster's subnet.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 272

Contexto: [topics:725](#topics-725)
You correctly configured Cloud DNS forwarding zones to point towards your on-premises DNS. You noticed that you cannot query your on-premises Active Directory main Domain Controller by using “dig ad.company.int” over your interconnect attachment. However, the query is successful if you directly target your on-premises DNS server by using “dig @10.10.10.53 ad.company.int”. You need to correctly configure Cloud DNS so VMs and other resources can correctly resolve DNS records in your on-premises DNS system. What should you do?

**A.** Make sure that the Cloud DNS source range is advertised over your BGP sessions towards the on-premises environment, and that the on-premises ingress firewalls allow traffic from this range on port 53.

**B.** Change the local DNS server in your Google Cloud VMs from 169.254.169.254 to your on-premises service, 10.10.10.53.

**C.** Use a nslookup query instead of a dig query.

**D.** Add an egress firewall rule in your VPC to allow DNS traffic on port 53 that is destined to your on-premises DNS server.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 273

Contexto: [topics:725](#topics-725)
You are managing a hybrid cloud environment connecting your on-premises data center to a Google Cloud VPC via Cloud VPN. Your on-premises DNS servers are authoritative for the corp.example.com zone, and a Cloud DNS private zone is authoritative for the gcp.example.com zone. You need to configure a Google-recommended solution that allows Google Cloud VMs to resolve on-premises hostnames and. conversely, allows on-premises hosts to resolve hostnames in your Google Cloud VPC. What should you do?

**A.** •	Create a Cloud DNS outbound server policy that forwards all DNS queries from the VPC to your on-premises DNS servers.
•	Configure your on-premises servers to handle resolution for gcp.example.com and public domains on behalf of the VPC.

**B.** •	Configure your on-premises DNS servers to use Google Cloud's public DNS (8.8.8.8) for all queries.
•	Update your Google Cloud instances to use Cloud DNS for internal resolution.

**C.** •	Deploy a Compute Engine VM in the VPC to run a DNS forwarder, such as BIND or Unbound.
•	Configure this VM to handle bi-directional forwarding between the on-premises DNS servers and Cloud DNS.

**D.** •	Create a Cloud DNS forwarding zone for corp.example.com that points to your on-premises DNS servers.
•	Configure a private Cloud DNS zone for gcp.example.com. Create a Cloud DNS inbound server policy, and configure on-premises DNS servers to forward queries for gcp.example.com to it.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 274

Contexto: [topics:725](#topics-725)
Your company's public domain, example.com. is managed using a public Cloud DNS zone. You need to enhance security and protect your users from DNS spoofing and cache poisoning attacks. What should you do?

**A.** Request DNSSEC be enabled at your domain registrar, and then import the provided key-signing keys (KSKs) into the Cloud DNS zone.

**B.** Attach a Google Cloud Armor security policy to the DNS zone to filter malicious queries and protect against DNS protocol-level attacks.

**C.** Use Cloud NGFW network policies to allow only specific DNS domains into the VPC.

**D.** Enable DNSSEC on the public Cloud DNS zone, and add the provided DS records to your domain registrar.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 275

Contexto: [topics:725](#topics-725)
Your company distributes software updates using a Cloud Storage bucket fronted by a global external HTTPS Application Load Balancer with Cloud CDN enabled. You uploaded a critical security patch to a file named latest_update.zip. The security patch eliminates a vulnerability that could be exploited by cybercriminals. You need to ensure that all users worldwide immediately receive the new version, and that any previously cached copies of latest_update.zip are purged from the Cloud CDN network. What should you do?

**A.** Disable and then re-enable Cloud CDN for the entire backend bucket to flush the cache.

**B.** Modify the metadata of the latest_update.zip object in Cloud Storage to set the Cache-Control header to no-cache.

**C.** Run the gcloud compute url-maps invalidate-cdn-cache command, specifying the load balancer’s URL map and the exact path to the latest_update.zip file.

**D.** Change the Cloud CDN cache mode for the backend bucket from CACHE_ALL_STATIC to USE_ORIGIN_HEADERS and then back to CACHE_ALL_STATIC.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 276

Contexto: [topics:725](#topics-725)
You are designing the networking for a Google Kubernetes Engine (GKE) cluster that will host an internal, employee-facing application. This application needs to be accessible from your on-premises corporate network and from specific internal VPC networks in Google Cloud. You need to design a highly available and scalable load balancing solution for ingress traffic with a cookie-based session affinity without exposing the application to the public internet. What should you do?

**A.** Use a GKE Gateway controller with an internal HTTPS load balancer. Configure DNS records to point to the load balancer's internal IP address from your on-premises network and peered internal VPCs.

**B.** Implement a GKE Service of type LoadBalancer to provision an internal TCP/UDP load balancer. Configure its forwarding rule to accept traffic from your internal VPC and on-premises IP ranges.

**C.** Expose the application using a Service of type NodePort. and configure an on-premises load balancer to target all the GKE node IPs as its backend.

**D.** Implement a GKE Service of type LoadBalancer to provision a regional TCP proxy load balancer. Apply firewall rules to restrict traffic to your internal source IP ranges.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 277

Contexto: [topics:725](#topics-725)
You are establishing a hybrid connectivity solution between your on-premises data center and a Google Cloud VPC network using Cloud Interconnect. The connection must automatically adapt to network topology changes and provide high availability. You need to ensure that routes from your on-premises network are dynamically advertised to your Google Cloud VPC. You also need to ensure that routes from your Google Cloud VPC are dynamically advertised back to your on-premises routers. What should you do?

**A.** Implement a policy-based route in your Google Cloud VPC network to forward all on-premises destined traffic to a Network Virtual Appliance (NVA).

**B.** Use HA VPN on top of Interconnect to establish a BGP session to your on-premise router. Configure the Cloud Router to advertise all visible subnets.

**C.** Deploy a Cloud Router in your Google Cloud VPC network configured to advertise all subnets visible to the Cloud Router. Establish a BGP session over your Cloud Interconnect VLAN attachment to your on-premises router.

**D.** Use a Cloud Function triggered by network monitoring logs to automatically script and update static routes in the VPC route table for any detected on-premises subnets.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 278

Contexto: [topics:725](#topics-725)
Your global website is hosted on Google Cloud. The website's static assets, such as images and CSS files, are stored in a Cloud Storage bucket, while the dynamic content is served by a managed instance group (MIG). You want to improve website performance, reduce latency, and create an efficient, budget-friendly solution that uses Cloud CDN to cache static assets as close to your users as possible. You also want to ensure that requests for dynamic content are sent directly to the MIG. What should you do?

**A.** Create two separate global external HTTPS Application Load Balancers. One for the Cloud Storage bucket with Cloud CDN enabled, and another for the MIG without Cloud CDN.

**B.** Create a Media CDN service, and configure it to pull content from both the Cloud Storage bucket and the MIG.

**C.** Configure a single global external HTTPS Application Load Balancer with a backend bucket for the Cloud Storage assets and a backend service for the MIG. Enable Cloud CDN on the backend bucket configuration.

**D.** Enable the static website hosting feature on the Cloud Storage bucket.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 279

Contexto: [topics:725](#topics-725)
You are planning a Google Kubernetes Engine (GKE) cluster deployment for a new application that will have varying compute requirements throughout the day. The application will serve different microservices, each potentially requiring different machine types and GPU configurations. You need a scalable and efficient solution that allows you to manage different types of worker nodes independently within the same cluster. What should you do?

**A.** Create multiple node pools within the GKE cluster. Configure each node pool with specific machine types and auto-scaling settings to match the varying compute needs of different microservices.

**B.** Provision the GKE cluster with a single default node pool using a general-purpose machine type. Enable the cluster autoscaler to add or remove nodes based on overall CPU utilization.

**C.** Create a single default node pool within the GKE cluster, and implement Pod affinity and anti-affinity rules to schedule microservices on specific nodes based on their resource requirements.

**D.** Deploy separate GKE clusters for each microservice, each with a single node pool, to isolate compute resources and manage them independently.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 280

Contexto: [topics:725](#topics-725)
Your organization has a web-based application that is going to be migrated to Google Cloud from an on-premises environment. You need to set up Cloud CDN for the application migration. The application previously used a different CDN provider and is configured to respond with Cache-Control headers. You want to keep this configuration. What should you do?

**A.** Don’t configure Cloud CDN at all since the backend is already configured for caching.

**B.** Use the automatic caching mechanism in Cloud CDN by configuring CACHE_ALL_STATIC cache mode.

**C.** Migrate the website to a Cloud Storage bucket, and use its built-in caching.

**D.** Configure USE_ORIGIN_HEADERS to honor the cache headers delivered by the origin.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 281

Contexto: [topics:725](#topics-725)
You are monitoring a fleet of production VMs that handle sensitive user data. Your security team requires a full copy of all inbound and outbound network traffic from these VMs for deep packet inspection by a third-party Intrusion Detection System (IDS). The IDS appliances are deployed as a managed instance group (MIG) and are served by an internal passthrough Network Load Balancer. You need to configure a monitoring solution that does not introduce any latency to the production traffic path. What should you do?

**A.** Deploy a Cloud IDS endpoint in the production VPC, and configure the endpoint to inspect traffic from the specified VMs.

**B.** Configure VPC Flow Logs for the production subnet, set the sampling rate to maximum, and stream the logs to the IDS appliances for analysis.

**C.** Configure a Cloud Private NAT gateway for the production VMs, and route all egress traffic through the gateway to the IDS appliances.

**D.** Create a Packet Mirroring policy that selects the production VMs as mirrored sources and sets the internal passthrough Network Load Balancer as the collector destination.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 282

Contexto: [topics:725](#topics-725)
You are deploying a new internal application on Google Kubernetes Engine (GKE). This application will be accessed by other internal services within the same Google Cloud VPC network. The application will need to communicate with a database service running within this VPC. You need the GKE cluster’s Pods to be allocated IP addresses directly from a range within the VPC. What should you do?

**A.** Create a GKE cluster with a primary IP address range for Pods that is separate from the Node's primary IP range.

**B.** Create a routes-based GKE cluster, and rely on the automatically generated custom static routes in the VPC for Pod IP address connectivity.

**C.** Enable VPC-native traffic routing by creating a cluster that uses alias IP ranges for its Pods and Services.

**D.** Implement a public GKE cluster so that the Pods can communicate to the databases through public or private IP addresses.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 283

Contexto: [topics:725](#topics-725)
You are integrating your company’s on-premises SD-WAN fabric with Google Cloud to route traffic from application VPCs to your on-premises network. The SD-WAN appliance is already deployed as a virtual machine in a central hub VPC. You want to minimize operational complexity by using the SD-WAN virtual appliance for policy enforcement and dynamic route exchange. What should you do?

**A.** Place the SD-WAN appliance that is in the hub VPC in a backend service behind an internal passthrough Network Load Balancer. Create a custom route in the spoke VPC that uses the load balancer as the next hop.

**B.** Establish a direct HA VPN connection from the application VPCs to the on-premises data center, and configure BGP to exchange dynamic routes directly.

**C.** Create a Network Connectivity Center hub in the hub VPC, and register the SD-WAN virtual machine as a router appliance hybrid spoke. Add the application networks to the hub as VPC spokes.

**D.** Peer the central hub and application VPCs. Create a static route in the application VPCs for the on-premises CIDR range with the next-hop set to the internal IP address of the SD-WAN appliance.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 284

Contexto: [topics:725](#topics-725)
You are doing a canary test for a new version of an online retailer’s main application, called app-v2, which is configured as a separate backend service from the current version, app-v1. You need to direct 10% of the traffic for the path /shop to app-v2 and direct the remaining 90% to app-v1.

The app-v2 service supports calls on both /shop/v2 and /shop, and the app-v1 service only supports calls on /shop. You need to implement the most efficient solution to achieve this traffic split and path rewrite.

What should you do?

**A.** •	Create a path rule for /shop in the URL map.
•	Configure its route action with weightedBackendServices to split traffic 90% to app-v1 and 10% to app-v2.

**B.** •	Create a single URL map rule for the /shop path.
•	In the rule’s route action, configure weightedBackendServices to split traffic 90/10 between app-v1 and app-v2.
•	Configure a urlRewrite to change the path to /shop/v2.

**C.** •	Create two URL map rules with the same /shop path.
•	Configure the first rule with a higher priority to route traffic to app-v2, and perform a urlRewrite to /shop/v2.
•	Configure the second rule with a lower priority to route traffic to app-v1 without a rewrite.

**D.** •	Create two separate route rules in the URL map.
•	The first rule, with a higher priority, matches traffic based on a specific HTTP header and routes it to app-v2 with a URL.
•	The second rule, with a lower priority, routes all other traffic to app-v1.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 285

Contexto: [topics:725](#topics-725)
Your company has a web application, app.example.com, hosted on a Compute Engine instance within a Google Cloud VPC. You need to configure DNS so that employees inside the VPC resolve app.example.com to its private IP address, while external users on the internet resolve the same hostname to a public IP address managed by a global external HTTPS Application Load Balancer. Your solution needs to follow Google-recommended practices.

What should you do?

**A.** Use a Cloud DNS forwarding zone to send all queries for app.example.com from your VPC to an on-premises DNS server that holds the private record.

**B.** Create a single public Cloud DNS zone for app.example.com. Add two ‘A’ records with the same hostname: one for the public IP and one for the private IP, relying on DNS round-robin.

**C.** Use Cloud DNS split horizon to create two Cloud DNS zones for app.example.com: a public zone for the public IP and a VPC-authorized private zone for the private IP.

**D.** Create a private Cloud DNS zone for app.example.com, and use a Cloud NAT gateway to translate the private IP to a public IP for external users.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 286

Contexto: [topics:725](#topics-725)
You are managing a containerized application environment on Google Kubernetes Engine (GKE). You deployed a microservice with a Kubernetes service manifest that defines a named port, http-api, for its main endpoint. You are now configuring an external http(s) load balancer to expose this microservice. You need to ensure the configuration is independent of the actual port number and follows best practices.

What should you do?

**A.** Create a backend service that uses the GKE node instance group as its backend, and configure the named port http-api in the backend service.

**B.** Reference the GCE_VM_IP_PORT network endpoint group (NEG) in the backend configuration that was automatically created for your Kubernetes service, and specify http-api named port for traffic.

**C.** Add an annotation to your Kubernetes service manifest to create a GCE_VM_IP network endpoint group (NEG), and configure the backend service to use this NEG.

**D.** Add an annotation in your Kubernetes ingress manifest to specify the http-api port number directly, and configure the backend service to use this hardcoded port number.

**Respuesta de la fuente:** B

**Explicación:** Using a Network Endpoint Group (NEG) created automatically for the Kubernetes service allows traffic to be routed directly to pods, bypassing node proxies and reducing latency. Referencing the named port `http-api` in the backend configuration ensures that the load balancer mapping remains independent of any specific port number changes, adhering to best practices for maintainability.

## Pregunta 287

Contexto: [topics:725](#topics-725)
You are assisting two independent development teams within your organization.

•	The first team manages a project (project-dev-a) with a VPC (vpc-a) hosting a critical backend microservice.
•	The second team manages a separate project (project-dev-b) with a VPC (vpc-b) hosting a frontend application that heavily consumes data from the backend microservice.

Both teams require secure, high-bandwidth, bi-directional connectivity, and low-latency communication between their applications, while minimizing operational overhead. Neither team wants to centralize their VPC management under a single Shared VPC host project. You need to implement a decentralized VPC management strategy.

What should you do?

**A.** Configure a VPC Network Peering connection between the two VPCs.

**B.** Setup Cloud VPN tunnels between the two VPCs.

**C.** Create a Network Connectivity Center hub and register both VPCs as spokes.

**D.** Use Private Service Connect endpoints.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 288

Contexto: [topics:725](#topics-725)
Your company uses a multi-VPC architecture to isolate its production, development, and testing environments. Following a recent security mandate, you need to ensure that all Compute Engine VMs across multiple production VPCs can access Google APIs, such as Cloud Storage and Cloud SQL, without having any route pointing to the internet gateway to comply with security policies. Your solution must also be scalable and easy to manage across all VPCs.

What should you do?

**A.** Deploy a Cloud NAT gateway in each VPC region to provide a secure egress point for traffic destined for Google APIs.

**B.** Configure VPC Service Controls, and create a service perimeter that includes all relevant projects and the required Google services on each VPC.

**C.** Enable Private Google Access on all subnets where the VMs are located. Create a private zone in Cloud DNS for googleapis.com, with an A record pointing to 199.36.153.8/30.

**D.** Create a Private Service Connect endpoint for Google APIs in each of the VPCs. Create a private zone in Cloud DNS for googleapis.com, with an A record pointing to the PSC endpoint created.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 289

Contexto: [topics:725](#topics-725)
Your company’s current network deployment is composed of a single VPC that is connected to a single data center by a Dedicated Interconnect connection. The Dedicated Interconnect topology has a 99.9% SLA. There is a single VLAN attachment for each of the two Dedicated Interconnect links. All VLAN attachments only use IPv4 addresses. Between the data center and the VPC, only IPv4 routes are exchanged by BGP.

You need to create a solution to exchange IPV6 routes between the data center and the VPC. You must use a procedure that requires the least amount of setup effort and minimizes costs. It’s impossible to add new BGP peers to the configuration of the on-premises routers. Only modifications of the existing BGP peers are possible.

What should you do?

**A.** Modify the stack type of the existing VLAN attachments from IPv4 only to dual stack. Add a pair of new IPv6-only interfaces to the cloud router. Add the new IPv6 BGP peers to the cloud router corresponding to on-premises routers.

**B.** Enable BFD on the cloud router where the BGP sessions between your cloud router and the on-premises router are configured.

**C.** Delete the existing VLAN attachments. Create two new dual stack VLAN attachments. Enable multiprotocol BGP (MP-BGP) on all the BGP sessions between your cloud router and the on-premises router.

**D.** Modify the stack type of the existing VLAN attachments from IPv4 only to dual stack. Enable multiprotocol BGP (MP-BGP) on all the BGP sessions between your cloud router and the on-premises router.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 290

Contexto: [topics:725](#topics-725)
Your media organization hosts its main news site on Cloud Run. The site is served through a global external Application Load Balancer with Cloud CDN enabled to ensure fast page load times for a global audience. You recently pushed a critical correction to a major news story, but you have received reports that users are still seeing the original, incorrect version of the article.

You have confirmed the updated content is live on the Cloud Run service. You need to ensure the corrected article is served to all users immediately with limited disruption.

What should you do?

**A.** Redeploy the Cloud Run service with a new revision.

**B.** Update the Time to Live (TTL) for the backend service in the Cloud CDN configuration to 0.

**C.** Disable and then re-enable Cloud CDN in the backend service configuration.

**D.** Run the gcloud compute url-maps invalidate-cdn-cache command with the path to the updated article.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 291

Contexto: [topics:725](#topics-725)
You manage a large, VPC-native Google Kubernetes Engine (GKE) cluster that is running out of IP addresses in its primary Pod CIDR range of 10.100.0.0/16. You have identified an available, non-contiguous CIDR block, 10.200.0.0/16, to use for new Pods. You need to expand the cluster’s Pod address space with this new range.

You also need to ensure that all traffic from Pods, regardless of which CIDR range they belong to, have its source address translated to the node’s IP address when communicating with an on-premises legacy monitoring system located at 192.168.10.0/24 while minimizing operational overhead.

What should you do?

**A.** Create a new node pool, and assign the 10.200.0.0/16 range as a secondary IP range to the underlying subnet.

**B.** •	Create a new secondary IP address range in the cluster’s subnet with the range 10.200.0.0/16.
•	Update the GKE cluster to use this new secondary range for Pods.
•	Ensure the ip-masq-agent ConfigMap’s nonMasqueradeCIDRs list does not include 192.168.10.0/24.

**C.** •	Create a new secondary IP address range in the cluster’s subnet with the range 10.200.0.0/16.
•	Update the GKE cluster to use this new secondary range for Pods.
•	Modify the ip-masq-agent ConfigMap to add 192.168.10.0/24 to the nonMasqueradeCIDRs list.

**D.** Create a new GKE cluster with the new Pod range, and use VPC Network Peering to connect it to the old cluster.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 292

Contexto: [topics:725](#topics-725)
Your organization needs to address the lack of private IP addresses. You need to create new GKE clusters and limit the secondary range size for pods to a maximum of /22.

What should you do?

**A.** Create a secondary range for pods with a size of /22. Create a secondary range for services manually. Reference these ranges during the GKE cluster creation.

**B.** Specify a new /22 IP range for pods during the GKE cluster creation. Let GKE automatically create the secondary range in your existing primary subnet range.

**C.** Deploy GKE Autopilot instead of GKE Standard.

**D.** Configure the pods per node value to the minimum to automatically use smaller subnet ranges for pods during the GKE cluster creation.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 293

Contexto: [topics:725](#topics-725)
Your global media company delivers premium video content to a worldwide audience. You set up an external Application Load Balancer with an internet network endpoint group (NEG) pointing to your on-premises video storage. Cloud CDN is enabled on this backend service, and you are using signed URLs to ensure only authorized users can access the video files.

A new, updated version of a popular video has recently been uploaded to the on-premises origin server, replacing the old file. You must ensure that all subsequent user requests retrieve the new version of the video immediately while maintaining the security of the content.

What should you do?

**A.** Rotate the Cloud CDN signed URL keys for the backend service.

**B.** Modify the backend service’s Cloud CDN policy to use origin headers for caching (USE_ORIGIN_HEADERS), and configure the origin to serve the video with a Cache-Control: no-store header.

**C.** Temporarily disable signed URLs on the backend service, wait for the cache to expire, and then re-enable signed URLs.

**D.** Invalidate the cache for the specific video file path, and ensure your application generates new signed URLs for users.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 294

Contexto: [topics:725](#topics-725)
You are establishing a hybrid connection between your on-premises data center and Google Cloud. You configured a Cloud DNS private zone and an inbound server policy in your primary VPC to allow on-premises hosts to resolve private DNS zones hosted in Google Cloud, such as vm.gcp.corp.internal. The inbound server policy has been assigned an IP address, and you have configured your on-premises DNS servers to conditionally forward requests for the gcp.corp.internal domain to this IP.

From your on-premises network, you can see that the routes for the inbound forwarding addresses were learned as expected, and response traffic is correctly being routed through your on-premises edge firewall to GCP. However, all DNS queries from on-premises clients for this domain are timing out, and they are unable to resolve the addresses of any Google Cloud resources.

What should you do?

**A.** Create a firewall rule on your on-premises firewall to allow traffic on TCP:53 and UDP:53 from the on-premises IP address range to Cloud DNS inbound server policy IP addresses.

**B.** Ensure the Cloud DNS API is enabled in the project that contains your primary VPC.

**C.** Create a Cloud DNS peering connection between your VPC and the VPC where the private zone is hosted.

**D.** Configure the Cloud DNS outbound server policy with the same IP address as the inbound policy.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 295

Contexto: [topics:725](#topics-725)
You manage a multi-tenant Google Kubernetes Engine (GKE) cluster where multiple teams deploy applications into a shared namespace.

•	One team has deployed a two-tier application with a frontend deployment and a backend deployment, identified by the labels app:frontend and app:backend, respectively.
•	Another team runs an analytics service, labeled app:analytics, in the same namespace.

You must implement a security rule stating that only Pods from the frontend deployment are allowed to connect to the backend Pods on TCP port 8080. You also must ensure that all other traffic to the backend Pods, including from the analytics pods, must be blocked while minimizing operational overhead.

What should you do?

**A.** Create a VPC firewall rule with a high priority to deny ingress traffic on port 8080 for all GKE nodes.

**B.** Install Istio on the cluster, and configure an AuthorizationPolicy to only allow requests from the frontend’s service account to the backend service.

**C.** Create a NetworkPolicy that selects the Pods with the app:backend label and includes an ingress rule that denies traffic from Pods with the app:analytics label.

**D.** Create a NetworkPolicy that selects Pods with the app:backend label and includes an ingress rule that only allows traffic on TCP port 8080 from Pods with the app:frontend label.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 296

Contexto: [topics:725](#topics-725)
You manage a rapidly growing ecommerce application running on a Google Kubernetes Engine (GKE) cluster. The cluster currently has a single-node pool (default-pool) that is configured with e2-standard-4 machine types and is using a /24 CIDR range for its nodes.

You recently observed that the application pods were stuck in a “pending” state, and you discovered that the default-pool had reached its maximum size because the subnet’s IP address space for nodes was exhausted. You need to add more compute capacity to the cluster immediately to handle the increased load and ensure future node scalability.

What should you do?

**A.** Configure a new primary range (that is, a new subnet) within the cluster’s VPC. Create a new node pool using this new primary range.

**B.** Add a new secondary IP address range to the existing subnet, and configure the default-pool to use it for new nodes.

**C.** Edit the default-pool to use a larger machine type, such as e2-standard-8, to provide more resources per node.

**D.** Increase the maxPodsPerNode setting on the existing default-pool to allow more pods to be scheduled.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 297

Contexto: [topics:725](#topics-725)
Your company’s current network deployment consists of:

•	One physical branch office in CITY_A.
•	One physical branch office in CITY_B.
•	One VPC with two compute instances (SDWAN_ONE, SDWAN_TWO) that act as SDWAN hubs for the two branch offices and provide applications running in the branch offices access to the databases deployed in the VPC. The databases are deployed on compute instances.

The CITY_A branch office has an SDWAN tunnel to the SDWAN_ONE compute instance. The CITY_B branch office has an SDWAN tunnel to the SDWAN_TWO compute instance. All tunnels run over the public internet.

You are notified that the applications in the CITY_A branch office are excessively slow. You need to determine if this behavior is network related. You must leverage a procedure that requires the least amount of setup effort and cost.

What should you do?

**A.** Enable VPC Flow Logs on the SDWAN_ONE compute instance and the compute instances of the databases. Investigate the rtt_msec metadata in the VPC Flow Logs.

**B.** SSH into the SDWAN_ONE compute instance and analyze the situation using the troubleshooting commands provided within the SDWAN_ONE operating system.

**C.** Use Network Intelligence Center to run a connectivity test between the SDWAN_ONE compute instance and the public IP address of the SDWAN hub that is located in the CITY_A branch.

**D.** Review the Performance Dashboard in Network Intelligence Center. Analyze packet loss and latency between the SDWAN_ONE compute instance and the databases’ compute instances. Analyze latency over the internet between CITY_A and the SDWAN_ONE compute instance.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 298

Contexto: [topics:725](#topics-725)
The applications in your Google Cloud environment and your AWS cloud environment frequently exchange large volumes of data, and the existing Cloud VPN connections are not meeting the required throughput and reliability. You need to establish high-performance, low-latency, highly available connectivity between your Google Cloud environment and your AWS cloud environment. You also need to create a dedicated, private connection between your Google Cloud VPC and your AWS VPC.

What should you do?

**A.** Establish a Partner Interconnect connection with a service provider that has direct presence in both Google Cloud and AWS regions.

**B.** Configure multiple dedicated Cloud VPN tunnels in an active/active configuration between the Google Cloud VPC and AWS VPC.

**C.** Provision a Cross-Cloud Interconnect connection between your Google Cloud project and your AWS account, and configure Border Gateway Protocol (BGP) peering over the dedicated connection.

**D.** Use a Google Cloud Dedicated Interconnect and an AWS Direct Connect and route traffic through a co-location provider.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 299

Contexto: [topics:725](#topics-725)
You are designing the VPC network for a large enterprise with many development teams. You need to centralize the management of common network resources while allowing each development team the flexibility to provision and manage their own virtual machines and other compute resources within their respective projects. You also need to ensure that all applications can communicate securely within the corporate environment.

What should you do?

**A.** Designate a host project to contain a Shared VPC network, and then attach each development team’s project as a service project to share this network.

**B.** Configure Cloud VPN tunnels from each development project’s VPC to a central network project that acts as a hub.

**C.** Implement a single large VPC for all development teams in one project and grant them specific IAM roles to manage resources within it.

**D.** Create individual VPCs in each development project and establish VPC Network Peering connections between all of them.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 300

Contexto: [topics:725](#topics-725)
You are designing the networking infrastructure for your company on Google Cloud. Your design must connect three separate VPC networks for development, testing, and production to two on-premises data centers while remaining isolated from each other. Each data center is connected to Google Cloud via Cloud VPN.

Additionally, your design must incorporate a user-published security service that is hosted in another Google Cloud organization and made available for private consumption. You need to create a scalable and centrally managed solution.

What should you do?

**A.** Use VPC Network Peering to create a full mesh between the development, testing, and production VPCs and the Cloud VPN network.

**B.** Create a Network Connectivity Center hub, and configure each of the three VPCs and the two Cloud VPN spokes. Use Private Service Connect to access the third-party service.

**C.** Create a Shared VPC, and migrate the resources from the development, testing, and production VPCs into service projects.

**D.** Use Network Connectivity Center to establish a full-mesh topology between the three VPCs. Use VPC Network Peering to connect to the Cloud VPN and Private Service Connect to access the third-party service.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 301

Contexto: [topics:725](#topics-725)
You are designing a security-focused network architecture on Google Cloud. Your company has deployed a central inspection VPC that contains a fleet of Cloud Next Generation Firewall (NGFW) appliances. The inspection VPC has a default route with next hop pointing to the passthrough Network Load Balancer with NGFW appliances as backends.

You also have two application VPCs (App-A and App-B) that are not allowed to directly communicate with each other, nor do they have a default route in their VPC. You need to ensure that all traffic originating from App-A and App-B are forced through the inspection VPC to be analyzed by the Cloud NGFW appliances.

What should you do?

**A.** Use VPC Network Peering to create a full mesh by peering all three VPCs with each other, and then use firewall rules to deny all traffic between App-A and App-B.

**B.** Create a Network Connectivity Center hub in mesh topology, connect all three VPCs as spokes, and configure the inspection VPC to advertise the default route.

**C.** Create a Network Connectivity Center hub in star topology. Configure the inspection VPC spoke as a center group that advertises a default route, and configure the application VPCs as edge spokes to use that route for inter-VPC traffic.

**D.** Create two separate VPC Network Peering connections: One between the inspection VPC and App-A, and another between the inspection VPC and App-B.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 302

Contexto: [topics:725](#topics-725)
You are designing a Google Kubernetes Engine (GKE) cluster for a rapidly scaling microservices application. The application will have thousands of pods and hundreds of services. The application requires internal pod-to-pod communication and exposure of services internally. You want to follow Google’s recommended approach to ensure efficient IP address utilization within your existing Virtual Private Cloud (VPC) subnet while leveraging Google Cloud’s native networking capabilities.

What should you do?

**A.** Deploy a route-based GKE cluster and rely on GKE-managed routing tables for all pod and service communication.

**B.** Allocate a primary IP address range for the entire cluster to encompass both node, pod, and service IP addresses.

**C.** Configure the GKE cluster to use a VPC-native mode with the main subnets primary IP range for nodes, and separate secondary IP ranges for pods and services.

**D.** Implement a mesh of Istio service proxies on every pod to manage all internal pod-to-pod communication and service discovery.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 303

Contexto: [topics:725](#topics-725)
You are managing the integration of a newly acquired company. The main corporate VPC (vpc-corp) and the acquired company’s VPC (vpc-acquired) have overlapping subnet CIDR ranges. You need to enable a private connection that allows the monitoring service in vpc-corp to initiate traffic to application servers in vpc-acquired while preventing all other connections.

What should you do?

**A.** Create a Network Connectivity Center hub. On the vpc-acquired spoke, configure Private NAT to translate its addresses for inbound traffic.

**B.** Create a Network Connectivity Center hub, connect both VPCs as spokes, and deploy a proxy instance in the hub.

**C.** Deploy Cloud NAT gateway in vpc-corp. Configure Cloud NAT to translate traffic outbound. Configure an external load balancer in vpc-acquired to accept the connections from Cloud NAT.

**D.** Create a Network Connectivity Center hub. On the vpc-corp spoke, configure Private NAT to translate its source address range for outbound traffic.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 304

Contexto: [topics:725](#topics-725)
Your company is modernizing its infrastructure by expanding its services. You are concerned about the long-term scalability of your network due to IPv4 address exhaustion. You need to design and deploy a new Google Kubernetes Engine (GKE) cluster that allows Pods and Services to communicate over IPv6 while maintaining IPv4 connectivity for backward compatibility with existing systems.

What should you do?

**A.** Create a new standard GKE cluster, and enable an IPv6-only address range for Pods.

**B.** Create a new GKE cluster, and enable an IPv6-only node pool.

**C.** Deploy a Cloud NAT gateway within your VPC to translate traffic between your existing IPv4-only GKE cluster and external IPv6 clients.

**D.** Create a new dual-stack subnet within your VPC, and then create a new GKE cluster within that subnet and specify dual-stack networking mode.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 305

Contexto: [topics:725](#topics-725)
You are designing a highly resilient and secure connection between an on-premises data center and Google Cloud for a financial services company. The company requires 10 Gbps of bandwidth and mandates that all traffic be encrypted end-to-end between their on-premises network and their Google Cloud VPC. You have already provisioned two 10 Gbps Dedicated Interconnect connections. You need to determine an encryption strategy that meets these requirements and provides redundancy.

What should you do?

**A.** Deploy four HA VPN gateways on each Dedicated Interconnect connection.

**B.** Deploy two HA VPN gateways on each Dedicated Interconnect connection.

**C.** Configure MACsec on each of the Dedicated Interconnect connections.

**D.** Use one Dedicated Interconnect for traffic and an HA VPN over the internet for backup.

**Respuesta de la fuente:** A

**Explicación:** The scenario mandates Dedicated Interconnects for transport, which rules out Internet-based HA VPN (Option D) and MACsec (Option C), as MACsec encrypts the link but does not use the tunnel architecture described in Options A/B.
To achieve end-to-end encryption over the interconnect with redundancy, you must deploy HA VPN gateways. According to Google Cloud best practices for capacity scaling, a 10 Gbps connection requires four active tunnels per attachment to fully utilize the bandwidth while maintaining high availability; thus, deploying four HA VPN gateways (tunnels) on each connection is the correct configuration.

## Pregunta 306

Contexto: [topics:725](#topics-725)
You are designing a solution to inspect all traffic between your company’s production-vpc and development-vpc for threat detection and compliance logging. The company will deploy a fleet of third-party Cloud Next Generation Firewall (NGFW) appliances that provide intrusion prevention system (IPS) capabilities. You need to prevent attacks by blocking malicious traffic in real time before it reaches its destination without adding significant latency or creating a single point of failure for inter-VPC communication.

What should you do?

**A.** •	Deploy the third-party NGFW appliances as multi-NIC VMs, with an NIC in each VPC.
•	Create custom static routes in each VPC that direct traffic destined for the other VPC to an internal TCP/UDP load balancer that uses the NGFW appliances as its backends.

**B.** •	Use Packet Mirroring to send traffic to the third-party NGFW appliances.
•	When a threat is detected, have the appliances use the Google Cloud Armor API to insert a rule blocking the malicious source.

**C.** •	Use Packet Mirroring to create a copy of all inter-VPC traffic.
•	Forward it to an internal Application Load Balancer that distributes the traffic to the NGFW appliance fleet for analysis.

**D.** •	Configure a Cloud NAT gateway to handle routing between the two VPCs, and enable NAT logging.
•	Use a script to parse the logs, and send them to the NGFW appliances.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 307

Contexto: [topics:725](#topics-725)
Your company runs its applications on Google Kubernetes Engine (GKE), and your team recently created a private Cloud DNS zone, corp.internal, to host records for internal services, such as a managed database at db.corp.internal. You verified that a Compute Engine VM in the same VPC as your GKE cluster can successfully resolve db.corp.internal. However, when you access a Pod inside your GKE cluster, you can resolve in-cluster services (for example, kubernetes.default.svc.cluster.local), but any attempt to resolve db.corp.internal fails.

Upon inspecting the coredns ConfigMap in the kube-system namespace, you discovered the default forward plugin has been modified to point directly to a public DNS provider’s IP address, bypassing the node’s local resolver. You need to enable Pods in the cluster to resolve records in the existing corp.internal private zone as well as other zones under .internal.

**A.** Modify the coredns ConfigMap in the kube-system namespace, and add corp.internal to a stubDomains entry that points to the VPC’s DNS resolver.

**B.** Create a Kubernetes service and endpoint of type ExternalName for db.corp.internal.

**C.** Enable Cloud DNS for GKE for the GKE cluster.

**D.** Modify the coredns ConfigMap in the kube-system namespace. In the Corefile configuration, change the forward plugin to point to /etc/resolv.conf.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 308

Contexto: [topics:725](#topics-725)
You are designing a critical multi-tier application on Google Cloud that requires high availability across multiple regions. The application consists of a web frontend in a managed instance group (MIG), an API backend, and a Cloud SQL database. You need to ensure that the application can seamlessly fail over to a secondary region if the primary region becomes unavailable, minimizing downtime and data loss.

What should you do?

**A.** Deploy the web frontend MIG in a single region, and configure a Cloud DNS failover policy pointing to a load balancer in another region.

**B.** Implement a strategy by deploying identical application components in two separate regions and using a global external HTTPS load balancer with multiple backend services.

**C.** Implement a disaster recovery strategy by deploying identical application components in two separate regions. Configure global external HTTPS load balancers in both regions, and use Cloud DNS to distribute traffic between them based on latency.

**D.** Configure cross-regional VPC Network Peering between the primary and secondary regions to allow for direct traffic flow during a failover event.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 309

Contexto: [topics:725](#topics-725)
You manage the network for a large enterprise with two geographically dispersed on-premises data centers: datacenter-east and datacenter-west. You also have a Google Cloud VPC named hub-vpc. You need to set up secure and high bandwidth private network communication between datacenter-east and datacenter-west using your existing Google Cloud network.

What should you do?

**A.** •	Create Dedicated Interconnects between hub-vpc and datacenter-east, and hub-vpc and datacenter-west.
•	Create a proxy VM to proxy traffic from one region to another.

**B.** •	Create an NCC hub and add hub-vpc as a VPC spoke.
•	Create an HA-VPN between hub-vpc and datacenter-east, and hub-vpc and datacenter-west.
•	Add the HA-VPNs as hybrid spokes to the NCC hub with site-to-site data transfer set to On.

**C.** •	Create an HA-VPN between hub-vpc and datacenter-east, and hub-vpc and datacenter-west.
•	Configure Cloud Storage buckets in your Google Cloud project, and use them as an intermediary to transfer data between datacenter-east and datacenter-west.

**D.** •	Create an NCC hub and add hub-vpc as a VPC spoke.
•	Create Dedicated Interconnects between hub-vpc and datacenter-east, and hub-vpc and datacenter-west.
•	Add the Dedicated Interconnects as hybrid spokes to the NCC hub with site-to-site data transfer set to On.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 310

Contexto: [topics:725](#topics-725)
You maintain a complex set of VPC firewall rules across multiple projects. Over time, many rules have been added, causing unintended behavior or security gaps when other rules are shadowed by higher-priority rules. You need a systematic way to identify these inefficient or ineffective firewall rules.

What should you do?

**A.** Review Cloud Logging entries for firewall rules to see which rules are being triggered.

**B.** Use VPC Flow Logs to trace network traffic and determine which firewall rules were applied to specific connections.

**C.** Create and run Connectivity Tests to see which paths are blocked or allowed.

**D.** Use Firewall Insights within the Network Intelligence Center to analyze rule usage and identify unused rules.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 311

Contexto: [topics:725](#topics-725)
Your company’s architecture consists of two separate VPCs, dev-vpc and prod-vpc, each in its own project. Both VPCs are connected to your on-premises data center through their own dedicated Cloud VPN tunnels and Cloud Routers. The on-premises network has a legacy DNS server at 192.168.1.10 that is authoritative for the corp.local zone.

You need to enable Compute Engine instances in both VPCs to resolve hostnames within the corp.local zone, while following Google-recommended practices for a scalable and manageable hub-and-spoke DNS design.

What should you do?

**A.** •	Create a Cloud DNS forwarding zone in the prod-vpc for the corp.local zone that forwards to 192.168.1.10.
•	Create a Cloud DNS peering zone in the dev-vpc for corp.local that peers with the prod-vpc.
•	Add a custom BGP advertisement on the prod-vpc’s Cloud Router for the 35.199.192.0/19 range.

**B.** •	Create a Cloud DNS forwarding zone in both VPCs for the corp.local zone that forwards to 192.168.1.10.
•	Add a custom BGP advertisement on the prod-vpc’s Cloud Router for the 35.199.192.0/19 range.

**C.** •	Create a Cloud DNS forwarding zone in the prod-vpc for the corp.local zone that forwards to 192.168.1.10.
•	Create a Cloud DNS peering zone in the dev-vpc for corp.local that peers with the prod-vpc.
•	Use the default BGP advertisements on the prod-vpc’s Cloud Router.

**D.** •	Create a Cloud DNS forwarding zone in both VPCs for the corp.local zone that forwards to 192.168.1.10.
•	Add a custom BGP advertisement on their respective Cloud Routers for the 35.199.192.0/19 range.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 312

Contexto: [topics:725](#topics-725)
You are designing the DNS topology for an enterprise that is migrating its applications to Google Cloud. The company has a robust on-premises Active Directory and DNS infrastructure that is authoritative for existing internal domains. New applications in Google Cloud will need their own private DNS records.

You need to achieve seamless resolution of all internal resources across both on-premises and cloud workloads, without exposing internal DNS records publicly, and minimize the administrative effort in managing DNS within the hybrid environment.

What should you do?

**A.** Deploy dedicated DNS proxy servers within the Google Cloud VPC, and configure these proxy servers to forward all DNS queries to the on-premises DNS servers. Concurrently configure the on-premises DNS servers to send cloud-specific DNS queries back to the Google Cloud proxy servers.

**B.** Configure Cloud DNS server policies in Google Cloud VPCs to enable:
•	inbound DNS queries from on-premises for cloud-hosted private zones.
•	outbound DNS forwarding to on-premises DNS servers for on-premises domains.

**C.** Use Cloud VPN or Interconnect to establish hybrid connectivity between the on-premises network and the Google Cloud VPThen configure custom route tables on all instances to direct DNS queries to the appropriate DNS server based on the domain.

**D.** Migrate all existing on-premises DNS records to private Cloud DNS zones, and configure all on-premises and cloud workloads to use Cloud DNS as their primary DNS resolver.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 313

Contexto: [topics:725](#topics-725)
You are designing a secure, multi-VPC environment using a Network Connectivity Center (NCC) hub. A landing-zone-vpc contains the VLAN attachments for a Dedicated Interconnect, which are configured as hybrid spokes on the NCC hub. The prod-vpc and landing-zone-vpc are connected as VPC spokes. Critical Cloud SQL databases are deployed in us-central1, hosted in the prod-vpc, and exposed using Private Service Connect (PSC) endpoints.

On-premises users, whose traffic arrives through the Dedicated Interconnect in us-west1, report they cannot connect to the database’s PSC endpoint. You need to enable this connectivity while following Google-recommended best practices.

What should you do?

**A.** Create additional PSC endpoints in us-central1 within the landing-zone-vpc using the Cloud SQL database service attachments found using the command gcloud sq1 instances describe.

**B.** Create additional PSC endpoints in us-west1 within the landing-zone-vpc using the Cloud SQL database service attachments found using the command gcloud sq1 instances describe.

**C.** Enable PSC connection propagation on the Network Connectivity Center hub. Specify the landing-zone-vpc as the target VPC network.

**D.** Enable PSC connection propagation on the Network Connectivity Center hub. Update the Cloud SQL PSC endpoints to enable global access.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 314

Contexto: [topics:725](#topics-725)
You are managing a hybrid network that connects your on-premises data center to a Google Cloud VPC through Cloud Interconnect. You created a Cloud DNS privately managed zone, corp.gcp.internal, for your VPC. Applications running on Compute Engine VMs are automatically registered in this zone.

Your on-premises users and servers need to resolve the DNS names in the corp.gcp.internal zone, but their requests are currently failing. You need to enable your on-premises DNS servers to forward these specific requests to Google Cloud using a secure method.

What should you do?

**A.** •	In Cloud DNS, create an inbound server policy and apply it to your VPC.
•	Configure your on-premises DNS server to conditionally forward requests for the corp.gcp.internal zone to one of the policy’s allocated IP addresses.
•	Advertise all VPC subnets from the Cloud Router to your on-premises network.

**B.** •	In Cloud DNS, create an outbound server policy and apply it to your VPC.
•	Configure your on-premises DNS server to conditionally forward requests for the corp.gcp.internal zone to an IP address within 35.199.192.0/19, the Cloud DNS proxy range.
•	Advertise the 35.199.192.0/19 range as a custom advertisement on the Cloud Router to your on-premises network.

**C.** •	In Cloud DNS, create an inbound server policy and apply it to your VPC.
•	Configure your on-premises DNS server to conditionally forward requests for the corp.gcp.internal zone to an IP address within 35.199.192.0/19, the Cloud DNS proxy range.
•	Advertise the 35.199.192.0/19 range as a custom advertisement on the Cloud Router.

**D.** •	In Cloud DNS, create an outbound server policy and apply it to your VPC.
•	Configure your on-premises DNS server to conditionally forward requests for the corp.gcp.internal zone to one of the policy’s allocated IP addresses.
•	Advertise all VPC subnets from the Cloud Router to your on-premises network.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 315

Contexto: [topics:725](#topics-725)
Your team is designing the network architecture for a new global web application in Google Cloud. This application’s frontend will serve HTTPS traffic to external users worldwide, and the backend will consist of game servers communicating via a custom TCP. You need to ensure low-latency access and high availability for the application while enabling global distribution and resilience.

What should you do?

**A.** Configure a global external Application Load Balancer for the HTTPS frontend and a cross-regional internal TCP proxy Network Load Balancer for the TCP game servers.

**B.** Configure a global external Application Load Balancer for the HTTPS frontend and an internal Network Load Balancer (Passthrough) for the game servers to handle direct client connections to backend instances globally.

**C.** Implement a regional external Application Load Balancer for the HTTPS frontend and multiple regional internal Network Load Balancers (Passthrough) for the TCP game servers across all regions.

**D.** Implement a regional internal Application Load Balancer for the HTTPS frontend and a regional internal TCP proxy Network Load Balancer for the game servers, and replicate this in each region.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 316

Contexto: [topics:725](#topics-725)
You manage a critical application that relies on a Dedicated Interconnect connection between your on-premises data center and your Google Cloud VPC. Users are reporting intermittent slowness when accessing the application. You need to confirm the health and performance of the Dedicated Interconnect connection and identify any bottlenecks.

What should you do?

**A.** Audit the BGP routing table on your Cloud Router to ensure all routes are being advertised on the dedicated link correctly.

**B.** Use VPC Flow Logs to analyze the traffic patterns between your on-premises network and the Google Cloud VPC.

**C.** Review Cloud Logging entries for the Dedicated Interconnect-related events to detect connection flaps.

**D.** Examine Cloud Monitoring metrics for the Dedicated Interconnect connection, focusing on ingress/egress bytes, packet loss, and latency.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.