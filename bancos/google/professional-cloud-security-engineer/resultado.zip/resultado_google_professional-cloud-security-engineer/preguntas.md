# professional cloud security engineer

376 / 376 preguntas. Cobertura completa: True.

Respuestas de la fuente; revisión técnica pendiente. Las imágenes permanecen en sus campos de origen.

376 respuestas conservadas; 0 pendientes.

<a id="topics-197"></a>
## Contexto topics:197
name:
Topic 1


## Pregunta 1

Contexto: [topics:197](#topics-197)
Your team needs to make sure that a Compute Engine instance does not have access to the internet or to any Google APIs or services.
Which two settings must remain disabled to meet these requirements? (Choose two.)

**A.** Public IP

**B.** IP Forwarding

**C.** Private Google Access

**D.** Static routes

**E.** IAM Network User Role

**Respuesta de la fuente:** A, C

**Explicación:** To prevent internet access, the instance must not have a Public IP address (A), as this is the direct path for outbound connectivity.
To block access to Google APIs and services specifically, Private Google Access (C) must be disabled, as this feature allows VMs with only private IPs to reach Google services directly without traversing the internet.

## Pregunta 2

Contexto: [topics:197](#topics-197)
Which two implied firewall rules are defined on a VPC network? (Choose two.)

**A.** A rule that allows all outbound connections

**B.** A rule that denies all inbound connections

**C.** A rule that blocks all inbound port 25 connections

**D.** A rule that blocks all outbound connections

**E.** A rule that allows all inbound port 80 connections

**Respuesta de la fuente:** A, B

**Explicación:** In a VPC, network firewall rules have specific default behaviors that are implied unless explicitly defined. By default, a VPC network allows all outbound traffic from all resources to the internet and other networks, satisfying option A. Simultaneously, the default policy for inbound traffic is to deny all connections that are not explicitly permitted by a specific allow rule, satisfying option B.
Option C is incorrect because while port 25 is often blocked by the underlying cloud provider to prevent spam, this is not a configurable *implied rule* within the standard VPC network firewall definition itself. Option D contradicts the default permissive outbound state, and Option E is incorrect because inbound traffic is strictly denied by default rather than allowed by default.

## Pregunta 3

Contexto: [topics:197](#topics-197)
A customer needs an alternative to storing their plain text secrets in their source-code management (SCM) system.
How should the customer achieve this using Google Cloud Platform?

**A.** Use Cloud Source Repositories, and store secrets in Cloud SQL.

**B.** Encrypt the secrets with a Customer-Managed Encryption Key (CMEK), and store them in Cloud Storage.

**C.** Run the Cloud Data Loss Prevention API to scan the secrets, and store them in Cloud SQL.

**D.** Deploy the SCM to a Compute Engine VM with local SSDs, and enable preemptible VMs.

**Respuesta de la fuente:** B

**Explicación:** Among the provided options, B is the correct choice because storing secrets in Cloud Storage encrypted with a Customer-Managed Encryption Key (CMEK) ensures that data remains confidential even if accessed by unauthorized personnel, as they would require the specific key to decrypt it. While Cloud Secret Manager is the modern best practice for this scenario, it is not listed; options A and C still store plaintext secrets in databases, and option D offers no encryption protection.

## Pregunta 4

Contexto: [topics:197](#topics-197)
Your team wants to centrally manage GCP IAM permissions from their on-premises Active Directory Service. Your team wants to manage permissions by AD group membership.
What should your team do to meet these requirements?

**A.** Set up Cloud Directory Sync to sync groups, and set IAM permissions on the groups.

**B.** Set up SAML 2.0 Single Sign-On (SSO), and assign IAM permissions to the groups.

**C.** Use the Cloud Identity and Access Management API to create groups and IAM permissions from Active Directory.

**D.** Use the Admin SDK to create groups and assign IAM permissions from Active Directory.

**Respuesta de la fuente:** A

**Explicación:** Cloud Directory Sync (now Identity Provider for Microsoft Active Directory) is the specific Google Cloud service designed to synchronize on-premises Active Directory groups and users into GCP.
Once the groups are synchronized, you can assign IAM roles directly to these GCP group resources, satisfying the requirement to manage permissions based on AD group membership.
SAML 2.0 (Option B) primarily handles authentication delegation, not the structural synchronization of group memberships required for centralized IAM management.

## Pregunta 5

Contexto: [topics:197](#topics-197)
When creating a secure container image, which two items should you incorporate into the build if possible? (Choose two.)

**A.** Ensure that the app does not run as PID 1.

**B.** Package a single app as a container.

**C.** Remove any unnecessary tools not needed by the app.

**D.** Use public container images as a base image for the app.

**E.** Use many container image layers to hide sensitive information.

**Respuesta de la fuente:** B, C

**Explicación:** Packaging a single application per container (B) follows the principle of isolation, reducing the attack surface and ensuring fault containment. Removing unnecessary tools (C) minimizes potential vulnerabilities by eliminating executables that could be exploited if the container is compromised.

Option A is incorrect because containers should generally run their main process as PID 1 to handle signals properly; Options D and E are insecure practices.

## Pregunta 6

Contexto: [topics:197](#topics-197)
A customer needs to launch a 3-tier internal web application on Google Cloud Platform (GCP). The customer's internal compliance requirements dictate that end- user access may only be allowed if the traffic seems to originate from a specific known good CIDR. The customer accepts the risk that their application will only have SYN flood DDoS protection. They want to use GCP's native SYN flood protection.
Which product should be used to meet these requirements?

**A.** Cloud Armor

**B.** VPC Firewall Rules

**C.** Cloud Identity and Access Management

**D.** Cloud CDN

**Respuesta de la fuente:** B

**Explicación:** VPC Firewall Rules are the correct choice because they provide native Layer 3/4 access control to restrict traffic source CIDRs for internal resources.
Cloud Armor is designed for Layer 7 HTTP/S security policies and DDoS mitigation at the load balancer edge, making it unsuitable for basic network-layer CIDR whitelisting of internal applications.

## Pregunta 7

Contexto: [topics:197](#topics-197)
A company is running workloads in a dedicated server room. They must only be accessed from within the private company network. You need to connect to these workloads from Compute Engine instances within a Google Cloud Platform project.
Which two approaches can you take to meet the requirements? (Choose two.)

**A.** Configure the project with Cloud VPN.

**B.** Configure the project with Shared VPC.

**C.** Configure the project with Cloud Interconnect.

**D.** Configure the project with VPC peering.

**E.** Configure all Compute Engine instances with Private Access.

**Respuesta de la fuente:** A, C

**Explicación:** Cloud VPN and Cloud Interconnect are the primary services designed to establish secure network connectivity between an on-premises environment (dedicated server room) and Google Cloud VPCs.

Cloud VPN creates encrypted tunnels over the public internet, while Cloud Interconnect provides a dedicated private connection, both allowing Compute Engine instances to reach the private workloads securely.

## Pregunta 8

Contexto: [topics:197](#topics-197)
A customer implements Cloud Identity-Aware Proxy for their ERP system hosted on Compute Engine. Their security team wants to add a security layer so that the
ERP systems only accept traffic from Cloud Identity-Aware Proxy.
What should the customer do to meet these requirements?

**A.** Make sure that the ERP system can validate the JWT assertion in the HTTP requests.

**B.** Make sure that the ERP system can validate the identity headers in the HTTP requests.

**C.** Make sure that the ERP system can validate the x-forwarded-for headers in the HTTP requests.

**D.** Make sure that the ERP system can validate the user's unique identifier headers in the HTTP requests.

**Respuesta de la fuente:** A

**Explicación:** To ensure the ERP system only accepts traffic from Cloud Identity-Aware Proxy (IAP), it must cryptographically verify the X-Goog-IAP-JWT-Assertion header. This header contains a JSON Web Token signed by Google, which proves the request originated from IAP and cannot be forged or bypassed. Validating other headers like x-forwarded-for or identity data alone is insufficient because they can potentially be spoofed if the application does not strictly enforce the cryptographic signature of the JWT.

## Pregunta 9

Contexto: [topics:197](#topics-197)
A company has been running their application on Compute Engine. A bug in the application allowed a malicious user to repeatedly execute a script that results in the Compute Engine instance crashing. Although the bug has been fixed, you want to get notified in case this hack re-occurs.
What should you do?

**A.** Create an Alerting Policy in Stackdriver using a Process Health condition, checking that the number of executions of the script remains below the desired threshold. Enable notifications.

**B.** Create an Alerting Policy in Stackdriver using the CPU usage metric. Set the threshold to 80% to be notified when the CPU usage goes above this 80%.

**C.** Log every execution of the script to Stackdriver Logging. Create a User-defined metric in Stackdriver Logging on the logs, and create a Stackdriver Dashboard displaying the metric.

**D.** Log every execution of the script to Stackdriver Logging. Configure BigQuery as a log sink, and create a BigQuery scheduled query to count the number of executions in a specific timeframe.

**Respuesta de la fuente:** A

**Explicación:** The objective is to receive notifications if the specific malicious script execution re-occurs. Option A is the only choice that explicitly enables an Alerting Policy with notifications triggered by a process health condition monitoring the script's execution count. Options C and D provide visibility via dashboards or scheduled queries but lack automated, real-time alerting capabilities. Option B monitors general CPU usage, which is not specific to the script and may generate false positives from normal workloads.

## Pregunta 10

Contexto: [topics:197](#topics-197)
Your team needs to obtain a unified log view of all development cloud projects in your SIEM. The development projects are under the NONPROD organization folder with the test and pre-production projects. The development projects share the ABC-BILLING billing account with the rest of the organization.
Which logging export strategy should you use to meet the requirements?

**A.** 1. Export logs to a Cloud Pub/Sub topic with folders/NONPROD parent and includeChildren property set to True in a dedicated SIEM project. 2. Subscribe SIEM to the topic.

**B.** 1. Create a Cloud Storage sink with billingAccounts/ABC-BILLING parent and includeChildren property set to False in a dedicated SIEM project. 2. Process Cloud Storage objects in SIEM.

**C.** 1. Export logs in each dev project to a Cloud Pub/Sub topic in a dedicated SIEM project. 2. Subscribe SIEM to the topic.

**D.** 1. Create a Cloud Storage sink with a publicly shared Cloud Storage bucket in each project. 2. Process Cloud Storage objects in SIEM.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because an aggregated sink created at the folder level with includeChildren set to true captures logs from all projects within that folder hierarchy.
This allows for a centralized export configuration that automatically includes new development projects, providing a unified log view without managing individual sinks.
While the sink also captures test and pre-production logs, these can be filtered within the SIEM or via advanced log filters, whereas per-project exports (Option C) lack the required scalability and uniformity.

## Pregunta 11

Contexto: [topics:197](#topics-197)
A customer needs to prevent attackers from hijacking their domain/IP and redirecting users to a malicious site through a man-in-the-middle attack.
Which solution should this customer use?

**A.** VPC Flow Logs

**B.** Cloud Armor

**C.** DNS Security Extensions

**D.** Cloud Identity-Aware Proxy

**Respuesta de la fuente:** C

**Explicación:** DNSSEC (Domain Name System Security Extensions) cryptographically signs DNS records to ensure the authenticity and integrity of DNS responses.
This prevents attackers from intercepting or spoofing domain-to-IP mappings, thereby mitigating DNS hijacking and man-in-the-middle attacks that redirect users to malicious sites.

## Pregunta 12

Contexto: [topics:197](#topics-197)
A customer deploys an application to App Engine and needs to check for Open Web Application Security Project (OWASP) vulnerabilities.
Which service should be used to accomplish this?

**A.** Cloud Armor

**B.** Google Cloud Audit Logs

**C.** Web Security Scanner

**D.** Anomaly Detection

**Respuesta de la fuente:** C

**Explicación:** Web Security Scanner is the correct service because it automatically scans applications for OWASP Top Ten vulnerabilities and other common web application security flaws.
It performs dynamic application security testing (DAST) against your deployed App Engine application, unlike Cloud Armor which focuses on DDoS mitigation and access control.

## Pregunta 13

Contexto: [topics:197](#topics-197)
A customer's data science group wants to use Google Cloud Platform (GCP) for their analytics workloads. Company policy dictates that all data must be company-owned and all user authentications must go through their own Security Assertion Markup Language (SAML) 2.0 Identity Provider (IdP). The
Infrastructure Operations Systems Engineer was trying to set up Cloud Identity for the customer and realized that their domain was already being used by G Suite.
How should you best advise the Systems Engineer to proceed with the least disruption?

**A.** Contact Google Support and initiate the Domain Contestation Process to use the domain name in your new Cloud Identity domain.

**B.** Register a new domain name, and use that for the new Cloud Identity domain.

**C.** Ask Google to provision the data science manager's account as a Super Administrator in the existing domain.

**D.** Ask customer's management to discover any other uses of Google managed services, and work with the existing Super Administrator.

**Respuesta de la fuente:** D

**Explicación:** Since the domain is already verified with a Google managed service, creating a new Cloud Identity instance for that same domain is technically impossible without first removing it from the existing account.
Initiating a domain contestation or registering a new domain would disrupt existing services and violate the goal of least disruption.
The correct approach is to coordinate with the current Super Administrator to configure SAML integration within the existing environment.

## Pregunta 14

Contexto: [topics:197](#topics-197)
A business unit at a multinational corporation signs up for GCP and starts moving workloads into GCP. The business unit creates a Cloud Identity domain with an organizational resource that has hundreds of projects.
Your team becomes aware of this and wants to take over managing permissions and auditing the domain resources.
Which type of access should your team grant to meet this requirement?

**A.** Organization Administrator

**B.** Security Reviewer

**C.** Organization Role Administrator

**D.** Organization Policy Administrator

**Respuesta de la fuente:** A

**Explicación:** The Organization Administrator role is the correct choice because it grants the necessary permissions (such as resourcemanager.projects.setIamPolicy) to manage IAM bindings and audit resources across the entire organization hierarchy. In contrast, the Organization Role Administrator only manages custom role definitions, not permission assignments, while Security Reviewer is read-only. Organization Policy Administrator focuses on resource constraints rather than identity-based access control.

## Pregunta 15

Contexto: [topics:197](#topics-197)
An application running on a Compute Engine instance needs to read data from a Cloud Storage bucket. Your team does not allow Cloud Storage buckets to be globally readable and wants to ensure the principle of least privilege.
Which option meets the requirement of your team?

**A.** Create a Cloud Storage ACL that allows read-only access from the Compute Engine instance's IP address and allows the application to read from the bucket without credentials.

**B.** Use a service account with read-only access to the Cloud Storage bucket, and store the credentials to the service account in the config of the application on the Compute Engine instance.

**C.** Use a service account with read-only access to the Cloud Storage bucket to retrieve the credentials from the instance metadata.

**D.** Encrypt the data in the Cloud Storage bucket using Cloud KMS, and allow the application to decrypt the data with the KMS key.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it leverages the metadata server to automatically provide short-lived credentials to the service account attached to the Compute Engine instance.
This approach adheres to the principle of least privilege by avoiding static key storage (as in B) and eliminates IP-based access controls that are insecure or unavailable for global services (as in A).
It ensures the bucket remains non-public while allowing secure, automated authentication without manual credential management.

## Pregunta 16

Contexto: [topics:197](#topics-197)
An organization's typical network and security review consists of analyzing application transit routes, request handling, and firewall rules. They want to enable their developer teams to deploy new applications without the overhead of this full review.
How should you advise this organization?

**A.** Use Forseti with Firewall filters to catch any unwanted configurations in production.

**B.** Mandate use of infrastructure as code and provide static analysis in the CI/CD pipelines to enforce policies.

**C.** Route all VPC traffic through customer-managed routers to detect malicious patterns in production.

**D.** All production applications will run on-premises. Allow developers free rein in GCP as their dev and QA platforms.

**Respuesta de la fuente:** B

**Explicación:** The goal is to reduce review overhead for developers deploying new applications, which is best achieved by shifting security left. Infrastructure as Code (IaC) combined with static analysis in CI/CD pipelines automatically enforces policies for transit routes, request handling, and firewall rules before deployment. This prevents configuration drift and eliminates the need for manual post-deployment reviews.

## Pregunta 17

Contexto: [topics:197](#topics-197)
An employer wants to track how bonus compensations have changed over time to identify employee outliers and correct earning disparities. This task must be performed without exposing the sensitive compensation data for any individual and must be reversible to identify the outlier.
Which Cloud Data Loss Prevention API technique should you use to accomplish this?

**A.** Generalization

**B.** Redaction

**C.** CryptoHashConfig

**D.** CryptoReplaceFfxFpeConfig

**Respuesta de la fuente:** D

**Explicación:** The requirement for reversibility rules out Generalization and Redaction, as these methods permanently lose or obscure the original specific values needed to identify individual outliers. CryptoReplaceFfxFpeConfig implements Format-Preserving Encryption (FPE), which is a deterministic encryption technique that allows authorized users with the key to decrypt (reverse) the data back to its original form for verification while keeping it secure during analysis.

## Pregunta 18

Contexto: [topics:197](#topics-197)
An organization adopts Google Cloud Platform (GCP) for application hosting services and needs guidance on setting up password requirements for their Cloud
Identity account. The organization has a password policy requirement that corporate employee passwords must have a minimum number of characters.
Which Cloud Identity password guidelines can the organization use to inform their new requirements?

**A.** Set the minimum length for passwords to be 8 characters.

**B.** Set the minimum length for passwords to be 10 characters.

**C.** Set the minimum length for passwords to be 12 characters.

**D.** Set the minimum length for passwords to be 6 characters.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Identity enforces a specific password policy where the minimum length is 8 characters and the maximum is 100.
Therefore, to meet the requirement for setting a minimum character count, the organization must configure at least 8 characters.

## Pregunta 19

Contexto: [topics:197](#topics-197)
You need to follow Google-recommended practices to leverage envelope encryption and encrypt data at the application layer.
What should you do?

**A.** Generate a data encryption key (DEK) locally to encrypt the data, and generate a new key encryption key (KEK) in Cloud KMS to encrypt the DEK. Store both the encrypted data and the encrypted DEK.

**B.** Generate a data encryption key (DEK) locally to encrypt the data, and generate a new key encryption key (KEK) in Cloud KMS to encrypt the DEK. Store both the encrypted data and the KEK.

**C.** Generate a new data encryption key (DEK) in Cloud KMS to encrypt the data, and generate a key encryption key (KEK) locally to encrypt the key. Store both the encrypted data and the encrypted DEK.

**D.** Generate a new data encryption key (DEK) in Cloud KMS to encrypt the data, and generate a key encryption key (KEK) locally to encrypt the key. Store both the encrypted data and the KEK.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud KMS envelope encryption best practices dictate generating a Data Encryption Key (DEK) locally to efficiently encrypt large volumes of application data.
The DEK is then encrypted (wrapped) by a Key Encryption Key (KEK) residing in Cloud KMS, ensuring the sensitive KEK never leaves the secure KMS environment.
You store both the encrypted data and the encrypted DEK together, allowing the application to decrypt data without handling the plaintext KEK.

## Pregunta 20

Contexto: [topics:197](#topics-197)
How should a customer reliably deliver Stackdriver logs from GCP to their on-premises SIEM system?

**A.** Send all logs to the SIEM system via an existing protocol such as syslog.

**B.** Configure every project to export all their logs to a common BigQuery DataSet, which will be queried by the SIEM system.

**C.** Configure Organizational Log Sinks to export logs to a Cloud Pub/Sub Topic, which will be sent to the SIEM via Dataflow.

**D.** Build a connector for the SIEM to query for all logs in real time from the GCP RESTful JSON APIs.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Cloud Logging cannot directly send logs to on-premises systems via protocols like syslog; it requires an intermediary.
Organizational Log Sinks allow centralized collection from multiple projects into a single Pub/Sub topic, ensuring reliability and scalability.
Dataflow provides the managed processing power to reliably transform and stream these logs from Pub/Sub to the on-premises SIEM.

## Pregunta 21

Contexto: [topics:197](#topics-197)
In order to meet PCI DSS requirements, a customer wants to ensure that all outbound traffic is authorized.
Which two cloud offerings meet this requirement without additional compensating controls? (Choose two.)

**A.** App Engine

**B.** Cloud Functions

**C.** Compute Engine

**D.** Google Kubernetes Engine

**E.** Cloud Storage

**Respuesta de la fuente:** C, D

**Explicación:** PCI DSS requires explicit authorization of all outbound (egress) traffic. App Engine traditionally lacks granular egress firewall rules without compensating controls, and Cloud Functions/Storage do not offer native VPC-style egress filtering. Compute Engine and Google Kubernetes Engine provide full VPC integration with configurable Firewall Rules that allow precise control over authorized outbound connections.

## Pregunta 22

Contexto: [topics:197](#topics-197)
A website design company recently migrated all customer sites to App Engine. Some sites are still in progress and should only be visible to customers and company employees from any location.
Which solution will restrict access to the in-progress sites?

**A.** Upload an .htaccess file containing the customer and employee user accounts to App Engine.

**B.** Create an App Engine firewall rule that allows access from the customer and employee networks and denies all other traffic.

**C.** Enable Cloud Identity-Aware Proxy (IAP), and allow access to a Google Group that contains the customer and employee user accounts.

**D.** Use Cloud VPN to create a VPN connection between the relevant on-premises networks and the company's GCP Virtual Private Cloud (VPC) network.

**Respuesta de la fuente:** C

**Explicación:** Cloud Identity-Aware Proxy (IAP) is the correct solution because it secures access to App Engine applications based on user identity rather than network location, satisfying the requirement for visibility from 'any location'.
In contrast, firewall rules and Cloud VPN rely on IP-based or network-level controls, which conflict with the need for universal geographic access, while .htaccess files are not supported on standard App Engine runtimes.

## Pregunta 23

Contexto: [topics:197](#topics-197)
When working with agents in the support center via online chat, your organization's customers often share pictures of their documents with personally identifiable information (PII). Your leadership team is concerned that this PII is being stored as part of the regular chat logs, which are reviewed by internal or external analysts for customer service trends.
You want to resolve this concern while still maintaining data utility. What should you do?

**A.** Use Cloud Key Management Service to encrypt PII shared by customers before storing it for analysis.

**B.** Use Object Lifecycle Management to make sure that all chat records containing PII are discarded and not saved for analysis.

**C.** Use the image inspection and redaction actions of the DLP API to redact PII from the images before storing them for analysis.

**D.** Use the generalization and bucketing actions of the DLP API solution to redact PII from the texts before storing them for analysis.

**Respuesta de la fuente:** C

**Explicación:** The scenario specifically involves customers sharing pictures (images) containing PII. Option C is correct because the DLP API's image inspection and redaction actions are designed to detect and mask sensitive information within image files, allowing the data to be stored for analysis while removing the PII. Option A is incorrect because encryption hides data from analysts, destroying its utility for trend analysis. Option B is incorrect because discarding records prevents any analysis. Option D is incorrect because it addresses text redaction, not image inspection.

## Pregunta 24

Contexto: [topics:197](#topics-197)
A company's application is deployed with a user-managed Service Account key. You want to use Google-recommended practices to rotate the key.
What should you do?

**A.** Open Cloud Shell and run gcloud iam service-accounts enable-auto-rotate --iam-account=IAM_ACCOUNT.

**B.** Open Cloud Shell and run gcloud iam service-accounts keys rotate --iam-account=IAM_ACCOUNT --key=NEW_KEY.

**C.** Create a new key, and use the new key in the application. Delete the old key from the Service Account.

**D.** Create a new key, and use the new key in the application. Store the old key on the system as a backup key.

**Respuesta de la fuente:** C

**Explicación:** Google recommends rotating user-managed service account keys by generating a new key, updating the application to use it, and immediately deleting the old key.
This process minimizes the window of vulnerability and reduces the risk of unauthorized access from leaked credentials.
Storing old keys as backups (Option D) is discouraged because it increases attack surface, while Options A and B reference invalid commands or incorrect procedures.

## Pregunta 25

Contexto: [topics:197](#topics-197)
Your team needs to configure their Google Cloud Platform (GCP) environment so they can centralize the control over networking resources like firewall rules, subnets, and routes. They also have an on-premises environment where resources need access back to the GCP resources through a private VPN connection.
The networking resources will need to be controlled by the network security team.
Which type of networking design should your team use to meet these requirements?

**A.** Shared VPC Network with a host project and service projects

**B.** Grant Compute Admin role to the networking team for each engineering project

**C.** VPC peering between all engineering projects using a hub and spoke model

**D.** Cloud VPN Gateway between all engineering projects using a hub and spoke model

**Respuesta de la fuente:** A

**Explicación:** Shared VPC is the correct design because it centralizes network resource management (firewalls, subnets, routes) in a dedicated host project, granting the network security team exclusive control over these assets across multiple service projects.
While Cloud VPN connects on-premises environments to GCP, Shared VPC specifically addresses the requirement for centralized governance and control of networking resources by separating network administration from compute resource management.

## Pregunta 26

Contexto: [topics:197](#topics-197)
An organization is migrating from their current on-premises productivity software systems to G Suite. Some network security controls were in place that were mandated by a regulatory body in their region for their previous on-premises system. The organization's risk team wants to ensure that network security controls are maintained and effective in G Suite. A security architect supporting this migration has been asked to ensure that network security controls are in place as part of the new shared responsibility model between the organization and Google Cloud.
What solution would help meet the requirements?

**A.** Ensure that firewall rules are in place to meet the required controls.

**B.** Set up Cloud Armor to ensure that network security controls can be managed for G Suite.

**C.** Network security is a built-in solution and Google's Cloud responsibility for SaaS products like G Suite.

**D.** Set up an array of Virtual Private Cloud (VPC) networks to control network security as mandated by the relevant regulation.

**Respuesta de la fuente:** C

**Explicación:** G Suite is a Software-as-a-Service (SaaS) offering, meaning Google assumes responsibility for the underlying infrastructure and network security.
In the shared responsibility model for SaaS, customers manage data and access controls, while Google manages the physical and network layers.
Therefore, options involving customer-managed VPCs, firewalls, or Cloud Armor are incorrect because those resources do not exist within G Suite.

## Pregunta 27

Contexto: [topics:197](#topics-197)
A customer's company has multiple business units. Each business unit operates independently, and each has their own engineering group. Your team wants visibility into all projects created within the company and wants to organize their Google Cloud Platform (GCP) projects based on different business units. Each business unit also requires separate sets of IAM permissions.
Which strategy should you use to meet these needs?

**A.** Create an organization node, and assign folders for each business unit.

**B.** Establish standalone projects for each business unit, using gmail.com accounts.

**C.** Assign GCP resources in a project, with a label identifying which business unit owns the resource.

**D.** Assign GCP resources in a VPC for each business unit to separate network access.

**Respuesta de la fuente:** A

**Explicación:** Using folders within an organization node is the recommended best practice for structuring resources by business unit, as it allows you to group projects logically.
Folders enable centralized management of IAM policies, ensuring that specific permissions can be applied uniformly across all projects within a particular business unit.

## Pregunta 28

Contexto: [topics:197](#topics-197)
A company has redundant mail servers in different Google Cloud Platform regions and wants to route customers to the nearest mail server based on location.
How should the company accomplish this?

**A.** Configure TCP Proxy Load Balancing as a global load balancing service listening on port 995.

**B.** Create a Network Load Balancer to listen on TCP port 995 with a forwarding rule to forward traffic based on location.

**C.** Use Cross-Region Load Balancing with an HTTP(S) load balancer to route traffic to the nearest region.

**D.** Use Cloud CDN to route the mail traffic to the closest origin mail server based on client IP address.

**Respuesta de la fuente:** A

**Explicación:** TCP Proxy Load Balancing is a global external load balancing service in GCP that routes traffic to the nearest backend region with available capacity.
It operates at Layer 4, making it suitable for TCP-based protocols like mail (IMAP/POP3 on port 995) which do not use HTTP(S).
Network Load Balancers are regional by default and cannot natively perform global location-based routing across regions without additional complex configuration.

## Pregunta 29

Contexto: [topics:197](#topics-197)
Your team sets up a Shared VPC Network where project co-vpc-prod is the host project. Your team has configured the firewall rules, subnets, and VPN gateway on the host project. They need to enable Engineering Group A to attach a Compute Engine instance to only the 10.1.1.0/24 subnet.
What should your team grant to Engineering Group A to meet this requirement?

**A.** Compute Network User Role at the host project level.

**B.** Compute Network User Role at the subnet level.

**C.** Compute Shared VPC Admin Role at the host project level.

**D.** Compute Shared VPC Admin Role at the service project level.

**Respuesta de la fuente:** B

**Explicación:** To adhere to the principle of least privilege and restrict access to a specific subnet, the Compute Network User role must be granted at the resource level (the subnet) rather than the project level. Granting this role at the host project level (Option A) would provide access to all subnets in the Shared VPC, violating the requirement for isolation.

## Pregunta 30

Contexto: [topics:197](#topics-197)
A company migrated their entire data/center to Google Cloud Platform. It is running thousands of instances across multiple projects managed by different departments. You want to have a historical record of what was running in Google Cloud Platform at any point in time.
What should you do?

**A.** Use Resource Manager on the organization level.

**B.** Use Forseti Security to automate inventory snapshots.

**C.** Use Stackdriver to create a dashboard across all projects.

**D.** Use Security Command Center to view all assets across the organization.

**Respuesta de la fuente:** D

**Explicación:** Google Cloud Asset Inventory (accessible via the Security Command Center interface) is the native service designed to track and audit asset history and configuration changes across an organization.
It provides historical records of assets, including deleted or modified resources, meeting the requirement for a point-in-time view.
While Forseti (Option B) offered similar capabilities in the past, it has been deprecated in favor of native Cloud services like Security Command Center/Asset Inventory.

## Pregunta 31

Contexto: [topics:197](#topics-197)
An organization is starting to move its infrastructure from its on-premises environment to Google Cloud Platform (GCP). The first step the organization wants to take is to migrate its current data backup and disaster recovery solutions to GCP for later analysis. The organization's production environment will remain on- premises for an indefinite time. The organization wants a scalable and cost-efficient solution.
Which GCP solution should the organization use?

**A.** BigQuery using a data pipeline job with continuous updates

**B.** Cloud Storage using a scheduled task and gsutil

**C.** Compute Engine Virtual Machines using Persistent Disk

**D.** Cloud Datastore using regularly scheduled batch upload jobs

**Respuesta de la fuente:** B

**Explicación:** Cloud Storage is the optimal choice for scalable and cost-efficient backup and disaster recovery because it offers durable object storage with tiered pricing models suited for archival data.
Using `gsutil` with a scheduled task allows for automated, reliable transfer of backup files from on-premises to GCP without requiring persistent compute resources like BigQuery or Compute Engine.

## Pregunta 32

Contexto: [topics:197](#topics-197)
You are creating an internal App Engine application that needs to access a user's Google Drive on the user's behalf. Your company does not want to rely on the current user's credentials. It also wants to follow Google-recommended practices.
What should you do?

**A.** Create a new Service account, and give all application users the role of Service Account User.

**B.** Create a new Service account, and add all application users to a Google Group. Give this group the role of Service Account User.

**C.** Use a dedicated G Suite Admin account, and authenticate the application's operations with these G Suite credentials.

**D.** Create a new service account, and grant it G Suite domain-wide delegation. Have the application use it to impersonate the user.

**Respuesta de la fuente:** D

**Explicación:** The requirement to access Google Drive on a user's behalf without using the user's credentials necessitates domain-wide delegation.
Option D correctly configures a service account to impersonate specific users, allowing the application to act as the user while using the service account's identity for authentication.
Options A and B incorrectly suggest Service Account User roles, which allow humans to use service accounts, not vice versa.
Option C violates best practices by relying on shared admin credentials rather than secure, auditable service account impersonation.

## Pregunta 33

Contexto: [topics:197](#topics-197)
A customer wants to move their sensitive workloads to a Compute Engine-based cluster using Managed Instance Groups (MIGs). The jobs are bursty and must be completed quickly. They have a requirement to be able to control the key lifecycle.
Which boot disk encryption solution should you use on the cluster to meet this customer's requirements?

**A.** Customer-supplied encryption keys (CSEK)

**B.** Customer-managed encryption keys (CMEK) using Cloud Key Management Service (KMS)

**C.** Encryption by default

**D.** Pre-encrypting files before transferring to Google Cloud Platform (GCP) for analysis

**Respuesta de la fuente:** B

**Explicación:** The customer's requirement to control the key lifecycle specifically points to Customer-Managed Encryption Keys (CMEK) using Cloud KMS, which allows users to manage key rotation, versioning, and access policies. While CSEK provides some control, it requires manual key handling for every API call and lacks the integrated lifecycle management features of Cloud KMS. Default encryption does not provide customer control over keys, and pre-encrypting files is an application-layer solution that does not address boot disk encryption requirements.

## Pregunta 34

Contexto: [topics:197](#topics-197)
Your company is using Cloud Dataproc for its Spark and Hadoop jobs. You want to be able to create, rotate, and destroy symmetric encryption keys used for the persistent disks used by Cloud Dataproc. Keys can be stored in the cloud.
What should you do?

**A.** Use the Cloud Key Management Service to manage the data encryption key (DEK).

**B.** Use the Cloud Key Management Service to manage the key encryption key (KEK).

**C.** Use customer-supplied encryption keys to manage the data encryption key (DEK).

**D.** Use customer-supplied encryption keys to manage the key encryption key (KEK).

**Respuesta de la fuente:** B

**Explicación:** Cloud Dataproc uses envelope encryption for persistent disks, where Google manages the Data Encryption Key (DEK) for performance and automation.
Customer-Managed Encryption Keys (CMEK) allow you to manage the Key Encryption Key (KEK) via Cloud KMS to control access without managing DEKs directly.
Therefore, using Cloud KMS to manage the KEK satisfies the requirement to create, rotate, and destroy keys for Dataproc persistent disks.

## Pregunta 35

Contexto: [topics:197](#topics-197)
You are a member of the security team at an organization. Your team has a single GCP project with credit card payment processing systems alongside web applications and data processing systems. You want to reduce the scope of systems subject to PCI audit standards.
What should you do?

**A.** Use multi-factor authentication for admin access to the web application.

**B.** Use only applications certified compliant with PA-DSS.

**C.** Move the cardholder data environment into a separate GCP project.

**D.** Use VPN for all connections between your office and cloud environments.

**Respuesta de la fuente:** C

**Explicación:** PCI DSS requires strict segmentation to minimize the scope of the Cardholder Data Environment (CDE). In Google Cloud Platform, projects serve as fundamental units of isolation; moving CDE components into a separate project ensures they are logically separated from non-compliant workloads like web apps and data processing systems. This architectural separation reduces the number of systems subject to audit requirements.

## Pregunta 36

Contexto: [topics:197](#topics-197)
A retail customer allows users to upload comments and product reviews. The customer needs to make sure the text does not include sensitive data before the comments or reviews are published.
Which Google Cloud Service should be used to achieve this?

**A.** Cloud Key Management Service

**B.** Cloud Data Loss Prevention API

**C.** BigQuery

**D.** Web Security Scanner

**Respuesta de la fuente:** B

**Explicación:** Cloud Data Loss Prevention (DLP) API is specifically designed to detect and redact sensitive information such as personal identifiable information (PII) from unstructured text data like comments and reviews. It allows you to inspect content for predefined sensitive data types before publication, whereas the other options focus on key management, analytics, or security vulnerability scanning.

## Pregunta 37

Contexto: [topics:197](#topics-197)
A company allows every employee to use Google Cloud Platform. Each department has a Google Group, with all department members as group members. If a department member creates a new project, all members of that department should automatically have read-only access to all new project resources. Members of any other department should not have access to the project. You need to configure this behavior.
What should you do to meet these requirements?

**A.** Create a Folder per department under the Organization. For each department's Folder, assign the Project Viewer role to the Google Group related to that department.

**B.** Create a Folder per department under the Organization. For each department's Folder, assign the Project Browser role to the Google Group related to that department.

**C.** Create a Project per department under the Organization. For each department's Project, assign the Project Viewer role to the Google Group related to that department.

**D.** Create a Project per department under the Organization. For each department's Project, assign the Project Browser role to the Google Group related to that department.

**Respuesta de la fuente:** A

**Explicación:** To ensure automatic permissions for new resources, IAM bindings must be assigned at the Folder level, as projects inherit access from their parent folder.
Assigning these roles directly to projects (Options C and D) would require manual updates for every new project, failing the automation requirement.
The Project Viewer role provides read-only access to view resources within a project, whereas the Project Browser role only allows viewing the project hierarchy and metadata, not the actual resources.

## Pregunta 38

Contexto: [topics:197](#topics-197)
A customer's internal security team must manage its own encryption keys for encrypting data on Cloud Storage and decides to use customer-supplied encryption keys (CSEK).
How should the team complete this task?

**A.** Upload the encryption key to a Cloud Storage bucket, and then upload the object to the same bucket.

**B.** Use the gsutil command line tool to upload the object to Cloud Storage, and specify the location of the encryption key.

**C.** Generate an encryption key in the Google Cloud Platform Console, and upload an object to Cloud Storage using the specified key.

**D.** Encrypt the object, then use the gsutil command line tool or the Google Cloud Platform Console to upload the object to Cloud Storage.

**Respuesta de la fuente:** B

**Explicación:** Customer-Supplied Encryption Keys (CSEK) for Google Cloud Storage are not supported via the Google Cloud Console UI; they must be provided programmatically or via command-line tools like gsutil.

Option B correctly identifies using gsutil to upload an object while specifying the encryption key, which is the standard method for applying CSEK during the upload process.

Options involving the Console (C) or pre-encrypting locally without passing the key metadata to GCS (D) do not align with how GCS implements server-side CSEK.

## Pregunta 39

Contexto: [topics:197](#topics-197)
A customer has 300 engineers. The company wants to grant different levels of access and efficiently manage IAM permissions between users in the development and production environment projects.
Which two steps should the company take to meet these requirements? (Choose two.)

**A.** Create a project with multiple VPC networks for each environment.

**B.** Create a folder for each development and production environment.

**C.** Create a Google Group for the Engineering team, and assign permissions at the folder level.

**D.** Create an Organizational Policy constraint for each folder environment.

**E.** Create projects for each environment, and grant IAM rights to each engineering user.

**Respuesta de la fuente:** B, C

**Explicación:** Creating folders for each environment (B) provides the necessary structural hierarchy to separate development and production resources logically.
Assigning permissions at the folder level via a Google Group (C) allows you to grant different access levels to dev and prod environments efficiently, while using groups ensures that IAM management remains scalable for 300 users.

## Pregunta 40

Contexto: [topics:197](#topics-197)
You want to evaluate your organization's Google Cloud instance for PCI compliance. You need to identify Google's inherent controls.
Which document should you review to find the information?

**A.** Google Cloud Platform: Customer Responsibility Matrix

**B.** PCI DSS Requirements and Security Assessment Procedures

**C.** PCI SSC Cloud Computing Guidelines

**D.** Product documentation for Compute Engine

**Respuesta de la fuente:** A

**Explicación:** The Google Cloud Platform Customer Responsibility Matrix explicitly delineates the shared responsibility model between Google and its customers.
It details which security controls are inherent to Google's infrastructure (managed by Google) and which are the customer's responsibility, making it the correct document for identifying Google's inherent controls.

## Pregunta 41

Contexto: [topics:197](#topics-197)
Your company runs a website that will store PII on Google Cloud Platform. To comply with data privacy regulations, this data can only be stored for a specific amount of time and must be fully deleted after this specific period. Data that has not yet reached the time period should not be deleted. You want to automate the process of complying with this regulation.
What should you do?

**A.** Store the data in a single Persistent Disk, and delete the disk at expiration time.

**B.** Store the data in a single BigQuery table and set the appropriate table expiration time.

**C.** Store the data in a single Cloud Storage bucket and configure the bucket's Time to Live.

**D.** Store the data in a single BigTable table and set an expiration time on the column families.

**Respuesta de la fuente:** C

**Explicación:** Cloud Storage Object Lifecycle Management allows you to define rules that automatically delete objects based on their age or creation date, which directly addresses the requirement to expire PII data after a specific period. This ensures individual records are removed automatically without manual intervention while leaving newer data intact.

## Pregunta 42

Contexto: [topics:197](#topics-197)
A DevOps team will create a new container to run on Google Kubernetes Engine. As the application will be internet-facing, they want to minimize the attack surface of the container.
What should they do?

**A.** Use Cloud Build to build the container images.

**B.** Build small containers using small base images.

**C.** Delete non-used versions from Container Registry.

**D.** Use a Continuous Delivery tool to deploy the application.

**Respuesta de la fuente:** B

**Explicación:** Using small base images (like distroless or Alpine) minimizes the number of installed packages and utilities within the container. This reduction directly shrinks the attack surface by removing potential vulnerabilities associated with unnecessary software components. Options A, C, and D relate to build processes or registry hygiene but do not inherently reduce the runtime exposure of the active container.

## Pregunta 43

Contexto: [topics:197](#topics-197)
While migrating your organization's infrastructure to GCP, a large number of users will need to access GCP Console. The Identity Management team already has a well-established way to manage your users and want to keep using your existing Active Directory or LDAP server along with the existing SSO password.
What should you do?

**A.** Manually synchronize the data in Google domain with your existing Active Directory or LDAP server.

**B.** Use Google Cloud Directory Sync to synchronize the data in Google domain with your existing Active Directory or LDAP server.

**C.** Users sign in directly to the GCP Console using the credentials from your on-premises Kerberos compliant identity provider.

**D.** Users sign in using OpenID (OIDC) compatible IdP, receive an authentication token, then use that token to log in to the GCP Console.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Directory Sync (GCDS) is the prescribed tool to synchronize user data from an existing Active Directory or LDAP source into the Google Cloud Identity domain, which is a prerequisite for configuring Single Sign-On (SSO).
While Option D correctly describes the OIDC authentication flow used for SSO, it addresses the login method rather than the necessary directory synchronization step required to map existing identity providers to GCP.
Manually syncing data (Option A) is not scalable or secure for a large user base, and direct Kerberos sign-in (Option C) is not supported for GCP Console access.

## Pregunta 44

Contexto: [topics:197](#topics-197)
Your company is using GSuite and has developed an application meant for internal usage on Google App Engine. You need to make sure that an external user cannot gain access to the application even when an employee's password has been compromised.
What should you do?

**A.** Enforce 2-factor authentication in GSuite for all users.

**B.** Configure Cloud Identity-Aware Proxy for the App Engine Application.

**C.** Provision user passwords using GSuite Password Sync.

**D.** Configure Cloud VPN between your private network and GCP.

**Respuesta de la fuente:** B

**Explicación:** Cloud Identity-Aware Proxy (IAP) is the correct solution because it enforces fine-grained, identity-based access controls that can restrict application access to specific users or groups regardless of their location, preventing external users from accessing the app even with compromised credentials.
While 2-factor authentication (Option A) protects against password theft at the login stage, IAP provides an additional layer of security by verifying authorization policies specific to the application resource, which is the most robust method for securing internal applications on App Engine.

## Pregunta 45

Contexto: [topics:197](#topics-197)
A large financial institution is moving its Big Data analytics to Google Cloud Platform. They want to have maximum control over the encryption process of data stored at rest in BigQuery.
What technique should the institution use?

**A.** Use Cloud Storage as a federated Data Source.

**B.** Use a Cloud Hardware Security Module (Cloud HSM).

**C.** Customer-managed encryption keys (CMEK).

**D.** Customer-supplied encryption keys (CSEK).

**Respuesta de la fuente:** C

**Explicación:** Customer-managed encryption keys (CMEK) allow organizations to generate and manage the master encryption keys used by BigQuery while Google handles key storage in Cloud KMS.

This provides maximum control over key lifecycle management, including rotation and revocation, satisfying the requirement for data stored at rest in BigQuery.

Customer-supplied encryption keys (CSEK) are not supported by BigQuery, making them an invalid option.

## Pregunta 46

Contexto: [topics:197](#topics-197)
A company is deploying their application on Google Cloud Platform. Company policy requires long-term data to be stored using a solution that can automatically replicate data over at least two geographic places.
Which Storage solution are they allowed to use?

**A.** Cloud Bigtable

**B.** Cloud BigQuery

**C.** Compute Engine SSD Disk

**D.** Compute Engine Persistent Disk

**Respuesta de la fuente:** B

**Explicación:** Cloud BigQuery automatically replicates data across multiple zones within a region and provides multi-regional storage options that ensure high durability and availability without manual setup.
In contrast, Cloud Bigtable requires manual configuration to set up replication between clusters or regions, making it an incorrect choice for a solution that 'automatically' handles this.
Compute Engine disks are local to specific zones and do not offer automatic geographic replication.

## Pregunta 47

Contexto: [topics:197](#topics-197)
A large e-retailer is moving to Google Cloud Platform with its ecommerce website. The company wants to ensure payment information is encrypted between the customer's browser and GCP when the customers checkout online.
What should they do?

**A.** Configure an SSL Certificate on an L7 Load Balancer and require encryption.

**B.** Configure an SSL Certificate on a Network TCP Load Balancer and require encryption.

**C.** Configure the firewall to allow inbound traffic on port 443, and block all other inbound traffic.

**D.** Configure the firewall to allow outbound traffic on port 443, and block all other outbound traffic.

**Respuesta de la fuente:** A

**Explicación:** HTTP(S) traffic is handled at Layer 7 (Application Layer), making the L7 Load Balancer the appropriate choice for managing web requests. To encrypt payment information between the browser and GCP, an SSL certificate must be configured on this load balancer to terminate HTTPS connections securely.
Network (Layer 4) load balancers do not handle SSL termination in the same application-aware manner required here, while firewall rules alone do not provide encryption capabilities.

## Pregunta 48

Contexto: [topics:197](#topics-197)
Applications often require access to `secrets` - small pieces of sensitive data at build or run time. The administrator managing these secrets on GCP wants to keep a track of `who did what, where, and when?` within their GCP projects.
Which two log streams would provide the information that the administrator is looking for? (Choose two.)

**A.** Admin Activity logs

**B.** System Event logs

**C.** Data Access logs

**D.** VPC Flow logs

**E.** Agent logs

**Respuesta de la fuente:** A, C

**Explicación:** Admin Activity logs (A) record control plane operations such as the creation, update, or deletion of Secret Manager resources, capturing administrative actions.
Data Access logs (C) record data plane operations like accessing the secret values themselves.
Together, these audit log types provide comprehensive tracking of who performed which action on secrets and when.

## Pregunta 49

Contexto: [topics:197](#topics-197)
You are in charge of migrating a legacy application from your company datacenters to GCP before the current maintenance contract expires. You do not know what ports the application is using and no documentation is available for you to check. You want to complete the migration without putting your environment at risk.
What should you do?

**A.** Migrate the application into an isolated project using a "Lift & Shift" approach. Enable all internal TCP traffic using VPC Firewall rules. Use VPC Flow logs to determine what traffic should be allowed for the application to work properly.

**B.** Migrate the application into an isolated project using a "Lift & Shift" approach in a custom network. Disable all traffic within the VPC and look at the Firewall logs to determine what traffic should be allowed for the application to work properly.

**C.** Refactor the application into a micro-services architecture in a GKE cluster. Disable all traffic from outside the cluster using Firewall Rules. Use VPC Flow logs to determine what traffic should be allowed for the application to work properly.

**D.** Refactor the application into a micro-services architecture hosted in Cloud Functions in an isolated project. Disable all traffic from outside your project using Firewall Rules. Use VPC Flow logs to determine what traffic should be allowed for the application to work properly.

**Respuesta de la fuente:** A

**Explicación:** A 'Lift & Shift' approach is required to meet the migration deadline without refactoring costs. To discover unknown ports while minimizing risk, migrating to an isolated project ensures containment.

Enabling all internal TCP traffic allows the application to function initially, and VPC Flow Logs provide the necessary data to identify actual traffic patterns for subsequent firewall hardening.

## Pregunta 50

Contexto: [topics:197](#topics-197)
Your company has deployed an application on Compute Engine. The application is accessible by clients on port 587. You need to balance the load between the different instances running the application. The connection should be secured using TLS, and terminated by the Load Balancer.
What type of Load Balancing should you use?

**A.** Network Load Balancing

**B.** HTTP(S) Load Balancing

**C.** TCP Proxy Load Balancing

**D.** SSL Proxy Load Balancing

**Respuesta de la fuente:** D

**Explicación:** SSL Proxy Load Balancing is the correct choice because it is specifically designed for SSL/TLS termination at the load balancer layer.

Unlike TCP Proxy or Network Load Balancers, which pass through encrypted traffic without terminating TLS, SSL Proxy offloads SSL/TLS processing before forwarding traffic to backend instances.

## Pregunta 51

Contexto: [topics:197](#topics-197)
You want to limit the images that can be used as the source for boot disks. These images will be stored in a dedicated project.
What should you do?

**A.** Use the Organization Policy Service to create a compute.trustedimageProjects constraint on the organization level. List the trusted project as the whitelist in an allow operation.

**B.** Use the Organization Policy Service to create a compute.trustedimageProjects constraint on the organization level. List the trusted projects as the exceptions in a deny operation.

**C.** In Resource Manager, edit the project permissions for the trusted project. Add the organization as member with the role: Compute Image User.

**D.** In Resource Manager, edit the organization permissions. Add the project ID as member with the role: Compute Image User.

**Respuesta de la fuente:** A

**Explicación:** The `compute.trustedImageProjects` Organization Policy constraint enforces image restrictions by specifying a list of allowed project IDs. To limit sources to a dedicated project, you must configure the policy with an 'allow' rule that explicitly whitelists that specific project ID.
This ensures that boot disks can only be created from images within the designated trusted project, overriding the default behavior where any accessible image is permitted.

## Pregunta 52

Contexto: [topics:197](#topics-197)
Your team needs to prevent users from creating projects in the organization. Only the DevOps team should be allowed to create projects on behalf of the requester.
Which two tasks should your team perform to handle this request? (Choose two.)

**A.** Remove all users from the Project Creator role at the organizational level.

**B.** Create an Organization Policy constraint, and apply it at the organizational level.

**C.** Grant the Project Editor role at the organizational level to a designated group of users.

**D.** Add a designated group of users to the Project Creator role at the organizational level.

**E.** Grant the billing account creator role to the designated DevOps team.

**Respuesta de la fuente:** A, D

**Explicación:** To restrict project creation to a specific team, you must first remove the Project Creator role from all general users at the organizational level (A).
Then, explicitly grant the Project Creator role only to the designated DevOps group (D).
This ensures least-privilege access by revoking default permissions and granting them selectively.

## Pregunta 53

Contexto: [topics:197](#topics-197)
A customer deployed an application on Compute Engine that takes advantage of the elastic nature of cloud computing.
How can you work with Infrastructure Operations Engineers to best ensure that Windows Compute Engine VMs are up to date with all the latest OS patches?

**A.** Build new base images when patches are available, and use a CI/CD pipeline to rebuild VMs, deploying incrementally.

**B.** Federate a Domain Controller into Compute Engine, and roll out weekly patches via Group Policy Object.

**C.** Use Deployment Manager to provision updated VMs into new serving Instance Groups (IGs).

**D.** Reboot all VMs during the weekly maintenance window and allow the StartUp Script to download the latest patches from the internet.

**Respuesta de la fuente:** A

**Explicación:** The recommended cloud-native approach for patching managed instances is the 'golden image' strategy: create a new base image with the latest patches applied and use CI/CD to incrementally replace old VMs with new ones built from this image.

This method avoids the risks and downtime associated with patching running production instances or relying on startup scripts, ensuring consistency and leveraging Compute Engine's elastic nature.

## Pregunta 54

Contexto: [topics:197](#topics-197)
Your team needs to make sure that their backend database can only be accessed by the frontend application and no other instances on the network.
How should your team design this network?

**A.** Create an ingress firewall rule to allow access only from the application to the database using firewall tags.

**B.** Create a different subnet for the frontend application and database to ensure network isolation.

**C.** Create two VPC networks, and connect the two networks using Cloud VPN gateways to ensure network isolation.

**D.** Create two VPC networks, and connect the two networks using VPC peering to ensure network isolation.

**Respuesta de la fuente:** A

**Explicación:** In Google Cloud VPC, default firewall rules deny all ingress traffic to instances. To allow the frontend application to access the backend database while blocking other network instances, you must create an explicit ingress rule. Using network tags (referred to as firewall tags in the option) allows you to precisely target the source (frontend) and destination (database) for this allowed traffic. Options B, C, and D rely on network topology or isolation strategies that do not inherently restrict access between specific VMs without additional firewall configurations.

## Pregunta 55

Contexto: [topics:197](#topics-197)
An organization receives an increasing number of phishing emails.
Which method should be used to protect employee credentials in this situation?

**A.** Multifactor Authentication

**B.** A strict password policy

**C.** Captcha on login pages

**D.** Encrypted emails

**Respuesta de la fuente:** A

**Explicación:** Multifactor Authentication (MFA) protects credentials by requiring a second verification step, ensuring that stolen passwords alone are insufficient for unauthorized access.
This directly mitigates the risk of phishing attacks where attackers harvest login credentials.
Other options like password policies or encryption do not prevent unauthorized access if credentials are compromised.

## Pregunta 56

Contexto: [topics:197](#topics-197)
A customer is collaborating with another company to build an application on Compute Engine. The customer is building the application tier in their GCP
Organization, and the other company is building the storage tier in a different GCP Organization. This is a 3-tier web application. Communication between portions of the application must not traverse the public internet by any means.
Which connectivity option should be implemented?

**A.** VPC peering

**B.** Cloud VPN

**C.** Cloud Interconnect

**D.** Shared VPC

**Respuesta de la fuente:** A

**Explicación:** VPC peering is the correct choice because it establishes a direct, private network connection between two VPCs without traversing the public internet, satisfying the security requirement. Unlike Shared VPC, which requires resources to reside within the same GCP organization or authorized host project, VPC peering supports connectivity across different GCP organizations. Cloud VPN and Cloud Interconnect are unnecessary overheads here since both environments are already hosted on Compute Engine within Google's infrastructure.

## Pregunta 57

Contexto: [topics:197](#topics-197)
Your team wants to make sure Compute Engine instances running in your production project do not have public IP addresses. The frontend application Compute
Engine instances will require public IPs. The product engineers have the Editor role to modify resources. Your team wants to enforce this requirement.
How should your team meet these requirements?

**A.** Enable Private Access on the VPC network in the production project.

**B.** Remove the Editor role and grant the Compute Admin IAM role to the engineers.

**C.** Set up an organization policy to only permit public IPs for the front-end Compute Engine instances.

**D.** Set up a VPC network with two subnets: one with public IPs and one without public IPs.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because the `compute.vmExternalIpAccess` Organization Policy constraint allows you to define a whitelist of specific Compute Engine instances permitted to use external IP addresses. By explicitly listing only the frontend instances in this allowed list, all other production instances are automatically denied public IPs, satisfying the security requirement regardless of user roles or subnet configurations.

## Pregunta 58

Contexto: [topics:197](#topics-197)
Which two security characteristics are related to the use of VPC peering to connect two VPC networks? (Choose two.)

**A.** Central management of routes, firewalls, and VPNs for peered networks

**B.** Non-transitive peered networks; where only directly peered networks can communicate

**C.** Ability to peer networks that belong to different Google Cloud organizations

**D.** Firewall rules that can be created with a tag from one peered network to another peered network

**E.** Ability to share specific subnets across peered networks

**Respuesta de la fuente:** B, C

**Explicación:** VPC peering is non-transitive, meaning connectivity is limited to directly peered networks, which restricts lateral movement and enhances security isolation (Option B).
Additionally, VPC peering allows connections between networks in different Google Cloud organizations, enabling private service sharing across organizational boundaries without exposing traffic to the public internet (Option C).
Options A, D, and E are incorrect because VPC peering does not support central management of firewall rules across networks, network tags do not work across peered VPCs for firewall matching, and subnets cannot be shared between VPCs.

## Pregunta 59

Contexto: [topics:197](#topics-197)
A patch for a vulnerability has been released, and a DevOps team needs to update their running containers in Google Kubernetes Engine (GKE).
How should the DevOps team accomplish this?

**A.** Use Puppet or Chef to push out the patch to the running container.

**B.** Verify that auto upgrade is enabled; if so, Google will upgrade the nodes in a GKE cluster.

**C.** Update the application code or apply a patch, build a new image, and redeploy it.

**D.** Configure containers to automatically upgrade when the base image is available in Container Registry.

**Respuesta de la fuente:** C

**Explicación:** Containers are designed to be immutable, meaning they should not be modified in place using configuration management tools like Puppet or Chef.
To patch a vulnerability within an application or its base OS inside a container, the team must update the source code or dependencies, build a new container image containing the fix, and deploy this new image to replace the running containers.

## Pregunta 60

Contexto: [topics:197](#topics-197)
A company is running their webshop on Google Kubernetes Engine and wants to analyze customer transactions in BigQuery. You need to ensure that no credit card numbers are stored in BigQuery
What should you do?

**A.** Create a BigQuery view with regular expressions matching credit card numbers to query and delete affected rows.

**B.** Use the Cloud Data Loss Prevention API to redact related infoTypes before data is ingested into BigQuery.

**C.** Leverage Security Command Center to scan for the assets of type Credit Card Number in BigQuery.

**D.** Enable Cloud Identity-Aware Proxy to filter out credit card numbers before storing the logs in BigQuery.

**Respuesta de la fuente:** B

**Explicación:** The Cloud Data Loss Prevention (DLP) API is designed to identify and redact sensitive information, such as credit card numbers, before it enters storage systems like BigQuery.
This preventative approach ensures compliance by stopping data exfiltration at the source rather than relying on reactive scanning or deletion after the fact.

## Pregunta 61

Contexto: [topics:197](#topics-197)
A customer wants to deploy a large number of 3-tier web applications on Compute Engine.
How should the customer ensure authenticated network separation between the different tiers of the application?

**A.** Run each tier in its own Project, and segregate using Project labels.

**B.** Run each tier with a different Service Account (SA), and use SA-based firewall rules.

**C.** Run each tier in its own subnet, and use subnet-based firewall rules.

**D.** Run each tier with its own VM tags, and use tag-based firewall rules.

**Respuesta de la fuente:** B

**Explicación:** The keyword 'authenticated' points to using Identity and Access Management (IAM) credentials rather than simple network attributes like tags or subnets. Google Cloud best practices recommend isolating VMs with distinct Service Accounts because they are access-controlled, whereas target tags can be modified by anyone with the instanceAdmin role without explicit authorization changes.

## Pregunta 62

Contexto: [topics:197](#topics-197)
A manager wants to start retaining security event logs for 2 years while minimizing costs. You write a filter to select the appropriate log entries.
Where should you export the logs?

**A.** BigQuery datasets

**B.** Cloud Storage buckets

**C.** StackDriver logging

**D.** Cloud Pub/Sub topics

**Respuesta de la fuente:** B

**Explicación:** Cloud Logging has a default retention period of 30 days (or up to 400 days with the Advanced plan), making it unsuitable for mandatory 2-year retention without significant cost.
Cloud Storage offers significantly lower storage costs, especially when using Nearline, Coldline, or Archive classes for long-term data retention, aligning with the goal of minimizing costs.

## Pregunta 63

Contexto: [topics:197](#topics-197)
For compliance reasons, an organization needs to ensure that in-scope PCI Kubernetes Pods reside on `in-scope` Nodes only. These Nodes can only contain the
`in-scope` Pods.
How should the organization achieve this objective?

**A.** Add a nodeSelector field to the pod configuration to only use the Nodes labeled inscope: true.

**B.** Create a node pool with the label inscope: true and a Pod Security Policy that only allows the Pods to run on Nodes with that label.

**C.** Place a taint on the Nodes with the label inscope: true and effect NoSchedule and a toleration to match in the Pod configuration.

**D.** Run all in-scope Pods in the namespace "in-scope-pci".

**Respuesta de la fuente:** C

**Explicación:** The requirement is bidirectional: ensure in-scope pods run only on in-scope nodes AND that in-scope nodes run ONLY in-scope pods.

- **NodeSelector (A)** ensures in-scope pods land on labeled nodes, but it does not prevent other non-labeled pods from being scheduled on those same nodes if no other constraints exist. It fails the "Nodes can only contain in-scope Pods" part of the requirement.
- **Taints and Tolerations (C)** are the correct mechanism for this. By applying a taint with `effect: NoSchedule` to the in-scope nodes, Kubernetes prevents any pod without a matching toleration from being scheduled there. This guarantees that only pods explicitly configured with the matching toleration (the in-scope PCI pods) can reside on those nodes, satisfying both conditions of the requirement.

## Pregunta 64

Contexto: [topics:197](#topics-197)
In an effort for your company messaging app to comply with FIPS 140-2, a decision was made to use GCP compute and network services. The messaging app architecture includes a Managed Instance Group (MIG) that controls a cluster of Compute Engine instances. The instances use Local SSDs for data caching and
UDP for instance-to-instance communications. The app development team is willing to make any changes necessary to comply with the standard
Which options should you recommend to meet the requirements?

**A.** Encrypt all cache storage and VM-to-VM communication using the BoringCrypto module.

**B.** Set Disk Encryption on the Instance Template used by the MIG to customer-managed key and use BoringSSL for all data transit between instances.

**C.** Change the app instance-to-instance communications from UDP to TCP and enable BoringSSL on clients' TLS connections.

**D.** Set Disk Encryption on the Instance Template used by the MIG to Google-managed Key and use BoringSSL library on all instance-to-instance communications.

**Respuesta de la fuente:** A

**Explicación:** To comply with FIPS 140-2 on Local SSDs, GCP documentation requires customers to provide their own encryption using a FIPS-validated cryptographic module because GCP's automatic encryption for this specific storage type lacks FIPS validation.
Option A correctly identifies the BoringCrypto module (part of BoringSSL) as the FIPS 140-2 validated solution for both encrypting the local cache storage and securing VM-to-VM communications.

## Pregunta 65

Contexto: [topics:197](#topics-197)
A customer has an analytics workload running on Compute Engine that should have limited internet access.
Your team created an egress firewall rule to deny (priority 1000) all traffic to the internet.
The Compute Engine instances now need to reach out to the public repository to get security updates.
What should your team do?

**A.** Create an egress firewall rule to allow traffic to the CIDR range of the repository with a priority greater than 1000.

**B.** Create an egress firewall rule to allow traffic to the CIDR range of the repository with a priority less than 1000.

**C.** Create an egress firewall rule to allow traffic to the hostname of the repository with a priority greater than 1000.

**D.** Create an egress firewall rule to allow traffic to the hostname of the repository with a priority less than 1000.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Firewall rules evaluate traffic based on priority, where lower integer values indicate higher priority. To override the existing deny rule (priority 1000), the new allow rule must have a priority less than 1000.
Additionally, firewall rules require destination addresses to be specified as IP ranges in CIDR notation; hostnames are not supported.

## Pregunta 66

Contexto: [topics:197](#topics-197)
You want data on Compute Engine disks to be encrypted at rest with keys managed by Cloud Key Management Service (KMS). Cloud Identity and Access
Management (IAM) permissions to these keys must be managed in a grouped way because the permissions should be the same for all keys.
What should you do?

**A.** Create a single KeyRing for all persistent disks and all Keys in this KeyRing. Manage the IAM permissions at the Key level.

**B.** Create a single KeyRing for all persistent disks and all Keys in this KeyRing. Manage the IAM permissions at the KeyRing level.

**C.** Create a KeyRing per persistent disk, with each KeyRing containing a single Key. Manage the IAM permissions at the Key level.

**D.** Create a KeyRing per persistent disk, with each KeyRing containing a single Key. Manage the IAM permissions at the KeyRing level.

**Respuesta de la fuente:** B

**Explicación:** Creating a single KeyRing consolidates all encryption keys into one logical container. Managing IAM permissions at the KeyRing level ensures that these permissions are inherited by all contained keys, efficiently satisfying the requirement for grouped permission management with identical access controls.

## Pregunta 67

Contexto: [topics:197](#topics-197)
A company is backing up application logs to a Cloud Storage bucket shared with both analysts and the administrator. Analysts should only have access to logs that do not contain any personally identifiable information (PII). Log files containing PII should be stored in another bucket that is only accessible by the administrator.
What should you do?

**A.** Use Cloud Pub/Sub and Cloud Functions to trigger a Data Loss Prevention scan every time a file is uploaded to the shared bucket. If the scan detects PII, have the function move into a Cloud Storage bucket only accessible by the administrator.

**B.** Upload the logs to both the shared bucket and the bucket only accessible by the administrator. Create a job trigger using the Cloud Data Loss Prevention API. Configure the trigger to delete any files from the shared bucket that contain PII.

**C.** On the bucket shared with both the analysts and the administrator, configure Object Lifecycle Management to delete objects that contain any PII.

**D.** On the bucket shared with both the analysts and the administrator, configure a Cloud Storage Trigger that is only triggered when PII data is uploaded. Use Cloud Functions to capture the trigger and delete such files.

**Respuesta de la fuente:** A

**Explicación:** Option A correctly leverages Cloud Functions triggered by Pub/Sub to automate the inspection of uploaded logs using the Cloud Data Loss Prevention (DLP) API. When PII is detected, the function moves the file to a restricted bucket, ensuring analysts only access non-PII data while maintaining administrator access to sensitive logs.

Options B and D are incorrect because deleting files from the shared bucket prevents administrators from accessing the PII-containing logs as required by the scenario.

## Pregunta 68

Contexto: [topics:197](#topics-197)
A customer terminates an engineer and needs to make sure the engineer's Google account is automatically deprovisioned.
What should the customer do?

**A.** Use the Cloud SDK with their directory service to remove their IAM permissions in Cloud Identity.

**B.** Use the Cloud SDK with their directory service to provision and deprovision users from Cloud Identity.

**C.** Configure Cloud Directory Sync with their directory service to provision and deprovision users from Cloud Identity.

**D.** Configure Cloud Directory Sync with their directory service to remove their IAM permissions in Cloud Identity.

**Respuesta de la fuente:** C

**Explicación:** Cloud Directory Sync (CDS) is the official tool for synchronizing user lifecycle events from an on-premises or third-party directory service to Cloud Identity.
By configuring CDS, changes such as user termination in the primary directory are automatically replicated, resulting in automatic deprovisioning of the corresponding Google account.
The Cloud SDK is a command-line interface for managing resources via API and does not provide automated, event-driven identity synchronization.

## Pregunta 69

Contexto: [topics:197](#topics-197)
An organization is evaluating the use of Google Cloud Platform (GCP) for certain IT workloads. A well-established directory service is used to manage user identities and lifecycle management. This directory service must continue for the organization to use as the `source of truth` directory for identities.
Which solution meets the organization's requirements?

**A.** Google Cloud Directory Sync (GCDS)

**B.** Cloud Identity

**C.** Security Assertion Markup Language (SAML)

**D.** Pub/Sub

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Directory Sync (GCDS) is the correct solution because it allows an organization to synchronize user identities from an existing external directory service (such as LDAP or Active Directory) to Google Workspace or Cloud Identity.
By using GCDS, the organization maintains its established directory as the 'source of truth' while ensuring that Google cloud identities remain consistent with that source.
Cloud Identity (Option B) would act as a local identity provider, which contradicts the requirement to keep the external service as the primary source.

## Pregunta 70

Contexto: [topics:197](#topics-197)
Which international compliance standard provides guidelines for information security controls applicable to the provision and use of cloud services?

**A.** ISO 27001

**B.** ISO 27002

**C.** ISO 27017

**D.** ISO 27018

**Respuesta de la fuente:** C

**Explicación:** ISO/IEC 27017 is specifically designed to provide guidelines for information security controls applicable to the provision and use of cloud services. While ISO 27001 covers general ISMS requirements and ISO 27018 focuses on privacy in public clouds, ISO 27017 explicitly addresses control sets for both cloud service providers and customers.

## Pregunta 71

Contexto: [topics:197](#topics-197)
You will create a new Service Account that should be able to list the Compute Engine instances in the project. You want to follow Google-recommended practices.
What should you do?

**A.** Create an Instance Template, and allow the Service Account Read Only access for the Compute Engine Access Scope.

**B.** Create a custom role with the permission compute.instances.list and grant the Service Account this role.

**C.** Give the Service Account the role of Compute Viewer, and use the new Service Account for all instances.

**D.** Give the Service Account the role of Project Viewer, and use the new Service Account for all instances.

**Respuesta de la fuente:** B

**Explicación:** The question requires granting only the ability to list Compute Engine instances while following Google-recommended practices, which emphasize the Principle of Least Privilege.
Creating a custom role with specifically the `compute.instances.list` permission ensures the Service Account has exactly the required access and nothing more.
Options C and D are incorrect because they grant overly broad permissions (Compute Viewer and Project Viewer) that exceed the specific requirement.

## Pregunta 72

Contexto: [topics:197](#topics-197)
In a shared security responsibility model for IaaS, which two layers of the stack does the customer share responsibility for? (Choose two.)

**A.** Hardware

**B.** Network Security

**C.** Storage Encryption

**D.** Access Policies

**E.** Boot

**Respuesta de la fuente:** B, D

**Explicación:** In the IaaS shared responsibility model, the cloud provider secures the infrastructure (hardware, hypervisor), while the customer manages security within the cloud.
The customer is responsible for 'Network Security' (B) by configuring firewalls and network access controls to protect their resources.
They are also responsible for 'Access Policies' (D), which involves defining identity management and permissions for users and services accessing the environment.

## Pregunta 73

Contexto: [topics:197](#topics-197)
An organization is starting to move its infrastructure from its on-premises environment to Google Cloud Platform (GCP). The first step the organization wants to take is to migrate its ongoing data backup and disaster recovery solutions to GCP. The organization's on-premises production environment is going to be the next phase for migration to GCP. Stable networking connectivity between the on-premises environment and GCP is also being implemented.
Which GCP solution should the organization use?

**A.** BigQuery using a data pipeline job with continuous updates via Cloud VPN

**B.** Cloud Storage using a scheduled task and gsutil via Cloud Interconnect

**C.** Compute Engines Virtual Machines using Persistent Disk via Cloud Interconnect

**D.** Cloud Datastore using regularly scheduled batch upload jobs via Cloud VPN

**Respuesta de la fuente:** B

**Explicación:** Cloud Storage is the primary GCP service for object-based backup and disaster recovery due to its durability, scalability, and cost-effectiveness.
Using gsutil with scheduled tasks enables automated, reliable data transfer from on-premises systems.
Cloud Interconnect provides the necessary stable, high-bandwidth connectivity required for efficient large-scale data migration compared to Cloud VPN.

## Pregunta 74

Contexto: [topics:197](#topics-197)
What are the steps to encrypt data using envelope encryption?

**A.** ✑ Generate a data encryption key (DEK) locally.
✑ Use a key encryption key (KEK) to wrap the DEK.
✑ Encrypt data with the KEK.
✑ Store the encrypted data and the wrapped KEK.

**B.** ✑ Generate a key encryption key (KEK) locally.
✑ Use the KEK to generate a data encryption key (DEK).
✑ Encrypt data with the DEK.
✑ Store the encrypted data and the wrapped DEK.

**C.** ✑ Generate a data encryption key (DEK) locally.
✑ Encrypt data with the DEK.
✑ Use a key encryption key (KEK) to wrap the DEK.
✑ Store the encrypted data and the wrapped DEK.

**D.** ✑ Generate a key encryption key (KEK) locally.
✑ Generate a data encryption key (DEK) locally.
✑ Encrypt data with the KEK.
Store the encrypted data and the wrapped DEK.
[Imagen: sin descripción]
Imagen · choices[3].text · sin descripción
![Imagen original](imagenes/7909d3ebe29e65e21b84.png)
OCR: no_text_detected_unverified · Revisión visual pendiente.

**Respuesta de la fuente:** C

**Explicación:** In envelope encryption, a local Data Encryption Key (DEK) is generated and used to encrypt the actual data. This DEK is then encrypted (wrapped) using a Key Encryption Key (KEK) managed by a KMS like Cloud KMS. Finally, both the encrypted data and the wrapped DEK are stored, ensuring the sensitive KEK never leaves the secure key management environment.

## Pregunta 75

Contexto: [topics:197](#topics-197)
A customer wants to make it convenient for their mobile workforce to access a CRM web interface that is hosted on Google Cloud Platform (GCP). The CRM can only be accessed by someone on the corporate network. The customer wants to make it available over the internet. Your team requires an authentication layer in front of the application that supports two-factor authentication
Which GCP product should the customer implement to meet these requirements?

**A.** Cloud Identity-Aware Proxy

**B.** Cloud Armor

**C.** Cloud Endpoints

**D.** Cloud VPN

**Respuesta de la fuente:** A

**Explicación:** Cloud Identity-Aware Proxy (IAP) is designed to secure applications by adding an authentication layer that supports multi-factor authentication via Google Sign-in. It allows external users to access internal resources securely without needing a VPN tunnel, satisfying the requirement for internet access with strict identity verification.

## Pregunta 76

Contexto: [topics:197](#topics-197)
Your company is storing sensitive data in Cloud Storage. You want a key generated on-premises to be used in the encryption process.
What should you do?

**A.** Use the Cloud Key Management Service to manage a data encryption key (DEK).

**B.** Use the Cloud Key Management Service to manage a key encryption key (KEK).

**C.** Use customer-supplied encryption keys to manage the data encryption key (DEK).

**D.** Use customer-supplied encryption keys to manage the key encryption key (KEK).

**Respuesta de la fuente:** C

**Explicación:** Customer-Supplied Encryption Keys (CSEK) allow you to provide your own encryption keys for data at rest in Cloud Storage.
In the CSEK model, the key you supply acts as the Key Encryption Key (KEK) to protect the Data Encryption Key (DEK) generated by Google, rather than directly encrypting the data itself.
This ensures that Google never stores or manages your provided key, satisfying the requirement for on-premises key generation and management.

## Pregunta 77

Contexto: [topics:197](#topics-197)
Last week, a company deployed a new App Engine application that writes logs to BigQuery. No other workloads are running in the project. You need to validate that all data written to BigQuery was done using the App Engine Default Service Account.
What should you do?

**A.** 1. Use Cloud Logging and filter on BigQuery Insert Jobs. 2. Click on the email address in line with the App Engine Default Service Account in the authentication field. 3. Click Hide Matching Entries. 4. Make sure the resulting list is empty.

**B.** 1. Use Cloud Logging and filter on BigQuery Insert Jobs. 2. Click on the email address in line with the App Engine Default Service Account in the authentication field. 3. Click Show Matching Entries. 4. Make sure the resulting list is empty.

**C.** 1. In BigQuery, select the related dataset. 2. Make sure that the App Engine Default Service Account is the only account that can write to the dataset.

**D.** 1. Go to the Identity and Access Management (IAM) section of the project. 2. Validate that the App Engine Default Service Account is the only account that has a role that can write to BigQuery.

**Respuesta de la fuente:** A

**Explicación:** To validate that ALL data was written by the specific service account, you must confirm that NO data was written by any other account. Option A achieves this by filtering for BigQuery insert jobs and hiding entries from the App Engine Default Service Account; if the resulting list is empty, it proves no other identities performed writes. Options C and D verify permissions (authorization) rather than actual execution history, while Option B would only show entries from the correct account, failing to detect unauthorized writes.

## Pregunta 78

Contexto: [topics:197](#topics-197)
Your team wants to limit users with administrative privileges at the organization level.
Which two roles should your team restrict? (Choose two.)

**A.** Organization Administrator

**B.** Super Admin

**C.** GKE Cluster Admin

**D.** Compute Admin

**E.** Organization Role Viewer

**Respuesta de la fuente:** A, B

**Explicación:** The Organization Administrator role grants full control over the resource hierarchy, making it a critical administrative privilege at the organization level.
While 'Super Admin' is technically a Cloud Identity/Google Workspace concept rather than a standard IAM role, exam questions often use this term to refer to users with equivalent top-level organizational authority (such as Project Owners or specific legacy admins) who must be restricted to limit broad administrative access.
Other options like GKE Cluster Admin and Compute Admin are resource-specific roles that do not inherently grant organization-wide privileges.

## Pregunta 79

Contexto: [topics:197](#topics-197)
An organization's security and risk management teams are concerned about where their responsibility lies for certain production workloads they are running in
Google Cloud and where Google's responsibility lies. They are mostly running workloads using Google Cloud's platform-as-a-Service (PaaS) offerings, including
App Engine primarily.
Which area in the technology stack should they focus on as their primary responsibility when using App Engine?

**A.** Configuring and monitoring VPC Flow Logs

**B.** Defending against XSS and SQLi attacks

**C.** Managing the latest updates and security patches for the Guest OS

**D.** Encrypting all stored data

**Respuesta de la fuente:** B

**Explicación:** Under the Google Cloud shared responsibility model for PaaS offerings like App Engine, Google manages the infrastructure, including the guest OS and hardware, ruling out option C. Data at rest is encrypted by default in Google Cloud, so customers do not primarily manage encryption mechanics, making D incorrect. VPC Flow Logs (A) are network-level controls often managed by platform services or infrastructure teams, but the core customer responsibility lies with the application layer. Therefore, securing the application code against vulnerabilities such as Cross-Site Scripting (XSS) and SQL injection (SQLi) is the primary responsibility of the organization.

## Pregunta 80

Contexto: [topics:197](#topics-197)
An engineering team is launching a web application that will be public on the internet. The web application is hosted in multiple GCP regions and will be directed to the respective backend based on the URL request.
Your team wants to avoid exposing the application directly on the internet and wants to deny traffic from a specific list of malicious IP addresses.
Which solution should your team implement to meet these requirements?

**A.** Cloud Armor

**B.** Network Load Balancing

**C.** SSL Proxy Load Balancing

**D.** NAT Gateway

**Respuesta de la fuente:** A

**Explicación:** Cloud Armor is the correct solution because it provides a web application firewall (WAF) capability specifically designed to protect backend services from malicious traffic. It allows administrators to define security policies with rules that deny requests based on specific IP addresses, directly satisfying the requirement to block known bad actors before they reach the application.

## Pregunta 81

Contexto: [topics:197](#topics-197)
A customer is running an analytics workload on Google Cloud Platform (GCP) where Compute Engine instances are accessing data stored on Cloud Storage.
Your team wants to make sure that this workload will not be able to access, or be accessed from, the internet.
Which two strategies should your team use to meet these requirements? (Choose two.)

**A.** Configure Private Google Access on the Compute Engine subnet

**B.** Avoid assigning public IP addresses to the Compute Engine cluster.

**C.** Make sure that the Compute Engine cluster is running on a separate subnet.

**D.** Turn off IP forwarding on the Compute Engine instances in the cluster.

**E.** Configure a Cloud NAT gateway.

**Respuesta de la fuente:** A, B

**Explicación:** To prevent internet access while maintaining connectivity to Google services like Cloud Storage, you must avoid assigning public IP addresses (Option B) to ensure instances are not directly reachable from or routable to the internet. Additionally, configuring Private Google Access (Option A) allows these private-only instances to communicate with Google APIs and services using internal IP addresses over the Google network, bypassing the need for a public NAT gateway.

## Pregunta 82

Contexto: [topics:197](#topics-197)
A customer wants to run a batch processing system on VMs and store the output files in a Cloud Storage bucket. The networking and security teams have decided that no VMs may reach the public internet.
How should this be accomplished?

**A.** Create a firewall rule to block internet traffic from the VM.

**B.** Provision a NAT Gateway to access the Cloud Storage API endpoint.

**C.** Enable Private Google Access.

**D.** Mount a Cloud Storage bucket as a local filesystem on every VM.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Private Google Access allows VMs to access Google APIs and services (like Cloud Storage) via internal IPs without traversing the public internet.
This configuration satisfies the requirement to store files in Cloud Storage while ensuring VMs do not reach the public internet, assuming they lack external IP addresses or outbound internet routes.

## Pregunta 83

Contexto: [topics:197](#topics-197)
As adoption of the Cloud Data Loss Prevention (Cloud DLP) API grows within your company, you need to optimize usage to reduce cost. Cloud DLP target data is stored in Cloud Storage and BigQuery. The location and region are identified as a suffix in the resource name.
Which cost reduction options should you recommend?

**A.** Set appropriate rowsLimit value on BigQuery data hosted outside the US and set appropriate bytesLimitPerFile value on multiregional Cloud Storage buckets.

**B.** Set appropriate rowsLimit value on BigQuery data hosted outside the US, and minimize transformation units on multiregional Cloud Storage buckets.

**C.** Use rowsLimit and bytesLimitPerFile to sample data and use CloudStorageRegexFileSet to limit scans.

**D.** Use FindingLimits and TimespanContfig to sample data and minimize transformation units.

**Respuesta de la fuente:** C

**Explicación:** To reduce Cloud DLP costs, you should limit the volume of data scanned. Using `rowsLimit` for BigQuery and `bytesLimitPerFile` for Cloud Storage allows you to sample data rather than scanning entire datasets.
Additionally, using `CloudStorageRegexFileSet` restricts scans to only files matching specific patterns, avoiding unnecessary processing of irrelevant files.

## Pregunta 84

Contexto: [topics:197](#topics-197)
Your team uses a service account to authenticate data transfers from a given Compute Engine virtual machine instance of to a specified Cloud Storage bucket. An engineer accidentally deletes the service account, which breaks application functionality. You want to recover the application as quickly as possible without compromising security.
What should you do?

**A.** Temporarily disable authentication on the Cloud Storage bucket.

**B.** Use the undelete command to recover the deleted service account.

**C.** Create a new service account with the same name as the deleted service account.

**D.** Update the permissions of another existing service account and supply those credentials to the applications.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Google Cloud IAM provides a specific `undelete` API method to restore recently deleted service accounts within 30 days.
This allows for immediate recovery of the original credentials and permissions without security risks or application reconfiguration required by other options.

## Pregunta 85

Contexto: [topics:197](#topics-197)
You are the Security Admin in your company. You want to synchronize all security groups that have an email address from your LDAP directory in Cloud IAM.
What should you do?

**A.** Configure Google Cloud Directory Sync to sync security groups using LDAP search rules that have "user email address" as the attribute to facilitate one-way sync.

**B.** Configure Google Cloud Directory Sync to sync security groups using LDAP search rules that have "user email address" as the attribute to facilitate bidirectional sync.

**C.** Use a management tool to sync the subset based on the email address attribute. Create a group in the Google domain. A group created in a Google domain will automatically have an explicit Google Cloud Identity and Access Management (IAM) role.

**D.** Use a management tool to sync the subset based on group object class attribute. Create a group in the Google domain. A group created in a Google domain will automatically have an explicit Google Cloud Identity and Access Management (IAM) role.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Directory Sync (GCDS) performs a one-way synchronization from the LDAP directory to Google Workspace/Cloud IAM.
It allows you to define custom LDAP search rules to filter specific groups, such as those containing user email addresses.

## Pregunta 86

Contexto: [topics:197](#topics-197)
You are part of a security team investigating a compromised service account key. You need to audit which new resources were created by the service account.
What should you do?

**A.** Query Data Access logs.

**B.** Query Admin Activity logs.

**C.** Query Access Transparency logs.

**D.** Query Stackdriver Monitoring Workspace.

**Respuesta de la fuente:** B

**Explicación:** Admin Activity audit logs record API calls and administrative actions that modify the configuration or metadata of resources, such as creating VM instances.
Data Access logs track user-provided data access and are disabled by default, while Access Transparency logs only cover IAM policy changes for specific data APIs.
Therefore, querying Admin Activity logs is the correct method to identify resources created by a service account.

## Pregunta 87

Contexto: [topics:197](#topics-197)
You have an application where the frontend is deployed on a managed instance group in subnet A and the data layer is stored on a mysql Compute Engine virtual machine (VM) in subnet B on the same VPC. Subnet A and Subnet B hold several other Compute Engine VMs. You only want to allow the application frontend to access the data in the application's mysql instance on port 3306.
What should you do?

**A.** Configure an ingress firewall rule that allows communication from the src IP range of subnet A to the tag "data-tag" that is applied to the mysql Compute Engine VM on port 3306.

**B.** Configure an ingress firewall rule that allows communication from the frontend's unique service account to the unique service account of the mysql Compute Engine VM on port 3306.

**C.** Configure a network tag "fe-tag" to be applied to all instances in subnet A and a network tag "data-tag" to be applied to all instances in subnet B. Then configure an egress firewall rule that allows communication from Compute Engine VMs tagged with data-tag to destination Compute Engine VMs tagged fe- tag.

**D.** Configure a network tag "fe-tag" to be applied to all instances in subnet A and a network tag "data-tag" to be applied to all instances in subnet B. Then configure an ingress firewall rule that allows communication from Compute Engine VMs tagged with fe-tag to destination Compute Engine VMs tagged with data-tag.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Firewall rules are Layer 3/4 constructs that filter traffic based on IP addresses, ports, and protocol tags; they do not support service account identity matching as source or destination criteria. Therefore, options A, C, and D rely on valid mechanisms (IP ranges/tags), while option B describes a technically impossible configuration for firewall rules.

## Pregunta 88

Contexto: [topics:197](#topics-197)
Your company operates an application instance group that is currently deployed behind a Google Cloud load balancer in us-central-1 and is configured to use the
Standard Tier network. The infrastructure team wants to expand to a second Google Cloud region, us-east-2. You need to set up a single external IP address to distribute new requests to the instance groups in both regions.
What should you do?

**A.** Change the load balancer backend configuration to use network endpoint groups instead of instance groups.

**B.** Change the load balancer frontend configuration to use the Premium Tier network, and add the new instance group.

**C.** Create a new load balancer in us-east-2 using the Standard Tier network, and assign a static external IP address.

**D.** Create a Cloud VPN connection between the two regions, and enable Google Private Access.

**Respuesta de la fuente:** B

**Explicación:** Standard Tier load balancers are regional and restrict backends to the same region as the forwarding rule.
Premium Tier provides global external IP addresses and supports cross-region backends, allowing a single frontend to serve instance groups in us-central-1 and us-east-2.
Therefore, switching to Premium Tier and adding the new backend is the required configuration.

## Pregunta 89

Contexto: [topics:197](#topics-197)
You are the security admin of your company. You have 3,000 objects in your Cloud Storage bucket. You do not want to manage access to each object individually.
You also do not want the uploader of an object to always have full control of the object. However, you want to use Cloud Audit Logs to manage access to your bucket.
What should you do?

**A.** Set up an ACL with OWNER permission to a scope of allUsers.

**B.** Set up an ACL with READER permission to a scope of allUsers.

**C.** Set up a default bucket ACL and manage access for users using IAM.

**D.** Set up Uniform bucket-level access on the Cloud Storage bucket and manage access for users using IAM.

**Respuesta de la fuente:** D

**Explicación:** Uniform bucket-level access disables ACLs entirely, ensuring that object-level permissions cannot override bucket settings or grant unexpected full control to uploaders. This centralizes permission management under IAM, allowing the administrator to apply consistent policies across all 3,000 objects without managing them individually. Additionally, it supports Cloud Audit Logs for monitoring access as required by the scenario.

## Pregunta 90

Contexto: [topics:197](#topics-197)
You are the security admin of your company. Your development team creates multiple GCP projects under the "implementation" folder for several dev, staging, and production workloads. You want to prevent data exfiltration by malicious insiders or compromised code by setting up a security perimeter. However, you do not want to restrict communication between the projects.
What should you do?

**A.** Use a Shared VPC to enable communication between all projects, and use firewall rules to prevent data exfiltration.

**B.** Create access levels in Access Context Manager to prevent data exfiltration, and use a shared VPC for communication between projects.

**C.** Use an infrastructure-as-code software tool to set up a single service perimeter and to deploy a Cloud Function that monitors the "implementation" folder via Stackdriver and Cloud Pub/Sub. When the function notices that a new project is added to the folder, it executes Terraform to add the new project to the associated perimeter.

**D.** Use an infrastructure-as-code software tool to set up three different service perimeters for dev, staging, and prod and to deploy a Cloud Function that monitors the "implementation" folder via Stackdriver and Cloud Pub/Sub. When the function notices that a new project is added to the folder, it executes Terraform to add the new project to the respective perimeter.

**Respuesta de la fuente:** C

**Explicación:** VPC Service Controls (Service Perimeters) are the specific GCP mechanism designed to prevent data exfiltration by malicious insiders or compromised credentials, which standard firewall rules cannot address.
Option C is correct because it creates a single service perimeter for all projects in the 'implementation' folder, ensuring that communication between dev, staging, and production remains unrestricted while maintaining the security boundary against external exfiltration.
Option D is incorrect because creating separate perimeters without explicit bridging would block cross-project communication.

## Pregunta 91

Contexto: [topics:197](#topics-197)
You need to provide a corporate user account in Google Cloud for each of your developers and operational staff who need direct access to GCP resources.
Corporate policy requires you to maintain the user identity in a third-party identity management provider and leverage single sign-on. You learn that a significant number of users are using their corporate domain email addresses for personal Google accounts, and you need to follow Google recommended practices to convert existing unmanaged users to managed accounts.
Which two actions should you take? (Choose two.)

**A.** Use Google Cloud Directory Sync to synchronize your local identity management system to Cloud Identity.

**B.** Use the Google Admin console to view which managed users are using a personal account for their recovery email.

**C.** Add users to your managed Google account and force users to change the email addresses associated with their personal accounts.

**D.** Use the Transfer Tool for Unmanaged Users (TTUU) to find users with conflicting accounts and ask them to transfer their personal Google accounts.

**E.** Send an email to all of your employees and ask those users with corporate email addresses for personal Google accounts to delete the personal accounts immediately.

**Respuesta de la fuente:** A, D

**Explicación:** Option A is correct because Google Cloud Directory Sync (gcdirs) is the recommended tool to synchronize user identities from a third-party identity provider to Cloud Identity, enabling Single Sign-On (SSO) as required by corporate policy.

Option D is correct because the Transfer Tool for Unmanaged Users (TTUU) allows administrators to identify users with conflicting personal accounts and initiate the recommended process to transfer ownership of those accounts into the managed domain.

## Pregunta 92

Contexto: [topics:197](#topics-197)
You are on your company's development team. You noticed that your web application hosted in staging on GKE dynamically includes user data in web pages without first properly validating the inputted data. This could allow an attacker to execute gibberish commands and display arbitrary content in a victim user's browser in a production environment.
How should you prevent and fix this vulnerability?

**A.** Use Cloud IAP based on IP address or end-user device attributes to prevent and fix the vulnerability.

**B.** Set up an HTTPS load balancer, and then use Cloud Armor for the production environment to prevent the potential XSS attack.

**C.** Use Web Security Scanner to validate the usage of an outdated library in the code, and then use a secured version of the included library.

**D.** Use Web Security Scanner in staging to simulate an XSS injection attack, and then use a templating system that supports contextual auto-escaping.

**Respuesta de la fuente:** D

**Explicación:** The scenario describes a Cross-Site Scripting (XSS) vulnerability caused by improper input validation.

Google Cloud Web Security Scanner is specifically designed to crawl applications and simulate attacks, including XSS injections, to identify these vulnerabilities in staging environments.

To fix the root cause, implementing a templating system with contextual auto-escaping ensures that user-supplied data is automatically encoded appropriately for its context (HTML, JavaScript, etc.), preventing malicious scripts from executing.

## Pregunta 93

Contexto: [topics:197](#topics-197)
You are part of a security team that wants to ensure that a Cloud Storage bucket in Project A can only be readable from Project B. You also want to ensure that data in the Cloud Storage bucket cannot be accessed from or copied to Cloud Storage buckets outside the network, even if the user has the correct credentials.
What should you do?

**A.** Enable VPC Service Controls, create a perimeter with Project A and B, and include Cloud Storage service.

**B.** Enable Domain Restricted Sharing Organization Policy and Bucket Policy Only on the Cloud Storage bucket.

**C.** Enable Private Access in Project A and B networks with strict firewall rules to allow communication between the networks.

**D.** Enable VPC Peering between Project A and B networks with strict firewall rules to allow communication between the networks.

**Respuesta de la fuente:** A

**Explicación:** VPC Service Controls define a security perimeter around Google Cloud services to protect data from exfiltration and unauthorized access.
By including Project A (storage owner) and Project B (authorized reader) in the same perimeter with Cloud Storage, you ensure that data cannot be accessed or copied by entities outside this boundary, even if they possess valid credentials.
Network-based controls like VPC Peering or firewall rules (Options C and D) do not prevent credential-based exfiltration to external networks.

## Pregunta 94

Contexto: [topics:197](#topics-197)
You are responsible for protecting highly sensitive data in BigQuery. Your operations teams need access to this data, but given privacy regulations, you want to ensure that they cannot read the sensitive fields such as email addresses and first names. These specific sensitive fields should only be available on a need-to- know basis to the Human Resources team. What should you do?

**A.** Perform data masking with the Cloud Data Loss Prevention API, and store that data in BigQuery for later use.

**B.** Perform data redaction with the Cloud Data Loss Prevention API, and store that data in BigQuery for later use.

**C.** Perform data inspection with the Cloud Data Loss Prevention API, and store that data in BigQuery for later use.

**D.** Perform tokenization for Pseudonymization with the Cloud Data Loss Prevention API, and store that data in BigQuery for later use.

**Respuesta de la fuente:** D

**Explicación:** Tokenization replaces sensitive data with non-sensitive equivalents (tokens) that can be mapped back to the original data using a secure decryption key or vault.

This allows the operations team to use anonymized data for analysis while enabling the HR team to re-identify specific records on a need-to-know basis, satisfying both privacy and access requirements.

Unlike redaction (which permanently removes data) or simple masking (which may not support controlled re-identification in this context), tokenization preserves data utility and enables authorized de-anonymization.

## Pregunta 95

Contexto: [topics:197](#topics-197)
You are a Security Administrator at your organization. You need to restrict service account creation capability within production environments. You want to accomplish this centrally across the organization. What should you do?

**A.** Use Identity and Access Management (IAM) to restrict access of all users and service accounts that have access to the production environment.

**B.** Use organization policy constraints/iam.disableServiceAccountKeyCreation boolean to disable the creation of new service accounts.

**C.** Use organization policy constraints/iam.disableServiceAccountKeyUpload boolean to disable the creation of new service accounts.

**D.** Use organization policy constraints/iam.disableServiceAccountCreation boolean to disable the creation of new service accounts.

**Respuesta de la fuente:** D

**Explicación:** To centrally restrict service account creation across an organization, you must use Organization Policies.
The specific constraint `constraints/iam.disableServiceAccountCreation` is designed to prevent the creation of new service accounts when set to true.
This ensures centralized control without affecting other IAM permissions or key management settings.

## Pregunta 96

Contexto: [topics:197](#topics-197)
You are the project owner for a regulated workload that runs in a project you own and manage as an Identity and Access Management (IAM) admin. For an upcoming audit, you need to provide access reviews evidence. Which tool should you use?

**A.** Policy Troubleshooter

**B.** Policy Analyzer

**C.** IAM Recommender

**D.** Policy Simulator

**Respuesta de la fuente:** B

**Explicación:** Policy Analyzer allows administrators to query and analyze IAM policies to determine who has access to specific resources.
It provides auditable evidence of effective permissions by showing the exact policy bindings granting access, which is required for access reviews in regulated environments.

## Pregunta 97

Contexto: [topics:197](#topics-197)
Your organization has implemented synchronization and SAML federation between Cloud Identity and Microsoft Active Directory. You want to reduce the risk of
Google Cloud user accounts being compromised. What should you do?

**A.** Create a Cloud Identity password policy with strong password settings, and configure 2-Step Verification with security keys in the Google Admin console.

**B.** Create a Cloud Identity password policy with strong password settings, and configure 2-Step Verification with verification codes via text or phone call in the Google Admin console.

**C.** Create an Active Directory domain password policy with strong password settings, and configure post-SSO (single sign-on) 2-Step Verification with security keys in the Google Admin console.

**D.** Create an Active Directory domain password policy with strong password settings, and configure post-SSO (single sign-on) 2-Step Verification with verification codes via text or phone call in the Google Admin console.

**Respuesta de la fuente:** C

**Explicación:** Since authentication is federated via SAML from Active Directory, password complexity should be enforced at the source (AD) rather than in Cloud Identity. Security keys provide significantly stronger protection against compromise than SMS or voice codes, which are vulnerable to SIM-swapping and interception as noted by NIST guidelines.

## Pregunta 98

Contexto: [topics:197](#topics-197)
You have been tasked with implementing external web application protection against common web application attacks for a public application on Google Cloud.
You want to validate these policy changes before they are enforced. What service should you use?

**A.** Google Cloud Armor's preconfigured rules in preview mode

**B.** Prepopulated VPC firewall rules in monitor mode

**C.** The inherent protections of Google Front End (GFE)

**D.** Cloud Load Balancing firewall rules

**E.** VPC Service Controls in dry run mode

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Armor offers a 'preview mode' for security policies that allows you to simulate the enforcement of rules without actually blocking traffic.

This feature logs the actions that would have been taken in Cloud Monitoring, enabling validation of policy changes before they are applied in enforce mode.

## Pregunta 99

Contexto: [topics:197](#topics-197)
You are asked to recommend a solution to store and retrieve sensitive configuration data from an application that runs on Compute Engine. Which option should you recommend?

**A.** Cloud Key Management Service

**B.** Compute Engine guest attributes

**C.** Compute Engine custom metadata

**D.** Secret Manager

**Respuesta de la fuente:** D

**Explicación:** Secret Manager is the designated service for storing sensitive data like API keys and passwords because it provides a central location with integrated access controls and audit logging.
Unlike Compute Engine custom metadata, which lacks granular IAM controls and can leak data to instance logs, Secret Manager ensures secrets are encrypted and auditable.

## Pregunta 100

Contexto: [topics:197](#topics-197)
You need to implement an encryption at-rest strategy that reduces key management complexity for non-sensitive data and protects sensitive data while providing the flexibility of controlling the key residency and rotation schedule. FIPS 140-2 L1 compliance is required for all data types. What should you do?

**A.** Encrypt non-sensitive data and sensitive data with Cloud External Key Manager.

**B.** Encrypt non-sensitive data and sensitive data with Cloud Key Management Service

**C.** Encrypt non-sensitive data with Google default encryption, and encrypt sensitive data with Cloud External Key Manager.

**D.** Encrypt non-sensitive data with Google default encryption, and encrypt sensitive data with Cloud Key Management Service.

**Respuesta de la fuente:** D

**Explicación:** The requirement to reduce key management complexity for non-sensitive data points to using Google default encryption (Google-managed keys), as this requires no administrative overhead. For sensitive data, Cloud Key Management Service (Cloud KMS) is required to provide the specific flexibility of controlling key residency and rotation schedules while meeting FIPS 140-2 Level 1 compliance.

## Pregunta 101

Contexto: [topics:197](#topics-197)
Your company wants to determine what products they can build to help customers improve their credit scores depending on their age range. To achieve this, you need to join user information in the company's banking app with customers' credit score data received from a third party. While using this raw data will allow you to complete this task, it exposes sensitive data, which could be propagated into new systems.
This risk needs to be addressed using de-identification and tokenization with Cloud Data Loss Prevention while maintaining the referential integrity across the database. Which cryptographic token format should you use to meet these requirements?

**A.** Deterministic encryption

**B.** Secure, key-based hashes

**C.** Format-preserving encryption

**D.** Cryptographic hashing

**Respuesta de la fuente:** A

**Explicación:** The question explicitly requires maintaining referential integrity to join datasets, which necessitates a reversible encryption method where identical inputs produce identical outputs. Deterministic encryption satisfies this by ensuring the same credit score always maps to the same token, allowing for consistent joins across systems while de-identifying the data.
Format-preserving encryption (C) is incorrect because, while it preserves data format, it does not inherently guarantee the deterministic consistency required for reliable referential integrity without specific configuration, and Deterministic Encryption is the standard term in Google Cloud DLP for this reversible, consistent tokenization use case.

## Pregunta 102

Contexto: [topics:197](#topics-197)
An office manager at your small startup company is responsible for matching payments to invoices and creating billing alerts. For compliance reasons, the office manager is only permitted to have the Identity and Access Management (IAM) permissions necessary for these tasks. Which two IAM roles should the office manager have? (Choose two.)

**A.** Organization Administrator

**B.** Project Creator

**C.** Billing Account Viewer

**D.** Billing Account Costs Manager

**E.** Billing Account User

**Respuesta de la fuente:** C, D

**Explicación:** To match payments to invoices, the user needs read-only access to billing documents, which is provided by the Billing Account Viewer role. To create billing alerts (budgets), the user requires permissions to manage budgets and notifications, granted by the Billing Account Costs Manager role. These two roles follow the principle of least privilege by providing only the necessary permissions for these specific tasks.

## Pregunta 103

Contexto: [topics:197](#topics-197)
You are designing a new governance model for your organization's secrets that are stored in Secret Manager. Currently, secrets for Production and Non-
Production applications are stored and accessed using service accounts. Your proposed solution must:
✑ Provide granular access to secrets
✑ Give you control over the rotation schedules for the encryption keys that wrap your secrets
✑ Maintain environment separation
✑ Provide ease of management
Which approach should you take?

**A.** 1. Use separate Google Cloud projects to store Production and Non-Production secrets. 2. Enforce access control to secrets using project-level identity and Access Management (IAM) bindings. 3. Use customer-managed encryption keys to encrypt secrets.

**B.** 1. Use a single Google Cloud project to store both Production and Non-Production secrets. 2. Enforce access control to secrets using secret-level Identity and Access Management (IAM) bindings. 3. Use Google-managed encryption keys to encrypt secrets.

**C.** 1. Use separate Google Cloud projects to store Production and Non-Production secrets. 2. Enforce access control to secrets using secret-level Identity and Access Management (IAM) bindings. 3. Use Google-managed encryption keys to encrypt secrets.

**D.** 1. Use a single Google Cloud project to store both Production and Non-Production secrets. 2. Enforce access control to secrets using project-level Identity and Access Management (IAM) bindings. 3. Use customer-managed encryption keys to encrypt secrets.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because using separate projects for Production and Non-Production environments ensures strict environment separation. Customer-managed encryption keys (CMEK) provide the necessary control over key rotation schedules, which Google-managed keys do not allow. While project-level IAM provides access at the resource group level rather than individual secret granularity, it is the only option among the choices that satisfies both the key rotation and environment separation requirements simultaneously.

## Pregunta 104

Contexto: [topics:197](#topics-197)
You are a security engineer at a finance company. Your organization plans to store data on Google Cloud, but your leadership team is worried about the security of their highly sensitive data. Specifically, your company is concerned about internal Google employees' ability to access your company's data on Google Cloud.
What solution should you propose?

**A.** Use customer-managed encryption keys.

**B.** Use Google's Identity and Access Management (IAM) service to manage access controls on Google Cloud.

**C.** Enable Admin activity logs to monitor access to resources.

**D.** Enable Access Transparency logs with Access Approval requests for Google employees.

**Respuesta de la fuente:** D

**Explicación:** Access Transparency provides visibility into Google's use of customer data, logging all access by Google employees to production systems.
Combined with Access Approval, it allows the organization to explicitly approve or deny such access requests before they occur.
This directly addresses the concern about internal Google employee access by adding an audit trail and a mandatory approval workflow.

## Pregunta 105

Contexto: [topics:197](#topics-197)
You want to use the gcloud command-line tool to authenticate using a third-party single sign-on (SSO) SAML identity provider. Which options are necessary to ensure that authentication is supported by the third-party identity provider (IdP)? (Choose two.)

**A.** SSO SAML as a third-party IdP

**B.** Identity Platform

**C.** OpenID Connect

**D.** Identity-Aware Proxy

**E.** Cloud Identity

**Respuesta de la fuente:** A, E

**Explicación:** To authenticate the gcloud CLI via a third-party SAML IdP, you must use Cloud Identity (E) because it is the Google-managed service that integrates external IdPs and generates short-lived access credentials for command-line usage. The third-party provider itself must support the SAML protocol (A) to issue the initial authentication assertion required by this integration.

Option C (OpenID Connect) is incorrect because the question specifically specifies a SAML identity provider, whereas OIDC is a different protocol standard not required in this specific SAML scenario.

## Pregunta 106

Contexto: [topics:197](#topics-197)
You work for a large organization where each business unit has thousands of users. You need to delegate management of access control permissions to each business unit. You have the following requirements:
✑ Each business unit manages access controls for their own projects.
✑ Each business unit manages access control permissions at scale.
✑ Business units cannot access other business units' projects.
✑ Users lose their access if they move to a different business unit or leave the company.
✑ Users and access control permissions are managed by the on-premises directory service.
What should you do? (Choose two.)

**A.** Use VPC Service Controls to create perimeters around each business unit's project.

**B.** Organize projects in folders, and assign permissions to Google groups at the folder level.

**C.** Group business units based on Organization Units (OUs) and manage permissions based on OUs

**D.** Create a project naming convention, and use Google's IAM Conditions to manage access based on the prefix of project names.

**E.** Use Google Cloud Directory Sync to synchronize users and group memberships in Cloud Identity.

**Respuesta de la fuente:** B, E

**Explicación:** Assigning permissions to Google Groups at the Folder level (B) satisfies the requirements for scalable access management and isolation, as folder policies inherit to all contained projects without cross-unit leakage.
Using Google Cloud Directory Sync (E) correctly fulfills the requirement to manage users and group memberships via an on-premises directory service, ensuring immediate access revocation upon user departure or transfer.

## Pregunta 107

Contexto: [topics:197](#topics-197)
Your organization recently deployed a new application on Google Kubernetes Engine. You need to deploy a solution to protect the application. The solution has the following requirements:
✑ Scans must run at least once per week
✑ Must be able to detect cross-site scripting vulnerabilities
✑ Must be able to authenticate using Google accounts
Which solution should you use?

**A.** Google Cloud Armor

**B.** Web Security Scanner

**C.** Security Health Analytics

**D.** Container Threat Detection

**Respuesta de la fuente:** B

**Explicación:** Web Security Scanner is the correct choice because it specifically performs automated vulnerability scans on web applications hosted on GKE, including detection of cross-site scripting (XSS) flaws. It supports scheduled scans (meeting the weekly requirement) and integrates with Google Identity for authentication, whereas Cloud Armor is a WAF for traffic filtering rather than a vulnerability scanner.

## Pregunta 108

Contexto: [topics:197](#topics-197)
An organization is moving applications to Google Cloud while maintaining a few mission-critical applications on-premises. The organization must transfer the data at a bandwidth of at least 50 Gbps. What should they use to ensure secure continued connectivity between sites?

**A.** Dedicated Interconnect

**B.** Cloud Router

**C.** Cloud VPN

**D.** Partner Interconnect

**Respuesta de la fuente:** A

**Explicación:** Dedicated Interconnect is the correct choice because it supports attachment sizes of up to 100 Gbps, meeting the requirement of 'at least 50 Gbps'.
Partner Interconnect has a maximum supported attachment size of 50 Gbps and may not always offer that capacity depending on the partner and location.
Cloud VPN is unsuitable due to lower bandwidth limits, higher latency, and overhead compared to physical interconnections.

## Pregunta 109

Contexto: [topics:197](#topics-197)
Your organization has had a few recent DDoS attacks. You need to authenticate responses to domain name lookups. Which Google Cloud service should you use?

**A.** Cloud DNS with DNSSEC

**B.** Cloud NAT

**C.** HTTP(S) Load Balancing

**D.** Google Cloud Armor

**Respuesta de la fuente:** A

**Explicación:** DNSSEC (Domain Name System Security Extensions) is specifically designed to authenticate responses to domain name lookups by providing origin authentication and data integrity.
It prevents attackers from manipulating or poisoning DNS responses, which directly addresses the requirement to authenticate lookups.
Cloud DNS natively supports DNSSEC, managing key rotation and zone signing automatically.

## Pregunta 110

Contexto: [topics:197](#topics-197)
Your Security team believes that a former employee of your company gained unauthorized access to Google Cloud resources some time in the past 2 months by using a service account key. You need to confirm the unauthorized access and determine the user activity. What should you do?

**A.** Use Security Health Analytics to determine user activity.

**B.** Use the Cloud Monitoring console to filter audit logs by user.

**C.** Use the Cloud Data Loss Prevention API to query logs in Cloud Storage.

**D.** Use the Logs Explorer to search for user activity.

**Respuesta de la fuente:** D

**Explicación:** The Logs Explorer in Cloud Logging is the primary tool for searching and analyzing audit logs to investigate specific user or service account activities.

Cloud Monitoring provides metrics and anomaly detection but does not allow direct filtering of detailed audit log entries by user identity, making it unsuitable for confirming specific unauthorized actions.

## Pregunta 111

Contexto: [topics:197](#topics-197)
Your company requires the security and network engineering teams to identify all network anomalies within and across VPCs, internal traffic from VMs to VMs, traffic between end locations on the internet and VMs, and traffic between VMs to Google Cloud services in production. Which method should you use?

**A.** Define an organization policy constraint.

**B.** Configure packet mirroring policies.

**C.** Enable VPC Flow Logs on the subnet.

**D.** Monitor and analyze Cloud Audit Logs.

**Respuesta de la fuente:** B

**Explicación:** Packet Mirroring is the correct choice because it provides full packet payloads and headers, which are required for deep inspection to identify complex security anomalies and threats across all specified traffic types. VPC Flow Logs (Choice C) only provide sampled metadata about connections, lacking the detailed content necessary for comprehensive anomaly detection.

## Pregunta 112

Contexto: [topics:197](#topics-197)
Your company has been creating users manually in Cloud Identity to provide access to Google Cloud resources. Due to continued growth of the environment, you want to authorize the Google Cloud Directory Sync (GCDS) instance and integrate it with your on-premises LDAP server to onboard hundreds of users. You are required to:
✑ Replicate user and group lifecycle changes from the on-premises LDAP server in Cloud Identity.
✑ Disable any manually created users in Cloud Identity.
You have already configured the LDAP search attributes to include the users and security groups in scope for Google Cloud. What should you do next to complete this solution?

**A.** 1. Configure the option to suspend domain users not found in LDAP. 2. Set up a recurring GCDS task.

**B.** 1. Configure the option to delete domain users not found in LDAP. 2. Run GCDS after user and group lifecycle changes.

**C.** 1. Configure the LDAP search attributes to exclude manually created Cloud Identity users not found in LDAP. 2. Set up a recurring GCDS task.

**D.** 1. Configure the LDAP search attributes to exclude manually created Cloud Identity users not found in LDAP. 2. Run GCDS after user and group lifecycle changes.

**Respuesta de la fuente:** A

**Explicación:** To disable manually created users not present in the on-premises LDAP directory, you must configure GCDS to suspend these accounts rather than delete them or ignore them.
Setting up a recurring GCDS task ensures that user and group lifecycle changes are continuously replicated from the LDAP server to Cloud Identity, maintaining synchronization.

## Pregunta 113

Contexto: [topics:197](#topics-197)
You are troubleshooting access denied errors between Compute Engine instances connected to a Shared VPC and BigQuery datasets. The datasets reside in a project protected by a VPC Service Controls perimeter. What should you do?

**A.** Add the host project containing the Shared VPC to the service perimeter.

**B.** Add the service project where the Compute Engine instances reside to the service perimeter.

**C.** Create a service perimeter between the service project where the Compute Engine instances reside and the host project that contains the Shared VPC.

**D.** Create a perimeter bridge between the service project where the Compute Engine instances reside and the perimeter that contains the protected BigQuery datasets.

**Respuesta de la fuente:** A

**Explicación:** In a Shared VPC architecture using VPC Service Controls, resources in service projects are implicitly considered part of the host project's identity for perimeter checks. Therefore, to allow Compute Engine instances in a service project to access BigQuery datasets within the same perimeter, the host project itself must be explicitly added to that service perimeter.

## Pregunta 114

Contexto: [topics:197](#topics-197)
You recently joined the networking team supporting your company's Google Cloud implementation. You are tasked with familiarizing yourself with the firewall rules configuration and providing recommendations based on your networking and Google Cloud experience. What product should you recommend to detect firewall rules that are overlapped by attributes from other firewall rules with higher or equal priority?

**A.** Security Command Center

**B.** Firewall Rules Logging

**C.** VPC Flow Logs

**D.** Firewall Insights

**Respuesta de la fuente:** D

**Explicación:** Firewall Insights is specifically designed to analyze firewall rule configurations and detect misconfigurations such as shadowed or overlapping rules. A shadowed rule occurs when its attributes are entirely covered by other rules with higher or equal priority, making it unreachable during evaluation.

Reference: Google Cloud Firewall Insights documentation on detecting shadowed rules.

## Pregunta 115

Contexto: [topics:197](#topics-197)
The security operations team needs access to the security-related logs for all projects in their organization. They have the following requirements:
✑ Follow the least privilege model by having only view access to logs.
✑ Have access to Admin Activity logs.
✑ Have access to Data Access logs.
✑ Have access to Access Transparency logs.
Which Identity and Access Management (IAM) role should the security operations team be granted?

**A.** roles/logging.privateLogViewer

**B.** roles/logging.admin

**C.** roles/viewer

**D.** roles/logging.viewer

**Respuesta de la fuente:** A

**Explicación:** The requirement for Data Access logs and Access Transparency logs dictates the use of the Private Logs Viewer role, as standard Logs Viewer roles do not include these sensitive audit entries. This role adheres to the least privilege principle by providing read-only access (excluding admin capabilities) while granting visibility into private log types that require specific IAM permissions.

## Pregunta 116

Contexto: [topics:197](#topics-197)
You are exporting application logs to Cloud Storage. You encounter an error message that the log sinks don't support uniform bucket-level access policies. How should you resolve this error?

**A.** Change the access control model for the bucket

**B.** Update your sink with the correct bucket destination.

**C.** Add the roles/logging.logWriter Identity and Access Management (IAM) role to the bucket for the log sink identity.

**D.** Add the roles/logging.bucketWriter Identity and Access Management (IAM) role to the bucket for the log sink identity.

**Respuesta de la fuente:** A

**Explicación:** The error occurs because Cloud Logging sinks do not support buckets configured with Uniform Bucket-Level Access (UBLA), which disables legacy Access Control Lists (ACLs) required for sink destination permissions.

To resolve this, you must change the bucket's access control model to fine-grained access within 90 days of creation, allowing the logging service to apply necessary ACLs.

## Pregunta 117

Contexto: [topics:197](#topics-197)
You plan to deploy your cloud infrastructure using a CI/CD cluster hosted on Compute Engine. You want to minimize the risk of its credentials being stolen by a third party. What should you do?

**A.** Create a dedicated Cloud Identity user account for the cluster. Use a strong self-hosted vault solution to store the user's temporary credentials.

**B.** Create a dedicated Cloud Identity user account for the cluster. Enable the constraints/iam.disableServiceAccountCreation organization policy at the project level.

**C.** Create a custom service account for the cluster. Enable the constraints/iam.disableServiceAccountKeyCreation organization policy at the project level

**D.** Create a custom service account for the cluster. Enable the constraints/iam.allowServiceAccountCredentialLifetimeExtension organization policy at the project level.

**Respuesta de la fuente:** C

**Explicación:** Service accounts are the recommended identity mechanism for workloads like Compute Engine clusters, avoiding the security risks associated with human user accounts.
Enabling the `constraints/iam.disableServiceAccountKeyCreation` organization policy prevents the creation of long-lived service account keys, which are static secrets susceptible to theft if exposed or improperly managed.
This forces the use of short-lived tokens generated via instance metadata or OAuth2 flows, significantly reducing the risk window for credential compromise.

## Pregunta 118

Contexto: [topics:197](#topics-197)
You need to set up two network segments: one with an untrusted subnet and the other with a trusted subnet. You want to configure a virtual appliance such as a next-generation firewall (NGFW) to inspect all traffic between the two network segments. How should you design the network to inspect the traffic?

**A.** 1. Set up one VPC with two subnets: one trusted and the other untrusted. 2. Configure a custom route for all traffic (0.0.0.0/0) pointed to the virtual appliance.

**B.** 1. Set up one VPC with two subnets: one trusted and the other untrusted. 2. Configure a custom route for all RFC1918 subnets pointed to the virtual appliance.

**C.** 1. Set up two VPC networks: one trusted and the other untrusted, and peer them together. 2. Configure a custom route on each network pointed to the virtual appliance.

**D.** 1. Set up two VPC networks: one trusted and the other untrusted. 2. Configure a virtual appliance using multiple network interfaces, with each interface connected to one of the VPC networks.

**Respuesta de la fuente:** D

**Explicación:** To inspect all traffic between two distinct network segments (trusted and untrusted), the virtual appliance must act as a bridge between them.
Using multiple network interfaces allows each interface to connect directly to one VPC, ensuring all inter-VPC traffic passes through the firewall for inspection.
Single-VPC routing options (A and B) do not isolate the trusted and untrusted segments into separate networks as required by the scenario.

## Pregunta 119

Contexto: [topics:197](#topics-197)
You are a member of your company's security team. You have been asked to reduce your Linux bastion host external attack surface by removing all public IP addresses. Site Reliability Engineers (SREs) require access to the bastion host from public locations so they can access the internal VPC while off-site. How should you enable this access?

**A.** Implement Cloud VPN for the region where the bastion host lives.

**B.** Implement OS Login with 2-step verification for the bastion host.

**C.** Implement Identity-Aware Proxy TCP forwarding for the bastion host.

**D.** Implement Google Cloud Armor in front of the bastion host.

**Respuesta de la fuente:** C

**Explicación:** Identity-Aware Proxy (IAP) TCP forwarding allows authenticated users to access instances via SSH or RDP without requiring a public IP address on the bastion host. This eliminates the external attack surface associated with direct internet exposure while maintaining secure remote access for SREs. Other options like Cloud VPN require complex network routing, OS Login does not remove the need for public IPs for connectivity, and Google Armor protects web traffic rather than providing access mechanisms for private instances.

## Pregunta 120

Contexto: [topics:197](#topics-197)
You need to enable VPC Service Controls and allow changes to perimeters in existing environments without preventing access to resources. Which VPC Service
Controls mode should you use?

**A.** Cloud Run

**B.** Native

**C.** Enforced

**D.** Dry run

**Respuesta de la fuente:** D

**Explicación:** Dry run mode allows you to monitor and log requests that would violate perimeter policies without actually denying access.
This enables safe testing of configuration changes in existing environments while ensuring resources remain accessible.

## Pregunta 121

Contexto: [topics:197](#topics-197)
You manage your organization's Security Operations Center (SOC). You currently monitor and detect network traffic anomalies in your Google Cloud VPCs based on packet header information. However, you want the capability to explore network flows and their payload to aid investigations. Which Google Cloud product should you use?

**A.** Marketplace IDS

**B.** VPC Flow Logs

**C.** VPC Service Controls logs

**D.** Packet Mirroring

**E.** Google Cloud Armor Deep Packet Inspection

**Respuesta de la fuente:** D

**Explicación:** VPC Flow Logs only capture packet header metadata (IPs, ports, protocols), which the user already monitors and finds insufficient for payload analysis.
Packet Mirroring allows you to clone traffic from specific instances, providing access to both headers and the full packet payload for deep inspection by third-party security tools.

## Pregunta 122

Contexto: [topics:197](#topics-197)
Your organization acquired a new workload. The Web and Application (App) servers will be running on Compute Engine in a newly created custom VPC. You are responsible for configuring a secure network communication solution that meets the following requirements:
✑ Only allows communication between the Web and App tiers.
✑ Enforces consistent network security when autoscaling the Web and App tiers.
✑ Prevents Compute Engine Instance Admins from altering network traffic.
What should you do?

**A.** 1. Configure all running Web and App servers with respective network tags. 2. Create an allow VPC firewall rule that specifies the target/source with respective network tags.

**B.** 1. Configure all running Web and App servers with respective service accounts. 2. Create an allow VPC firewall rule that specifies the target/source with respective service accounts.

**C.** 1. Re-deploy the Web and App servers with instance templates configured with respective network tags. 2. Create an allow VPC firewall rule that specifies the target/source with respective network tags.

**D.** 1. Re-deploy the Web and App servers with instance templates configured with respective service accounts. 2. Create an allow VPC firewall rule that specifies the target/source with respective service accounts.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because using service accounts for firewall targeting prevents Compute Engine Instance Admins from altering network traffic via metadata changes, unlike network tags. Additionally, deploying via instance templates ensures that new instances created by autoscaling inherit the required service account configurations automatically.

## Pregunta 123

Contexto: [topics:197](#topics-197)
You need to connect your organization's on-premises network with an existing Google Cloud environment that includes one Shared VPC with two subnets named
Production and Non-Production. You are required to:
✑ Use a private transport link.
✑ Configure access to Google Cloud APIs through private API endpoints originating from on-premises environments.
✑ Ensure that Google Cloud APIs are only consumed via VPC Service Controls.
What should you do?

**A.** 1. Set up a Cloud VPN link between the on-premises environment and Google Cloud. 2. Configure private access using the restricted.googleapis.com domains in on-premises DNS configurations.

**B.** 1. Set up a Partner Interconnect link between the on-premises environment and Google Cloud. 2. Configure private access using the private.googleapis.com domains in on-premises DNS configurations.

**C.** 1. Set up a Direct Peering link between the on-premises environment and Google Cloud. 2. Configure private access for both VPC subnets.

**D.** 1. Set up a Dedicated Interconnect link between the on-premises environment and Google Cloud. 2. Configure private access using the restricted.googleapis.com domains in on-premises DNS configurations.

**Respuesta de la fuente:** D

**Explicación:** A Dedicated Interconnect provides a private, high-bandwidth physical connection, satisfying the requirement for a private transport link more robustly than Cloud VPN which traverses the public internet.
Using restricted.googleapis.com ensures that API traffic is routed through Google's private backbone and is subject to VPC Service Controls, whereas private.googleapis.com allows access without these security boundaries.

## Pregunta 124

Contexto: [topics:197](#topics-197)
You are working with protected health information (PHI) for an electronic health record system. The privacy officer is concerned that sensitive data is stored in the analytics system. You are tasked with anonymizing the sensitive data in a way that is not reversible. Also, the anonymized data should not preserve the character set and length. Which Google Cloud solution should you use?

**A.** Cloud Data Loss Prevention with deterministic encryption using AES-SIV

**B.** Cloud Data Loss Prevention with format-preserving encryption

**C.** Cloud Data Loss Prevention with cryptographic hashing

**D.** Cloud Data Loss Prevention with Cloud Key Management Service wrapped cryptographic keys

**Respuesta de la fuente:** C

**Explicación:** Cryptographic hashing is the only method listed that produces irreversible output, satisfying the requirement for non-reversible anonymization. Additionally, hashing transforms input into a fixed-length string (e.g., SHA-256), which does not preserve the original character set or length of the data.

## Pregunta 125

Contexto: [topics:197](#topics-197)
You are setting up a CI/CD pipeline to deploy containerized applications to your production clusters on Google Kubernetes Engine (GKE). You need to prevent containers with known vulnerabilities from being deployed. You have the following requirements for your solution:

Must be cloud-native -
[Imagen: sin descripción]
✑ Must be cost-efficient
✑ Minimize operational overhead
How should you accomplish this? (Choose two.)
Imagen · question_text · sin descripción
![Imagen original](imagenes/08f8c37915fa2ad652a1.png)
OCR: no_text_detected_unverified · Revisión visual pendiente.

**A.** Create a Cloud Build pipeline that will monitor changes to your container templates in a Cloud Source Repositories repository. Add a step to analyze Container Analysis results before allowing the build to continue.

**B.** Use a Cloud Function triggered by log events in Google Cloud's operations suite to automatically scan your container images in Container Registry.

**C.** Use a cron job on a Compute Engine instance to scan your existing repositories for known vulnerabilities and raise an alert if a non-compliant container image is found.

**D.** Deploy Jenkins on GKE and configure a CI/CD pipeline to deploy your containers to Container Registry. Add a step to validate your container images before deploying your container to the cluster.

**E.** In your CI/CD pipeline, add an attestation on your container image when no vulnerabilities have been found. Use a Binary Authorization policy to block deployments of containers with no attestation in your cluster.

**Respuesta de la fuente:** A, E

**Explicación:** Option A satisfies the cloud-native and cost-efficiency requirements by leveraging Cloud Build's native integration with Container Analysis to scan images for vulnerabilities during the build process.
Option E complements this by using Binary Authorization, a serverless, native GKE feature, to enforce deployment policies that block unattested (and thus potentially vulnerable) containers, minimizing operational overhead compared to managing external tools like Jenkins or Compute Engine instances.

## Pregunta 126

Contexto: [topics:197](#topics-197)
Which type of load balancer should you use to maintain client IP by default while using the standard network tier?

**A.** SSL Proxy

**B.** TCP Proxy

**C.** Internal TCP/UDP

**D.** TCP/UDP Network

**Respuesta de la fuente:** D

**Explicación:** The TCP/UDP Network load balancer is a non-proxied Layer 4 load balancer that forwards traffic without terminating connections, thereby preserving the original client IP address by default.
Unlike Proxy-based load balancers (SSL/TCP Proxy) which are restricted to the Premium network tier, and unlike Internal TCP/UDP load balancers which require Premium tier for global features or are internal-only, the External TCP/UDP Network load balancer supports the Standard network tier.

## Pregunta 127

Contexto: [topics:197](#topics-197)
You want to prevent users from accidentally deleting a Shared VPC host project. Which organization-level policy constraint should you enable?

**A.** compute.restrictSharedVpcHostProjects

**B.** compute.restrictXpnProjectLienRemoval

**C.** compute.restrictSharedVpcSubnetworks

**D.** compute.sharedReservationsOwnerProjects

**Respuesta de la fuente:** B

**Explicación:** The compute.restrictXpnProjectLienRemoval constraint controls who can remove the protection lien on a Shared VPC host project.
Enabling this constraint ensures that only users with specific organization-level permissions can remove the lien, thereby preventing accidental deletion by standard project owners.

## Pregunta 128

Contexto: [topics:197](#topics-197)
Users are reporting an outage on your public-facing application that is hosted on Compute Engine. You suspect that a recent change to your firewall rules is responsible. You need to test whether your firewall rules are working properly. What should you do?

**A.** Enable Firewall Rules Logging on the latest rules that were changed. Use Logs Explorer to analyze whether the rules are working correctly.

**B.** Connect to a bastion host in your VPC. Use a network traffic analyzer to determine at which point your requests are being blocked.

**C.** In a pre-production environment, disable all firewall rules individually to determine which one is blocking user traffic.

**D.** Enable VPC Flow Logs in your VPC. Use Logs Explorer to analyze whether the rules are working correctly.

**Respuesta de la fuente:** A

**Explicación:** Firewall rules logging provides specific connection records that indicate whether traffic was allowed or denied by a particular rule. This feature allows you to verify the exact behavior of the recently changed firewall rules directly in Cloud Logging without generating additional network traffic or impacting production availability.

## Pregunta 129

Contexto: [topics:197](#topics-197)
You are a security administrator at your company. Per Google-recommended best practices, you implemented the domain restricted sharing organization policy to allow only required domains to access your projects. An engineering team is now reporting that users at an external partner outside your organization domain cannot be granted access to the resources in a project. How should you make an exception for your partner's domain while following the stated best practices?

**A.** Turn off the domain restriction sharing organization policy. Set the policy value to "Allow All."

**B.** Turn off the domain restricted sharing organization policy. Provide the external partners with the required permissions using Google's Identity and Access Management (IAM) service.

**C.** Turn off the domain restricted sharing organization policy. Add each partner's Google Workspace customer ID to a Google group, add the Google group as an exception under the organization policy, and then turn the policy back on.

**D.** Turn off the domain restricted sharing organization policy. Set the policy value to "Custom." Add each external partner's Cloud Identity or Google Workspace customer ID as an exception under the organization policy, and then turn the policy back on.

**Respuesta de la fuente:** D

**Explicación:** The 'restrict-domains' organization policy controls which Google Workspace or Cloud Identity domains can access resources.
To grant access to external partners, you must configure the policy value to 'Custom' and add their specific Customer IDs as allowed values.
This preserves the security restriction for other domains while explicitly permitting the partner's identities, whereas using groups (Option C) is not supported directly in the policy configuration itself.

## Pregunta 130

Contexto: [topics:197](#topics-197)
You plan to use a Google Cloud Armor policy to prevent common attacks such as cross-site scripting (XSS) and SQL injection (SQLi) from reaching your web application's backend. What are two requirements for using Google Cloud Armor security policies? (Choose two.)

**A.** The load balancer must be an external SSL proxy load balancer.

**B.** Google Cloud Armor Policy rules can only match on Layer 7 (L7) attributes.

**C.** The load balancer must use the Premium Network Service Tier.

**D.** The backend service's load balancing scheme must be EXTERNAL.

**E.** The load balancer must be an external HTTP(S) load balancer.

**Respuesta de la fuente:** D, E

**Explicación:** Google Cloud Armor requires the backend service's load balancing scheme to be EXTERNAL (Option D). Additionally, it must be attached to a supported external load balancer, such as an external HTTP(S) load balancer (Option E). Options A and C are incorrect because SSL proxy load balancers are also supported (not exclusive) and Standard Tier is permitted (not just Premium). Option B is false because rules can match on Layer 3-7 attributes.

## Pregunta 131

Contexto: [topics:197](#topics-197)
You perform a security assessment on a customer architecture and discover that multiple VMs have public IP addresses. After providing a recommendation to remove the public IP addresses, you are told those VMs need to communicate to external sites as part of the customer's typical operations. What should you recommend to reduce the need for public IP addresses in your customer's VMs?

**A.** Google Cloud Armor

**B.** Cloud NAT

**C.** Cloud Router

**D.** Cloud VPN

**Respuesta de la fuente:** B

**Explicación:** Cloud NAT allows VMs in a VPC network to initiate outbound connections to the internet without requiring individual external IP addresses on each instance.
It handles the Network Address Translation (NAT) for these VMs, enabling them to access external sites while keeping their private IPs non-routable from the internet.
This directly addresses the security assessment finding by reducing the attack surface associated with public IP assignments.

## Pregunta 132

Contexto: [topics:197](#topics-197)
You are tasked with exporting and auditing security logs for login activity events for Google Cloud console and API calls that modify configurations to Google
Cloud resources. Your export must meet the following requirements:
✑ Export related logs for all projects in the Google Cloud organization.
✑ Export logs in near real-time to an external SIEM.
What should you do? (Choose two.)

**A.** Create a Log Sink at the organization level with a Pub/Sub destination.

**B.** Create a Log Sink at the organization level with the includeChildren parameter, and set the destination to a Pub/Sub topic.

**C.** Enable Data Access audit logs at the organization level to apply to all projects.

**D.** Enable Google Workspace audit logs to be shared with Google Cloud in the Admin Console.

**E.** Ensure that the SIEM processes the AuthenticationInfo field in the audit log entry to gather identity information.

**Respuesta de la fuente:** B, C

**Explicación:** No conservada en esta captura.

## Pregunta 133

Contexto: [topics:197](#topics-197)
Your company's Chief Information Security Officer (CISO) creates a requirement that business data must be stored in specific locations due to regulatory requirements that affect the company's global expansion plans. After working on the details to implement this requirement, you determine the following:
✑ The services in scope are included in the Google Cloud Data Residency Terms.
✑ The business data remains within specific locations under the same organization.
✑ The folder structure can contain multiple data residency locations.
You plan to use the Resource Location Restriction organization policy constraint. At which level in the resource hierarchy should you set the constraint?

**A.** Folder

**B.** Resource

**C.** Project

**D.** Organization

**Respuesta de la fuente:** C

**Explicación:** The Resource Location Restriction organization policy can be set at the Organization, Folder, or Project levels, but not directly on individual Resources.
Since the scenario states that a single folder structure contains multiple data residency locations, applying the constraint at the Folder level would enforce a single location for all projects within it, violating the requirement.
Therefore, the constraint must be applied at the Project level to allow different projects under the same folder to reside in different specific locations.

## Pregunta 134

Contexto: [topics:197](#topics-197)
You need to set up a Cloud interconnect connection between your company's on-premises data center and VPC host network. You want to make sure that on- premises applications can only access Google APIs over the Cloud Interconnect and not through the public internet. You are required to only use APIs that are supported by VPC Service Controls to mitigate against exfiltration risk to non-supported APIs. How should you configure the network?

**A.** Enable Private Google Access on the regional subnets and global dynamic routing mode.

**B.** Set up a Private Service Connect endpoint IP address with the API bundle of "all-apis", which is advertised as a route over the Cloud interconnect connection.

**C.** Use private.googleapis.com to access Google APIs using a set of IP addresses only routable from within Google Cloud, which are advertised as routes over the connection.

**D.** Use restricted googleapis.com to access Google APIs using a set of IP addresses only routable from within Google Cloud, which are advertised as routes over the Cloud Interconnect connection.

**Respuesta de la fuente:** D

**Explicación:** The requirement to mitigate exfiltration risk by restricting access to only VPC Service Controls-supported APIs necessitates using the 'restricted.googleapis.com' endpoint, which explicitly supports this subset.

Option D correctly identifies this endpoint and describes the mechanism of advertising its private IP ranges over Cloud Interconnect, ensuring traffic remains within Google's backbone rather than traversing the public internet.

## Pregunta 135

Contexto: [topics:197](#topics-197)
You need to implement an encryption-at-rest strategy that protects sensitive data and reduces key management complexity for non-sensitive data. Your solution has the following requirements:
✑ Schedule key rotation for sensitive data.
✑ Control which region the encryption keys for sensitive data are stored in.
✑ Minimize the latency to access encryption keys for both sensitive and non-sensitive data.
What should you do?

**A.** Encrypt non-sensitive data and sensitive data with Cloud External Key Manager.

**B.** Encrypt non-sensitive data and sensitive data with Cloud Key Management Service.

**C.** Encrypt non-sensitive data with Google default encryption, and encrypt sensitive data with Cloud External Key Manager.

**D.** Encrypt non-sensitive data with Google default encryption, and encrypt sensitive data with Cloud Key Management Service.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it balances requirements for both data types. For sensitive data, Cloud Key Management Service (KMS) allows explicit control over key storage regions and scheduling of key rotation, which Google's default encryption does not support. For non-sensitive data, using Google's default encryption minimizes key management complexity and latency, as Data Encryption Keys are stored locally near the data and managed automatically by Google.

## Pregunta 136

Contexto: [topics:197](#topics-197)
Your security team uses encryption keys to ensure confidentiality of user data. You want to establish a process to reduce the impact of a potentially compromised symmetric encryption key in Cloud Key Management Service (Cloud KMS).
Which steps should your team take before an incident occurs? (Choose two.)

**A.** Disable and revoke access to compromised keys.

**B.** Enable automatic key version rotation on a regular schedule.

**C.** Manually rotate key versions on an ad hoc schedule.

**D.** Limit the number of messages encrypted with each key version.

**E.** Disable the Cloud KMS API.

**Respuesta de la fuente:** B, D

**Explicación:** The question asks for proactive measures to take 'before an incident occurs' to reduce the impact of a potential compromise.

1. Enable automatic key version rotation on a regular schedule (B): This ensures that if a key is compromised, it will be replaced automatically within a predictable timeframe, limiting the window of exposure.
2. Limit the number of messages encrypted with each key version (D): According to Cloud KMS best practices, limiting usage per key version helps prevent cryptanalysis attacks and reduces the volume of data at risk if a specific key version is compromised.

Option A (Disable and revoke access) is a reactive step taken *after* compromise is suspected or confirmed, not before. Option C (Manual rotation) is less reliable than automatic rotation for ensuring timely updates. Option E (Disable API) would break functionality.

## Pregunta 137

Contexto: [topics:197](#topics-197)
Your company's chief information security officer (CISO) is requiring business data to be stored in specific locations due to regulatory requirements that affect the company's global expansion plans. After working on a plan to implement this requirement, you determine the following:
✑ The services in scope are included in the Google Cloud data residency requirements.
✑ The business data remains within specific locations under the same organization.
✑ The folder structure can contain multiple data residency locations.
✑ The projects are aligned to specific locations.
You plan to use the Resource Location Restriction organization policy constraint with very granular control. At which level in the hierarchy should you set the constraint?

**A.** Organization

**B.** Resource

**C.** Project

**D.** Folder

**Respuesta de la fuente:** C

**Explicación:** The question explicitly requires 'very granular control' and notes that projects are aligned to specific locations. In Google Cloud organization policy inheritance, setting the constraint at the Project level overrides broader Folder or Organization settings, providing the most precise enforcement for data residency per individual project.

## Pregunta 138

Contexto: [topics:197](#topics-197)
A database administrator notices malicious activities within their Cloud SQL instance. The database administrator wants to monitor the API calls that read the configuration or metadata of resources. Which logs should the database administrator review?

**A.** Admin Activity

**B.** System Event

**C.** Access Transparency

**D.** Data Access

**Respuesta de la fuente:** D

**Explicación:** Data Access audit logs specifically record API calls that read the configuration or metadata of resources, which matches the administrator's requirement to monitor read operations. In contrast, Admin Activity logs only track actions that modify configuration or metadata, such as creating instances or changing permissions.

## Pregunta 139

Contexto: [topics:197](#topics-197)
You are backing up application logs to a shared Cloud Storage bucket that is accessible to both the administrator and analysts. Analysts should not have access to logs that contain any personally identifiable information (PII). Log files containing PII should be stored in another bucket that is only accessible to the administrator. What should you do?

**A.** Upload the logs to both the shared bucket and the bucket with PII that is only accessible to the administrator. Use the Cloud Data Loss Prevention API to create a job trigger. Configure the trigger to delete any files that contain PII from the shared bucket.

**B.** On the shared bucket, configure Object Lifecycle Management to delete objects that contain PII.

**C.** On the shared bucket, configure a Cloud Storage trigger that is only triggered when PII is uploaded. Use Cloud Functions to capture the trigger and delete the files that contain PII.

**D.** Use Pub/Sub and Cloud Functions to trigger a Cloud Data Loss Prevention scan every time a file is uploaded to the administrator's bucket. If the scan does not detect PII, have the function move the objects into the shared Cloud Storage bucket.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it implements a secure-by-default architecture where all logs initially land in the restricted administrator bucket.
Using Cloud Data Loss Prevention (DLP) to scan for PII ensures that only non-PII files are moved to the shared bucket, guaranteeing analysts never access sensitive data.
This approach avoids the race condition and complexity of deleting files from a shared bucket after they have already been accessible (as in Option A).

## Pregunta 140

Contexto: [topics:197](#topics-197)
You work for an organization in a regulated industry that has strict data protection requirements. The organization backs up their data in the cloud. To comply with data privacy regulations, this data can only be stored for a specific length of time and must be deleted after this specific period.
You want to automate the compliance with this regulation while minimizing storage costs. What should you do?

**A.** Store the data in a persistent disk, and delete the disk at expiration time.

**B.** Store the data in a Cloud Bigtable table, and set an expiration time on the column families.

**C.** Store the data in a BigQuery table, and set the table's expiration time.

**D.** Store the data in a Cloud Storage bucket, and configure the bucket's Object Lifecycle Management feature.

**Respuesta de la fuente:** D

**Explicación:** Object Lifecycle Management in Cloud Storage allows you to automatically delete objects after a specified period, satisfying the regulatory requirement for data expiration.
Cloud Storage is generally more cost-effective than BigQuery for simple data retention and deletion tasks, especially when the data format is not strictly tabular or analytical.
This approach directly automates compliance while minimizing storage costs compared to persistent disks or other database services.

## Pregunta 141

Contexto: [topics:197](#topics-197)
You have been tasked with configuring Security Command Center for your organization's Google Cloud environment. Your security team needs to receive alerts of potential crypto mining in the organization's compute environment and alerts for common Google Cloud misconfigurations that impact security. Which Security
Command Center features should you use to configure these alerts? (Choose two.)

**A.** Event Threat Detection

**B.** Container Threat Detection

**C.** Security Health Analytics

**D.** Cloud Data Loss Prevention

**E.** Google Cloud Armor

**Respuesta de la fuente:** A, C

**Explicación:** Event Threat Detection identifies malicious activities such as crypto mining on compute resources by analyzing VM metrics and logs.
Security Health Analytics continuously monitors your Google Cloud environment for common misconfigurations that could expose sensitive data or services.

## Pregunta 142

Contexto: [topics:197](#topics-197)
You have noticed an increased number of phishing attacks across your enterprise user accounts. You want to implement the Google 2-Step Verification (2SV) option that uses a cryptographic signature to authenticate a user and verify the URL of the login page. Which Google 2SV option should you use?

**A.** Titan Security Keys

**B.** Google prompt

**C.** Google Authenticator app

**D.** Cloud HSM keys

**Respuesta de la fuente:** A

**Explicación:** Titan Security Keys are phishing-resistant authentication factors that utilize FIDO standards and public key cryptography.
They generate a cryptographic signature to authenticate the user and bind that signature to the specific origin URL of the login page, preventing credential theft via spoofed sites.

## Pregunta 143

Contexto: [topics:197](#topics-197)
Your organization hosts a financial services application running on Compute Engine instances for a third-party company. The third-party company's servers that will consume the application also run on Compute Engine in a separate Google Cloud organization. You need to configure a secure network connection between the Compute Engine instances. You have the following requirements:
✑ The network connection must be encrypted.
✑ The communication between servers must be over private IP addresses.
What should you do?

**A.** Configure a Cloud VPN connection between your organization's VPC network and the third party's that is controlled by VPC firewall rules.

**B.** Configure a VPC peering connection between your organization's VPC network and the third party's that is controlled by VPC firewall rules.

**C.** Configure a VPC Service Controls perimeter around your Compute Engine instances, and provide access to the third party via an access level.

**D.** Configure an Apigee proxy that exposes your Compute Engine-hosted application as an API, and is encrypted with TLS which allows access only to the third party.

**Respuesta de la fuente:** B

**Explicación:** VPC peering is the correct solution because it establishes a direct, low-latency connection between two VPCs using private IP addresses without requiring traffic to traverse the public internet. While Cloud VPN (A) also uses private IPs over a tunnel, Google Cloud automatically encrypts all VM-to-VM traffic within a VPC and across peered networks by default at the data link layer, satisfying the encryption requirement more efficiently than an application-layer or IPsec overlay. The other options fail: C refers to data security perimeters rather than network connectivity, and D exposes the service via TLS (typically over public endpoints) rather than maintaining a pure private IP backbone.

## Pregunta 144

Contexto: [topics:197](#topics-197)
Your company's new CEO recently sold two of the company's divisions. Your Director asks you to help migrate the Google Cloud projects associated with those divisions to a new organization node. Which preparation steps are necessary before this migration occurs? (Choose two.)

**A.** Remove all project-level custom Identity and Access Management (IAM) roles.

**B.** Disallow inheritance of organization policies.

**C.** Identify inherited Identity and Access Management (IAM) roles on projects to be migrated.

**D.** Create a new folder for all projects to be migrated.

**E.** Remove the specific migration projects from any VPC Service Controls perimeters and bridges.

**Respuesta de la fuente:** C, E

**Explicación:** Choice C is correct because migrating projects across organizations breaks resource hierarchy, causing inherited IAM policies to stop applying; identifying these dependencies prevents unauthorized access post-migration.
Choice E is correct because Google Cloud strictly prohibits moving projects that are currently members of VPC Service Control perimeters or bridges, requiring their removal before migration can proceed.

## Pregunta 145

Contexto: [topics:197](#topics-197)
You are a consultant for an organization that is considering migrating their data from its private cloud to Google Cloud. The organization's compliance team is not familiar with Google Cloud and needs guidance on how compliance requirements will be met on Google Cloud. One specific compliance requirement is for customer data at rest to reside within specific geographic boundaries. Which option should you recommend for the organization to meet their data residency requirements on Google Cloud?

**A.** Organization Policy Service constraints

**B.** Shielded VM instances

**C.** Access control lists

**D.** Geolocation access controls

**E.** Google Cloud Armor

**Respuesta de la fuente:** A

**Explicación:** The Organization Policy Service allows administrators to enforce the 'Resource Locations' constraint across an organization hierarchy.
This constraint restricts where new resources can be created by limiting them to specific regions or zones, ensuring data residency compliance for customer data at rest.

## Pregunta 146

Contexto: [topics:197](#topics-197)
Your security team wants to reduce the risk of user-managed keys being mismanaged and compromised. To achieve this, you need to prevent developers from creating user-managed service account keys for projects in their organization. How should you enforce this?

**A.** Configure Secret Manager to manage service account keys.

**B.** Enable an organization policy to disable service accounts from being created.

**C.** Enable an organization policy to prevent service account keys from being created.

**D.** Remove the iam.serviceAccounts.getAccessToken permission from users.

**Respuesta de la fuente:** C

**Explicación:** Google Cloud Organization Policy constraints allow administrators to enforce rules across the resource hierarchy. Specifically, enabling the `constraints/iam.disableServiceAccountKeyCreation` policy prevents user-managed service account keys from being created, forcing a shift toward more secure non-key authentication methods like Workload Identity or IAM credentials API.

## Pregunta 147

Contexto: [topics:197](#topics-197)
You are responsible for managing your company's identities in Google Cloud. Your company enforces 2-Step Verification (2SV) for all users. You need to reset a user's access, but the user lost their second factor for 2SV. You want to minimize risk. What should you do?

**A.** On the Google Admin console, select the appropriate user account, and generate a backup code to allow the user to sign in. Ask the user to update their second factor.

**B.** On the Google Admin console, temporarily disable the 2SV requirements for all users. Ask the user to log in and add their new second factor to their account. Re-enable the 2SV requirement for all users.

**C.** On the Google Admin console, select the appropriate user account, and temporarily disable 2SV for this account. Ask the user to update their second factor, and then re-enable 2SV for this account.

**D.** On the Google Admin console, use a super administrator account to reset the user account's credentials. Ask the user to update their credentials after their first login.

**Respuesta de la fuente:** A

**Explicación:** Generating a backup code allows the user to regain access without disabling 2SV for the organization or the specific account.
This approach minimizes risk by maintaining the security posture, as the account remains protected by the second factor requirement rather than being temporarily exempted.

## Pregunta 148

Contexto: [topics:197](#topics-197)
Which Google Cloud service should you use to enforce access control policies for applications and resources?

**A.** Identity-Aware Proxy

**B.** Cloud NAT

**C.** Google Cloud Armor

**D.** Shielded VMs

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Identity-Aware Proxy (IAP) is specifically designed to provide secure access to web applications and resources based on user identity and context, rather than just network location. It enforces access control policies by requiring users to authenticate with Google or SAML before accessing resources behind the proxy. Other options like Cloud NAT handle outbound traffic translation, Cloud Armor provides DDoS protection and WAF features, and Shielded VMs secure boot integrity, none of which directly enforce application-level identity-based access controls.

## Pregunta 149

Contexto: [topics:197](#topics-197)
You want to update your existing VPC Service Controls perimeter with a new access level. You need to avoid breaking the existing perimeter with this change, and ensure the least disruptions to users while minimizing overhead. What should you do?

**A.** Create an exact replica of your existing perimeter. Add your new access level to the replica. Update the original perimeter after the access level has been vetted.

**B.** Update your perimeter with a new access level that never matches. Update the new access level to match your desired state one condition at a time to avoid being overly permissive.

**C.** Enable the dry run mode on your perimeter. Add your new access level to the perimeter configuration. Update the perimeter configuration after the access level has been vetted.

**D.** Enable the dry run mode on your perimeter. Add your new access level to the perimeter dry run configuration. Update the perimeter configuration after the access level has been vetted.

**Respuesta de la fuente:** D

**Explicación:** VPC Service Controls provides a 'Dry Run' mode specifically to test configuration changes without enforcing them, ensuring zero disruption to existing users.
You must add the new access level to the **dry run configuration** (not the active one) to simulate its effect.
Once verified, you apply the change to the active perimeter, satisfying the requirement for minimal overhead and no service interruption.

## Pregunta 150

Contexto: [topics:197](#topics-197)
Your organization's Google Cloud VMs are deployed via an instance template that configures them with a public IP address in order to host web services for external users. The VMs reside in a service project that is attached to a host (VPC) project containing one custom Shared VPC for the VMs. You have been asked to reduce the exposure of the VMs to the internet while continuing to service external users. You have already recreated the instance template without a public IP address configuration to launch the managed instance group (MIG). What should you do?

**A.** Deploy a Cloud NAT Gateway in the service project for the MIG.

**B.** Deploy a Cloud NAT Gateway in the host (VPC) project for the MIG.

**C.** Deploy an external HTTP(S) load balancer in the service project with the MIG as a backend.

**D.** Deploy an external HTTP(S) load balancer in the host (VPC) project with the MIG as a backend.

**Respuesta de la fuente:** C

**Explicación:** Cloud NAT is designed for outbound internet access (egress), not for handling incoming external requests, so options A and B are incorrect. To reduce VM exposure while serving external users, an external HTTP(S) load balancer must be used as the ingress point. According to Google Cloud Shared VPC architecture guidelines, the global front-end components of an HTTP(S) load balancer (such as the forwarding rule and proxy) must reside in the same service project as the backend services (the MIG). Therefore, deploying the load balancer in the service project is the correct action.

## Pregunta 151

Contexto: [topics:197](#topics-197)
Your privacy team uses crypto-shredding (deleting encryption keys) as a strategy to delete personally identifiable information (PII). You need to implement this practice on Google Cloud while still utilizing the majority of the platform's services and minimizing operational overhead. What should you do?

**A.** Use client-side encryption before sending data to Google Cloud, and delete encryption keys on-premises.

**B.** Use Cloud External Key Manager to delete specific encryption keys.

**C.** Use customer-managed encryption keys to delete specific encryption keys.

**D.** Use Google default encryption to delete specific encryption keys.

**Respuesta de la fuente:** C

**Explicación:** Customer-Managed Encryption Keys (CMEK) stored in Cloud Key Management Service allow you to destroy specific key versions to render encrypted data inaccessible, fulfilling the crypto-shredding requirement.
Unlike client-side encryption or external key managers, CMEK minimizes operational overhead by keeping key management within the Google Cloud platform while providing control over key deletion.

## Pregunta 152

Contexto: [topics:197](#topics-197)
You need to centralize your team's logs for production projects. You want your team to be able to search and analyze the logs using Logs Explorer. What should you do?

**A.** Enable Cloud Monitoring workspace, and add the production projects to be monitored.

**B.** Use Logs Explorer at the organization level and filter for production project logs.

**C.** Create an aggregate org sink at the parent folder of the production projects, and set the destination to a Cloud Storage bucket.

**D.** Create an aggregate org sink at the parent folder of the production projects, and set the destination to a logs bucket.

**Respuesta de la fuente:** D

**Explicación:** To centralize logs for centralized analysis in Logs Explorer, you must export them to a Logs Bucket. Cloud Storage buckets (Option C) are not directly searchable via Logs Explorer, requiring import or other tools. Option D correctly uses an aggregate sink at the parent folder level to capture logs from multiple projects into a single Logs Bucket, enabling unified querying.

## Pregunta 153

Contexto: [topics:197](#topics-197)
You need to use Cloud External Key Manager to create an encryption key to encrypt specific BigQuery data at rest in Google Cloud. Which steps should you do first?

**A.** 1. Create or use an existing key with a unique uniform resource identifier (URI) in your Google Cloud project. 2. Grant your Google Cloud project access to a supported external key management partner system.

**B.** 1. Create or use an existing key with a unique uniform resource identifier (URI) in Cloud Key Management Service (Cloud KMS). 2. In Cloud KMS, grant your Google Cloud project access to use the key.

**C.** 1. Create or use an existing key with a unique uniform resource identifier (URI) in a supported external key management partner system. 2. In the external key management partner system, grant access for this key to use your Google Cloud project.

**D.** 1. Create an external key with a unique uniform resource identifier (URI) in Cloud Key Management Service (Cloud KMS). 2. In Cloud KMS, grant your Google Cloud project access to use the key.

**Respuesta de la fuente:** C

**Explicación:** Cloud External Key Manager (Cloud EKM) relies on keys managed outside of Google Cloud, so the first step is to create or identify an existing key in a supported external key management partner system.
Access control for these external keys is granted within that partner system, not in Cloud KMS or the Google Cloud Console, making option C the correct sequence.

## Pregunta 154

Contexto: [topics:197](#topics-197)
Your company's cloud security policy dictates that VM instances should not have an external IP address. You need to identify the Google Cloud service that will allow VM instances without external IP addresses to connect to the internet to update the VMs. Which service should you use?

**A.** Identity Aware-Proxy

**B.** Cloud NAT

**C.** TCP/UDP Load Balancing

**D.** Cloud DNS

**Respuesta de la fuente:** B

**Explicación:** Cloud NAT enables outbound internet access for private VM instances that do not have external IP addresses by performing network address translation.
This allows the VMs to initiate connections to the internet, such as for system updates, while remaining protected from inbound external traffic.
Other options like Identity-Aware Proxy or Load Balancing handle inbound traffic or authentication, and Cloud DNS resolves domain names but does not facilitate network connectivity.

## Pregunta 155

Contexto: [topics:197](#topics-197)
You want to make sure that your organization's Cloud Storage buckets cannot have data publicly available to the internet. You want to enforce this across all
Cloud Storage buckets. What should you do?

**A.** Remove Owner roles from end users, and configure Cloud Data Loss Prevention.

**B.** Remove Owner roles from end users, and enforce domain restricted sharing in an organization policy.

**C.** Configure uniform bucket-level access, and enforce domain restricted sharing in an organization policy.

**D.** Remove *.setIamPolicy permissions from all roles, and enforce domain restricted sharing in an organization policy.

**Respuesta de la fuente:** C

**Explicación:** Enabling uniform bucket-level access disables Access Control Lists (ACLs), forcing the use of Identity and Access Management (IAM) for all permission management to simplify security controls. Enforcing the 'domain restricted sharing' organization policy constraint specifically prevents objects from being made publicly accessible, ensuring data remains within the organizational boundary.

## Pregunta 156

Contexto: [topics:197](#topics-197)
Your company plans to move most of its IT infrastructure to Google Cloud. They want to leverage their existing on-premises Active Directory as an identity provider for Google Cloud. Which two steps should you take to integrate the company's on-premises Active Directory with Google Cloud and configure access management? (Choose two.)

**A.** Use Identity Platform to provision users and groups to Google Cloud.

**B.** Use Cloud Identity SAML integration to provision users and groups to Google Cloud.

**C.** Install Google Cloud Directory Sync and connect it to Active Directory and Cloud Identity.

**D.** Create Identity and Access Management (IAM) roles with permissions corresponding to each Active Directory group.

**E.** Create Identity and Access Management (IAM) groups with permissions corresponding to each Active Directory group.

**Respuesta de la fuente:** C, D

**Explicación:** Google Cloud Directory Sync (GCDS) is the recommended tool for synchronizing users and groups from on-premises Active Directory to Cloud Identity.
Once synced, IAM roles should be granted directly to these synchronized groups to manage access permissions effectively.

## Pregunta 157

Contexto: [topics:197](#topics-197)
You are in charge of creating a new Google Cloud organization for your company. Which two actions should you take when creating the super administrator accounts? (Choose two.)

**A.** Create an access level in the Google Admin console to prevent super admin from logging in to Google Cloud.

**B.** Disable any Identity and Access Management (IAM) roles for super admin at the organization level in the Google Cloud Console.

**C.** Use a physical token to secure the super admin credentials with multi-factor authentication (MFA).

**D.** Use a private connection to create the super admin accounts to avoid sending your credentials over the Internet.

**E.** Provide non-privileged identities to the super admin users for their day-to-day activities.

**Respuesta de la fuente:** C, E

**Explicación:** Super administrator accounts require the highest level of security, making Multi-Factor Authentication (MFA) with a physical token essential to prevent credential theft.
Additionally, adhering to the principle of least privilege involves providing non-privileged identities for daily tasks to limit exposure and reduce the risk of accidental changes or malicious exploitation.

## Pregunta 158

Contexto: [topics:197](#topics-197)
You are deploying a web application hosted on Compute Engine. A business requirement mandates that application logs are preserved for 12 years and data is kept within European boundaries. You want to implement a storage solution that minimizes overhead and is cost-effective. What should you do?

**A.** Create a Cloud Storage bucket to store your logs in the EUROPE-WEST1 region. Modify your application code to ship logs directly to your bucket for increased efficiency.

**B.** Configure your Compute Engine instances to use the Google Cloud's operations suite Cloud Logging agent to send application logs to a custom log bucket in the EUROPE-WEST1 region with a custom retention of 12 years.

**C.** Use a Pub/Sub topic to forward your application logs to a Cloud Storage bucket in the EUROPE-WEST1 region.

**D.** Configure a custom retention policy of 12 years on your Google Cloud's operations suite log bucket in the EUROPE-WEST1 region.

**Respuesta de la fuente:** A

**Explicación:** Options B and D are incorrect because Cloud Logging custom buckets have a maximum retention period of 3,650 days (approximately 10 years), which fails to meet the 12-year requirement. Option A is superior to C because shipping logs directly from the application to Cloud Storage minimizes operational overhead by eliminating the need for intermediate services like Pub/Sub.

## Pregunta 159

Contexto: [topics:197](#topics-197)
You discovered that sensitive personally identifiable information (PII) is being ingested to your Google Cloud environment in the daily ETL process from an on- premises environment to your BigQuery datasets. You need to redact this data to obfuscate the PII, but need to re-identify it for data analytics purposes. Which components should you use in your solution? (Choose two.)

**A.** Secret Manager

**B.** Cloud Key Management Service

**C.** Cloud Data Loss Prevention with cryptographic hashing

**D.** Cloud Data Loss Prevention with automatic text redaction

**E.** Cloud Data Loss Prevention with deterministic encryption using AES-SIV

**Respuesta de la fuente:** B, E

**Explicación:** Cloud Data Loss Prevention (DLP) with deterministic encryption (Option E) is required because it allows for the reversible obfuscation of PII, enabling re-identification for analytics later. Unlike simple hashing or redaction, deterministic encryption maps specific plaintext values to consistent ciphertexts.

Cloud Key Management Service (KMS) (Option B) is necessary to manage and store the cryptographic keys used by Cloud DLP for these encryption operations, ensuring secure key lifecycle management.

## Pregunta 160

Contexto: [topics:197](#topics-197)
You are working with a client that is concerned about control of their encryption keys for sensitive data. The client does not want to store encryption keys at rest in the same cloud service provider (CSP) as the data that the keys are encrypting. Which Google Cloud encryption solutions should you recommend to this client?
(Choose two.)

**A.** Customer-supplied encryption keys.

**B.** Google default encryption

**C.** Secret Manager

**D.** Cloud External Key Manager

**E.** Customer-managed encryption keys

**Respuesta de la fuente:** A, D

**Explicación:** Customer-supplied encryption keys (CSEK) and Cloud External Key Manager (EKM) satisfy the requirement by keeping encryption keys outside Google Cloud's infrastructure.
In CSEK, the customer manages the keys entirely in their own environment, never storing them at rest on GCP.
EKM allows customers to use an external key management system (such as an HSM or KMS) where keys are stored and managed independently of Google Cloud.
Google-managed encryption (default) and Customer-Managed Encryption Keys (CMEK via Cloud KMS) store keys within Google's infrastructure, which violates the client's constraint.

## Pregunta 161

Contexto: [topics:197](#topics-197)
You are implementing data protection by design and in accordance with GDPR requirements. As part of design reviews, you are told that you need to manage the encryption key for a solution that includes workloads for Compute Engine, Google Kubernetes Engine, Cloud Storage, BigQuery, and Pub/Sub. Which option should you choose for this implementation?

**A.** Cloud External Key Manager

**B.** Customer-managed encryption keys

**C.** Customer-supplied encryption keys

**D.** Google default encryption

**Respuesta de la fuente:** A

**Explicación:** Cloud External Key Manager (EKM) is the correct choice for GDPR-compliant 'data protection by design' because it allows organizations to store encryption keys in their own on-premises or third-party hardware security modules (HSMs), preventing Google from accessing the raw key material.
This ensures strict control over key usage, including the ability to deny decryption requests even if Google needs them for service maintenance, which aligns with the highest standards of data sovereignty and compliance required by GDPR.
While Customer-Managed Encryption Keys (CMEK) offer some control, the keys are still stored within Google Cloud KMS; EKM provides the strongest guarantee that Google never holds the key.

## Pregunta 162

Contexto: [topics:197](#topics-197)
Which Identity-Aware Proxy role should you grant to an Identity and Access Management (IAM) user to access HTTPS resources?

**A.** Security Reviewer

**B.** IAP-Secured Tunnel User

**C.** IAP-Secured Web App User

**D.** Service Broker Operator

**Respuesta de la fuente:** C

**Explicación:** The IAP-Secured Web App User role (roles/iap.httpsResourceAccessor) is specifically designed to grant access to HTTPS resources protected by Identity-Aware Proxy, such as App Engine and Compute Engine applications.
In contrast, the IAP-Secured Tunnel User role applies to TCP tunnels, while Security Reviewer and Service Broker Operator are unrelated administrative or service management roles.

## Pregunta 163

Contexto: [topics:197](#topics-197)
You need to audit the network segmentation for your Google Cloud footprint. You currently operate Production and Non-Production infrastructure-as-a-service
(IaaS) environments. All your VM instances are deployed without any service account customization.
After observing the traffic in your custom network, you notice that all instances can communicate freely `" despite tag-based VPC firewall rules in place to segment traffic properly `" with a priority of 1000. What are the most likely reasons for this behavior?

**A.** All VM instances are missing the respective network tags.

**B.** All VM instances are residing in the same network subnet.

**C.** All VM instances are configured with the same network route.

**D.** A VPC firewall rule is allowing traffic between source/targets based on the same service account with priority 999. E . A VPC firewall rule is allowing traffic between source/targets based on the same service account with priority 1001.

**Respuesta de la fuente:** A, D

**Explicación:** GCP VPC firewall evaluation prioritizes lower numerical values. A rule with priority 999 (Option D) takes precedence over the segmentation rules at priority 1000, allowing traffic if the source and target match.
Additionally, since all VMs lack specific service account customization, they likely use the default compute engine service account. If a rule targets this shared identity, it effectively bypasses tag-based segmentation, making the absence of distinct tags (Option A) a contributing factor to the observed behavior.

## Pregunta 164

Contexto: [topics:197](#topics-197)
You are creating a new infrastructure CI/CD pipeline to deploy hundreds of ephemeral projects in your Google Cloud organization to enable your users to interact with Google Cloud. You want to restrict the use of the default networks in your organization while following Google-recommended best practices. What should you do?

**A.** Enable the constraints/compute.skipDefaultNetworkCreation organization policy constraint at the organization level.

**B.** Create a cron job to trigger a daily Cloud Function to automatically delete all default networks for each project.

**C.** Grant your users the IAM Owner role at the organization level. Create a VPC Service Controls perimeter around the project that restricts the compute.googleapis.com API.

**D.** Only allow your users to use your CI/CD pipeline with a predefined set of infrastructure templates they can deploy to skip the creation of the default networks.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because the `constraints/compute.skipDefaultNetworkCreation` Organization Policy specifically prevents the automatic creation of default networks when new projects are provisioned. This aligns with Google-recommended best practices for restricting default network usage across an organization without manual intervention or custom automation.

## Pregunta 165

Contexto: [topics:197](#topics-197)
You are a security administrator at your company and are responsible for managing access controls (identification, authentication, and authorization) on Google
Cloud. Which Google-recommended best practices should you follow when configuring authentication and authorization? (Choose two.)

**A.** Use Google default encryption.

**B.** Manually add users to Google Cloud.

**C.** Provision users with basic roles using Google's Identity and Access Management (IAM) service.

**D.** Use SSO/SAML integration with Cloud Identity for user authentication and user lifecycle management.

**E.** Provide granular access with predefined roles.

**Respuesta de la fuente:** D, E

**Explicación:** Google recommends using SSO/SAML integration with Cloud Identity (Option D) to streamline user authentication and lifecycle management, ensuring centralized control.
Additionally, providing granular access through predefined roles (Option E) aligns with the Principle of Least Privilege by allowing precise authorization without manual role creation overhead.

## Pregunta 166

Contexto: [topics:197](#topics-197)
You have been tasked with inspecting IP packet data for invalid or malicious content. What should you do?

**A.** Use Packet Mirroring to mirror traffic to and from particular VM instances. Perform inspection using security software that analyzes the mirrored traffic.

**B.** Enable VPC Flow Logs for all subnets in the VPC. Perform inspection on the Flow Logs data using Cloud Logging.

**C.** Configure the Fluentd agent on each VM Instance within the VPC. Perform inspection on the log data using Cloud Logging.

**D.** Configure Google Cloud Armor access logs to perform inspection on the log data.

**Respuesta de la fuente:** A

**Explicación:** Packet Mirroring captures the full packet data, including payloads and headers, allowing for deep inspection of content for invalid or malicious activity. VPC Flow Logs only record metadata about network flows (such as source/destination IPs and ports) and do not capture packet contents, making them insufficient for content inspection.

## Pregunta 167

Contexto: [topics:197](#topics-197)
You have the following resource hierarchy. There is an organization policy at each node in the hierarchy as shown. Which load balancer types are denied in VPC
A?
[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/1b4af3fe779dfc794d07.jpg)
OCR: automatic_unverified · Revisión visual pendiente.
```text
{
“constraint”: “constraints/compute.restrictLoadBalancerCreationForlypes™,
UstPolicy": {
?
Example.com
Organization node
{
“constraint”: “constraints/compute.restrictLoadsalancerCreationtorlypes".
—_—— “ListPolicy”: {
“deniedValues™: [
INTERWAL_TCP_UOP™,
Folder 1 Folder 2 “g
Project 2
“ListPolicy”: (
“dentedvelues”
```

**A.** All load balancer types are denied in accordance with the global node's policy.

**B.** INTERNAL_TCP_UDP, INTERNAL_HTTP_HTTPS is denied in accordance with the folder's policy.

**C.** EXTERNAL_TCP_PROXY, EXTERNAL_SSL_PROXY are denied in accordance with the project's policy.

**D.** EXTERNAL_TCP_PROXY, EXTERNAL_SSL_PROXY, INTERNAL_TCP_UDP, and INTERNAL_HTTP_HTTPS are denied in accordance with the folder and project's policies.

**Respuesta de la fuente:** A

**Explicación:** In Google Cloud Organization Policy hierarchies, policies are inherited by default unless `inheritFromParent` is explicitly set to false. Since the question implies standard inheritance behavior without explicit overrides breaking that chain, the effective policy at VPC A aggregates the constraints from all ancestor nodes (Organization, Folder, and Project). Therefore, any load balancer type denied at any level in the hierarchy is effectively denied at the project level, resulting in all listed types being blocked.

## Pregunta 168

Contexto: [topics:197](#topics-197)
Your security team wants to implement a defense-in-depth approach to protect sensitive data stored in a Cloud Storage bucket. Your team has the following requirements:
✑ The Cloud Storage bucket in Project A can only be readable from Project B.
✑ The Cloud Storage bucket in Project A cannot be accessed from outside the network.
✑ Data in the Cloud Storage bucket cannot be copied to an external Cloud Storage bucket.
What should the security team do?

**A.** Enable domain restricted sharing in an organization policy, and enable uniform bucket-level access on the Cloud Storage bucket.

**B.** Enable VPC Service Controls, create a perimeter around Projects A and B, and include the Cloud Storage API in the Service Perimeter configuration.

**C.** Enable Private Access in both Project A and B's networks with strict firewall rules that allow communication between the networks.

**D.** Enable VPC Peering between Project A and B's networks with strict firewall rules that allow communication between the networks.

**Respuesta de la fuente:** B

**Explicación:** VPC Service Controls establish security perimeters around Google Cloud resources, preventing data exfiltration outside the perimeter. By placing both Project A and Project B within the same perimeter and including Cloud Storage, access is restricted to authorized principals within those projects while blocking external access.

## Pregunta 169

Contexto: [topics:197](#topics-197)
You need to create a VPC that enables your security team to control network resources such as firewall rules. How should you configure the network to allow for separation of duties for network resources?

**A.** Set up multiple VPC networks, and set up multi-NIC virtual appliances to connect the networks.

**B.** Set up VPC Network Peering, and allow developers to peer their network with a Shared VPC.

**C.** Set up a VPC in a project. Assign the Compute Network Admin role to the security team, and assign the Compute Admin role to the developers.

**D.** Set up a Shared VPC where the security team manages the firewall rules, and share the network with developers via service projects.

**Respuesta de la fuente:** D

**Explicación:** Shared VPC allows a central host project to manage network resources, such as firewall rules, while granting service projects access to the network without giving them administrative privileges. This architecture enforces separation of duties by ensuring only the security team (host project admins) can modify network configurations, while developers (service project users) can deploy workloads within that controlled environment.

## Pregunta 170

Contexto: [topics:197](#topics-197)
You are onboarding new users into Cloud Identity and discover that some users have created consumer user accounts using the corporate domain name. How should you manage these consumer user accounts with Cloud Identity?

**A.** Use Google Cloud Directory Sync to convert the unmanaged user accounts.

**B.** Create a new managed user account for each consumer user account.

**C.** Use the transfer tool for unmanaged user accounts.

**D.** Configure single sign-on using a customer's third-party provider.

**Respuesta de la fuente:** C

**Explicación:** Google Cloud Identity provides a specific 'Transfer Unmanaged Users' tool to convert consumer (unmanaged) accounts using the corporate domain into managed organizational accounts.
This tool sends transfer requests to users, allowing them to migrate their data and identity without creating duplicate entries or relying on directory sync tools designed for bulk provisioning.

## Pregunta 171

Contexto: [topics:197](#topics-197)
You have created an OS image that is hardened per your organization's security standards and is being stored in a project managed by the security team. As a
Google Cloud administrator, you need to make sure all VMs in your Google Cloud organization can only use that specific OS image while minimizing operational overhead. What should you do? (Choose two.)

**A.** Grant users the compute.imageUser role in their own projects.

**B.** Grant users the compute.imageUser role in the OS image project.

**C.** Store the image in every project that is spun up in your organization.

**D.** Set up an image access organization policy constraint, and list the security team managed project in the project's allow list.

**E.** Remove VM instance creation permission from users of the projects, and only allow you and your team to create VM instances.

**Respuesta de la fuente:** B, D

**Explicación:** To minimize operational overhead and enforce the use of a specific hardened image, you must first enable access for users to read and instantiate that image from the source project by granting them the compute.imageUser role (Option B). Then, to strictly restrict VMs from using any other images, you apply an Organization Policy constraint on `constraints/compute.vmExternalIpAccess` or specifically `compute.restrictedImageProjects` to whitelist only the security team's project (Option D).

## Pregunta 172

Contexto: [topics:197](#topics-197)
You're developing the incident response plan for your company. You need to define the access strategy that your DevOps team will use when reviewing and investigating a deployment issue in your Google Cloud environment. There are two main requirements:
✑ Least-privilege access must be enforced at all times.
✑ The DevOps team must be able to access the required resources only during the deployment issue.
How should you grant access while following Google-recommended best practices?

**A.** Assign the Project Viewer Identity and Access Management (IAM) role to the DevOps team.

**B.** Create a custom IAM role with limited list/view permissions, and assign it to the DevOps team.

**C.** Create a service account, and grant it the Project Owner IAM role. Give the Service Account User Role on this service account to the DevOps team.

**D.** Create a service account, and grant it limited list/view permissions. Give the Service Account User Role on this service account to the DevOps team.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 173

Contexto: [topics:197](#topics-197)
You are working with a client who plans to migrate their data to Google Cloud. You are responsible for recommending an encryption service to manage their encrypted keys. You have the following requirements:
✑ The master key must be rotated at least once every 45 days.
✑ The solution that stores the master key must be FIPS 140-2 Level 3 validated.
✑ The master key must be stored in multiple regions within the US for redundancy.
Which solution meets these requirements?

**A.** Customer-managed encryption keys with Cloud Key Management Service

**B.** Customer-managed encryption keys with Cloud HSM

**C.** Customer-supplied encryption keys

**D.** Google-managed encryption keys

**Respuesta de la fuente:** B

**Explicación:** Cloud HSM is the only option among the choices that is FIPS 140-2 Level 3 validated, meeting the specific compliance requirement.
Standard Cloud KMS (Option A) typically uses lower validation levels (such as Level 2 or software-based), while Google-managed keys and customer-supplied keys do not provide the managed hardware security module environment required for Level 3 validation.
Cloud HSM also supports automatic key rotation policies and multi-region redundancy, satisfying all stated constraints.

## Pregunta 174

Contexto: [topics:197](#topics-197)
You manage your organization's Security Operations Center (SOC). You currently monitor and detect network traffic anomalies in your VPCs based on network logs. However, you want to explore your environment using network payloads and headers. Which Google Cloud product should you use?

**A.** Cloud IDS

**B.** VPC Service Controls logs

**C.** VPC Flow Logs

**D.** Google Cloud Armor

**E.** Packet Mirroring

**Respuesta de la fuente:** A

**Explicación:** Cloud IDS is the dedicated security product designed to inspect network traffic for anomalies and threats by analyzing both packet headers and payloads.
Unlike Packet Mirroring, which only captures and copies traffic without inherent analysis capabilities, Cloud IDS processes this data to detect malicious activity.

## Pregunta 175

Contexto: [topics:197](#topics-197)
You are consulting with a client that requires end-to-end encryption of application data (including data in transit, data in use, and data at rest) within Google Cloud.
Which options should you utilize to accomplish this? (Choose two.)

**A.** External Key Manager

**B.** Customer-supplied encryption keys

**C.** Hardware Security Module

**D.** Confidential Computing and Istio

**E.** Client-side encryption

**Respuesta de la fuente:** D, E

**Explicación:** Confidential Computing is the only Google Cloud technology explicitly designed to encrypt data while it is being processed (data in use) within protected memory spaces.
Istio provides robust TLS encryption for service-to-service traffic, satisfying the requirement for data in transit between microservices.
Client-side encryption (E) protects data before it reaches GCP but does not inherently secure the data once stored or processed within GCP unless combined with specific application logic, making D and E the most comprehensive architectural pair listed despite nuances regarding 'data at rest' defaults.

## Pregunta 176

Contexto: [topics:197](#topics-197)
You need to enforce a security policy in your Google Cloud organization that prevents users from exposing objects in their buckets externally. There are currently no buckets in your organization. Which solution should you implement proactively to achieve this goal with the least operational overhead?

**A.** Create an hourly cron job to run a Cloud Function that finds public buckets and makes them private.

**B.** Enable the constraints/storage.publicAccessPrevention constraint at the organization level.

**C.** Enable the constraints/storage.uniformBucketLevelAccess constraint at the organization level.

**D.** Create a VPC Service Controls perimeter that protects the storage.googleapis.com service in your projects that contains buckets. Add any new project that contains a bucket to the perimeter.

**Respuesta de la fuente:** B

**Explicación:** Enabling the constraints/storage.publicAccessPrevention organization policy is a proactive measure that prevents all new and existing buckets from being set to publicly accessible via IAM policies or ACLs. This approach eliminates the risk of accidental exposure without requiring manual interventions like cron jobs, VPC Service Controls perimeters, or bucket-level access enforcement.

## Pregunta 177

Contexto: [topics:197](#topics-197)
Your company requires the security and network engineering teams to identify all network anomalies and be able to capture payloads within VPCs. Which method should you use?

**A.** Define an organization policy constraint.

**B.** Configure packet mirroring policies.

**C.** Enable VPC Flow Logs on the subnet.

**D.** Monitor and analyze Cloud Audit Logs.

**Respuesta de la fuente:** B

**Explicación:** VPC Flow Logs only record metadata (source/destination IP, ports) and do not capture packet payloads. Packet mirroring allows you to copy traffic for analysis by security tools, enabling the inspection of actual payload contents to identify anomalies.

## Pregunta 178

Contexto: [topics:197](#topics-197)
An organization wants to track how bonus compensations have changed over time to identify employee outliers and correct earning disparities. This task must be performed without exposing the sensitive compensation data for any individual and must be reversible to identify the outlier.

Which Cloud Data Loss Prevention API technique should you use?

**A.** Cryptographic hashing

**B.** Redaction

**C.** Format-preserving encryption

**D.** Generalization

**Respuesta de la fuente:** C

**Explicación:** Format-preserving encryption (FPE) is the correct choice because it encrypts sensitive data while maintaining its original format, allowing for continued analysis such as sorting and comparison without exposing individual values.
Crucially, FPE is reversible, enabling the organization to decrypt specific records to identify and correct outliers when necessary, satisfying both privacy and auditability requirements.

## Pregunta 179

Contexto: [topics:197](#topics-197)
You need to set up a Cloud Interconnect connection between your company’s on-premises data center and VPC host network. You want to make sure that on-premises applications can only access Google APIs over the Cloud Interconnect and not through the public internet. You are required to only use APIs that are supported by VPC Service Controls to mitigate against exfiltration risk to non-supported APIs. How should you configure the network?

**A.** Enable Private Google Access on the regional subnets and global dynamic routing mode.

**B.** Create a CNAME to map *.googleapis.com to restricted.googleapis.com, and create A records for restricted.googleapis.com mapped to 199.36.153.8/30.

**C.** Use private.googleapis.com to access Google APIs using a set of IP addresses only routable from within Google Cloud, which are advertised as routes over the connection.

**D.** Use restricted googleapis.com to access Google APIs using a set of IP addresses only routable from within Google Cloud, which are advertised as routes over the Cloud Interconnect connection.

**Respuesta de la fuente:** D

**Explicación:** Restricted Google Access (using restricted.googleapis.com) is the specific feature designed to force API traffic over private interconnects while enforcing VPC Service Controls compliance. It ensures that only APIs supporting VPC SC are accessible via these private IPs, explicitly blocking access to non-supported APIs and preventing exfiltration risks through public endpoints.

## Pregunta 180

Contexto: [topics:197](#topics-197)
Your organization develops software involved in many open source projects and is concerned about software supply chain threats. You need to deliver provenance for the build to demonstrate the software is untampered.

What should you do?

**A.** 1. Hire an external auditor to review and provide provenance.
2. Define the scope and conditions.
3. Get support from the Security department or representative.
4. Publish the attestation to your public web page.

**B.** 1. Review the software process.
2. Generate private and public key pairs and use Pretty Good Privacy (PGP) protocols to sign the output software artifacts together with a file containing the address of your enterprise and point of contact.
3. Publish the PGP signed attestation to your public web page.

**C.** 1. Publish the software code on GitHub as open source.
2. Establish a bug bounty program, and encourage the open source community to review, report, and fix the vulnerabilities.

**D.** 1. Generate Supply Chain Levels for Software Artifacts (SLSA) level 3 assurance by using Cloud Build.
2. View the build provenance in the Security insights side panel within the Google Cloud console.

**Respuesta de la fuente:** D

**Explicación:** SLSA (Supply Chain Levels for Software Artifacts) is the industry standard framework designed to prevent supply chain attacks by verifying artifact provenance. Option D correctly leverages Google Cloud Build’s native capabilities to generate SLSA Level 3 provenance attestation, which cryptographically proves that the software build was untampered and originated from verified sources.

## Pregunta 181

Contexto: [topics:197](#topics-197)
Your organization operates Virtual Machines (VMs) with only private IPs in the Virtual Private Cloud (VPC) with internet access through Cloud NAT. Everyday, you must patch all VMs with critical OS updates and provide summary reports.

What should you do?

**A.** Validate that the egress firewall rules allow any outgoing traffic. Log in to each VM and execute OS specific update commands. Configure the Cloud Scheduler job to update with critical patches daily for daily updates.

**B.** Copy the latest patches to the Cloud Storage bucket. Log in to each VM, download the patches from the bucket, and install them.

**C.** Assign public IPs to VMs. Validate that the egress firewall rules allow any outgoing traffic. Log in to each VM, and configure a daily cron job to enable for OS updates at night during low activity periods.

**D.** Ensure that VM Manager is installed and running on the VMs. In the OS patch management service, configure the patch jobs to update with critical patches dally.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because VM Manager is a serverless suite of tools that provides automated OS patch management for large fleets of Compute Engine instances. It allows you to schedule daily patch jobs without manually logging into each VM, adhering to best practices for automation and reduced operational burden.

## Pregunta 182

Contexto: [topics:197](#topics-197)
For compliance reporting purposes, the internal audit department needs you to provide the list of virtual machines (VMs) that have critical operating system (OS) security updates available, but not installed. You must provide this list every six months, and you want to perform this task quickly.

What should you do?

**A.** Run a Security Command Center security scan on all VMs to extract a list of VMs with critical OS vulnerabilities every six months.

**B.** Run a gcloud CLI command from the Command Line Interface (CLI) to extract the VM's OS version information every six months.

**C.** Ensure that the Cloud Logging agent is installed on all VMs, and extract the OS last update log date every six months.

**D.** Ensure the OS Config agent is installed on all VMs and extract the patch status dashboard every six months.

**Respuesta de la fuente:** D

**Explicación:** The OS Config agent is specifically designed to manage and report on the patch status of virtual machines, including identifying available but uninstalled security updates.
By installing this agent, you gain access to the Patch Status dashboard in VM Manager, which directly provides the required compliance data without manual log analysis or incomplete vulnerability scans.

## Pregunta 183

Contexto: [topics:197](#topics-197)
Your company conducts clinical trials and needs to analyze the results of a recent study that are stored in BigQuery. The interval when the medicine was taken contains start and stop dates. The interval data is critical to the analysis, but specific dates may identify a particular batch and introduce bias. You need to obfuscate the start and end dates for each row and preserve the interval data.

What should you do?

**A.** Use date shifting with the context set to the unique ID of the test subject.

**B.** Extract the date using TimePartConfig from each date field and append a random month and year.

**C.** Use bucketing to shift values to a predetermined date based on the initial value.

**D.** Use the FFX mode of format preserving encryption (FPE) and maintain data consistency.

**Respuesta de la fuente:** A

**Explicación:** Date shifting randomly shifts dates by a consistent offset within a specified context (the subject ID), ensuring that while absolute dates are obfuscated, the relative intervals and sequence between start and stop dates remain intact.

This preserves the critical duration data needed for analysis without introducing bias from specific calendar dates, whereas bucketing or encryption would either lose temporal granularity or fail to preserve meaningful interval relationships.

## Pregunta 184

Contexto: [topics:197](#topics-197)
You have a highly sensitive BigQuery workload that contains personally identifiable information (PII) that you want to ensure is not accessible from the internet. To prevent data exfiltration, only requests from authorized IP addresses are allowed to query your BigQuery tables.

What should you do?

**A.** Use service perimeter and create an access level based on the authorized source IP address as the condition.

**B.** Use Google Cloud Armor security policies defining an allowlist of authorized IP addresses at the global HTTPS load balancer.

**C.** Use the Restrict Resource Service Usage organization policy constraint along with Cloud Data Loss Prevention (DLP).

**D.** Use the Restrict allowed Google Cloud APIs and services organization policy constraint along with Cloud Data Loss Prevention (DLP).

**Respuesta de la fuente:** A

**Explicación:** Cloud Armor is designed for frontend traffic at the edge (e.g., HTTP(S) Load Balancers) and cannot control direct access to BigQuery APIs. Service Perimeters, part of BeyondCorp Enterprise/Access Context Manager, create a security boundary that enforces strict access controls on data resources regardless of how they are accessed. By defining an Access Level based on source IP conditions, you ensure that only requests originating from authorized networks can enter the perimeter and query the sensitive BigQuery tables.

## Pregunta 185

Contexto: [topics:197](#topics-197)
Your organization is moving virtual machines (VMs) to Google Cloud. You must ensure that operating system images that are used across your projects are trusted and meet your security requirements.

What should you do?

**A.** Implement an organization policy to enforce that boot disks can only be created from images that come from the trusted image project.

**B.** Implement an organization policy constraint that enables the Shielded VM service on all projects to enforce the trusted image repository usage.

**C.** Create a Cloud Function that is automatically triggered when a new virtual machine is created from the trusted image repository. Verify that the image is not deprecated.

**D.** Automate a security scanner that verifies that no common vulnerabilities and exposures (CVEs) are present in your trusted image repository.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Organization Policies allow you to enforce constraints across all projects in your organization.
Specifically, the `constraints/compute.vmExternalIpAccess` or custom constraints can restrict boot disks to specific allowed source images or projects.
This ensures that only pre-approved, trusted OS images are used for VM creation, satisfying the requirement proactively rather than relying on post-creation scanning.

## Pregunta 186

Contexto: [topics:197](#topics-197)
You have stored company approved compute images in a single Google Cloud project that is used as an image repository. This project is protected with VPC Service Controls and exists in the perimeter along with other projects in your organization. This lets other projects deploy images from the image repository project. A team requires deploying a third-party disk image that is stored in an external Google Cloud organization. You need to grant read access to the disk image so that it can be deployed into the perimeter.

What should you do?

**A.** Allow the external project by using the organizational policy, constraints/compute.trustedImageProjects.

**B.** 1. Update the perimeter.
2. Configure the egressTo field to include the external Google Cloud project number as an allowed resource and the serviceName to compute.googleapis.com.
3. Configure the egressFrom field to set identityType to ANY_IDENTITY.

**C.** 1. Update the perimeter.
2. Configure the ingressFrom field to set identityType to ANY_IDENTITY.
3. Configure the ingressTo field to include the external Google Cloud project number as an allowed resource and the serviceName to compute.googleapis.com.

**D.** 1. Update the perimeter.
2. Configure the egressTo field to set identityType to ANY_IDENTITY.
3. Configure the egressFrom field to include the external Google Cloud project number as an allowed resource and the serviceName to compute.googleapis.com.

**Respuesta de la fuente:** B

**Explicación:** Accessing a resource outside the VPC Service Controls perimeter requires an egress rule, not ingress. The egress rule must specify the destination service (compute.googleapis.com) and resource (external project number) in the 'egressTo' field, while the source identity within the perimeter is defined in 'egressFrom'. Option B correctly configures these fields to allow the internal project to read the external image.

## Pregunta 187

Contexto: [topics:197](#topics-197)
A service account key has been publicly exposed on multiple public code repositories. After reviewing the logs, you notice that the keys were used to generate short-lived credentials. You need to immediately remove access with the service account.

What should you do?

**A.** Delete the compromised service account.

**B.** Disable the compromised service account key.

**C.** Wait until the service account credentials expire automatically.

**D.** Rotate the compromised service account key.

**Respuesta de la fuente:** A

**Explicación:** Disabling a service account key (Option B) does not revoke short-lived credentials that have already been generated using that key.
According to Google Cloud IAM documentation, the only way to immediately invalidate these active short-lived tokens is to delete the entire service account (Option A).
Although disruptive, this is the required remediation step when short-lived credentials derived from a compromised long-lived key are in use.

## Pregunta 188

Contexto: [topics:197](#topics-197)
A company is using Google Kubernetes Engine (GKE) with container images of a mission-critical application. The company wants to scan the images for known security issues and securely share the report with the security team without exposing them outside Google Cloud.

What should you do?

**A.** 1. Enable Container Threat Detection in the Security Command Center Premium tier.
2. Upgrade all clusters that are not on a supported version of GKE to the latest possible GKE version.
3. View and share the results from the Security Command Center.

**B.** 1. Use an open source tool in Cloud Build to scan the images.
2. Upload reports to publicly accessible buckets in Cloud Storage by using gsutil.
3. Share the scan report link with your security department.

**C.** 1. Enable vulnerability scanning in the Artifact Registry settings.
2. Use Cloud Build to build the images.
3. Push the images to the Artifact Registry for automatic scanning.
4. View the reports in the Artifact Registry.

**D.** 1. Get a GitHub subscription.
2. Build the images in Cloud Build and store them in GitHub for automatic scanning.
3. Download the report from GitHub and share with the Security Team.

**Respuesta de la fuente:** C

**Explicación:** Option C is the correct solution because Artifact Registry provides built-in vulnerability scanning for container images upon push, fulfilling the requirement to scan for known security issues. The reports are accessible directly within the Artifact Registry console, allowing secure sharing with the security team inside Google Cloud without exposing data externally or requiring expensive upgrades to Security Command Center Premium.

## Pregunta 189

Contexto: [topics:197](#topics-197)
Your application is deployed as a highly available, cross-region solution behind a global external HTTP(S) load balancer. You notice significant spikes in traffic from multiple IP addresses, but it is unknown whether the IPs are malicious. You are concerned about your application's availability. You want to limit traffic from these clients over a specified time interval.

What should you do?

**A.** Configure a throttle action by using Google Cloud Armor to limit the number of requests per client over a specified time interval.

**B.** Configure a rate_based_ban action by using Google Cloud Armor and set the ban_duration_sec parameter to the specified lime interval.

**C.** Configure a firewall rule in your VPC to throttle traffic from the identified IP addresses.

**D.** Configure a deny action by using Google Cloud Armor to deny the clients that issued too many requests over the specified time interval.

**Respuesta de la fuente:** A

**Explicación:** The requirement is to 'limit' traffic when the malicious nature of IPs is unknown, making a ban or deny action inappropriate as it would block legitimate users.
Google Cloud Armor's throttle action specifically allows you to cap the number of requests per client over a defined time interval without completely denying access, aligning perfectly with the goal.

## Pregunta 190

Contexto: [topics:197](#topics-197)
Your organization is using Active Directory and wants to configure Security Assertion Markup Language (SAML). You must set up and enforce single sign-on (SSO) for all users.

What should you do?

**A.** 1. Create a new SAML profile.
2. Populate the sign-in and sign-out page URLs.
3. Upload the X.509 certificate.
4. Configure Entity ID and ACS URL in your IdP.

**B.** 1. Configure prerequisites for OpenID Connect (OIDC) in your Active Directory (AD) tenant.
2. Verify the AD domain.
3. Decide which users should use SAML.
4. Assign the pre-configured profile to the select organizational units (OUs) and groups.

**C.** 1. Create a new SAML profile.
2. Upload the X.509 certificate.
3. Enable the change password URL.
4. Configure Entity ID and ACS URL in your IdP.

**D.** 1. Manage SAML profile assignments.
2. Enable OpenID Connect (OIDC) in your Active Directory (AD) tenant.
3. Verify the domain.

**Respuesta de la fuente:** A

**Explicación:** Configuring SAML-based Single Sign-On (SSO) requires establishing a trust relationship between the Identity Provider and Service Provider.
This is achieved by creating a SAML profile, uploading an X.509 certificate for encryption/signing, and configuring specific endpoints including sign-in/sign-out URLs, Entity ID, and ACS URL.

## Pregunta 191

Contexto: [topics:197](#topics-197)
Employees at your company use their personal computers to access your organization's Google Cloud console. You need to ensure that users can only access the Google Cloud console from their corporate-issued devices and verify that they have a valid enterprise certificate.

What should you do?

**A.** Implement an Access Policy in BeyondCorp Enterprise to verify the device certificate. Create an access binding with the access policy just created.

**B.** Implement a VPC firewall policy. Activate packet inspection and create an allow rule to validate and verify the device certificate.

**C.** Implement an organization policy to verify the certificate from the access context.

**D.** Implement an Identity and Access Management (IAM) conditional policy to verify the device certificate.

**Respuesta de la fuente:** A

**Explicación:** BeyondCorp Enterprise implements a zero-trust security model that verifies device health and identity before granting access to resources.
By creating an Access Policy within Access Context Manager, you can define conditions requiring valid enterprise certificates and corporate-issued device attributes.
Binding this policy ensures that only users meeting these specific criteria can access the Google Cloud console.

## Pregunta 192

Contexto: [topics:197](#topics-197)
Your organization is rolling out a new continuous integration and delivery (CI/CD) process to deploy infrastructure and applications in Google Cloud. Many teams will use their own instances of the CI/CD workflow. It will run on Google Kubernetes Engine (GKE). The CI/CD pipelines must be designed to securely access Google Cloud APIs.

What should you do?

**A.** 1. Create two service accounts, one for the infrastructure and one for the application deployment.
2. Use workload identities to let the pods run the two pipelines and authenticate with the service accounts.
3. Run the infrastructure and application pipelines in separate namespaces.

**B.** 1. Create a dedicated service account for the CI/CD pipelines.
2. Run the deployment pipelines in a dedicated nodes pool in the GKE cluster.
3. Use the service account that you created as identity for the nodes in the pool to authenticate to the Google Cloud APIs.

**C.** 1. Create individual service accounts for each deployment pipeline.
2. Add an identifier for the pipeline in the service account naming convention.
3. Ensure each pipeline runs on dedicated pods.
4. Use workload identity to map a deployment pipeline pod with a service account.

**D.** 1. Create service accounts for each deployment pipeline.
2. Generate private keys for the service accounts.
3. Securely store the private keys as Kubernetes secrets accessible only by the pods that run the specific deploy pipeline.

**Respuesta de la fuente:** C

**Explicación:** Option C is the most secure approach because it adheres strictly to the principle of least privilege by creating individual service accounts for each pipeline, ensuring that compromised credentials have minimal blast radius.
It utilizes Workload Identity to allow Kubernetes workloads to authenticate with Google Cloud APIs without managing static private key files (as in Option D) or relying on broader node-level permissions (as in Option B).
While Option A is a good practice, Option C provides greater granularity by isolating permissions per pipeline rather than just separating infrastructure and application roles, which aligns with multi-tenant CI/CD best practices.

## Pregunta 193

Contexto: [topics:197](#topics-197)
Your organization's Customers must scan and upload the contract and their driver license into a web portal in Cloud Storage. You must remove all personally identifiable information (PII) from files that are older than 12 months. Also, you must archive the anonymized files for retention purposes.

What should you do?

**A.** Set a time to live (TTL) of 12 months for the files in the Cloud Storage bucket that removes PII and moves the files to the archive storage class.

**B.** Create a Cloud Data loss Prevention (DLP) inspection job that de-identifies PII in files created more than 12 months ago and archives them to another Cloud Storage bucket. Delete the original files.

**C.** Configure the Autoclass feature of the Cloud Storage bucket to de-identify PII. Archive the files that are older than 12 months. Delete the original files.

**D.** Schedule a Cloud Key Management Service (KMS) rotation period of 12 months for the encryption keys of the Cloud Storage files containing PII to de-identify them. Delete the original keys.

**Respuesta de la fuente:** B

**Explicación:** Cloud Data Loss Prevention (DLP) is the appropriate service for identifying and de-identifying personally identifiable information (PII) in unstructured data like contracts.
Option B correctly leverages DLP inspection jobs to redact PII from older files, move the anonymized versions to an archive location, and delete the originals to ensure compliance.
Other options are incorrect because TTL and Autoclass manage storage lifecycle/class, not content privacy, and KMS manages encryption keys, which does not remove PII from file contents.

## Pregunta 194

Contexto: [topics:197](#topics-197)
You plan to synchronize identities to Cloud Identity from a third-party identity provider (IdP). You discovered that some employees used their corporate email address to set up consumer accounts to access Google services. You need to ensure that the organization has control over the configuration, security, and lifecycle of these consumer accounts.

What should you do? (Choose two.)

**A.** Mandate that those corporate employees delete their unmanaged consumer accounts.

**B.** Reconcile accounts that exist in Cloud Identity but not in the third-party IdP.

**C.** Evict the unmanaged consumer accounts in the third-party IdP before you sync identities.

**D.** Use Google Cloud Directory Sync (GCDS) to migrate the unmanaged consumer accounts' emails as user aliases.

**E.** Use the transfer tool to invite those corporate employees to transfer their unmanaged consumer accounts to the corporate domain.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 195

Contexto: [topics:197](#topics-197)
You are auditing all your Google Cloud resources in the production project. You want to identify all principals who can change firewall rules.

What should you do?

**A.** Use Policy Analyzer to query the permissions compute.firewalls.get or compute.firewalls.list.

**B.** Use Firewall Insights to understand your firewall rules usage patterns.

**C.** Reference the Security Health Analytics – Firewall Vulnerability Findings in the Security Command Center.

**D.** Use Policy Analyzer to query the permissions compute.firewalls.create or compute.firewalls.update or compute.firewalls.delete.

**Respuesta de la fuente:** D

**Explicación:** Policy Analyzer is the correct tool for determining which principals have specific access to resources. To identify those who can 'change' firewall rules, you must query write permissions like compute.firewalls.create, compute.firewalls.update, and compute.firewalls.delete. Options A lists read-only permissions, while B and C focus on usage patterns and vulnerability detection rather than IAM access.

## Pregunta 196

Contexto: [topics:197](#topics-197)
Your organization previously stored files in Cloud Storage by using Google Managed Encryption Keys (GMEK), but has recently updated the internal policy to require Customer Managed Encryption Keys (CMEK). You need to re-encrypt the files quickly and efficiently with minimal cost.

What should you do?

**A.** Reupload the files to the same Cloud Storage bucket specifying a key file by using gsutil.

**B.** Encrypt the files locally, and then use gsutil to upload the files to a new bucket.

**C.** Copy the files to a new bucket with CMEK enabled in a secondary region.

**D.** Change the encryption type on the bucket to CMEK, and rewrite the objects.

**Respuesta de la fuente:** D

**Explicación:** Changing the bucket's default encryption key to CMEK ensures all new objects are encrypted correctly.
Rewriting existing objects is required to re-encrypt them with the new key, which is the standard Google Cloud procedure for this task.
This approach avoids the overhead and potential data transfer costs associated with copying to a new bucket or region.

## Pregunta 197

Contexto: [topics:197](#topics-197)
You run applications on Cloud Run. You already enabled container analysis for vulnerability scanning. However, you are concerned about the lack of control on the applications that are deployed. You must ensure that only trusted container images are deployed on Cloud Run.

What should you do? (Choose two.)

**A.** Enable Binary Authorization on the existing Cloud Run service.

**B.** Set the organization policy constraint constraints/run.allowedBinaryAuthorizationPolicies to the list or allowed Binary Authorization policy names.

**C.** Enable Binary Authorization on the existing Kubernetes cluster.

**D.** Use Cloud Run breakglass to deploy an image that meets the Binary Authorization policy by default.

**E.** Set the organization policy constraint constraints/compute.trustedImageProjects to the list of projects that contain the trusted container images.

**Respuesta de la fuente:** A, B

**Explicación:** To enforce that only trusted images are deployed to Cloud Run, you must first enable Binary Authorization on the specific Cloud Run service (Option A).
Then, you need to configure the organization policy constraint `constraints/run.allowedBinaryAuthorizationPolicies` (Option B) to specify which Binary Authorization policies govern the deployment.
This combination ensures that deployments are evaluated against the defined trust policies before being allowed.

## Pregunta 198

Contexto: [topics:197](#topics-197)
Your organization has on-premises hosts that need to access Google Cloud APIs. You must enforce private connectivity between these hosts, minimize costs, and optimize for operational efficiency.

What should you do?

**A.** Set up VPC peering between the hosts on-premises and the VPC through the internet.

**B.** Route all on-premises traffic to Google Cloud through an IPsec VPN tunnel to a VPC with Private Google Access enabled.

**C.** Enforce a security policy that mandates all applications to encrypt data with a Cloud Key Management Service (KMS) key before you send it over the network.

**D.** Route all on-premises traffic to Google Cloud through a dedicated or Partner Interconnect to a VPC with Private Google Access enabled.

**Respuesta de la fuente:** B

**Explicación:** Option B is the correct choice because Cloud VPN provides private connectivity via IPsec tunnels at a significantly lower cost than Dedicated or Partner Interconnect.
Additionally, enabling Private Google Access on the VPC ensures that traffic destined for Google APIs does not traverse the public internet, satisfying the security and operational efficiency requirements.

## Pregunta 199

Contexto: [topics:197](#topics-197)
As part of your organization's zero trust strategy, you use Identity-Aware Proxy (IAP) to protect multiple applications. You need to ingest logs into a Security Information and Event Management (SIEM) system so that you are alerted to possible intrusions.

Which logs should you analyze?

**A.** Data Access audit logs

**B.** Policy Denied audit logs

**C.** Cloud Identity user log events

**D.** Admin Activity audit logs

**Respuesta de la fuente:** A

**Explicación:** Identity-Aware Proxy (IAP) generates Data Access audit logs that record every request to protected resources, including the outcome of the access control evaluation.

These logs contain critical details such as whether access was authorized or denied, allowing SIEM systems to detect successful intrusions and blocked attempts for comprehensive security monitoring.

## Pregunta 200

Contexto: [topics:197](#topics-197)
Your company must follow industry specific regulations. Therefore, you need to enforce customer-managed encryption keys (CMEK) for all new Cloud Storage resources in the organization called org1.

What command should you execute?

**A.** •	organization poli-cy:constraints/gcp.restrictStorageNonCmekServices
•	binding at: org1
•	policy type: allow
•	policy value: all supported services

**B.** •	organization policy: con-straints/gcp.restrictNonCmekServices
•	binding at: org1
•	policy type: deny
•	policy value: storage.googleapis.com

**C.** •	organization policy: con-straints/gcp.restrictStorageNonCmekServices
•	binding at: org1
•	policy type: deny
•	policy value: storage.googleapis.com

**D.** •	organization policy: con-straints/gcp.restrictNonCmekServices
•	binding at: org1
•	policy type: allow
•	policy value: storage.googleapis.com

**Respuesta de la fuente:** B

**Explicación:** To enforce CMEK for specific services like Cloud Storage, the organization policy constraint `constraints/gcp.restrictNonCmekServices` must be used. This is a list constraint that requires setting the policy type to `DENY` and specifying the service name (`storage.googleapis.com`) in the allowed values list to block resource creation without customer-managed keys.

## Pregunta 201

Contexto: [topics:197](#topics-197)
Your company's Google Cloud organization has about 200 projects and 1,500 virtual machines. There is no uniform strategy for logs and events management, which reduces visibility for your security operations team. You need to design a logs management solution that provides visibility and allows the security team to view the environment's configuration.

What should you do?

**A.** 1. Create a dedicated log sink for each project that is in scope.
2. Use a BigQuery dataset with time partitioning enabled as a destination of the log sinks.
3. Deploy alerts based on log metrics in every project.
4. Grant the role "Monitoring Viewer" to the security operations team in each project.

**B.** 1. Create one log sink at the organization level that includes all the child resources.
2. Use as destination a Pub/Sub topic to ingest the logs into the security information and event. management (SIEM) on-premises, and ensure that the right team can access the SIEM.
3. Grant the Viewer role at organization level to the security operations team.

**C.** 1. Enable network logs and data access logs for all resources in the "Production" folder.
2. Do not create log sinks to avoid unnecessary costs and latency.
3. Grant the roles "Logs Viewer" and "Browser" at project level to the security operations team.

**D.** 1. Create one sink for the "Production" folder that includes child resources and one sink for the logs ingested at the organization level that excludes child resources.
2. As destination, use a log bucket with a minimum retention period of 90 days in a project that can be accessed by the security team.
3. Grant the security operations team the role of Security Reviewer at organization level.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because creating a single log sink at the organization level centralizes logging for all 200 projects efficiently, avoiding the operational overhead of managing individual sinks. Sending logs to a SIEM via Pub/Sub enables advanced analysis and configuration visibility required by the security team.
In contrast, Option A creates excessive complexity with per-project sinks, Option C fails to stream logs effectively, and Option D's specific retention and role choices are less aligned with standard centralized SIEM integration patterns for broad visibility.

## Pregunta 202

Contexto: [topics:197](#topics-197)
Your Google Cloud organization allows for administrative capabilities to be distributed to each team through provision of a Google Cloud project with Owner role (roles/owner). The organization contains thousands of Google Cloud projects. Security Command Center Premium has surfaced multiple OPEN_MYSQL_PORT findings. You are enforcing the guardrails and need to prevent these types of common misconfigurations.

What should you do?

**A.** Create a hierarchical firewall policy configured at the organization to deny all connections from 0.0.0.0/0.

**B.** Create a hierarchical firewall policy configured at the organization to allow connections only from internal IP ranges.

**C.** Create a Google Cloud Armor security policy to deny traffic from 0.0.0.0/0.

**D.** Create a firewall rule for each virtual private cloud (VPC) to deny traffic from 0.0.0.0/0 with priority 0.

**Respuesta de la fuente:** B

**Explicación:** Option B is the correct remediation strategy for OPEN_MYSQL_PORT findings because it restricts MySQL access to internal IP ranges, preventing exposure to the public internet while maintaining necessary internal connectivity.
Unlike Option A, which creates an overly broad deny-all rule that would likely break legitimate external traffic and requires complex exceptions, Option B specifically targets the security risk of public database exposure.
Hierarchical firewall policies allow this guardrail to be enforced across thousands of projects consistently without managing individual VPC rules (Option D) or using incorrect services like Cloud Armor (Option C).

## Pregunta 203

Contexto: [topics:197](#topics-197)
Your organization must comply with the regulation to keep instance logging data within Europe. Your workloads will be hosted in the Netherlands in region europe-west4 in a new project. You must configure Cloud Logging to keep your data in the country.

What should you do?

**A.** Configure the organization policy constraint gcp.resourceLocations to europe-west4.

**B.** Configure log sink to export all logs into a Cloud Storage bucket in europe-west4.

**C.** Create a new log bucket in europe-west4, and redirect the _Default bucket to the new bucket.

**D.** Set the logging storage region to europe-west4 by using the gcloud CLI logging settings update.

**Respuesta de la fuente:** C

**Explicación:** To ensure logs are stored in a specific region like europe-west4, you must create a log bucket in that region because buckets are region-specific resources.

You then redirect the _Default sink to this new bucket so that incoming logs are written directly to it, keeping the data within the Netherlands as required.

Option D is incorrect because default settings apply organization-wide, which does not satisfy the specific requirement for this new project's workloads.

## Pregunta 204

Contexto: [topics:197](#topics-197)
You are using Security Command Center (SCC) to protect your workloads and receive alerts for suspected security breaches at your company. You need to detect cryptocurrency mining software.

Which SCC service should you use?

**A.** Virtual Machine Threat Detection

**B.** Container Threat Detection

**C.** Rapid Vulnerability Detection

**D.** Web Security Scanner

**Respuesta de la fuente:** A

**Explicación:** Virtual Machine Threat Detection is the specific SCC service designed to scan Compute Engine VM instances for potentially malicious applications.
It explicitly includes detection capabilities for cryptocurrency mining software and kernel-mode rootkits.
Other options focus on containers, vulnerability scanning, or web security, which do not address in-VM crypto-mining detection.

## Pregunta 205

Contexto: [topics:197](#topics-197)
You are running applications outside Google Cloud that need access to Google Cloud resources. You are using workload identity federation to grant external identities Identity and Access Management (IAM) roles to eliminate the maintenance and security burden associated with service account keys. You must protect against attempts to spoof another user's identity and gain unauthorized access to Google Cloud resources.

What should you do? (Choose two.)

**A.** Enable data access logs for IAM APIs.

**B.** Limit the number of external identities that can impersonate a service account.

**C.** Use a dedicated project to manage workload identity pools and providers.

**D.** Use immutable attributes in attribute mappings.

**E.** Limit the resources that a service account can access.

**Respuesta de la fuente:** C, D

**Explicación:** To prevent identity spoofing in Workload Identity Federation, you should use a dedicated project to manage pools and providers (Option C), centralizing control and restricting who can create or modify trust configurations. Additionally, using immutable attributes in attribute mappings (Option D) ensures that critical identity claims cannot be altered by the external identity provider, thereby preventing attackers from forging valid credentials to impersonate other users.

## Pregunta 206

Contexto: [topics:197](#topics-197)
You manage a BigQuery analytical data warehouse in your organization. You want to keep data for all your customers in a common table while you also restrict query access based on rows and columns permissions. Non-query operations should not be supported.

What should you do? (Choose two.)

**A.** Create row-level access policies to restrict the result data when you run queries with the filter expression set to TRUE.

**B.** Configure column-level encryption by using Authenticated Encryption with Associated Data (AEAD) functions with Cloud Key Management Service (KMS) to control access to columns at query runtime.

**C.** Create row-level access policies to restrict the result data when you run queries with the filter expression set to FALSE.

**D.** Configure dynamic data masking rules to control access to columns at query runtime.

**E.** Create column-level policy tags to control access to columns at query runtime.

**Respuesta de la fuente:** C, E

**Explicación:** Option C is correct because setting the filter expression to FALSE in row-level access policies ensures that data remains visible during non-query operations (like schema inspection) while restricting visibility during actual queries.
Option E is correct as Column-Level Security via policy tags allows you to control access to specific columns at query runtime, satisfying the requirement for column-based permissions.

## Pregunta 207

Contexto: [topics:197](#topics-197)
Your DevOps team uses Packer to build Compute Engine images by using this process:

1. Create an ephemeral Compute Engine VM.
2. Copy a binary from a Cloud Storage bucket to the VM's file system.
3. Update the VM's package manager.
4. Install external packages from the internet onto the VM.

Your security team just enabled the organizational policy, constraints/ compute.vmExternalIpAccess, to restrict the usage of public IP Addresses on VMs. In response, your DevOps team updated their scripts to remove public IP addresses on the Compute Engine VMs; however, the build pipeline is failing due to connectivity issues.

What should you do? (Choose two.)

**A.** Provision an HTTP load balancer with the VM in an unmanaged instance group to allow inbound connections from the internet to your VM.

**B.** Provision a Cloud NAT instance in the same VPC and region as the Compute Engine VM.

**C.** Enable Private Google Access on the subnet that the Compute Engine VM is deployed within.

**D.** Update the VPC routes to allow traffic to and from the internet.

**E.** Provision a Cloud VPN tunnel in the same VPC and region as the Compute Engine VM.

**Respuesta de la fuente:** B, C

**Explicación:** The build process requires outbound internet access for package installation and private access to Cloud Storage for binary retrieval, both while lacking a public IP.

Option B (Cloud NAT) enables stateless outbound internet connectivity for VMs without external IPs, resolving the package manager update failure.

Option C (Private Google Access) allows the VM to reach Google APIs and Cloud Storage over the private network range, ensuring the binary copy step succeeds without needing a public IP.

## Pregunta 208

Contexto: [topics:197](#topics-197)
Your organization recently activated the Security Command Center (SCC) standard tier. There are a few Cloud Storage buckets that were accidentally made accessible to the public. You need to investigate the impact of the incident and remediate it.

What should you do?

**A.** 1. Remove the Identity and Access Management (IAM) granting access to all Users from the buckets.
2. Apply the organization policy storage.uniformBucketLevelAccess to prevent regressions.
3. Query the data access logs to report on unauthorized access.

**B.** 1. Change permissions to limit access for authorized users.
2. Enforce a VPC Service Controls perimeter around all the production projects to immediately stop any unauthorized access.
3. Review the administrator activity audit logs to report on any unauthorized access.

**C.** 1. Change the bucket permissions to limit access.
2. Query the bucket's usage logs to report on unauthorized access to the data.
3. Enforce the organization policy storage.publicAccessPrevention to avoid regressions.

**D.** 1. Change bucket permissions to limit access.
2. Query the data access audit logs for any unauthorized access to the buckets.
3. After the misconfiguration is corrected, mute the finding in the Security Command Center.

**Respuesta de la fuente:** C

**Explicación:** The correct approach is to immediately revoke public access by changing bucket permissions. To investigate the impact of public exposure (allUsers/allAuthenticatedUsers), you must query usage logs, as standard audit logs do not track anonymous access events. Finally, enforcing the storage.publicAccessPrevention organization policy ensures that buckets cannot be accidentally made public again.

## Pregunta 209

Contexto: [topics:197](#topics-197)
Your organization is transitioning to Google Cloud. You want to ensure that only trusted container images are deployed on Google Kubernetes Engine (GKE) clusters in a project. The containers must be deployed from a centrally managed Container Registry and signed by a trusted authority.

What should you do? (Choose two.)

**A.** Enable Container Threat Detection in the Security Command Center (SCC) for the project.

**B.** Configure the trusted image organization policy constraint for the project.

**C.** Create a custom organization policy constraint to enforce Binary Authorization for Google Kubernetes Engine (GKE).

**D.** Enable PodSecurity standards, and set them to Restricted.

**E.** Configure the Binary Authorization policy with respective attestations for the project.

**Respuesta de la fuente:** C, E

**Explicación:** Option E is correct because Binary Authorization with attestations enforces that only container images signed by trusted authorities are deployed to GKE.
Option C is correct because creating a custom organization policy constraint is the mechanism to enforce this Binary Authorization requirement at the project level, ensuring no unsigned images can bypass the policy.
Options A and D focus on threat detection and runtime security standards respectively, not image provenance enforcement. Option B refers to Compute Engine disk images, not container images.

## Pregunta 210

Contexto: [topics:197](#topics-197)
Your company uses Google Cloud and has publicly exposed network assets. You want to discover the assets and perform a security audit on these assets by using a software tool in the least amount of time.

What should you do?

**A.** Run a platform security scanner on all instances in the organization.

**B.** Identify all external assets by using Cloud Asset Inventory, and then run a network security scanner against them.

**C.** Contact a Google approved security vendor to perform the audit.

**D.** Notify Google about the pending audit, and wait for confirmation before performing the scan.

**Respuesta de la fuente:** B

**Explicación:** Cloud Asset Inventory provides a comprehensive view of all resources, enabling rapid identification of publicly exposed assets without manual discovery. Once identified, running a network security scanner specifically against these external assets targets the audit scope efficiently, satisfying the requirement for the least amount of time.

## Pregunta 211

Contexto: [topics:197](#topics-197)
Your organization wants to be compliant with the General Data Protection Regulation (GDPR) on Google Cloud. You must implement data residency and operational sovereignty in the EU.

What should you do? (Choose two.)

**A.** Limit the physical location of a new resource with the Organization Policy Service "resource locations constraint."

**B.** Use Cloud IDS to get east-west and north-south traffic visibility in the EU to monitor intra-VPC and inter-VPC communication.

**C.** Limit Google personnel access based on predefined attributes such as their citizenship or geographic location by using Key Access Justifications.

**D.** Use identity federation to limit access to Google Cloud resources from non-EU entities.

**E.** Use VPC Flow Logs to monitor intra-VPC and inter-VPC traffic in the EU.

**Respuesta de la fuente:** A, C

**Explicación:** Option A ensures data residency by using Organization Policies to constrain resource creation to EU regions, preventing accidental deployment outside the required jurisdiction.
Option C addresses operational sovereignty by leveraging Key Access Justifications in Assured Workloads to restrict Google personnel access based on attributes like citizenship or location, aligning with GDPR's strict data handling requirements.

## Pregunta 212

Contexto: [topics:197](#topics-197)
Your company is moving to Google Cloud. You plan to sync your users first by using Google Cloud Directory Sync (GCDS). Some employees have already created Google Cloud accounts by using their company email addresses that were created outside of GCDS. You must create your users on Cloud Identity.

What should you do?

**A.** Configure GCDS and use GCDS search rules to sync these users.

**B.** Use the transfer tool to migrate unmanaged users.

**C.** Write a custom script to identify existing Google Cloud users and call the Admin SDK: Directory API to transfer their account.

**D.** Configure GCDS and use GCDS exclusion rules to ensure users are not suspended.

**Respuesta de la fuente:** B

**Explicación:** The correct approach is to use the transfer tool (Choice B), which is specifically designed by Google to migrate unmanaged user accounts into a managed Cloud Identity domain. This built-in tool handles the transition from personal or unmanaged Google Accounts to organization-managed identities seamlessly, whereas GCDS syncs from an external directory source and does not inherently convert existing unmanaged accounts.

## Pregunta 213

Contexto: [topics:197](#topics-197)
Your organization is using GitHub Actions as a continuous integration and delivery (CI/CD) platform. You must enable access to Google Cloud resources from the CI/CD pipelines in the most secure way.

What should you do?

**A.** Create a service account key, and add it to the GitHub pipeline configuration file.

**B.** Create a service account key, and add it to the GitHub repository content.

**C.** Configure a Google Kubernetes Engine cluster that uses Workload Identity to supply credentials to GitHub.

**D.** Configure workload identity federation to use GitHub as an identity pool provider.

**Respuesta de la fuente:** D

**Explicación:** Workload Identity Federation is the recommended secure method because it eliminates the need to manage long-lived service account keys, which poses a security risk if compromised or leaked.
By configuring GitHub as an identity pool provider, Google Cloud trusts GitHub's OIDC tokens directly, ensuring that credentials are short-lived and automatically rotated without manual intervention.

## Pregunta 214

Contexto: [topics:197](#topics-197)
Your organization processes sensitive health information. You want to ensure that data is encrypted while in use by the virtual machines (VMs). You must create a policy that is enforced across the entire organization.

What should you do?

**A.** Implement an organization policy that ensures that all VM resources created across your organization use customer-managed encryption keys (CMEK) protection.

**B.** Implement an organization policy that ensures all VM resources created across your organization are Confidential VM instances.

**C.** Implement an organization policy that ensures that all VM resources created across your organization use Cloud External Key Manager (EKM) protection.

**D.** No action is necessary because Google encrypts data while it is in use by default.

**Respuesta de la fuente:** B

**Explicación:** Confidential VMs utilize hardware-based memory encryption (such as AMD SEV) to protect data while it is in use within the VM's RAM, addressing the specific requirement for in-use encryption. Standard CMEK or EKM solutions only encrypt data at rest and in transit, leaving it vulnerable while processed in memory. Implementing an organization policy constraint ensures this protection is uniformly enforced across all VM resources in the organization.

## Pregunta 215

Contexto: [topics:197](#topics-197)
You are a Cloud Identity administrator for your organization. In your Google Cloud environment, groups are used to manage user permissions. Each application team has a dedicated group. Your team is responsible for creating these groups and the application teams can manage the team members on their own through the Google Cloud console. You must ensure that the application teams can only add users from within your organization to their groups.

What should you do?

**A.** Change the configuration of the relevant groups in the Google Workspace Admin console to prevent external users from being added to the group.

**B.** Set an Identity and Access Management (IAM) policy that includes a condition that restricts group membership to user principals that belong to your organization.

**C.** Define an Identity and Access Management (IAM) deny policy that denies the assignment of principals that are outside your organization to the groups in scope.

**D.** Export the Cloud Identity logs to BigQuery. Configure an alert for external members added to groups. Have the alert trigger a Cloud Function instance that removes the external members from the group.

**Respuesta de la fuente:** A

**Explicación:** To restrict group membership to internal users only, you should configure the specific Google Workspace settings for those groups.
Google Workspace Admin Console provides a 'Membership type' setting that allows administrators to limit who can join or be added to a group, specifically preventing external users from being members.
IAM policies (Options B and C) manage resource access permissions, not the internal membership composition of identity groups.

## Pregunta 216

Contexto: [topics:197](#topics-197)
Your organization wants to be continuously evaluated against CIS Google Cloud Computing Foundations Benchmark v1.3.0 (CIS Google Cloud Foundation 1.3). Some of the controls are irrelevant to your organization and must be disregarded in evaluation. You need to create an automated system or process to ensure that only the relevant controls are evaluated.

What should you do?

**A.** Mark all security findings that are irrelevant with a tag and a value that indicates a security exception. Select all marked findings, and mute them on the console every time they appear. Activate Security Command Center (SCC) Premium.

**B.** Activate Security Command Center (SCC) Premium. Create a rule to mute the security findings in SCC so they are not evaluated.

**C.** Download all findings from Security Command Center (SCC) to a CSV file. Mark the findings that are part of CIS Google Cloud Foundation 1.3 in the file. Ignore the entries that are irrelevant and out of scope for the company.

**D.** Ask an external audit company to provide independent reports including needed CIS benchmarks. In the scope of the audit, clarify that some of the controls are not needed and must be disregarded.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Security Command Center Premium provides the 'Muting Rules' feature, which allows for the automated suppression of specific security findings based on predefined criteria. This automation ensures that irrelevant CIS controls are consistently excluded from evaluation without requiring manual intervention for each instance, unlike Option A. Options C and D rely on manual processes or external audits, failing to meet the requirement for an automated system.

## Pregunta 217

Contexto: [topics:197](#topics-197)
You are routing all your internet facing traffic from Google Cloud through your on-premises internet connection. You want to accomplish this goal securely and with the highest bandwidth possible.

What should you do?

**A.** Create an HA VPN connection to Google Cloud. Replace the default 0.0.0.0/0 route.

**B.** Create a routing VM in Compute Engine. Configure the default route with the VM as the next hop.

**C.** Configure Cloud Interconnect with HA VPN. Replace the default 0.0.0.0/0 route to an on-premises destination.

**D.** Configure Cloud Interconnect and route traffic through an on-premises firewall.

**Respuesta de la fuente:** D

**Explicación:** Cloud Interconnect provides dedicated, high-bandwidth private connectivity (up to 200 Gbps), satisfying the requirement for the highest bandwidth compared to HA VPN's ~3 Gbps limit.
Routing this traffic through an on-premises firewall ensures centralized security inspection and policy enforcement, meeting the secure routing goal without unnecessary complexity.

## Pregunta 218

Contexto: [topics:197](#topics-197)
Your organization uses Google Workspace Enterprise Edition for authentication. You are concerned about employees leaving their laptops unattended for extended periods of time after authenticating into Google Cloud. You must prevent malicious people from using an employee's unattended laptop to modify their environment.

What should you do?

**A.** Create a policy that requires employees to not leave their sessions open for long durations.

**B.** Review and disable unnecessary Google Cloud APIs.

**C.** Require strong passwords and 2SV through a security token or Google authenticator.

**D.** Set the session length timeout for Google Cloud services to a shorter duration.

**Respuesta de la fuente:** D

**Explicación:** The scenario specifically highlights unattended laptops and the risk of unauthorized access during those idle periods. Setting a shorter session timeout (Option D) automatically logs out inactive users, invalidating their credentials before a malicious actor can utilize the unattended session. Other options like policies (A) or strong passwords (C) do not technically enforce immediate disconnection upon user absence.

## Pregunta 219

Contexto: [topics:197](#topics-197)
You are migrating an on-premises data warehouse to BigQuery, Cloud SQL, and Cloud Storage. You need to configure security services in the data warehouse. Your company compliance policies mandate that the data warehouse must:

•	Protect data at rest with full lifecycle management on cryptographic keys.
•	Implement a separate key management provider from data management.
•	Provide visibility into all encryption key requests.

What services should be included in the data warehouse implementation? (Choose two.)

**A.** Customer-managed encryption keys

**B.** Customer-Supplied Encryption Keys

**C.** Key Access Justifications

**D.** Access Transparency and Approval

**E.** Cloud External Key Manager

**Respuesta de la fuente:** C, E

**Explicación:** Cloud External Key Manager (KEK) satisfies the requirement for a separate key management provider and full lifecycle control by allowing keys to be stored outside Google Cloud infrastructure. Key Access Justifications provides the necessary visibility into all encryption key requests by requiring real-time justification for decryption operations.

## Pregunta 220

Contexto: [topics:197](#topics-197)
You manage one of your organization's Google Cloud projects (Project A). A VPC Service Control (SC) perimeter is blocking API access requests to this project, including Pub/Sub. A resource running under a service account in another project (Project B) needs to collect messages from a Pub/Sub topic in your project. Project B is not included in a VPC SC perimeter. You need to provide access from Project B to the Pub/Sub topic in Project A using the principle of least privilege.

What should you do?

**A.** Configure an ingress policy for the perimeter in Project A, and allow access for the service account in Project B to collect messages.

**B.** Create an access level that allows a developer in Project B to subscribe to the Pub/Sub topic that is located in Project A.

**C.** Create a perimeter bridge between Project A and Project B to allow the required communication between both projects.

**D.** Remove the Pub/Sub API from the list of restricted services in the perimeter configuration for Project A.

**Respuesta de la fuente:** A

**Explicación:** A perimeter bridge (Option C) requires both Project A and Project B to be part of distinct VPC Service Perimeters; since Project B is not in a perimeter, a bridge cannot be established. Configuring an ingress policy (Option A) allows specific external service accounts, like the one in Project B, to access resources within the restricted perimeter, satisfying the least privilege requirement without removing security controls.

## Pregunta 221

Contexto: [topics:197](#topics-197)
You define central security controls in your Google Cloud environment. For one of the folders in your organization, you set an organizational policy to deny the assignment of external IP addresses to VMs. Two days later, you receive an alert about a new VM with an external IP address under that folder.

What could have caused this alert?

**A.** The VM was created with a static external IP address that was reserved in the project before the organizational policy rule was set.

**B.** The organizational policy constraint wasn't properly enforced and is running in "dry run" mode.

**C.** A project level, the organizational policy control has been overwritten with an "allow" value.

**D.** The policy constraint on the folder level does not have any effect because of an "allow" value for that constraint on the organizational level.

**Respuesta de la fuente:** C

**Explicación:** Organizational policies in Google Cloud operate on a hierarchy where lower levels (like projects) can override or define specific behaviors relative to their parent, provided the constraint allows it. If the policy is set at the folder level but subsequently overridden at the project level with an 'allow' value, VMs within that project can be assigned external IPs despite the folder-level denial.
This override mechanism explains why a VM could exist with an external IP under the folder: the project-level configuration took precedence or explicitly permitted the action.

## Pregunta 222

Contexto: [topics:197](#topics-197)
Your company recently published a security policy to minimize the usage of service account keys. On-premises Windows-based applications are interacting with Google Cloud APIs. You need to implement Workload Identity Federation (WIF) with your identity provider on-premises.

What should you do?

**A.** Set up a workload identity pool with your corporate Active Directory Federation Service (ADFS). Configure a rule to let principals in the pool impersonate the Google Cloud service account.

**B.** Set up a workload identity pool with your corporate Active Directory Federation Service (ADFS). Let all principals in the pool impersonate the Google Cloud service account.

**C.** Set up a workload identity pool with an OpenID Connect (OIDC) service on the same machine. Configure a rule to let principals in the pool impersonate the Google Cloud service account.

**D.** Set up a workload identity pool with an OpenID Connect (OIDC) service on the same machine. Let all principals in the pool impersonate the Google Cloud service account.

**Respuesta de la fuente:** A

**Explicación:** Workload Identity Federation with on-premises Active Directory typically utilizes ADFS as the identity provider to issue tokens for external workloads.
Configuring specific rules ensures that only authorized principals can impersonate the Google Cloud service account, adhering to the principle of least privilege and preventing the security risk of allowing all principals in the pool access.

## Pregunta 223

Contexto: [topics:197](#topics-197)
After completing a security vulnerability assessment, you learned that cloud administrators leave Google Cloud CLI sessions open for days. You need to reduce the risk of attackers who might exploit these open sessions by setting these sessions to the minimum duration.

What should you do?

**A.** Set the session duration for the Google session control to one hour.

**B.** Set the reauthentication frequency for the Google Cloud Session Control to one hour.

**C.** Set the organization policy constraint constraints/iam.allowServiceAccountCredentialLifetimeExtension to one hour.

**D.** Set the organization policy constraint constraints/iam.serviceAccountKeyExpiryHours to one hour and inheritFromParent to false.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Session Control is a specific feature within Google Workspace admin that allows administrators to manage session lengths and reauthentication frequency for cloud services, including the Google Cloud CLI. Setting the reauthentication frequency (Option B) directly addresses the risk of long-lived open sessions by forcing users to re-authenticate at a specified interval, thereby limiting the window of opportunity for attackers to exploit stolen credentials or hijacked sessions. Options C and D relate to Service Account keys, which are distinct from human user CLI sessions.

## Pregunta 224

Contexto: [topics:197](#topics-197)
You have numerous private virtual machines on Google Cloud. You occasionally need to manage the servers through Secure Socket Shell (SSH) from a remote location. You want to configure remote access to the servers in a manner that optimizes security and cost efficiency.

What should you do?

**A.** Create a site-to-site VPN from your corporate network to Google Cloud.

**B.** Configure server instances with public IP addresses. Create a firewall rule to only allow traffic from your corporate IPs.

**C.** Create a firewall rule to allow access from the Identity-Aware Proxy (IAP) IP range. Grant the role of an IAP-secured Tunnel User to the administrators.

**D.** Create a jump host instance with public IP. Manage the instances by connecting through the jump host.

**Respuesta de la fuente:** C

**Explicación:** Identity-Aware Proxy (IAP) TCP forwarding allows secure SSH access to VMs without exposing public IP addresses or requiring a separate bastion host.
This approach optimizes security by enforcing identity-based authentication and improves cost efficiency by eliminating the need for dedicated VPN tunnels or additional compute resources.

## Pregunta 225

Contexto: [topics:197](#topics-197)
Your organization's record data exists in Cloud Storage. You must retain all record data for at least seven years. This policy must be permanent.

What should you do?

**A.** 1. Identify buckets with record data.
2. Apply a retention policy, and set it to retain for seven years.
3. Monitor the bucket by using log-based alerts to ensure that no modifications to the retention policy occurs.

**B.** 1. Identify buckets with record data.
2. Apply a retention policy, and set it to retain for seven years.
3. Remove any Identity and Access Management (IAM) roles that contain the storage buckets update permission.

**C.** 1. Identify buckets with record data.
2. Enable the bucket policy only to ensure that data is retained.
3. Enable bucket lock.

**D.** 1. Identify buckets with record data.
2. Apply a retention policy and set it to retain for seven years.
3. Enable bucket lock.

**Respuesta de la fuente:** D

**Explicación:** To meet the requirement of permanently retaining data for seven years, you must first apply a retention policy with the specified duration.
Crucially, enabling Bucket Lock makes the retention policy permanent by preventing any users, including administrators, from deleting the bucket or modifying its retention policy to shorten the retention period.

## Pregunta 226

Contexto: [topics:197](#topics-197)
Your organization wants to protect all workloads that run on Compute Engine VM to ensure that the instances weren't compromised by boot-level or kernel-level malware. Also, you need to ensure that data in use on the VM cannot be read by the underlying host system by using a hardware-based solution.

What should you do?

**A.** 1. Use Google Shielded VM including secure boot, Virtual Trusted Platform Module (vTPM), and integrity monitoring.
2. Create a Cloud Run function to check for the VM settings, generate metrics, and run the function regularly.

**B.** 1. Activate Virtual Machine Threat Detection in Security Command Center (SCC) Premium.
2. Monitor the findings in SCC.

**C.** 1. Use Google Shielded VM including secure boot, Virtual Trusted Platform Module (vTPM), and integrity monitoring.
2. Activate Confidential Computing.
3. Enforce these actions by using organization policies.

**D.** 1. Use secure hardened images from the Google Cloud Marketplace.
2. When deploying the images, activate the Confidential Computing option.
3. Enforce the use of the correct images and Confidential Computing by using organization policies.

**Respuesta de la fuente:** C

**Explicación:** Shielded VMs provide essential protections against boot-level and kernel-level malware via Secure Boot, vTPM, and integrity monitoring.
Confidential Computing is specifically designed to protect data in use from the underlying host system using hardware-based trusted execution environments (TEEs).
Option C correctly combines both technologies to address all requirements, while enforcing them with organization policies ensures compliance.

## Pregunta 227

Contexto: [topics:197](#topics-197)
You are migrating your users to Google Cloud. There are cookie replay attacks with Google web and Google Cloud CLI SDK sessions on endpoint devices. You need to reduce the risk of these threats.

What should you do? (Choose two.)

**A.** Configure Google session control to a shorter duration.

**B.** Set an organizational policy for OAuth 2.0 access token with a shorter duration.

**C.** Set a reauthentication policy for Google Cloud services to a shorter duration.

**D.** Configure a third-party identity provider with session management.

**E.** Enforce Security Key Authentication with 2SV.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 228

Contexto: [topics:197](#topics-197)
You manage a mission-critical workload for your organization, which is in a highly regulated industry. The workload uses Compute Engine VMs to analyze and process the sensitive data after it is uploaded to Cloud Storage from the endpoint computers. Your compliance team has detected that this workload does not meet the data protection requirements for sensitive data. You need to meet these requirements:

•	Manage the data encryption key (DEK) outside the Google Cloud boundary.
•	Maintain full control of encryption keys through a third-party provider.
•	Encrypt the sensitive data before uploading it to Cloud Storage.
•	Decrypt the sensitive data during processing in the Compute Engine VMs.
•	Encrypt the sensitive data in memory while in use in the Compute Engine VMs.

What should you do? (Choose two.)

**A.** Configure Customer Managed Encryption Keys to encrypt the sensitive data before it is uploaded to Cloud Storage, and decrypt the sensitive data after it is downloaded into your VMs.

**B.** Configure Cloud External Key Manager to encrypt the sensitive data before it is uploaded to Cloud Storage, and decrypt the sensitive data after it is downloaded into your VMs.

**C.** Create Confidential VMs to access the sensitive data.

**D.** Migrate the Compute Engine VMs to Confidential VMs to access the sensitive data.

**E.** Create a VPC Service Controls service perimeter across your existing Compute Engine VMs and Cloud Storage buckets.

**Respuesta de la fuente:** B, C

**Explicación:** Cloud External Key Manager (EKMS) satisfies the requirement to manage and control encryption keys outside Google Cloud via a third-party provider, enabling client-side encryption before storage.
Confidential VMs are required to encrypt data in memory while in use; since they cannot be enabled on existing instances through live migration, you must create new Confidential VMs for the workload.

## Pregunta 229

Contexto: [topics:197](#topics-197)
Your organization wants to be General Data Protection Regulation (GDPR) compliant. You want to ensure that your DevOps teams can only create Google Cloud resources in the Europe regions.

What should you do?

**A.** Use Identity-Aware Proxy (IAP) with Access Context Manager to restrict the location of Google Cloud resources.

**B.** Use the org policy constraint 'Google Cloud Platform – Resource Location Restriction' on your Google Cloud organization node.

**C.** Use the org policy constraint 'Restrict Resource Service Usage' on your Google Cloud organization node.

**D.** Use Identity and Access Management (IAM) custom roles to ensure that your DevOps team can only create resources in the Europe regions.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Organization Policy constraints specifically include 'constraints/gcp.resourceLocations', which allows administrators to whitelist specific regions (such as Europe) for resource creation.

IAM custom roles (Option D) control permissions but cannot enforce geographic location restrictions, while IAP (Option A) manages access to applications rather than resource deployment locations.

## Pregunta 230

Contexto: [topics:197](#topics-197)
For data residency requirements, you want your secrets in Google Clouds Secret Manager to only have payloads in europe-west1 and europe-west4. Your secrets must be highly available in both regions.

What should you do?

**A.** Create your secret with a user managed replication policy, and choose only compliant locations.

**B.** Create your secret with an automatic replication policy, and choose only compliant locations.

**C.** Create two secrets by using Terraform, one in europe-west1 and the other in europe-west4.

**D.** Create your secret with an automatic replication policy, and create an organizational policy to deny secret creation in non-compliant locations.

**Respuesta de la fuente:** A

**Explicación:** User-managed replication allows you to specify exactly which regions store the secret payloads, ensuring strict data residency within europe-west1 and europe-west4. Automatic replication stores secrets across all Google Cloud regions (unless restricted by organizational policies, but even then, it doesn't allow selecting specific compliant regions directly during creation for residency control in the same explicit way), violating the requirement to limit storage to only those two regions. Creating separate secrets via Terraform increases management complexity and does not provide a single highly available secret entity as requested.

## Pregunta 231

Contexto: [topics:197](#topics-197)
You are migrating an application into the cloud. The application will need to read data from a Cloud Storage bucket. Due to local regulatory requirements, you need to hold the key material used for encryption fully under your control and you require a valid rationale for accessing the key material.

What should you do?

**A.** Encrypt the data in the Cloud Storage bucket by using Customer Managed Encryption Keys. Configure an IAM deny policy for unauthorized groups.

**B.** Generate a key in your on-premises environment to encrypt the data before you upload the data to the Cloud Storage bucket. Upload the key to the Cloud Key Management Service (KMS). Activate Key Access Justifications (KAJ) and have the external key system reject unauthorized accesses.

**C.** Encrypt the data in the Cloud Storage bucket by using Customer Managed Encryption Keys backed by a Cloud Hardware Security Module (HSM). Enable data access logs.

**D.** Generate a key in your on-premises environment and store it in a Hardware Security Module (HSM) that is managed on-premises. Use this key as an external key in the Cloud Key Management Service (KMS). Activate Key Access Justifications (KAJ) and set the external key system to reject unauthorized accesses.

**Respuesta de la fuente:** D

**Explicación:** To maintain full control over key material while using cloud services, you must use Cloud External Key Manager, which allows encryption keys to reside in an on-premises HSM rather than Google's infrastructure.
This setup ensures the key never leaves your physical possession, satisfying regulatory requirements for strict custody.
Additionally, activating Key Access Justifications enforces a policy where every access attempt requires a valid business reason, providing the required audit trail and rationale for usage.

## Pregunta 232

Contexto: [topics:197](#topics-197)
Your organization uses the top-tier folder to separate application environments (prod and dev). The developers need to see all application development audit logs, but they are not permitted to review production logs. Your security team can review all logs in production and development environments. You must grant Identity and Access Management (IAM) roles at the right resource level for the developers and security team while you ensure least privilege.

What should you do?

**A.** 1. Grant logging.viewer role to the security team at the organization resource level.
2. Grant logging.viewer role to the developer team at the folder resource level that contains all the dev projects.

**B.** 1. Grant logging.viewer role to the security team at the organization resource level.
2. Grant logging.admin role to the developer team at the organization resource level.

**C.** 1. Grant logging.admin role to the security team at the organization resource level.
2. Grant logging.viewer role to the developer team at the folder resource level that contains all the dev projects.

**D.** 1. Grant logging.admin role to the security team at the organization resource level.
2. Grant logging.admin role to the developer team at the organization resource level.

**Respuesta de la fuente:** A

**Explicación:** Option A correctly applies the principle of least privilege by granting the security team `logging.viewer` at the organization level to access all logs, without unnecessary administrative permissions.
Developers receive `logging.viewer` only at the dev folder level, ensuring they can audit development activity while remaining restricted from production logs.

## Pregunta 233

Contexto: [topics:197](#topics-197)
You manage a fleet of virtual machines (VMs) in your organization. You have encountered issues with lack of patching in many VMs. You need to automate regular patching in your VMs and view the patch management data across multiple projects.

What should you do? (Choose two.)

**A.** View patch management data in VM Manager by using OS patch management.

**B.** View patch management data in Artifact Registry.

**C.** View patch management data in a Security Command Center dashboard.

**D.** Deploy patches with Security Command Genter by using Rapid Vulnerability Detection.

**E.** Deploy patches with VM Manager by using OS patch management.

**Respuesta de la fuente:** A, E

**Explicación:** Google Cloud VM Manager provides the OS Patch Management feature, which allows you to automate patch deployment schedules for your virtual machines (Option E).
Additionally, it offers a centralized dashboard to view patch compliance and management data across multiple projects within an organization (Option A).

## Pregunta 234

Contexto: [topics:197](#topics-197)
Your organization uses BigQuery to process highly sensitive, structured datasets. Following the “need to know” principle, you need to create the Identity and Access Management (IAM) design to meet the needs of these users:
•	Business user: must access curated reports.
•	Data engineer: must administrate the data lifecycle in the platform.
•	Security operator: must review user activity on the data platform.

What should you do?

**A.** Configure data access log for BigQuery services, and grant Project Viewer role to security operator.

**B.** Set row-based access control based on the “region” column, and filter the record from the United States for data engineers.

**C.** Create curated tables in a separate dataset and assign the role roles/bigquery.dataViewer.

**D.** Generate a CSV data file based on the business user's needs, and send the data to their email addresses.

**Respuesta de la fuente:** C

**Explicación:** Option C correctly applies the 'need to know' principle by segregating sensitive data into a curated dataset and granting the Business User only read-only access via the BigQuery Data Viewer role. This ensures users can only see specific, non-sensitive information required for their reports.
Other options fail because A grants excessive permissions (Project Viewer) and lacks proper log viewing roles; B uses row-level filtering which does not address the core access design for reports; and D bypasses the platform entirely.

## Pregunta 235

Contexto: [topics:197](#topics-197)
You are setting up a new Cloud Storage bucket in your environment that is encrypted with a customer managed encryption key (CMEK). The CMEK is stored in Cloud Key Management Service (KMS), in project “prj-a”, and the Cloud Storage bucket will use project “prj-b”. The key is backed by a Cloud Hardware Security Module (HSM) and resides in the region europe-west3. Your storage bucket will be located in the region europe-west1. When you create the bucket, you cannot access the key, and you need to troubleshoot why.

What has caused the access issue?

**A.** A firewall rule prevents the key from being accessible.

**B.** Cloud HSM does not support Cloud Storage.

**C.** The CMEK is in a different project than the Cloud Storage bucket.

**D.** The CMEK is in a different region than the Cloud Storage bucket.

**Respuesta de la fuente:** D

**Explicación:** In Google Cloud, a CMEK key and the resource it protects must reside in the same regional location.
The scenario specifies that the key is in europe-west3 while the bucket is in europe-west1.
This geographic mismatch prevents the bucket from accessing the key during creation.

## Pregunta 236

Contexto: [topics:197](#topics-197)
You are deploying regulated workloads on Google Cloud. The regulation has data residency and data access requirements. It also requires that support is provided from the same geographical location as where the data resides.

What should you do?

**A.** Enable Access Transparency Logging.

**B.** Deploy Assured Workloads.

**C.** Deploy resources only to regions permitted by data residency requirements.

**D.** Use Data Access logging and Access Transparency logging to confirm that no users are accessing data from another region.

**Respuesta de la fuente:** B

**Explicación:** Assured Workloads is specifically designed to help regulated organizations meet strict compliance requirements, including data residency and personnel access controls. It ensures that only support personnel from the required geographical locations can access customer resources, directly addressing the specific support constraint mentioned in the question.

## Pregunta 237

Contexto: [topics:197](#topics-197)
Your organization wants full control of the keys used to encrypt data at rest in their Google Cloud environments. Keys must be generated and stored outside of Google and integrate with many Google Services including BigQuery.

What should you do?

**A.** Use customer-supplied encryption keys (CSEK) with keys generated on trusted external systems. Provide the raw CSEK as part of the API call.

**B.** Create a KMS key that is stored on a Google managed FIPS 140-2 level 3 Hardware Security Module (HSM). Manage the Identity and Access Management (IAM) permissions settings, and set up the key rotation period.

**C.** Use Cloud External Key Management (EKM) that integrates with an external Hardware Security Module (HSM) system from supported vendors.

**D.** Create a Cloud Key Management Service (KMS) key with imported key material. Wrap the key for protection during import. Import the key generated on a trusted system in Cloud KMS.

**Respuesta de la fuente:** C

**Explicación:** Cloud External Key Management (EKM) is the correct choice because it allows keys to remain entirely within an external HSM system, ensuring Google never holds or manages the key material. This satisfies the strict requirement for full control and external storage while enabling integration with Google services like BigQuery for data-at-rest encryption.

## Pregunta 238

Contexto: [topics:197](#topics-197)
Your company is concerned about unauthorized parties gaining access to the Google Cloud environment by using a fake login page. You must implement a solution to protect against person-in-the-middle attacks.

Which security measure should you use?

**A.** Security key

**B.** Google prompt

**C.** Text message or phone call code

**D.** Google Authenticator application

**Respuesta de la fuente:** A

**Explicación:** Security keys (FIDO/U2F) are specifically designed to mitigate phishing and man-in-the-middle attacks by binding the cryptographic authentication to the exact origin domain. Unlike SMS or authenticator apps, they do not rely on user input that can be tricked into submission on a fake page.

## Pregunta 239

Contexto: [topics:197](#topics-197)
You control network traffic for a folder in your Google Cloud environment. Your folder includes multiple projects and Virtual Private Cloud (VPC) networks. You want to enforce on the folder level that egress connections are limited only to IP range 10.58.5.0/24 and only from the VPC network “dev-vpc”. You want to minimize implementation and maintenance effort.

What should you do?

**A.** 1. Leave the network configuration of the VMs in scope unchanged.
2. Create a new project including a new VPC network “new-vpc”.
3. Deploy a network appliance in “new-vpc” to filter access requests and only allow egress connections from “dev-vpc” to 10.58.5.0/24.

**B.** 1. Leave the network configuration of the VMs in scope unchanged.
2. Enable Cloud NAT for “dev-vpc” and restrict the target range in Cloud NAT to 10.58.5.0/24.

**C.** 1. Attach external IP addresses to the VMs in scope.
2. Define and apply a hierarchical firewall policy on folder level to deny all egress connections and to allow egress to IP range 10.58.5.0/24 from network dev-vpc.

**D.** 1. Attach external IP addresses to the VMs in scope.
2. Configure a VPC Firewall rule in “dev-vpc” that allows egress connectivity to IP range 10.58.5.0/24 for all source addresses in this network.

**Respuesta de la fuente:** C

**Explicación:** Hierarchical Firewall Policies are the only native GCP feature that allows enforcing network rules at the organization or folder level, satisfying the scope requirement.
Cloud NAT (Option B) is configured per project/VPC and cannot centrally enforce restrictions across a folder.
Standard VPC firewall rules (Option D) are project-scoped and do not meet the folder-level enforcement criteria.
Attaching external IPs ensures egress traffic exists to be filtered by the hierarchical policy.

## Pregunta 240

Contexto: [topics:197](#topics-197)
Your customer has an on-premises Public Key Infrastructure (PKI) with a certificate authority (CA). You need to issue certificates for many HTTP load balancer frontends. The on-premises PKI should be minimally affected due to many manual processes, and the solution needs to scale.

What should you do?

**A.** Use Certificate Manager to issue Google managed public certificates and configure it at HTTP the load balancers in your infrastructure as code (IaC).

**B.** Use a subordinate CA in the Google Certificate Authority Service from the on-premises PKI system to issue certificates for the load balancers.

**C.** Use Certificate Manager to import certificates issued from on-premises PKI and for the frontends. Leverage the gcloud tool for importing.

**D.** Use the web applications with PKCS12 certificates issued from subordinate CA based on OpenSSL on-premises. Use the gcloud tool for importing. Use the External TCP/UDP Network load balancer instead of an external HTTP Load Balancer.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Google Cloud Certificate Authority Service supports creating Subordinate CAs linked to an on-premises Root CA. This architecture allows automated, programmatic certificate issuance for load balancers via the subordinate CA, satisfying the scalability requirement while isolating manual processes from the root infrastructure.

## Pregunta 241

Contexto: [topics:197](#topics-197)
You are developing a new application that uses exclusively Compute Engine VMs. Once a day, this application will execute five different batch jobs. Each of the batch jobs requires a dedicated set of permissions on Google Cloud resources outside of your application. You need to design a secure access concept for the batch jobs that adheres to the least-privilege principle.

What should you do?

**A.** 1. Create a general service account “g-sa” to orchestrate the batch jobs.
2. Create one service account per batch job ‘b-sa-[1-5]’. Grant only the permissions required to run the individual batch jobs to the service accounts and generate service account keys for each of these service accounts.
3. Store the service account keys in Secret Manager. Grant g-sa access to Secret Manager and run the batch jobs with the permissions of b-sa-[1-5].

**B.** 1. Create a general service account “g-sa” to execute the batch jobs.
2. Grant the permissions required to execute the batch jobs to g-sa.
3. Execute the batch jobs with the permissions granted to g-sa.

**C.** 1. Create a workload identity pool and configure workload identity pool providers for each batch job.
2. Assign the workload identity user role to each of the identities configured in the providers.
3. Create one service account per batch job “b-sa-[1-5]”, and grant only the permissions required to run the individual batch jobs to the service accounts.
4. Generate credential configuration files for each of the providers. Use these files to execute the batch jobs with the permissions of b-sa-[1-5].

**D.** 1. Create a general service account “g-sa” to orchestrate the batch jobs.
2. Create one service account per batch job “b-sa-[1-5]”, and grant only the permissions required to run the individual batch jobs to the service accounts.
3. Grant the Service Account Token Creator role to g-sa. Use g-sa to obtain short-lived access tokens for b-sa-[1-5] and to execute the batch jobs with the permissions of b-sa-[1-5].

**Respuesta de la fuente:** D

**Explicación:** Option D correctly implements the least-privilege principle by creating dedicated service accounts with specific permissions for each batch job.
Instead of using long-lived keys (insecure) or a single overly privileged account (violating least privilege), it uses an orchestrator service account to impersonate the job-specific accounts via short-lived access tokens.
This ensures that each batch job executes with only the necessary permissions while maintaining high security through temporary credentials.

## Pregunta 242

Contexto: [topics:197](#topics-197)
Your Google Cloud environment has one organization node, one folder named “Apps”, and several projects within that folder. The organizational node enforces the constraints/iam.allowedPolicyMemberDomains organization policy, which allows members from the terramearth.com organization. The “Apps” folder enforces the constraints/iam.allowedPolicyMemberDomains organization policy, which allows members from the flowlogistic.com organization. It also has the inheritFromParent: false property.

You attempt to grant access to a project in the “Apps” folder to the user testuser@terramearth.com.

What is the result of your action and why?

**A.** The action succeeds because members from both organizations, terramearth.com or flowlogistic.com, are allowed on projects in the “Apps” folder.

**B.** The action succeeds and the new member is successfully added to the project's Identity and Access Management (IAM) policy because all policies are inherited by underlying folders and projects.

**C.** The action fails because a constraints/iam.allowedPolicyMemberDomains organization policy must be defined on the current project to deactivate the constraint temporarily.

**D.** The action fails because a constraints/iam.allowedPolicyMemberDomains organization policy is in place and only members from the flowlogistic.com organization are allowed.

**Respuesta de la fuente:** D

**Explicación:** The 'Apps' folder has the inheritFromParent: false property set, meaning it does not inherit policies from the organization node and instead enforces its own specific constraints. The folder's policy restricts allowed members to flowlogistic.com only, overriding the terramearth.com allowance defined at the organization level. Since [email protected] belongs to terramearth.com and not flowlogistic.com, the access grant fails.

## Pregunta 243

Contexto: [topics:197](#topics-197)
An administrative application is running on a virtual machine (VM) in a managed group at port 5601 inside a Virtual Private Cloud (VPC) instance without access to the internet currently. You want to expose the web interface at port 5601 to users and enforce authentication and authorization Google credentials.

What should you do?

**A.** Configure the bastion host with OS Login enabled and allow connection to port 5601 at VPC firewall. Log in to the bastion host from the Google Cloud console by using SSH-in-browser and then to the web application.

**B.** Modify the VPC routing with the default route point to the default internet gateway. Modify the VPC Firewall rule to allow access from the internet 0.0.0.0/0 to port 5601 on the application instance.

**C.** Configure Secure Shell Access (SSH) bastion host in a public network, and allow only the bastion host to connect to the application on port 5601. Use a bastion host as a jump host to connect to the application.

**D.** Configure an HTTP Load Balancing instance that points to the managed group with Identity-Aware Proxy (IAP) protection with Google credentials. Modify the VPC firewall to allow access from IAP network range.

**Respuesta de la fuente:** D

**Explicación:** Identity-Aware Proxy (IAP) is the correct solution because it provides secure access to backend services while enforcing authentication and authorization using Google credentials. By placing IAP in front of an HTTP Load Balancer, traffic is intercepted and verified before reaching the VMs, allowing you to restrict VPC firewall rules to only accept traffic from the IAP service ranges rather than opening ports directly to the internet.

## Pregunta 244

Contexto: [topics:197](#topics-197)
Your company’s users access data in a BigQuery table. You want to ensure they can only access the data during working hours.

What should you do?

**A.** Assign a BigQuery Data Viewer role along with an IAM condition that limits the access to specified working hours.

**B.** Run a gsutil script that assigns a BigQuery Data Viewer role, and remove it only during the specified working hours.

**C.** Assign a BigQuery Data Viewer role to a service account that adds and removes the users daily during the specified working hours.

**D.** Configure Cloud Scheduler so that it triggers a Cloud Functions instance that modifies the organizational policy constraint for BigQuery during the specified working hours.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud IAM supports time-bound conditions that evaluate access requests based on the request timestamp.
By attaching an IAM condition to the BigQuery Data Viewer role, you can enforce granular policies that automatically deny access outside specified working hours without manual intervention.

## Pregunta 245

Contexto: [topics:197](#topics-197)
You have placed several Compute Engine instances in a private subnet. You want to allow these instances to access Google Cloud services, like Cloud Storage, without traversing the internet. What should you do?

**A.** Enable Private Google Access for the private subnet.

**B.** Configure Private Service Connect for the private subnet's Virtual Private Cloud (VPC) and allocate an IP range for the Compute Engine instances.

**C.** Reserve and assign static external IP addresses for the Compute Engine instances.

**D.** Create a Cloud NAT gateway for the region where the private subnet is configured.

**Respuesta de la fuente:** A

**Explicación:** Private Google Access allows instances in a private subnet to reach Google APIs and services (like Cloud Storage) via internal IP addresses, bypassing the public internet.
This feature is specifically designed for this use case, ensuring that traffic between compute resources and Google services remains within Google's network backbone.

## Pregunta 246

Contexto: [topics:197](#topics-197)
Your organization relies heavily on Cloud Run for its containerized applications. You utilize Cloud Build for image creation, Artifact Registry for image storage, and Cloud Run for deployment. You must ensure that containers with vulnerabilities rated above a common vulnerability scoring system (CVSS) score of "medium" are not deployed to production. What should you do?

**A.** Implement vulnerability scanning as part of the Cloud Build process. If any medium or higher vulnerabilities are detected, manually rebuild the image with updated components.

**B.** Perform manual vulnerability checks post-build, but before Cloud Run deployment. Implement a manual security-engineer-driven remediation process.

**C.** Configure Binary Authorization on Cloud Run to enforce image signatures. Create policies to allow deployment only for images passing a defined vulnerability threshold.

**D.** Utilize a vulnerability scanner during the Cloud Build stage and set Artifact Registry permissions to block images containing vulnerabilities above "medium."

**Respuesta de la fuente:** C

**Explicación:** Binary Authorization is the correct control because it enforces admission policies at the deployment stage, ensuring only images meeting specific security criteria can run.
It integrates with Container Analysis vulnerability findings to automatically block deployments of images containing vulnerabilities above the defined CVSS threshold.
This provides an automated, policy-based enforcement mechanism that prevents insecure containers from reaching production without manual intervention.

## Pregunta 247

Contexto: [topics:197](#topics-197)
You run a web application on top of Cloud Run that is exposed to the internet with an Application Load Balancer. You want to ensure that only privileged users from your organization can access the application. The proposed solution must support browser access with single sign-on. What should you do?

**A.** Change Cloud Run configuration to require authentication. Assign the role of Cloud Run Invoker to the group of privileged users.

**B.** Create a group of privileged users in Cloud Identity. Assign the role of Cloud Run User to the group directly on the Cloud Run service.

**C.** Change the Ingress Control configuration of Cloud Run to internal and create firewall rules to allow only access from known IP addresses.

**D.** Activate Identity-Aware Proxy (IAP) on the Application Load Balancer backend. Assign the role of IAP-secured Web App User to the group of privileged users.

**Respuesta de la fuente:** D

**Explicación:** Identity-Aware Proxy (IAP) is the correct solution because it integrates with Google Cloud's identity platform to provide Single Sign-On (SSO) and fine-grained access control for web applications behind an Application Load Balancer.

Assigning the 'IAP-secured Web App User' role to specific groups ensures that only authenticated, privileged users can access the application, satisfying both the security and browser-based SSO requirements.

Other options fail because Cloud Run Invoker roles (A/B) do not provide a native browser-based SSO flow for external internet traffic without additional complex setup, and restricting ingress to internal-only (C) breaks public internet accessibility.

## Pregunta 248

Contexto: [topics:197](#topics-197)
During a routine security review, your team discovered a suspicious login attempt to impersonate a highly privileged but regularly used service account by an unknown IP address. You need to effectively investigate in order to respond to this potential security incident. What should you do?

**A.** Enable Cloud Audit Logs for the resources that the service account interacts with. Review the logs for further evidence of unauthorized activity.

**B.** Review Cloud Audit Logs for activity related to the service account. Focus on the time period of the suspicious login attempt.

**C.** Run a vulnerability scan to identify potentially exploitable weaknesses in systems that use the service account.

**D.** Check Event Threat Detection in Security Command Center for any related alerts. Cross-reference your findings with Cloud Audit Logs.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Security Command Center's Event Threat Detection automatically analyzes logs to identify suspicious patterns like service account impersonation, providing immediate alerts. Cross-referencing these alerts with Cloud Audit Logs allows for a comprehensive investigation by combining high-level threat detection with granular forensic details of the unauthorized activity.

## Pregunta 249

Contexto: [topics:197](#topics-197)
Your organization has an operational image classification model running on a managed AI service on Google Cloud. You are in a configuration review with stakeholders and must describe the security responsibilities for the image classification model. What should you do?

**A.** Explain that using platform-as-a-service (PaaS) transfers security concerns to Google. Describe the need for strict API usage limits to protect against unexpected usage and billing spikes.

**B.** Explain the security aspects of the code that transforms user-uploaded images using Google's service. Define Cloud IAM for fine-grained access control within the development team.

**C.** Explain Google's shared responsibility model. Focus the configuration review on Identity and Access Management (IAM) permissions, secure data upload/download procedures, and monitoring logs for any potential malicious activity.

**D.** Explain the development of custom network firewalls around the image classification service for deep intrusion detection and prevention. Describe vulnerability scanning tools for known vulnerabilities.

**Respuesta de la fuente:** C

**Explicación:** In a managed AI service environment, security follows the shared responsibility model where Google secures the infrastructure and the customer secures their data and access controls. Choice C correctly identifies this division of labor by focusing on customer responsibilities: configuring Identity and Access Management (IAM) for least privilege, ensuring secure data handling procedures, and monitoring logs for suspicious activity. Other options are incorrect because A incorrectly suggests security concerns fully transfer to Google, D suggests unnecessary infrastructure management (firewalls) for a managed service, and B is too narrow by focusing only on code rather than the broader configuration review required.

## Pregunta 250

Contexto: [topics:197](#topics-197)
You are managing data in your organization's Cloud Storage buckets and are required to retain objects. To reduce storage costs, you must automatically downgrade the storage class of objects older than 365 days to Coldline storage. What should you do?

**A.** Use Cloud Asset Inventory to generate a report of the configuration of all storage buckets. Examine the Lifecycle management policy settings and ensure that they are set correctly.

**B.** Set up a CloudRun Job with Cloud Scheduler to execute a script that searches for and removes flies older than 365 days from your Cloud Storage.

**C.** Enable the Autoclass feature to manage all aspects of bucket storage classes.

**D.** Define a lifecycle policy JSON with an action on SetStorageClass to COLDLINE with an age condition of 365 and matchStorageClass STANDARD.

**Respuesta de la fuente:** D

**Explicación:** Cloud Storage lifecycle management allows you to automate object transitions based on specific conditions.
Option D correctly defines a lifecycle rule with an action to set the storage class to COLDLINE for objects meeting the age condition of 365 days.
The matchStorageClass filter ensures that only STANDARD objects are targeted, preventing redundant operations on objects already in colder classes.

## Pregunta 251

Contexto: [topics:197](#topics-197)
Your organization has a centralized identity provider that is used to manage human and machine access. You want to leverage this existing identity management system to enable on-premises applications to access Google Cloud without hard coded credentials. What should you do?

**A.** Enable Secure Web Proxy. Create a proxy subnet for each region that Secure Web Proxy will be deployed. Deploy an SSL certificate to Certificate Manager. Create a Secure Web Proxy policy and rules that allow access to Google Cloud services.

**B.** Enable Workforce Identity Federation. Create a workforce identity pool and specify the on-premises identity provider as a workforce identity pool provider. Create an attribute mapping to map the on-premises identity provider token to a Google STS token. Create an IAM binding that binds the required role(s) to the external identity by specifying the project ID, workload identity pool, and attribute that should be matched.

**C.** Enable Identity-Aware Proxy (IAP). Configure IAP by specifying the groups and service accounts that should have access to the application. Grant these identities the IAP-secured web app user role.

**D.** Enable Workload Identity Federation. Create a workload identity pool and specify the on-premises identity provider as a workload identity pool provider. Create an attribute mapping to map the on-premises identity provider token to a Google STS token. Create a service account with the necessary permissions for the workload. Grant the external identity the Workload Identity user role on the service account.

**Respuesta de la fuente:** D

**Explicación:** The scenario requires access for on-premises applications, which mandates Workload Identity Federation rather than Workforce Identity Federation (used for human users). Option D correctly outlines the process of creating a workload identity pool, mapping attributes to Google STS tokens, and granting the Workload Identity User role to a service account. This approach allows external workloads to authenticate using short-lived tokens, eliminating the need for hard-coded long-lived credentials.

## Pregunta 252

Contexto: [topics:197](#topics-197)
Your organization is migrating a sensitive data processing workflow from on-premises infrastructure to Google Cloud. This workflow involves the collection, storage, and analysis of customer information that includes personally identifiable information (PII). You need to design security measures to mitigate the risk of data exfiltration in this new cloud environment. What should you do?

**A.** Encrypt all sensitive data in transit and at rest. Establish secure communication channels by using TLS and HTTPS protocols.

**B.** Implement a Cloud DLP solution to scan and identify sensitive information, and apply redaction or masking techniques to the PII. Integrate VPC SC with your network security controls to block potential data exfiltration attempts.

**C.** Restrict all outbound network traffic from cloud resources. Implement rigorous access controls and logging for all sensitive data and the systems that process the data.

**D.** Rely on employee expertise to prevent accidental data exfiltration incidents.

**Respuesta de la fuente:** B

**Explicación:** Option B is the correct answer because it combines detection and prevention specifically targeted at data exfiltration.
Cloud DLP identifies and masks PII to reduce the value of leaked data, while VPC Service Controls create a security perimeter that restricts unauthorized cross-service or external API access, effectively blocking exfiltration attempts even if credentials are compromised.

## Pregunta 253

Contexto: [topics:197](#topics-197)
Your organization is building a chatbot that is powered by generative AI to deliver automated conversations with internal employees. You must ensure that no data with personally identifiable information (PII) is communicated through the chatbot. What should you do?

**A.** Encrypt data at rest for both input and output by using Cloud KMS, and apply least privilege access to the encryption keys.

**B.** Discover and transform PII data in both input and output by using the Cloud Data Loss Prevention (Cloud DLP) API.

**C.** Prevent PII data exfiltration by using VPC-SC to create a safe scope around your chatbot.

**D.** Scan both input and output by using data encryption tools from the Google Cloud Marketplace.

**Respuesta de la fuente:** B

**Explicación:** The Cloud Data Loss Prevention (DLP) API is specifically designed to identify sensitive information like PII within data streams.
By using the API to inspect and transform (e.g., de-identify or redact) both inputs from employees and outputs from the generative AI model, you actively prevent PII communication.
Other options focus on encryption or perimeter security, which do not prevent PII from being processed or revealed by the chatbot itself.

## Pregunta 254

Contexto: [topics:197](#topics-197)
Your organization has applications that run in multiple clouds. The applications require access to a Google Cloud resource running in your project. You must use short-lived access credentials to maintain security across the clouds. What should you do?

**A.** Create a managed workload identity. Bind an attested identity to the Compute Engine workload.

**B.** Create a service account key. Download the key to each application that requires access to the Google Cloud resource.

**C.** Create a workload identity pool with a workload identity provider for each external cloud. Set up a service account and add an IAM binding for impersonation.

**D.** Create a VPC firewall rule for ingress traffic with an allowlist of the IP ranges of the external cloud applications.

**Respuesta de la fuente:** C

**Explicación:** Workload Identity Federation is the designated solution for granting external workloads (such as those in other clouds) access to Google Cloud resources using short-lived credentials, eliminating the need for long-lived service account keys.
By creating a workload identity pool and provider for each external cloud, applications can exchange their native identity tokens for short-lived Google Cloud tokens.
These tokens are used to impersonate a specific Google Cloud service account with appropriate IAM bindings, ensuring secure, temporary access.

## Pregunta 255

Contexto: [topics:197](#topics-197)
Your organization's financial modeling application is already deployed on Google Cloud. The application processes large amounts of sensitive customer financial data. Application code is old and poorly understood by your current software engineers. Recent threat modeling exercises have highlighted the potential risk of sophisticated side-channel attacks against the application while the application is running. You need to further harden the Google Cloud solution to mitigate the risk of these side-channel attacks, ensuring maximum protection for the confidentiality of financial data during processing, while minimizing application problems. What should you do?

**A.** Enforce stricter access controls for Compute Engine instances by using service accounts, least privilege IAM policies, and limit network access.

**B.** Implement a runtime library designed to introduce noise and timing variations into the application's execution which will disrupt side-channel attack.

**C.** Migrate the application to Confidential VMs to provide hardware-level encryption of memory and protect sensitive data during processing.

**D.** Utilize customer-managed encryption keys (CMEK) to ensure complete control over the encryption process.

**Respuesta de la fuente:** C

**Explicación:** Confidential VMs utilize Intel SGX or AMD SEV hardware features to encrypt data while it is in use (in memory), specifically mitigating side-channel attacks by preventing unauthorized access even by cloud administrators.
This approach is ideal because it provides hardware-level isolation without requiring changes to the legacy application code, thereby minimizing application problems.
Other options like IAM controls or CMEK only protect data at rest or in transit, not during active processing.

## Pregunta 256

Contexto: [topics:197](#topics-197)
Your organization has two VPC Service Controls service perimeters, Perimeter-A and Perimeter-B, in Google Cloud. You want to allow data to be copied from a Cloud Storage bucket in Perimeter-A to another Cloud Storage bucket in Perimeter-B. You must minimize exfiltration risk, only allow required connections, and follow the principle of least privilege. What should you do?

**A.** Configure a perimeter bridge between Perimeter-A and Perimeter-B, and specify the Cloud Storage buckets as the resources involved.

**B.** Configure a perimeter bridge between the projects hosting the Cloud Storage buckets in Perimeter-A and Perimeter-B.

**C.** Configure an egress rule for the Cloud Storage bucket in Perimeter-A and a corresponding ingress rule in Perimeter-B.

**D.** Configure a bidirectional egress/ingress rule for the Cloud Storage buckets in Perimeter-A and Perimeter-B.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because ingress and egress rules allow you to define specific exceptions for data flow between perimeters with granular control, adhering strictly to the principle of least privilege.
Perimeter bridges (Options A and B) link entire perimeters or projects, which is broader in scope than necessary for a specific bucket-to-bucket copy operation and increases potential attack surface.

## Pregunta 257

Contexto: [topics:197](#topics-197)
You are running code in Google Kubernetes Engine (GKE) containers in Google Cloud that require access to objects stored in a Cloud Storage bucket. You need to securely grant the Pods access to the bucket while minimizing management overhead. What should you do?

**A.** Create a service account. Grant bucket access to the Pods by using Workload Identity Federation for GKE.

**B.** Create a service account with keys. Store the keys in Secret Manager with a 30-day rotation schedule. Reference the keys in the Pods.

**C.** Create a service account with keys. Store the keys as a Kubernetes secret. Reference the keys in the Pods.

**D.** Create a service account with keys. Store the keys in Secret Manager. Reference the keys in the Pods.

**Respuesta de la fuente:** A

**Explicación:** Workload Identity Federation for GKE is the recommended best practice because it securely binds Kubernetes service accounts to Google Cloud service accounts.
This approach allows pods to obtain short-lived credentials automatically, eliminating the need to create, store, or rotate static long-term keys.
Avoiding static keys significantly reduces security risks and management overhead compared to using Secret Manager or Kubernetes Secrets for key storage.

## Pregunta 258

Contexto: [topics:197](#topics-197)
Your organization is adopting Google Cloud and wants to ensure sensitive resources are only accessible from devices within the internal on-premises corporate network. You must configure Access Context Manager to enforce this requirement. These considerations apply:

•	The internal network uses IP ranges 10.100.0.0/16 and 192.168.0.0/16.
•	Some employees work remotely but connect securely through a company-managed virtual private network (VPN). The VPN dynamically allocates IP addresses from the pool 172.16.0.0/20.
•	Access should be restricted to a specific Google Cloud project that is contained within an existing service perimeter.

What should you do?

**A.** Create an access level named "Authorized Devices." Utilize the Device Policy attribute to require corporate-managed devices. Apply the access level to the Google Cloud project and instruct all employees to enroll their devices in the organization's management system.

**B.** Create an access level titled "Internal Network Only." Add a condition with these attributes:
•	IP Subnetworks: 10.100.0.0/16, 192.168.0.0/16
•	Device Policy: Require OS as Windows or macOS. Apply this access level to the sensitive Google Cloud project.

**C.** Create an access level titled "Corporate Access." Add a condition with the IP Subnetworks attribute, including the ranges: 10.100.0.0/16, 192.168.0.0/16, 172.16.0.0/20. Assign this access level to a service perimeter encompassing the sensitive project.

**D.** Create a new IAM role called "InternalAccess. Add the IP ranges 10.100.0.0/16, 192.16.0.0/16, and 172.16.0.0/20 to the role as an IAM condition. Assign this role to IAM groups corresponding to on-premises and VPN users. Grant this role the necessary permissions on the resource within this sensitive Google Cloud project.

**Respuesta de la fuente:** C

**Explicación:** The scenario requires restricting access based on network location (IP ranges), which is achieved by defining an Access Level with the IP Subnetworks attribute in Access Context Manager.
To include both on-premises users and those connected via the corporate VPN, all three specified CIDR blocks must be included in the condition.
Finally, this Access Level must be applied to the Service Perimeter containing the sensitive project to enforce the restriction.

## Pregunta 259

Contexto: [topics:197](#topics-197)
Your team maintains 1PB of sensitive data within BigOuery that contains personally identifiable information (PII). You need to provide access to this dataset to another team within your organization for analysis purposes. You must share the BigQuery dataset with the other team while protecting the PII. What should you do?

**A.** Utilize BigQuery's row-level access policies to mask PII columns based on the other team's user identities.

**B.** Export the BigQuery dataset to Cloud Storage. Create a VPC Service Control perimeter and allow only their team's project access to the bucket.

**C.** Implement data pseudonymization techniques to replace the PII fields with non-identifiable values. Grant the other team access to the pseudonymized dataset.

**D.** Create a filtered copy of the dataset and replace the sensitive data with hash values in a separate project. Grant the other team access to this new project.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because pseudonymization (data masking) replaces sensitive PII with non-identifiable substitutes, directly addressing the requirement to protect data while preserving utility for analysis.
Options A and D are incorrect because row-level security filters rows, not columns, and replacing PII in a 1PB dataset is computationally expensive and impractical.
Option B fails to mask the PII itself, only restricting network access.

## Pregunta 260

Contexto: [topics:197](#topics-197)
Your organization uses Google Cloud to process large amounts of location data for analysis and visualization. The location data is potentially sensitive. You must design a solution that allows storing and processing the location data securely, minimizing data exposure risks, and adhering to both regulatory guidelines and your organization's internal data residency policies. What should you do?

**A.** Enable location restrictions on Compute Engine instances and virtual disk resources where the data is handled. Apply labels to tag geographic metadata for all stored data.

**B.** Use the Cloud Data Loss Prevention (Cloud DLP) API to scan for sensitive location data before any storage or processing. Create Cloud Storage buckets with global availability for optimal performance, relying on Cloud DLP results to filter and control data access.

**C.** Create regional Cloud Storage buckets with Object Lifecycle Management policies that limit data lifetime. Enable fine-grained access controls by using IAM conditions. Encrypt data with customer-managed encryption keys (CMEK) generated within specific Cloud KMS key locations.

**D.** Store data within BigQuery in a specified region by using dataset location configuration. Use authorized views and row-level security to enforce geographic access restrictions. Encrypt data within BigQuery tables by using customer-managed encryption keys (CMEK).

**Respuesta de la fuente:** D

**Explicación:** The question explicitly requires processing data for analysis and visualization, which is the primary use case for BigQuery rather than Cloud Storage or Compute Engine. Option D ensures data residency by setting a specific dataset location and minimizes exposure through fine-grained access controls like authorized views and row-level security.
Additionally, using Customer-Managed Encryption Keys (CMEK) provides the necessary encryption control required for sensitive regulatory compliance.

## Pregunta 261

Contexto: [topics:197](#topics-197)
Your organization utilizes Cloud Run services within multiple projects underneath the non-production folder which requires primarily internal communication. Some services need external access to approved fully qualified domain names (FQDN) while other external traffic must be blocked. Internal applications must not be exposed. You must achieve this granular control with allowlists overriding broader restrictions only for designated VPCs. What should you do?

**A.** Implement a global-level allowlist rule for the necessary FQDNs within a hierarchical firewall policy. Apply this policy across all VPCs in the organization and configure Cloud NAT without any additional filtering.

**B.** Create a folder-level deny-all rule for outbound traffic within a hierarchical firewall policy. Define FQDN allowlist rules in separate policies and associate them with the necessary VPCs. Configure Cloud NAT for these VPCs.

**C.** Create a project-level deny-all rule within a hierarchical structure and apply it broadly. Override this rule with separate FQDN allowlists defined in VPC-level firewall policies associated with the relevant VPCs.

**D.** Configure Cloud NAT with IP-based filtering to permit outbound traffic only to the allowlist d FQDNs' IP ranges. Apply Cloud NAT uniformly to all VPCs within the organization's folder structure.

**Respuesta de la fuente:** B

**Explicación:** Hierarchical firewall policies allow you to enforce a broad deny-all egress rule at the folder level to block external traffic by default.
Higher-priority policies can then be applied to specific VPCs to override this restriction with granular FQDN allowlists, ensuring only approved domains are accessible.
Cloud NAT provides the necessary outbound connectivity for Cloud Run services to reach these internet destinations securely.

## Pregunta 262

Contexto: [topics:197](#topics-197)
Your organization hosts a sensitive web application in Google Cloud. To protect the web application, you've set up a virtual private cloud (VPC) with dedicated subnets for the application's frontend and backend components. You must implement security controls to restrict incoming traffic, protect against web-based attacks, and monitor internal traffic. What should you do?

**A.** Configure Cloud Firewall to permit allow-listed traffic only, deploy Google Cloud Armor with predefined rules for blocking common web attacks, and deploy Cloud Intrusion Detection System (IDS) to detect internal traffic anomalies.

**B.** Configure Google Cloud Armor to allow incoming connections, configure DNS Security Extensions (DNSSEC) on Cloud DNS to secure against common web attacks, and deploy Cloud Intrusion Detection System (Cloud IDS) to detect internal traffic anomalies.

**C.** Configure Cloud Intrusion Detection System (Cloud IDS) to monitor incoming connections, deploy Identity-Aware Proxy (IAP) to block common web attacks, and deploy Google Cloud Armor to detect internal traffic anomalies.

**D.** Configure Cloud DNS to secure incoming traffic, deploy Cloud Intrusion Detection System (Cloud IDS) to detect common web attacks, and deploy Google Cloud Armor to detect internal traffic anomalies.

**Respuesta de la fuente:** A

**Explicación:** Cloud Firewall is the primary service for controlling VPC ingress traffic through allow-listing. Google Cloud Armor acts as a Web Application Firewall (WAF) to protect against specific web-based attacks like SQL injection and XSS. Cloud Intrusion Detection System (IDS) is designed specifically to monitor internal network traffic for anomalies and suspicious activity.

## Pregunta 263

Contexto: [topics:197](#topics-197)
Your organization relies heavily on virtual machines (VMs) in Compute Engine. Due to team growth and resource demands, VM sprawl is becoming problematic. Maintaining consistent security hardening and timely package updates poses an increasing challenge. You need to centralize VM image management and automate the enforcement of security baselines throughout the virtual machine lifecycle. What should you do?

**A.** Use VM Manager to automatically distribute and apply patches to YMs across your projects. Integrate VM Manager with hardened, organization-standard VM images stored in a central repository.

**B.** Configure the sole-tenancy feature in Compute Engine for all projects. Set up custom organization policies in Policy Controller to restrict the operating systems and image sources that teams are allowed to use.

**C.** Create a Cloud Build trigger to build a pipeline that generates hardened VM images. Run vulnerability scans in the pipeline, and store images with passing scans in a registry. Use instance templates pointing to this registry.

**D.** Activate Security Command Center Enterprise. Use VM discovery and posture management features to monitor hardening state and trigger automatic responses upon detection of issues.

**Respuesta de la fuente:** A

**Explicación:** VM Manager is the designated GCP service for centralizing the management of Compute Engine VMs, specifically addressing patching and configuration compliance.
It directly solves the stated challenges of 'consistent security hardening' and 'timely package updates' by automating these tasks across all projects.
The 'throughout the virtual machine lifecycle' requirement is met because VM Manager handles ongoing maintenance (patching), whereas Option C only addresses the initial image creation phase.

## Pregunta 264

Contexto: [topics:197](#topics-197)
Customers complain about error messages when they access your organization's website. You suspect that the web application firewall rules configured in Cloud Armor are too strict. You want to collect request logs to investigate what triggered the rules and blocked the traffic. What should you do?

**A.** Modify the Application Load Balancer backend and increase the tog sample rate to a higher number.

**B.** Enable logging in the Application Load Balancer backend and set the log level to VERBOSE in the Cloud Armor policy.

**C.** Change the configuration of suspicious web application firewall rules in the Cloud Armor policy to preview mode.

**D.** Create a log sink with a filter for togs containing redirected_by_security_policy and set a BigQuery dataset as destination.

**Respuesta de la fuente:** B

**Explicación:** To investigate the specific requests triggering WAF rules without altering the blocking behavior, you should enable verbose logging for the Cloud Armor policy.

Verbose logging provides detailed information about which specific rule matched and why, which standard logs do not capture.

Preview mode (Option C) would allow traffic to pass, changing the security posture rather than just collecting data for investigation.

## Pregunta 265

Contexto: [topics:197](#topics-197)
Your organization must follow the Payment Card Industry Data Security Standard (PCI DSS). To prepare for an audit, you must detect deviations on an infrastructure-as-a-service level in your Google Cloud landing zone. What should you do?

**A.** Create a data profile covering all payment relevant data types. Configure Data Discovery and a risk analysis job in Google Cloud Sensitive Data Protection to analyze findings.

**B.** Use the Google Cloud Compliance Reports Manager to download the latest version of the PCI DSS report Analyze the report to detect deviations.

**C.** Create an Assured Workloads folder in your Google Cloud organization. Migrate existing projects into the folder and monitor for deviations in the PCI DSS.

**D.** Activate Security Command Center Premium. Use the Compliance Monitoring product to filter findings that may not be PCI DSS compliant.

**Respuesta de la fuente:** D

**Explicación:** Security Command Center Premium includes Compliance Monitoring, which actively scans your infrastructure against specific security standards like PCI DSS.
It automatically detects configuration deviations and surfaces findings for non-compliant resources, allowing you to remediate issues before the audit.
Other options focus on data classification (A), static reporting (B), or workload isolation (C), none of which provide automated IaaS-level deviation detection.

## Pregunta 266

Contexto: [topics:197](#topics-197)
Your organization is migrating a complex application to Google Cloud. The application has multiple internal components that interact with each other across several Google Cloud projects. Security is a major concern, and you must design an authorization scheme for administrators that aligns with the principles of least privilege and separation of duties. What should you do?

**A.** Identify the users who will migrate the application, revoke the default user roles and assign the users with purposely created custom roles.

**B.** Use multiple external identity providers (IdP) configured to use different SAML profiles and federate the IdPs for each application component.

**C.** Configure multi-factor authentication (MFA) to enforce the use of physical tokens for all users who will migrate the application.

**D.** No action needed. When a Google Cloud organization is created, the appropriate permissions are automatically assigned to all users in the domain.

**Respuesta de la fuente:** A

**Explicación:** To adhere to the principles of least privilege and separation of duties, you must avoid broad default roles by revoking them. Assigning purpose-built custom roles ensures administrators only receive the specific permissions required for their distinct tasks, minimizing security risk.

## Pregunta 267

Contexto: [topics:197](#topics-197)
Your organization operates in a highly regulated industry and needs to implement strict controls around temporary access to sensitive Google Cloud resources. You have been using Access Approval to manage this access, but your compliance team has mandated the use of a custom signing key. Additionally, they require that the key be stored in a hardware security module (HSM) located outside Google Cloud. You need to configure Access Approval to use a custom signing key that meets the compliance requirements. What should you do?

**A.** Create a new asymmetric signing key in Cloud Key Management System (Cloud KMS) using a supported algorithm and grant the Access Approval service account the IAM signerVerifier role on the key.

**B.** Export your existing Access Approval signing key as a PEM file. Upload the file to your external HSM and reconfigure Access Approval to use the key from the HSM.

**C.** Create a signing key in your external HSM. Integrate the HSM with Cloud External Key Manager (Cloud EKM) and make the key available within your project. Configure Access Approval to use this key.

**D.** Create a new asymmetric signing key in Cloud KMS and configure the key with a rotation period of 30 days. Add the corresponding public key to your external HSM.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Cloud External Key Manager (Cloud EKM) is specifically designed to integrate Google Cloud services with external key management systems, such as on-premises Hardware Security Modules (HSMs). This setup ensures that cryptographic keys remain under the organization's control outside of Google Cloud, satisfying the strict compliance mandate for an externally stored custom signing key.

Reference: https://cloud.google.com/assured-workloads/access-approval/docs/review-approve-access-requests-custom-keys#select-key

## Pregunta 268

Contexto: [topics:197](#topics-197)
Your organization has sensitive data stored in BigQuery and Cloud Storage. You need to design a solution that provides granular and flexible control authorization to read data. What should you do?

**A.** Deidentify sensitive fields within the dataset by using data leakage protection within the Sensitive Data Protection services.

**B.** Use Cloud External Key Manager (Cloud EKM) to encrypt the data in BigQuery and Cloud Storage.

**C.** Grant identity and access management (IAM) roles and permissions to principals.

**D.** Enable server-side encryption on the data in BigQuery and Cloud Storage.

**Respuesta de la fuente:** C

**Explicación:** IAM is the primary mechanism in Google Cloud for enforcing granular access controls by assigning specific roles and permissions to principals. This allows precise authorization of read operations on individual BigQuery datasets/tables and Cloud Storage objects, directly addressing the requirement for flexible control.

## Pregunta 269

Contexto: [topics:197](#topics-197)
Your organization is using Security Command Center Premium as a central tool to detect and alert on security threats. You also want to alert on suspicious outbound traffic that is targeting domains of known suspicious web services. What should you do?

**A.** Create a DNS Server Policy in Cloud DNS and turn on logs. Attach this policy to all Virtual Private Cloud networks with internet connectivity.

**B.** Forward all logs to Chronicle Security Information and Event Management. Create an alert for suspicious egress traffic to the internet.

**C.** Create a Cloud Intrusion Detection endpoint. Connect this endpoint to all Virtual Private Cloud networks with internet connectivity.

**D.** Create an egress firewall policy with Threat Intelligence as the destination. Attach this policy to all Virtual Private Cloud networks with internet connectivity.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Cloud Firewall Policies support Google Threat Intelligence as a destination for egress rules, allowing you to dynamically match traffic against known suspicious domains and IPs.
This approach directly addresses the requirement within the Security Command Center Premium ecosystem by generating findings or logs when matches occur, without requiring additional services like Chronicle (Option B) or DNS logging alone (Option A).

## Pregunta 270

Contexto: [topics:197](#topics-197)
You work for a healthcare provider that is expanding into the cloud to store and process sensitive patient data. You must ensure the chosen Google Cloud configuration meets these strict regulatory requirements:

•	Data must reside within specific geographic regions.
•	Certain administrative actions on patient data require explicit approval from designated compliance officers.
•	Access to patient data must be auditable.

What should you do?

**A.** Select a standard Google Cloud region. Restrict access to patient data based on user location and job function by using Access Context Manager. Enable both Cloud Audit Logging and Access Transparency.

**B.** Deploy an Assured Workloads environment in an approved region. Configure Access Approval for sensitive operations on patient data. Enable both Cloud Audit Logs and Access Transparency.

**C.** Deploy an Assured Workloads environment in multiple regions for redundancy. Utilize custom IAM roles with granular permissions. Isolate network-level data by using VPC Service Controls.

**D.** Select multiple standard Google Cloud regions for high availability. Implement Access Control Lists (ACLs) on individual storage objects containing patient data. Enable Cloud Audit Logs.

**Respuesta de la fuente:** B

**Explicación:** Assured Workloads is specifically designed to meet strict regulatory requirements like HIPAA by enforcing data residency within approved regions and isolating workloads.
Access Approval addresses the requirement for explicit compliance officer approval on sensitive administrative actions, which standard IAM cannot handle alone.
Cloud Audit Logs and Access Transparency together provide the necessary comprehensive auditing of both customer and Google employee access.

## Pregunta 271

Contexto: [topics:197](#topics-197)
You work for a multinational organization that has systems deployed across multiple cloud providers, including Google Cloud. Your organization maintains an extensive on-premises security information and event management (SIEM) system. New security compliance regulations require that relevant Google Cloud logs be integrated seamlessly with the existing SIEM to provide a unified view of security events. You need to implement a solution that exports Google Cloud logs to your on-premises SIEM by using a push-based, near real-time approach. You must prioritize fault tolerance, security, and auto scaling capabilities. In particular, you must ensure that if a log delivery fails, logs are re-sent. What should you do?

**A.** Create a Pub/Sub topic for log aggregation. Write a custom Python script on a Cloud Function Leverage the Cloud Logging API to periodically pull logs from Google Cloud and forward the logs to the SIEM. Schedule the Cloud Function to run twice per day.

**B.** Collect all logs into an organization-level aggregated log sink and send the logs to a Pub/Sub topic. Implement a primary Dataflow pipeline that consumes logs from this Pub/Sub topic and delivers the logs to the SIEM. Implement a secondary Dataflow pipeline that replays failed messages.

**C.** Deploy a Cloud Logging sink with a filter that routes all logs directly to a syslog endpoint. The endpoint is based on a single Compute Engine hosted on Google Cloud that routes all logs to the on-premises SIEM. Implement a Cloud Function that triggers a retry action in case of failure.

**D.** Utilize custom firewall rules to allow your SIEM to directly query Google Cloud logs. Implement a Cloud Function that notifies the SIEM of a failed delivery and triggers a retry action.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it leverages Cloud Logging sinks to Pub/Sub for near real-time export and Dataflow for auto-scaling, fault-tolerant processing. The secondary pipeline specifically addresses the requirement to re-send failed logs, ensuring data integrity and resilience that options A, C, and D lack due to their pull-based, single-point-of-failure, or insecure designs.

## Pregunta 272

Contexto: [topics:197](#topics-197)
You work for a global company. Due to compliance requirements, certain Compute Engine instances that reside within specific projects must be located exclusively in cloud regions within the European Union (EU). You need to ensure that existing non-compliant workloads are remediated and prevent future Compute Engine instances from being launched in restricted regions. What should you do?

**A.** Use a third-party configuration management tool to monitor the location of Compute Engine instances. Automatically delete or migrate non-compliant instances, including existing deployments.

**B.** Deploy a Security Command Center source to detect Compute Engine instances created outside the EU. Use a custom remediation function to automatically relocate the instances, run the function once a day.

**C.** Use organization policy constraints in Resource Manager to enforce allowed regions for Compute Engine instance creation within specific projects.

**D.** Set an organization policy that denies the creation of Compute Engine instances outside the EU. Apply the policy to the appropriate projects. Identify existing non-compliant instances and migrate the instances to compliant EU regions.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it addresses both requirements of the scenario: prevention and remediation.
Organization policies (specifically `constraints/gcp.resourceLocations`) enforce region restrictions at creation time, preventing future non-compliant deployments.
However, organization policies do not automatically migrate existing resources; therefore, you must separately identify and move current non-compliant instances to satisfy the compliance mandate.

## Pregunta 273

Contexto: [topics:197](#topics-197)
You are working with developers to secure custom training jobs running on Vertex AI. For compliance reasons, all supported data types must be encrypted by key materials that reside in the Europe region and are controlled by your organization. The encryption activity must not impact the training operation in Vertex AI. What should you do?

**A.** Encrypt the code, training data, and metadata with Google default encryption. Use customer-managed encryption keys (CMEK) for the trained models exported to Cloud Storage buckets.

**B.** Encrypt the code, training data, metadata, and exported trained models with customer-managed encryption keys (CMEK).

**C.** Encrypt the code, training data, and exported trained models with customer-managed encryption keys (CMEK).

**D.** Encrypt the code, training data, and metadata with Google default encryption. Implement an organization policy that enforces a constraint to restrict the Cloud KMS location to the Europe region.

**Respuesta de la fuente:** B

**Explicación:** The requirement specifies that 'all supported data types' must be encrypted with organization-controlled keys. In Vertex AI, user-supplied artifacts like code, training data, and exported models are the primary data types eligible for Customer-Managed Encryption Keys (CMEK). Metadata is typically encrypted by default Google-managed mechanisms and cannot be targeted by CMEK in this context, nor does the question require encrypting metadata if it's not a 'supported' type for CMEK. Option B correctly identifies that CMEK should be used for the relevant data artifacts (code, data, models) to meet the compliance control requirement, while implicitly accepting standard encryption for non-CMEK-eligible items like internal operational metadata which is not under user key control anyway.

## Pregunta 274

Contexto: [topics:197](#topics-197)
Your EU-based organization stores both Personally Identifiable Information (PII) and non-PII data in Cloud Storage buckets across multiple Google Cloud regions. EU data privacy laws require that the PII data must not be stored outside of the EU. To help meet this compliance requirement, you want to detect if Cloud Storage buckets outside of the EU contain healthcare data. What should you do?

**A.** Create a Sensitive Data Protection job. Specify the infoType of data to be detected and run the job across all Google Cloud Storage buckets.

**B.** Create a log sink with a filter on resourceLocation.currentLocations. Trigger an alert if a log message appears with a non- EUcountry.

**C.** Activate Security Command Center Premium. Use compliance monitoring to detect resources that do not follow the applicable healthcare regulation.

**D.** Enforce the gcp.resourceLocations organization policy and add "EU" in a custom rule that only applies on resources with the tag "healthcare".

**Respuesta de la fuente:** A

**Explicación:** The requirement is to detect the presence of specific sensitive data (healthcare/PII) within Cloud Storage buckets. Google Cloud Data Loss Prevention (DLP), accessed via Sensitive Data Protection, provides Inspect Jobs designed specifically to scan storage resources for predefined infoTypes. By running these jobs across all buckets, you can identify exactly which non-EU buckets contain the prohibited healthcare data.

## Pregunta 275

Contexto: [topics:197](#topics-197)
Your organization is migrating business critical applications to Google Cloud across multiple projects. You only have the required IAM permission at the Google Cloud organization level. You want to grant project access to support engineers from two partner organizations using their existing identity provider (IdP) credentials. What should you do?

**A.** Create two single sign-on (SSO) profiles for the internal and partner IdPs by using SSO for Cloud Identity.

**B.** Create users manually by using the Google Cloud console. Assign the users to groups.

**C.** Create two workforce identity pools for the partner IdPs.

**D.** Sync user identities from their existing IdPs to Cloud Identity by using Google Cloud Directory Sync (GCDS).

**Respuesta de la fuente:** C

**Explicación:** Workforce Identity Federation is the correct solution because it allows users from external identity providers (such as partner organizations) to access Google Cloud resources using their existing credentials without creating local user accounts. This 'syncless' approach supports B2B scenarios by establishing trust with external IdPs via identity pools, enabling direct IAM role assignment based on federated attributes rather than synchronized directory entries.

## Pregunta 276

Contexto: [topics:197](#topics-197)
You are creating a secure network architecture. You must fully isolate development and production environments, and prevent any network traffic between the two environments. The network team requires that there is only one central entry point to the cloud network from the on-premises environment. What should you do?

**A.** Create one Virtual Private Cloud (VPC) network per environment. Add the on-premises entry point to the production VPC. Peer the VPCs with each other and create firewall rules to prevent traffic.

**B.** Create one shared Virtual Private Cloud (VPC) network and use it as the entry point to the cloud network. Create separate subnets per environment. Create firewall rules to prevent traffic.

**C.** Create one Virtual Private Cloud (VPC) network per environment. Create a VPC Service Controls perimeter per environment and add one environment VPC to each.

**D.** Create one Virtual Private Cloud (VPC) network per environment. Create one additional VPC for the entry point to the cloud network. Peer the entry point VPC with the environment VPCs.

**Respuesta de la fuente:** D

**Explicación:** Option D implements a hub-and-spoke architecture using VPC Network Peering.
Since VPC peering is non-transitive, traffic between the development and production spokes cannot flow through the central entry point (hub), ensuring full isolation.
This design also satisfies the requirement for a single on-premises connection point via the hub VPC.

## Pregunta 277

Contexto: [topics:197](#topics-197)
You work for a large organization that is using Cloud Identity as the identity provider (IdP) on Google Cloud. Your InfoSec team has mandated the enforcement of a strong password with a length between 12 and 16 characters for all users. After configuring this requirement, users are still able to access the Google Cloud console with passwords that are less than 12 characters. You need to fix this problem within the Admin console. What should you do?

**A.** Review each user's password configuration and reset existing passwords.

**B.** Review the organization password management setting and select Enforce password policy at the next sign-in.

**C.** Review each user's password configuration and select Enforce strong password.

**D.** Review the organization password management setting and select Enforce strong password.

**Respuesta de la fuente:** B

**Explicación:** Changing the password policy configuration only applies to future password changes; it does not automatically invalidate existing passwords that do not meet the new criteria. To force users with non-compliant passwords to update them, you must enable the 'Enforce password policy at the next sign-in' setting in the organization's password management settings.

## Pregunta 278

Contexto: [topics:197](#topics-197)
Your organization is preparing to build business services in Google Cloud for the first time. You must determine where to apply appropriate controls or policies. You must also identify what aspects of your cloud deployment are managed by Google. What should you do?

**A.** Model your deployment on the Google Enterprise foundations blueprint. Follow the blueprint exactly and rely on the blueprint to maintain the posture necessary for your business.

**B.** Use the Risk Manager tool in the Risk Protection Program to generate a report on your cloud security posture. Obtain cyber insurance coverage.

**C.** Subscribe to the Google Cloud release notes to keep up on product updates and when new services are available. Evaluate new services for appropriate use before enabling their API.

**D.** Study the shared responsibilities model. Depending on your business scenario, you might need to consider your responsibilities based on the location of your business offices, your customers, and your data.

**Respuesta de la fuente:** D

**Explicación:** The question explicitly asks to determine where controls are applied and what is managed by Google, which is the definition of the shared responsibility model.
Option D directly addresses this by identifying the need to study this model to distinguish between Google's infrastructure responsibilities and the customer's workload responsibilities.

## Pregunta 279

Contexto: [topics:197](#topics-197)
Your organization operates a hybrid cloud environment and has recently deployed a private Artifact Registry repository in Google Cloud. On-premises developers cannot resolve the Artifact Registry hostname and therefore cannot push or pull artifacts. You've verified the following:

•	Connectivity to Google Cloud is established by Cloud VPN or Cloud Interconnect.
•	No custom DNS configurations exist on-premises.
•	There is no route to the internet from the on-premises network.

You need to identify the cause and enable the developers to push and pull artifacts. What is likely causing the issue and what should you do to fix the issue?

**A.** On-premises DNS servers lack the necessary records to resolve private Google API domains. Create DNS records for restricted.googleapis.com or private.googleapis.com pointing to Google's published IP ranges.

**B.** Developers must be granted the artifactregistry.writer IAM role. Grant the relevant developer group this role.

**C.** Private Google Access is not enabled for the subnet hosting the Artifact Registry. Enable Private Google Access for the appropriate subnet.

**D.** Artifact Registry requires external HTTP/HTTPS access. Create a new firewall rule allowing ingress traffic on ports 80 and 443 from the developer's IP ranges.

**Respuesta de la fuente:** A

**Explicación:** The issue is a DNS resolution failure because on-premises developers lack internet access to resolve public Artifact Registry hostnames. By configuring local DNS records for private.googleapis.com, the hostname resolves to Google’s private IP ranges, allowing traffic to route over the established Cloud VPN or Interconnect link instead of failing due to missing internet connectivity.

## Pregunta 280

Contexto: [topics:197](#topics-197)
Your organization has an application hosted in Cloud Run. You must control access to the application by using Cloud Identity-Aware Proxy (IAP) with these requirements:

•	Only users from the AppDev group may have access.
•	Access must be restricted to internal network IP addresses.

What should you do?

**A.** Deploy a VPN gateway and instruct the AppDev group to connect to the company network before accessing the application.

**B.** Create an access level that includes conditions for internal IP address ranges and AppDev groups. Apply this access level to the application's IAP policy.

**C.** Configure firewall rules to limit access to IAP based on the AppDev group and source IP addresses.

**D.** Configure IAP to enforce multi-factor authentication (MFA) for all users and use network intrusion detection systems (NIDS) to block unauthorized access attempts.

**Respuesta de la fuente:** B

**Explicación:** Cloud Identity-Aware Proxy (IAP) uses Access Levels defined in Access Context Manager to enforce fine-grained access policies.
Option B correctly describes creating an Access Level that combines user identity conditions (AppDev group membership) and device/network conditions (internal IP ranges).
This composite policy is then applied to the Cloud Run service's IAP configuration to restrict access accordingly.

## Pregunta 281

Contexto: [topics:197](#topics-197)
You just implemented a Secure Web Proxy instance on Google Cloud for your organization. You were able to reach the internet when you tested this configuration on your test instance. However, developers cannot access the allowed URLs on the Secure Web Proxy instance from their Linux instance on Google Cloud. You want to solve this problem with developers. What should you do?

**A.** Configure a Cloud NAT gateway to enable internet access from the developer instance subnet.

**B.** Ensure that the developers have restarted their instance and HTTP service is enabled.

**C.** Ensure that the developers have explicitly configured the proxy address on their instance.

**D.** Configure a firewall rule to allow HTTP/S from the developer instance.

**Respuesta de la fuente:** C

**Explicación:** Secure Web Proxy requires client-side configuration to intercept traffic; it does not automatically redirect HTTP/S requests without explicit proxy settings.
Since the proxy instance itself is functional, developers must configure their Linux instances with the proxy address and port to route their web traffic through it.

## Pregunta 282

Contexto: [topics:197](#topics-197)
You have just created a new log bucket to replace the _Default log bucket. You want to route all log entries that are currently routed to the _Default log bucket to this new log bucket, in the most efficient manner. What should you do?

**A.** Create exclusion filters for the _Default sink to prevent it from receiving new logs. Create a user-defined sink, and select the new log bucket as the sink destination.

**B.** Disable the _Default sink. Create a user-defined sink and select the new log bucket as the sink destination.

**C.** Create a user-defined sink with inclusion filters copied from the _Default sink. Select the new log bucket as the sink destination.

**D.** Edit the _Default sink, and select the new log bucket as the sink destination.

**Respuesta de la fuente:** D

**Explicación:** The _Default sink is a pre-configured system sink that can be edited to change its destination.
Editing this existing sink to point to the new log bucket is the most efficient method because it avoids the overhead of creating additional user-defined sinks or managing complex inclusion/exclusion filters.
This approach ensures all logs previously routed to _Default are seamlessly redirected without interruption.

## Pregunta 283

Contexto: [topics:197](#topics-197)
Your organization's use of the Google Cloud has grown substantially and there are many different groups using different cloud resources independently. You must identify common misconfigurations and compliance violations across the organization and track findings for remedial action in a dashboard. What should you do?

**A.** Create a filter set in Cloud Asset Inventory to identify service accounts with high privileges and IAM principals with Gmail domains.

**B.** Scan and alert vulnerabilities and misconfigurations by using Secure Health Analytics detectors in Security Command Center Premium.

**C.** Set up filters on Cloud Audit Logs to flag log entries for specific, risky API calls, and display the calls in a Cloud Log Analytics dashboard.

**D.** Alert and track emerging attacks detected in your environment by using Event Threat Detection detectors.

**Respuesta de la fuente:** B

**Explicación:** Security Command Center Premium includes Security Health Analytics (SHA), which specifically scans resources for common misconfigurations and compliance violations. SHA aggregates these findings into a central dashboard, allowing you to track and prioritize remedial actions across the organization as required.

## Pregunta 284

Contexto: [topics:197](#topics-197)
You are responsible for a set of Cloud Functions running on your organization's Google Cloud environment. During the last annual security review, secrets were identified in environment variables of some of these Cloud Functions. You must ensure that secrets are identified in a timely manner. What should you do?

**A.** Implement regular peer reviews to assess the environment variables and identify secrets in your Cloud Functions. Raise a security incident if secrets are discovered.

**B.** Implement a Cloud Function that scans the environment variables multiple times a day, and creates a finding in Security Command Center if secrets are discovered.

**C.** Use Sensitive Data Protection to scan the environment variables multiple times per day, and create a finding in Security Command Center if secrets are discovered.

**D.** Integrate dynamic application security testing into the CI/CD pipeline that scans the application code for the Cloud Functions. Fail the build process if secrets are discovered.

**Respuesta de la fuente:** C

**Explicación:** Option C is the correct answer because Google Cloud's Sensitive Data Protection (part of Security Command Center) has a built-in 'Secrets in environment variables' scanner specifically designed to detect secrets in Cloud Functions.

This native tool runs periodic scans without requiring custom code or complex CI/CD integration, directly addressing the requirement for timely identification within the GCP ecosystem.

## Pregunta 285

Contexto: [topics:197](#topics-197)
Your organization 1s developing a new SaaS application on Google Cloud. Stringent compliance standards require visibility into privileged account activity, and potentially unauthorized changes and misconfigurations to the application's infrastructure. You need to monitor administrative actions, log changes to IAM roles and permissions, and be able to trace potentially unauthorized configuration changes. What should you do?

**A.** Create log sinks to Cloud Storage for long-term retention. Set up log-based alerts in Cloud Logging based on relevant log types. Enable VPC Flow Logs for network visibility.

**B.** Deploy Cloud IDS and activate Firewall Rules Logging. Create a custom dashboard in Security Command Center to visualize potential intrusion attempts.

**C.** Detect sensitive administrative actions by using Cloud Logging with custom filters. Enable VPC Flow Logs with BigQuery exports for rapid analysis of network traffic patterns.

**D.** Enable Event Threat Detection and Security Health Analytics in Security Command Center. Set up detailed logging for IAM-related activity and relevant project resources by deploying Cloud Audit Logs.

**Respuesta de la fuente:** D

**Explicación:** The question requires monitoring privileged activity and detecting unauthorized misconfigurations. Cloud Audit Logs provide the granular data needed to trace administrative actions and IAM changes, while Security Health Analytics specifically identifies infrastructure misconfigurations.
Option D is the correct choice because it combines these two services to address both logging requirements and automated security posture detection.

## Pregunta 286

Contexto: [topics:197](#topics-197)
Your application development team is releasing a new critical feature. To complete their final testing, they requested 10 thousand real transaction records. The new feature includes format checking on the primary account number (PAN) of a credit card. You must support the request and minimize the risk of unintended personally identifiable information (PII) exposure. What should you do?

**A.** Run the new application by using Confidential Computing to ensure PII and card PAN is encrypted in use.

**B.** Scan and redact PII from the records by using the Cloud Data Loss Prevention API. Perform format-preserving encryption on the card PAN.

**C.** Encrypt the records by using Cloud Key Management Service to protect the PII and card PAN.

**D.** Build a tool to replace the card PAN and PII fields with randomly generated values.

**Respuesta de la fuente:** B

**Explicación:** The requirement to test PAN format checking necessitates that the data retains its original structure (length and checksum) while being rendered non-sensitive. Format-preserving encryption (FPE) replaces real PANs with synthetic values that maintain this structure, enabling valid testing without exposing actual card numbers.
Additionally, using Cloud DLP API to scan and redact other PII ensures comprehensive protection of the dataset beyond just the credit card information.

## Pregunta 287

Contexto: [topics:197](#topics-197)
You work for a banking organization. You are migrating sensitive customer data to Google Cloud that is currently encrypted at rest while on-premises. There are strict regulatory requirements when moving sensitive data to the cloud. Independent of the cloud service provider, you must be able to audit key usage and be able to deny certain types of decrypt requests. You must choose an encryption strategy that will ensure robust security and compliance with the regulations. What should you do?

**A.** Utilize Google default encryption and Cloud IAM to keep the keys within your organization's control.

**B.** Implement Cloud External Key Manager (Cloud EKM) with Access Approval, to integrate with your existing on-premises key management solution.

**C.** Implement Cloud External Key Manager (Cloud EKM) with Key Access Justifications to integrate with your existing one premises key management solution.

**D.** Utilize customer-managed encryption keys (CMEK) created in a dedicated Google Compute Engine instance with Confidential Compute encryption, under your organization's control.

**Respuesta de la fuente:** C

**Explicación:** Cloud External Key Manager (Cloud EKM) is the correct service because it keeps encryption keys entirely outside Google's infrastructure, satisfying the requirement for independence from the cloud provider.
Among the options, only Cloud EKM supports Key Access Justifications, a feature that mandates users provide a reason for decryption requests.
This justification mechanism enables the external key manager to programmatically audit and deny specific decrypt operations, directly fulfilling the compliance requirements.

## Pregunta 288

Contexto: [topics:197](#topics-197)
Your organization is developing an application that will have both corporate and public end-users. You want to centrally manage those customers' identities and authorizations. Corporate end users must access the application by using their corporate user and domain name. What should you do?

**A.** Add the corporate and public end-user domains to domain restricted sharing on the organization.

**B.** Federate the customers' identity provider (IdP) with Workforce Identity Federation in your application's project.

**C.** Do nothing. Google Workspace identities will allow you to filter personal accounts and disable their access.

**D.** Use a customer identity and access management tool (CIAM) like Identity Platform.

**Respuesta de la fuente:** D

**Explicación:** Identity Platform is a Customer Identity and Access Management (CIAM) solution designed to manage authentication for external customers and public end-users. Workforce Identity Federation is intended for managing access for internal employees or partners, not for public-facing application users.

## Pregunta 289

Contexto: [topics:197](#topics-197)
You work for an organization that handles sensitive customer data. You must secure a series of Google Cloud Storage buckets housing this data and meet these requirements:

•	Multiple teams need varying access levels (some read-only, some read-write).
•	Data must be protected in storage and at rest.
•	It's critical to track file changes and audit access for compliance purposes.
•	For compliance purposes, the organization must have control over the encryption keys.

What should you do?

**A.** Create IAM groups for each team and manage permissions at the group level. Employ server-side encryption and Object Versioning by Google Cloud Storage. Configure cloud monitoring tools to alert on anomalous data access patterns.

**B.** Set individual permissions for each team and apply access control lists (ACLs) to each bucket and file. Enforce TLS encryption for file transfers. Enable Object Versioning and Cloud Audit Logs for the storage buckets.

**C.** Use predefined IAM roles tailored to each team's access needs, such as Storage Object Viewer and Storage Object User. Utilize customer-supplied encryption keys (CSEK) and enforce TLS encryption. Turn on both Object Versioning and Cloud Audit Logs for the storage buckets.

**D.** Assign IAM permissions for all teams at the object level. Implement third-party software to encrypt data at rest. Track data access by using network logs.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it uses predefined IAM roles to enforce least-privilege access for different teams. It satisfies the key control requirement by employing Customer-Supplied Encryption Keys (CSEK), ensuring the organization retains ownership of encryption keys. Finally, it meets compliance tracking needs by enabling both Object Versioning and Cloud Audit Logs.

## Pregunta 290

Contexto: [topics:197](#topics-197)
You are implementing communications restrictions for specific services in your Google Cloud organization. Your data analytics team works in a dedicated folder. You need to ensure that access to BigQuery is controlled for that folder and its projects. The data analytics team must be able to control the restrictions only at the folder level. What should you do?

**A.** Create an organization-level access policy with a service perimeter to restrict BigQuery access. Assign the data analytics team the Access Context Manager Editor role on the access policy to allow the team to configure the access policy.

**B.** Create a scoped policy on the folder with a service perimeter to restrict BigQuery access. Assign the data analytics team the Access Context Manager Editor role on the scoped policy to allow the team to configure the scoped policy.

**C.** Define a hierarchical firewall policy on the folder to deny BigQuery access. Assign the data analytics team the Compute Organization Firewall Policy Admin role to allow the team to configure rules for the firewall policy.

**D.** Enforce the Restrict Resource Service Usage organization policy constraint on the folder to restrict BigQuery access. Assign the data analytics team the Organization Policy Administrator role to allow the team to manage exclusions within the folder.

**Respuesta de la fuente:** B

**Explicación:** VPC Service Controls, specifically Service Perimeters, are the correct mechanism to restrict data access within BigQuery and other sensitive services.
A scoped policy allows administrators to delegate management permissions for these security resources at a specific organizational unit (like a folder) without granting organization-wide privileges.
This satisfies the requirement for the team to control restrictions only at the folder level, whereas firewall policies (C) apply to network traffic, not data access, and OPCs (D) typically block service usage entirely rather than managing perimeter access.

## Pregunta 291

Contexto: [topics:197](#topics-197)
Your organization шs using a third-party identity and authentication provider to centrally manage users. You want to use this identity provider to grant access to the Google Cloud console without syncing identities to Google Cloud. Users should receive permissions based on attributes. What should you do?

**A.** Configure the central identity provider as a workforce identity pool provider in Workforce Identity Federation. Create an attribute mapping by using the Common Expression Language (CEL).

**B.** Configure a periodic synchronization of relevant users and groups with attributes to Cloud Identity. Activate single sign-on by using the Security Assertion Markup Language (SAML).

**C.** Set up the Google Cloud Identity Platform. Configure an external authentication provider by using OpenID Connect and link user accounts based on attributes.

**D.** Activate external identities on the Identity-Aware Proxy. Use the Security Assertion Markup Language (SAML) to configure authentication based on attributes to the central authentication provider.

**Respuesta de la fuente:** A

**Explicación:** Workforce Identity Federation allows organizations to grant their workforce access to Google Cloud resources using a third-party identity provider without syncing identities. It supports attribute-based access control through Common Expression Language (CEL) mappings, directly satisfying the requirement to avoid user synchronization while granting permissions based on attributes.

## Pregunta 292

Contexto: [topics:197](#topics-197)
You are implementing a new web application on Google Cloud that will be accessed from your on-premises network. To provide protection from threats like malware, you must implement transport layer security (TLS) interception for incoming traffic to your application. What should you do?

**A.** Configure Secure Web Proxy. Offload the TLS traffic in the load balancer, inspect the traffic, and forward the traffic to the web application.

**B.** Configure an internal proxy load balancer. Offload the TLS traffic in the load balancer inspect, the traffic and forward the traffic to the web application.

**C.** Configure a hierarchical firewall policy. Enable TLS interception by using Cloud Next Generation Firewall (NGFW) Enterprise.

**D.** Configure a VPC firewall rule. Enable TLS interception by using Cloud Next Generation Firewall (NGFW) Enterprise.

**Respuesta de la fuente:** C

**Explicación:** Google Cloud Next Generation Firewall (NGFW) Enterprise provides Layer 7 security capabilities, including TLS inspection, which allows the firewall to decrypt, inspect, and re-encrypt traffic to detect threats like malware.

This feature is configured via hierarchical firewall policies attached to VPC networks or subnets. Standard VPC firewall rules (Layer 3/4) and standard load balancers do not support native deep packet inspection or TLS decryption for security purposes.

## Pregunta 293

Contexto: [topics:197](#topics-197)
Your organization has hired a small, temporary partner team for 18 months. The temporary team will work alongside your DevOps team to develop your organization's application that is hosted on Google Cloud. You must give the temporary partner team access to your application's resources on Google Cloud and ensure that partner employees lose access. If they are removed from their employer's organization. What should you do?

**A.** Create a temporary username and password for the temporary partner team members. Auto-clean the usernames and passwords after the work engagement has ended.

**B.** Create a workforce identity pool and federate the identity pool with the identity provider (IdP) of the temporary partner team.

**C.** Implement just-in-time privileged access to Google Cloud for the temporary partner team.

**D.** Add the identities of the temporary partner team members to your identity provider (IdP).

**Respuesta de la fuente:** B

**Explicación:** Workforce Identity Federation allows Google Cloud to trust identities from an external Identity Provider (IdP) without creating managed user accounts.
By federating with the partner's IdP, access is automatically revoked when the partner deactivates an employee's account in their own system, satisfying the requirement for automatic removal without manual intervention.

## Pregunta 294

Contexto: [topics:197](#topics-197)
Your organization has an internet-facing application behind a load balancer. Your regulators require end-to-end encryption of user login credentials. You must implement this requirement. What should you do?

**A.** Generate a symmetric key with Cloud KMS. Encrypt client-side user credentials by using the symmetric key.

**B.** Concatenate the credential with a timestamp. Submit the timestamp and hashed value of credentials to the network.

**C.** Deploy the TLS certificate at Google Cloud Global HTTPs Load Balancer, and submit the user credentials through HTTPs.

**D.** Generate an asymmetric key with Cloud KMS. Encrypt client-side user credentials using the public key.

**Respuesta de la fuente:** C

**Explicación:** The question specifies an application behind a Google Cloud Global HTTP(S) Load Balancer. To meet the requirement for encrypting credentials in transit (often colloquially referred to as end-to-end in this context, meaning client-to-LB and LB-to-backend), deploying TLS certificates at the load balancer is the standard, scalable method provided by the service.

Option C is correct because Google Cloud's HTTP(S) Load Balancers support native SSL/TLS termination and can be configured to re-encrypt traffic to backends (SSL bridging), ensuring credentials are encrypted across the entire path.

Option D is incorrect because encrypting individual fields on the client-side using KMS public keys introduces significant latency, complexity, and scalability issues that contradict the intended use of a load balancer for TLS termination.

## Pregunta 295

Contexto: [topics:197](#topics-197)
Your organization heavily utilizes serverless applications while prioritizing security best practices. You are responsible for enforcing image provenance and compliance with security standards before deployment. You leverage Cloud Build as your continuous integration and continuous deployment (CI/CD) tool for building container images. You must configure Binary Authorization to ensure that only images built by your Cloud Build pipeline are deployed and that the images pass security standard compliance checks. What should you do?

**A.** Create a Binary Authorization attestor that uses a scanner to assess source code management repositories. Deploy images only if the attestor validates results against a security policy.

**B.** Create a Binary Authorization attestor that utilizes a scanner to evaluate container image build processes. Define a policy that requires deployment of images only if this attestation is present.

**C.** Create a Binary Authorization attestor that retrieves the Cloud Build build ID of the container image. Configure a policy to allow deployment only if there's a matching build ID attestation.

**D.** Utilize a custom Security Health Analytics module to create a policy. Enforce the policy through Binary Authorization to prevent deployment of images that do not meet predefined security standards.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it addresses both requirements: enforcing provenance and security compliance. Binary Authorization attestors can be configured to use automated scanners (like Container Analysis) during the build process to verify that images meet security standards. The policy then restricts deployment to only those images bearing this specific attestation, ensuring they passed both the build pipeline validation and security checks.

## Pregunta 296

Contexto: [topics:197](#topics-197)
Your organization operates in a highly regulated industry and uses multiple Google Cloud services. You need to identify potential risks to regulatory compliance. Which situation introduces the greatest risk?

**A.** The security team mandates the use of customer-managed encryption keys (CMEK) for all data classified as sensitive.

**B.** Sensitive data is stored in a Cloud Storage bucket with the uniform bucket-level access setting enabled.

**C.** The audit team needs access to Cloud Audit Logs related to managed services like BigQuery.

**D.** Principals have broad IAM roles allowing the creation and management of Compute Engine VMs without a pre-defined hardening process.

**Respuesta de la fuente:** D

**Explicación:** Option D presents the greatest risk because broad IAM roles violate the principle of least privilege, enabling users to deploy resources without security constraints.
Without a mandatory hardening process, Compute Engine VMs can be provisioned with default configurations or vulnerabilities that directly breach regulatory security standards.
In contrast, Options A and B represent strong security controls (encryption and access uniformity), and Option C describes a standard compliance monitoring activity.

## Pregunta 297

Contexto: [topics:197](#topics-197)
Your multinational organization is undergoing rapid expansion within Google Cloud. New teams and projects are added frequently. You are concerned about the potential for inconsistent security policy application and permission sprawl across the organization. You must enforce consistent standards while maintaining the autonomy of regional teams. You need to design a strategy to effectively manage IAM and organization policies at scale, ensuring security and administrative efficiency. What should you do?

**A.** Create detailed organization-wide policies for common scenarios. Instruct teams to apply the policies carefully at the project and resource level as needed.

**B.** Delegate the creation of organization policies to regional teams. Centrally review these policies for compliance before deployment.

**C.** Define a small set of essential organization policies. Supplement these policies with a library of optional policy templates for teams to leverage as needed.

**D.** Use a hierarchical structure of folders. Implement template-based organization policies that cascade down, allowing limited customization by regional teams.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it leverages Google Cloud's resource hierarchy (Organization > Folders > Projects) to enforce consistent security baselines via cascading Organization Policies.
By using folders to group regional teams, central administrators can apply mandatory constraints that automatically inherit downwards, preventing permission sprawl while allowing localized customization within defined limits.

## Pregunta 298

Contexto: [topics:197](#topics-197)
A security audit uncovered several inconsistencies in your project's Identity and Access Management (IAM) configuration. Some service accounts have overly permissive roles, and a few external collaborators have more access than necessary. You need to gain detailed visibility into changes to IAM policies, user activity, service account behavior, and access to sensitive projects. What should you do?

**A.** Configure Google Cloud Functions to be triggered by changes to IAM policies. Analyze changes by using the policy simulator, send alerts upon risky modifications, and store event details.

**B.** Enable the metrics explorer in Cloud Monitoring to follow the service account authentication events and build alerts linked on it.

**C.** Use Cloud Audit Logs. Create log export sinks to send these logs to a security information and event management (SIEM) solution for correlation with other event sources.

**D.** Deploy the OS Config Management agent to your VMs. Use OS Config Management to create patch management jobs and monitor system modifications.

**Respuesta de la fuente:** C

**Explicación:** Cloud Audit Logs are the native Google Cloud service designed to provide detailed records of administrator actions (IAM policy changes) and access activity across resources.
Exporting these logs to a SIEM solution allows for centralized correlation, advanced analysis, and persistent storage, meeting the requirement for comprehensive visibility into user activity and service account behavior.

## Pregunta 299

Contexto: [topics:197](#topics-197)
You manage multiple internal-only applications that are hosted within different Google Cloud projects. You are deploying a new application that requires external internet access. To maintain security, you want to clearly separate this new application from internal systems. Your solution must have effective security isolation for the new externally-facing application. What should you do?

**A.** Deploy the application within the same project as an internal application. Use a Shared VPC model to manage network configurations.

**B.** Place the application in the same project as an existing internal application, and adjust firewall rules to allow external traffic.

**C.** Create a VPC Service Controls perimeter, and place the new application’s project within that perimeter.

**D.** Create a new project for the application, and use VPC Network Peering to access necessary resources in the internal projects.

**Respuesta de la fuente:** C

**Explicación:** VPC Service Controls (Answer C) provide the strongest security isolation by enforcing a boundary that restricts data exfiltration and limits access to sensitive resources, directly addressing the requirement for effective isolation of the new externally-facing application from internal systems. Placing the external app in its own perimeter prevents unauthorized lateral movement or data leakage even if the application is compromised, whereas VPC Network Peering (Answer D) creates network connectivity that inherently reduces isolation by exposing IP ranges to potential scanning or attacks.

## Pregunta 300

Contexto: [topics:197](#topics-197)
You work for an ecommerce company that stores sensitive customer data across multiple Google Cloud regions. The development team has built a new 3-tier application to process orders and must integrate the application into the production environment.

You must design the network architecture to ensure strong security boundaries and isolation for the new application, facilitate secure remote maintenance by authorized third-party vendors, and follow the principle of least privilege. What should you do?

**A.** Create separate VPC networks for each tier. Use VPC peering between application tiers and other required VPCs. Provide vendors with SSH keys and root access only to the instances within the VPC for maintenance purposes.

**B.** Create a single VPC network and create different subnets for each tier. Create a new Google project specifically for the third-party vendors and grant the network admin role to the vendors. Deploy a VPN appliance and rely on the vendors’ configurations to secure third-party access.

**C.** Create separate VPC networks for each tier. Use VPC peering between application tiers and other required VPCs. Enable Identity-Aware Proxy (IAP) for remote access to management resources, limiting access to authorized vendors.

**D.** Create a single VPC network and create different subnets for each tier. Create a new Google project specifically for the third-party vendors. Grant the vendors ownership of that project and the ability to modify the Shared VPC configuration.

**Respuesta de la fuente:** C

**Explicación:** Creating separate VPC networks for each tier establishes strong network isolation boundaries, preventing lateral movement if one tier is compromised. Identity-Aware Proxy (IAP) enables secure, identity-based remote access for vendors without exposing SSH/RDP ports directly to the internet, adhering to the zero-trust model. This approach avoids granting broad IAM roles or managing static SSH keys, thereby enforcing the principle of least privilege.

## Pregunta 301

Contexto: [topics:197](#topics-197)
Your organization is implementing separation of duties in a Google Cloud project. A group of developers must deploy new code, but cannot have permission to change network firewall rules. What should you do?

**A.** Assign the network administrator IAM role to all developers. Tell developers not to change firewall settings.

**B.** Use Access Context Manager to create conditions that allow only authorized administrators to change firewall rules based on attributes such as IP address or device security posture.

**C.** Create and assign two custom IAM roles. Assign the deployer role to control Compute Engine and deployment-related permissions. Assign the network administrator role to manage firewall permissions.

**D.** Grant the editor IAM role to the developer group. Explicitly negate any firewall modification permissions by using IAM deny policies.

**Respuesta de la fuente:** C

**Explicación:** The correct approach to separation of duties is to assign distinct IAM roles that grant only necessary permissions for specific tasks. By creating custom roles (or assigning predefined ones) where developers receive deployment permissions but lack network management rights, you enforce the principle of least privilege without relying on administrative overrides like Deny policies, which are not standard practice for basic role scoping.

## Pregunta 302

Contexto: [topics:197](#topics-197)
You manage a Google Cloud organization with many projects located in various regions around the world. The projects are protected by the same Access Context Manager access policy. You created a new folder that will host two projects that process protected health information (PHI) for US-based customers. The two projects will be separately managed and require stricter protections. You are setting up the VPC Service Controls configuration for the new folder. You must ensure that only US-based personnel can access these projects and restrict Google Cloud API access to only BigQuery and Cloud Storage within these projects. What should you do?

**A.** • Create a scoped access policy, add the new folder under “Select resources to include in the policy,” and assign an administrator under “Manage principals.”
• For the service perimeter, specify the two new projects as “Resources to protect” in the service perimeter configuration.
• Set “Restricted services” to “all services,” set “VPC accessible services” to “Selected services,” and specify only BigQuery and Cloud Storage under “Selected services.”

**B.** • Enable Identity Aware Proxy in the new projects.
• Create an Access Context Manager access level with an “IP Subnetworks” attribute condition set to the US-based corporate IP range.
• Enable the “Restrict Resource Service Usage” organization policy at the new folder level with an “Allow” policy type and set both “storage.googleapis.com” and “bigquery.googleapis.com” under “Custom values.”

**C.** • Edit the organization-level access policy and add the new folder under “Select resources to include in the policy.”
• Specify the two new projects as “Resources to protect” in the service perimeter configuration.
• Set “Restricted services” to “all services,” set “VPC accessible services” to “Selected services,” and specify only BigQuery and Cloud Storage.
• Edit the existing access level to add a “Geographic locations” condition set to “US.”

**D.** • Configure a Cloud Interconnect connection or a Virtual Private Network (VPN) between the on-premises environment and the Google Cloud organization.
• Configure the VPC firewall policies within the new projects to only allow connections from the on-premises IP address range.
• Enable the Restrict Resource Service Usage organization policy on the new folder with an “Allow” policy type, and set both “storage.googleapis.com” and “bigquery.googleapis.com” under “Custom values.”

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it correctly configures VPC Service Controls to restrict API access to only BigQuery and Cloud Storage within a service perimeter, and uses an Access Context Manager condition (Geographic Location) to enforce the US-only personnel requirement.
Although editing the organization-level policy risks applying changes globally, the question specifies setting up the configuration for the new folder under the existing policy; Option C explicitly scopes the 'Resources to protect' to the two new projects, ensuring the perimeter restrictions only apply to them.
The tempting alternative (A) is incorrect because it fails to implement the required geographic restriction ('only US-based personnel'), which is a core requirement of the scenario.

## Pregunta 303

Contexto: [topics:197](#topics-197)
There is a threat actor that is targeting organizations like yours. Attacks are always initiated from a known IP address range. You want to deny-list those IPs for your website, which is exposed to the internet through an Application Load Balancer. What should you do?

**A.** Create a Cloud Armor policy with a deny-rule for the known IP address range. Attach the policy to the backend of the Application Load Balancer.

**B.** Activate Identity-Aware Proxy for the backend of the Application Load Balancer. Create a firewall rule that only allows traffic from the proxy to the application.

**C.** Create a log sink with a filter containing the known IP address range. Trigger an alert that detects when the Application Load Balancer is accessed from those IPs.

**D.** Create a Cloud Firewall policy with a deny-rule for the known IP address range. Associate the firewall policy to the Virtual Private Cloud with the application backend.

**Respuesta de la fuente:** A

**Explicación:** Cloud Armor is the appropriate Google Cloud service for implementing Web Application Firewall (WAF) rules, including IP deny-listing, at the edge.
Attaching a Cloud Armor security policy with a deny rule to the Application Load Balancer ensures traffic from the specified IP range is blocked before reaching backend instances.
Option D is incorrect because Cloud Firewall operates on VPC compute resources, not directly on external load balancers.

## Pregunta 304

Contexto: [topics:197](#topics-197)
You are managing a Google Cloud environment that is organized into folders that represent different teams. These teams need the flexibility to modify organization policies relevant to their work. You want to grant the teams the necessary permissions while upholding Google-recommended security practices and minimizing administrative complexity. What should you do?

**A.** Create a custom IAM role with the organization policy administrator permission and grant the permission to each team’s folder. Limit policy modifications based on folder names within the custom role’s definition.

**B.** Assign the organization policy administrator role to a central service account and provide teams with the credentials to use the service account when needed.

**C.** Create an organization-level tag. Attach the tag to relevant folders. Use an IAM condition to restrict the organization policy administrator role to resources with that tag.

**D.** Grant each team the organization policy administrator role at the organization level.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it uses Resource Manager tags and IAM conditions to enforce the principle of least privilege without granting broad organization-level access.
By restricting the Organization Policy Administrator role to resources with a specific tag, you ensure that teams can only modify policies within their designated folders while preventing unauthorized changes elsewhere.
This approach minimizes administrative complexity by centralizing the permission logic rather than managing numerous individual bindings or sharing service account credentials.

## Pregunta 305

Contexto: [topics:197](#topics-197)
Your organization is using Vertex AI Workbench Instances. You must ensure that newly deployed Instances are automatically kept up-to-date and that users cannot accidentally alter settings in the operating system. What should you do?

**A.** Enforce the disableRootAccesa and requireAutoUpgradeSchedule organization policies for newly deployed Instances.

**B.** Enable the VM Manager and ensure the corresponding Google Compute Engine instances are added.

**C.** Implement a firewall rule that prevents Secure Shell access to the corresponding Google Compute Engine instances by using tags.

**D.** Assign the AI Notebooks Runner and AI Notebooks Viewer roles to the users of the AI Workbench Instances.

**Respuesta de la fuente:** A

**Explicación:** The `disableRootAccess` organization policy prevents users from accessing the root account, thereby restricting their ability to alter operating system settings.
The `requireAutoUpgradeSchedule` organization policy ensures that instances are automatically kept up-to-date with necessary patches and updates.
Together, these policies directly address both requirements specified in the scenario.

## Pregunta 306

Contexto: [topics:197](#topics-197)
You must ensure that the keys used for at-rest encryption of your data are compliant with your organization's security controls. One security control mandates that keys get rotated every 90 days. You must implement an effective detection strategy to validate if keys are rotated as required. What should you do?

**A.** Analyze the crypto key versions of the keys by using data from Cloud Asset Inventory. If an active key is older than 90 days, send an alert message through your incident notification channel.

**B.** Assess the keys in the Cloud Key Management Service by implementing code in Cloud Run. If a key is not rotated after 90 days, raise a finding in Security Command Center.

**C.** Define a metric that checks for timely key updates by using Cloud Logging. If a key is not rotated after 90 days, send an alert message through your incident notification channel.

**D.** Identify keys that have not been rotated by using Security Health Analytics. If a key is not rotated after 90 days, a finding in Security Command Center is raised.

**Respuesta de la fuente:** D

**Explicación:** Security Health Analytics is the native Google Cloud service designed to automatically detect common security misconfigurations without requiring custom code or manual analysis.
It includes a specific detector for Cloud KMS key rotation compliance, which automatically generates findings in Security Command Center when keys exceed the recommended rotation period.

## Pregunta 307

Contexto: [topics:197](#topics-197)
Your organization is developing a sophisticated machine learning (ML) model to predict customer behavior for targeted marketing campaigns. The BigQuery dataset used for training includes sensitive personal information. You must design the security controls around the AI/ML pipeline. Data privacy must be maintained throughout the model’s lifecycle and you must ensure that personal data is not used in the training process. Additionally, you must restrict access to the dataset to an authorized subset of people only. What should you do?

**A.** De-identify sensitive data before model training by using Cloud Data Loss Prevention (DLP)APIs. and implement strict Identity and Access Management (IAM) policies to control access to BigQuery.

**B.** Implement Identity-Aware Proxy to enforce context-aware access to BigQuery and models based on user identity and device.

**C.** Implement at-rest encryption by using customer-managed encryption keys (CMEK) for the pipeline. Implement strict Identity and Access Management (IAM) policies to control access to BigQuery.

**D.** Deploy the model on Confidential VMs for enhanced protection of data and code while in use. Implement strict Identity and Access Management (IAM) policies to control access to BigQuery.

**Respuesta de la fuente:** A

**Explicación:** The requirement to ensure personal data is not used in training mandates de-identification, which Cloud DLP provides by detecting and masking sensitive PII. Additionally, the need to restrict dataset access to an authorized subset requires granular Identity and Access Management (IAM) controls on BigQuery.
Option A is the only choice that directly addresses both data privacy during processing via de-identification and access control via IAM.

## Pregunta 308

Contexto: [topics:197](#topics-197)
Your organization wants to publish yearly reports of your website usage analytics. You must ensure that no data with personally identifiable information (PII) is published by using the Cloud Data Loss Prevention (Cloud DLP) API. Data integrity must be preserved. What should you do?

**A.** Detect all PII in storage by using the Cloud DLP API. Create a cloud function to delete the PII.

**B.** Discover and quarantine your PII data in your storage by using the Cloud DLP API.

**C.** Discover and transform PII data in your reports by using the Cloud DLP API.

**D.** Encrypt the PII from the report by using the Cloud DLP API.

**Respuesta de la fuente:** C

**Explicación:** The Cloud DLP API's inspection and transformation capabilities allow you to identify PII and then apply operations like redaction, tokenization, or generalization. This approach effectively removes personally identifiable information while preserving the overall structure and statistical properties of the dataset, thus maintaining data integrity for analytics. Deleting PII (Option A) or encrypting it without a key management strategy (Option D) would either destroy useful context or render the data unusable for standard reporting without additional complex infrastructure.

## Pregunta 309

Contexto: [topics:197](#topics-197)
Your development team is launching a new application. The new application has a microservices architecture on Compute Engine instances and serverless components, including Cloud Functions. This application will process financial transactions that require temporary, highly sensitive data in memory. You need to secure data in use during computations with a focus on minimizing the risk of unauthorized access to memory for this financial application. What should you do?

**A.** Enable Confidential VM instances for Compute Engine, and ensure that relevant Cloud Functions can leverage hardware-based memory isolation.

**B.** Use data masking and tokenization techniques on sensitive financial data fields throughout the application and the application's data processing workflows.

**C.** Use the Cloud Data Loss Prevention (Cloud DLP) API to scan and mask sensitive data before feeding the data into any compute environment.

**D.** Store all sensitive data during processing in Cloud Storage by using customer-managed encryption keys (CMEK), and set strict bucket-level permissions.

**Respuesta de la fuente:** A

**Explicación:** The question specifically requires securing data 'in use' (data in memory) during computations. Confidential VMs provide hardware-based isolation that encrypts RAM, protecting sensitive financial data from unauthorized access even if the host or hypervisor is compromised. Options B, C, and D address data at rest or in transit/masking but do not protect the actual memory contents while the code is executing.

## Pregunta 310

Contexto: [topics:197](#topics-197)
You work for a financial organization in a highly regulated industry that is subject to active regulatory compliance. To meet compliance requirements, you need to continuously maintain a specific set of configurations, data residency, organizational policies, and personnel data access controls. What should you do?

**A.** Apply an organizational policy constraint at the organization level to limit the location of new resource creation.

**B.** Create an Assured Workloads folder for your required compliance program to apply defined controls and requirements.

**C.** Go to the Compliance page in Security Command Center. View the report for your status against the required compliance standard. Triage violations to maintain compliance on a regular basis.

**D.** Create a posture.yaml file with the required security compliance posture. Apply the posture with the gcloud scc postures create
POSTURE_NAME --posture-from-file=posture.yaml command in Security Command Center Premium.

**Respuesta de la fuente:** B

**Explicación:** Assured Workloads is designed specifically for highly regulated industries to maintain compliance with strict data residency and organizational policy requirements.
It enforces a defined set of controls, including restricting resource creation locations and managing personnel access, ensuring continuous adherence to the required compliance program.

## Pregunta 311

Contexto: [topics:197](#topics-197)
Your organization is worried about recent news headlines regarding application vulnerabilities in production applications that have led to security breaches. You want to automatically scan your deployment pipeline for vulnerabilities and ensure only scanned and verified containers can run in the environment. What should you do?

**A.** Use Kubernetes role-based access control (RBAC) as the source of truth for cluster access by granting “container.clusters.get” to limited users. Restrict deployment access by allowing these users to generate a kubeconfig file containing the configuration access to the GKE cluster.

**B.** Use gcloud artifacts docker images describe LOCATION-docker.pkg.dev/PROJECT_ID/REPOSITORY/IMAGE_ID@sha256:HASH --show-package-vulnerability in your CI/CD pipeline, and trigger a pipeline failure for critical vulnerabilities.

**C.** Enforce the use of Cloud Code for development so users receive real-time security feedback on vulnerable libraries and dependencies before they check in their code.

**D.** Enable Binary Authorization and create attestations of scans.

**Respuesta de la fuente:** D

**Explicación:** Binary Authorization is the correct solution because it enforces admission control policies at the Kubernetes API server level, ensuring that only containers with specific attestations can be deployed.
By creating attestations for vulnerability scans within the CI/CD pipeline, you establish a verifiable trust boundary that blocks unverified or vulnerable images from running in the production environment.

## Pregunta 312

Contexto: [topics:197](#topics-197)
A team at your organization collects logs in an on-premises security information and event management system (SIEM). You must provide a subset of Google Cloud logs for the SIEM, and minimize the risk of data exposure in your cloud environment. What should you do?

**A.** Create a new BigQuery dataset. Stream all logs to this dataset. Provide the on-premises SIEM system access to the data in BigQuery by using workload identity federation and let the SIEM team filter for the relevant log data.

**B.** Define a log view for the relevant logs. Provide access to the log view to a principal from your on-premises identity provider by using workforce identity federation.

**C.** Create a log sink for the relevant logs. Send the logs to Pub/Sub. Retrieve the logs from Pub/Sub and push the logs to the SIEM by using Dataflow.

**D.** Filter for the relevant logs. Store the logs in a Cloud Storage bucket. Grant the service account access to the bucket. Provide the service account key to the SIEM team.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it creates a secure export pipeline that adheres to the principle of least privilege by sending only the filtered subset of logs via a Log Sink. Using Pub/Sub and Dataflow allows for real-time, reliable delivery to the on-premises SIEM without exposing Google Cloud credentials or granting direct network access to internal cloud resources. Options A and D violate security best practices by streaming all data or sharing long-lived service account keys, while Option B does not facilitate effective external log export.

## Pregunta 313

Contexto: [topics:197](#topics-197)
Your Google Cloud organization is subdivided into three folders: production, development, and networking, Networking resources for the organization are centrally managed in the networking folder. You discovered that projects in the production folder are attaching to Shared VPCs that are outside of the networking folder which could become a data exfiltration risk. You must resolve the production folder issue without impacting the development folder. You need to use the most efficient and least disruptive approach. What should you do?

**A.** Enable the Restrict Shared VPC Host Projects organization policy on the production folder. Create a custom rule and configure the policy type to Allow. In the Custom value section, enter under:folders/networking.

**B.** Enable the Restrict Shared VPC Host Projects organization policy on the networking folder only. Create a new custom rule and configure the policy type to Allow. In the Custom value section, enter under:organizations/123456739123.

**C.** Enable the Restrict Shared VPC Host Projects organization policy at the project level for each of the production projects. Create a custom rule and configure the policy type to Allow. In the Custom value section, enter under:folders/networking.

**D.** Enable the Restrict Shared VPC Host Projects organization policy at the organization level. Create a custom rule and configure the policy type to Allow. In the Custom value section, enter under:folders/networking.

**Respuesta de la fuente:** A

**Explicación:** Applying the 'Restrict Shared VPC Host Projects' organization policy at the production folder level ensures the restriction applies to all projects within that specific folder while leaving the development and networking folders unaffected.
This approach is the most efficient because it targets the scope of the issue directly without requiring manual configuration for individual projects or risking unintended constraints on other organizational units.

## Pregunta 314

Contexto: [topics:197](#topics-197)
Your organization operates in a highly regulated environment and has a stringent set of compliance requirements for protecting customer data. You must encrypt data while in use to meet regulations. What should you do?

**A.** Enable the use of customer-supplied encryption keys (CSEK) keys in the Google Compute Engine VMs to give your organization maximum control over their VM disk encryption.

**B.** Establish a trusted execution environment with a Confidential VM.

**C.** Use a Shielded VM to ensure a secure boot with integrity monitoring for the application environment.

**D.** Use customer-managed encryption keys (CMEK) and Cloud KSM to enable your organization to control their keys for data encryption in Cloud SQL.

**Respuesta de la fuente:** B

**Explicación:** The question specifically requires encrypting data 'while in use' (in memory), which is distinct from data at rest or in transit.
Confidential VMs leverage Trusted Execution Environment (TEE) technology to encrypt RAM, ensuring that even cloud administrators cannot access the data while it is being processed.
Options A and D address encryption for data at rest on disks or databases, and Option C focuses on boot integrity rather than memory encryption.

## Pregunta 315

Contexto: [topics:197](#topics-197)
Your organization is building a real-time recommendation engine using ML models that process live user activity data stored in BigQuery and Cloud Storage. Each new model developed is saved to Artifact Registry. This new system deploys models to Google Kubernetes Engine, and uses Pub/Sub for message queues. Recent industry news have been reporting attacks exploiting ML model supply chains. You need to enhance the security in this serverless architecture, specifically against risks to the development and deployment pipeline. What should you do?

**A.** Enable container image vulnerability scanning during development and pre-deployment. Enforce Binary Authorization on images deployed from Artifact Registry to your continuous integration and continuous deployment (CVCD) pipeline.

**B.** Thoroughly sanitize all training data prior to model development to reduce risk of poisoning attacks. Use IAM for authorization, and apply role-based restrictions to code repositories and cloud services.

**C.** Limit external libraries and dependencies that are used for the ML models as much as possible. Continuously rotate encryption keys that are used to access the user data from BigQuery and Cloud Storage.

**D.** Develop strict firewall rules to limit external traffic to Cloud Run instances. Integrate intrusion detection systems (IDS) for real-time anomaly detection on Pub/Sub message flows.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it directly addresses the ML model supply chain risk mentioned in the scenario. Container image vulnerability scanning identifies known issues in artifacts, while Binary Authorization enforces that only verified and scanned images are deployed to GKE, securing the development and deployment pipeline.

## Pregunta 316

Contexto: [topics:197](#topics-197)
You want to set up a secure, internal network within Google Cloud for database servers. The servers must not have any direct communication with the public internet. What should you do?

**A.** Assign a private IP address to each database server. Use a NAT gateway to provide internet connectivity to the database servers.

**B.** Assign a static public IP address to each database server. Use firewall rules to restrict external access.

**C.** Create a VPC with a private subnet. Assign a private IP address to each database server.

**D.** Assign both a private IP address and a public IP address to each database server.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because placing database servers in a VPC with only private IP addresses ensures they have no public endpoint, strictly satisfying the requirement for zero direct communication with the public internet.

Options A, B, and D involve assigning or enabling public internet connectivity (either directly via public IPs or indirectly via NAT), which introduces unnecessary attack surfaces and violates the principle of least privilege for isolated database environments.

## Pregunta 317

Contexto: [topics:197](#topics-197)
You work for a large organization that recently implemented a 100GB Cloud Interconnect connection between your Google Cloud and your on-premises edge router. While routinely checking the connectivity, you noticed that the connection is operational but there is an error message that indicates MACsec is operationally down. You need to resolve this error. What should you do?

**A.** Ensure that the Cloud Interconnect connection supports MACsec.

**B.** Ensure that the on-premises router is not down.

**C.** Ensure that the active pre-shared key created for MACsec is not expired on both the on-premises and Google edge routers.

**D.** Ensure that the active pre-shared key matches on both the on-premises and Google edge routers.

**Respuesta de la fuente:** D

**Explicación:** MACsec requires symmetric pre-shared keys (PSKs) to be identical on both endpoints for the security association to establish. If the physical link is operational but MACsec reports as operationally down, a mismatch in the PSK configuration between the Google Cloud and on-premises routers is the primary cause preventing encryption negotiation.

## Pregunta 318

Contexto: [topics:197](#topics-197)
Your organization must store highly sensitive data within Google Cloud. You need to design a solution that provides the strongest level of security and control. What should you do?

**A.** Use Cloud Storage with customer-supplied encryption keys (CSEK), VPC Service Controls for network isolation, and Cloud DLP for data inspection.

**B.** Use Cloud Storage with customer-managed encryption keys (CMEK), Cloud DLP for data classification, and Secret Manager for storing API access tokens.

**C.** Use Cloud Storage with client-side encryption, Cloud KMS for key management, and Cloud HSM for cryptographic operations.

**D.** Use Cloud Storage with server-side encryption, BigQuery with column-level encryption, and IAM roles for access control.

**Respuesta de la fuente:** C

**Explicación:** Client-side encryption ensures data is encrypted before leaving the on-premises environment, preventing Google from ever handling the plaintext.
Combining this with Cloud HSM provides hardware-level protection for cryptographic keys, offering the highest available assurance against key compromise.
This architecture delivers maximum control and security by eliminating reliance on server-side key management.

## Pregunta 319

Contexto: [topics:197](#topics-197)
The InfoSec team has mandated that all new Cloud Run jobs and services in production must have Binary Authorization enabled. You need to enforce this requirement. What should you do?

**A.** Configure an organization policy to require Binary Authorization enforcement on images deployed to Cloud Run.

**B.** Configure a Security Health Analytics (SHA) custom rule that prevents the execution of Cloud Run jobs and services without Binary Authorization.

**C.** Ensure the Cloud Run admin role is not assigned to developers.

**D.** Configure a Binary Authorization custom policy that is not editable by developers and auto-attaches to all Cloud Run jobs and services.

**Respuesta de la fuente:** A

**Explicación:** Organization Policy Service allows you to enforce constraints at the organization or folder level that restrict resources from being deployed unless they meet specific criteria. By configuring an org policy to require Binary Authorization enforcement for Cloud Run, you ensure that no container image can be deployed to a production service or job without first passing through the Binary Authorization admission controller.

## Pregunta 320

Contexto: [topics:197](#topics-197)
You are developing an application that runs on a Compute Engine VM. The application needs to access data stored in Cloud Storage buckets in other Google Cloud projects. The required access to the buckets is variable. You need to provide access to these resources while following Google- recommended practices. What should you do?

**A.** Limit the VMs access to the Cloud Storage buckets by setting the relevant access scope of the VM.

**B.** Create IAM bindings for the VM’s service account and the required buckets that allow appropriate access to the data stored in the buckets.

**C.** Grant the VM's service account access to the required buckets by using domain-wide delegation.

**D.** Create a group and assign IAM bindings to the group for each bucket that the application needs to access. Assign the VM's service account to the group.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud best practices recommend using IAM to grant least-privilege access directly to the VM's service account rather than relying on deprecated Access Scopes (Option A).
Creating a group for a single VM's service account (Option D) adds unnecessary complexity, as groups are intended for managing multiple identities, not individual machine identities.
Directly binding IAM roles to the service account ensures precise, flexible, and secure cross-project access control.

## Pregunta 321

Contexto: [topics:197](#topics-197)
Your organization strives to be a market leader in software innovation. You provided a large number of Google Cloud environments so developers can test the integration of Gemini in Vertex AI into their existing applications or create new projects. Your organization has 200 developers and a five-person security team. You must prevent and detect proper security policies across the Google Cloud environments. What should you do? (Choose two.)

**A.** Apply organization policy constraints. Detect and monitor drifts by using Security Health Analytics.

**B.** Publish internal policies and clear guidelines to securely develop applications.

**C.** Use Cloud Logging to create log filters to detect misconfigurations. Trigger Cloud Run functions to remediate misconfigurations.

**D.** Apply a predefined AI-recommended security posture template for Gemini in Vertex AI in Security Command Center Enterprise or Premium tiers.

**E.** Implement the least privileged access Identity and Access Management roles to prevent misconfigurations.

**Respuesta de la fuente:** A, D

**Explicación:** The correct answers are A and D. Organization policy constraints act as preventative controls to enforce security standards at scale, while Security Health Analytics provides continuous detection of misconfigurations, directly addressing the 'prevent and detect' requirement for a small security team managing many environments. Additionally, using a predefined secure AI template in Security Command Center (Option D) leverages specific, managed guardrails for Vertex AI workloads, ensuring proper security posture without manual configuration overhead.

## Pregunta 322

Contexto: [topics:197](#topics-197)
You are responsible for managing identities in your company’s Google Cloud organization. Employees are frequently using your organization's corporate domain name to create unmanaged Google accounts. You want to implement a practical and efficient solution to prevent employees from completing this action in the future. What should you do?

**A.** Create a Google Cloud identity for all users in your organization. Ensure that new users are added automatically.

**B.** Implement an automated process that scans all identities in your organization and disables any unmanaged accounts.

**C.** Register a new domain for your Google Cloud resources. Move all existing identities and resources to this domain.

**D.** Switch your corporate email system to another domain to avoid using the same domain for Google Cloud identities and corporate emails.

**Respuesta de la fuente:** A

**Explicación:** The most effective way to prevent employees from creating unmanaged Google accounts with a corporate domain is to establish centralized management of that domain via Google Cloud Identity or Workspace. Once the organization claims the domain and manages identities centrally, it restricts the ability of individual users to register new, unmanaged personal accounts using that same domain. This proactive approach ensures all identities are governed by organizational policies rather than relying on reactive scanning or domain changes.

## Pregunta 323

Contexto: [topics:197](#topics-197)
Your organization leverages folders to represent different teams within your Google Cloud environment. To support Infrastructure as Code (IaC) practices, each team receives a dedicated service account upon onboarding. You want to ensure that teams have comprehensive permissions to manage resources within their assigned folders while adhering to the principle of least privilege. You must design the permissions for these team-based service accounts in the most effective way possible. What should you do?

**A.** Grant each service account the folder administrator role on its respective folder.

**B.** Grant each service account the project creator role at the organization level and use folder-level IAM conditions to restrict project creation to specific folders.

**C.** Assign each service account the project editor role at the organization level and instruct teams to use IAM bindings at the folder level for fine-grained permissions.

**D.** Assign each service account the folder IAM administrator role on its respective folder to allow teams to create and manage additional custom roles if needed.

**Respuesta de la fuente:** A

**Explicación:** The Folder Administrator role is the most effective choice because it grants comprehensive permissions to manage all resources within the assigned folder while strictly confining access to that specific scope. This approach satisfies Infrastructure as Code requirements for broad resource management without violating the principle of least privilege, unlike organization-wide roles which are overly permissive.

## Pregunta 324

Contexto: [topics:197](#topics-197)
Your organization has a workload that is regulated by European laws. You must restrict the creation of resources outside of the EU for this specific workload. You must find an effective way to implement this security control without disrupting the other global applications. What should you do?

**A.** Create a Cloud Function triggered at asset creation that detects and deletes resources outside of the EU.

**B.** Create all your workload’s assets in a regional subnet in the EU in one project or folder.

**C.** Segment your workload in the EU in one project or folder by using VPC Service Controls.

**D.** Implement an organization policy that only allows the EU as the location for your workload’s project or folder.

**Respuesta de la fuente:** D

**Explicación:** Organization Policies in Google Cloud allow administrators to enforce constraints on resources, including restricting allowed locations.
By applying an organization policy constraint to the specific project or folder, you can prevent resource creation outside the EU without affecting other global workloads.
This is a declarative, enforcement-based control that is more effective and less error-prone than reactive mechanisms like Cloud Functions.

## Pregunta 325

Contexto: [topics:197](#topics-197)
Your organization manages a critical web application that serves international customers on Google Cloud. An increase in malicious traffic targeting this application has strained resources and caused periods of downtime. You need to design security measures to increase the application's resilience against web attacks, enhance perimeter protection, and provide access control. What should you do?

**A.** Employ network load balancing for traffic distribution. Update Identity-Aware Proxy (IAP) policies to allow only administrative access. Implement custom firewall rules on all external IP addresses.

**B.** Set up firewall rules on Compute Engine instances within the application's environment. Rely on load balancers for threat detection. Increase instance resources to cope with attack volume.

**C.** Configure firewall rules to block traffic from known malicious IP ranges. Set up Google Cloud Armor and implement Identity-Aware Proxy (IAP) for granular access control.

**D.** Add firewall rules that restrict all internal IP ranges. Establish Cloud DNS security policies. Disable external IP addresses to reduce the attack surface. Create user groups for access control.

**Respuesta de la fuente:** C

**Explicación:** Google Cloud Armor acts as a Web Application Firewall (WAF) and DDoS protection service at the load balancer level, effectively mitigating malicious traffic before it reaches your instances.
Identity-Aware Proxy (IAP) enforces granular, identity-based access control, ensuring only authorized users can reach the application regardless of their network location.
This combination addresses both perimeter protection against attacks and secure access requirements specified in the scenario.

## Pregunta 326

Contexto: [topics:197](#topics-197)
Your organization deploys a large number of containerized applications on Google Kubernetes Engine (GKE). Node updates are currently applied manually. Audit findings show that a critical patch has not been installed due to a missed notification. You need to design a more reliable, cloud-first, and scalable process for node updates. What should you do?

**A.** Configure node auto-upgrades for node pools in the maintenance windows.

**B.** Develop a custom script to continuously check for patch availability, download patches, and apply the patches across all components of the cluster.

**C.** Migrate the cluster infrastructure to a self-managed Kubernetes environment for greater control over the patching process.

**D.** Schedule a daily reboot for all nodes to automatically upgrade.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it leverages GKE's native node auto-upgrade feature, which aligns with the 'cloud-first' and 'scalable' requirements by automating the process without custom development.
Configuring maintenance windows ensures that these automatic updates occur during acceptable downtime periods, directly addressing the reliability issue caused by missed manual notifications.

## Pregunta 327

Contexto: [topics:197](#topics-197)
Your organization is migrating its primary web application from on-premises to Google Kubernetes Engine (GKE). You must advise the development team on how to grant their applications access to Google Cloud services from within GKE according to security recommended practices. What should you advise the development team to do?

**A.** Configure the GKE nodes to use the default Compute Engine service account.

**B.** Enable Workload Identity for GKE. Assign a Kubernetes service account to the application and configure that Kubernetes service account to act as an Identity and Access Management (IAM) service account. Grant the required roles to the IAM service account.

**C.** Create a user-managed service account with only the roles required for the specific workload. Assign this service account to the GKE nodes.

**D.** Create an application-specific IAM service account and generate a user-managed service account key for it. Inject the key to the workload by storing it as a Kubernetes secret within the same namespace as the application.

**Respuesta de la fuente:** B

**Explicación:** Workload Identity is the recommended security best practice for GKE because it eliminates the need to manage static service account keys, which are a significant security risk if leaked.
It enables granular, pod-level access control by mapping Kubernetes Service Accounts to IAM roles, adhering to the principle of least privilege rather than granting broad node-level permissions.

## Pregunta 328

Contexto: [topics:197](#topics-197)
Your organization’s application is being integrated with a partner application that requires read access to customer data to process customer orders. The customer data is stored in one of your Cloud Storage buckets. You have evaluated different options and determined that this activity requires the use of service account keys. You must advise the partner on how to minimize the risk of a compromised service account key causing a loss of data. What should you advise the partner to do?

**A.** Scan the Cloud Storage bucket with Sensitive Data Protection when new data is added, and automatically mask all customer data.

**B.** Define a VPC Service Controls perimeter, and restrict the Cloud Storage API. Add an ingress rule to the perimeter to allow access to the Cloud Storage API for the service account from outside of the perimeter.

**C.** Ensure that all data for the application that is accessed through the relevant service accounts is encrypted at rest by using customer-managed encryption keys (CMEK).

**D.** Implement a secret management service. Configure the service to frequently rotate the service account key. Configure proper access control to the key, and restrict who can create service account keys.

**Respuesta de la fuente:** D

**Explicación:** Option D is the most effective mitigation because frequent rotation of service account keys limits the window of opportunity for an attacker to exploit a compromised key. While encryption (C) and perimeter controls (B) provide defense-in-depth, they do not address the immediate risk posed by a leaked credential as directly as limiting its validity period. Secret management services automate this rotation, reducing operational overhead and human error.

## Pregunta 329

Contexto: [topics:197](#topics-197)
Your organization is implementing a new Python application that will be deployed on Cloud Run. The application needs to connect to a MySQL database that runs on Cloud SQL in a different project in your Google Cloud organization. You must secure the connection from the application to the Cloud SQL instance while minimizing management overhead. What should you do?

**A.** Use a public IP address for the Cloud SQL instance. Integrate the Cloud SQL Python Connector into your application code to connect to the Cloud SQL instance.

**B.** Ensure that the Cloud SQL instance doesn’t have a public IP address. Configure Cloud Run to use Cloud SQL Auth Proxy to connect to the Cloud SQL instance.

**C.** Ensure that the Cloud SQL instance doesn't have a public IP address. Enforce SSL/TLS. Require the use of a trusted client certificate to connect to the Cloud SQL instance.

**D.** Ensure that the Cloud SQL instance doesn’t have a public IP address. Configure the application's IP address as an authorized network to connect to the Cloud SQL instance.

**Respuesta de la fuente:** B

**Explicación:** The correct answer is B because it combines the security benefit of a private IP address (no public exposure) with the low-management-overhead solution of using the Cloud SQL Auth Proxy. While Google recommends language-specific connectors for simplified code, these connectors still require careful handling of credentials and do not inherently enforce private-only connectivity without additional VPC configuration; the Cloud SQL Auth Proxy is the robust, standard method to secure connections from Cloud Run to a private Cloud SQL instance while minimizing operational overhead for managing certificates or authorized networks. Options A exposes the database to the internet, C involves high management overhead with manual certificate handling, and D requires complex IP whitelisting which conflicts with Cloud Run's dynamic IPs unless VPC Access is configured (which adds complexity not mentioned in D).

## Pregunta 330

Contexto: [topics:197](#topics-197)
Your organization has Google Cloud applications that require access to external web services. You must monitor, control, and log access to these services. What should you do?

**A.** Set up a Secure Web Proxy that allows access to the specific external web services. Configure applications to use the proxy for the web service requests.

**B.** Set up a Cloud NAT instance to allow egress traffic from your VPC.

**C.** Configure VPC firewall rules to allow the services to access the IP addresses of required external web services.

**D.** Configure Google Cloud Armor to monitor and protect your applications by checking incoming traffic patterns for attack patterns.

**Respuesta de la fuente:** A

**Explicación:** Secure Web Proxy is the correct solution because it specifically enables monitoring, controlling (via allow/deny lists), and logging of outbound web traffic to external services.
Cloud NAT only facilitates egress without granular control or logging, while VPC firewall rules lack deep web inspection capabilities. Google Cloud Armor focuses on protecting against inbound attacks rather than managing outbound application traffic.

## Pregunta 331

Contexto: [topics:197](#topics-197)
Your organization uses a microservices architecture based on Google Kubernetes Engine (GKE). Recent security reviews recommend tighter controls around deployed container images to reduce potential vulnerabilities and maintain compliance. You need to implement an automated system by using managed services to ensure that only approved container images are deployed to the GKE clusters. What should you do?

**A.** Develop custom organization policies that restrict GKE cluster deployments to container images hosted within a specific Artifact Registry project where your approved images reside.

**B.** Enforce Binary Authorization in your GKE clusters. Integrate container image vulnerability scanning into the CI/CD pipeline and require vulnerability scan results to be used for Binary Authorization policy decisions.

**C.** Automatically deploy new container images upon successful CI/CD builds by using Cloud Build triggers. Set up firewall rules to limit and control access to instances to mitigate malware injection.

**D.** Build a system using third-party vulnerability databases and custom scripts to identify potential Common Vulnerabilities and Exposures (CVEs) in your container images. Prevent image deployment if the CVE impact score is beyond a specified threshold.

**Respuesta de la fuente:** B

**Explicación:** Binary Authorization is the Google Cloud managed service designed specifically to enforce admission control on Kubernetes deployments based on container image provenance and vulnerability status. By integrating vulnerability scanning results into Binary Authorization policies, you ensure that only images meeting compliance standards are admitted to GKE clusters, directly addressing the requirement for automated security controls.

## Pregunta 332

Contexto: [topics:197](#topics-197)
Your organization has recently migrated sensitive customer data to Cloud Storage buckets. For compliance reasons, you must ensure that all vendor data access and administrative access by Google personnel is logged. What should you do?

**A.** Configure Data Access audit logs for Cloud Storage on the project hosting the Cloud Storage buckets.

**B.** Enable Access Transparency for the organization.

**C.** Configure Data Access audit logs for Cloud Storage at the organization level.

**D.** Enable Access Transparency for the project hosting the Cloud Storage buckets.

**Respuesta de la fuente:** B

**Explicación:** The question specifically requires logging administrative access by Google personnel, which is the distinct function of Access Transparency, whereas Data Access audit logs primarily track customer-initiated API calls. To ensure consistent compliance across all sensitive data storage regardless of project structure, enabling this feature at the organization level is the recommended best practice.

## Pregunta 333

Contexto: [topics:197](#topics-197)
Your organization is implementing a Zero Trust security model and using Chrome Enterprise Premium. The company is interested in governing access to sensitive data stored in Cloud Storage. You need to configure access controls that ensure only authorized users on managed devices can access this data, regardless of their network location. Access should be restricted based on the device's security posture. This requires up-to-date operating system patches and antivirus software. What should you do?

**A.** Grant access to specific users to the VPC Service Controls to create a perimeter to access the Cloud Storage buckets. Configure Identity-Aware Proxy (IAP) to authenticate users before they can access the data.

**B.** Configure IAM conditions based on IP address ranges. Require users to connect through a VPN. Implement endpoint verification software on user devices to check for basic compliance.

**C.** Create an access level in Access Context Manager that requires a device policy. Create a Context-Aware Access policy using this access level. Apply the policy to the VPC Service Controls perimeter that includes the Cloud Storage buckets.

**D.** Use Cloud Firewall rules to restrict access to the Cloud Storage buckets based on the source IP addresses. Require users to authenticate with a multi-factor authentication method.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it utilizes Access Context Manager to define device-level constraints (such as OS patching and antivirus status) via a device policy, which satisfies the Zero Trust requirement for verifying endpoint posture. By applying this access level to VPC Service Controls, you enforce these checks at the API level, ensuring that only requests from compliant, managed devices can access the protected Cloud Storage buckets regardless of network location.

## Pregunta 334

Contexto: [topics:197](#topics-197)
Your organization is using AI to improve products through innovation. The developers want to use Gemini in Vertex AI on a project. You need to provide a secure Google Cloud environment to prevent and detect information leakages. What should you do?

**A.** Set up VPC Service Controls perimeters around the Vertex AI project. Enable Data Loss Prevention API for content inspection.

**B.** Grant the developers and AI engineers the Vertex AI User role. Monitor the audit trails with Cloud Logging.

**C.** Deploy Model Armor to protect the Vertex AI endpoint. Review Security Command Center findings to detect information leakages.

**D.** Implement a firewall rule that allows all traffic to and from the Vertex AI API endpoint.

**Respuesta de la fuente:** C

**Explicación:** Model Armor provides real-time protection against prompt injection and sensitive data leakage at the Vertex AI endpoint, directly addressing the prevention requirement for Gen AI usage. Security Command Center aggregates security signals to detect potential information leakages across the environment. VPC Service Controls (Option A) restrict data movement between resources but cannot inspect the semantic content of AI prompts or responses to prevent inadvertent data exposure within the allowed traffic.

## Pregunta 335

Contexto: [topics:197](#topics-197)
You are responsible for configuring Identity and Access Management in your organization's Google Cloud environment. You need to restrict your organization's users from accessing Cloud Storage buckets in other Google Cloud organizations. What should you do?

**A.** Set a principal access boundary policy with the appropriate enforcement version. Bind the policy to the principals of your organization.

**B.** Configure organization restriction headers for your environment. Only include the organization ID of your organization in the list of allowed resources.

**C.** Create an IAM deny policy on the organization level that prevents access to Cloud Storage buckets outside the organization.

**D.** Enforce domain restricted sharing in your organization. Configure a managed constraint, and only include the principals in your organization.

**Respuesta de la fuente:** A

**Explicación:** Principal Access Boundary (PAB) policies are the correct mechanism to restrict a principal's access to resources within or outside your organization.
By defining an access boundary that limits resource access to specific organization IDs, you prevent users from accessing Cloud Storage buckets in other organizations, even if they have been granted IAM permissions there.

## Pregunta 336

Contexto: [topics:197](#topics-197)
Your organization is storing regulated data in Cloud Storage. Data in Cloud Storage buckets is encrypted by Google-managed encryption keys. To meet compliance requirements, you need to update the existing data to use customer-managed encryption keys instead. What should you do?

**A.** Create a new key ring and key in the Cloud Key Management Service. In each Cloud Storage bucket configuration, change the encryption type to customer-managed encryption key.

**B.** Identify which projects contain Cloud Storage buckets with regulated data. Apply the restrictNonCmekServices organization policy constraint to the identified projects or parent folder.

**C.** Create a new key ring and key in the Cloud Key Management Service. Identify which projects contain Cloud Storage buckets with regulated data. Perform a write action on all existing objects in the buckets.

**D.** Create a customer-managed encryption key. Change the encryption type in each Cloud Storage bucket configuration to the newly created key. Perform a write action on all existing objects in the buckets.

**Respuesta de la fuente:** D

**Explicación:** Changing the default KMS key in bucket configuration only affects newly uploaded objects; it does not automatically re-encrypt existing data.
To comply with the requirement for existing regulated data, you must perform a write operation (such as copying objects to themselves) to trigger re-encryption using the new customer-managed key.

## Pregunta 337

Contexto: [topics:197](#topics-197)
There is a vendor who needs access to your company's Google Cloud environment. The vendor uses a third-party identity provider (IdP). You need to integrate this IdP with your company's Google Cloud environment to enable single sign-on (SSO) for the vendor's users in the most secure way. You don't want to manage any of the vendor users' lifecycle management. What should you do?

**A.** Use Google Cloud Directory Sync to synchronize user accounts from the IdP to Google Workspace, and then configure SSO between Google Workspace and Google Cloud.

**B.** Develop a custom application that queries the IdP for user authentication and then programmatically creates Google Cloud user accounts.

**C.** Connect the vendor's IdP with Google Cloud using Workforce Identify Federation.

**D.** Create Google Cloud accounts for each user and synchronize their passwords with the third-party IdP.

**Respuesta de la fuente:** C

**Explicación:** Workforce Identity Federation is the recommended Google Cloud feature for granting external users, such as vendors, access via their home identity provider. It eliminates the need to provision or manage user accounts and passwords within Google Cloud, thereby satisfying the requirement for no lifecycle management while maintaining a secure, standards-based SSO integration.

## Pregunta 338

Contexto: [topics:197](#topics-197)
Your organization is planning to deploy a large number of Google Kubernetes Engine (GKE) clusters to run business applications in different folders and projects. You must ensure that all GKE nodes always run the latest release to minimize vulnerability risk and administrative effort. What should you do?

**A.** After creating clusters, use the Google Cloud console gcloud container node-pools describe NODE_POOL_NAME --cluster=CLUSTER_NAME command. Examine the upgradeSettings and UpdateInfo output.

**B.** Create a custom organization policy constraint resource.management.autoUpgrade == true with an action type of ALLOW at the organization level before deployment.

**C.** Create a new node pool with the newer version for each cluster. Migrate the workload. Eliminate the outdated node pool.

**D.** Manually run the Google Cloud console gcloud container clusters upgrade CLUSTER_NAME--node-pool=NODE_POOL_NAME --cluster-version VERSION command on newly created clusters regularly.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Organization Policies allow you to enforce consistent configurations at scale across multiple projects and folders. By setting the auto-upgrade constraint to 'ALLOW' (or requiring it), you ensure that all GKE node pools are configured for automatic upgrades by default, minimizing manual administrative effort and ensuring nodes run the latest secure versions without human intervention.

## Pregunta 339

Contexto: [topics:197](#topics-197)
Your company is migrating a three-tier web application to Google Cloud. The application consists of a web frontend, an application backend, and a database. Due to regulatory requirements and existing on-premises infrastructure dependencies, you need to implement a hybrid cloud architecture. The web frontend will be hosted on Google Cloud, while the application backend and the database will remain on-premises initially. You need to ensure secure and efficient communication between the cloud-based frontend and the on-premises backend and database, minimizing latency and maximizing availability. What should you do?

**A.** Establish a Dedicated Interconnect connection between the Google Cloud VPC network and the on-premises network. Configure firewall rules to allow communication between the three tiers.

**B.** Establish a direct internet connection between the Google Cloud VPC network hosting the web frontend and the on-premises network that hosts the backend and database. Configure firewall rules to allow communication between the three tiers.

**C.** Replicate the on-premises backend and database to Google Cloud. Use a hybrid connectivity network endpoint group for the primary. Backup to the zonal network endpoint group.

**D.** Use a highly-available Cloud VPN connection over the public internet to connect the Google Cloud VPC network to the on-premises network.

**Respuesta de la fuente:** A

**Explicación:** Dedicated Interconnect provides a private, high-bandwidth physical connection that bypasses the public internet, ensuring the lowest and most stable latency required by the scenario.
Unlike Cloud VPN, which routes traffic over the unpredictable public internet causing potential latency spikes, Dedicated Interconnect offers superior performance and security for hybrid connectivity.

## Pregunta 340

Contexto: [topics:197](#topics-197)
Your organization is building an application powered by generative AI that uses sensitive internal data lo train the AI model. The application is built using Vertex AI, which is generally available in your region. You must ensure Google does not use your sensitive data when tuning public models because it could result in your data being shared with other Google Cloud customers. What should you do?

**A.** Do not use Vertex AI for sensitive data. Use only public data with minimal privacy requirements.

**B.** Encrypt your data by using customer-managed encryption keys (CMEK) to have full control over encryption key access.

**C.** Do nothing. Vertex AI foundation models are frozen by default and do not use your data for model-tuning purposes.

**D.** Contact Google support to opt out of model tuning.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google Cloud's Enterprise Privacy Policy explicitly prohibits using customer data from Vertex AI to train or improve public foundation models.
Foundation models are "frozen" by default, meaning any fine-tuning with sensitive internal data creates a private model instance that remains exclusively accessible to your organization.
Therefore, no additional action is required to prevent Google from using your data for general model tuning, as this is the default behavior.

## Pregunta 341

Contexto: [topics:197](#topics-197)
Your organization is deploying a new web application on Compute Engine and needs robust perimeter security. You need to protect the application from common web attacks, including SQL injection and cross-site scripting (XSS), while also controlling network traffic based on the source IP address and user identity. What should you do?

**A.** Implement Cloud Load Balancing and Cloud DNS. Set up Cloud CDN to cache content and mitigate some DDoS attacks. Configure Cloud Armor to provide layer 7 protection.

**B.** Deploy Cloud Armor with its default WAF rules enabled. Configure network firewall rules on the Compute Engine instances to control all traffic based on source IP addresses. Use Cloud IAM to manage which users have roles granting access to the web application.

**C.** Use Google Cloud Armor with pre-configured WAF rules to filter malicious traffic. Implement VPC Service Controls to create a secure perimeter around the application's resources. Manage users with Cloud IAM.

**D.** Deploy Cloud Armor, and configure Cloud Firewall rules to control traffic based on source IP addresses. Integrate with Identity-Aware Proxy to control access based on user identity.

**Respuesta de la fuente:** D

**Explicación:** Cloud Armor provides the necessary Web Application Firewall (WAF) rules to mitigate SQL injection and cross-site scripting attacks.
VPC firewall rules are used to control network traffic based on source IP addresses at the perimeter level.
Identity-Aware Proxy (IAP) is the specific service designed to enforce access control based on user identity, satisfying the final requirement.

## Pregunta 342

Contexto: [topics:197](#topics-197)
Your company is in a regulated industry that requires low overhead encryption using private connectivity from on-premises data centers to Google Cloud. You need to establish connectivity and ensure high availability across multiple regions. What should you do?

**A.** Set up two pairs of HA VPNs using IPSec from the data centers in multiple regions.

**B.** Set up pairs of Cloud Interconnect connections to your data centers in multiple regions, and employ MACSec encryption.

**C.** Set up L2TP encryption over pairs of dedicated Cloud Interconnect connections from the data centers in multiple regions.

**D.** Set up IPSec encryption over Partner Interconnect connections from your data centers in multiple regions.

**Respuesta de la fuente:** B

**Explicación:** Cloud Interconnect provides the dedicated private connectivity required, while MACSec offers low-overhead, line-rate Layer 2 encryption superior to IPsec for this use case. Setting up pairs of connections across multiple regions ensures high availability and redundancy as specified in the requirements.

## Pregunta 343

Contexto: [topics:197](#topics-197)
You manage the security logs within your cloud environment. You have configured a continuous export of security logs to Cloud Storage buckets for long-term retention. You need to provide auditors the ability to analyze the logs that were exported to Cloud Storage. Your solution must be cost-effective and quickly implemented.

What should you do?

**A.** Use a VM instance to download the data from Cloud Storage. Provide the auditors access to the VM and allow them to install their preferred analytics toolset.

**B.** Use the data in the Cloud Storage bucket as an external table in BigQuery. Provide the auditors access to the BigQuery dataset.

**C.** Use Dataflow to import the data from Cloud Storage into Elasticsearch. Provide the auditors with access to Elasticsearch.

**D.** Use a Cloud Run job to import the log data from Cloud Storage to Cloud Logging. Provide the auditors access through Log Analytics.

**Respuesta de la fuente:** B

**Explicación:** Creating an external table in BigQuery allows auditors to query log files directly from Cloud Storage using SQL without copying or ingesting the data, satisfying the cost-effectiveness and speed requirements.
This serverless approach avoids the overhead of provisioning VMs, setting up Dataflow pipelines, or migrating data to Elasticsearch, which would be more complex and expensive.

## Pregunta 344

Contexto: [topics:197](#topics-197)
Your organization currently uses a third-party identity provider (IdP) that only requires a username and password for authentication. You need to enforce 2-step verification (2SV) for the Super admins in Cloud Identity. What should you do?

**A.** Create an organizational unit (OU) for Super admins, and enable 2SV within Cloud Identity for the OU.

**B.** Collaborate with the third-party IdP to enable 2SV for Super admins while maintaining the current Cloud Identity configuration.

**C.** Implement monitoring tools to track the authentication methods used by Super admins in Cloud Identity. Alert on those not using 2SV.

**D.** Evaluate the 2SV options for Super admins offered by both the third-party IdP and Cloud Identity. Implement the solution that provides the strongest second factor.

**Respuesta de la fuente:** A

**Explicación:** Cloud Identity allows administrators to enforce security policies, including 2-Step Verification (2SV), at the Organizational Unit (OU) level.
By creating a dedicated OU for Super admins and enabling 2SV within that specific OU, you can override any inherited settings from the third-party IdP or parent OUs.
This ensures that the high-privilege accounts are subject to stricter authentication requirements directly managed by Cloud Identity policies.

## Pregunta 345

Contexto: [topics:197](#topics-197)
Your organization has a hybrid cloud environment with a data center connected to Google Cloud through a dedicated Cloud Interconnect connection. You need to configure private access from your on-premises hosts to Google APIs, specifically Cloud Storage and BigQuery, without exposing traffic to the public internet. What should you do?

**A.** Configure Shared VPC to extend your Google Cloud VPC network to your on-premises environment. Use Private Google Access to access Google APIs.

**B.** Establish VPC peering between your on-premises network and your Google Cloud VPC network. Configure Cloud Firewall rules to allow traffic to Google API IP ranges.

**C.** Use Private Google Access for on-premises hosts. Configure DNS resolution to point to the private.googleapis.com domain.

**D.** Configure Cloud NAT on your on-premises network. Configure DNS records in a private DNS zone to send requests to 199.36.153.8/30 to access Google APIs.

**Respuesta de la fuente:** C

**Explicación:** Private Google Access allows resources in a VPC to access Google APIs privately over the internal network.
To extend this capability to on-premises hosts via Cloud Interconnect, you must configure DNS resolution to point requests to the private.googleapis.com domain.
This ensures traffic routes through the dedicated interconnect link rather than traversing the public internet.

## Pregunta 346

Contexto: [topics:197](#topics-197)
A batch job running on Compute Engine needs temporary write access to a Cloud Storage bucket. You want the batch job to use the minimum permissions necessary to complete the task. What should you do?

**A.** Create a service account with full Cloud Storage administrator permissions. Assign the service account to the Compute Engine instance.

**B.** Create a service account and embed a long-lived service account key file that has write permissions specified directly in the batch job script.

**C.** Create a service account with the storage.objectCreator role. Use service account impersonation in the batch job's code.

**D.** Grant the predefined storage.objectCreator role to the Compute Engine instance's default service account.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it adheres to the principle of least privilege by granting only the storage.objectCreator role, which provides the minimum necessary write access. Using service account impersonation within the code allows the batch job to assume these specific permissions securely without embedding long-lived keys or assigning overly broad roles like Administrator.

## Pregunta 347

Contexto: [topics:197](#topics-197)
Your company has recently enabled Security Command Center at the organization level. You need to implement runtime threat detection for applications running in containers within projects residing in the production folder. Specifically, you need to be notified if additional libraries are loaded or malicious scripts are executed within these running containers. You need to configure Security Command Center to meet this requirement while ensuring findings are visible within Security Command Center. What should you do?

**A.** Create log-based metrics and alerts in Cloud Logging and Cloud Monitoring for suspicious container activity within the production folder.

**B.** Configure Security Health Analytics within Security Command Center to monitor container runtime vulnerabilities in the production folder.

**C.** Ensure that the containers in the production folder are running on hosts that are using Container-Optimized OS.

**D.** Enable Container Threat Detection in Security Command Center Premium tier for the projects within the production folder.

**Respuesta de la fuente:** D

**Explicación:** Container Threat Detection is the specific Security Command Center Premium feature designed for runtime security of workloads in GKE and Cloud Run. It actively monitors container processes to detect anomalies such as unexpected library loading or malicious script execution, which standard logging or configuration analytics (like Security Health Analytics) do not cover in real-time.

## Pregunta 348

Contexto: [topics:197](#topics-197)
Your organization enforces a custom organization policy that disables the use of Compute Engine VM instances with external IP addresses. However, a regulated business unit requires an exception to temporarily use external IPs for a third-party audit process. The regulated business workload must comply with least privilege principles and minimize policy drift. You need to ensure secure policy management and proper handling. What should you do?

**A.** Create a folder. Apply the restrictive organization policy for non-regulated business workloads in the folder. Place the regulated business workload in that folder.

**B.** Apply the restrictive organization policy at the organization level. Create an IAM custom role with permissions to bypass organization policies. Assign the custom role to the regulated business team for the specific project.

**C.** Apply the custom organization policy at the organization level to restrict external IPs. Move the regulated business workload to a separate folder. Override the policy at that folder level.

**D.** Modify the custom organization policy at the organization level to allow external IPs for all projects. Configure VPC firewall rules to restrict egress traffic except for the regulated business workload.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 349

Contexto: [topics:197](#topics-197)
Your company wants to deploy 2-step verification (2SV). The organizational unit (OU) structure of your company is divided into four departmental units: Human Resources, Finance. Engineering, and Marketing You need to prevent many access issues from occurring at the same time. Your solution should minimize complexity in management and configuration. What should you do?

**A.** Create a single new OU to configure enforcement of 2SV to certain users but not others.

**B.** Create configuration groups, and enable a phased migration to control the number of individuals in which to enforce 2SV.

**C.** In the Admin console, for each OU, check the checkbox to Allow users to turn on 2-Step Verification and set Enforcement to Off.

**D.** In the Admin console, for each OU, uncheck the checkbox to Allow users to turn on 2-Step Verification and set Enforcement to On.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 350

Contexto: [topics:197](#topics-197)
Your company is deploying a large number of containerized applications to GKE. The existing CI/CD pipeline uses Cloud Build to construct container images, transfers the images to Artifact Registry, and then deploys the images to GKE. You need to ensure that only images that have passed vulnerability scanning and meet specific corporate policies are allowed to be deployed. The process needs to be automated and integrated into the existing CI/CD pipeline. What should you do?

**A.** Configure a policy in Binary Authorization to use Artifact Analysis vulnerability scanning to only allow images that pass the scan to deploy to your GKE clusters.

**B.** Enable Artifact Analysis vulnerability scanning and regularly scan images in Artifact Registry. Remove any images that do not meet the vulnerability requirements before deployment.

**C.** Implement a custom script in the Cloud Build pipeline that uses a third-party vulnerability scanning tool. Fail the build if vulnerabilities are found.

**D.** Configure GKE to use only images from a specific, trusted Artifact Registry repository. Manually inspect all images before pushing them to this repository.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 351

Contexto: [topics:197](#topics-197)
You are managing a set of Google Cloud projects that are contained in a folder named Data Warehouse. A new data analysis team has been approved to perform data analysis for all BigQuery data in the projects within the Data Warehouse folder. They should only be able to read the data and not have permissions to modify or delete the data. You want to reduce the operational overhead of provisioning access while adhering to the principle of least privilege. What should you do?

**A.** Grant the BigQuery Data Viewer role at the project level for each project within the Data Warehouse folder.

**B.** Grant the BigQuery Data Viewer role at the Data Warehouse folder.

**C.** Grant the BigQuery Data Viewer role at the dataset level for each BigQuery dataset within each project in the Data Warehouse folder.

**D.** Grant the BigQuery Metadata Viewer role at the Data Warehouse folder.

**Respuesta de la fuente:** B

**Explicación:** Granting the BigQuery Data Viewer role at the folder level ensures that all projects within the 'Data Warehouse' folder inherit the necessary read-only permissions for BigQuery resources. This approach minimizes operational overhead by applying a single IAM policy to multiple projects, rather than managing individual bindings per project or dataset.

References:
Google Cloud Identity and Access Management: Resource hierarchy (Folders)

## Pregunta 352

Contexto: [topics:197](#topics-197)
Your company hosts a critical web application on Google Cloud. The application is experiencing an increasing number of sophisticated layer 7 attacks, including cross-site scripting (XSS) and SQL injection attempts. You need to protect the application from these attacks while minimizing the impact on legitimate traffic and ensuring high availability. What should you do?

**A.** Implement a load balancer in front of the web application instances, and enable Adaptive Protection and throttling to mitigate the occurrence of these malicious requests.

**B.** Configure Cloud Next Generation Firewall to block known malicious IP addresses targeting /32 addresses.

**C.** Enable Google Cloud Armor’s pre-configured WAF rules for OWASP Top 10 vulnerabilities at the backend service.

**D.** Configure a Cloud Armor security policy with customized and pre-configured WAF rules for OWASP Top 10 vulnerabilities at the load balancer.

**Respuesta de la fuente:** D

**Explicación:** Cloud Armor is the recommended Google Cloud service for protecting against Layer 7 attacks like XSS and SQL injection by applying Web Application Firewall (WAF) rules.
Configuring security policies at the load balancer level ensures that malicious traffic is filtered before it reaches backend instances, which preserves backend resources and maintains high availability.

## Pregunta 353

Contexto: [topics:197](#topics-197)
Your financial services company needs to process customer personally identifiable information (PII) for analytics while adhering to strict privacy regulations. You must transform this data to protect individual privacy to ensure that the data retains its original format and consistency for analytical integrity. Your solution must avoid full irreversible deletion. What should you do?

**A.** Use Cloud Key Management Service (Cloud KMS) to encrypt the entire dataset with a customer-managed encryption key (CMEK).

**B.** Set up VPC Service Controls around the BigQuery project. Implement row-level encryption.

**C.** Implement a custom BigQuery user-defined function (UDF) by using JavaScript to hash all sensitive fields before they are loaded into the analytical tables.

**D.** Configure Sensitive Data Protection (SDP) to de-identify PII using format-preserving encryption (FPE).

**Respuesta de la fuente:** D

**Explicación:** Sensitive Data Protection (SDP) is designed specifically for de-identifying PII while maintaining data utility. Format-Preserving Encryption (FPE) ensures that transformed data retains the original format and consistency, which is required for analytical integrity without irreversible deletion.

## Pregunta 354

Contexto: [topics:197](#topics-197)
Your global defense company is migrating top-secret classified data to BigQuery and Cloud Storage. National security regulations demand that master encryption key material never leaves the accredited on-premises cryptographic hardware. You must retain the unilateral ability to revoke data access, independent of any cloud provider. What should you do?

**A.** Use customer-managed encryption keys (CMEKs) for the BigQuery datasets and Cloud Storage buckets. Store the keys in Cloud Key Management Service (Cloud KMS).

**B.** Use customer-supplied encryption keys (CSEKs) by providing your own encryption keys with each data operation in Cloud Storage and BigQuery.

**C.** Import existing on-premises master encryption keys into Cloud Key Management Service (Cloud KMS). Use the imported keys for BigQuery and Cloud Storage encryption.

**D.** Configure Cloud External Key Manager (Cloud EKM) for the BigQuery datasets and Cloud Storage buckets. Integrate EKM with your existing on-premises hardware security modules (HSMs).

**Respuesta de la fuente:** D

**Explicación:** Cloud External Key Manager (EKM) is the only option that ensures master key material never leaves the customer's on-premises HSMs, as it uses Cloud KMS to call out to external key stores rather than storing keys in Google infrastructure.
This architecture grants unilateral revocation capability because disconnecting or disabling access to the on-premises keys immediately renders the encrypted data in BigQuery and Cloud Storage inaccessible, independent of Google's permissions system.

## Pregunta 355

Contexto: [topics:197](#topics-197)
You work at a company in a regulated industry and are responsible for ongoing security of the Cloud environment. You need to prevent and detect misconfigurations in a particular folder based on specific compliance policies. You need to adhere to industry-specific compliance policies and policies that are internal to your company. What should you do?

**A.** Create a Posture file by using custom and predefined SHA or organization policies. Enforce the posture on the folder level.

**B.** Create custom organization policies that follow specific business requirements. Enforce the policies on the folder level.

**C.** Enable Assured Workloads on the folder level, with the specific control bundle appropriate for your industry’s regulations.

**D.** Use Workload Manager with custom Rego policies to continuously scan the environment for misconfigurations on the folder level.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Posture Management (formerly Security Health Analytics) is the specific service designed to provide a unified view of configuration posture and compliance against predefined frameworks (like CIS, NIST) and custom policies. It allows you to define expected configurations ('posture') and enforce or report on deviations at the folder level, directly addressing the need for both industry-specific and internal policy adherence.

While Organization Policies (Option B) restrict resource creation/changes, they do not provide comprehensive misconfiguration detection against complex compliance frameworks in the same way Posture Management does. Assured Workloads (Option C) is focused on isolating sensitive workloads rather than general folder-level configuration scanning.

## Pregunta 356

Contexto: [topics:197](#topics-197)
Your organization is using Google Workspace, Google Cloud, and a third-party SIEM. You need to export events such as user logins, successful logins, and failed logins to the SIEM. Logs need to be ingested in real time or near real-time. What should you do?

**A.** Poll Cloud Logging for authentication events using the gcloud logging read tool. Forward the events to the SIEM.

**B.** Configure Google Workspace to directly send logs to the API endpoint of the third-party SIEM.

**C.** Create a Cloud Storage bucket as a sink for all logs. Configure the SIEM to periodically scan the bucket for new log files.

**D.** Create a Cloud Logging sink to export relevant authentication logs to a Pub/Sub topic for SIEM subscription.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 357

Contexto: [topics:197](#topics-197)
Your company is developing a new application for your organization. The application consists of two Cloud Run services, service A and service B. Service A provides a web-based user frontend. Service B provides backend services that are called by service A. You need to set up Identity and Access Management for the application. Your solution should follow the principle of least privilege. What should you do?

**A.** Create two separate service accounts. Grant one service account the permissions to execute service A, and grant the other service account the permissions to execute service B. Require authentication for service B. Permit only the service account for service A to call the backend.

**B.** Create three separate service accounts. Grant one service account the permissions to execute service A. Grant the second service account the permissions to run service Grant the third service account the permissions to communicate between both services A and Require authentication for service Call the backend by authenticating with a service account key for the third service account.

**C.** Create a new service account with the permissions to run service A and service B. Require authentication for service B. Permit only the new service account to call the backend.

**D.** Use the Compute Engine default service account to run service A and service B. Require authentication for service B. Permit only the default service account to call the backend.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 358

Contexto: [topics:197](#topics-197)
Your organization has established a highly sensitive project within a VPC Service Controls perimeter. You need to ensure that only users meeting specific contextual requirements such as having a company-managed device, a specific location, and a valid user identity can access resources within this perimeter. You want to evaluate the impact of this change without blocking legitimate access. What should you do?

**A.** Establish a Context-Aware Access policy that specifies the required contextual attributes, and associate the policy with the VPC Service Controls perimeter in dry run mode.

**B.** Use the VPC Service Control Violation dashboard to identify the impact of details about access denials by service perimeters.

**C.** Configure a VPC Service Controls perimeter in dry run mode, and enforce strict network segmentation using firewall rules. Use multi-factor authentication (MFA) for user verification.

**D.** Use Cloud Audit Logs to monitor user access to the project resources. Use post-incident analysis to identify unauthorized access attempts.

**Respuesta de la fuente:** A

**Explicación:** Context-Aware Access policies allow you to enforce access requirements based on user identity, device management status, and geographic location.
Associating this policy with a VPC Service Controls perimeter in dry-run mode enables you to monitor which requests would be denied without actually blocking access, thereby safely evaluating the impact of the new restrictions.

## Pregunta 359

Contexto: [topics:197](#topics-197)
Your company’s storage team manages all product images within a specific Google Cloud project. To maintain control, you must isolate access to Cloud Storage for this project, allowing the storage team to manage restrictions at the project level. They must be restricted to using corporate computers. What should you do?

**A.** Use Identity and Access Management (IAM) roles at the project level within the storage team’s project. Grant the storage team granular permissions on the project’s Cloud Storage resources.

**B.** Employ organization-level firewall rules to block all traffic to Cloud Storage. Create exceptions for specific service accounts used by the storage team within their project.

**C.** Use Context-Aware Access Create an access level that defines the required context. Apply it as an organization policy specifically at the project level, restricting access to Cloud Storage based on that context.

**D.** Implement VPC Service Controls by establishing an organization-wide service perimeter with all projects. Configure ingress and egress rules to restrict access to Cloud Storage based on IP address ranges.

**Respuesta de la fuente:** C

**Explicación:** The requirement to restrict access based on device type (corporate computers) necessitates the use of Context-Aware Access, which evaluates signals like device trust rather than just static IAM permissions.
Option C correctly describes creating an access level defined by this context and applying it via organization policy at the project level, isolating Cloud Storage access as requested.

## Pregunta 360

Contexto: [topics:197](#topics-197)
Your organization uses Google Workspace as the primary identity provider for Google Cloud. Users in your organization initially created their passwords. You need to improve password security due to a recent security event. What should you do?

**A.** Conduct a security awareness training session, and set the password expiration settings to require more frequent updates.

**B.** Check the Enforce strong password box, and check Enforce password policy at the next sign-in.

**C.** Check the Enforce strong password box, and set the password expiration to occur more frequently.

**D.** Audit user activity for suspicious logins by using the audit and investigation tool.

**Respuesta de la fuente:** B

**Explicación:** To immediately improve password security after an incident in Google Workspace, you must enable strong password policies to enforce complexity requirements.
Checking 'Enforce password policy at the next sign-in' is critical because it forces existing users to change their current passwords to comply with the new standards immediately upon their next login, rather than waiting for a scheduled expiration.

## Pregunta 361

Contexto: [topics:197](#topics-197)
Your company has deployed an artificial intelligence model in a central project. This model has a lot of sensitive intellectual property and must be kept strictly isolated from the internet. You must expose the model endpoint only to a defined list of projects in your organization. What should you do?

**A.** Within the model project, create an internal Application Load Balancer that points to the model endpoint. Expose this load balancer with Private Service Connect to a configured list of projects.

**B.** Activate Private Google Access in both the model project and in each project that needs to connect to the model. Create a firewall policy to allow connectivity to Private Google Access addresses.

**C.** Create a central project to host Shared VPC networks that are provided to all other projects. Centrally administer all firewall rules in this project to grant access to the model.

**D.** Within the model project, create an external Application Load Balancer that points to the model endpoint. Create a Cloud Armor policy to restrict IP addresses to Google Cloud.

**Respuesta de la fuente:** A

**Explicación:** Private Service Connect allows you to expose a service hosted in one VPC network to selected consumer projects via an internal Application Load Balancer without exposing it to the public internet. This satisfies the strict isolation requirement by keeping traffic on Google's private backbone while enabling access control through defined forwarding rules.

## Pregunta 362

Contexto: [topics:197](#topics-197)
Your financial services company is migrating its operations to Google Cloud. You are implementing a centralized logging strategy to meet strict regulatory compliance requirements. Your company's Google Cloud organization has a dedicated folder for all production projects.

All audit logs, including data access logs from all current and future projects within this production folder, must be securely collected and stored in a central BigQuery dataset for long-term retention and analysis.

To prevent duplicate log storage and enforce centralized control, you need to implement a logging solution that intercepts and overrides any project-level log sinks for these audit logs. You must ensure that logs are not inadvertently routed elsewhere.

What should you do?

**A.** Create a log sink in each production project to route audit logs to the central BigQuery dataset. Set the writerIdentity field of each sink to a service account with BigQuery Data Editor permissions on the central dataset.

**B.** Create an aggregated log sink at the production folder level with a destination of the central BigQuery dataset. Configure an inclusion filter for all audit and Data Access logs. Grant the Logs Bucket Writer role to the sink’s service account on the production folder.

**C.** Create an intercepting aggregated log sink at the production folder level with the central BigQuery dataset as the destination. Configure an inclusion filter for the necessary audit logs. Grant the appropriate IAM permissions to the sink’s writerIdentity on the BigQuery dataset.

**D.** Create an aggregated log sink at the organization level with a destination of the central BigQuery dataset and a filter for all audit logs. Use the -- include-children flag and configure a log view for the production folder.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 363

Contexto: [topics:197](#topics-197)
Your company has multiple teams needing access to specific datasets across various Google Cloud data services for different projects. You need to ensure that team members can only access the data relevant to their projects and prevent unauthorized access to sensitive information within BigQuery, Cloud Storage, and Cloud SQL.

What should you do?

**A.** Grant project-level group permissions by using specific Cloud IAM roles. Use BigQuery authorized views, Cloud Storage uniform bucket-level access, and Cloud SQL database roles.

**B.** Use VPC Service Controls to create security perimeters around the projects for BigQuery, Cloud Storage, and Cloud SQL services, restricting access based on the network origin of the requests.

**C.** Configure an access level to control access to the Google Cloud console for users managing these data services. Require multi-factor authentication for all access attempts.

**D.** Enable project-level data access logs for BigQuery, Cloud Storage, and Cloud SQL. Configure log sinks to export these logs to Security Command Center to identify unauthorized access attempts.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 364

Contexto: [topics:197](#topics-197)
Your organization wants to protect its supply chain from attacks. You need to automatically scan your deployment pipeline for vulnerabilities and ensure only scanned and verified containers can be executed in your production environment. You want to minimize management overhead. What should you do?

**A.** Use Cloud Next Generation Firewall (Cloud NGFW) Enterprise with traffic inspection to restrict access to containerized applications in the production environment.

**B.** Deploy all container images to a staging environment and use Container Threat Detection to detect malicious content before promoting them to production.

**C.** Review container images before deployment to production, checking for known vulnerabilities using a public vulnerability database. Use Grafeas and Kritis to prevent deployment of containers that haven’t been built using your build pipeline.

**D.** Integrate Artifact Registry vulnerability scanning and Binary Authorization into your CI/CD pipeline to ensure only verified images are deployed to production.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 365

Contexto: [topics:197](#topics-197)
A European financial services company is building a new application on Google Cloud to process sensitive customer loan data. To comply with GDPR and other local regulations, the company’s se-curity team has defined two critical requirements for the environment that will host this application:

•	Data residency: All customer data at rest and in processing must remain strictly within data centers located in the European Union.
•	Access control: Any administrative or support access to customer data by Google personnel must require explicit approval from the company’s security team before access is granted.

You need to design a solution that ensures these compliance requirements are automatically and con-sistently enforced across the Google Cloud environment hosting the new application. What should you do?

**A.** Create an Assured Workloads folder configured for EU Regions and data residency. Enable Ac-cess Approval on the folder to ensure all Google support access requests require explicit, time-bound approval.

**B.** Deploy all resources to EU regions and create a custom IAM role that grants access only to ser-vices physically located in the EU. Monitor Cloud Audit Logs to detect unauthorized access.

**C.** Establish a VPC Service Control perimeter around the projects that denies egress to any non-EU services. Use IAM conditions to restrict access to principals located in the EU.

**D.** Create an Organization Policy at the project level with a constraint that restricts resource locations to EU regions. Use Access Transparency logs to audit any access by Google personnel.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 366

Contexto: [topics:197](#topics-197)
Your security team notified you that a developer at your company has excessive user account per-missions. The developer frequently needs to perform actions that require elevated privileges on cer-tain Google Cloud resources. You need to implement a solution that allows the developer to perform these privileged actions securely, without granting permanent, broad access. What should you do?

**A.** Create a dedicated service account with the required permissions, and share its key with the de-veloper.

**B.** Create a separate project for these privileged operations, and grant the developer full access to the project.

**C.** Configure Privileged Access Manager to provide temporary access to the service account with the required permissions.

**D.** Grant the developer’s user account the necessary IAM roles directly on the target resources using Terraform.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 367

Contexto: [topics:197](#topics-197)
Your organization has a critical application deployed within a Google Cloud VPC. This VPC is part of a VPC Service Controls perimeter that enforces strict data security policies for your Cloud Stor-age buckets and BigQuery datasets. The application requires:

•	Secure, private network connectivity to a legacy API in your on-premises data center.
•	Access to the perimeter-protected Google Cloud Storage and BigQuery APIs from within the VPC.
•	On-premises resources within the VPC resources can only communicate with Google APIs that are integrated with your VPC Service Controls perimeter.

What should you do?

**A.** Establish a Cloud VPN connection to your on-premises network. Configure Private Google Ac-cess on the application’s subnet, and create private DNS zones to resolve *.googleapis.com to the IP addresses associated with restricted.googleapis.com.

**B.** Configure a Cloud VPN for on-premises connectivity. Enable Private Google Access on the sub-net. Use the default private.googleapis.com for accessing Google APIs.

**C.** Set up a Dedicated Interconnect connection for on-premises access. For Google API access from the VPC, configure Private Service Connect endpoints for Cloud Storage and BigQuery specifically, and allow other Google API traffic through a Cloud NAT gateway.

**D.** Deploy a Cloud Router in your VPC, and peer the Cloud Router with your on-premises router. Use public Google API endpoints, and configure VPC Service Controls.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 368

Contexto: [topics:197](#topics-197)
Your organization has 3 TB of information in BigQuery and Cloud SQL. You need to develop a cost-effective, scalable, and secure strategy to anonymize the personally identifiable information (PII) that exists today. What should you do?

**A.** Scan your BigQuery and Cloud SQL data using the Cloud SDP data profiling feature. Use the data profiling results to create a de-identification strategy with either Cloud Sensitive Data Protec-tion’s de-identification templates or custom configurations.

**B.** Export all 3TB of data from BigQuery and Cloud SQL to Cloud Storage. Use Cloud Sensitive Data Protection to anonymize the exported data. Re-import the anonymized data back into BigQuery and Cloud SQL.

**C.** Inspect a representative sample of the data in BigQuery and Cloud SQL to identify PII. Based on this analysis, develop a custom script to anonymize the identified PII.

**D.** Create a new BigQuery dataset and Cloud SQL instance. Copy a small subset of the data to these new locations. Use Cloud Data Loss Prevention API to scan this subset for PII. Based on the results, create a custom anonymization script and apply the script to the entire 3 TB dataset in the original locations.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 369

Contexto: [topics:197](#topics-197)
Your organization has recently migrated sensitive customer data to Google Cloud storage buckets. Due to regulatory requirements, the security department has mandated that all storage buckets stor-ing sensitive information be encrypted with customer-managed encryption keys (CMEKs). You need to encrypt the Google Cloud Storage buckets using a FIPS 140-2 level 3 validated encryption type. Your solution must support automatic key rotation and frequent data reads. What should you do?

**A.** Use an asymmetric key generated by Cloud Hardware Security Module (HSM).

**B.** Use a symmetric key generated by Cloud External Key Manager (EKM).

**C.** Use a symmetric key generated by Cloud Hardware Security Module (HSM).

**D.** Use a symmetric key generated by Cloud Key Management Service (KMS).

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 370

Contexto: [topics:197](#topics-197)
You are designing a solution to securely manage internet egress for your Google Cloud environment. This environment includes 50 Google Cloud projects with individual networks. Resources in each of the projects need to access the internet. The solution must be able to control access to internet re-sources by monitoring and filtering source IP addresses, destination IP addresses, and URLs. It must also be able to inspect TLS traffic. The deployed solution must be cost-efficient and easy to maintain. What should you do?

**A.** Deploy a set of VPC firewall rules in the relevant VPC networks. Configure the network firewall policy to restrict connections to the internet as required.

**B.** Deploy a Cloud Router in each of the projects, and configure a Cloud NAT gateway for the Cloud Router. Configure the Cloud NAT gateway to restrict connections to the internet as required.

**C.** Deploy a Secure Web Proxy instance in a separate project. Use Private Service Connect to make this instance available in each of the projects and restrict connections to the internet as required.

**D.** Deploy a global Cloud Next Generation Firewall (Cloud NGFW) Standard network firewall pol-icy in your Google Cloud environment. Configure the network firewall policy to restrict connections to the internet as required.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 371

Contexto: [topics:197](#topics-197)
Your company is deploying proprietary financial trading algorithms on Compute Engine for real-time market analysis. Despite strong encryption for data at rest and in transit, you need to prevent exposure of these algorithms and their in-memory data during active execution, even from highly privileged cloud administrators. What should you do?

**A.** Enable Confidential Computing on the Compute Engine virtual machines. Use hardware-level encryption to protect data in use.

**B.** Configure VPC Service Controls to create a secure perimeter around the Compute Engine project.

**C.** Implement extensive IAM policies on the Compute Engine instances and their associated service accounts.

**D.** Develop and implement application-level encryption and code obfuscation techniques for the proprietary algorithms and any temporary data before execution on the VMs.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 372

Contexto: [topics:197](#topics-197)
All logs in your organization are aggregated into a centralized Google Cloud logging project for analysis and long-term retention. While most of the log data can be viewed by operations teams, there are specific sensitive fields (i.e., protoPay-load.authenticationInfo.principalEmail) that contain identifiable information that should be restricted only to security teams. You need to implement a solution that allows differ-ent teams to view their respective application logs in the centralized logging project. It must also re-strict access to specific sensitive fields within those logs to only a designated security group. Your solution must ensure that other fields in the same log entry remain visible to other authorized groups. What should you do?

**A.** Use Cloud IAM custom roles with specific permissions on log-ging.privateLogEntrie.list. Define field-level access within the custom role’s condi-tions.

**B.** Create a BigQuery authorized view on the exported log sink to filter out the sensitive fields based on user groups.

**C.** Configure field-level access in Cloud Logging by defining data access policies that specify sensi-tive fields and the authorized principals.

**D.** Implement a log sink to exclude sensitive fields before logs are sent to the centralized logging project. Create separate sinks for sensitive data.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 373

Contexto: [topics:197](#topics-197)
Your company is using Vertex AI to train a custom image recognition model using sensitive, proprie-tary image data stored in Cloud Storage. You are concerned about the potential for data exfiltration during the model training process. You need to prevent unauthorized access to the training data and ensure that data cannot be copied or transferred outside of your controlled Google Cloud environ-ment during and after the training process. What should you do?

**A.** Configure a VPC Service Controls perimeter and Context-Aware Access that includes your Cloud Storage bucket and the Vertex AI service.

**B.** Encrypt the training data in Cloud Storage using a customer-managed encryption key (CMEK).

**C.** Create a firewall rule in your VPC to block all outbound traffic from the Vertex AI training in-stances.

**D.** Enable Cloud Data Loss Prevention (Cloud DLP) on the Cloud Storage bucket that contains the training data.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 374

Contexto: [topics:197](#topics-197)
You work for a large financial institution that uses Google Cloud. Your company has a strict policy that requires encryption at rest for all data. You want to enforce the use of approved customer-managed encryption keys (CMEKs) for all supported resources across the organization. You also want to prevent the creation of resources that do not comply with the encryption policy. What should you do?

**A.** Implement an organization policy that sets the gcp.resourceLocations constraint to on-ly allow resource creation in regions where approved CMEKs are available.

**B.** Implement an organization policy that restricts the gcp.restrictNonCmekServices constraint to enforce CMEK usage for supported services and restricts the gcp.restrictCmekCryptoKeyProjects constraint to limit which keys can be used.

**C.** Develop a Cloud function triggered by Cloud Audit Logs for resource creation events. Configure the function to inspect resource configurations for approved CMEK usage and automatically delete or quarantine non-compliant resources.
Mark for Review

**D.** Create a custom IAM role that allows creating resources only if CMEK is specified. Assign this role to all developers.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 375

Contexto: [topics:197](#topics-197)
A centralized security service has been implemented by your company. All applications running in Google Cloud are required to send data to this service. You need to ensure that developers have high autonomy to configure firewall rules within their projects, while preventing accidental blockage of access to the central security service. What should you do?

**A.** Create a central project to manage Shared VPC networks which will be accessible to all other projects. Administer all firewall rules centrally within this project.

**B.** Use Terraform to automate the creation of the required firewall rule in all projects. Restrict rule change permissions solely to the Terraform service account.

**C.** Implement a hierarchical firewall policy that prioritizes the central security service by allowing its connections and directing all other traffic to the subsequent firewall level.

**D.** Deploy a central Secure Web Proxy and connect it to all VPC networks. Create a Secure Web Proxy policy to allow traffic to the central security service.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 376

Contexto: [topics:197](#topics-197)
Your team has developed a public web application that is running on Cloud Run. In the past, there were passwords in the application configuration that escaped your checks. You need to implement an approach to timely identify when the Cloud Run service’s environment variables include any passwords. What should you do?

**A.** Activate Container Threat Detection. Verify that it checks for passwords on a continuous basis.

**B.** Integrate source code scans into the CI/CD pipeline. Verify that the application code is scanned each time a new deployment is triggered.

**C.** Set up discovery scans in Sensitive Data Protection. Verify that scans are updated regularly and when relevant data changes.

**D.** Enable a third party web security scanner. Verify that it regularly scans the public endpoints of the application.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.