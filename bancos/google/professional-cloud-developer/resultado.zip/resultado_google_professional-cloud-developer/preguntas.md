# professional cloud developer

379 / 379 preguntas. Cobertura completa: True.

Respuestas de la fuente; revisión técnica pendiente. Las imágenes permanecen en sus campos de origen.

379 respuestas conservadas; 0 pendientes.

<a id="topics-726"></a>
## Contexto topics:726
name:
Topic 1

<a id="case_studies-117"></a>
## Contexto case_studies:117
name:
HipLocal

scenario_text:
Case study -

This is a case study. Case studies are not timed separately. You can use as much exam time as you would like to complete each case. However, there may be additional case studies and sections on this exam. You must manage your time to ensure that you are able to complete all questions included on this exam in the time provided.

To answer the questions included in a case study, you will need to reference information that is provided in the case study. Case studies might contain exhibits and other resources that provide more information about the scenario that is described in the case study. Each question is independent of the other questions in this case study.

At the end of this case study, a review screen will appear. This screen allows you to review your answers and to make changes before you move to the next section of the exam. After you begin a new section, you cannot return to this section.

To start the case study -
To display the first question in this case study, click the Next button. Use the buttons in the left pane to explore the content of the case study before you answer the questions. Clicking these buttons displays information such as business requirements, existing environment, and problem statements. If the case study has an All Information tab, note that the information displayed is identical to the information displayed on the subsequent tabs. When you are ready to answer a question, click the Question button to return to the question.

Company Overview -
HipLocal is a community application designed to facilitate communication between people in close proximity. It is used for event planning and organizing sporting events, and for businesses to connect with their local communities. HipLocal launched recently in a few neighborhoods in Dallas and is rapidly growing into a global phenomenon. Its unique style of hyper-local community communication and business outreach is in demand around the world.

Executive Statement -
We are the number one local community app; it's time to take our local community services global. Our venture capital investors want to see rapid growth and the same great experience for new local and virtual communities that come online, whether their members are 10 or 10000 miles away from each other.

Solution Concept -
HipLocal wants to expand their existing service, with updated functionality, in new regions to better serve their global customers. They want to hire and train a new team to support these regions in their time zones. They will need to ensure that the application scales smoothly and provides clear uptime data, and that they analyze and respond to any issues that occur.

Existing Technical Environment -
HipLocal's environment is a mix of on-premises hardware and infrastructure running in Google Cloud Platform. The HipLocal team understands their application well, but has limited experience in global scale applications. Their existing technical environment is as follows:
• Existing APIs run on Compute Engine virtual machine instances hosted in GCP.
• State is stored in a single instance MySQL database in GCP.
• Release cycles include development freezes to allow for QA testing.
• The application has no logging.
• Applications are manually deployed by infrastructure engineers during periods of slow traffic on weekday evenings.
• There are basic indicators of uptime; alerts are frequently fired when the APIs are unresponsive.

Business Requirements -
HipLocal's investors want to expand their footprint and support the increase in demand they are seeing. Their requirements are:
• Expand availability of the application to new regions.
• Support 10x as many concurrent users.
• Ensure a consistent experience for users when they travel to different regions.
• Obtain user activity metrics to better understand how to monetize their product.
• Ensure compliance with regulations in the new regions (for example, GDPR).
• Reduce infrastructure management time and cost.
• Adopt the Google-recommended practices for cloud computing.
○ Develop standardized workflows and processes around application lifecycle management.
○ Define service level indicators (SLIs) and service level objectives (SLOs).

Technical Requirements -
• Provide secure communications between the on-premises data center and cloud-hosted applications and infrastructure.
• The application must provide usage metrics and monitoring.
• APIs require authentication and authorization.
• Implement faster and more accurate validation of new features.
• Logging and performance metrics must provide actionable information to be able to provide debugging information and alerts.
• Must scale to meet user demand.


## Pregunta 1

Contexto: [topics:726](#topics-726)
You want to upload files from an on-premises virtual machine to Google Cloud Storage as part of a data migration. These files will be consumed by Cloud
DataProc Hadoop cluster in a GCP environment.
Which command should you use?

**A.** gsutil cp [LOCAL_OBJECT] gs://[DESTINATION_BUCKET_NAME]/

**B.** gcloud cp [LOCAL_OBJECT] gs://[DESTINATION_BUCKET_NAME]/

**C.** hadoop fs cp [LOCAL_OBJECT] gs://[DESTINATION_BUCKET_NAME]/

**D.** gcloud dataproc cp [LOCAL_OBJECT] gs://[DESTINATION_BUCKET_NAME]/

**Respuesta de la fuente:** A

**Explicación:** gsutil is the dedicated command-line tool for interacting with Google Cloud Storage, making 'gsutil cp' the correct method for uploading local files to a GCS bucket.
The gcloud CLI is primarily for resource management and configuration, not designed for direct data transfer operations like copying files to buckets.

## Pregunta 2

Contexto: [topics:726](#topics-726)
You migrated your applications to Google Cloud Platform and kept your existing monitoring platform. You now find that your notification system is too slow for time critical problems.
What should you do?

**A.** Replace your entire monitoring platform with Stackdriver.

**B.** Install the Stackdriver agents on your Compute Engine instances.

**C.** Use Stackdriver to capture and alert on logs, then ship them to your existing platform.

**D.** Migrate some traffic back to your old platform and perform AB testing on the two platforms concurrently.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it addresses the specific bottleneck (slow notifications) by leveraging Stackdriver's immediate alerting capabilities for time-critical issues, while preserving the investment in the existing monitoring platform for broader log analysis and storage. This approach avoids the high cost and complexity of a full migration (Option A) and ensures no disruption to ongoing operational workflows.

Option A is incorrect because replacing an entire working monitoring system is excessive when only the notification latency is problematic; it introduces unnecessary risk, cost, and retraining overhead without addressing the root cause efficiently.

## Pregunta 3

Contexto: [topics:726](#topics-726)
You are planning to migrate a MySQL database to the managed Cloud SQL database for Google Cloud. You have Compute Engine virtual machine instances that will connect with this Cloud SQL instance. You do not want to whitelist IPs for the Compute Engine instances to be able to access Cloud SQL.
What should you do?

**A.** Enable private IP for the Cloud SQL instance.

**B.** Whitelist a project to access Cloud SQL, and add Compute Engine instances in the whitelisted project.

**C.** Create a role in Cloud SQL that allows access to the database from external instances, and assign the Compute Engine instances to that role.

**D.** Create a CloudSQL instance on one project. Create Compute engine instances in a different project. Create a VPN between these two projects to allow internal access to CloudSQL.

**Respuesta de la fuente:** A

**Explicación:** To connect Compute Engine instances to Cloud SQL without whitelisting IPs, you must use a Private IP configuration. This allows traffic to flow over the internal VPC network, bypassing the need for public IP exposure and associated firewall/whitelist rules.
Option B is incorrect because Cloud SQL does not support project-level access whitelisting as described; it relies on IP addresses or proxies. Options C and D involve unnecessary complexity or non-existent features for this specific requirement.

## Pregunta 4

Contexto: [topics:726](#topics-726)
You have deployed an HTTP(s) Load Balancer with the gcloud commands shown below.
[Imagen: sin descripción]
Health checks to port 80 on the Compute Engine virtual machine instance are failing and no traffic is sent to your instances. You want to resolve the problem.
Which commands should you run?
Imagen · question_text · sin descripción
![Imagen original](imagenes/f3313e39abdaaaa58cef.jpg)
OCR: automatic_unverified · Revisión visual pendiente.
```text
export NAME-load-balancer
# create network
geloud compute networks create ${NAME}
# add instance
geloud compute instances create ${NAME}-backend-instance-1 --subnet ${NAME} --no address
# create the instance group
geloud compute instance-groups unmanaged create ${NAME}-i
geloud compute instance-groups unmanaged set-named-ports ${NAME}-i --named-ports http:80
gcloud compute instance-groups unmanaged add-instances ${NAME}-i --instances ${NAME}-instance-1
# configure health checks
gcloud compute health-checks create http ${NAME}-http-he --port 80
# create backend service
gcloud compute backend-services create ${NAME}-http-bes --health-checks ${NAME}-http-he --protocol HTTP --port-name http
--global
gcloud compute backend-services add-backend ${NAME}-http-bes --instance-group ${NAME}-i --balancing-mode RATE --max-rate
100000 --capacity-scaler 1.0 --global --instance-group-zone us-easti-d
# create urls maps and forwarding rule
geloud compute url-maps create ${NAME}-http-urlmap --default-service ${NAME}-http-bes
geloud compute target-http-proxies create ${NAME}-http-proxy --url-map ${NAME}-http-urlmap
gceloud compute forwarding-rules create ${NAME}-http-fw --global --ip-protocol ICP --target-http-proxy ${NAME}-http-proxy
--ports 80
```

**A.** gcloud compute instances add-access-config ${NAME}-backend-instance-1

**B.** gcloud compute instances add-tags ${NAME}-backend-instance-1 --tags http-server

**C.** gcloud compute firewall-rules create allow-lb --network load-balancer --allow tcp --source-ranges 130.211.0.0/22,35.191.0.0/16 --direction INGRESS

**D.** gcloud compute firewall-rules create allow-lb --network load-balancer --allow tcp --destination-ranges 130.211.0.0/22,35.191.0.0/16 --direction EGRESS

**Respuesta de la fuente:** C

**Explicación:** Google Cloud HTTP(S) Load Balancers use specific source IP ranges (130.211.0.0/22 and 35.191.0.0/16) to send health check probes to backend instances. Since these are inbound connections initiated by Google's load balancing infrastructure, an INGRESS firewall rule allowing TCP traffic from these specific source ranges is required to ensure the health checks succeed.
Option B is tempting because network tags are often used for firewall targeting, but adding a tag alone does not create the necessary firewall rule to allow traffic; without the corresponding ingress rule permitting the health check IPs, the probes will still be blocked.

## Pregunta 5

Contexto: [topics:726](#topics-726)
Your website is deployed on Compute Engine. Your marketing team wants to test conversion rates between 3 different website designs.
Which approach should you use?

**A.** Deploy the website on App Engine and use traffic splitting.

**B.** Deploy the website on App Engine as three separate services.

**C.** Deploy the website on Cloud Functions and use traffic splitting.

**D.** Deploy the website on Cloud Functions as three separate functions.

**Respuesta de la fuente:** A

**Explicación:** App Engine supports deploying multiple versions of the same service and using traffic splitting to route a percentage of incoming requests to each version, making it ideal for A/B testing. Cloud Functions do not natively support this type of proportional traffic splitting between different function deployments without additional infrastructure like Load Balancing.
Option B is incorrect because creating three separate services adds unnecessary management overhead; the goal is to test variations of the same application logic, which App Engine versions handle efficiently.

## Pregunta 6

Contexto: [topics:726](#topics-726)
You need to copy directory local-scripts and all of its contents from your local workstation to a Compute Engine virtual machine instance.
Which command should you use?

**A.** gsutil cp --project "my-gcp-project" -r ~/local-scripts/ gcp-instance-name:~/server-scripts/ --zone "us-east1-b"

**B.** gsutil cp --project "my-gcp-project" -R ~/local-scripts/ gcp-instance-name:~/server-scripts/ --zone "us-east1-b"

**C.** gcloud compute scp --project "my-gcp-project" --recurse ~/local-scripts/ gcp-instance-name:~/server-scripts/ --zone "us-east1-b"

**D.** gcloud compute mv --project "my-gcp-project" --recurse ~/local-scripts/ gcp-instance-name:~/server-scripts/ --zone "us-east1-b"

**Respuesta de la fuente:** C

**Explicación:** The gcloud compute scp command is specifically designed to securely copy files between a local workstation and Compute Engine instances using SSH.
Option C correctly uses the --recurse flag (equivalent to -r in standard scp) to copy the directory and its contents.
Options A and B are incorrect because gsutil is intended for transferring data to/from Cloud Storage buckets, not directly to VM instances.
Option D is incorrect because there is no gcloud compute mv command for this purpose.

## Pregunta 7

Contexto: [topics:726](#topics-726)
You are deploying your application to a Compute Engine virtual machine instance with the Stackdriver Monitoring Agent installed. Your application is a unix process on the instance. You want to be alerted if the unix process has not run for at least 5 minutes. You are not able to change the application to generate metrics or logs.
Which alert condition should you configure?

**A.** Uptime check

**B.** Process health

**C.** Metric absence

**D.** Metric threshold

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 8

Contexto: [topics:726](#topics-726)
You have two tables in an ANSI-SQL compliant database with identical columns that you need to quickly combine into a single table, removing duplicate rows from the result set.
What should you do?

**A.** Use the JOIN operator in SQL to combine the tables.

**B.** Use nested WITH statements to combine the tables.

**C.** Use the UNION operator in SQL to combine the tables.

**D.** Use the UNION ALL operator in SQL to combine the tables.

**Respuesta de la fuente:** C

**Explicación:** The UNION operator combines result sets from multiple SELECT statements and automatically removes duplicate rows, which directly satisfies the requirement to remove duplicates.
In contrast, UNION ALL retains all duplicates, making it incorrect for this specific constraint, while JOIN is used to combine columns horizontally based on a relationship rather than stacking rows vertically.

## Pregunta 9

Contexto: [topics:726](#topics-726)
You have an application deployed in production. When a new version is deployed, some issues don't arise until the application receives traffic from users in production. You want to reduce both the impact and the number of users affected.
Which deployment strategy should you use?

**A.** Blue/green deployment

**B.** Canary deployment

**C.** Rolling deployment

**D.** Recreate deployment

**Respuesta de la fuente:** B

**Explicación:** Canary deployment is the correct choice because it allows you to route a small percentage of traffic to the new version, thereby limiting the number of users affected if issues arise. This strategy directly addresses the requirement to reduce both the impact and the scope of potential failures during production rollout.

Blue/green deployment (A) typically switches all traffic at once or in large batches, which does not limit the number of affected users as effectively as a canary release for initial validation.

## Pregunta 10

Contexto: [topics:726](#topics-726)
Your company wants to expand their users outside the United States for their popular application. The company wants to ensure 99.999% availability of the database for their application and also wants to minimize the read latency for their users across the globe.
Which two actions should they take? (Choose two.)

**A.** Create a multi-regional Cloud Spanner instance with "nam-asia-eur1" configuration.

**B.** Create a multi-regional Cloud Spanner instance with "nam3" configuration.

**C.** Create a cluster with at least 3 Spanner nodes.

**D.** Create a cluster with at least 1 Spanner node.

**E.** Create a minimum of two Cloud Spanner instances in separate regions with at least one node.

**F.** Create a Cloud Dataflow pipeline to replicate data across different databases.

**Respuesta de la fuente:** A, C

**Explicación:** To achieve 99.999% availability and minimize global read latency, the correct configuration is a multi-regional Cloud Spanner instance spanning North America, Asia, and Europe (Option A). This ensures low-latency reads from any global user base by locating replicas near them.

Regarding node count, while nodes primarily scale CPU/RAM for throughput, Option C is selected in this context to ensure sufficient computational resources are provisioned to handle the query load without becoming a bottleneck, thereby indirectly supporting latency goals under high concurrency. Options B and D cover insufficient geographic scope or resource capacity, respectively, and F is unnecessary as Spanner handles replication automatically.

## Pregunta 11

Contexto: [topics:726](#topics-726)
You need to migrate an internal file upload API with an enforced 500-MB file size limit to App Engine.
What should you do?

**A.** Use FTP to upload files.

**B.** Use CPanel to upload files.

**C.** Use signed URLs to upload files.

**D.** Change the API to be a multipart file upload API.

**Respuesta de la fuente:** C

**Explicación:** App Engine standard environment has a request body size limit (typically 10MB-32MB), which makes direct uploads of large files like 500 MB impossible via the API.
Using signed URLs allows clients to upload files directly to Cloud Storage, bypassing the App Engine instance and its size constraints entirely.
Option D is incorrect because changing the API to multipart does not remove the underlying request size limit imposed by the App Engine runtime.

## Pregunta 12

Contexto: [topics:726](#topics-726)
You are planning to deploy your application in a Google Kubernetes Engine (GKE) cluster. The application exposes an HTTP-based health check at /healthz. You want to use this health check endpoint to determine whether traffic should be routed to the pod by the load balancer.
Which code snippet should you include in your Pod configuration?

**A.** [Imagen: sin descripción]
Imagen · choices[0].text · sin descripción
![Imagen original](imagenes/b86bfe185beef047023a.jpg)
OCR: automatic_unverified · Revisión visual pendiente.
```text
livenessProbe:
httpGet:
path: /healthz
port: 80
```

**B.** [Imagen: sin descripción]
Imagen · choices[1].text · sin descripción
![Imagen original](imagenes/8ccdec80d7859515df49.jpg)
OCR: automatic_unverified · Revisión visual pendiente.
```text
readinessProbe:
httpGet:
path: /healthz
port: 80
```

**C.** [Imagen: sin descripción]
Imagen · choices[2].text · sin descripción
![Imagen original](imagenes/9a844ffe1be2b8d63685.jpg)
OCR: automatic_unverified · Revisión visual pendiente.
```text
loadbalancerHealthCheck:
httpGet:
path: /healthz
port: 80
```

**D.** [Imagen: sin descripción]
Imagen · choices[3].text · sin descripción
![Imagen original](imagenes/748b9581c370ed8a8b8c.jpg)
OCR: automatic_unverified · Revisión visual pendiente.
```text
healthCheck:
httpGet:
path: /healthz
port: 80
```

**Respuesta de la fuente:** B

**Explicación:** The readiness probe determines when a pod is ready to accept traffic; if it fails, the pod is removed from service endpoints.
In GKE, the Ingress controller and load balancers infer health check parameters directly from the container's readiness probe configuration.
Liveness probes manage restarts but do not control traffic routing, while options C and D are invalid Kubernetes fields.

## Pregunta 13

Contexto: [topics:726](#topics-726)
Your teammate has asked you to review the code below. Its purpose is to efficiently add a large number of small rows to a BigQuery table.
[Imagen: sin descripción]
Which improvement should you suggest your teammate make?
Imagen · question_text · sin descripción
![Imagen original](imagenes/a6f6ae332c7479082323.jpg)
OCR: automatic_unverified · Revisión visual pendiente.
```text
BigQuery service = BigQueryOptions.newBuilder() .build() .getService();
public void writeToBigQuery(Collection<Map<String, String>> rows){
for (Map<String, String> row : rows) {
InsertAllRequest insertRequest = InsertAllRequest.newBuilder (
“datasetId”, “tableId”,
InsertAllRequest .RowToInsert.of (row) ) .build();
service.insertAll (insertRequest) ;
```

**A.** Include multiple rows with each request.

**B.** Perform the inserts in parallel by creating multiple threads.

**C.** Write each row to a Cloud Storage object, then load into BigQuery.

**D.** Write each row to a Cloud Storage object in parallel, then load into BigQuery.

**Respuesta de la fuente:** A

**Explicación:** The provided code inefficiently sends individual HTTP requests for each row via the BigQuery Streaming Inserts API. To optimize performance, you should batch multiple rows into a single InsertAllRequest, reducing network latency and overhead per row.

Option C is less suitable here because while loading from Cloud Storage is efficient for very large datasets, it introduces significant storage I/O and processing steps that are unnecessary if the data is already in memory and can be streamed efficiently via batching.

## Pregunta 14

Contexto: [topics:726](#topics-726)
You are developing a JPEG image-resizing API hosted on Google Kubernetes Engine (GKE). Callers of the service will exist within the same GKE cluster. You want clients to be able to get the IP address of the service.
What should you do?

**A.** Define a GKE Service. Clients should use the name of the A record in Cloud DNS to find the service's cluster IP address.

**B.** Define a GKE Service. Clients should use the service name in the URL to connect to the service.

**C.** Define a GKE Endpoint. Clients should get the endpoint name from the appropriate environment variable in the client container.

**D.** Define a GKE Endpoint. Clients should get the endpoint name from Cloud DNS.

**Respuesta de la fuente:** B

**Explicación:** Answer B is correct because Kubernetes Services automatically register DNS entries that map the service name to its cluster IP, allowing internal clients to connect using the service name directly in URLs without managing static IPs.
Option A is incorrect because GKE uses CoreDNS (or kube-dns) for internal resolution, not Cloud DNS, which is primarily used for external internet-facing domains.

## Pregunta 15

Contexto: [topics:726](#topics-726)
You are using Cloud Build to build and test application source code stored in Cloud Source Repositories. The build process requires a build tool not available in the Cloud Build environment.
What should you do?

**A.** Download the binary from the internet during the build process.

**B.** Build a custom cloud builder image and reference the image in your build steps.

**C.** Include the binary in your Cloud Source Repositories repository and reference it in your build scripts.

**D.** Ask to have the binary added to the Cloud Build environment by filing a feature request against the Cloud Build public Issue Tracker.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Build allows you to use custom Docker images that include any specific build tools or dependencies required for your process. By building a custom cloud builder image, you create a reusable environment tailored to your needs without relying on external downloads during the build or modifying the source repository.

Option A is incorrect because downloading binaries during the build increases build time and introduces security risks if not properly validated. Option C is discouraged as storing large binaries in version control systems bloats the repository and complicates management.

## Pregunta 16

Contexto: [topics:726](#topics-726)
You are deploying your application to a Compute Engine virtual machine instance. Your application is configured to write its log files to disk. You want to view the logs in Stackdriver Logging without changing the application code.
What should you do?

**A.** Install the Stackdriver Logging Agent and configure it to send the application logs.

**B.** Use a Stackdriver Logging Library to log directly from the application to Stackdriver Logging.

**C.** Provide the log file folder path in the metadata of the instance to configure it to send the application logs.

**D.** Change the application to log to /var/log so that its logs are automatically sent to Stackdriver Logging.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because the Stackdriver Logging Agent (now part of the Cloud Operations agent) is specifically designed to collect logs from custom file paths on VM instances without requiring modifications to the application code. Option B is incorrect as it requires integrating logging libraries directly into the application, violating the 'no code changes' constraint. Options C and D are invalid because instance metadata cannot arbitrarily configure log collection for custom paths, and changing the log destination to /var/log constitutes an application code or configuration change.

## Pregunta 17

Contexto: [topics:726](#topics-726)
Your service adds text to images that it reads from Cloud Storage. During busy times of the year, requests to Cloud Storage fail with an HTTP 429 "Too Many
Requests" status code.
How should you handle this error?

**A.** Add a cache-control header to the objects.

**B.** Request a quota increase from the GCP Console.

**C.** Retry the request with a truncated exponential backoff strategy.

**D.** Change the storage class of the Cloud Storage bucket to Multi-regional.

**Respuesta de la fuente:** C

**Explicación:** HTTP 429 errors indicate that the client has exceeded the allowed request rate, triggering server-side throttling. Google Cloud documentation explicitly recommends using a truncated exponential backoff strategy to gracefully handle these limits by spacing out retries until capacity is available.

Option B (quota increase) addresses the limit configuration but does not resolve immediate transient failures caused by bursty traffic patterns, whereas backoff handles the error at the application level.

## Pregunta 18

Contexto: [topics:726](#topics-726)
You are building an API that will be used by Android and iOS apps. The API must:
* Support HTTPs
* Minimize bandwidth cost
* Integrate easily with mobile apps
Which API architecture should you use?

**A.** RESTful APIs

**B.** MQTT for APIs

**C.** gRPC-based APIs

**D.** SOAP-based APIs

**Respuesta de la fuente:** C

**Explicación:** gRPC (C) is the correct choice because it uses Protocol Buffers for binary serialization, which significantly minimizes bandwidth costs compared to text-based formats like JSON or XML.
It natively supports HTTPS via HTTP/2 and generates client stubs that simplify integration for both Android and iOS applications.
The most tempting alternative, RESTful APIs (A), is incorrect because its typical use of JSON results in higher payload sizes, failing the specific requirement to minimize bandwidth.

## Pregunta 19

Contexto: [topics:726](#topics-726)
Your application takes an input from a user and publishes it to the user's contacts. This input is stored in a table in Cloud Spanner. Your application is more sensitive to latency and less sensitive to consistency.
How should you perform reads from Cloud Spanner for this application?

**A.** Perform Read-Only transactions.

**B.** Perform stale reads using single-read methods.

**C.** Perform strong reads using single-read methods.

**D.** Perform stale reads using read-write transactions.

**Respuesta de la fuente:** B

**Explicación:** The application prioritizes low latency over strong consistency, which makes stale reads the optimal choice as they offer better performance by reading at a past timestamp.
Single-read methods are recommended for simple read operations to minimize overhead compared to full transactions, making option B the correct configuration.

## Pregunta 20

Contexto: [topics:726](#topics-726)
Your application is deployed in a Google Kubernetes Engine (GKE) cluster. When a new version of your application is released, your CI/CD tool updates the spec.template.spec.containers[0].image value to reference the Docker image of your new application version. When the Deployment object applies the change, you want to deploy at least 1 replica of the new version and maintain the previous replicas until the new replica is healthy.
Which change should you make to the GKE Deployment object shown below?
[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/962a1cfa990edfd78c4f.jpg)
OCR: automatic_unverified · Revisión visual pendiente.
```text
apiVersion: apps/v1
kind: Deployment
metadata:
name: ecommerce-frontend-deployment
spec:
replicas: 3
selector:
matchLabels:
app: ecommerce-frontend
template:
metadata:
labels:
app: ecommerce-frontend
spec:
containers:
- name: ecommerce-frontend-webapp
image: ecommerce-frontend-webapp:1.7.
ports:
- containerPort: 80
```

**A.** Set the Deployment strategy to RollingUpdate with maxSurge set to 0, maxUnavailable set to 1.

**B.** Set the Deployment strategy to RollingUpdate with maxSurge set to 1, maxUnavailable set to 0.

**C.** Set the Deployment strategy to Recreate with maxSurge set to 0, maxUnavailable set to 1.

**D.** Set the Deployment strategy to Recreate with maxSurge set to 1, maxUnavailable set to 0.

**Respuesta de la fuente:** B

**Explicación:** To maintain all previous replicas until the new one is healthy, maxUnavailable must be 0, ensuring no old pods are terminated before validation. Setting maxSurge to 1 allows exactly one new replica to be created and verified alongside the existing fleet, fulfilling the requirement for a safe, non-disruptive update. Option A is incorrect because setting maxUnavailable to 1 would allow an old pod to be terminated immediately, violating the condition to maintain previous replicas.

## Pregunta 21

Contexto: [topics:726](#topics-726)
You plan to make a simple HTML application available on the internet. This site keeps information about FAQs for your application. The application is static and contains images, HTML, CSS, and Javascript. You want to make this application available on the internet with as few steps as possible.
What should you do?

**A.** Upload your application to Cloud Storage.

**B.** Upload your application to an App Engine environment.

**C.** Create a Compute Engine instance with Apache web server installed. Configure Apache web server to host the application.

**D.** Containerize your application first. Deploy this container to Google Kubernetes Engine (GKE) and assign an external IP address to the GKE pod hosting the application.

**Respuesta de la fuente:** A

**Explicación:** Cloud Storage is the most efficient solution for hosting static content because it requires no server management or runtime configuration, directly addressing the goal of minimizing steps. App Engine (Option B) is a tempting alternative but introduces unnecessary complexity by requiring a standard environment setup when simple object storage suffices for pure static assets.

## Pregunta 22

Contexto: [topics:726](#topics-726)
Your company has deployed a new API to App Engine Standard environment. During testing, the API is not behaving as expected. You want to monitor the application over time to diagnose the problem within the application code without redeploying the application.
Which tool should you use?

**A.** Stackdriver Trace

**B.** Stackdriver Monitoring

**C.** Stackdriver Debug Snapshots

**D.** Stackdriver Debug Logpoints

**Respuesta de la fuente:** D

**Explicación:** Stackdriver Debug Logpoints (now Cloud Debugger) allow you to instrument code in a running application to capture variable values and execution paths without redeploying or restarting instances. This is the specific tool designed for diagnosing issues within application code logic in a live environment.

The most tempting alternative, Stackdriver Monitoring, aggregates metrics and logs but does not provide line-by-line execution context or variable inspection capabilities needed to diagnose specific code-level bugs.

## Pregunta 23

Contexto: [topics:726](#topics-726)
You want to use the Stackdriver Logging Agent to send an application's log file to Stackdriver from a Compute Engine virtual machine instance.
After installing the Stackdriver Logging Agent, what should you do first?

**A.** Enable the Error Reporting API on the project.

**B.** Grant the instance full access to all Cloud APIs.

**C.** Configure the application log file as a custom source.

**D.** Create a Stackdriver Logs Export Sink with a filter that matches the application's log entries.

**Respuesta de la fuente:** C

**Explicación:** To send a specific application log file via the Stackdriver Logging Agent, you must first configure that file as a custom input source in the agent's configuration file (e.g., /etc/google-fluentd/conf.d/stackdriver.conf). Without this configuration, the agent does not know which files to monitor and forward to Cloud Logging.

Options A and B are incorrect because the Logging API is typically enabled by default for Compute Engine instances with appropriate scopes, and full access to all APIs (Option B) violates least-privilege security principles. Option D is a post-collection action used for routing logs, not an initial setup step.

## Pregunta 24

Contexto: [topics:726](#topics-726)
Your company has a BigQuery data mart that provides analytics information to hundreds of employees. One user of wants to run jobs without interrupting important workloads. This user isn't concerned about the time it takes to run these jobs. You want to fulfill this request while minimizing cost to the company and the effort required on your part.
What should you do?

**A.** Ask the user to run the jobs as batch jobs.

**B.** Create a separate project for the user to run jobs.

**C.** Add the user as a job.user role in the existing project.

**D.** Allow the user to run jobs when important workloads are not running.

**Respuesta de la fuente:** A

**Explicación:** Batch jobs in BigQuery are specifically designed to execute with lower priority, ensuring they do not interrupt critical interactive workloads. This approach satisfies the user's non-urgent requirements while minimizing administrative effort compared to creating new projects or complex role configurations.
Option B is incorrect because creating a separate project introduces unnecessary infrastructure overhead and management complexity.

## Pregunta 25

Contexto: [topics:726](#topics-726)
You want to notify on-call engineers about a service degradation in production while minimizing development time.
What should you do?

**A.** Use Cloud Function to monitor resources and raise alerts.

**B.** Use Cloud Pub/Sub to monitor resources and raise alerts.

**C.** Use Stackdriver Error Reporting to capture errors and raise alerts.

**D.** Use Stackdriver Monitoring to monitor resources and raise alerts.

**Respuesta de la fuente:** D

**Explicación:** Stackdriver (Cloud) Monitoring is the native GCP service designed for resource monitoring and alerting, providing built-in metrics and alert policies that require no custom code development.
Using Cloud Functions (A) or Pub/Sub (B) would require writing and maintaining custom logic to evaluate thresholds and trigger notifications, violating the goal of minimizing development time.
Error Reporting (C) only captures error logs, missing broader service degradation signals like high latency or resource saturation.

## Pregunta 26

Contexto: [topics:726](#topics-726)
You are writing a single-page web application with a user-interface that communicates with a third-party API for content using XMLHttpRequest. The data displayed on the UI by the API results is less critical than other data displayed on the same web page, so it is acceptable for some requests to not have the API data displayed in the UI. However, calls made to the API should not delay rendering of other parts of the user interface. You want your application to perform well when the API response is an error or a timeout.
What should you do?

**A.** Set the asynchronous option for your requests to the API to false and omit the widget displaying the API results when a timeout or error is encountered.

**B.** Set the asynchronous option for your request to the API to true and omit the widget displaying the API results when a timeout or error is encountered.

**C.** Catch timeout or error exceptions from the API call and keep trying with exponential backoff until the API response is successful.

**D.** Catch timeout or error exceptions from the API call and display the error response in the UI widget.

**Respuesta de la fuente:** B

**Explicación:** Setting the asynchronous option to true (B) ensures the API call does not block the main thread, allowing the rest of the UI to render immediately as required. Omitting the widget on error satisfies the condition that missing data is acceptable without disrupting the user experience.

Choice A is incorrect because synchronous requests block the browser's execution thread, preventing other UI elements from rendering and degrading performance.

## Pregunta 27

Contexto: [topics:726](#topics-726)
You are creating a web application that runs in a Compute Engine instance and writes a file to any user's Google Drive. You need to configure the application to authenticate to the Google Drive API. What should you do?

**A.** Use an OAuth Client ID that uses the https://www.googleapis.com/auth/drive.file scope to obtain an access token for each user.

**B.** Use an OAuth Client ID with delegated domain-wide authority.

**C.** Use the App Engine service account and https://www.googleapis.com/auth/drive.file scope to generate a signed JSON Web Token (JWT).

**D.** Use the App Engine service account with delegated domain-wide authority.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because the application needs to access individual users' Google Drive files, which requires obtaining OAuth 2.0 access tokens specific to each user via a standard Client ID. The `drive.file` scope is recommended for narrow access, ensuring the app only accesses files it created or opened by the user.

Option B (delegated domain-wide authority) is incorrect because it allows the service account to impersonate users within a specific Google Workspace domain, whereas the requirement implies accessing 'any user's' drive, not just those in a managed organization.

## Pregunta 28

Contexto: [topics:726](#topics-726)
You are creating a Google Kubernetes Engine (GKE) cluster and run this command:
[Imagen: sin descripción]
The command fails with the error:
[Imagen: sin descripción]
You want to resolve the issue. What should you do?
Imagen · question_text · sin descripción
![Imagen original](imagenes/b1bb074a0f05b3b12c2a.jpg)
OCR: automatic_unverified · Revisión visual pendiente.
```text
> gcloud container clusters create large-cluster --num-nodes 200
```
Imagen · question_text · sin descripción
![Imagen original](imagenes/69cf68b9efc198138d53.jpg)
OCR: automatic_unverified · Revisión visual pendiente.
```text
insufficient regional quota to satisfy request: resource “CPUS”: request
requires '200.0' and is short '176.0'. project has a quota of '24.0' with
'24.0' available
```

**A.** Request additional GKE quota in the GCP Console.

**B.** Request additional Compute Engine quota in the GCP Console.

**C.** Open a support case to request additional GKE quota.

**D.** Decouple services in the cluster, and rewrite new clusters to function with fewer cores.

**Respuesta de la fuente:** B

**Explicación:** GKE nodes are implemented as Compute Engine virtual machines, so CPU quota limitations for GKE clusters are governed by Compute Engine regional CPU quotas. To resolve the insufficient CPU error, you must request an increase to these underlying Compute Engine quotas via the Cloud Console.
Requesting GKE-specific quotas (Option A) is incorrect because GKE relies on Compute Engine resource limits for compute capacity.

## Pregunta 29

Contexto: [topics:726](#topics-726)
You are parsing a log file that contains three columns: a timestamp, an account number (a string), and a transaction amount (a number). You want to calculate the sum of all transaction amounts for each unique account number efficiently.
Which data structure should you use?

**A.** A linked list

**B.** A hash table

**C.** A two-dimensional array

**D.** A comma-delimited string

**Respuesta de la fuente:** B

**Explicación:** A hash table provides O(1) average-time complexity for lookups and updates, making it the most efficient choice for aggregating values by a unique key (account number).
Linked lists require O(n) linear scans to find existing accounts, while two-dimensional arrays lack dynamic resizing capabilities and efficient key-based indexing.

## Pregunta 30

Contexto: [topics:726](#topics-726)
Your company has a BigQuery dataset named "Master" that keeps information about employee travel and expenses. This information is organized by employee department. That means employees should only be able to view information for their department. You want to apply a security framework to enforce this requirement with the minimum number of steps.
What should you do?

**A.** Create a separate dataset for each department. Create a view with an appropriate WHERE clause to select records from a particular dataset for the specific department. Authorize this view to access records from your Master dataset. Give employees the permission to this department-specific dataset.

**B.** Create a separate dataset for each department. Create a data pipeline for each department to copy appropriate information from the Master dataset to the specific dataset for the department. Give employees the permission to this department-specific dataset.

**C.** Create a dataset named Master dataset. Create a separate view for each department in the Master dataset. Give employees access to the specific view for their department.

**D.** Create a dataset named Master dataset. Create a separate table for each department in the Master dataset. Give employees access to the specific table for their department.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it enforces row-level security using views with appropriate WHERE clauses within the existing Master dataset, satisfying the requirement with the minimum number of steps.
Creating separate datasets (A) or tables (D) introduces unnecessary operational overhead for data ingestion and maintenance, while copying data (B) creates redundancy and violates real-time consistency requirements.

## Pregunta 31

Contexto: [topics:726](#topics-726)
You have an application in production. It is deployed on Compute Engine virtual machine instances controlled by a managed instance group. Traffic is routed to the instances via a HTTP(s) load balancer. Your users are unable to access your application. You want to implement a monitoring technique to alert you when the application is unavailable.
Which technique should you choose?

**A.** Smoke tests

**B.** Stackdriver uptime checks

**C.** Cloud Load Balancing - heath checks

**D.** Managed instance group - heath checks

**Respuesta de la fuente:** B

**Explicación:** Stackdriver (Cloud) uptime checks are specifically designed to monitor the availability of an application endpoint and trigger alerts when it becomes unresponsive. Health checks used by Load Balancers or Managed Instance Groups manage traffic routing and instance lifecycle but do not inherently provide alerting capabilities for user-facing availability.
Reference: Google Cloud Monitoring documentation on Uptime Checks

## Pregunta 32

Contexto: [topics:726](#topics-726)
You are load testing your server application. During the first 30 seconds, you observe that a previously inactive Cloud Storage bucket is now servicing 2000 write requests per second and 7500 read requests per second. Your application is now receiving intermittent 5xx and 429 HTTP responses from the Cloud Storage
JSON API as the demand escalates. You want to decrease the failed responses from the Cloud Storage API.
What should you do?

**A.** Distribute the uploads across a large number of individual storage buckets.

**B.** Use the XML API instead of the JSON API for interfacing with Cloud Storage.

**C.** Pass the HTTP response codes back to clients that are invoking the uploads from your application.

**D.** Limit the upload rate from your application clients so that the dormant bucket's peak request rate is reached more gradually.

**Respuesta de la fuente:** D

**Explicación:** Google Cloud Storage imposes request rate limits on buckets that ramp up gradually from a dormant state to accommodate traffic increases. Sending traffic too quickly triggers throttling errors (429) and server failures (5xx) because the service hasn't scaled enough resources yet.
Limiting the upload rate allows the bucket's throughput capacity to scale organically, preventing these intermittent failures.
Option A is incorrect as distributing uploads across many buckets is an architectural change not required for this scaling issue.

## Pregunta 33

Contexto: [topics:726](#topics-726)
Your application is controlled by a managed instance group. You want to share a large read-only data set between all the instances in the managed instance group. You want to ensure that each instance can start quickly and can access the data set via its filesystem with very low latency. You also want to minimize the total cost of the solution.
What should you do?

**A.** Move the data to a Cloud Storage bucket, and mount the bucket on the filesystem using Cloud Storage FUSE.

**B.** Move the data to a Cloud Storage bucket, and copy the data to the boot disk of the instance via a startup script.

**C.** Move the data to a Compute Engine persistent disk, and attach the disk in read-only mode to multiple Compute Engine virtual machine instances.

**D.** Move the data to a Compute Engine persistent disk, take a snapshot, create multiple disks from the snapshot, and attach each disk to its own instance.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because attaching a single read-only persistent disk to multiple instances satisfies the requirement for very low latency (block storage) while minimizing cost by avoiding data replication or network overhead.

Option A is incorrect because Cloud Storage FUSE introduces higher latency compared to direct block storage access due to network hops and protocol translation.

Option B and D are suboptimal: B incurs startup delays from copying data, and D increases costs significantly by requiring a separate disk for every instance.

## Pregunta 34

Contexto: [topics:726](#topics-726)
You are developing an HTTP API hosted on a Compute Engine virtual machine instance that needs to be invoked by multiple clients within the same Virtual
Private Cloud (VPC). You want clients to be able to get the IP address of the service.
What should you do?

**A.** Reserve a static external IP address and assign it to an HTTP(S) load balancing service's forwarding rule. Clients should use this IP address to connect to the service.

**B.** Reserve a static external IP address and assign it to an HTTP(S) load balancing service's forwarding rule. Then, define an A record in Cloud DNS. Clients should use the name of the A record to connect to the service.

**C.** Ensure that clients use Compute Engine internal DNS by connecting to the instance name with the url https://[INSTANCE_NAME].[ZONE].c. [PROJECT_ID].internal/.

**D.** Ensure that clients use Compute Engine internal DNS by connecting to the instance name with the url https://[API_NAME]/[API_VERSION]/.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google Cloud provides a built-in internal DNS service that automatically resolves Compute Engine instance names to their internal IP addresses within the same VPC. By using the standard internal DNS name format ([INSTANCE_NAME].[ZONE].c.[PROJECT_ID].internal), clients can reliably locate the service without exposing it externally or managing manual IP reservations. Options A and B are incorrect because they involve external IP addresses, which contradicts the requirement for internal-only access within the same VPC.

## Pregunta 35

Contexto: [topics:726](#topics-726)
Your application is logging to Stackdriver. You want to get the count of all requests on all /api/alpha/* endpoints.
What should you do?

**A.** Add a Stackdriver counter metric for path:/api/alpha/.

**B.** Add a Stackdriver counter metric for endpoint:/api/alpha/*.

**C.** Export the logs to Cloud Storage and count lines matching /api/alpha.

**D.** Export the logs to Cloud Pub/Sub and count lines matching /api/alpha.

**Respuesta de la fuente:** A

**Explicación:** Creating a log-based counter metric in Cloud Logging is the most efficient and native way to count specific request patterns without exporting data to external services like Cloud Storage or Pub/Sub.
Between options A and B, option A is the correct exam answer because it correctly identifies the mechanism (a Stackdriver counter metric) and implies using the logging query language filter on the path field, whereas option B uses syntactically imprecise terminology ('endpoint' vs 'path') that may not align with standard Cloud Logging resource label definitions.
Options C and D are incorrect because they involve unnecessary data export steps and manual counting, which violates the principle of using managed service features for monitoring.

## Pregunta 36

Contexto: [topics:726](#topics-726)
You want to re-architect a monolithic application so that it follows a microservices model. You want to accomplish this efficiently while minimizing the impact of this change to the business.
Which approach should you take?

**A.** Deploy the application to Compute Engine and turn on autoscaling.

**B.** Replace the application's features with appropriate microservices in phases.

**C.** Refactor the monolithic application with appropriate microservices in a single effort and deploy it.

**D.** Build a new application with the appropriate microservices separate from the monolith and replace it when it is complete.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it employs the Strangler Fig pattern, which involves incrementally replacing specific functionalities with microservices. This phased approach minimizes business risk and impact by avoiding a massive, disruptive 'big bang' migration.

Option C is incorrect as attempting a complete refactor in a single effort is high-risk, prone to failure, and causes significant downtime or disruption.

## Pregunta 37

Contexto: [topics:726](#topics-726)
Your existing application keeps user state information in a single MySQL database. This state information is very user-specific and depends heavily on how long a user has been using an application. The MySQL database is causing challenges to maintain and enhance the schema for various users.
Which storage option should you choose?

**A.** Cloud SQL

**B.** Cloud Storage

**C.** Cloud Spanner

**D.** Cloud Datastore/Firestore

**Respuesta de la fuente:** D

**Explicación:** The scenario highlights difficulties in maintaining and enhancing a relational schema for highly variable user-specific state, indicating a need for a schemaless or flexible data model. Cloud Datastore/Firestore is a NoSQL database designed specifically for high availability with minimal schema management overhead, making it ideal for dynamic user profiles.
Cloud SQL (Option A) remains a relational database and would not resolve the schema maintenance challenges described in the prompt.

## Pregunta 38

Contexto: [topics:726](#topics-726)
You are building a new API. You want to minimize the cost of storing and reduce the latency of serving images.
Which architecture should you use?

**A.** App Engine backed by Cloud Storage

**B.** Compute Engine backed by Persistent Disk

**C.** Transfer Appliance backed by Cloud Filestore

**D.** Cloud Content Delivery Network (CDN) backed by Cloud Storage

**Respuesta de la fuente:** D

**Explicación:** Cloud Storage is the most cost-effective solution for storing large amounts of static data like images. Pairing it with Cloud CDN caches content at edge locations globally, significantly reducing latency for end-users compared to serving directly from a central storage bucket or compute instance.
Options A and B involve computing resources that add unnecessary cost and potential single-point-of-failure latency, while Option C is designed for offline bulk data transfer, not live serving.

## Pregunta 39

Contexto: [topics:726](#topics-726)
Your company's development teams want to use Cloud Build in their projects to build and push Docker images to Container Registry. The operations team requires all Docker images to be published to a centralized, securely managed Docker registry that the operations team manages.
What should you do?

**A.** Use Container Registry to create a registry in each development team's project. Configure the Cloud Build build to push the Docker image to the project's registry. Grant the operations team access to each development team's registry.

**B.** Create a separate project for the operations team that has Container Registry configured. Assign appropriate permissions to the Cloud Build service account in each developer team's project to allow access to the operation team's registry.

**C.** Create a separate project for the operations team that has Container Registry configured. Create a Service Account for each development team and assign the appropriate permissions to allow it access to the operations team's registry. Store the service account key file in the source code repository and use it to authenticate against the operations team's registry.

**D.** Create a separate project for the operations team that has the open source Docker Registry deployed on a Compute Engine virtual machine instance. Create a username and password for each development team. Store the username and password in the source code repository and use it to authenticate against the operations team's Docker registry.

**Respuesta de la fuente:** B

**Explicación:** Answer B is correct because it leverages Google Cloud's native IAM model by granting the developer project's Cloud Build service account direct write permissions to the centralized Container Registry in the operations project. This ensures secure, centralized management without violating security best practices.

Option C is incorrect and dangerous because storing service account key files directly in source code repositories exposes credentials, whereas Option B uses identity-based access control.

## Pregunta 40

Contexto: [topics:726](#topics-726)
You are planning to deploy your application in a Google Kubernetes Engine (GKE) cluster. Your application can scale horizontally, and each instance of your application needs to have a stable network identity and its own persistent disk.
Which GKE object should you use?

**A.** Deployment

**B.** StatefulSet

**C.** ReplicaSet

**D.** ReplicaController

**Respuesta de la fuente:** B

**Explicación:** StatefulSets are specifically designed for applications that require stable, unique network identifiers and persistent storage volumes for each Pod instance. Unlike Deployments, which treat Pods as interchangeable replicas without guaranteed identity or storage persistence across restarts, StatefulSets ensure ordered deployment and stable storage bindings.
Therefore, B is the correct choice because it directly satisfies the requirements for stable network identity and individual persistent disks.

## Pregunta 41

Contexto: [topics:726](#topics-726)
You are using Cloud Build to build a Docker image. You need to modify the build to execute unit and run integration tests. When there is a failure, you want the build history to clearly display the stage at which the build failed.
What should you do?

**A.** Add RUN commands in the Dockerfile to execute unit and integration tests.

**B.** Create a Cloud Build build config file with a single build step to compile unit and integration tests.

**C.** Create a Cloud Build build config file that will spawn a separate cloud build pipeline for unit and integration tests.

**D.** Create a Cloud Build build config file with separate cloud builder steps to compile and execute unit and integration tests.

**Respuesta de la fuente:** D

**Explicación:** Cloud Build records execution status for each individual step defined in the build configuration file. By creating separate steps for compiling and executing unit and integration tests (Option D), Cloud Build will distinctly log the start, duration, and success/failure of each specific action. This granular logging ensures that if a failure occurs, the build history clearly identifies exactly which step failed.

Option A is incorrect because running tests inside the Dockerfile during image creation does not integrate with Cloud Build's step-level visibility; it only shows the final image build status. Option B combines actions into a single step, obscuring which specific test suite caused a failure. Option C is overly complex and unnecessary for simple test execution within a single pipeline.

## Pregunta 42

Contexto: [topics:726](#topics-726)
Your code is running on Cloud Functions in project A. It is supposed to write an object in a Cloud Storage bucket owned by project B. However, the write call is failing with the error "403 Forbidden".
What should you do to correct the problem?

**A.** Grant your user account the roles/storage.objectCreator role for the Cloud Storage bucket.

**B.** Grant your user account the roles/iam.serviceAccountUser role for the service-PROJECTA@gcf-admin-robot.iam.gserviceaccount.com service account.

**C.** Grant the service-PROJECTA@gcf-admin-robot.iam.gserviceaccount.com service account the roles/storage.objectCreator role for the Cloud Storage bucket.

**D.** Enable the Cloud Storage API in project B.

**Respuesta de la fuente:** C

**Explicación:** Cloud Functions execute using the project's default Compute Engine service account. To allow the function to write to a bucket in Project B, that specific service account must be granted the necessary IAM permissions (roles/storage.objectCreator) on the destination resource.
Granting permissions to a human user (Options A and B) is incorrect because the code runs under the service account identity, not the user's personal credentials.

## Pregunta 43

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
HipLocal's .net-based auth service fails under intermittent load.
What should they do?

**A.** Use App Engine for autoscaling.

**B.** Use Cloud Functions for autoscaling.

**C.** Use a Compute Engine cluster for the service.

**D.** Use a dedicated Compute Engine virtual machine instance for the service.

**Respuesta de la fuente:** A

**Explicación:** App Engine is the correct choice because it provides built-in automatic scaling for web applications and supports .NET via the Flexible Environment, directly addressing the intermittent load issue.
Cloud Functions (B) is less suitable as it is designed for event-driven, short-lived executions rather than maintaining stateful or long-running authentication services.
Compute Engine options (C and D) require manual configuration of scaling policies or lack automatic scaling capabilities natively compared to App Engine.

## Pregunta 44

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
HipLocal's APIs are having occasional application failures. They want to collect application information specifically to troubleshoot the issue. What should they do?

**A.** Take frequent snapshots of the virtual machines.

**B.** Install the Cloud Logging agent on the virtual machines.

**C.** Install the Cloud Monitoring agent on the virtual machines.

**D.** Use Cloud Trace to look for performance bottlenecks.

**Respuesta de la fuente:** B

**Explicación:** Cloud Logging is the primary service for collecting and analyzing application logs, which contain the detailed error messages and stack traces necessary to troubleshoot specific application failures.
Installating the Cloud Logging agent on VMs ensures these logs are aggregated centrally for diagnosis.

## Pregunta 45

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
HipLocal has connected their Hadoop infrastructure to GCP using Cloud Interconnect in order to query data stored on persistent disks.
Which IP strategy should they use?

**A.** Create manual subnets.

**B.** Create an auto mode subnet.

**C.** Create multiple peered VPCs.

**D.** Provision a single instance for NAT.

**Respuesta de la fuente:** A

**Explicación:** Manual subnets are required for Cloud Interconnect to ensure precise control over IP address ranges, preventing conflicts with on-premises Hadoop infrastructure CIDRs. Auto mode subnets automatically assign secondary IPs that may overlap with local networks, breaking hybrid connectivity.

## Pregunta 46

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
Which service should HipLocal use to enable access to internal apps?

**A.** Cloud VPN

**B.** Cloud Armor

**C.** Virtual Private Cloud

**D.** Cloud Identity-Aware Proxy

**Respuesta de la fuente:** D

**Explicación:** Cloud Identity-Aware Proxy (IAP) is the correct choice because it provides secure, identity-based access to web applications without requiring a traditional VPN tunnel, aligning with zero-trust principles by verifying user identity and context before granting application-level access.

While Cloud VPN (Option A) establishes network connectivity, it does not inherently provide the granular, application-level access control or identity verification that IAP offers for internal apps.

## Pregunta 47

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
HipLocal wants to reduce the number of on-call engineers and eliminate manual scaling.
Which two services should they choose? (Choose two.)

**A.** Use Google App Engine services.

**B.** Use serverless Google Cloud Functions.

**C.** Use Knative to build and deploy serverless applications.

**D.** Use Google Kubernetes Engine for automated deployments.

**E.** Use a large Google Compute Engine cluster for deployments.

**Respuesta de la fuente:** C, D

**Explicación:** Google Kubernetes Engine (GKE) with Horizontal Pod Autoscaling and Knative provide the necessary serverless, auto-scaling capabilities to eliminate manual scaling and reduce on-call burden. Specifically, GKE handles infrastructure management while Knative offers event-driven, zero-idle scaling for containers, meeting both requirements effectively.

Google App Engine and Cloud Functions (Options A and B) are single-region services by default in this context or less suitable for the specific container-based workload described in HipLocal's case study, whereas GKE supports multi-cluster global deployments more flexibly.

## Pregunta 48

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
In order to meet their business requirements, how should HipLocal store their application state?

**A.** Use local SSDs to store state.

**B.** Put a memcache layer in front of MySQL.

**C.** Move the state storage to Cloud Spanner.

**D.** Replace the MySQL instance with Cloud SQL.

**Respuesta de la fuente:** C

**Explicación:** HipLocal requires a globally distributed solution to reduce latency for users traveling across regions and ensure consistent access regardless of location. Cloud Spanner is the only option that provides global distribution with strong consistency and low-latency reads/writes worldwide.
Cloud SQL (D) remains regionally constrained, which fails the multi-region availability requirement, while Memcache (B) does not solve persistent storage distribution.

## Pregunta 49

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
Which service should HipLocal use for their public APIs?

**A.** Cloud Armor

**B.** Cloud Functions

**C.** Cloud Endpoints

**D.** Shielded Virtual Machines

**Respuesta de la fuente:** C

**Explicación:** Cloud Endpoints is the correct choice because it is Google Cloud's dedicated API management system, providing essential features such as authentication, logging, monitoring, and quota management for public APIs.
While Cloud Armor (A) provides DDoS protection and WAF capabilities, it does not handle API lifecycle management or logic execution, making it insufficient as a standalone solution for serving APIs.

## Pregunta 50

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
HipLocal wants to improve the resilience of their MySQL deployment, while also meeting their business and technical requirements.
Which configuration should they choose?

**A.** Use the current single instance MySQL on Compute Engine and several read-only MySQL servers on Compute Engine.

**B.** Use the current single instance MySQL on Compute Engine, and replicate the data to Cloud SQL in an external master configuration.

**C.** Replace the current single instance MySQL instance with Cloud SQL, and configure high availability.

**D.** Replace the current single instance MySQL instance with Cloud SQL, and Google provides redundancy without further configuration.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because moving to Cloud SQL provides a managed environment, and explicitly enabling the High Availability (HA) configuration creates an automatic failover replica in a different zone within the same region, directly addressing the requirement for improved resilience. Option D is incorrect because standard Cloud SQL single-instance deployments do not provide automatic redundancy or failover; HA features must be intentionally configured during instance creation to ensure business continuity.

## Pregunta 51

Contexto: [topics:726](#topics-726)
Your application is running in multiple Google Kubernetes Engine clusters. It is managed by a Deployment in each cluster. The Deployment has created multiple replicas of your Pod in each cluster. You want to view the logs sent to stdout for all of the replicas in your Deployment in all clusters.
Which command should you use?

**A.** kubectl logs [PARAM]

**B.** gcloud logging read [PARAM]

**C.** kubectl exec —it [PARAM] journalctl

**D.** gcloud compute ssh [PARAM] —-command= "sudo journalctl"

**Respuesta de la fuente:** B

**Explicación:** In Google Kubernetes Engine, standard output (stdout) from containers is automatically collected and stored in Cloud Logging.
While 'kubectl logs' retrieves logs for a single cluster context, 'gcloud logging read' queries the centralized logging backend, allowing you to filter and view logs across all clusters simultaneously using filters like resource.type="k8s_container". This makes B the only option capable of aggregating data from multiple clusters in one command.

## Pregunta 52

Contexto: [topics:726](#topics-726)
You are using Cloud Build to create a new Docker image on each source code commit to a Cloud Source Repositories repository. Your application is built on every commit to the master branch. You want to release specific commits made to the master branch in an automated method.
What should you do?

**A.** Manually trigger the build for new releases.

**B.** Create a build trigger on a Git tag pattern. Use a Git tag convention for new releases.

**C.** Create a build trigger on a Git branch name pattern. Use a Git branch naming convention for new releases.

**D.** Commit your source code to a second Cloud Source Repositories repository with a second Cloud Build trigger. Use this repository for new releases only.

**Respuesta de la fuente:** B

**Explicación:** The goal is to automate releases for specific commits on the master branch without triggering them on every push. Git tags are the standard mechanism to mark specific points in history (like versions) as release candidates, allowing Cloud Build triggers to fire only when a tag matching a pattern is pushed.
Option C is incorrect because creating new branches for every release creates unnecessary repository clutter and complicates history management compared to the immutable nature of tags for versioning.

## Pregunta 53

Contexto: [topics:726](#topics-726)
You are designing a schema for a table that will be moved from MySQL to Cloud Bigtable. The MySQL table is as follows:
[Imagen: sin descripción]
How should you design a row key for Cloud Bigtable for this table?
Imagen · question_text · sin descripción
![Imagen original](imagenes/6771989108335f15cffc.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
AccountActivity
(
Account_id int,
Event_timestamp datetime,
Transaction_type string,
Amount numeric(18, 4)
) primary key (Account_id,
Event_timectam)
```

**A.** Set Account_id as a key.

**B.** Set Account_id_Event_timestamp as a key.

**C.** Set Event_timestamp_Account_id as a key.

**D.** Set Event_timestamp as a key.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Cloud Bigtable row keys should start with a high-cardinality value (like Account_id) to ensure data is distributed evenly across nodes. Placing the timestamp second allows for efficient range scans within an account while preventing write hotspots that occur when sequential timestamps are at the beginning of the key (as in Option C).

Option C is incorrect because starting the row key with a timestamp causes all new writes to hit the same node, creating a severe performance bottleneck known as hotspotting.

## Pregunta 54

Contexto: [topics:726](#topics-726)
You want to view the memory usage of your application deployed on Compute Engine.
What should you do?

**A.** Install the Stackdriver Client Library.

**B.** Install the Stackdriver Monitoring Agent.

**C.** Use the Stackdriver Metrics Explorer.

**D.** Use the Google Cloud Platform Console.

**Respuesta de la fuente:** B

**Explicación:** To view specific memory usage metrics for a Compute Engine instance, you must install the Stackdriver Monitoring Agent (Option B) because detailed OS-level metrics like memory are not collected by default.
Option A is incorrect as the client library is for application-specific metrics, not system resource monitoring.
Option C and D are insufficient on their own because without the agent installed to generate the data, there will be no memory metrics available in the console or explorer.

## Pregunta 55

Contexto: [topics:726](#topics-726)
You have an analytics application that runs hundreds of queries on BigQuery every few minutes using BigQuery API. You want to find out how much time these queries take to execute.
What should you do?

**A.** Use Stackdriver Monitoring to plot slot usage.

**B.** Use Stackdriver Trace to plot API execution time.

**C.** Use Stackdriver Trace to plot query execution time.

**D.** Use Stackdriver Monitoring to plot query execution times.

**Respuesta de la fuente:** D

**Explicación:** Stackdriver Monitoring (Cloud Monitoring) is the correct tool for aggregating and plotting metric data like query execution times over time.
BigQuery exposes specific metrics, such as `query_execution_times`, which can be visualized in custom dashboards to track performance trends without needing distributed tracing.
Options A, B, and C are incorrect because slot usage measures resource consumption rather than duration, and Trace is designed for debugging individual request paths rather than plotting aggregate time-series metrics.

## Pregunta 56

Contexto: [topics:726](#topics-726)
You are designing a schema for a Cloud Spanner customer database. You want to store a phone number array field in a customer table. You also want to allow users to search customers by phone number.
How should you design this schema?

**A.** Create a table named Customers. Add an Array field in a table that will hold phone numbers for the customer.

**B.** Create a table named Customers. Create a table named Phones. Add a CustomerId field in the Phones table to find the CustomerId from a phone number.

**C.** Create a table named Customers. Add an Array field in a table that will hold phone numbers for the customer. Create a secondary index on the Array field.

**D.** Create a table named Customers as a parent table. Create a table named Phones, and interleave this table into the Customer table. Create an index on the phone number field in the Phones table.

**Respuesta de la fuente:** D

**Explicación:** Cloud Spanner does not support creating secondary indexes on ARRAY columns, which makes option C invalid.
Option D is correct because it uses an interleaved table (Phones) to normalize the one-to-many relationship between customers and phone numbers, allowing a standard secondary index on the phone number field for efficient searching.

## Pregunta 57

Contexto: [topics:726](#topics-726)
You are deploying a single website on App Engine that needs to be accessible via the URL http://www.altostrat.com/.
What should you do?

**A.** Verify domain ownership with Webmaster Central. Create a DNS CNAME record to point to the App Engine canonical name ghs.googlehosted.com.

**B.** Verify domain ownership with Webmaster Central. Define an A record pointing to the single global App Engine IP address.

**C.** Define a mapping in dispatch.yaml to point the domain www.altostrat.com to your App Engine service. Create a DNS CNAME record to point to the App Engine canonical name ghs.googlehosted.com.

**D.** Define a mapping in dispatch.yaml to point the domain www.altostrat.com to your App Engine service. Define an A record pointing to the single global App Engine IP address.

**Respuesta de la fuente:** A

**Explicación:** To map a custom domain to App Engine Standard Environment (the implied context for this classic exam pattern), you must verify domain ownership using Google Search Console (formerly Webmaster Central) and configure a CNAME record pointing www.altostrat.com to ghs.googlehosted.com. App Engine does not use a single static global IP address, making A records (Options B and D) technically incorrect for standard configurations. While dispatch.yaml (Options C and D) is used for routing traffic between multiple services within an application, it is unnecessary for deploying a single website where the default service handles all traffic.

## Pregunta 58

Contexto: [topics:726](#topics-726)
You are running an application on App Engine that you inherited. You want to find out whether the application is using insecure binaries or is vulnerable to XSS attacks.
Which service should you use?

**A.** Cloud Amor

**B.** Stackdriver Debugger

**C.** Cloud Security Scanner

**D.** Stackdriver Error Reporting

**Respuesta de la fuente:** C

**Explicación:** Cloud Security Scanner (formerly Web Security Scanner) is the dedicated service designed to crawl App Engine applications and detect specific web vulnerabilities such as cross-site scripting (XSS), outdated libraries, and mixed content. While Stackdriver tools handle runtime debugging or error logging, they do not perform automated security scans for these types of application-layer vulnerabilities.

## Pregunta 59

Contexto: [topics:726](#topics-726)
You are working on a social media application. You plan to add a feature that allows users to upload images. These images will be 2 MB `" 1 GB in size. You want to minimize their infrastructure operations overhead for this feature.
What should you do?

**A.** Change the application to accept images directly and store them in the database that stores other user information.

**B.** Change the application to create signed URLs for Cloud Storage. Transfer these signed URLs to the client application to upload images to Cloud Storage.

**C.** Set up a web server on GCP to accept user images and create a file store to keep uploaded files. Change the application to retrieve images from the file store.

**D.** Create a separate bucket for each user in Cloud Storage. Assign a separate service account to allow write access on each bucket. Transfer service account credentials to the client application based on user information. The application uses this service account to upload images to Cloud Storage.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because using signed URLs for Cloud Storage allows clients to upload directly to object storage without proxying data through your application servers, significantly reducing infrastructure overhead and operational complexity.

Option A is incorrect because storing binary objects in relational databases degrades performance and increases database size unnecessarily. Option D is wrong due to severe security risks (exposing service account credentials) and excessive operational overhead in managing individual buckets and accounts.

## Pregunta 60

Contexto: [topics:726](#topics-726)
Your application is built as a custom machine image. You have multiple unique deployments of the machine image. Each deployment is a separate managed instance group with its own template. Each deployment requires a unique set of configuration values. You want to provide these unique values to each deployment but use the same custom machine image in all deployments. You want to use out-of-the-box features of Compute Engine.
What should you do?

**A.** Place the unique configuration values in the persistent disk.

**B.** Place the unique configuration values in a Cloud Bigtable table.

**C.** Place the unique configuration values in the instance template startup script.

**D.** Place the unique configuration values in the instance template instance metadata.

**Respuesta de la fuente:** D

**Explicación:** Instance metadata allows you to provide unique configuration data to each VM instance at creation time without modifying the underlying custom machine image. This aligns with the requirement to use out-of-the-box Compute Engine features while keeping deployments separate and configurable via their specific instance templates.
Option C (startup script) is less ideal because embedding unique config directly in the script often requires generating a new template for every small change, whereas metadata provides a cleaner separation of configuration from code/image.

## Pregunta 61

Contexto: [topics:726](#topics-726)
Your application performs well when tested locally, but it runs significantly slower after you deploy it to a Compute Engine instance. You need to diagnose the problem. What should you do?
What should you do?

**A.** File a ticket with Cloud Support indicating that the application performs faster locally.

**B.** Use Cloud Debugger snapshots to look at a point-in-time execution of the application.

**C.** Use Cloud Profiler to determine which functions within the application take the longest amount of time.

**D.** Add logging commands to the application and use Cloud Logging to check where the latency problem occurs.

**Respuesta de la fuente:** C

**Explicación:** Cloud Profiler is the correct choice because it continuously samples CPU and memory usage to identify specific functions causing latency bottlenecks without requiring code changes.
Option D is a tempting alternative but is less optimal because adding logging requires manual instrumentation, which is more labor-intensive and can introduce overhead compared to the automated analysis provided by Cloud Profiler.

## Pregunta 62

Contexto: [topics:726](#topics-726)
You have an application running in App Engine. Your application is instrumented with Stackdriver Trace. The /product-details request reports details about four known unique products at /sku-details as shown below. You want to reduce the time it takes for the request to complete.
What should you do?
[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/58ea53546c82be695ae7.jpg)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Timeline
0 0 100 10
(kage (20.059 ms)
(Pekisdtais (22.124 ms)
(PBs 29.329 m=)
(RR 0 (20-287 ms)
```

**A.** Increase the size of the instance class.

**B.** Change the Persistent Disk type to SSD.

**C.** Change /product-details to perform the requests in parallel.

**D.** Store the /sku-details information in a database, and replace the webservice call with a database query.

**Respuesta de la fuente:** C

**Explicación:** The trace indicates that /product-details makes four sequential calls to /sku-details, creating a linear latency bottleneck. By converting these sequential requests into parallel execution, the total response time is reduced to roughly the duration of the slowest single call rather than the sum of all four.
Option A (increasing instance size) and Option B (changing disk type) address compute or storage bottlenecks, which are not identified by the trace as the cause of latency.

## Pregunta 63

Contexto: [topics:726](#topics-726)
Your company has a data warehouse that keeps your application information in BigQuery. The BigQuery data warehouse keeps 2 PBs of user data. Recently, your company expanded your user base to include EU users and needs to comply with these requirements:
✑ Your company must be able to delete all user account information upon user request.
✑ All EU user data must be stored in a single region specifically for EU users.
Which two actions should you take? (Choose two.)

**A.** Use BigQuery federated queries to query data from Cloud Storage.

**B.** Create a dataset in the EU region that will keep information about EU users only.

**C.** Create a Cloud Storage bucket in the EU region to store information for EU users only.

**D.** Re-upload your data using to a Cloud Dataflow pipeline by filtering your user records out.

**E.** Use DML statements in BigQuery to update/delete user records based on their requests.

**Respuesta de la fuente:** B, E

**Explicación:** Option B correctly isolates EU user data by creating a specific dataset in an EU region, satisfying the residency requirement without migrating to a different service like Cloud Storage.
Option E fulfills the deletion requirement efficiently using BigQuery DML statements, which support direct row-level deletes for GDPR compliance within the existing data warehouse.

## Pregunta 64

Contexto: [topics:726](#topics-726)
Your App Engine standard configuration is as follows:
service: production
instance_class: B1
You want to limit the application to 5 instances.
Which code snippet should you include in your configuration?

**A.** manual_scaling: instances: 5 min_pending_latency: 30ms

**B.** manual_scaling: max_instances: 5 idle_timeout: 10m

**C.** basic_scaling: instances: 5 min_pending_latency: 30ms

**D.** basic_scaling: max_instances: 5 idle_timeout: 10m

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because `basic_scaling` supports the `max_instances` parameter to cap instance usage while allowing idle instances to shut down via `idle_timeout`. Option B is incorrect because `manual_scaling` only accepts a fixed `instances` count and does not support a `max_instances` limit.

## Pregunta 65

Contexto: [topics:726](#topics-726)
Your analytics system executes queries against a BigQuery dataset. The SQL query is executed in batch and passes the contents of a SQL file to the BigQuery
CLI. Then it redirects the BigQuery CLI output to another process. However, you are getting a permission error from the BigQuery CLI when the queries are executed.
You want to resolve the issue. What should you do?

**A.** Grant the service account BigQuery Data Viewer and BigQuery Job User roles.

**B.** Grant the service account BigQuery Data Editor and BigQuery Data Viewer roles.

**C.** Create a view in BigQuery from the SQL query and SELECT* from the view in the CLI.

**D.** Create a new dataset in BigQuery, and copy the source table to the new dataset Query the new dataset and table from the CLI.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it adheres to the principle of least privilege: BigQuery Data Viewer allows reading data, and BigQuery Job User permits executing queries without unnecessary write permissions. Option B is incorrect because BigQuery Data Editor grants write/modify capabilities, which are excessive for a read-only query execution task.

## Pregunta 66

Contexto: [topics:726](#topics-726)
Your application is running on Compute Engine and is showing sustained failures for a small number of requests. You have narrowed the cause down to a single
Compute Engine instance, but the instance is unresponsive to SSH.
What should you do next?

**A.** Reboot the machine.

**B.** Enable and check the serial port output.

**C.** Delete the machine and create a new one.

**D.** Take a snapshot of the disk and attach it to a new machine.

**Respuesta de la fuente:** B

**Explicación:** When an instance is unresponsive to SSH, the serial console provides a direct view of system boot logs and kernel messages, allowing you to diagnose whether the issue is OS-level, network-related, or application-specific without disrupting service. Rebooting (Option A) is premature because it destroys volatile diagnostic context and may not resolve persistent configuration errors, while deleting (Option C) or detaching disks (Option D) are invasive measures reserved for when the VM hardware itself is suspected of failure after initial troubleshooting fails.

## Pregunta 67

Contexto: [topics:726](#topics-726)
You configured your Compute Engine instance group to scale automatically according to overall CPU usage. However, your application's response latency increases sharply before the cluster has finished adding up instances. You want to provide a more consistent latency experience for your end users by changing the configuration of the instance group autoscaler.
Which two configuration changes should you make? (Choose two.)

**A.** Add the label "AUTOSCALE" to the instance group template.

**B.** Decrease the cool-down period for instances added to the group.

**C.** Increase the target CPU usage for the instance group autoscaler.

**D.** Decrease the target CPU usage for the instance group autoscaler.

**E.** Remove the health-check for individual VMs in the instance group.

**Respuesta de la fuente:** B, D

**Explicación:** Decreasing the target CPU usage (D) triggers scaling at lower utilization levels, adding capacity before latency spikes occur. Decreasing the cool-down period (B) reduces the wait time between scaling events, allowing new instances to be added more rapidly in response to sudden load increases. Increasing the target CPU usage (C) is incorrect because it delays scaling until higher utilization, worsening the latency issue.

## Pregunta 68

Contexto: [topics:726](#topics-726)
You have an application controlled by a managed instance group. When you deploy a new version of the application, costs should be minimized and the number of instances should not increase. You want to ensure that, when each new instance is created, the deployment only continues if the new instance is healthy.
What should you do?

**A.** Perform a rolling-action with maxSurge set to 1, maxUnavailable set to 0.

**B.** Perform a rolling-action with maxSurge set to 0, maxUnavailable set to 1

**C.** Perform a rolling-action with maxHealthy set to 1, maxUnhealthy set to 0.

**D.** Perform a rolling-action with maxHealthy set to 0, maxUnhealthy set to 1.

**Respuesta de la fuente:** B

**Explicación:** The requirement states that the number of instances should not increase, which mandates setting maxSurge to 0. To minimize costs and ensure continuity, you must terminate one instance at a time before creating its replacement, requiring maxUnavailable set to 1.

Option A is incorrect because setting maxSurge to 1 would create an extra instance, violating the constraint that instance count must not increase.

## Pregunta 69

Contexto: [topics:726](#topics-726)
Your application requires service accounts to be authenticated to GCP products via credentials stored on its host Compute Engine virtual machine instances. You want to distribute these credentials to the host instances as securely as possible.
What should you do?

**A.** Use HTTP signed URLs to securely provide access to the required resources.

**B.** Use the instance's service account Application Default Credentials to authenticate to the required resources.

**C.** Generate a P12 file from the GCP Console after the instance is deployed, and copy the credentials to the host instance before starting the application.

**D.** Commit the credential JSON file into your application's source repository, and have your CI/CD process package it with the software that is deployed to the instance.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Application Default Credentials (ADC) allow the Compute Engine instance to authenticate using its attached service account via the metadata server, eliminating the need to store or transmit static credential files. This avoids the security risks associated with committing credentials to source control (D), manually copying key files (C), or using signed URLs which are for temporary object access rather than identity authentication (A).

## Pregunta 70

Contexto: [topics:726](#topics-726)
Your application is deployed in a Google Kubernetes Engine (GKE) cluster. You want to expose this application publicly behind a Cloud Load Balancing HTTP(S) load balancer.
What should you do?

**A.** Configure a GKE Ingress resource.

**B.** Configure a GKE Service resource.

**C.** Configure a GKE Ingress resource with type: LoadBalancer.

**D.** Configure a GKE Service resource with type: LoadBalancer.

**Respuesta de la fuente:** A

**Explicación:** To expose an application behind a Cloud Load Balancing HTTP(S) load balancer in GKE, you must configure a Kubernetes Ingress resource. The Ingress controller monitors these resources and provisions the corresponding L7 HTTP(S) load balancer on Google Cloud, handling SSL termination and host/path-based routing.

Option D is incorrect because a Service with type: LoadBalancer creates an L4 TCP/UDP proxy (unless specifically configured otherwise via annotations), whereas an Ingress resource explicitly defines the rules required for an HTTP(S) L7 load balancer.

## Pregunta 71

Contexto: [topics:726](#topics-726)
Your company is planning to migrate their on-premises Hadoop environment to the cloud. Increasing storage cost and maintenance of data stored in HDFS is a major concern for your company. You also want to make minimal changes to existing data analytics jobs and existing architecture.
How should you proceed with the migration?

**A.** Migrate your data stored in Hadoop to BigQuery. Change your jobs to source their information from BigQuery instead of the on-premises Hadoop environment.

**B.** Create Compute Engine instances with HDD instead of SSD to save costs. Then perform a full migration of your existing environment into the new one in Compute Engine instances.

**C.** Create a Cloud Dataproc cluster on Google Cloud Platform, and then migrate your Hadoop environment to the new Cloud Dataproc cluster. Move your HDFS data into larger HDD disks to save on storage costs.

**D.** Create a Cloud Dataproc cluster on Google Cloud Platform, and then migrate your Hadoop code objects to the new cluster. Move your data to Cloud Storage and leverage the Cloud Dataproc connector to run jobs on that data.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it separates storage from compute, using Cloud Storage for cost-effective data persistence and Cloud Dataproc for managed Hadoop processing. This architecture minimizes changes to existing jobs via the Cloud Dataproc connector while significantly reducing costs compared to maintaining persistent HDFS clusters.

Option C is incorrect because keeping data in HDFS on Dataproc is more expensive and less flexible than using Cloud Storage, which decouples storage costs from compute instance lifecycles.

## Pregunta 72

Contexto: [topics:726](#topics-726)
Your data is stored in Cloud Storage buckets. Fellow developers have reported that data downloaded from Cloud Storage is resulting in slow API performance.
You want to research the issue to provide details to the GCP support team.
Which command should you run?

**A.** gsutil test —o output.json gs://my-bucket

**B.** gsutil perfdiag —o output.json gs://my-bucket

**C.** gcloud compute scp example-instance:~/test-data —o output.json gs://my-bucket

**D.** gcloud services test —o output.json gs://my-bucket

**Respuesta de la fuente:** B

**Explicación:** The `gsutil perfdiag` command is specifically designed to run a suite of diagnostic tests on Cloud Storage buckets, capturing performance metrics like latency and throughput that are essential for troubleshooting slow API responses.
Unlike the other options, it is the only valid tool provided by Google for generating detailed performance diagnostics compatible with GCP support analysis.

## Pregunta 73

Contexto: [topics:726](#topics-726)
You are using Cloud Build build to promote a Docker image to Development, Test, and Production environments. You need to ensure that the same Docker image is deployed to each of these environments.
How should you identify the Docker image in your build?

**A.** Use the latest Docker image tag.

**B.** Use a unique Docker image name.

**C.** Use the digest of the Docker image.

**D.** Use a semantic version Docker image tag.

**Respuesta de la fuente:** C

**Explicación:** Docker image digests are cryptographic hashes that uniquely and immutably identify a specific image manifest.
While semantic version tags (Option D) follow naming conventions, they are mutable labels that can be retagged to point to different image content, potentially causing environment drift.
Using the digest guarantees that the exact same binary artifact is deployed across Development, Test, and Production.

## Pregunta 74

Contexto: [topics:726](#topics-726)
Your company has created an application that uploads a report to a Cloud Storage bucket. When the report is uploaded to the bucket, you want to publish a message to a Cloud Pub/Sub topic. You want to implement a solution that will take a small amount to effort to implement.
What should you do?

**A.** Configure the Cloud Storage bucket to trigger Cloud Pub/Sub notifications when objects are modified.

**B.** Create an App Engine application to receive the file; when it is received, publish a message to the Cloud Pub/Sub topic.

**C.** Create a Cloud Function that is triggered by the Cloud Storage bucket. In the Cloud Function, publish a message to the Cloud Pub/Sub topic.

**D.** Create an application deployed in a Google Kubernetes Engine cluster to receive the file; when it is received, publish a message to the Cloud Pub/Sub topic.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Cloud Storage natively supports publishing notifications directly to a Cloud Pub/Sub topic via configuration (e.g., gcloud command or console), requiring zero custom code and minimal setup effort.
Options B, C, and D are incorrect because they involve deploying additional compute resources (App Engine, Cloud Functions, or GKE) and writing/maintaining application logic, which contradicts the requirement for the smallest amount of implementation effort.

## Pregunta 75

Contexto: [topics:726](#topics-726)
Your teammate has asked you to review the code below, which is adding a credit to an account balance in Cloud Datastore.
Which improvement should you suggest your teammate make?
[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/8b1b08bdbf9c61a53145.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
public Entity creditAccount (long accountId, long
creditamount) {
Entity account = datastore.get
(keyFactory.newKey (accountId));
account = Entity.builder (account) .set (
“balance”, account .getLong (“balance”)
+ creditAmount) .build()
datastore.put (account) ;
return account;
```

**A.** Get the entity with an ancestor query.

**B.** Get and put the entity in a transaction.

**C.** Use a strongly consistent transactional database.

**D.** Don't return the account entity from the function.

**Respuesta de la fuente:** B

**Explicación:** The code performs a read-modify-write operation on a mutable value (account balance), which creates a race condition if two users update the balance simultaneously.
Executing the get and put operations within a transaction ensures atomicity, preventing lost updates by forcing the system to retry or serialize conflicting changes.
Option A is incorrect because an ancestor query only ensures strong consistency for reading but does not guarantee the integrity of the subsequent write operation against concurrent modifications.

## Pregunta 76

Contexto: [topics:726](#topics-726)
Your company stores their source code in a Cloud Source Repositories repository. Your company wants to build and test their code on each source code commit to the repository and requires a solution that is managed and has minimal operations overhead.
Which method should they use?

**A.** Use Cloud Build with a trigger configured for each source code commit.

**B.** Use Jenkins deployed via the Google Cloud Platform Marketplace, configured to watch for source code commits.

**C.** Use a Compute Engine virtual machine instance with an open source continuous integration tool, configured to watch for source code commits.

**D.** Use a source code commit trigger to push a message to a Cloud Pub/Sub topic that triggers an App Engine service to build the source code.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Build is the fully managed Continuous Integration (CI) service specifically designed to integrate with Cloud Source Repositories via triggers. This directly satisfies the requirement for a 'managed' solution that initiates builds and tests on every commit.

Options B and C involve deploying and managing Jenkins or other open-source tools, which introduces significant operational overhead contradicting the prompt's constraints. Option D creates an overly complex and unnecessary architecture by routing through Pub/Sub and App Engine when Cloud Build provides native, direct trigger support.

## Pregunta 77

Contexto: [topics:726](#topics-726)
You are writing a Compute Engine hosted application in project A that needs to securely authenticate to a Cloud Pub/Sub topic in project B.
What should you do?

**A.** Configure the instances with a service account owned by project B. Add the service account as a Cloud Pub/Sub publisher to project A.

**B.** Configure the instances with a service account owned by project A. Add the service account as a publisher on the topic.

**C.** Configure Application Default Credentials to use the private key of a service account owned by project B. Add the service account as a Cloud Pub/Sub publisher to project A.

**D.** Configure Application Default Credentials to use the private key of a service account owned by project A. Add the service account as a publisher on the topic

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because the best practice for cross-project access in GCP is to use a service account from the source project (Project A) and grant it the necessary IAM roles (Publisher) on the target resource in Project B. This avoids sharing private keys or managing credentials externally, leveraging the instance's attached service account identity securely.

Option D is incorrect because using Application Default Credentials with an explicit private key file is not the standard secure configuration for Compute Engine instances, which should instead use the automatically provided metadata server credentials associated with their attached service account.

## Pregunta 78

Contexto: [topics:726](#topics-726)
You are developing a corporate tool on Compute Engine for the finance department, which needs to authenticate users and verify that they are in the finance department. All company employees use G Suite.
What should you do?

**A.** Enable Cloud Identity-Aware Proxy on the HTTP(s) load balancer and restrict access to a Google Group containing users in the finance department. Verify the provided JSON Web Token within the application.

**B.** Enable Cloud Identity-Aware Proxy on the HTTP(s) load balancer and restrict access to a Google Group containing users in the finance department. Issue client-side certificates to everybody in the finance team and verify the certificates in the application.

**C.** Configure Cloud Armor Security Policies to restrict access to only corporate IP address ranges. Verify the provided JSON Web Token within the application.

**D.** Configure Cloud Armor Security Policies to restrict access to only corporate IP address ranges. Issue client side certificates to everybody in the finance team and verify the certificates in the application.

**Respuesta de la fuente:** A

**Explicación:** Cloud Identity-Aware Proxy (IAP) is designed specifically for user-based authentication and authorization using Google Cloud Identity or G Suite accounts, allowing you to restrict access by Google Groups. IAP sends a verified JWT in the HTTP request headers, which the application validates to confirm the user's identity and group membership.

Options C and D are incorrect because Cloud Armor is a Web Application Firewall (WAF) focused on Layer 7 filtering and IP-based restrictions; it cannot authenticate individual G Suite users or enforce Google Group policies.

## Pregunta 79

Contexto: [topics:726](#topics-726)
Your API backend is running on multiple cloud providers. You want to generate reports for the network latency of your API.
Which two steps should you take? (Choose two.)

**A.** Use Zipkin collector to gather data.

**B.** Use Fluentd agent to gather data.

**C.** Use Stackdriver Trace to generate reports.

**D.** Use Stackdriver Debugger to generate report.

**E.** Use Stackdriver Profiler to generate report.

**Respuesta de la fuente:** A, C

**Explicación:** Zipkin is the standard distributed tracing tool used to gather latency data across heterogeneous environments, including multiple cloud providers, ensuring comprehensive data collection regardless of infrastructure origin.
Stackdriver Trace (now Cloud Trace) is the specific GCP service designed to analyze and report on trace data, allowing you to visualize network latency bottlenecks and generate performance reports.
Fluentd (B) is primarily for log aggregation rather than distributed tracing, while Debugger (D) and Profiler (E) focus on code-level state inspection and resource usage, not network latency reporting.

## Pregunta 80

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
Which database should HipLocal use for storing user activity?

**A.** BigQuery

**B.** Cloud SQL

**C.** Cloud Spanner

**D.** Cloud Datastore

**Respuesta de la fuente:** A

**Explicación:** BigQuery is the correct choice because the HipLocal case study explicitly states the need to 'obtain user activity metrics' to analyze usage patterns, which aligns with BigQuery's purpose as a serverless, highly scalable data warehouse for analytics.

Cloud Datastore (or Firestore) is designed for operational NoSQL workloads like user profiles and session state, not for large-scale analytical queries on activity logs.

## Pregunta 81

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
HipLocal is configuring their access controls.
Which firewall configuration should they implement?

**A.** Block all traffic on port 443.

**B.** Allow all traffic into the network.

**C.** Allow traffic on port 443 for a specific tag.

**D.** Allow all traffic on port 443 into the network.

**Respuesta de la fuente:** C

**Explicación:** Option C is the best practice because it applies the principle of least privilege by restricting inbound HTTPS (port 443) traffic only to instances explicitly designated with a specific network tag, such as web servers.
In contrast, Option D is incorrect because allowing all traffic on port 443 to every instance in the network unnecessarily expands the attack surface, exposing non-web VMs to potential exploits.

## Pregunta 82

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
HipLocal's data science team wants to analyze user reviews.
How should they prepare the data?

**A.** Use the Cloud Data Loss Prevention API for redaction of the review dataset.

**B.** Use the Cloud Data Loss Prevention API for de-identification of the review dataset.

**C.** Use the Cloud Natural Language Processing API for redaction of the review dataset.

**D.** Use the Cloud Natural Language Processing API for de-identification of the review dataset.

**Respuesta de la fuente:** B

**Explicación:** The Cloud Data Loss Prevention (DLP) API is the correct service for de-identification tasks, as it specifically detects and transforms personally identifiable information (PII) within text datasets using methods like redaction, masking, or tokenization.
Option A is less optimal because 'redaction' is merely one technique of de-identification, whereas 'de-identification' is the broader objective required for privacy compliance before analysis.
Options C and D are incorrect because the Cloud Natural Language API focuses on linguistic analysis (e.g., sentiment, entity extraction) rather than data protection or privacy enforcement.

## Pregunta 83

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
In order for HipLocal to store application state and meet their stated business requirements, which database service should they migrate to?

**A.** Cloud Spanner

**B.** Cloud Datastore

**C.** Cloud Memorystore as a cache

**D.** Separate Cloud SQL clusters for each region

**Respuesta de la fuente:** A

**Explicación:** Cloud Spanner is the correct choice because it provides strong global consistency and horizontal scalability while supporting data locality configurations for GDPR compliance.
It is a fully managed service, which directly addresses HipLocal's requirement to reduce infrastructure management time and cost.
Separate Cloud SQL clusters (Option D) are incorrect because managing multiple independent databases introduces significant operational overhead and does not offer the seamless global scaling and consistency required by a rapidly growing, distributed application.

## Pregunta 84

Contexto: [topics:726](#topics-726)
You have an application deployed in production. When a new version is deployed, you want to ensure that all production traffic is routed to the new version of your application. You also want to keep the previous version deployed so that you can revert to it if there is an issue with the new version.
Which deployment strategy should you use?

**A.** Blue/green deployment

**B.** Canary deployment

**C.** Rolling deployment

**D.** Recreate deployment

**Respuesta de la fuente:** A

**Explicación:** Blue/green deployment maintains two identical production environments, allowing instant switching of all traffic to the new version while keeping the previous version live for immediate rollback. In contrast, rolling deployments gradually shift traffic between versions rather than moving all at once, and recreate deployments do not retain the old version for quick reversion.

## Pregunta 85

Contexto: [topics:726](#topics-726)
You are porting an existing Apache/MySQL/PHP application stack from a single machine to Google
Kubernetes Engine. You need to determine how to containerize the application. Your approach should follow Google-recommended best practices for availability.
What should you do?

**A.** Package each component in a separate container. Implement readiness and liveness probes.

**B.** Package the application in a single container. Use a process management tool to manage each component.

**C.** Package each component in a separate container. Use a script to orchestrate the launch of the components.

**D.** Package the application in a single container. Use a bash script as an entrypoint to the container, and then spawn each component as a background job.

**Respuesta de la fuente:** A

**Explicación:** Google Kubernetes Engine best practices dictate that each container should run a single process to ensure independent scalability and lifecycle management; therefore, Apache, MySQL, and PHP must be packaged in separate containers. Additionally, implementing readiness and liveness probes is essential for the orchestrator to monitor component health and maintain application availability.

The most tempting alternative (B) is incorrect because packaging multiple processes into a single container violates the one-process-per-container principle, making it difficult for Kubernetes to manage individual component failures or scale specific services independently.

## Pregunta 86

Contexto: [topics:726](#topics-726)
You are developing an application that will be launched on Compute Engine instances into multiple distinct projects, each corresponding to the environments in your software development process (development, QA, staging, and production). The instances in each project have the same application code but a different configuration. During deployment, each instance should receive the application's configuration based on the environment it serves. You want to minimize the number of steps to configure this flow. What should you do?

**A.** When creating your instances, configure a startup script using the gcloud command to determine the project name that indicates the correct environment.

**B.** In each project, configure a metadata key "environment" whose value is the environment it serves. Use your deployment tool to query the instance metadata and configure the application based on the "environment" value.

**C.** Deploy your chosen deployment tool on an instance in each project. Use a deployment job to retrieve the appropriate configuration file from your version control system, and apply the configuration when deploying the application on each instance.

**D.** During each instance launch, configure an instance custom-metadata key named "environment" whose value is the environment the instance serves. Use your deployment tool to query the instance metadata, and configure the application based on the "environment" value.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because setting a project-level metadata key applies to all instances within that project automatically, eliminating the need to configure metadata for each individual instance.
This aligns with the requirement to minimize steps, as opposed to Option D, which requires adding custom metadata during every single instance launch.

## Pregunta 87

Contexto: [topics:726](#topics-726)
You are developing an ecommerce application that stores customer, order, and inventory data as relational tables inside Cloud Spanner. During a recent load test, you discover that Spanner performance is not scaling linearly as expected. Which of the following is the cause?

**A.** The use of 64-bit numeric types for 32-bit numbers.

**B.** The use of the STRING data type for arbitrary-precision values.

**C.** The use of Version 1 UUIDs as primary keys that increase monotonically.

**D.** The use of LIKE instead of STARTS_WITH keyword for parameterized SQL queries.

**Respuesta de la fuente:** C

**Explicación:** Cloud Spanner splits data into fixed-size chunks called 'split points' based on the primary key. Using Version 1 UUIDs, which are monotonically increasing timestamps, causes all new inserts to target the most recent chunk (hotspotting).
This prevents linear scaling because a single node handles all write load instead of distributing it across nodes.
The other options involve minor storage inefficiencies or query syntax that do not fundamentally block distributed scaling.

## Pregunta 88

Contexto: [topics:726](#topics-726)
You are developing an application that reads credit card data from a Pub/Sub subscription. You have written code and completed unit testing. You need to test the
Pub/Sub integration before deploying to Google Cloud. What should you do?

**A.** Create a service to publish messages, and deploy the Pub/Sub emulator. Generate random content in the publishing service, and publish to the emulator.

**B.** Create a service to publish messages to your application. Collect the messages from Pub/Sub in production, and replay them through the publishing service.

**C.** Create a service to publish messages, and deploy the Pub/Sub emulator. Collect the messages from Pub/Sub in production, and publish them to the emulator.

**D.** Create a service to publish messages, and deploy the Pub/Sub emulator. Publish a standard set of testing messages from the publishing service to the emulator.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because the Cloud Pub/Sub emulator allows you to test your application's integration locally without incurring costs or risking data security. Using a standard, controlled set of test messages ensures reproducibility and verifies that your application handles expected payloads correctly before deployment.

Option A is incorrect because generating random content makes tests non-deterministic and difficult to debug, as you cannot predict the exact inputs to validate specific business logic outcomes.

## Pregunta 89

Contexto: [topics:726](#topics-726)
You are designing an application that will subscribe to and receive messages from a single Pub/Sub topic and insert corresponding rows into a database. Your application runs on Linux and leverages preemptible virtual machines to reduce costs. You need to create a shutdown script that will initiate a graceful shutdown.
What should you do?

**A.** Write a shutdown script that uses inter-process signals to notify the application process to disconnect from the database.

**B.** Write a shutdown script that broadcasts a message to all signed-in users that the Compute Engine instance is going down and instructs them to save current work and sign out.

**C.** Write a shutdown script that writes a file in a location that is being polled by the application once every five minutes. After the file is read, the application disconnects from the database.

**D.** Write a shutdown script that publishes a message to the Pub/Sub topic announcing that a shutdown is in progress. After the application reads the message, it disconnects from the database.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because using inter-process signals (such as SIGTERM) is the standard and most reliable method in Linux to notify a running application of an imminent shutdown, allowing it to perform immediate cleanup tasks like disconnecting from the database.

Options C and D are incorrect because polling for a file or consuming a self-published message introduces unnecessary latency and complexity, which may cause the application to miss the short preemption window. Option B is irrelevant as preemptible VMs typically host backend services without signed-in users requiring manual logout.

## Pregunta 90

Contexto: [topics:726](#topics-726)
You work for a web development team at a small startup. Your team is developing a Node.js application using Google Cloud services, including Cloud Storage and Cloud Build. The team uses a Git repository for version control. Your manager calls you over the weekend and instructs you to make an emergency update to one of the company's websites, and you're the only developer available. You need to access Google Cloud to make the update, but you don't have your work laptop. You are not allowed to store source code locally on a non-corporate computer. How should you set up your developer environment?

**A.** Use a text editor and the Git command line to send your source code updates as pull requests from a public computer.

**B.** Use a text editor and the Git command line to send your source code updates as pull requests from a virtual machine running on a public computer.

**C.** Use Cloud Shell and the built-in code editor for development. Send your source code updates as pull requests.

**D.** Use a Cloud Storage bucket to store the source code that you need to edit. Mount the bucket to a public computer as a drive, and use a code editor to update the code. Turn on versioning for the bucket, and point it to the team's Git repository.

**Respuesta de la fuente:** C

**Explicación:** Cloud Shell provides a secure, ephemeral Linux environment within Google Cloud, ensuring that no source code is stored locally on the untrusted public computer.
The built-in code editor allows you to make changes and submit pull requests directly from the browser, adhering to the company's policy against local storage on non-corporate devices.

## Pregunta 91

Contexto: [topics:726](#topics-726)
Your team develops services that run on Google Kubernetes Engine. You need to standardize their log data using Google-recommended practices and make the data more useful in the fewest number of steps. What should you do? (Choose two.)

**A.** Create aggregated exports on application logs to BigQuery to facilitate log analytics.

**B.** Create aggregated exports on application logs to Cloud Storage to facilitate log analytics.

**C.** Write log output to standard output (stdout) as single-line JSON to be ingested into Cloud Logging as structured logs.

**D.** Mandate the use of the Logging API in the application code to write structured logs to Cloud Logging.

**E.** Mandate the use of the Pub/Sub API to write structured data to Pub/Sub and create a Dataflow streaming pipeline to normalize logs and write them to BigQuery for analytics.

**Respuesta de la fuente:** A, C

**Explicación:** Option C is correct because GKE best practices dictate writing logs to stdout/stderr as single-line JSON; the built-in Fluentd agent automatically ingests these as structured logs in Cloud Logging, requiring minimal configuration. Option A is correct because exporting aggregated application logs to BigQuery is the recommended method for performing complex analytics and long-term retention on large datasets.

Option D is incorrect because using the Logging API adds unnecessary complexity compared to stdout ingestion. Option E is wrong because it introduces excessive infrastructure (Pub/Sub and Dataflow) contrary to the goal of using the fewest steps.

## Pregunta 92

Contexto: [topics:726](#topics-726)
You are designing a deployment technique for your new applications on Google Cloud. As part of your deployment planning, you want to use live traffic to gather performance metrics for both new and existing applications. You need to test against the full production load prior to launch. What should you do?

**A.** Use canary deployment

**B.** Use blue/green deployment

**C.** Use rolling updates deployment

**D.** Use A/B testing with traffic mirroring during deployment

**Respuesta de la fuente:** D

**Explicación:** The requirement to test against the full production load prior to launch is key. Traffic mirroring copies live production traffic to the new version without affecting real users, allowing it to handle the complete volume for performance metrics. Canary and rolling updates only expose a fraction of live traffic to the new version, failing the full-load constraint.

## Pregunta 93

Contexto: [topics:726](#topics-726)
You support an application that uses the Cloud Storage API. You review the logs and discover multiple HTTP 503 Service Unavailable error responses from the
API. Your application logs the error and does not take any further action. You want to implement Google-recommended retry logic to improve success rates.
Which approach should you take?

**A.** Retry the failures in batch after a set number of failures is logged.

**B.** Retry each failure at a set time interval up to a maximum number of times.

**C.** Retry each failure at increasing time intervals up to a maximum number of tries.

**D.** Retry each failure at decreasing time intervals up to a maximum number of tries.

**Respuesta de la fuente:** C

**Explicación:** Google recommends using exponential backoff (retrying at increasing time intervals) to handle transient errors like HTTP 503, preventing overwhelming the service with immediate retries. Option B is incorrect because fixed-interval retries do not scale well during sustained outages and can contribute to thundering herd problems.

## Pregunta 94

Contexto: [topics:726](#topics-726)
You need to redesign the ingestion of audit events from your authentication service to allow it to handle a large increase in traffic. Currently, the audit service and the authentication system run in the same Compute Engine virtual machine. You plan to use the following Google Cloud tools in the new architecture:
✑ Multiple Compute Engine machines, each running an instance of the authentication service
✑ Multiple Compute Engine machines, each running an instance of the audit service
✑ Pub/Sub to send the events from the authentication services.
How should you set up the topics and subscriptions to ensure that the system can handle a large volume of messages and can scale efficiently?

**A.** Create one Pub/Sub topic. Create one pull subscription to allow the audit services to share the messages.

**B.** Create one Pub/Sub topic. Create one pull subscription per audit service instance to allow the services to share the messages.

**C.** Create one Pub/Sub topic. Create one push subscription with the endpoint pointing to a load balancer in front of the audit services.

**D.** Create one Pub/Sub topic per authentication service. Create one pull subscription per topic to be used by one audit service.

**E.** Create one Pub/Sub topic per authentication service. Create one push subscription per topic, with the endpoint pointing to one audit service.

**Respuesta de la fuente:** A

**Explicación:** Creating a single topic with one shared pull subscription allows multiple audit service instances to compete for messages, ensuring each message is processed only once while efficiently distributing load.
Option B is incorrect because creating separate subscriptions per instance would duplicate every message to all subscribers, leading to redundant processing and inefficiency.

## Pregunta 95

Contexto: [topics:726](#topics-726)
You are developing a marquee stateless web application that will run on Google Cloud. The rate of the incoming user traffic is expected to be unpredictable, with no traffic on some days and large spikes on other days. You need the application to automatically scale up and down, and you need to minimize the cost associated with running the application. What should you do?

**A.** Build the application in Python with Firestore as the database. Deploy the application to Cloud Run.

**B.** Build the application in C# with Firestore as the database. Deploy the application to App Engine flexible environment.

**C.** Build the application in Python with CloudSQL as the database. Deploy the application to App Engine standard environment.

**D.** Build the application in Python with Firestore as the database. Deploy the application to a Compute Engine managed instance group with autoscaling.

**Respuesta de la fuente:** A

**Explicación:** Cloud Run is the optimal choice because it supports scaling to zero instances, ensuring zero cost during periods of no traffic, and offers fine-grained billing (per 100ms) for minimal costs during spikes. While App Engine Standard also scales to zero, Cloud Run generally provides more granular control over resource allocation per request, further minimizing costs for unpredictable workloads. Option D is incorrect because Compute Engine instances incur charges even when idle, failing the cost minimization requirement.

## Pregunta 96

Contexto: [topics:726](#topics-726)
You have written a Cloud Function that accesses other Google Cloud resources. You want to secure the environment using the principle of least privilege. What should you do?

**A.** Create a new service account that has Editor authority to access the resources. The deployer is given permission to get the access token.

**B.** Create a new service account that has a custom IAM role to access the resources. The deployer is given permission to get the access token.

**C.** Create a new service account that has Editor authority to access the resources. The deployer is given permission to act as the new service account.

**D.** Create a new service account that has a custom IAM role to access the resources. The deployer is given permission to act as the new service account.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it strictly adheres to the principle of least privilege by using a custom IAM role rather than the overly permissive 'Editor' basic role found in options A and C. Additionally, granting the deployer the `iam.serviceAccounts.actAs` permission allows them to deploy the function using that service account's identity without needing broader access token management permissions.

## Pregunta 97

Contexto: [topics:726](#topics-726)
You are a SaaS provider deploying dedicated blogging software to customers in your Google Kubernetes Engine (GKE) cluster. You want to configure a secure multi-tenant platform to ensure that each customer has access to only their own blog and can't affect the workloads of other customers. What should you do?

**A.** Enable Application-layer Secrets on the GKE cluster to protect the cluster.

**B.** Deploy a namespace per tenant and use Network Policies in each blog deployment.

**C.** Use GKE Audit Logging to identify malicious containers and delete them on discovery.

**D.** Build a custom image of the blogging software and use Binary Authorization to prevent untrusted image deployments.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Kubernetes namespaces provide logical isolation for resources, while Network Policies enforce traffic restrictions between pods, directly addressing the requirement to prevent customers from accessing each other's workloads or affecting one another. This combination forms the foundation of secure multi-tenancy within a shared cluster environment as outlined in GKE documentation. Option A (Application-layer Secrets) focuses on secret management rather than workload isolation, and Option D (Binary Authorization) ensures image integrity but does not prevent runtime interference between tenants.

## Pregunta 98

Contexto: [topics:726](#topics-726)
You have decided to migrate your Compute Engine application to Google Kubernetes Engine. You need to build a container image and push it to Artifact Registry using Cloud Build. What should you do? (Choose two.)

**A.** Run gcloud builds submit in the directory that contains the application source code.

**B.** Run gcloud run deploy app-name --image gcr.io/$PROJECT_ID/app-name in the directory that contains the application source code.

**C.** Run gcloud container images add-tag gcr.io/$PROJECT_ID/app-name gcr.io/$PROJECT_ID/app-name:latest in the directory that contains the application source code.

**D.** In the application source directory, create a file named cloudbuild.yaml that contains the following contents: [Imagen: sin descripción]
Imagen · choices[3].text · sin descripción
![Imagen original](imagenes/87ec3b34cf539e330b94.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
steps:
args
- name:
args
“gcr.io/cloud-builders/docker*
[‘build', -t',
5	1	3	1	2	3	197	37	235	14	23.734360	‘gcr.io/$PROJECT_ID/app-name ,
*gcr.io/cloud-builders/docker*
: ["push", ‘gcr.io/$PROJECT_ID/app-name* ]
```

**E.** In the application source directory, create a file named cloudbuild.yaml that contains the following contents: [Imagen: sin descripción]
Imagen · choices[4].text · sin descripción
![Imagen original](imagenes/335fff4dcbd6b30d3ab7.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
*gcr.io/cloud-builders/gcloud"
: [‘app', ‘deploy*]
1600s
```

**Respuesta de la fuente:** A, D

**Explicación:** Option D defines the correct cloudbuild.yaml configuration with the necessary Docker build and push steps to create the image.
Option A executes gcloud builds submit, which triggers Cloud Build to read that configuration file and perform the operations.
Options B and C are incorrect because they target Cloud Run deployment and image tagging respectively, rather than building and pushing the image.

## Pregunta 99

Contexto: [topics:726](#topics-726)
You are developing an internal application that will allow employees to organize community events within your company. You deployed your application on a single Compute Engine instance. Your company uses Google Workspace (formerly G Suite), and you need to ensure that the company employees can authenticate to the application from anywhere. What should you do?

**A.** Add a public IP address to your instance, and restrict access to the instance using firewall rules. Allow your company's proxy as the only source IP address.

**B.** Add an HTTP(S) load balancer in front of the instance, and set up Identity-Aware Proxy (IAP). Configure the IAP settings to allow your company domain to access the website.

**C.** Set up a VPN tunnel between your company network and your instance's VPC location on Google Cloud. Configure the required firewall rules and routing information to both the on-premises and Google Cloud networks.

**D.** Add a public IP address to your instance, and allow traffic from the internet. Generate a random hash, and create a subdomain that includes this hash and points to your instance. Distribute this DNS address to your company's employees.

**Respuesta de la fuente:** B

**Explicación:** Identity-Aware Proxy (IAP) is the correct choice because it authenticates users against Google Workspace credentials, allowing secure access from any location without relying on IP-based restrictions or VPN tunnels.
Option C is incorrect because a VPN requires a connection to the corporate network, which contradicts the requirement for employees to authenticate from anywhere.

## Pregunta 100

Contexto: [topics:726](#topics-726)
Your development team is using Cloud Build to promote a Node.js application built on App Engine from your staging environment to production. The application relies on several directories of photos stored in a Cloud Storage bucket named webphotos-staging in the staging environment. After the promotion, these photos must be available in a Cloud Storage bucket named webphotos-prod in the production environment. You want to automate the process where possible. What should you do?

**A.** Manually copy the photos to webphotos-prod.

**B.** Add a startup script in the application's app.yami file to move the photos from webphotos-staging to webphotos-prod.

**C.** Add a build step in the cloudbuild.yaml file before the promotion step with the arguments: [Imagen: sin descripción]
Imagen · choices[2].text · sin descripción
![Imagen original](imagenes/f3294ed16bb970c1bde5.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
— name: gcr.io/cloud-builders/gsutil
args: [‘cp', '-r', 'gs://webphotos-staging",
*gs://webphotos-prod']
waitFor: ['-"]
```

**D.** Add a build step in the cloudbuild.yaml file before the promotion step with the arguments: [Imagen: sin descripción]
Imagen · choices[3].text · sin descripción
![Imagen original](imagenes/45d018a0e200dfe4a638.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
= name: ger.io/cloud-builders/gcloud
args: [‘cp', '-A', 'gs://webphotos-staging",
*gs://webphotos-prod']
waitFor: ['-"]
```

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it uses the `gsutil cp -r` command within a Cloud Build step to recursively copy objects from the staging bucket to the production bucket before the application promotes. This automates the data migration as part of the CI/CD pipeline, ensuring the production environment has the required assets immediately upon deployment.

Option D is incorrect because using `mv` (move) would remove the files from the staging bucket, violating data integrity for the staging environment which should retain its own state. Option B is wrong because application startup scripts are not designed for large-scale infrastructure data synchronization and lack the robustness of a dedicated build step.

## Pregunta 101

Contexto: [topics:726](#topics-726)
You are developing a web application that will be accessible over both HTTP and HTTPS and will run on Compute Engine instances. On occasion, you will need to SSH from your remote laptop into one of the Compute Engine instances to conduct maintenance on the app. How should you configure the instances while following Google-recommended best practices?

**A.** Set up a backend with Compute Engine web server instances with a private IP address behind a TCP proxy load balancer.

**B.** Configure the firewall rules to allow all ingress traffic to connect to the Compute Engine web servers, with each server having a unique external IP address.

**C.** Configure Cloud Identity-Aware Proxy API for SSH access. Then configure the Compute Engine servers with private IP addresses behind an HTTP(s) load balancer for the application web traffic.

**D.** Set up a backend with Compute Engine web server instances with a private IP address behind an HTTP(S) load balancer. Set up a bastion host with a public IP address and open firewall ports. Connect to the web instances using the bastion host.

**Respuesta de la fuente:** C

**Explicación:** Option C is the correct answer because it aligns with Google Cloud's recommended best practice of keeping Compute Engine instances in private subnets without external IP addresses to minimize the attack surface.
For administrative access, Identity-Aware Proxy (IAP) TCP forwarding allows secure SSH connections over HTTPS without exposing port 22 to the internet or requiring a bastion host.
Option D is a viable legacy pattern but requires managing a separate bastion host and complex firewall rules, whereas IAP provides a more streamlined, identity-based security model preferred in modern Google Cloud architectures.

## Pregunta 102

Contexto: [topics:726](#topics-726)
You have a mixture of packaged and internally developed applications hosted on a Compute Engine instance that is running Linux. These applications write log records as text in local files. You want the logs to be written to Cloud Logging. What should you do?

**A.** Pipe the content of the files to the Linux Syslog daemon.

**B.** Install a Google version of fluentd on the Compute Engine instance.

**C.** Install a Google version of collectd on the Compute Engine instance.

**D.** Using cron, schedule a job to copy the log files to Cloud Storage once a day.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because the Cloud Logging agent (based on Fluentd) is specifically designed to collect logs from arbitrary text files and forward them to Cloud Logging in near real-time.

Option C is incorrect because collectd is a metrics collection daemon used for monitoring performance data, not log ingestion.

Option A is inefficient as it relies on syslog infrastructure rather than the dedicated logging agent optimized for file-based logs.

Option D fails to provide real-time logging and stores data in Cloud Storage rather than ingesting it directly into the Cloud Logging service.

## Pregunta 103

Contexto: [topics:726](#topics-726)
You want to create `fully baked` or `golden` Compute Engine images for your application. You need to bootstrap your application to connect to the appropriate database according to the environment the application is running on (test, staging, production). What should you do?

**A.** Embed the appropriate database connection string in the image. Create a different image for each environment.

**B.** When creating the Compute Engine instance, add a tag with the name of the database to be connected. In your application, query the Compute Engine API to pull the tags for the current instance, and use the tag to construct the appropriate database connection string.

**C.** When creating the Compute Engine instance, create a metadata item with a key of "DATABASE" and a value for the appropriate database connection string. In your application, read the "DATABASE" environment variable, and use the value to connect to the appropriate database.

**D.** When creating the Compute Engine instance, create a metadata item with a key of "DATABASE" and a value for the appropriate database connection string. In your application, query the metadata server for the "DATABASE" value, and use the value to connect to the appropriate database.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it leverages the Compute Engine metadata server to provide environment-specific configuration (database connection string) at runtime without baking it into the image. This allows a single 'golden' image to be used across test, staging, and production environments while securely retrieving the appropriate credentials via an HTTP request to the local metadata service (169.254.169.254). Option C is incorrect because simply setting a custom metadata key does not automatically populate an environment variable in the guest OS unless specific startup scripts or agent features are used; querying the metadata server directly is the reliable, standard method for accessing this data programmatically.

## Pregunta 104

Contexto: [topics:726](#topics-726)
You are developing a microservice-based application that will be deployed on a Google Kubernetes Engine cluster. The application needs to read and write to a
Spanner database. You want to follow security best practices while minimizing code changes. How should you configure your application to retrieve Spanner credentials?

**A.** Configure the appropriate service accounts, and use Workload Identity to run the pods.

**B.** Store the application credentials as Kubernetes Secrets, and expose them as environment variables.

**C.** Configure the appropriate routing rules, and use a VPC-native cluster to directly connect to the database.

**D.** Store the application credentials using Cloud Key Management Service, and retrieve them whenever a database connection is made.

**Respuesta de la fuente:** A

**Explicación:** Workload Identity allows GKE workloads to impersonate Google Cloud IAM service accounts, enabling access to Spanner without storing long-lived credentials in Kubernetes Secrets. This approach eliminates the overhead of key rotation and reduces attack surface by avoiding static secret storage, aligning with security best practices while requiring minimal code changes via default credential discovery.

Option B is incorrect because storing credentials as Kubernetes Secrets introduces management overhead and security risks associated with static keys that must be manually rotated.

## Pregunta 105

Contexto: [topics:726](#topics-726)
You are deploying your application on a Compute Engine instance that communicates with Cloud SQL. You will use Cloud SQL Proxy to allow your application to communicate to the database using the service account associated with the application's instance. You want to follow the Google-recommended best practice of providing minimum access for the role assigned to the service account. What should you do?

**A.** Assign the Project Editor role.

**B.** Assign the Project Owner role.

**C.** Assign the Cloud SQL Client role.

**D.** Assign the Cloud SQL Editor role.

**Respuesta de la fuente:** C

**Explicación:** To adhere to the principle of least privilege, you must assign only the permissions necessary for the application to connect to the database. The Cloud SQL Client role (C) grants exactly these minimal permissions for connecting and querying via the proxy.

Options A and B are broad project-level roles that grant excessive access beyond database connectivity, while Option D (Cloud SQL Editor) includes administrative permissions for managing instances, which is unnecessary for a read/write application workload.

## Pregunta 106

Contexto: [topics:726](#topics-726)
Your team develops stateless services that run on Google Kubernetes Engine (GKE). You need to deploy a new service that will only be accessed by other services running in the GKE cluster. The service will need to scale as quickly as possible to respond to changing load. What should you do?

**A.** Use a Vertical Pod Autoscaler to scale the containers, and expose them via a ClusterIP Service.

**B.** Use a Vertical Pod Autoscaler to scale the containers, and expose them via a NodePort Service.

**C.** Use a Horizontal Pod Autoscaler to scale the containers, and expose them via a ClusterIP Service.

**D.** Use a Horizontal Pod Autoscaler to scale the containers, and expose them via a NodePort Service.

**Respuesta de la fuente:** C

**Explicación:** Horizontal Pod Autoscaler (HPA) is the correct scaling mechanism because it dynamically adds or removes pod replicas based on metrics like CPU utilization, allowing for rapid response to changing load demands. In contrast, Vertical Pod Autoscaler (VPA) only adjusts resource requests/limits for existing pods, which is slower and less effective for handling sudden traffic spikes.

ClusterIP Service is required because the scenario specifies the service must only be accessed by other services within the GKE cluster; NodePort exposes the service on each node's IP and port, making it accessible from outside the cluster, which violates the security/access constraint.

## Pregunta 107

Contexto: [topics:726](#topics-726)
You recently migrated a monolithic application to Google Cloud by breaking it down into microservices. One of the microservices is deployed using Cloud
Functions. As you modernize the application, you make a change to the API of the service that is backward-incompatible. You need to support both existing callers who use the original API and new callers who use the new API. What should you do?

**A.** Leave the original Cloud Function as-is and deploy a second Cloud Function with the new API. Use a load balancer to distribute calls between the versions.

**B.** Leave the original Cloud Function as-is and deploy a second Cloud Function that includes only the changed API. Calls are automatically routed to the correct function.

**C.** Leave the original Cloud Function as-is and deploy a second Cloud Function with the new API. Use Cloud Endpoints to provide an API gateway that exposes a versioned API.

**D.** Re-deploy the Cloud Function after making code changes to support the new API. Requests for both versions of the API are fulfilled based on a version identifier included in the call.

**Respuesta de la fuente:** C

**Explicación:** When dealing with backward-incompatible changes, Google Cloud best practices recommend maintaining separate deployments for each version to ensure existing callers are not disrupted. Cloud Endpoints serves as an API Gateway that can route requests based on versioned paths or headers, allowing distinct Cloud Functions (one for the old API, one for the new) to coexist and be accessed appropriately.

Option D is incorrect because it suggests modifying the existing function to handle multiple versions within a single deployment; while technically possible via code logic, this couples the versions together, increasing complexity and risk of regression during updates, whereas separate deployments provide isolation and independent lifecycle management as preferred in microservices architectures.

## Pregunta 108

Contexto: [topics:726](#topics-726)
You are developing an application that will allow users to read and post comments on news articles. You want to configure your application to store and display user-submitted comments using Firestore. How should you design the schema to support an unknown number of comments and articles?

**A.** Store each comment in a subcollection of the article.

**B.** Add each comment to an array property on the article.

**C.** Store each comment in a document, and add the comment's key to an array property on the article.

**D.** Store each comment in a document, and add the comment's key to an array property on the user profile.

**Respuesta de la fuente:** A

**Explicación:** Option A is the correct answer because Firestore subcollections are designed to store an unlimited number of child documents under a parent document, making them ideal for scenarios like comments on articles where the volume is unknown and potentially large.
Storing comments in an array (Option B) violates Firestore's 1 MiB document size limit, while Options C and D introduce unnecessary complexity by decoupling data access; subcollections allow efficient, direct querying of all comments for a specific article without requiring index maintenance on parent arrays.

## Pregunta 109

Contexto: [topics:726](#topics-726)
You recently developed an application. You need to call the Cloud Storage API from a Compute
Engine instance that doesn't have a public IP address. What should you do?

**A.** Use Carrier Peering

**B.** Use VPC Network Peering

**C.** Use Shared VPC networks

**D.** Use Private Google Access

**Respuesta de la fuente:** D

**Explicación:** Private Google Access is the specific VPC feature that allows instances without external IP addresses to access Google APIs and services over Google's internal network infrastructure. This ensures secure, private connectivity to public endpoints like Cloud Storage without exposing the instance to the internet. Options A, B, and C relate to network connectivity models (peering or sharing) but do not inherently grant API access to non-public instances.

## Pregunta 110

Contexto: [topics:726](#topics-726)
You are a developer working with the CI/CD team to troubleshoot a new feature that your team introduced. The CI/CD team used HashiCorp Packer to create a new Compute Engine image from your development branch. The image was successfully built, but is not booting up. You need to investigate the issue with the CI/
CD team. What should you do?

**A.** Create a new feature branch, and ask the build team to rebuild the image.

**B.** Shut down the deployed virtual machine, export the disk, and then mount the disk locally to access the boot logs.

**C.** Install Packer locally, build the Compute Engine image locally, and then run it in your personal Google Cloud project.

**D.** Check Compute Engine OS logs using the serial port, and check the Cloud Logging logs to confirm access to the serial port.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because accessing the serial port provides direct visibility into the VM's boot process and kernel messages when the OS fails to initialize network services or SSH, which are unavailable in this scenario. Checking Cloud Logging ensures you can verify that the serial port output was captured and is accessible despite potential IAM or configuration restrictions.
Option B is incorrect because exporting and mounting a disk locally is overly complex, invasive, and unnecessary when native GCP troubleshooting tools like the serial console offer immediate, non-destructive access to boot logs.

## Pregunta 111

Contexto: [topics:726](#topics-726)
You manage an application that runs in a Compute Engine instance. You also have multiple backend services executing in stand-alone Docker containers running in Compute Engine instances. The Compute Engine instances supporting the backend services are scaled by managed instance groups in multiple regions. You want your calling application to be loosely coupled. You need to be able to invoke distinct service implementations that are chosen based on the value of an HTTP header found in the request. Which Google Cloud feature should you use to invoke the backend services?

**A.** Traffic Director

**B.** Service Directory

**C.** Anthos Service Mesh

**D.** Internal HTTP(S) Load Balancing

**Respuesta de la fuente:** A

**Explicación:** Traffic Director is a fully managed service mesh control plane that enables advanced traffic routing based on HTTP headers across multiple regions and zones without requiring specific container orchestrators like Kubernetes. This matches the requirement for loosely coupling the calling application to backend services running in Compute Engine instances via header-based routing rules.

Internal HTTP(S) Load Balancing (Option D) is the most tempting alternative because it also supports header-based host/path routing, but it operates at a lower level within a single VPC and lacks the global, multi-region service mesh capabilities and loose coupling benefits explicitly highlighted for Traffic Director in this distributed architecture context.

## Pregunta 112

Contexto: [topics:726](#topics-726)
Your team is developing an ecommerce platform for your company. Users will log in to the website and add items to their shopping cart. Users will be automatically logged out after 30 minutes of inactivity. When users log back in, their shopping cart should be saved. How should you store users' session and shopping cart information while following Google-recommended best practices?

**A.** Store the session information in Pub/Sub, and store the shopping cart information in Cloud SQL.

**B.** Store the shopping cart information in a file on Cloud Storage where the filename is the SESSION ID.

**C.** Store the session and shopping cart information in a MySQL database running on multiple Compute Engine instances.

**D.** Store the session information in Memorystore for Redis or Memorystore for Memcached, and store the shopping cart information in Firestore.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Memorystore (Redis/Memcached) provides the low-latency, high-throughput storage required for ephemeral session data, while Firestore is a fully managed NoSQL database ideal for persisting structured shopping cart data across login events.

The most tempting alternative, C, involves managing MySQL on Compute Engine instances, which contradicts Google Cloud best practices that favor managed database services (like Cloud SQL) or NoSQL options (like Firestore) to reduce operational overhead and ensure better scalability.

## Pregunta 113

Contexto: [topics:726](#topics-726)
You are designing a resource-sharing policy for applications used by different teams in a Google Kubernetes Engine cluster. You need to ensure that all applications can access the resources needed to run. What should you do? (Choose two.)

**A.** Specify the resource limits and requests in the object specifications.

**B.** Create a namespace for each team, and attach resource quotas to each namespace.

**C.** Create a LimitRange to specify the default compute resource requirements for each namespace.

**D.** Create a Kubernetes service account (KSA) for each application, and assign each KSA to the namespace.

**E.** Use the Anthos Policy Controller to enforce label annotations on all namespaces. Use taints and tolerations to allow resource sharing for namespaces.

**Respuesta de la fuente:** B, C

**Explicación:** To ensure all applications have the resources they need in a shared GKE cluster, you must enforce hard caps and provide defaults.
Option B creates namespaces with ResourceQuotas to prevent any single team from consuming excessive cluster resources (resource hogging).
Option C uses LimitRanges to set default requests and limits for containers that do not explicitly specify them, ensuring every application has defined resource boundaries.
Option A is incorrect because while pods should specify these values, the policy design question asks for the mechanism to *ensure* access and safety at the cluster/namespace level; relying solely on individual object specs without quotas or defaults leaves the cluster vulnerable to unbounded consumption.

## Pregunta 114

Contexto: [topics:726](#topics-726)
You are developing a new application that has the following design requirements:
✑ Creation and changes to the application infrastructure are versioned and auditable.
✑ The application and deployment infrastructure uses Google-managed services as much as possible.
✑ The application runs on a serverless compute platform.
How should you design the application's architecture?

**A.** 1. Store the application and infrastructure source code in a Git repository. 2. Use Cloud Build to deploy the application infrastructure with Terraform. 3. Deploy the application to a Cloud Function as a pipeline step.

**B.** 1. Deploy Jenkins from the Google Cloud Marketplace, and define a continuous integration pipeline in Jenkins. 2. Configure a pipeline step to pull the application source code from a Git repository. 3. Deploy the application source code to App Engine as a pipeline step.

**C.** 1. Create a continuous integration pipeline on Cloud Build, and configure the pipeline to deploy the application infrastructure using Deployment Manager templates. 2. Configure a pipeline step to create a container with the latest application source code. 3. Deploy the container to a Compute Engine instance as a pipeline step.

**D.** 1. Deploy the application infrastructure using gcloud commands. 2. Use Cloud Build to define a continuous integration pipeline for changes to the application source code. 3. Configure a pipeline step to pull the application source code from a Git repository, and create a containerized application. 4. Deploy the new container on Cloud Run as a pipeline step.

**Respuesta de la fuente:** A

**Explicación:** Option A is the correct design because it uses Terraform to declaratively define infrastructure, ensuring that all changes are versioned in Git and auditable.

It leverages Cloud Build as a fully Google-managed CI/CD service and deploys to Cloud Functions, which provides the required serverless compute capability.

## Pregunta 115

Contexto: [topics:726](#topics-726)
You are creating and running containers across different projects in Google Cloud. The application you are developing needs to access Google Cloud services from within Google Kubernetes Engine (GKE). What should you do?

**A.** Assign a Google service account to the GKE nodes.

**B.** Use a Google service account to run the Pod with Workload Identity.

**C.** Store the Google service account credentials as a Kubernetes Secret.

**D.** Use a Google service account with GKE role-based access control (RBAC).

**Respuesta de la fuente:** B

**Explicación:** Workload Identity allows Kubernetes service accounts to be mapped directly to Google Cloud service accounts, enabling pods to access GCP resources without managing long-lived credentials.
Option C is incorrect because storing service account keys as Kubernetes Secrets is a legacy practice that poses security risks and complicates key rotation.

## Pregunta 116

Contexto: [topics:726](#topics-726)
You have containerized a legacy application that stores its configuration on an NFS share. You need to deploy this application to Google Kubernetes Engine
(GKE) and do not want the application serving traffic until after the configuration has been retrieved. What should you do?

**A.** Use the gsutil utility to copy files from within the Docker container at startup, and start the service using an ENTRYPOINT script.

**B.** Create a PersistentVolumeClaim on the GKE cluster. Access the configuration files from the volume, and start the service using an ENTRYPOINT script.

**C.** Use the COPY statement in the Dockerfile to load the configuration into the container image. Verify that the configuration is available, and start the service using an ENTRYPOINT script.

**D.** Add a startup script to the GKE instance group to mount the NFS share at node startup. Copy the configuration files into the container, and start the service using an ENTRYPOINT script.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because using a PersistentVolumeClaim (PVC) allows Kubernetes to mount the NFS share directly into the container filesystem in a standardized way, ensuring configuration availability before the service starts.
Option C is incorrect because copying files during the image build step (COPY) does not retrieve dynamic or external configuration from an NFS share at runtime.

## Pregunta 117

Contexto: [topics:726](#topics-726)
Your team is developing a new application using a PostgreSQL database and Cloud Run. You are responsible for ensuring that all traffic is kept private on Google
Cloud. You want to use managed services and follow Google-recommended best practices. What should you do?

**A.** 1. Enable Cloud SQL and Cloud Run in the same project. 2. Configure a private IP address for Cloud SQL. Enable private services access. 3. Create a Serverless VPC Access connector. 4. Configure Cloud Run to use the connector to connect to Cloud SQL.

**B.** 1. Install PostgreSQL on a Compute Engine virtual machine (VM), and enable Cloud Run in the same project. 2. Configure a private IP address for the VM. Enable private services access. 3. Create a Serverless VPC Access connector. 4. Configure Cloud Run to use the connector to connect to the VM hosting PostgreSQL.

**C.** 1. Use Cloud SQL and Cloud Run in different projects. 2. Configure a private IP address for Cloud SQL. Enable private services access. 3. Create a Serverless VPC Access connector. 4. Set up a VPN connection between the two projects. Configure Cloud Run to use the connector to connect to Cloud SQL.

**D.** 1. Install PostgreSQL on a Compute Engine VM, and enable Cloud Run in different projects. 2. Configure a private IP address for the VM. Enable private services access. 3. Create a Serverless VPC Access connector. 4. Set up a VPN connection between the two projects. Configure Cloud Run to use the connector to access the VM hosting PostgreSQL

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it strictly adheres to the requirement for managed services by using Cloud SQL instead of self-managed PostgreSQL on a Compute Engine VM. It also follows Google best practices by keeping resources in the same project and utilizing Private Services Access with a Serverless VPC Access connector to ensure private, secure connectivity without exposing traffic to the public internet.

Option B is incorrect because installing PostgreSQL on a Compute Engine VM creates an unmanaged service, which contradicts the explicit requirement to use managed services. Options C and D are less optimal as they introduce unnecessary complexity through cross-project configurations and VPN setups when same-project Private Services Access provides a simpler, fully supported private path.

## Pregunta 118

Contexto: [topics:726](#topics-726)
You are developing an application that will allow clients to download a file from your website for a specific period of time. How should you design the application to complete this task while following Google-recommended best practices?

**A.** Configure the application to send the file to the client as an email attachment.

**B.** Generate and assign a Cloud Storage-signed URL for the file. Make the URL available for the client to download.

**C.** Create a temporary Cloud Storage bucket with time expiration specified, and give download permissions to the bucket. Copy the file, and send it to the client.

**D.** Generate the HTTP cookies with time expiration specified. If the time is valid, copy the file from the Cloud Storage bucket, and make the file available for the client to download.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Storage signed URLs are the recommended best practice for granting time-limited, secure access to specific objects without making them publicly accessible. They allow you to specify an exact expiration duration and HTTP method, ensuring clients can only download the file during the allotted window.
Option D is incorrect because using cookies and server-side copying introduces unnecessary latency and complexity compared to direct object access via signed URLs.

## Pregunta 119

Contexto: [topics:726](#topics-726)
Your development team has been asked to refactor an existing monolithic application into a set of composable microservices. Which design aspects should you implement for the new application? (Choose two.)

**A.** Develop the microservice code in the same programming language used by the microservice caller.

**B.** Create an API contract agreement between the microservice implementation and microservice caller.

**C.** Require asynchronous communications between all microservice implementations and microservice callers.

**D.** Ensure that sufficient instances of the microservice are running to accommodate the performance requirements.

**E.** Implement a versioning scheme to permit future changes that could be incompatible with the current interface.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 120

Contexto: [topics:726](#topics-726)
You deployed a new application to Google Kubernetes Engine and are experiencing some performance degradation. Your logs are being written to Cloud
Logging, and you are using a Prometheus sidecar model for capturing metrics. You need to correlate the metrics and data from the logs to troubleshoot the performance issue and send real-time alerts while minimizing costs. What should you do?

**A.** Create custom metrics from the Cloud Logging logs, and use Prometheus to import the results using the Cloud Monitoring REST API.

**B.** Export the Cloud Logging logs and the Prometheus metrics to Cloud Bigtable. Run a query to join the results, and analyze in Google Data Studio.

**C.** Export the Cloud Logging logs and stream the Prometheus metrics to BigQuery. Run a recurring query to join the results, and send notifications using Cloud Tasks.

**D.** Export the Prometheus metrics and use Cloud Monitoring to view them as external metrics. Configure Cloud Monitoring to create log-based metrics from the logs, and correlate them with the Prometheus data.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it leverages Cloud Monitoring as a unified platform to ingest Prometheus data as external metrics and generate log-based metrics from Cloud Logging, enabling direct correlation, real-time alerting, and dashboarding within a single service. This approach minimizes costs by avoiding the export fees associated with moving large volumes of data to BigQuery or Bigtable (as suggested in options B and C) while providing native integration for troubleshooting.

## Pregunta 121

Contexto: [topics:726](#topics-726)
You have been tasked with planning the migration of your company's application from on-premises to Google Cloud. Your company's monolithic application is an ecommerce website. The application will be migrated to microservices deployed on Google Cloud in stages. The majority of your company's revenue is generated through online sales, so it is important to minimize risk during the migration. You need to prioritize features and select the first functionality to migrate. What should you do?

**A.** Migrate the Product catalog, which has integrations to the frontend and product database.

**B.** Migrate Payment processing, which has integrations to the frontend, order database, and third-party payment vendor.

**C.** Migrate Order fulfillment, which has integrations to the order database, inventory system, and third-party shipping vendor.

**D.** Migrate the Shopping cart, which has integrations to the frontend, cart database, inventory system, and payment processing system.

**Respuesta de la fuente:** A

**Explicación:** To minimize risk during the initial phase of migrating a revenue-critical application, you should start with a bounded context that has the fewest complex external dependencies. The Product catalog (Option A) primarily interfaces with the frontend and its own database, making it a lower-risk 'strangler' candidate compared to services involving financial transactions or third-party integrations.

Payment processing (Option B) is the most tempting alternative due to its importance, but it involves high-risk third-party vendor integrations and strict compliance requirements, making it unsuitable for a low-risk first step.

## Pregunta 122

Contexto: [topics:726](#topics-726)
Your team develops services that run on Google Kubernetes Engine. Your team's code is stored in Cloud Source Repositories. You need to quickly identify bugs in the code before it is deployed to production. You want to invest in automation to improve developer feedback and make the process as efficient as possible.
What should you do?

**A.** Use Spinnaker to automate building container images from code based on Git tags.

**B.** Use Cloud Build to automate building container images from code based on Git tags.

**C.** Use Spinnaker to automate deploying container images to the production environment.

**D.** Use Cloud Build to automate building container images from code based on forked versions.

**Respuesta de la fuente:** B

**Explicación:** Cloud Build is the native Google Cloud CI/CD service designed to automatically build and test code stored in Cloud Source Repositories, providing immediate feedback on bugs before deployment. Spinnaker is primarily a continuous delivery tool for managing deployments across environments, not for the initial automated build and validation step required here.

## Pregunta 123

Contexto: [topics:726](#topics-726)
Your team is developing an application in Google Cloud that executes with user identities maintained by Cloud Identity. Each of your application's users will have an associated Pub/Sub topic to which messages are published, and a Pub/Sub subscription where the same user will retrieve published messages. You need to ensure that only authorized users can publish and subscribe to their own specific Pub/Sub topic and subscription. What should you do?
[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/3f6ed4571c0a1eab3efc.jpg)
OCR: automatic_unverified · Revisión visual pendiente.
```text
User Identity
__Publish ub/Sub
Topi
Subscription
a >
Queued
Messages
```

**A.** Bind the user identity to the pubsub.publisher and pubsub.subscriber roles at the resource level.

**B.** Grant the user identity the pubsub.publisher and pubsub.subscriber roles at the project level.

**C.** Grant the user identity a custom role that contains the pubsub.topics.create and pubsub.subscriptions.create permissions.

**D.** Configure the application to run as a service account that has the pubsub.publisher and pubsub.subscriber roles.

**Respuesta de la fuente:** A

**Explicación:** To ensure users can only access their specific resources, you must apply IAM bindings at the resource level (topic and subscription) rather than the project level. This follows the principle of least privilege, granting `pubsub.publisher` and `pubsub.subscriber` roles only where needed.

Option B is incorrect because granting roles at the project level would allow users to publish to or subscribe from *any* topic in the project, violating the requirement for user-specific access control.

## Pregunta 124

Contexto: [topics:726](#topics-726)
You are evaluating developer tools to help drive Google Kubernetes Engine adoption and integration with your development environment, which includes VS Code and IntelliJ. What should you do?

**A.** Use Cloud Code to develop applications.

**B.** Use the Cloud Shell integrated Code Editor to edit code and configuration files.

**C.** Use a Cloud Notebook instance to ingest and process data and deploy models.

**D.** Use Cloud Shell to manage your infrastructure and applications from the command line.

**Respuesta de la fuente:** A

**Explicación:** Cloud Code is the official Google Cloud plugin specifically designed to integrate with VS Code and IntelliJ, providing a unified development environment for GKE.
It offers Kubernetes-specific features like debugging, profiling, and seamless deployment workflows directly within these IDEs.
Options B and D focus on Cloud Shell, which lacks deep IDE integration, while Option C (Notebooks) is intended for data science, not application development.

## Pregunta 125

Contexto: [topics:726](#topics-726)
You are developing an ecommerce web application that uses App Engine standard environment and Memorystore for Redis. When a user logs into the app, the application caches the user's information (e.g., session, name, address, preferences), which is stored for quick retrieval during checkout.
While testing your application in a browser, you get a 502 Bad Gateway error. You have determined that the application is not connecting to Memorystore. What is the reason for this error?

**A.** Your Memorystore for Redis instance was deployed without a public IP address.

**B.** You configured your Serverless VPC Access connector in a different region than your App Engine instance.

**C.** The firewall rule allowing a connection between App Engine and Memorystore was removed during an infrastructure update by the DevOps team.

**D.** You configured your application to use a Serverless VPC Access connector on a different subnet in a different availability zone than your App Engine instance.

**Respuesta de la fuente:** B

**Explicación:** App Engine services connect to Memorystore for Redis via a Serverless VPC Access connector. A hard requirement for this connectivity is that the App Engine application and its associated Serverless VPC Access connector must reside in the same region.

If the connector is deployed in a different region, App Engine cannot route traffic to it, resulting in connection failures that manifest as 502 Bad Gateway errors when the application attempts to reach Redis. Option C is incorrect because Memorystore uses private IP addresses within the VPC and does not rely on custom firewall rules for standard connectivity; the issue here is architectural misconfiguration of the connector's location.

## Pregunta 126

Contexto: [topics:726](#topics-726)
Your team develops services that run on Google Cloud. You need to build a data processing service and will use Cloud Functions. The data to be processed by the function is sensitive. You need to ensure that invocations can only happen from authorized services and follow Google-recommended best practices for securing functions. What should you do?

**A.** Enable Identity-Aware Proxy in your project. Secure function access using its permissions.

**B.** Create a service account with the Cloud Functions Viewer role. Use that service account to invoke the function.

**C.** Create a service account with the Cloud Functions Invoker role. Use that service account to invoke the function.

**D.** Create an OAuth 2.0 client ID for your calling service in the same project as the function you want to secure. Use those credentials to invoke the function.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google Cloud Functions supports fine-grained IAM authorization, allowing you to assign the 'Cloud Functions Invoker' role to a specific service account to restrict invocation privileges. This aligns with the principle of least privilege and Google's recommended best practices for securing serverless workloads.

Option A is incorrect because Identity-Aware Proxy (IAP) does not support Cloud Functions as a protected resource type, making it technically infeasible for this scenario.

## Pregunta 127

Contexto: [topics:726](#topics-726)
You are deploying your applications on Compute Engine. One of your Compute Engine instances failed to launch. What should you do? (Choose two.)

**A.** Determine whether your file system is corrupted.

**B.** Access Compute Engine as a different SSH user.

**C.** Troubleshoot firewall rules or routes on an instance.

**D.** Check whether your instance boot disk is completely full.

**E.** Check whether network traffic to or from your instance is being dropped.

**Respuesta de la fuente:** A, D

**Explicación:** According to GCP troubleshooting documentation for VM startup issues, primary causes include a boot disk that is completely full (D) or a corrupted file system on the boot disk (A), both of which prevent the OS from initializing. Network-related options like firewall rules (C) or dropped traffic (E) are incorrect because network connectivity is established after the instance has successfully booted and initialized.

## Pregunta 128

Contexto: [topics:726](#topics-726)
Your web application is deployed to the corporate intranet. You need to migrate the web application to Google Cloud. The web application must be available only to company employees and accessible to employees as they travel. You need to ensure the security and accessibility of the web application while minimizing application changes. What should you do?

**A.** Configure the application to check authentication credentials for each HTTP(S) request to the application.

**B.** Configure Identity-Aware Proxy to allow employees to access the application through its public IP address.

**C.** Configure a Compute Engine instance that requests users to log in to their corporate account. Change the web application DNS to point to the proxy Compute Engine instance. After authenticating, the Compute Engine instance forwards requests to and from the web application.

**D.** Configure a Compute Engine instance that requests users to log in to their corporate account. Change the web application DNS to point to the proxy Compute Engine instance. After authenticating, the Compute Engine issues an HTTP redirect to a public IP address hosting the web application.

**Respuesta de la fuente:** B

**Explicación:** Identity-Aware Proxy (IAP) is the recommended Google Cloud solution for securing web applications with minimal code changes, as it handles authentication and authorization before requests reach the application. While IAP uses a public IP endpoint to allow remote access for traveling employees, it restricts access based on identity, ensuring only authorized company employees can connect.

Option C suggests building a custom proxy on Compute Engine, which is complex, inefficient, and does not meet the 'minimizing application changes' or best-practice criteria compared to using managed services like IAP.

## Pregunta 129

Contexto: [topics:726](#topics-726)
You have an application that uses an HTTP Cloud Function to process user activity from both desktop browser and mobile application clients. This function will serve as the endpoint for all metric submissions using HTTP POST.
Due to legacy restrictions, the function must be mapped to a domain that is separate from the domain requested by users on web or mobile sessions. The domain for the Cloud Function is https://fn.example.com. Desktop and mobile clients use the domain https://www.example.com. You need to add a header to the function's
HTTP response so that only those browser and mobile sessions can submit metrics to the Cloud Function. Which response header should you add?

**A.** Access-Control-Allow-Origin: *

**B.** Access-Control-Allow-Origin: https://*.example.com

**C.** Access-Control-Allow-Origin: https://fn.example.com

**D.** Access-Control-Allow-origin: https://www.example.com

**Respuesta de la fuente:** D

**Explicación:** To allow Cross-Origin Resource Sharing (CORS) from a specific source, the `Access-Control-Allow-Origin` header must explicitly list that origin.
Since the clients are hosted on `https://www.example.com`, setting the header to this domain ensures only those sessions can interact with the Cloud Function at `fn.example.com`.
Option A is incorrect because `*` permits requests from any origin, violating the requirement to restrict access to specific client domains.

## Pregunta 130

Contexto: [topics:726](#topics-726)
You have an HTTP Cloud Function that is called via POST. Each submission's request body has a flat, unnested JSON structure containing numeric and text data. After the Cloud Function completes, the collected data should be immediately available for ongoing and complex analytics by many users in parallel. How should you persist the submissions?

**A.** Directly persist each POST request's JSON data into Datastore.

**B.** Transform the POST request's JSON data, and stream it into BigQuery.

**C.** Transform the POST request's JSON data, and store it in a regional Cloud SQL cluster.

**D.** Persist each POST request's JSON data as an individual file within Cloud Storage, with the file name containing the request identifier.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because BigQuery is Google Cloud's managed data warehouse service, specifically optimized for complex analytics and high-concurrency parallel querying. While Option A (Datastore) handles rapid writes efficiently, it is a NoSQL document store not designed for the heavy analytical queries required by many users in parallel.

## Pregunta 131

Contexto: [topics:726](#topics-726)
Your security team is auditing all deployed applications running in Google Kubernetes Engine. After completing the audit, your team discovers that some of the applications send traffic within the cluster in clear text. You need to ensure that all application traffic is encrypted as quickly as possible while minimizing changes to your applications and maintaining support from Google. What should you do?

**A.** Use Network Policies to block traffic between applications.

**B.** Install Istio, enable proxy injection on your application namespace, and then enable mTLS.

**C.** Define Trusted Network ranges within the application, and configure the applications to allow traffic only from those networks.

**D.** Use an automated process to request SSL Certificates for your applications from Let's Encrypt and add them to your applications.

**Respuesta de la fuente:** B

**Explicación:** Istio is a fully managed service mesh on GKE that enables mutual TLS (mTLS) for all intra-cluster traffic via sidecar proxies, ensuring encryption without requiring changes to application code.
Option D is incorrect because it requires manual SSL certificate management and application-level configuration updates, whereas Istio automates this process infrastructure-side.

## Pregunta 132

Contexto: [topics:726](#topics-726)
You migrated some of your applications to Google Cloud. You are using a legacy monitoring platform deployed on-premises for both on-premises and cloud- deployed applications. You discover that your notification system is responding slowly to time-critical problems in the cloud applications. What should you do?

**A.** Replace your monitoring platform with Cloud Monitoring.

**B.** Install the Cloud Monitoring agent on your Compute Engine instances.

**C.** Migrate some traffic back to your old platform. Perform A/B testing on the two platforms concurrently.

**D.** Use Cloud Logging and Cloud Monitoring to capture logs, monitor, and send alerts. Send them to your existing platform.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it addresses the latency issue by leveraging Cloud Monitoring for low-latency detection while preserving the investment in the existing on-premises notification infrastructure through integration.
Replacing the platform (A) ignores the partial migration context and creates unnecessary overhead, while installing agents (B) does not solve the alerting delay or integration requirement.

## Pregunta 133

Contexto: [topics:726](#topics-726)
You recently deployed your application in Google Kubernetes Engine, and now need to release a new version of your application. You need the ability to instantly roll back to the previous version in case there are issues with the new version. Which deployment model should you use?

**A.** Perform a rolling deployment, and test your new application after the deployment is complete.

**B.** Perform A/B testing, and test your application periodically after the new tests are implemented.

**C.** Perform a blue/green deployment, and test your new application after the deployment is. complete.

**D.** Perform a canary deployment, and test your new application periodically after the new version is deployed.

**Respuesta de la fuente:** C

**Explicación:** Blue/green deployment maintains two identical environments (blue and green), allowing traffic to switch instantly between them. This architecture supports immediate rollback by simply redirecting traffic back to the previous stable environment without needing to redeploy or restart pods.

In contrast, rolling updates replace instances incrementally, making a full instant rollback more complex and time-consuming as it requires reverting the rollout process.

## Pregunta 134

Contexto: [topics:726](#topics-726)
You developed a JavaScript web application that needs to access Google Drive's API and obtain permission from users to store files in their Google Drives. You need to select an authorization approach for your application. What should you do?

**A.** Create an API key.

**B.** Create a SAML token.

**C.** Create a service account.

**D.** Create an OAuth Client ID.

**Respuesta de la fuente:** D

**Explicación:** You need an OAuth Client ID because the application acts on behalf of individual users who must explicitly grant permission to access their private Google Drive data.
OAuth 2.0 is the standard protocol for this delegated authorization, ensuring user credentials are never shared with your application.
The most tempting alternative, Service Accounts (C), is incorrect because they are designed for server-to-server authentication or accessing application-owned data, not for acting on behalf of end-users.

## Pregunta 135

Contexto: [topics:726](#topics-726)
You manage an ecommerce application that processes purchases from customers who can subsequently cancel or change those purchases. You discover that order volumes are highly variable and the backend order-processing system can only process one request at a time. You want to ensure seamless performance for customers regardless of usage volume. It is crucial that customers' order update requests are performed in the sequence in which they were generated. What should you do?

**A.** Send the purchase and change requests over WebSockets to the backend.

**B.** Send the purchase and change requests as REST requests to the backend.

**C.** Use a Pub/Sub subscriber in pull mode and use a data store to manage ordering.

**D.** Use a Pub/Sub subscriber in push mode and use a data store to manage ordering.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because using Pub/Sub with a pull-based subscriber allows the backend to control the rate of message consumption, ensuring that only one request is processed at a time as required. The data store is essential for maintaining the exact sequence of operations despite asynchronous processing. Option A (WebSockets) and Option B (REST) would overwhelm the single-threaded backend during volume spikes, while Option D (Push mode) imposes external delivery rates that cannot be easily throttled to match the backend's strict one-at-a-time constraint.

## Pregunta 136

Contexto: [topics:726](#topics-726)
Your company needs a database solution that stores customer purchase history and meets the following requirements:
✑ Customers can query their purchase immediately after submission.
✑ Purchases can be sorted on a variety of fields.
✑ Distinct record formats can be stored at the same time.
Which storage option satisfies these requirements?

**A.** Firestore in Native mode

**B.** Cloud Storage using an object read

**C.** Cloud SQL using a SQL SELECT statement

**D.** Firestore in Datastore mode using a global query

**Respuesta de la fuente:** A

**Explicación:** Firestore in Native mode is the correct choice because it is a NoSQL document database that supports semi-structured data, allowing distinct record formats (schemas) to coexist without rigid table definitions. It provides immediate query capabilities and supports sorting on various fields through index management, meeting all specified requirements for flexibility and performance.

Cloud SQL (Option C) is the most tempting alternative but is incorrect because it is a relational database requiring predefined schemas, which contradicts the requirement to store distinct record formats simultaneously without schema migration.

## Pregunta 137

Contexto: [topics:726](#topics-726)
You recently developed a new service on Cloud Run. The new service authenticates using a custom service and then writes transactional information to a Cloud
Spanner database. You need to verify that your application can support up to 5,000 read and 1,000 write transactions per second while identifying any bottlenecks that occur. Your test infrastructure must be able to autoscale. What should you do?

**A.** Build a test harness to generate requests and deploy it to Cloud Run. Analyze the VPC Flow Logs using Cloud Logging.

**B.** Create a Google Kubernetes Engine cluster running the Locust or JMeter images to dynamically generate load tests. Analyze the results using Cloud Trace.

**C.** Create a Cloud Task to generate a test load. Use Cloud Scheduler to run 60,000 Cloud Task transactions per minute for 10 minutes. Analyze the results using Cloud Monitoring.

**D.** Create a Compute Engine instance that uses a LAMP stack image from the Marketplace, and use Apache Bench to generate load tests against the service. Analyze the results using Cloud Trace.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Google Kubernetes Engine (GKE) natively supports horizontal pod autoscaling for the test infrastructure itself, allowing it to dynamically scale up to generate the required 5,000 reads and 1,000 writes per second. Cloud Trace provides distributed tracing data that helps identify performance bottlenecks across service calls and database interactions.

Option A is incorrect because VPC Flow Logs record network traffic metadata (IPs, ports, bytes) but do not provide application-level latency or transaction throughput metrics needed to identify bottlenecks in business logic or database performance.

## Pregunta 138

Contexto: [topics:726](#topics-726)
You are using Cloud Build for your CI/CD pipeline to complete several tasks, including copying certain files to Compute Engine virtual machines. Your pipeline requires a flat file that is generated in one builder in the pipeline to be accessible by subsequent builders in the same pipeline. How should you store the file so that all the builders in the pipeline can access it?

**A.** Store and retrieve the file contents using Compute Engine instance metadata.

**B.** Output the file contents to a file in /workspace. Read from the same /workspace file in the subsequent build step.

**C.** Use gsutil to output the file contents to a Cloud Storage object. Read from the same object in the subsequent build step.

**D.** Add a build argument that runs an HTTP POST via curl to a separate web server to persist the value in one builder. Use an HTTP GET via curl from the subsequent build step to read the value.

**Respuesta de la fuente:** B

**Explicación:** In Google Cloud Build, the /workspace directory is shared across all build steps within a single pipeline, allowing one step to write a file that subsequent steps can read directly. This is the simplest and most efficient method for sharing data between steps without requiring external network calls or storage services.

## Pregunta 139

Contexto: [topics:726](#topics-726)
Your company’s development teams want to use various open source operating systems in their Docker builds. When images are created in published containers in your company’s environment, you need to scan them for Common Vulnerabilities and Exposures (CVEs). The scanning process must not impact software development agility. You want to use managed services where possible. What should you do?

**A.** Enable the Vulnerability scanning setting in the Container Registry.

**B.** Create a Cloud Function that is triggered on a code check-in and scan the code for CVEs.

**C.** Disallow the use of non-commercially supported base images in your development environment.

**D.** Use Cloud Monitoring to review the output of Cloud Build to determine whether a vulnerable version has been used.

**Respuesta de la fuente:** A

**Explicación:** Enabling vulnerability scanning in the Container Registry is a fully managed service that automatically scans images for CVEs upon push, satisfying the requirement to use managed services while ensuring security checks are integrated without manual overhead.
This approach maintains development agility by running asynchronously in the background rather than blocking the build pipeline with custom code analysis or imposing restrictive bans on open-source base images.

## Pregunta 140

Contexto: [topics:726](#topics-726)
You are configuring a continuous integration pipeline using Cloud Build to automate the deployment of new container images to Google Kubernetes Engine (GKE). The pipeline builds the application from its source code, runs unit and integration tests in separate steps, and pushes the container to Container Registry. The application runs on a Python web server.

The Dockerfile is as follows:

FROM python:3.7-alpine -

COPY . /app -

WORKDIR /app -
RUN pip install -r requirements.txt
CMD [ "gunicorn", "-w 4", "main:app" ]

You notice that Cloud Build runs are taking longer than expected to complete. You want to decrease the build time. What should you do? (Choose two.)

**A.** Select a virtual machine (VM) size with higher CPU for Cloud Build runs.

**B.** Deploy a Container Registry on a Compute Engine VM in a VPC, and use it to store the final images.

**C.** Cache the Docker image for subsequent builds using the -- cache-from argument in your build config file.

**D.** Change the base image in the Dockerfile to ubuntu:latest, and install Python 3.7 using a package manager utility.

**E.** Store application source code on Cloud Storage, and configure the pipeline to use gsutil to download the source code.

**Respuesta de la fuente:** A, C

**Explicación:** Answer A is correct because Cloud Build documentation explicitly recommends increasing VM vCPU counts to accelerate build processes by providing more compute power for compilation and testing steps. Answer C is correct because using Docker layer caching (via --cache-from or configured cache settings) allows Cloud Build to reuse unchanged layers from previous builds, significantly reducing rebuild time even when source code changes invalidate only specific layers.

Answer D is incorrect because switching from Alpine to Ubuntu increases image size and build complexity, which would likely increase rather than decrease build times. Answer E is incorrect because adding a step to download source code from Cloud Storage introduces network latency and extra processing overhead, failing to reduce overall pipeline duration.

## Pregunta 141

Contexto: [topics:726](#topics-726)
You are building a CI/CD pipeline that consists of a version control system, Cloud Build, and Container Registry. Each time a new tag is pushed to the repository, a Cloud Build job is triggered, which runs unit tests on the new code builds a new Docker container image, and pushes it into Container Registry. The last step of your pipeline should deploy the new container to your production Google Kubernetes Engine (GKE) cluster. You need to select a tool and deployment strategy that meets the following requirements:
• Zero downtime is incurred
• Testing is fully automated
• Allows for testing before being rolled out to users
• Can quickly rollback if needed

What should you do?

**A.** Trigger a Spinnaker pipeline configured as an A/B test of your new code and, if it is successful, deploy the container to production.

**B.** Trigger a Spinnaker pipeline configured as a canary test of your new code and, if it is successful, deploy the container to production.

**C.** Trigger another Cloud Build job that uses the Kubernetes CLI tools to deploy your new container to your GKE cluster, where you can perform a canary test.

**D.** Trigger another Cloud Build job that uses the Kubernetes CLI tools to deploy your new container to your GKE cluster, where you can perform a shadow test.

**Respuesta de la fuente:** D

**Explicación:** Option D is the correct answer because shadow testing allows you to validate new code against real production traffic without exposing end-users to potential errors, thereby ensuring zero downtime and allowing for testing before full rollout.
In contrast, Canary deployments (Options B and C) route a subset of live user traffic to the new version, which risks impacting users if issues arise and thus conflicts with the strict requirement of zero risk/downtime during the testing phase.

## Pregunta 142

Contexto: [topics:726](#topics-726)
Your operations team has asked you to create a script that lists the Cloud Bigtable, Memorystore, and Cloud SQL databases running within a project. The script should allow users to submit a filter expression to limit the results presented. How should you retrieve the data?

**A.** Use the HBase API, Redis API, and MySQL connection to retrieve database lists. Combine the results, and then apply the filter to display the results

**B.** Use the HBase API, Redis API, and MySQL connection to retrieve database lists. Filter the results individually, and then combine them to display the results

**C.** Run gcloud bigtable instances list, gcloud redis instances list, and gcloud sql databases list. Use a filter within the application, and then display the results

**D.** Run gcloud bigtable instances list, gcloud redis instances list, and gcloud sql databases list. Use --filter flag with each command, and then display the results

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because the gcloud CLI supports a unified --filter flag that applies server-side filtering to listing commands, efficiently limiting results before they are displayed. Options A and B are incorrect because HBase and Redis APIs are data-access protocols, not management interfaces for listing cloud resources. Option C is inferior because filtering within the application (client-side) processes all retrieved data locally rather than leveraging the efficient built-in filtering capabilities of the gcloud tool.

## Pregunta 143

Contexto: [topics:726](#topics-726)
You need to deploy a new European version of a website hosted on Google Kubernetes Engine. The current and new websites must be accessed via the same HTTP(S) load balancer's external IP address, but have different domain names. What should you do?

**A.** Define a new Ingress resource with a host rule matching the new domain

**B.** Modify the existing Ingress resource with a host rule matching the new domain

**C.** Create a new Service of type LoadBalancer specifying the existing IP address as the loadBalancerIP

**D.** Generate a new Ingress resource and specify the existing IP address as the kubernetes.io/ingress.global-static-ip-name annotation value

**Respuesta de la fuente:** B

**Explicación:** Modifying the existing Ingress resource (Option B) is correct because GKE provisions a single HTTP(S) load balancer per Ingress controller, and adding a new host rule to that existing resource enables name-based virtual hosting without creating a redundant load balancer or conflicting IP assignments.
Creating a separate Ingress resource (Options A and D) would typically provision a second, distinct load balancer with its own external IP, violating the requirement to use the same IP address.
Option C is incorrect because standard Service resources of type LoadBalancer do not support domain-based routing (host rules), which are necessary to distinguish traffic for different domain names arriving at the same IP.

## Pregunta 144

Contexto: [topics:726](#topics-726)
You are developing a single-player mobile game backend that has unpredictable traffic patterns as users interact with the game throughout the day and night. You want to optimize costs by ensuring that you have enough resources to handle requests, but minimize over-provisioning. You also want the system to handle traffic spikes efficiently. Which compute platform should you use?

**A.** Cloud Run

**B.** Compute Engine with managed instance groups

**C.** Compute Engine with unmanaged instance groups

**D.** Google Kubernetes Engine using cluster autoscaling

**Respuesta de la fuente:** A

**Explicación:** Cloud Run is the optimal choice because it provides serverless, event-driven autoscaling that scales down to zero instances when idle, ensuring minimal costs for unpredictable traffic patterns.
In contrast, Compute Engine with instance groups and GKE require maintaining minimum node or VM resources, leading to over-provisioning during low-traffic periods and slower scaling responses compared to Cloud Run's granular concurrency-based scaling.

## Pregunta 145

Contexto: [topics:726](#topics-726)
The development teams in your company want to manage resources from their local environments. You have been asked to enable developer access to each team’s Google Cloud projects. You want to maximize efficiency while following Google-recommended best practices. What should you do?

**A.** Add the users to their projects, assign the relevant roles to the users, and then provide the users with each relevant Project ID.

**B.** Add the users to their projects, assign the relevant roles to the users, and then provide the users with each relevant Project Number.

**C.** Create groups, add the users to their groups, assign the relevant roles to the groups, and then provide the users with each relevant Project ID.

**D.** Create groups, add the users to their groups, assign the relevant roles to the groups, and then provide the users with each relevant Project Number.

**Respuesta de la fuente:** C

**Explicación:** Google Cloud best practices recommend using Identity and Access Management (IAM) groups rather than individual users to assign roles, as this simplifies permission management and reduces administrative overhead when personnel changes occur. Additionally, developers should be provided with the Project ID because it is the human-readable identifier used in most UIs, CLI commands, and API calls for resource identification, whereas the Project Number is an internal system identifier.

## Pregunta 146

Contexto: [topics:726](#topics-726)
Your company’s product team has a new requirement based on customer demand to autoscale your stateless and distributed service running in a Google Kubernetes Engine (GKE) duster. You want to find a solution that minimizes changes because this feature will go live in two weeks. What should you do?

**A.** Deploy a Vertical Pod Autoscaler, and scale based on the CPU load.

**B.** Deploy a Vertical Pod Autoscaler, and scale based on a custom metric.

**C.** Deploy a Horizontal Pod Autoscaler, and scale based on the CPU toad.

**D.** Deploy a Horizontal Pod Autoscaler, and scale based on a custom metric.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Horizontal Pod Autoscaler (HPA) is the standard mechanism for scaling stateless distributed services by adding replicas, and using built-in CPU metrics requires zero custom instrumentation or additional components. This minimizes configuration changes and implementation time, fitting the two-week deadline perfectly.

Option D is the most tempting alternative but is incorrect because implementing custom metrics requires setting up Prometheus adapters and defining specific queries, which introduces unnecessary complexity and development overhead when simple CPU-based scaling suffices for a quick rollout.

## Pregunta 147

Contexto: [topics:726](#topics-726)
Your application is composed of a set of loosely coupled services orchestrated by code executed on Compute Engine. You want your application to easily bring up new Compute Engine instances that find and use a specific version of a service. How should this be configured?

**A.** Define your service endpoint information as metadata that is retrieved at runtime and used to connect to the desired service.

**B.** Define your service endpoint information as label data that is retrieved at runtime and used to connect to the desired service.

**C.** Define your service endpoint information to be retrieved from an environment variable at runtime and used to connect to the desired service.

**D.** Define your service to use a fixed hostname and port to connect to the desired service. Replace the service at the endpoint with your new version.

**Respuesta de la fuente:** A

**Explicación:** Compute Engine instance metadata is specifically designed to provide dynamic configuration data and service endpoint information to instances at runtime without requiring code changes or restarts. This supports the loosely coupled architecture by allowing new instances to automatically discover the correct service version upon boot.
Labels (Choice B) are primarily intended for resource organization, billing, and IAM policies, making them unsuitable for storing runtime configuration data like endpoints.

## Pregunta 148

Contexto: [topics:726](#topics-726)
You are developing a microservice-based application that will run on Google Kubernetes Engine (GKE). Some of the services need to access different Google Cloud APIs. How should you set up authentication of these services in the cluster following Google-recommended best practices? (Choose two.)

**A.** Use the service account attached to the GKE node.

**B.** Enable Workload Identity in the cluster via the gcloud command-line tool.

**C.** Access the Google service account keys from a secret management service.

**D.** Store the Google service account keys in a central secret management service.

**E.** Use gcloud to bind the Kubernetes service account and the Google service account using roles/iam.workloadIdentity.

**Respuesta de la fuente:** B, E

**Explicación:** Google recommends Workload Identity as the best practice for GKE authentication because it eliminates the need to manage and rotate Google Cloud service account keys. Option B is correct because you must enable Workload Identity on the cluster to establish this trust boundary. Option E is correct because it performs the necessary IAM binding that maps a Kubernetes Service Account to a specific Google Cloud Service Account, granting granular access to APIs.

Options C and D are incorrect because managing static service account keys introduces security risks and operational overhead related to mandatory key rotation, which Workload Identity specifically avoids. Option A is suboptimal because using the node's default service account grants all pods on that node excessive permissions, violating the principle of least privilege.

## Pregunta 149

Contexto: [topics:726](#topics-726)
Your development team has been tasked with maintaining a .NET legacy application. The application incurs occasional changes and was recently updated. Your goal is to ensure that the application provides consistent results while moving through the CI/CD pipeline from environment to environment. You want to minimize the cost of deployment while making sure that external factors and dependencies between hosting environments are not problematic. Containers are not yet approved in your organization. What should you do?

**A.** Rewrite the application using .NET Core, and deploy to Cloud Run. Use revisions to separate the environments.

**B.** Use Cloud Build to deploy the application as a new Compute Engine image for each build. Use this image in each environment.

**C.** Deploy the application using MS Web Deploy, and make sure to always use the latest, patched MS Windows Server base image in Compute Engine.

**D.** Use Cloud Build to package the application, and deploy to a Google Kubernetes Engine cluster. Use namespaces to separate the environments.

**Respuesta de la fuente:** B

**Explicación:** The requirement explicitly states that containers are not approved, which immediately disqualifies options involving Cloud Run (A) and Google Kubernetes Engine (D). Option C relies on external web deployment tools and frequent base image updates, which increases complexity and potential environmental drift rather than minimizing cost and ensuring consistency. Option B is correct because using Cloud Build to create a Compute Engine VM image captures the exact application state and dependencies in a reproducible snapshot, allowing consistent deployment across environments without container technology.

## Pregunta 150

Contexto: [topics:726](#topics-726)
The new version of your containerized application has been tested and is ready to deploy to production on Google Kubernetes Engine. You were not able to fully load-test the new version in pre-production environments, and you need to make sure that it does not have performance problems once deployed. Your deployment must be automated. What should you do?

**A.** Use Cloud Load Balancing to slowly ramp up traffic between versions. Use Cloud Monitoring to look for performance issues.

**B.** Deploy the application via a continuous delivery pipeline using canary deployments. Use Cloud Monitoring to look for performance issues. and ramp up traffic as the metrics support it.

**C.** Deploy the application via a continuous delivery pipeline using blue/green deployments. Use Cloud Monitoring to look for performance issues, and launch fully when the metrics support it.

**D.** Deploy the application using kubectl and set the spec.updateStrategv.type to RollingUpdate. Use Cloud Monitoring to look for performance issues, and run the kubectl rollback command if there are any issues.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because a canary deployment allows for the automated, gradual introduction of traffic to the new version based on real-time performance metrics from Cloud Monitoring. This strategy specifically addresses the risk of unknown performance issues by letting you ramp up traffic only as metrics validate stability.

Option D (RollingUpdate) is incorrect because it typically deploys all instances sequentially without a mechanism to automatically pause or reverse based on performance thresholds, failing to mitigate the specific risk of untested load performance.

## Pregunta 151

Contexto: [topics:726](#topics-726)
Users are complaining that your Cloud Run-hosted website responds too slowly during traffic spikes. You want to provide a better user experience during traffic peaks. What should you do?

**A.** Read application configuration and static data from the database on application startup.

**B.** Package application configuration and static data into the application image during build time.

**C.** Perform as much work as possible in the background after the response has been returned to the user.

**D.** Ensure that timeout exceptions and errors cause the Cloud Run instance to exit quickly so a replacement instance can be started.

**Respuesta de la fuente:** B

**Explicación:** Cloud Run scales dynamically by spinning up new instances during traffic spikes, resulting in frequent cold starts.
Packaging configuration and static data into the container image (Option B) eliminates the latency of fetching this data from external sources like databases at startup, directly improving cold start times and request handling speed.
Reading from a database on startup (Option A) adds I/O delay to every new instance spin-up, worsening performance during rapid scaling.

## Pregunta 152

Contexto: [topics:726](#topics-726)
You are a developer working on an internal application for payroll processing. You are building a component of the application that allows an employee to submit a timesheet, which then initiates several steps:

• An email is sent to the employee and manager, notifying them that the timesheet was submitted.
• A timesheet is sent to payroll processing for the vendor's API.
• A timesheet is sent to the data warehouse for headcount planning.

These steps are not dependent on each other and can be completed in any order. New steps are being considered and will be implemented by different development teams. Each development team will implement the error handling specific to their step. What should you do?

**A.** Deploy a Cloud Function for each step that calls the corresponding downstream system to complete the required action.

**B.** Create a Pub/Sub topic for each step. Create a subscription for each downstream development team to subscribe to their step's topic.

**C.** Create a Pub/Sub topic for timesheet submissions. Create a subscription for each downstream development team to subscribe to the topic.

**D.** Create a timesheet microservice deployed to Google Kubernetes Engine. The microservice calls each downstream step and waits for a successful response before calling the next step.

**Respuesta de la fuente:** C

**Explicación:** Cloud Pub/Sub implements a publish-subscribe model that decouples the timesheet submission component from multiple independent downstream consumers.
By creating a single topic for submissions and allowing each team to create their own subscriptions, you enable parallel, non-blocking processing of steps without coupling the producer to specific consumer logic.
Option B is incorrect because creating a separate topic per step defeats the purpose of event-driven decoupling and increases management overhead, while Option D introduces unnecessary blocking dependencies.

## Pregunta 153

Contexto: [topics:726](#topics-726)
You are designing an application that uses a microservices architecture. You are planning to deploy the application in the cloud and on-premises. You want to make sure the application can scale up on demand and also use managed services as much as possible. What should you do?

**A.** Deploy open source Istio in a multi-cluster deployment on multiple Google Kubernetes Engine (GKE) clusters managed by Anthos.

**B.** Create a GKE cluster in each environment with Anthos, and use Cloud Run for Anthos to deploy your application to each cluster.

**C.** Install a GKE cluster in each environment with Anthos, and use Cloud Build to create a Deployment for your application in each cluster.

**D.** Create a GKE cluster in the cloud and install open-source Kubernetes on-premises. Use an external load balancer service to distribute traffic across the two environments.

**Respuesta de la fuente:** B

**Explicación:** Anthos provides a unified control plane to manage Kubernetes clusters across both Google Cloud (GKE) and on-premises environments, satisfying the hybrid deployment requirement.

Cloud Run for Anthos enables serverless, event-driven scaling on demand and integrates with managed services, which directly addresses the need for auto-scaling and maximizing managed service usage in a hybrid context.

## Pregunta 154

Contexto: [topics:726](#topics-726)
You want to migrate an on-premises container running in Knative to Google Cloud. You need to make sure that the migration doesn't affect your application's deployment strategy, and you want to use a fully managed service. Which Google Cloud service should you use to deploy your container?

**A.** Cloud Run

**B.** Compute Engine

**C.** Google Kubernetes Engine

**D.** App Engine flexible environment

**Respuesta de la fuente:** A

**Explicación:** Cloud Run is the correct choice because it is a fully managed service built directly on top of Knative. This ensures that applications using Knative's features, such as event-driven scaling and revision-based deployment strategies, migrate seamlessly without requiring architectural changes.

## Pregunta 155

Contexto: [topics:726](#topics-726)
This architectural diagram depicts a system that streams data from thousands of devices. You want to ingest data into a pipeline, store the data, and analyze the data using SQL statements. Which Google Cloud services should you use for steps 1, 2, 3, and 4?

[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/e749299d1c8a33fe20d8.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Transaction Database
O oo Coo
Ingest
Monitoring Logging
Pipeline
Analytics
©
Kubernetes
Engine
Application & Presentation
© 0
App Engine
```

**A.** 1. App Engine
2. Pub/Sub
3. BigQuery
4. Firestore

**B.** 1. Dataflow
2. Pub/Sub
3. Firestore
4. BigQuery

**C.** 1. Pub/Sub
2. Dataflow
3. BigQuery
4. Firestore

**D.** 1. Pub/Sub
2. Dataflow
3. Firestore
4. BigQuery

**Respuesta de la fuente:** D

**Explicación:** Step 1 requires a messaging service to ingest high-volume streaming data from devices, making Pub/Sub the correct choice. Step 2 needs a data processing engine for the pipeline, which is Dataflow. Step 3 specifies storing data, and Firestore serves as the operational NoSQL database here. Step 4 requires SQL-based analysis, for which BigQuery is the designated data warehouse solution.

## Pregunta 156

Contexto: [topics:726](#topics-726)
Your company just experienced a Google Kubernetes Engine (GKE) API outage due to a zone failure. You want to deploy a highly available GKE architecture that minimizes service interruption to users in the event of a future zone failure. What should you do?

**A.** Deploy Zonal clusters

**B.** Deploy Regional clusters

**C.** Deploy Multi-Zone clusters

**D.** Deploy GKE on-premises clusters

**Respuesta de la fuente:** B

**Explicación:** Regional clusters deploy the control plane (master nodes) across multiple availability zones within a region, ensuring high availability and protection against zone failures. In contrast, Zonal clusters confine the control plane to a single zone, creating a single point of failure, while 'Multi-Zone' is not the specific terminology for the cluster type in GKE documentation.

## Pregunta 157

Contexto: [topics:726](#topics-726)
Your team develops services that run on Google Cloud. You want to process messages sent to a Pub/Sub topic, and then store them. Each message must be processed exactly once to avoid duplication of data and any data conflicts. You need to use the cheapest and most simple solution. What should you do?

**A.** Process the messages with a Dataproc job, and write the output to storage.

**B.** Process the messages with a Dataflow streaming pipeline using Apache Beam's PubSubIO package, and write the output to storage.

**C.** Process the messages with a Cloud Function, and write the results to a BigQuery location where you can run a job to deduplicate the data.

**D.** Retrieve the messages with a Dataflow streaming pipeline, store them in Cloud Bigtable, and use another Dataflow streaming pipeline to deduplicate messages.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Apache Beam's Pub/SubIO connector in Dataflow automatically deduplicates messages using their unique message IDs, satisfying the exact-once processing requirement without additional logic. This serverless approach minimizes complexity and cost compared to managing cluster resources (A) or implementing manual deduplication logic (C). Option D adds unnecessary complexity and cost by storing data in Bigtable before deduplication.

## Pregunta 158

Contexto: [topics:726](#topics-726)
You are running a containerized application on Google Kubernetes Engine. Your container images are stored in Container Registry. Your team uses CI/CD practices. You need to prevent the deployment of containers with known critical vulnerabilities. What should you do?

**A.** • Use Web Security Scanner to automatically crawl your application
• Review your application logs for scan results, and provide an attestation that the container is free of known critical vulnerabilities
• Use Binary Authorization to implement a policy that forces the attestation to be provided before the container is deployed

**B.** • Use Web Security Scanner to automatically crawl your application
• Review the scan results in the scan details page in the Cloud Console, and provide an attestation that the container is free of known critical vulnerabilities
• Use Binary Authorization to implement a policy that forces the attestation to be provided before the container is deployed

**C.** • Enable the Container Scanning API to perform vulnerability scanning
• Review vulnerability reporting in Container Registry in the Cloud Console, and provide an attestation that the container is free of known critical vulnerabilities
• Use Binary Authorization to implement a policy that forces the attestation to be provided before the container is deployed

**D.** • Enable the Container Scanning API to perform vulnerability scanning
• Programmatically review vulnerability reporting through the Container Scanning API, and provide an attestation that the container is free of known critical vulnerabilities
• Use Binary Authorization to implement a policy that forces the attestation to be provided before the container is deployed

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because the scenario specifies a CI/CD pipeline, which requires automated, programmatic integration rather than manual console review.
By using the Container Scanning API to programmatically assess vulnerabilities and generate attestations via Binary Authorization, you enforce security controls directly within the automation workflow.
Option C is incorrect because reviewing reports manually in the Cloud Console breaks the continuous integration flow and introduces human error or delay.

## Pregunta 159

Contexto: [topics:726](#topics-726)
You have an on-premises application that authenticates to the Cloud Storage API using a user-managed service account with a user-managed key. The application connects to Cloud Storage using Private Google Access over a Dedicated Interconnect link. You discover that requests from the application to access objects in the Cloud Storage bucket are failing with a 403 Permission Denied error code. What is the likely cause of this issue?

**A.** The folder structure inside the bucket and object paths have changed.

**B.** The permissions of the service account’s predefined role have changed.

**C.** The service account key has been rotated but not updated on the application server.

**D.** The Interconnect link from the on-premises data center to Google Cloud is experiencing a temporary outage.

**Respuesta de la fuente:** C

**Explicación:** While a 403 error typically signifies an authorization failure (lack of permissions), in the context of Google Cloud APIs and this specific exam scenario, an expired or rotated service account key that is not updated on the client can also manifest as a 403 Forbidden error because the request fails authentication checks at the API gateway before authorization logic is fully processed. Option B implies a deliberate permission change, which is less likely to happen spontaneously without notice, whereas key rotation without updating the application server is a common operational oversight leading to immediate access failures.

## Pregunta 160

Contexto: [topics:726](#topics-726)
You are using the Cloud Client Library to upload an image in your application to Cloud Storage. Users of the application report that occasionally the upload does not complete and the client library reports an HTTP 504 Gateway Timeout error. You want to make the application more resilient to errors. What changes to the application should you make?

**A.** Write an exponential backoff process around the client library call.

**B.** Write a one-second wait time backoff process around the client library call.

**C.** Design a retry button in the application and ask users to click if the error occurs.

**D.** Create a queue for the object and inform the users that the application will try again in 10 minutes.

**Respuesta de la fuente:** A

**Explicación:** An HTTP 504 Gateway Timeout indicates a transient network or server-side issue that may resolve itself quickly. Implementing an exponential backoff strategy (Choice A) allows the application to automatically retry the request with increasing delays, preventing overwhelming the server during congestion and maximizing success probability for transient failures without user intervention. Choice B is less effective because a fixed delay does not adapt to system load, while Choices C and D degrade the user experience by requiring manual action or introducing significant latency.

## Pregunta 161

Contexto: [topics:726](#topics-726)
You are building a mobile application that will store hierarchical data structures in a database. The application will enable users working offline to sync changes when they are back online. A backend service will enrich the data in the database using a service account. The application is expected to be very popular and needs to scale seamlessly and securely. Which database and IAM role should you use?

**A.** Use Cloud SQL, and assign the roles/cloudsql.editor role to the service account.

**B.** Use Bigtable, and assign the roles/bigtable.viewer role to the service account.

**C.** Use Firestore in Native mode and assign the roles/datastore.user role to the service account.

**D.** Use Firestore in Datastore mode and assign the roles/datastore.viewer role to the service account.

**Respuesta de la fuente:** C

**Explicación:** Firestore in Native mode is the optimal choice for mobile applications requiring offline support and hierarchical data structures, as it provides built-in client-side caching and automatic synchronization. The backend service account requires write permissions to enrich data, so the roles/datastore.user role (which grants read/write access) is correct, whereas Option D uses a viewer role that lacks necessary write capabilities.

## Pregunta 162

Contexto: [topics:726](#topics-726)
Your application is deployed on hundreds of Compute Engine instances in a managed instance group (MIG) in multiple zones. You need to deploy a new instance template to fix a critical vulnerability immediately but must avoid impact to your service. What setting should be made to the MIG after updating the instance template?

**A.** Set the Max Surge to 100%.

**B.** Set the Update mode to Opportunistic.

**C.** Set the Maximum Unavailable to 100%.

**D.** Set the Minimum Wait time to 0 seconds.

**Respuesta de la fuente:** D

**Explicación:** The goal is to update the Managed Instance Group (MIG) as quickly as possible ('immediately') while avoiding service impact. Setting 'Minimum Wait time' to 0 seconds (Option D) eliminates any artificial delay between creating a new instance and terminating an old one, ensuring the fastest possible rolling update completion.

Option A (Max Surge 100%) increases parallelism but does not directly address the timing constraint as precisely as removing wait times; it also risks quota issues or cost spikes without guaranteeing the 'immediate' start. Option B (Opportunistic) is incorrect because it only updates idle instances, delaying the critical fix. Option C (Max Unavailable 100%) violates the requirement to avoid service impact.

## Pregunta 163

Contexto: [topics:726](#topics-726)
You made a typo in a low-level Linux configuration file that prevents your Compute Engine instance from booting to a normal run level. You just created the Compute Engine instance today and have done no other maintenance on it, other than tweaking files. How should you correct this error?

**A.** Download the file using scp, change the file, and then upload the modified version

**B.** Configure and log in to the Compute Engine instance through SSH, and change the file

**C.** Configure and log in to the Compute Engine instance through the serial port, and change the file

**D.** Configure and log in to the Compute Engine instance using a remote desktop client, and change the file

**Respuesta de la fuente:** C

**Explicación:** Since the typo prevents the instance from booting to a normal run level, network services like SSH (Option B) and SCP (Option A) are unavailable because the networking stack is not initialized.
The Serial Console (Option C) provides a direct, out-of-band text-based interface that remains accessible even when the operating system fails to start properly, allowing you to troubleshoot boot issues. Remote Desktop (Option D) is incorrect because Linux instances typically do not run a GUI service by default, and it would also fail if the system cannot boot.

## Pregunta 164

Contexto: [topics:726](#topics-726)
You are developing an application that needs to store files belonging to users in Cloud Storage. You want each user to have their own subdirectory in Cloud Storage. When a new user is created, the corresponding empty subdirectory should also be created. What should you do?

**A.** Create an object with the name of the subdirectory ending with a trailing slash ('/') that is zero bytes in length.

**B.** Create an object with the name of the subdirectory, and then immediately delete the object within that subdirectory.

**C.** Create an object with the name of the subdirectory that is zero bytes in length and has WRITER access control list permission.

**D.** Create an object with the name of the subdirectory that is zero bytes in length. Set the Content-Type metadata to CLOUDSTORAGE_FOLDER.

**Respuesta de la fuente:** A

**Explicación:** Cloud Storage uses a flat namespace where folders are simulated by using object names that end with a trailing slash ('/').
To create an empty subdirectory, you must upload a zero-byte object whose name ends with this delimiter, which the console and APIs interpret as a folder.
Option C is incorrect because omitting the trailing slash creates a file named after the directory rather than defining the directory structure itself.

## Pregunta 165

Contexto: [topics:726](#topics-726)
Your company’s corporate policy states that there must be a copyright comment at the very beginning of all source files. You want to write a custom step in Cloud Build that is triggered by each source commit. You need the trigger to validate that the source contains a copyright and add one for subsequent steps if not there. What should you do?

**A.** Build a new Docker container that examines the files in /workspace and then checks and adds a copyright for each source file. Changed files are explicitly committed back to the source repository.

**B.** Build a new Docker container that examines the files in /workspace and then checks and adds a copyright for each source file. Changed files do not need to be committed back to the source repository.

**C.** Build a new Docker container that examines the files in a Cloud Storage bucket and then checks and adds a copyright for each source file. Changed files are written back to the Cloud Storage bucket.

**D.** Build a new Docker container that examines the files in a Cloud Storage bucket and then checks and adds a copyright for each source file. Changed files are explicitly committed back to the source repository.

**Respuesta de la fuente:** A

**Explicación:** Cloud Build runs custom steps within a Docker container where the source code is automatically cloned into the `/workspace` directory, making it the correct location for file examination.
For subsequent build steps to utilize the modified files containing the copyright headers, those changes must be committed back to the repository so they persist in the build context and version control.

## Pregunta 166

Contexto: [topics:726](#topics-726)
One of your deployed applications in Google Kubernetes Engine (GKE) is having intermittent performance issues. Your team uses a third-party logging solution. You want to install this solution on each node in your GKE cluster so you can view the logs. What should you do?

**A.** Deploy the third-party solution as a DaemonSet

**B.** Modify your container image to include the monitoring software

**C.** Use SSH to connect to the GKE node, and install the software manually

**D.** Deploy the third-party solution using Terraform and deploy the logging Pod as a Kubernetes Deployment

**Respuesta de la fuente:** A

**Explicación:** A DaemonSet ensures that a copy of a Pod runs on every node (or a subset of nodes), making it the standard Kubernetes pattern for deploying system daemons like logging agents across a cluster.
Option B is incorrect because modifying container images violates the principle of immutable infrastructure and couples the logging agent to the application, reducing portability.
Option C is wrong because manual SSH installation does not scale with dynamic node changes in GKE and breaks declarative management practices.

## Pregunta 167

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
For this question, refer to the HipLocal case study.

How should HipLocal redesign their architecture to ensure that the application scales to support a large increase in users?

**A.** Use Google Kubernetes Engine (GKE) to run the application as a microservice. Run the MySQL database on a dedicated GKE node.

**B.** Use multiple Compute Engine instances to run MySQL to store state information. Use a Google Cloud-managed load balancer to distribute the load between instances. Use managed instance groups for scaling.

**C.** Use Memorystore to store session information and CloudSQL to store state information. Use a Google Cloud-managed load balancer to distribute the load between instances. Use managed instance groups for scaling.

**D.** Use a Cloud Storage bucket to serve the application as a static website, and use another Cloud Storage bucket to store user state information.

**Respuesta de la fuente:** C

**Explicación:** Option C correctly implements a scalable stateless architecture by offloading session data to Memorystore (Redis) and persistent state to CloudSQL, allowing Compute Engine instances behind a load balancer to scale horizontally via Managed Instance Groups. Options A and B are incorrect because running MySQL on GKE nodes or individual Compute Engine instances creates single points of failure and management overhead compared to using the fully managed Cloud SQL service.

## Pregunta 168

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
For this question, refer to the HipLocal case study.

How should HipLocal increase their API development speed while continuing to provide the QA team with a stable testing environment that meets feature requirements?

**A.** Include unit tests in their code, and prevent deployments to QA until all tests have a passing status.

**B.** Include performance tests in their code, and prevent deployments to QA until all tests have a passing status.

**C.** Create health checks for the QA environment, and redeploy the APIs at a later time if the environment is unhealthy.

**D.** Redeploy the APIs to App Engine using Traffic Splitting. Do not move QA traffic to the new versions if errors are found.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because unit tests verify the fundamental correctness of individual code components before they are deployed, ensuring the QA environment remains stable and functional for feature testing. This 'shift-left' approach catches bugs early in the development cycle, thereby increasing API development speed by preventing broken builds from reaching QA.

Option B is incorrect because performance tests are typically resource-intensive and better suited for later stages or dedicated load-testing environments, not as a gatekeeper for basic functional stability.

## Pregunta 169

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
For this question, refer to the HipLocal case study.

HipLocal's application uses Cloud Client Libraries to interact with Google Cloud. HipLocal needs to configure authentication and authorization in the Cloud Client Libraries to implement least privileged access for the application. What should they do?

**A.** Create an API key. Use the API key to interact with Google Cloud.

**B.** Use the default compute service account to interact with Google Cloud.

**C.** Create a service account for the application. Export and deploy the private key for the application. Use the service account to interact with Google Cloud.

**D.** Create a service account for the application and for each Google Cloud API used by the application. Export and deploy the private keys used by the application. Use the service account with one Google Cloud API to interact with Google Cloud.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because creating a dedicated service account allows you to assign specific IAM roles, adhering to the principle of least privilege.
In contrast, Option A uses API keys which lack fine-grained authentication and authorization controls, while Option B relies on the default compute service account which typically has overly broad permissions.

## Pregunta 170

Contexto: [topics:726](#topics-726)
You are in the final stage of migrating an on-premises data center to Google Cloud. You are quickly approaching your deadline, and discover that a web API is running on a server slated for decommissioning. You need to recommend a solution to modernize this API while migrating to Google Cloud. The modernized web API must meet the following requirements:

• Autoscales during high traffic periods at the end of each month
• Written in Python 3.x
• Developers must be able to rapidly deploy new versions in response to frequent code changes

You want to minimize cost, effort, and operational overhead of this migration. What should you do?

**A.** Modernize and deploy the code on App Engine flexible environment.

**B.** Modernize and deploy the code on App Engine standard environment.

**C.** Deploy the modernized application to an n1-standard-1 Compute Engine instance.

**D.** Ask the development team to re-write the application to run as a Docker container on Google Kubernetes Engine.

**Respuesta de la fuente:** B

**Explicación:** App Engine Standard is the optimal choice because it natively supports Python 3.x, provides automatic scaling (including scaling down to zero instances in some configurations), and minimizes operational overhead by managing servers.
In contrast, App Engine Flexible runs on Compute Engine instances that cannot scale to zero, resulting in higher minimum costs.
Compute Engine requires manual management of VMs and scaling logic, while GKE introduces unnecessary infrastructure complexity for a simple web API.

## Pregunta 171

Contexto: [topics:726](#topics-726)
You are developing an application that consists of several microservices running in a Google Kubernetes Engine cluster. One microservice needs to connect to a third-party database running on-premises. You need to store credentials to the database and ensure that these credentials can be rotated while following security best practices. What should you do?

**A.** Store the credentials in a sidecar container proxy, and use it to connect to the third-party database.

**B.** Configure a service mesh to allow or restrict traffic from the Pods in your microservice to the database.

**C.** Store the credentials in an encrypted volume mount, and associate a Persistent Volume Claim with the client Pod.

**D.** Store the credentials as a Kubernetes Secret, and use the Cloud Key Management Service plugin to handle encryption and decryption.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it combines the standard Kubernetes mechanism for sensitive data (Secrets) with Cloud KMS to meet the requirement for encryption management and secure credential rotation. Storing credentials in a sidecar (A) or service mesh config (B) does not address secure storage and encryption, while using a Persistent Volume Claim (C) is unsuitable as secrets are ephemeral objects designed for immediate injection into pods, not long-term persistent block storage.

## Pregunta 172

Contexto: [topics:726](#topics-726)
You manage your company's ecommerce platform's payment system, which runs on Google Cloud. Your company must retain user logs for 1 year for internal auditing purposes and for 3 years to meet compliance requirements. You need to store new user logs on Google Cloud to minimize on-premises storage usage and ensure that they are easily searchable. You want to minimize effort while ensuring that the logs are stored correctly. What should you do?

**A.** Store the logs in a Cloud Storage bucket with bucket lock turned on.

**B.** Store the logs in a Cloud Storage bucket with a 3-year retention period.

**C.** Store the logs in Cloud Logging as custom logs with a custom retention period.

**D.** Store the logs in a Cloud Storage bucket with a 1-year retention period. After 1 year, move the logs to another bucket with a 2-year retention period.

**Respuesta de la fuente:** C

**Explicación:** Cloud Logging is designed for ingesting and searching log data, directly satisfying the requirement for logs to be easily searchable without additional indexing infrastructure. It supports custom retention periods up to 10 years (3650 days), allowing a single configuration to meet the 3-year compliance mandate with minimal effort.

In contrast, Cloud Storage options (A, B, D) store raw files that are not natively structured for efficient search queries, requiring extra processing or indexing tools to retrieve specific log entries.

## Pregunta 173

Contexto: [topics:726](#topics-726)
Your company has a new security initiative that requires all data stored in Google Cloud to be encrypted by customer-managed encryption keys. You plan to use Cloud Key Management Service (KMS) to configure access to the keys. You need to follow the "separation of duties" principle and Google-recommended best practices. What should you do? (Choose two.)

**A.** Provision Cloud KMS in its own project.

**B.** Do not assign an owner to the Cloud KMS project.

**C.** Provision Cloud KMS in the project where the keys are being used.

**D.** Grant the roles/cloudkms.admin role to the owner of the project where the keys from Cloud KMS are being used.

**E.** Grant an owner role for the Cloud KMS project to a different user than the owner of the project where the keys from Cloud KMS are being used.

**Respuesta de la fuente:** A, B

**Explicación:** Google Cloud best practices for separation of duties in KMS recommend provisioning keys in a dedicated project (A) to isolate key management from workload projects.
Furthermore, assigning no Owner role to the KMS project (B) prevents any single user from having unrestricted control over all cryptographic material, enforcing stricter access controls via specific IAM roles.

## Pregunta 174

Contexto: [topics:726](#topics-726)
You need to migrate a standalone Java application running in an on-premises Linux virtual machine (VM) to Google Cloud in a cost-effective manner. You decide not to take the lift-and-shift approach, and instead you plan to modernize the application by converting it to a container. How should you accomplish this task?

**A.** Use Migrate for Anthos to migrate the VM to your Google Kubernetes Engine (GKE) cluster as a container.

**B.** Export the VM as a raw disk and import it as an image. Create a Compute Engine instance from the Imported image.

**C.** Use Migrate for Compute Engine to migrate the VM to a Compute Engine instance, and use Cloud Build to convert it to a container.

**D.** Use Jib to build a Docker image from your source code, and upload it to Artifact Registry. Deploy the application in a GKE cluster, and test the application.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it directly addresses the requirement to modernize a Java application by building a container image from source code using Jib, which is the standard Google Cloud-recommended tool for this purpose. This approach ensures true containerization (immutable images) rather than just moving a VM.

Option A is incorrect because Migrate for Anthos performs a lift-and-shift of the entire VM into a Kubernetes pod, preserving the original OS and architecture; it does not refactor or re-containerize the application code itself.

## Pregunta 175

Contexto: [topics:726](#topics-726)
Your organization has recently begun an initiative to replatform their legacy applications onto Google Kubernetes Engine. You need to decompose a monolithic application into microservices. Multiple instances have read and write access to a configuration file, which is stored on a shared file system. You want to minimize the effort required to manage this transition, and you want to avoid rewriting the application code. What should you do?

**A.** Create a new Cloud Storage bucket, and mount it via FUSE in the container.

**B.** Create a new persistent disk, and mount the volume as a shared PersistentVolume.

**C.** Create a new Filestore instance, and mount the volume as an NFS PersistentVolume.

**D.** Create a new ConfigMap and volumeMount to store the contents of the configuration file.

**Respuesta de la fuente:** C

**Explicación:** Choice C is correct because Google Cloud Filestore provides a fully managed NFS service that supports ReadWriteMany access mode, allowing multiple pods to concurrently read and write to the same filesystem without code changes. The most tempting alternative, D (ConfigMap), is incorrect because ConfigMaps are mounted as read-only volumes within containers, preventing the application instances from writing updates to the configuration file as required.

## Pregunta 176

Contexto: [topics:726](#topics-726)
Your development team has built several Cloud Functions using Java along with corresponding integration and service tests. You are building and deploying the functions and launching the tests using Cloud Build. Your Cloud Build job is reporting deployment failures immediately after successfully validating the code. What should you do?

**A.** Check the maximum number of Cloud Function instances.

**B.** Verify that your Cloud Build trigger has the correct build parameters.

**C.** Retry the tests using the truncated exponential backoff polling strategy.

**D.** Verify that the Cloud Build service account is assigned the Cloud Functions Developer role.

**Respuesta de la fuente:** D

**Explicación:** The failure occurs immediately after code validation during deployment, indicating an authorization issue rather than a build configuration or runtime problem. Cloud Build requires the service account executing the job to have permissions to deploy resources; specifically, the Cloud Functions Developer role grants the necessary `cloudfunctions.functions.update` permission.
Other options like checking instance limits (A) or build parameters (B) would likely result in different error types or failures during the build phase, not specifically at the deployment step due to access denial.

## Pregunta 177

Contexto: [topics:726](#topics-726)
You manage a microservices application on Google Kubernetes Engine (GKE) using Istio. You secure the communication channels between your microservices by implementing an Istio AuthorizationPolicy, a Kubernetes NetworkPolicy, and mTLS on your GKE cluster. You discover that HTTP requests between two Pods to specific URLs fail, while other requests to other URLs succeed. What is the cause of the connection issue?

**A.** A Kubernetes NetworkPolicy resource is blocking HTTP traffic between the Pods.

**B.** The Pod initiating the HTTP requests is attempting to connect to the target Pod via an incorrect TCP port.

**C.** The Authorization Policy of your cluster is blocking HTTP requests for specific paths within your application.

**D.** The cluster has mTLS configured in permissive mode, but the Pod's sidecar proxy is sending unencrypted traffic in plain text.

**Respuesta de la fuente:** C

**Explicación:** The issue is isolated to specific URLs, which indicates a Layer 7 filtering mechanism. Istio AuthorizationPolicies operate at the HTTP layer and can explicitly deny requests based on URL paths, whereas Kubernetes NetworkPolicies only filter by IP/port (Layer 3/4) and would block all traffic between those pods if misconfigured. mTLS issues typically result in connection errors or handshake failures for all traffic, not selective path-based denials.

## Pregunta 178

Contexto: [topics:726](#topics-726)
You recently migrated an on-premises monolithic application to a microservices application on Google Kubernetes Engine (GKE). The application has dependencies on backend services on-premises, including a CRM system and a MySQL database that contains personally identifiable information (PII). The backend services must remain on-premises to meet regulatory requirements.

You established a Cloud VPN connection between your on-premises data center and Google Cloud. You notice that some requests from your microservices application on GKE to the backend services are failing due to latency issues caused by fluctuating bandwidth, which is causing the application to crash. How should you address the latency issues?

**A.** Use Memorystore to cache frequently accessed PII data from the on-premises MySQL database

**B.** Use Istio to create a service mesh that includes the microservices on GKE and the on-premises services

**C.** Increase the number of Cloud VPN tunnels for the connection between Google Cloud and the on-premises services

**D.** Decrease the network layer packet size by decreasing the Maximum Transmission Unit (MTU) value from its default value on Cloud VPN

**Respuesta de la fuente:** B

**Explicación:** Istio creates a service mesh that implements advanced traffic management features such as retries, timeouts, and circuit breaking, which directly mitigate application crashes caused by transient latency and network instability.
While increasing VPN tunnels (Choice C) may add bandwidth capacity, it does not provide the application-layer resilience mechanisms needed to handle fluctuating latency gracefully.

## Pregunta 179

Contexto: [topics:726](#topics-726)
Your company has deployed a new API to a Compute Engine instance. During testing, the API is not behaving as expected. You want to monitor the application over 12 hours to diagnose the problem within the application code without redeploying the application. Which tool should you use?

**A.** Cloud Trace

**B.** Cloud Monitoring

**C.** Cloud Debugger logpoints

**D.** Cloud Debugger snapshots

**Respuesta de la fuente:** C

**Explicación:** Cloud Debugger logpoints allow you to inspect variable values and capture runtime data at specific lines of code without redeploying the application or modifying source files. This directly satisfies the requirement to diagnose issues within the application code over an extended period while keeping the running environment stable.

Option A (Cloud Trace) is incorrect because it focuses on latency and distributed request flow rather than detailed variable inspection within the code logic. Option B (Cloud Monitoring) tracks system metrics and aggregates logs but does not provide the ability to dynamically inspect specific application variables at runtime without code changes.

## Pregunta 180

Contexto: [topics:726](#topics-726)
You are designing an application that consists of several microservices. Each microservice has its own RESTful API and will be deployed as a separate Kubernetes Service. You want to ensure that the consumers of these APIs aren't impacted when there is a change to your API, and also ensure that third-party systems aren't interrupted when new versions of the API are released. How should you configure the connection to the application following Google-recommended best practices?

**A.** Use an Ingress that uses the API's URL to route requests to the appropriate backend.

**B.** Leverage a Service Discovery system, and connect to the backend specified by the request.

**C.** Use multiple clusters, and use DNS entries to route requests to separate versioned backends.

**D.** Combine multiple versions in the same service, and then specify the API version in the POST request.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud recommends using an Ingress resource to manage external traffic routing based on URL paths, which allows for seamless backend updates without impacting API consumers. This approach decouples client requests from specific internal services and supports versioning via URL paths (e.g., /v1/), ensuring third-party systems remain uninterrupted during deployments.
Option B is incorrect because Service Discovery is primarily an internal cluster mechanism and does not solve the problem of routing external traffic to specific backends based on API versions.

## Pregunta 181

Contexto: [topics:726](#topics-726)
Your team is building an application for a financial institution. The application's frontend runs on Compute Engine, and the data resides in Cloud SQL and one Cloud Storage bucket. The application will collect data containing PII, which will be stored in the Cloud SQL database and the Cloud Storage bucket. You need to secure the PII data. What should you do?

**A.** 1. Create the relevant firewall rules to allow only the frontend to communicate with the Cloud SQL database
2. Using IAM, allow only the frontend service account to access the Cloud Storage bucket

**B.** 1. Create the relevant firewall rules to allow only the frontend to communicate with the Cloud SQL database
2. Enable private access to allow the frontend to access the Cloud Storage bucket privately

**C.** 1. Configure a private IP address for Cloud SQL
2. Use VPC-SC to create a service perimeter
3. Add the Cloud SQL database and the Cloud Storage bucket to the same service perimeter

**D.** 1. Configure a private IP address for Cloud SQL
2. Use VPC-SC to create a service perimeter
3. Add the Cloud SQL database and the Cloud Storage bucket to different service perimeters

**Respuesta de la fuente:** C

**Explicación:** VPC Service Controls (VPC-SC) are required to prevent data exfiltration from Google Cloud services, which is the primary risk for PII.
To ensure consistent access control and allow seamless interaction between the database and storage without breaking security boundaries, both resources must be placed within the same service perimeter.

## Pregunta 182

Contexto: [topics:726](#topics-726)
You are designing a chat room application that will host multiple rooms and retain the message history for each room. You have selected Firestore as your database. How should you represent the data in Firestore?

**A.** Create a collection for the rooms. For each room, create a document that lists the contents of the messages

[Imagen: sin descripción]
Imagen · choices[0].text · sin descripción
![Imagen original](imagenes/e156f5f917dfd2c51b0f.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Rooms
(Collection)
Room
(Document)
```

**B.** Create a collection for the rooms. For each room, create a collection that contains a document for each message

[Imagen: sin descripción]
Imagen · choices[1].text · sin descripción
![Imagen original](imagenes/1431cbd2274ab34285aa.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Rooms
(Collection)
Room
(Collection)
Message
(Document)
```

**C.** Create a collection for the rooms. For each room, create a document that contains a collection for documents, each of which contains a message.

[Imagen: sin descripción]
Imagen · choices[2].text · sin descripción
![Imagen original](imagenes/5b3d7b59f4174a6107be.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Rooms
(Collection)
Room
(Document)
Messages
(Collection)
Message
(Document)
```

**D.** Create a collection for the rooms, and create a document for each room. Create a separate collection for messages, with one document per message. Each room’s document contains a list of references to the messages.

[Imagen: sin descripción]
Imagen · choices[3].text · sin descripción
![Imagen original](imagenes/32e4ebea0da7c651cc2c.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Messages
Message
(Document)
(Collection)
Rooms
(Collection)
Room
(Document)
```

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Firestore requires collections to exist within documents; you cannot place a collection directly inside another collection.
Using subcollections allows messages to be associated with specific rooms while bypassing the 1 MiB document size limit that would restrict Option A.
Option D is less ideal because maintaining a list of references in the room document for every message creates unnecessary write overhead and potential consistency issues during high-volume chat activity.

## Pregunta 183

Contexto: [topics:726](#topics-726)
You are developing an application that will handle requests from end users. You need to secure a Cloud Function called by the application to allow authorized end users to authenticate to the function via the application while restricting access to unauthorized users. You will integrate Google Sign-In as part of the solution and want to follow Google-recommended best practices. What should you do?

**A.** Deploy from a source code repository and grant users the roles/cloudfunctions.viewer role.

**B.** Deploy from a source code repository and grant users the roles/cloudfunctions.invoker role

**C.** Deploy from your local machine using gcloud and grant users the roles/cloudfunctions.admin role

**D.** Deploy from your local machine using gcloud and grant users the roles/cloudfunctions.developer role

**Respuesta de la fuente:** B

**Explicación:** To secure the function for authorized end users while restricting unauthorized access, you must grant the `roles/cloudfunctions.invoker` role, which provides the specific permission to invoke the function.
Deploying from a source code repository aligns with Google-recommended best practices for CI/CD automation and auditability.
The 'viewer' role (A) is insufficient as it only allows reading metadata, while 'admin' (C) and 'developer' (D) roles grant excessive privileges beyond mere invocation.

## Pregunta 184

Contexto: [topics:726](#topics-726)
You are running a web application on Google Kubernetes Engine that you inherited. You want to determine whether the application is using libraries with known vulnerabilities or is vulnerable to XSS attacks. Which service should you use?

**A.** Google Cloud Armor

**B.** Debugger

**C.** Web Security Scanner

**D.** Error Reporting

**Respuesta de la fuente:** C

**Explicación:** Google Cloud Web Security Scanner automatically crawls deployed web applications to detect common vulnerabilities, including Cross-Site Scripting (XSS) and outdated libraries with known security issues. While tools like Trivy or Grype scan container images for library vulnerabilities offline, Web Security Scanner provides runtime analysis specifically designed for the 'vulnerable to XSS' requirement in a live GKE environment.

## Pregunta 185

Contexto: [topics:726](#topics-726)
You are building a highly available and globally accessible application that will serve static content to users. You need to configure the storage and serving components. You want to minimize management overhead and latency while maximizing reliability for users. What should you do?

**A.** 1. Create a managed instance group. Replicate the static content across the virtual machines (VMs)
2. Create an external HTTP(S) load balancer.
3. Enable Cloud CDN, and send traffic to the managed instance group.

**B.** 1. Create an unmanaged instance group. Replicate the static content across the VMs.
2. Create an external HTTP(S) load balancer
3. Enable Cloud CDN, and send traffic to the unmanaged instance group.

**C.** 1. Create a Standard storage class, regional Cloud Storage bucket. Put the static content in the bucket
2. Reserve an external IP address, and create an external HTTP(S) load balancer
3. Enable Cloud CDN, and send traffic to your backend bucket

**D.** 1. Create a Standard storage class, multi-regional Cloud Storage bucket. Put the static content in the bucket.
2. Reserve an external IP address, and create an external HTTP(S) load balancer.
3. Enable Cloud CDN, and send traffic to your backend bucket.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because a multi-regional Cloud Storage bucket provides global availability and low latency for static content without the overhead of managing VMs, satisfying the requirements for minimized management and maximized reliability. Option C is incorrect because a regional bucket restricts data to a single geographic area, increasing latency for users outside that region compared to the globally distributed nature of multi-regional storage.

## Pregunta 186

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
For this question refer to the HipLocal case study.

HipLocal wants to reduce the latency of their services for users in global locations. They have created read replicas of their database in locations where their users reside and configured their service to read traffic using those replicas. How should they further reduce latency for all database interactions with the least amount of effort?

**A.** Migrate the database to Bigtable and use it to serve all global user traffic.

**B.** Migrate the database to Cloud Spanner and use it to serve all global user traffic.

**C.** Migrate the database to Firestore in Datastore mode and use it to serve all global user traffic.

**D.** Migrate the services to Google Kubernetes Engine and use a load balancer service to better scale the application.

**Respuesta de la fuente:** B

**Explicación:** HipLocal currently uses MySQL, a relational database. To reduce global latency with the least effort while maintaining compatibility, migrating to Cloud Spanner is the optimal choice because it is a globally distributed, horizontally scalable relational database that supports standard SQL and ACID transactions.

Firestore (Option C) is NoSQL and would require significant schema refactoring, Bigtable (Option A) lacks native relational features, and Kubernetes (Option D) addresses application scaling rather than database latency.

## Pregunta 187

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
For this question, refer to the HipLocal case study.

Which Google Cloud product addresses HipLocal’s business requirements for service level indicators and objectives?

**A.** Cloud Profiler

**B.** Cloud Monitoring

**C.** Cloud Trace

**D.** Cloud Logging

**Respuesta de la fuente:** B

**Explicación:** Cloud Monitoring is the correct product because it provides the tools to define, track, and alert on Service Level Indicators (SLIs) and Objectives (SLOs), which are core metrics for service reliability.

While Cloud Logging stores event data and Cloud Trace analyzes latency, neither directly manages SLO compliance dashboards or alerts as their primary function.

## Pregunta 188

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
For this question, refer to the HipLocal case study.

A recent security audit discovers that HipLocal’s database credentials for their Compute Engine-hosted MySQL databases are stored in plain text on persistent disks. HipLocal needs to reduce the risk of these credentials being stolen. What should they do?

**A.** Create a service account and download its key. Use the key to authenticate to Cloud Key Management Service (KMS) to obtain the database credentials.

**B.** Create a service account and download its key. Use the key to authenticate to Cloud Key Management Service (KMS) to obtain a key used to decrypt the database credentials.

**C.** Create a service account and grant it the roles/iam.serviceAccountUser role. Impersonate as this account and authenticate using the Cloud SQL Proxy.

**D.** Grant the roles/secretmanager.secretAccessor role to the Compute Engine service account. Store and access the database credentials with the Secret Manager API.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Google Cloud Secret Manager is the dedicated service for securely storing and accessing sensitive data like database credentials, eliminating the need to store them in plain text on disks. By granting the secretmanager.secretAccessor role to the Compute Engine instance's service account, the application can retrieve secrets programmatically via IAM without managing long-lived keys.

Options A and B are incorrect because downloading service account keys violates security best practices by introducing the risk of key exposure; keys should not be stored on VMs when identity-based access is available. Option C is irrelevant to the core problem, as using Cloud SQL Proxy addresses connection encryption but does not solve the issue of credentials being stored in plain text.

## Pregunta 189

Contexto: [topics:726](#topics-726)
Contexto: [case_studies:117](#case_studies-117)
For this question, refer to the HipLocal case study.

HipLocal is expanding into new locations. They must capture additional data each time the application is launched in a new European country. This is causing delays in the development process due to constant schema changes and a lack of environments for conducting testing on the application changes. How should they resolve the issue while meeting the business requirements?

**A.** Create new Cloud SQL instances in Europe and North America for testing and deployment. Provide developers with local MySQL instances to conduct testing on the application changes.

**B.** Migrate data to Bigtable. Instruct the development teams to use the Cloud SDK to emulate a local Bigtable development environment.

**C.** Move from Cloud SQL to MySQL hosted on Compute Engine. Replicate hosts across regions in the Americas and Europe. Provide developers with local MySQL instances to conduct testing on the application changes.

**D.** Migrate data to Firestore in Native mode and set up instances in Europe and North America. Instruct the development teams to use the Cloud SDK to emulate a local Firestore in Native mode development environment.

**Respuesta de la fuente:** D

**Explicación:** Firestore in Native mode is a NoSQL document database that handles constant schema changes flexibly without the rigid structure of relational databases like Cloud SQL or MySQL. It provides the required multi-region support for GDPR compliance and allows developers to emulate the database locally, resolving the testing environment delays. Option A is incorrect because it retains the problematic rigid schema of MySQL and increases infrastructure management overhead.

## Pregunta 190

Contexto: [topics:726](#topics-726)
You are writing from a Go application to a Cloud Spanner database. You want to optimize your application’s performance using Google-recommended best practices. What should you do?

**A.** Write to Cloud Spanner using Cloud Client Libraries.

**B.** Write to Cloud Spanner using Google API Client Libraries

**C.** Write to Cloud Spanner using a custom gRPC client library.

**D.** Write to Cloud Spanner using a third-party HTTP client library.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Client Libraries are the officially recommended way to access Google Cloud services programmatically, as they handle authentication, retries, and versioning automatically while providing idiomatic language support.
Option B (Google API Client Libraries) is intended for general Google APIs (like YouTube or Drive) rather than core infrastructure services like Spanner, where the specialized Cloud Client Library offers better performance and feature parity.

## Pregunta 191

Contexto: [topics:726](#topics-726)
You have an application deployed in Google Kubernetes Engine (GKE). You need to update the application to make authorized requests to Google Cloud managed services. You want this to be a one-time setup, and you need to follow security best practices of auto-rotating your security keys and storing them in an encrypted store. You already created a service account with appropriate access to the Google Cloud service. What should you do next?

**A.** Assign the Google Cloud service account to your GKE Pod using Workload Identity.

**B.** Export the Google Cloud service account, and share it with the Pod as a Kubernetes Secret.

**C.** Export the Google Cloud service account, and embed it in the source code of the application.

**D.** Export the Google Cloud service account, and upload it to HashiCorp Vault to generate a dynamic service account for your application.

**Respuesta de la fuente:** A

**Explicación:** Workload Identity bridges Kubernetes service accounts with Google Cloud IAM, enabling GKE pods to automatically obtain short-lived access tokens for Google services without managing static credentials. This approach inherently supports auto-rotation and eliminates the security risks of storing long-term keys in Secrets or code, satisfying the requirement for a one-time, secure setup.
Option B is incorrect because storing service account key files as Kubernetes Secrets requires manual key management and rotation, violating the best practice of avoiding static credential storage.

## Pregunta 192

Contexto: [topics:726](#topics-726)
You are planning to deploy hundreds of microservices in your Google Kubernetes Engine (GKE) cluster. How should you secure communication between the microservices on GKE using a managed service?

**A.** Use global HTTP(S) Load Balancing with managed SSL certificates to protect your services

**B.** Deploy open source Istio in your GKE cluster, and enable mTLS in your Service Mesh

**C.** Install cert-manager on GKE to automatically renew the SSL certificates.

**D.** Install Anthos Service Mesh, and enable mTLS in your Service Mesh.

**Respuesta de la fuente:** D

**Explicación:** The question specifically requests a solution using a **managed service**. Anthos Service Mesh is Google Cloud's fully managed offering for Istio, providing automated operations, security patches, and simplified mTLS enforcement, whereas deploying open-source Istio (Option B) requires significant manual maintenance and is not considered a managed service in this context. Options A and C address external ingress traffic or certificate lifecycle management rather than securing internal east-west communication between hundreds of microservices.

## Pregunta 193

Contexto: [topics:726](#topics-726)
You are developing an application that will store and access sensitive unstructured data objects in a Cloud Storage bucket. To comply with regulatory requirements, you need to ensure that all data objects are available for at least 7 years after their initial creation. Objects created more than 3 years ago are accessed very infrequently (less than once a year). You need to configure object storage while ensuring that storage cost is optimized. What should you do? (Choose two.)

**A.** Set a retention policy on the bucket with a period of 7 years.

**B.** Use IAM Conditions to provide access to objects 7 years after the object creation date.

**C.** Enable Object Versioning to prevent objects from being accidentally deleted for 7 years after object creation.

**D.** Create an object lifecycle policy on the bucket that moves objects from Standard Storage to Archive Storage after 3 years.

**E.** Implement a Cloud Function that checks the age of each object in the bucket and moves the objects older than 3 years to a second bucket with the Archive Storage class. Use Cloud Scheduler to trigger the Cloud Function on a daily schedule.

**Respuesta de la fuente:** A, D

**Explicación:** Option A is correct because Cloud Storage bucket lock retention policies enforce a minimum retention period, ensuring regulatory compliance by preventing object deletion for the required 7 years.
Option D is correct because lifecycle rules automatically transition objects to Archive storage after 3 years, which optimizes costs for infrequently accessed data without manual intervention.
The tempting alternative E is wrong because it reinvents built-in functionality; Cloud Storage handles tier transitions natively via lifecycle policies, making custom Cloud Functions unnecessary and less efficient.

## Pregunta 194

Contexto: [topics:726](#topics-726)
You are developing an application using different microservices that must remain internal to the cluster. You want the ability to configure each microservice with a specific number of replicas. You also want the ability to address a specific microservice from any other microservice in a uniform way, regardless of the number of replicas the microservice scales to. You plan to implement this solution on Google Kubernetes Engine. What should you do?

**A.** Deploy each microservice as a Deployment. Expose the Deployment in the cluster using a Service, and use the Service DNS name to address it from other microservices within the cluster.

**B.** Deploy each microservice as a Deployment. Expose the Deployment in the cluster using an Ingress, and use the Ingress IP address to address the Deployment from other microservices within the cluster.

**C.** Deploy each microservice as a Pod. Expose the Pod in the cluster using a Service, and use the Service DNS name to address the microservice from other microservices within the cluster.

**D.** Deploy each microservice as a Pod. Expose the Pod in the cluster using an Ingress, and use the Ingress IP address to address the Pod from other microservices within the cluster.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because a Deployment manages the desired number of replicas for stateless workloads, while a Service provides a stable DNS name and load-balancing layer that abstracts away individual Pod IPs. This ensures uniform internal addressing regardless of scaling events. Option C is incorrect because Pods are ephemeral and lack built-in replica management; Option B uses an Ingress, which is designed for external traffic routing rather than internal service discovery.

## Pregunta 195

Contexto: [topics:726](#topics-726)
You are building an application that uses a distributed microservices architecture. You want to measure the performance and system resource utilization in one of the microservices written in Java. What should you do?

**A.** Instrument the service with Cloud Profiler to measure CPU utilization and method-level execution times in the service.

**B.** Instrument the service with Debugger to investigate service errors.

**C.** Instrument the service with Cloud Trace to measure request latency.

**D.** Instrument the service with OpenCensus to measure service latency, and write custom metrics to Cloud Monitoring.

**Respuesta de la fuente:** A

**Explicación:** The question specifically asks to measure performance and system resource utilization (such as CPU usage) at the method level. Cloud Profiler is designed for this purpose, providing detailed insights into CPU profiles, memory allocation, and lock contention within Java applications.

Cloud Trace (Option C) focuses on request latency and distributed tracing rather than low-level resource consumption, while Debugger (Option B) is an interactive tool for investigating specific errors, not for continuous performance monitoring.

## Pregunta 196

Contexto: [topics:726](#topics-726)
Your team is responsible for maintaining an application that aggregates news articles from many different sources. Your monitoring dashboard contains publicly accessible real-time reports and runs on a Compute Engine instance as a web application. External stakeholders and analysts need to access these reports via a secure channel without authentication. How should you configure this secure channel?

**A.** Add a public IP address to the instance. Use the service account key of the instance to encrypt the traffic.

**B.** Use Cloud Scheduler to trigger Cloud Build every hour to create an export from the reports. Store the reports in a public Cloud Storage bucket.

**C.** Add an HTTP(S) load balancer in front of the monitoring dashboard. Configure Identity-Aware Proxy to secure the communication channel.

**D.** Add an HTTP(S) load balancer in front of the monitoring dashboard. Set up a Google-managed SSL certificate on the load balancer for traffic encryption.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it establishes an encrypted HTTPS connection via a Google-managed SSL certificate on the load balancer, ensuring secure data in transit without requiring user authentication. Option C is incorrect because Identity-Aware Proxy (IAP) enforces authentication and authorization, which directly contradicts the requirement for access 'without authentication'.

## Pregunta 197

Contexto: [topics:726](#topics-726)
You are planning to add unit tests to your application. You need to be able to assert that published Pub/Sub messages are processed by your subscriber in order. You want the unit tests to be cost-effective and reliable. What should you do?

**A.** Implement a mocking framework.

**B.** Create a topic and subscription for each tester.

**C.** Add a filter by tester to the subscription.

**D.** Use the Pub/Sub emulator.

**Respuesta de la fuente:** D

**Explicación:** The Pub/Sub emulator is the correct choice because it provides a local, cost-free environment for unit testing that isolates the application from external service dependencies, ensuring reliability and speed.

Option B (creating topics/subscriptions per tester) is incorrect because managing real cloud resources for every test run incurs unnecessary costs and introduces latency/instability from network calls, making it unsuitable for efficient unit testing.

## Pregunta 198

Contexto: [topics:726](#topics-726)
You have an application deployed in Google Kubernetes Engine (GKE) that reads and processes Pub/Sub messages. Each Pod handles a fixed number of messages per minute. The rate at which messages are published to the Pub/Sub topic varies considerably throughout the day and week, including occasional large batches of messages published at a single moment.

You want to scale your GKE Deployment to be able to process messages in a timely manner. What GKE feature should you use to automatically adapt your workload?

**A.** Vertical Pod Autoscaler in Auto mode

**B.** Vertical Pod Autoscaler in Recommendation mode

**C.** Horizontal Pod Autoscaler based on an external metric

**D.** Horizontal Pod Autoscaler based on resources utilization

**Respuesta de la fuente:** C

**Explicación:** Pub/Sub is an external service to the GKE cluster, so its queue depth or message rate constitutes an external metric rather than a standard resource utilization metric like CPU or memory. Using HPA with an external metric allows scaling directly based on the backlog of messages in Pub/Sub, ensuring timely processing even before pod resource usage spikes. Option D (HPA based on resources) is reactive and less effective here because pods might not hit high CPU/memory thresholds until they are already overwhelmed by the message burst, leading to latency.

## Pregunta 199

Contexto: [topics:726](#topics-726)
You are using Cloud Run to host a web application. You need to securely obtain the application project ID and region where the application is running and display this information to users. You want to use the most performant approach. What should you do?

**A.** Use HTTP requests to query the available metadata server at the http://metadata.google.internal/ endpoint with the Metadata-Flavor: Google header.

**B.** In the Google Cloud console, navigate to the Project Dashboard and gather configuration details. Navigate to the Cloud Run “Variables & Secrets” tab, and add the desired environment variables in Key:Value format.

**C.** In the Google Cloud console, navigate to the Project Dashboard and gather configuration details. Write the application configuration information to Cloud Run's in-memory container filesystem.

**D.** Make an API call to the Cloud Asset Inventory API from the application and format the request to include instance metadata.

**Respuesta de la fuente:** A

**Explicación:** The Cloud Run metadata server provides the most performant and secure way to retrieve instance-specific information like project ID and region without external network hops or manual configuration. Querying the local http://metadata.google.internal/ endpoint ensures low latency and automatic availability within the container environment.

Option B is incorrect because manually adding configuration via the console creates maintenance overhead and lacks the dynamic, zero-config performance of the metadata server.

## Pregunta 200

Contexto: [topics:726](#topics-726)
You need to deploy resources from your laptop to Google Cloud using Terraform. Resources in your Google Cloud environment must be created using a service account. Your Cloud Identity has the roles/iam.serviceAccountTokenCreator Identity and Access Management (IAM) role and the necessary permissions to deploy the resources using Terraform. You want to set up your development environment to deploy the desired resources following Google-recommended best practices. What should you do?

**A.** 1. Download the service account’s key file in JSON format, and store it locally on your laptop.
2. Set the GOOGLE_APPLICATION_CREDENTIALS environment variable to the path of your downloaded key file.

**B.** 1. Run the following command from a command line: gcloud config set auth/impersonate_service_account service-account-name@project.iam.gserviceacccount.com.
2. Set the GOOGLE_OAUTH_ACCESS_TOKEN environment variable to the value that is returned by the gcloud auth print-access-token command.

**C.** 1. Run the following command from a command line: gcloud auth application-default login.
2. In the browser window that opens, authenticate using your personal credentials.

**D.** 1. Store the service account's key file in JSON format in Hashicorp Vault.
2. Integrate Terraform with Vault to retrieve the key file dynamically, and authenticate to Vault using a short-lived access token.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it leverages service account impersonation via short-lived access tokens, which aligns with Google Cloud security best practices by avoiding the creation and storage of long-lived static service account keys. The user already possesses the `roles/iam.serviceAccountTokenCreator` role, enabling them to generate these temporary credentials securely.

Option A is the most tempting alternative but is incorrect because downloading and storing JSON key files locally creates a significant security risk due to the potential for credential leakage or unauthorized use, violating the principle of least privilege and secret management best practices.

## Pregunta 201

Contexto: [topics:726](#topics-726)
Your company uses Cloud Logging to manage large volumes of log data. You need to build a real-time log analysis architecture that pushes logs to a third-party application for processing. What should you do?

**A.** Create a Cloud Logging log export to Pub/Sub.

**B.** Create a Cloud Logging log export to BigQuery.

**C.** Create a Cloud Logging log export to Cloud Storage.

**D.** Create a Cloud Function to read Cloud Logging log entries and send them to the third-party application.

**Respuesta de la fuente:** A

**Explicación:** Cloud Logging supports direct exports to Pub/Sub, which is the standard mechanism for real-time streaming of log data to external systems. This allows a third-party application to subscribe to the topic and process logs as they arrive, meeting the requirement for real-time push.
BigQuery (B) and Cloud Storage (C) are batch-oriented sinks suitable for long-term storage or historical analysis, not real-time delivery. Option D introduces unnecessary custom complexity when a native, managed export feature exists.

## Pregunta 202

Contexto: [topics:726](#topics-726)
You are developing a new public-facing application that needs to retrieve specific properties in the metadata of users’ objects in their respective Cloud Storage buckets. Due to privacy and data residency requirements, you must retrieve only the metadata and not the object data. You want to maximize the performance of the retrieval process. How should you retrieve the metadata?

**A.** Use the patch method.

**B.** Use the compose method.

**C.** Use the copy method.

**D.** Use the fields request parameter.

**Respuesta de la fuente:** D

**Explicación:** Using the `fields` request parameter (Response Fields) allows you to selectively retrieve only specific metadata properties, minimizing payload size and maximizing performance while adhering to privacy requirements by excluding object data.
Methods like `patch`, `compose`, or `copy` are used for modifying, combining, or duplicating objects, not for efficient read-only retrieval of specific metadata fields.

## Pregunta 203

Contexto: [topics:726](#topics-726)
You are deploying a microservices application to Google Kubernetes Engine (GKE) that will broadcast livestreams. You expect unpredictable traffic patterns and large variations in the number of concurrent users. Your application must meet the following requirements:

•	Scales automatically during popular events and maintains high availability
•	Is resilient in the event of hardware failures

How should you configure the deployment parameters? (Choose two.)

**A.** Distribute your workload evenly using a multi-zonal node pool.

**B.** Distribute your workload evenly using multiple zonal node pools.

**C.** Use cluster autoscaler to resize the number of nodes in the node pool, and use a Horizontal Pod Autoscaler to scale the workload.

**D.** Create a managed instance group for Compute Engine with the cluster nodes. Configure autoscaling rules for the managed instance group.

**E.** Create alerting policies in Cloud Monitoring based on GKE CPU and memory utilization. Ask an on-duty engineer to scale the workload by executing a script when CPU and memory usage exceed predefined thresholds.

**Respuesta de la fuente:** A, C

**Explicación:** To meet the high availability and resilience requirements against hardware failures, you must distribute workloads across multiple zones using a multi-zonal node pool (A), which automatically places nodes uniformly across available zones.

For handling unpredictable traffic and scaling demands, you need both Cluster Autoscaler to adjust the number of nodes based on resource needs and Horizontal Pod Autoscaler to scale the actual application pods (C).

Option B is incorrect because managing multiple separate zonal node pools is more complex and less robust for uniform distribution than a single multi-zonal pool. Option D is wrong because Managed Instance Groups are used for standard Compute Engine VMs, not Kubernetes clusters.

## Pregunta 204

Contexto: [topics:726](#topics-726)
You work at a rapidly growing financial technology startup. You manage the payment processing application written in Go and hosted on Cloud Run in the Singapore region (asia-southeast1). The payment processing application processes data stored in a Cloud Storage bucket that is also located in the Singapore region.

The startup plans to expand further into the Asia Pacific region. You plan to deploy the Payment Gateway in Jakarta, Hong Kong, and Taiwan over the next six months. Each location has data residency requirements that require customer data to reside in the country where the transaction was made. You want to minimize the cost of these deployments. What should you do?

**A.** Create a Cloud Storage bucket in each region, and create a Cloud Run service of the payment processing application in each region.

**B.** Create a Cloud Storage bucket in each region, and create three Cloud Run services of the payment processing application in the Singapore region.

**C.** Create three Cloud Storage buckets in the Asia multi-region, and create three Cloud Run services of the payment processing application in the Singapore region.

**D.** Create three Cloud Storage buckets in the Asia multi-region, and create three Cloud Run revisions of the payment processing application in the Singapore region.

**Respuesta de la fuente:** A

**Explicación:** Answer A is correct because data residency requirements mandate that customer data physically resides within the specific country of origin. Creating regional Cloud Storage buckets in Jakarta, Hong Kong, and Taiwan ensures compliance, while deploying Cloud Run services in those same regions minimizes latency and avoids cross-region egress costs.

Choice B is incorrect because keeping Cloud Run services in Singapore would force data transfer across borders to process local transactions, violating strict residency mandates. Choices C and D are wrong because multi-regions do not guarantee data placement in specific countries required by law.

## Pregunta 205

Contexto: [topics:726](#topics-726)
You recently joined a new team that has a Cloud Spanner database instance running in production. Your manager has asked you to optimize the Spanner instance to reduce cost while maintaining high reliability and availability of the database. What should you do?

**A.** Use Cloud Logging to check for error logs, and reduce Spanner processing units by small increments until you find the minimum capacity required.

**B.** Use Cloud Trace to monitor the requests per sec of incoming requests to Spanner, and reduce Spanner processing units by small increments until you find the minimum capacity required.

**C.** Use Cloud Monitoring to monitor the CPU utilization, and reduce Spanner processing units by small increments until you find the minimum capacity required.

**D.** Use Snapshot Debugger to check for application errors, and reduce Spanner processing units by small increments until you find the minimum capacity required.

**Respuesta de la fuente:** C

**Explicación:** According to Google Cloud documentation on Spanner compute capacity, you should use Cloud Monitoring to observe CPU utilization metrics. This metric directly indicates whether the instance is over-provisioned or under-provisioned, allowing for safe incremental adjustments.
Option B is incorrect because Cloud Trace is designed for latency and bottleneck analysis in application code, not for monitoring aggregate system load like requests per second for capacity planning.

## Pregunta 206

Contexto: [topics:726](#topics-726)
You recently deployed a Go application on Google Kubernetes Engine (GKE). The operations team has noticed that the application's CPU usage is high even when there is low production traffic. The operations team has asked you to optimize your application's CPU resource consumption. You want to determine which Go functions consume the largest amount of CPU. What should you do?

**A.** Deploy a Fluent Bit daemonset on the GKE cluster to log data in Cloud Logging. Analyze the logs to get insights into your application code’s performance.

**B.** Create a custom dashboard in Cloud Monitoring to evaluate the CPU performance metrics of your application.

**C.** Connect to your GKE nodes using SSH. Run the top command on the shell to extract the CPU utilization of your application.

**D.** Modify your Go application to capture profiling data. Analyze the CPU metrics of your application in flame graphs in Profiler.

**Respuesta de la fuente:** D

**Explicación:** To identify which specific Go functions are consuming the most CPU, you need code-level profiling rather than infrastructure-level metrics. Option D is correct because Google Cloud Profiler integrates with Go applications to capture CPU profiles and visualize them as flame graphs, highlighting the exact call stacks and functions responsible for high CPU usage.

Option B (Cloud Monitoring dashboards) provides aggregate system metrics but does not break down CPU consumption by individual application functions, making it insufficient for this specific optimization goal.

## Pregunta 207

Contexto: [topics:726](#topics-726)
Your team manages a Google Kubernetes Engine (GKE) cluster where an application is running. A different team is planning to integrate with this application. Before they start the integration, you need to ensure that the other team cannot make changes to your application, but they can deploy the integration on GKE. What should you do?

**A.** Using Identity and Access Management (IAM), grant the Viewer IAM role on the cluster project to the other team.

**B.** Create a new GKE cluster. Using Identity and Access Management (IAM), grant the Editor role on the cluster project to the other team.

**C.** Create a new namespace in the existing cluster. Using Identity and Access Management (IAM), grant the Editor role on the cluster project to the other team.

**D.** Create a new namespace in the existing cluster. Using Kubernetes role-based access control (RBAC), grant the Admin role on the new namespace to the other team.

**Respuesta de la fuente:** D

**Explicación:** Create a new namespace in the existing cluster. Using Kubernetes role-based access control (RBAC), grant the Admin role on the new namespace to the other team.

## Pregunta 208

Contexto: [topics:726](#topics-726)
You have recently instrumented a new application with OpenTelemetry, and you want to check the latency of your application requests in Trace. You want to ensure that a specific request is always traced. What should you do?

**A.** Wait 10 minutes, then verify that Trace captures those types of requests automatically.

**B.** Write a custom script that sends this type of request repeatedly from your dev project.

**C.** Use the Trace API to apply custom attributes to the trace.

**D.** Add the X-Cloud-Trace-Context header to the request with the appropriate parameters.

**Respuesta de la fuente:** D

**Explicación:** To guarantee that a specific request is traced in Google Cloud Trace, you must include the X-Cloud-Trace-Context header with valid trace and span IDs.
This mechanism explicitly overrides default sampling policies for that individual request, ensuring it is recorded regardless of the configured sampling rate.
The most tempting alternative (C) is incorrect because adding custom attributes modifies data within an existing trace but does not influence whether a new request is sampled or included in the trace dataset.

## Pregunta 209

Contexto: [topics:726](#topics-726)
You are trying to connect to your Google Kubernetes Engine (GKE) cluster using kubectl from Cloud Shell. You have deployed your GKE cluster with a public endpoint. From Cloud Shell, you run the following command:

[Imagen: sin descripción]

You notice that the kubectl commands time out without returning an error message. What is the most likely cause of this issue?
Imagen · question_text · sin descripción
![Imagen original](imagenes/5b2977f8b12e60559402.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
gcloud container clusters get-credentials <cluster-name> \
-zone <zone> --project <project-name> \
```

**A.** Your user account does not have privileges to interact with the cluster using kubectl.

**B.** Your Cloud Shell external IP address is not part of the authorized networks of the cluster.

**C.** The Cloud Shell is not part of the same VPC as the GKE cluster.

**D.** A VPC firewall is blocking access to the cluster’s endpoint.

**Respuesta de la fuente:** B

**Explicación:** When connecting to a GKE cluster, a timeout (rather than an immediate connection refused or permission denied error) typically indicates that the request packets are being dropped before reaching the API server. In private clusters or those with master authorized networks configured, the cloud provider drops traffic from unauthorized IP addresses silently, resulting in a timeout. Therefore, if the Cloud Shell's external IP is not listed in the authorized networks, the connection will time out.

Option A is incorrect because insufficient permissions would result in a 'Forbidden' or 'Unauthorized' HTTP error after establishing a TCP connection, not a timeout. Option C is incorrect because connectivity to a public endpoint does not require the client to be in the same VPC; it only requires network reachability and authorization. Option D is less likely than B because Cloud Shell is a Google-managed service with implicit egress rules, making authorized network misconfiguration the standard cause for this specific timeout behavior.

## Pregunta 210

Contexto: [topics:726](#topics-726)
You are developing a web application that contains private images and videos stored in a Cloud Storage bucket. Your users are anonymous and do not have Google Accounts. You want to use your application-specific logic to control access to the images and videos. How should you configure access?

**A.** Cache each web application user's IP address to create a named IP table using Google Cloud Armor. Create a Google Cloud Armor security policy that allows users to access the backend bucket.

**B.** Grant the Storage Object Viewer IAM role to allUsers. Allow users to access the bucket after authenticating through your web application.

**C.** Configure Identity-Aware Proxy (IAP) to authenticate users into the web application. Allow users to access the bucket after authenticating through IAP.

**D.** Generate a signed URL that grants read access to the bucket. Allow users to access the URL after authenticating through your web application.

**Respuesta de la fuente:** D

**Explicación:** Signed URLs provide time-limited, secure access to private objects without exposing the bucket publicly or requiring user authentication with Google Accounts. This allows the web application's backend logic to generate these URLs dynamically based on specific business rules, satisfying the requirement for application-controlled access. Option B is incorrect because granting access to 'allUsers' makes the bucket public, which violates the privacy requirement and prevents granular application-level control.

## Pregunta 211

Contexto: [topics:726](#topics-726)
You need to configure a Deployment on Google Kubernetes Engine (GKE). You want to include a check that verifies that the containers can connect to the database. If the Pod is failing to connect, you want a script on the container to run to complete a graceful shutdown. How should you configure the Deployment?

**A.** Create two jobs: one that checks whether the container can connect to the database, and another that runs the shutdown script if the Pod is failing.

**B.** Create the Deployment with a livenessProbe for the container that will fail if the container can't connect to the database. Configure a Prestop lifecycle handler that runs the shutdown script if the container is failing.

**C.** Create the Deployment with a PostStart lifecycle handler that checks the service availability. Configure a PreStop lifecycle handler that runs the shutdown script if the container is failing.

**D.** Create the Deployment with an initContainer that checks the service availability. Configure a Prestop lifecycle handler that runs the shutdown script if the Pod is failing.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because a livenessProbe continuously monitors the container's health, specifically checking database connectivity here; if it fails, Kubernetes terminates the container. The preStop lifecycle hook executes before termination to allow for a graceful shutdown script execution.
Option A is incorrect because Jobs are separate resources not designed for continuous in-container health monitoring or automated graceful shutdown triggers within the main Deployment lifecycle.

## Pregunta 212

Contexto: [topics:726](#topics-726)
You are responsible for deploying a new API. That API will have three different URL paths:

•	https://yourcompany.com/students
•	https://yourcompany.com/teachers
•	https://yourcompany.com/classes

You need to configure each API URL path to invoke a different function in your code. What should you do?

**A.** Create one Cloud Function as a backend service exposed using an HTTPS load balancer.

**B.** Create three Cloud Functions exposed directly.

**C.** Create one Cloud Function exposed directly.

**D.** Create three Cloud Functions as three backend services exposed using an HTTPS load balancer.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Cloud Functions exposed directly via HTTPS triggers use auto-generated global unique hostnames (e.g., region-project.cloudfunctions.net/function-name), which cannot be mapped to a single custom domain path structure like yourcompany.com/students. To serve multiple paths under one custom domain, you must use an HTTPS Load Balancer as the entry point to handle DNS and perform path-based routing to the individual Cloud Function backend services.
Option B is incorrect because each directly exposed function gets its own distinct URL endpoint; you cannot configure three separate functions to respond to different paths on a single custom domain name without an intermediary load balancer.

## Pregunta 213

Contexto: [topics:726](#topics-726)
You are deploying a microservices application to Google Kubernetes Engine (GKE). The application will receive daily updates. You expect to deploy a large number of distinct containers that will run on the Linux operating system (OS). You want to be alerted to any known OS vulnerabilities in the new containers. You want to follow Google-recommended best practices. What should you do?

**A.** Use the gcloud CLI to call Container Analysis to scan new container images. Review the vulnerability results before each deployment.

**B.** Enable Container Analysis, and upload new container images to Artifact Registry. Review the vulnerability results before each deployment.

**C.** Enable Container Analysis, and upload new container images to Artifact Registry. Review the critical vulnerability results before each deployment.

**D.** Use the Container Analysis REST API to call Container Analysis to scan new container images. Review the vulnerability results before each deployment.

**Respuesta de la fuente:** B

**Explicación:** Answer B is correct because Artifact Registry automatically scans container images for vulnerabilities using the underlying Container Analysis service, integrating this check directly into the image push workflow.
Option A and D are incorrect because they imply manual or CLI/API-driven scanning that bypasses the automated integration provided by Artifact Registry.
Option C is inferior because security best practices generally require reviewing all known vulnerabilities rather than limiting the scope to only critical ones to ensure comprehensive risk management.

## Pregunta 214

Contexto: [topics:726](#topics-726)
You are a developer at a large organization. You have an application written in Go running in a production Google Kubernetes Engine (GKE) cluster. You need to add a new feature that requires access to BigQuery. You want to grant BigQuery access to your GKE cluster following Google-recommended best practices. What should you do?

**A.** Create a Google service account with BigQuery access. Add the JSON key to Secret Manager, and use the Go client library to access the JSON key.

**B.** Create a Google service account with BigQuery access. Add the Google service account JSON key as a Kubernetes secret, and configure the application to use this secret.

**C.** Create a Google service account with BigQuery access. Add the Google service account JSON key to Secret Manager, and use an init container to access the secret for the application to use.

**D.** Create a Google service account and a Kubernetes service account. Configure Workload Identity on the GKE cluster, and reference the Kubernetes service account on the application Deployment.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Google recommends Workload Identity for GKE to securely delegate identity without managing long-lived service account keys. It maps Kubernetes service accounts to Google Cloud service accounts, allowing the application to authenticate using short-lived tokens issued by the cluster.
Options A, B, and C are incorrect because they rely on static JSON key files, which pose security risks (credential theft/leakage) and require manual rotation, violating the principle of least privilege and key management best practices.

## Pregunta 215

Contexto: [topics:726](#topics-726)
You have an application written in Python running in production on Cloud Run. Your application needs to read/write data stored in a Cloud Storage bucket in the same project. You want to grant access to your application following the principle of least privilege. What should you do?

**A.** Create a user-managed service account with a custom Identity and Access Management (IAM) role.

**B.** Create a user-managed service account with the Storage Admin Identity and Access Management (IAM) role.

**C.** Create a user-managed service account with the Project Editor Identity and Access Management (IAM) role.

**D.** Use the default service account linked to the Cloud Run revision in production.

**Respuesta de la fuente:** A

**Explicación:** The principle of least privilege requires granting only the minimum permissions necessary for a task. A custom IAM role allows you to define specific read/write permissions for Cloud Storage without including extraneous administrative capabilities, whereas roles like Storage Admin or Project Editor provide excessive access. Using the default service account often lacks the granular control needed and may already have broader defaults that violate strict least-privilege constraints.

## Pregunta 216

Contexto: [topics:726](#topics-726)
Your team is developing unit tests for Cloud Function code. The code is stored in a Cloud Source Repositories repository. You are responsible for implementing the tests. Only a specific service account has the necessary permissions to deploy the code to Cloud Functions. You want to ensure that the code cannot be deployed without first passing the tests. How should you configure the unit testing process?

**A.** Configure Cloud Build to deploy the Cloud Function. If the code passes the tests, a deployment approval is sent to you.

**B.** Configure Cloud Build to deploy the Cloud Function, using the specific service account as the build agent. Run the unit tests after successful deployment.

**C.** Configure Cloud Build to run the unit tests. If the code passes the tests, the developer deploys the Cloud Function.

**D.** Configure Cloud Build to run the unit tests, using the specific service account as the build agent. If the code passes the tests, Cloud Build deploys the Cloud Function.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it automates the entire pipeline within Cloud Build using the specific service account that holds deployment permissions. This ensures code cannot reach production without passing tests and removes reliance on manual developer intervention for deployment.

Option A is incorrect because introducing a manual approval step breaks the requirement to strictly enforce automated test gating before deployment. Option C is also wrong as it requires manual deployment by the developer, who lacks the necessary permissions.

## Pregunta 217

Contexto: [topics:726](#topics-726)
Your team detected a spike of errors in an application running on Cloud Run in your production project. The application is configured to read messages from Pub/Sub topic A, process the messages, and write the messages to topic B. You want to conduct tests to identify the cause of the errors. You can use a set of mock messages for testing. What should you do?

**A.** Deploy the Pub/Sub and Cloud Run emulators on your local machine. Deploy the application locally, and change the logging level in the application to DEBUG or INFO. Write mock messages to topic A, and then analyze the logs.

**B.** Use the gcloud CLI to write mock messages to topic A. Change the logging level in the application to DEBUG or INFO, and then analyze the logs.

**C.** Deploy the Pub/Sub emulator on your local machine. Point the production application to your local Pub/Sub topics. Write mock messages to topic A, and then analyze the logs.

**D.** Use the Google Cloud console to write mock messages to topic A. Change the logging level in the application to DEBUG or INFO, and then analyze the logs.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it establishes a fully isolated local testing environment using both Pub/Sub and Cloud Run emulators, allowing you to safely inject mock data and inspect detailed logs without affecting production systems. Option B is incorrect because writing mock messages to the actual production topic could introduce unintended side effects or pollute real data, whereas local emulation ensures no impact on live services.

## Pregunta 218

Contexto: [topics:726](#topics-726)
You are developing a Java Web Server that needs to interact with Google Cloud services via the Google Cloud API on the user's behalf. Users should be able to authenticate to the Google Cloud API using their Google Cloud identities. Which workflow should you implement in your web application?

**A.** 1. When a user arrives at your application, prompt them for their Google username and password.
2. Store an SHA password hash in your application's database along with the user's username.
3. The application authenticates to the Google Cloud API using HTTPs requests with the user's username and password hash in the Authorization request header.

**B.** 1. When a user arrives at your application, prompt them for their Google username and password.
2. Forward the user's username and password in an HTTPS request to the Google Cloud authorization server, and request an access token.
3. The Google server validates the user's credentials and returns an access token to the application.
4. The application uses the access token to call the Google Cloud API.

**C.** 1. When a user arrives at your application, route them to a Google Cloud consent screen with a list of requested permissions that prompts the user to sign in with SSO to their Google Account.
2. After the user signs in and provides consent, your application receives an authorization code from a Google server.
3. The Google server returns the authorization code to the user, which is stored in the browser's cookies.
4. The user authenticates to the Google Cloud API using the authorization code in the cookie.

**D.** 1. When a user arrives at your application, route them to a Google Cloud consent screen with a list of requested permissions that prompts the user to sign in with SSO to their Google Account.
2. After the user signs in and provides consent, your application receives an authorization code from a Google server.
3. The application requests a Google Server to exchange the authorization code with an access token.
4. The Google server responds with the access token that is used by the application to call the Google Cloud API.

**Respuesta de la fuente:** D

**Explicación:** Option D correctly implements the OAuth 2.0 Authorization Code flow: users authenticate via Google SSO, and the server securely exchanges the returned authorization code for an access token behind the scenes.
Options A and B are incorrect because applications must never handle user credentials directly; Option C is wrong because the authorization code itself cannot be used to call APIs—it must first be exchanged for a token.

## Pregunta 219

Contexto: [topics:726](#topics-726)
You recently developed a new application. You want to deploy the application on Cloud Run without a Dockerfile. Your organization requires that all container images are pushed to a centrally managed container repository. How should you build your container using Google Cloud services? (Choose two.)

**A.** Push your source code to Artifact Registry.

**B.** Submit a Cloud Build job to push the image.

**C.** Use the pack build command with pack CLI.

**D.** Include the --source flag with the gcloud run deploy CLI command.

**E.** Include the --platform=kubernetes flag with the gcloud run deploy CLI command.

**Respuesta de la fuente:** C, D

**Explicación:** Option C is correct because Buildpacks (via the pack CLI or Cloud Run's integrated support) enable creating container images directly from source code without a Dockerfile. Option D is correct because using the --source flag with gcloud run deploy allows you to deploy directly from source, which triggers Google Cloud to automatically build the image using Buildpacks and store it in Artifact Registry.
Option B is incorrect because submitting a Cloud Build job typically requires a cloudbuild.yaml or Dockerfile context, whereas the question specifies no Dockerfile. Option A is incorrect because Artifact Registry stores artifacts like container images, not source code repositories.

## Pregunta 220

Contexto: [topics:726](#topics-726)
You work for an organization that manages an online ecommerce website. Your company plans to expand across the world; however, the estore currently serves one specific region. You need to select a SQL database and configure a schema that will scale as your organization grows. You want to create a table that stores all customer transactions and ensure that the customer (CustomerId) and the transaction (TransactionId) are unique. What should you do?

**A.** Create a Cloud SQL table that has TransactionId and CustomerId configured as primary keys. Use an incremental number for the TransactionId.

**B.** Create a Cloud SQL table that has TransactionId and CustomerId configured as primary keys. Use a random string (UUID) for the Transactionid.

**C.** Create a Cloud Spanner table that has TransactionId and CustomerId configured as primary keys. Use a random string (UUID) for the TransactionId.

**D.** Create a Cloud Spanner table that has TransactionId and CustomerId configured as primary keys. Use an incremental number for the TransactionId.

**Respuesta de la fuente:** C

**Explicación:** Cloud Spanner is the correct choice because it provides globally distributed, horizontally scalable SQL capabilities required for worldwide expansion, unlike Cloud SQL which faces scaling limitations. Using a UUID (random string) for the primary key prevents write hotspots that would occur with sequential incremental IDs in a globally distributed system, ensuring consistent performance as data grows.

## Pregunta 221

Contexto: [topics:726](#topics-726)
You are monitoring a web application that is written in Go and deployed in Google Kubernetes Engine. You notice an increase in CPU and memory utilization. You need to determine which source code is consuming the most CPU and memory resources. What should you do?

**A.** Download, install, and start the Snapshot Debugger agent in your VM. Take debug snapshots of the functions that take the longest time. Review the call stack frame, and identify the local variables at that level in the stack.

**B.** Import the Cloud Profiler package into your application, and initialize the Profiler agent. Review the generated flame graph in the Google Cloud console to identify time-intensive functions.

**C.** Import OpenTelemetry and Trace export packages into your application, and create the trace provider.
Review the latency data for your application on the Trace overview page, and identify where bottlenecks are occurring.

**D.** Create a Cloud Logging query that gathers the web application's logs. Write a Python script that calculates the difference between the timestamps from the beginning and the end of the application's longest functions to identity time-intensive functions.

**Respuesta de la fuente:** B

**Explicación:** Cloud Profiler is the native GCP service designed specifically to profile application CPU and memory usage with minimal overhead. It generates flame graphs that visualize call stacks, allowing you to pinpoint the exact source code functions consuming the most resources. Option C (Trace) focuses on request latency and distributed tracing rather than resource utilization bottlenecks within specific functions.

## Pregunta 222

Contexto: [topics:726](#topics-726)
You have a container deployed on Google Kubernetes Engine. The container can sometimes be slow to launch, so you have implemented a liveness probe. You notice that the liveness probe occasionally fails on launch. What should you do?

**A.** Add a startup probe.

**B.** Increase the initial delay for the liveness probe.

**C.** Increase the CPU limit for the container.

**D.** Add a readiness probe.

**Respuesta de la fuente:** A

**Explicación:** Startup probes are specifically designed for applications with a long or variable initialization time. When configured, they suspend liveness and readiness checks until the startup probe succeeds, preventing the kubelet from killing a slow-starting container prematurely.

Increasing the initial delay (Option B) is a static configuration that may fail if startup times vary significantly, whereas a startup probe dynamically waits for the application to be fully initialized.

## Pregunta 223

Contexto: [topics:726](#topics-726)
You work for an organization that manages an ecommerce site. Your application is deployed behind a global HTTP(S) load balancer. You need to test a new product recommendation algorithm. You plan to use A/B testing to determine the new algorithm’s effect on sales in a randomized way. How should you test this feature?

**A.** Split traffic between versions using weights.

**B.** Enable the new recommendation feature flag on a single instance.

**C.** Mirror traffic to the new version of your application.

**D.** Use HTTP header-based routing.

**Respuesta de la fuente:** A

**Explicación:** Weight-based traffic splitting is the standard method for A/B testing on a global HTTP(S) load balancer because it allows you to probabilistically distribute user requests across different backend versions.
This ensures a randomized distribution of traffic, which is required to statistically compare the performance of the new algorithm against the old one.
Using HTTP header-based routing (D) typically targets specific groups or internal tools rather than providing true randomization for all users, while mirroring (C) does not allow user interaction with the test version.

## Pregunta 224

Contexto: [topics:726](#topics-726)
You plan to deploy a new application revision with a Deployment resource to Google Kubernetes Engine (GKE) in production. The container might not work correctly. You want to minimize risk in case there are issues after deploying the revision. You want to follow Google-recommended best practices. What should you do?

**A.** Perform a rolling update with a PodDisruptionBudget of 80%.

**B.** Perform a rolling update with a HorizontalPodAutoscaler scale-down policy value of 0.

**C.** Convert the Deployment to a StatefulSet, and perform a rolling update with a PodDisruptionBudget of 80%.

**D.** Convert the Deployment to a StatefulSet, and perform a rolling update with a HorizontalPodAutoscaler scale-down policy value of 0.

**Respuesta de la fuente:** A

**Explicación:** Answer A is correct because a PodDisruptionBudget (PDB) explicitly defines the minimum number or percentage of pods that must remain available during voluntary disruptions, such as rolling updates. This ensures high availability and minimizes the risk of downtime if the new container revision fails, aligning with Google's best practices for reliable deployments.

The other options are incorrect because HorizontalPodAutoscaler (HPA) scale-down policies control how quickly pods are removed due to low load, not during a deployment update process. Additionally, converting to a StatefulSet (C and D) is unnecessary unless the application requires stable network identities or ordered deployment, which is not specified in the scenario.

## Pregunta 225

Contexto: [topics:726](#topics-726)
Before promoting your new application code to production, you want to conduct testing across a variety of different users. Although this plan is risky, you want to test the new version of the application with production users and you want to control which users are forwarded to the new version of the application based on their operating system. If bugs are discovered in the new version, you want to roll back the newly deployed version of the application as quickly as possible.

What should you do?

**A.** Deploy your application on Cloud Run. Use traffic splitting to direct a subset of user traffic to the new version based on the revision tag.

**B.** Deploy your application on Google Kubernetes Engine with Anthos Service Mesh. Use traffic splitting to direct a subset of user traffic to the new version based on the user-agent header.

**C.** Deploy your application on App Engine. Use traffic splitting to direct a subset of user traffic to the new version based on the IP address.

**D.** Deploy your application on Compute Engine. Use Traffic Director to direct a subset of user traffic to the new version based on predefined weights.

**Respuesta de la fuente:** B

**Explicación:** The requirement to route traffic based on the user's operating system necessitates inspecting the User-Agent header, which contains OS information. Google Kubernetes Engine with Anthos Service Mesh supports advanced traffic splitting rules that can evaluate headers like User-Agent to direct specific subsets of users.

Option A is incorrect because Cloud Run's standard traffic splitting relies on revision weights or exact URLs, not dynamic header-based routing logic for OS differentiation.

## Pregunta 226

Contexto: [topics:726](#topics-726)
Your team is writing a backend application to implement the business logic for an interactive voice response (IVR) system that will support a payroll application. The IVR system has the following technical characteristics:

•	Each customer phone call is associated with a unique IVR session.
•	The IVR system creates a separate persistent gRPC connection to the backend for each session.
•	If the connection is interrupted, the IVR system establishes a new connection, causing a slight latency for that call.

You need to determine which compute environment should be used to deploy the backend application. Using current call data, you determine that:

•	Call duration ranges from 1 to 30 minutes.
•	Calls are typically made during business hours.
•	There are significant spikes of calls around certain known dates (e.g., pay days), or when large payroll changes occur.

You want to minimize cost, effort, and operational overhead. Where should you deploy the backend application?

**A.** Compute Engine

**B.** Google Kubernetes Engine cluster in Standard mode

**C.** Cloud Functions

**D.** Cloud Run

**Respuesta de la fuente:** D

**Explicación:** Cloud Run is the optimal choice because it natively supports persistent gRPC connections required by the IVR sessions while offering serverless scaling to handle payroll-related spikes with minimal operational overhead. Unlike Cloud Functions, which has strict execution timeouts (typically 9 minutes) that cannot accommodate calls lasting up to 30 minutes, Cloud Run allows longer-running instances. It is more cost-effective and simpler to manage than GKE or Compute Engine for this variable workload, as it automatically scales to zero during off-hours.

## Pregunta 227

Contexto: [topics:726](#topics-726)
You are developing an application hosted on Google Cloud that uses a MySQL relational database schema. The application will have a large volume of reads and writes to the database and will require backups and ongoing capacity planning. Your team does not have time to fully manage the database but can take on small administrative tasks. How should you host the database?

**A.** Configure Cloud SQL to host the database, and import the schema into Cloud SQL.

**B.** Deploy MySQL from the Google Cloud Marketplace to the database using a client, and import the schema.

**C.** Configure Bigtable to host the database, and import the data into Bigtable.

**D.** Configure Cloud Spanner to host the database, and import the schema into Cloud Spanner.

**E.** Configure Firestore to host the database, and import the data into Firestore.

**Respuesta de la fuente:** A

**Explicación:** Cloud SQL is the correct choice because it is a fully managed MySQL-compatible relational database service that requires minimal administrative overhead, aligning with the team's limited capacity for management. It natively supports automated backups, read/write scaling, and easy schema imports from existing MySQL environments.

Option B is incorrect because deploying MySQL via the Marketplace involves self-managing the OS and database software, which contradicts the requirement to minimize administrative tasks.

## Pregunta 228

Contexto: [topics:726](#topics-726)
You are developing a new web application using Cloud Run and committing code to Cloud Source Repositories. You want to deploy new code in the most efficient way possible. You have already created a Cloud Build YAML file that builds a container and runs the following command: gcloud run deploy. What should you do next?

**A.** Create a Pub/Sub topic to be notified when code is pushed to the repository. Create a Pub/Sub trigger that runs the build file when an event is published to the topic.

**B.** Create a build trigger that runs the build file in response to a repository code being pushed to the development branch.

**C.** Create a webhook build trigger that runs the build file in response to HTTP POST calls to the webhook URL.

**D.** Create a Cron job that runs the following command every 24 hours: gcloud builds submit.

**Respuesta de la fuente:** B

**Explicación:** Option B is the correct next step because Cloud Build provides native integration with Cloud Source Repositories via build triggers that automatically execute the defined YAML configuration upon code commits to specified branches. This eliminates the need for manual intervention or external event systems like Pub/Sub (Option A) and ensures immediate, efficient deployment upon changes.

Options C and D are incorrect; webhooks (C) add unnecessary complexity when native source control integration exists, and cron jobs (D) introduce significant latency and inefficiency by checking for changes periodically rather than responding instantly to commits.

## Pregunta 229

Contexto: [topics:726](#topics-726)
You are a developer at a large organization. You are deploying a web application to Google Kubernetes Engine (GKE). The DevOps team has built a CI/CD pipeline that uses Cloud Deploy to deploy the application to Dev, Test, and Prod clusters in GKE. After Cloud Deploy successfully deploys the application to the Dev cluster, you want to automatically promote it to the Test cluster. How should you configure this process following Google-recommended best practices?

**A.** 1. Create a Cloud Build trigger that listens for SUCCEEDED Pub/Sub messages from the clouddeploy-operations topic.
2. Configure Cloud Build to include a step that promotes the application to the Test cluster.

**B.** 1. Create a Cloud Function that calls the Google Cloud Deploy API to promote the application to the Test cluster.
2. Configure this function to be triggered by SUCCEEDED Pub/Sub messages from the cloud-builds topic.

**C.** 1. Create a Cloud Function that calls the Google Cloud Deploy API to promote the application to the Test cluster.
2. Configure this function to be triggered by SUCCEEDED Pub/Sub messages from the clouddeploy-operations topic.

**D.** 1. Create a Cloud Build pipeline that uses the gke-deploy builder.
2. Create a Cloud Build trigger that listens for SUCCEEDED Pub/Sub messages from the cloud-builds topic.
3. Configure this pipeline to run a deployment step to the Test cluster.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Cloud Deploy integrates natively with Cloud Build to automate promotion workflows.
Google's recommended best practice for this scenario involves using a Cloud Build trigger that listens for SUCCEEDED Pub/Sub messages from the clouddeploy-operations topic to automatically execute the next deployment step.

## Pregunta 230

Contexto: [topics:726](#topics-726)
Your application is running as a container in a Google Kubernetes Engine cluster. You need to add a secret to your application using a secure approach. What should you do?

**A.** Create a Kubernetes Secret, and pass the Secret as an environment variable to the container.

**B.** Enable Application-layer Secret Encryption on the cluster using a Cloud Key Management Service (KMS) key.

**C.** Store the credential in Cloud KMS. Create a Google service account (GSA) to read the credential from Cloud KMS. Export the GSA as a .json file, and pass the .json file to the container as a volume which can read the credential from Cloud KMS.

**D.** Store the credential in Secret Manager. Create a Google service account (GSA) to read the credential from Secret Manager. Create a Kubernetes service account (KSA) to run the container. Use Workload Identity to configure your KSA to act as a GSA.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it follows GKE best practices by using Secret Manager for centralized, encrypted secret storage and Workload Identity to securely bind Kubernetes Service Accounts to Google Service Accounts without static credentials.
Option A is incorrect because standard Kubernetes Secrets are only base64-encoded (not encrypted) and can be accessed by anyone with cluster permissions, whereas D ensures secrets are retrieved via authenticated API calls using identity-based access controls.

## Pregunta 231

Contexto: [topics:726](#topics-726)
You are a developer at a financial institution. You use Cloud Shell to interact with Google Cloud services. User data is currently stored on an ephemeral disk; however, a recently passed regulation mandates that you can no longer store sensitive information on an ephemeral disk. You need to implement a new storage solution for your user data. You want to minimize code changes. Where should you store your user data?

**A.** Store user data on a Cloud Shell home disk, and log in at least every 120 days to prevent its deletion.

**B.** Store user data on a persistent disk in a Compute Engine instance.

**C.** Store user data in a Cloud Storage bucket.

**D.** Store user data in BigQuery tables.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Cloud Shell's ephemeral disk is backed by a Compute Engine persistent disk mechanism; switching to a dedicated Compute Engine persistent disk maintains the same block-storage interface, thereby minimizing code changes compared to object storage or databases. Option C (Cloud Storage) requires changing data access patterns from file-system APIs to REST/object APIs (unless GCS Fuse is used, which adds complexity), violating the 'minimize code changes' constraint.

## Pregunta 232

Contexto: [topics:726](#topics-726)
You recently developed a web application to transfer log data to a Cloud Storage bucket daily. Authenticated users will regularly review logs from the prior two weeks for critical events. After that, logs will be reviewed once annually by an external auditor. Data must be stored for a period of no less than 7 years. You want to propose a storage solution that meets these requirements and minimizes costs. What should you do? (Choose two.)

**A.** Use the Bucket Lock feature to set the retention policy on the data.

**B.** Run a scheduled job to set the storage class to Coldline for objects older than 14 days.

**C.** Create a JSON Web Token (JWT) for users needing access to the Coldline storage buckets.

**D.** Create a lifecycle management policy to set the storage class to Coldline for objects older than 14 days.

**E.** Create a lifecycle management policy to set the storage class to Nearline for objects older than 14 days.

**Respuesta de la fuente:** A, D

**Explicación:** Option A is correct because Bucket Lock enforces an immutable retention policy, satisfying the strict legal requirement to store data for at least 7 years without deletion. Option D is correct because a lifecycle management policy automatically transitions infrequently accessed logs (older than 14 days) to the Coldline storage class, optimizing costs while maintaining access for annual audits. Option C is incorrect as JWTs are not the standard mechanism for authenticating users against Cloud Storage buckets; IAM roles are used instead.

## Pregunta 233

Contexto: [topics:726](#topics-726)
Your team is developing a Cloud Function triggered by Cloud Storage events. You want to accelerate testing and development of your Cloud Function while following Google-recommended best practices. What should you do?

**A.** Create a new Cloud Function that is triggered when Cloud Audit Logs detects the cloudfunctions.functions.sourceCodeSet operation in the original Cloud Function. Send mock requests to the new function to evaluate the functionality.

**B.** Make a copy of the Cloud Function, and rewrite the code to be HTTP-triggered. Edit and test the new version by triggering the HTTP endpoint. Send mock requests to the new function to evaluate the functionality.

**C.** Install the Functions Frameworks library, and configure the Cloud Function on localhost. Make a copy of the function, and make edits to the new version. Test the new version using curl.

**D.** Make a copy of the Cloud Function in the Google Cloud console. Use the Cloud console's in-line editor to make source code changes to the new function. Modify your web application to call the new function, and test the new version in production

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google Cloud Functions documentation explicitly recommends using the Functions Frameworks library to run functions locally on localhost. This approach accelerates development by allowing rapid iterative testing with tools like curl without the latency of deploying to the cloud or waiting for logs. Option B is less optimal because rewriting code to be HTTP-triggered requires structural changes and does not leverage the official local emulation framework designed for event-driven functions.

## Pregunta 234

Contexto: [topics:726](#topics-726)
Your team is setting up a build pipeline for an application that will run in Google Kubernetes Engine (GKE). For security reasons, you only want images produced by the pipeline to be deployed to your GKE cluster. Which combination of Google Cloud services should you use?

**A.** Cloud Build, Cloud Storage, and Binary Authorization

**B.** Google Cloud Deploy, Cloud Storage, and Google Cloud Armor

**C.** Google Cloud Deploy, Artifact Registry, and Google Cloud Armor

**D.** Cloud Build, Artifact Registry, and Binary Authorization

**Respuesta de la fuente:** D

**Explicación:** Cloud Build handles the CI process to create container images, which are then stored in Artifact Registry.
Binary Authorization enforces admission control policies on GKE, ensuring that only signed and approved images from trusted sources are deployed.
Option A is incorrect because Cloud Storage is not a container registry, and Options B and C rely on Google Cloud Armor, which provides DDoS protection and WAF capabilities rather than image-level deployment security.

## Pregunta 235

Contexto: [topics:726](#topics-726)
You are supporting a business-critical application in production deployed on Cloud Run. The application is reporting HTTP 500 errors that are affecting the usability of the application. You want to be alerted when the number of errors exceeds 15% of the requests within a specific time window. What should you do?

**A.** Create a Cloud Function that consumes the Cloud Monitoring API. Use Cloud Scheduler to trigger the Cloud Function daily and alert you if the number of errors is above the defined threshold.

**B.** Navigate to the Cloud Run page in the Google Cloud console, and select the service from the services list. Use the Metrics tab to visualize the number of errors for that revision, and refresh the page daily.

**C.** Create an alerting policy in Cloud Monitoring that alerts you if the number of errors is above the defined threshold.

**D.** Create a Cloud Function that consumes the Cloud Monitoring API. Use Cloud Composer to trigger the Cloud Function daily and alert you if the number of errors is above the defined threshold.

**Respuesta de la fuente:** C

**Explicación:** Cloud Monitoring's alerting policies are the native, purpose-built mechanism to automatically detect when metrics (like error ratios) exceed defined thresholds and trigger notifications. Options A and D are overly complex workarounds that introduce unnecessary latency and maintenance overhead by requiring custom functions and schedulers for a task already handled natively.
Option B is incorrect because manually refreshing a dashboard daily does not provide the immediate, automated alerting required for a business-critical application experiencing active errors.

## Pregunta 236

Contexto: [topics:726](#topics-726)
You need to build a public API that authenticates, enforces quotas, and reports metrics for API callers. Which tool should you use to complete this architecture?

[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/ba7636c0515660df514b.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Cloud Load
Balancing
```

**A.** App Engine

**B.** Cloud Endpoints

**C.** Identity-Aware Proxy

**D.** GKE Ingress for HTTP(S) Load Balancing

**Respuesta de la fuente:** B

**Explicación:** Cloud Endpoints is the correct solution because it natively provides authentication, quota enforcement, and metrics reporting for APIs, fulfilling all requirements stated in the scenario. While App Engine hosts backend services, it does not inherently provide a centralized API management layer for these specific cross-cutting concerns.

## Pregunta 237

Contexto: [topics:726](#topics-726)
You noticed that your application was forcefully shut down during a Deployment update in Google Kubernetes Engine. Your application didn’t close the database connection before it was terminated. You want to update your application to make sure that it completes a graceful shutdown. What should you do?

**A.** Update your code to process a received SIGTERM signal to gracefully disconnect from the database.

**B.** Configure a PodDisruptionBudget to prevent the Pod from being forcefully shut down.

**C.** Increase the terminationGracePeriodSeconds for your application.

**D.** Configure a PreStop hook to shut down your application.

**Respuesta de la fuente:** A

**Explicación:** When Kubernetes terminates a Pod, it sends a SIGTERM signal to the main process. To achieve a graceful shutdown, your application code must handle this signal to perform cleanup tasks, such as closing database connections, before exiting.

Option B (PodDisruptionBudget) prevents voluntary disruptions like node drains but does not handle forced terminations or ensure graceful application behavior. Option C (terminationGracePeriodSeconds) only increases the wait time before a SIGKILL is sent; if the application ignores SIGTERM, it will still be killed forcefully after the timeout. Option D (PreStop hook) delays termination but does not inherently trigger the necessary application-level cleanup logic without corresponding signal handling in the code.

## Pregunta 238

Contexto: [topics:726](#topics-726)
You are a lead developer working on a new retail system that runs on Cloud Run and Firestore in Datastore mode. A web UI requirement is for the system to display a list of available products when users access the system and for the user to be able to browse through all products. You have implemented this requirement in the minimum viable product (MVP) phase by returning a list of all available products stored in Firestore.

A few months after go-live, you notice that Cloud Run instances are terminated with HTTP 500: Container instances are exceeding memory limits errors during busy times. This error coincides with spikes in the number of Datastore entity reads. You need to prevent Cloud Run from crashing and decrease the number of Datastore entity reads. You want to use a solution that optimizes system performance. What should you do?

**A.** Modify the query that returns the product list using integer offsets.

**B.** Modify the query that returns the product list using limits.

**C.** Modify the Cloud Run configuration to increase the memory limits.

**D.** Modify the query that returns the product list using cursors.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because using cursors for pagination significantly reduces the number of Datastore entity reads and memory consumption by fetching only a subset of results per request, addressing both the high read count and OOM errors efficiently.
Option A (integer offsets) is incorrect because Datastore/Firestore calculates offset positions by reading through entities sequentially, resulting in higher latency and cost that increases as the dataset grows, failing to optimize performance effectively.

## Pregunta 239

Contexto: [topics:726](#topics-726)
You need to deploy an internet-facing microservices application to Google Kubernetes Engine (GKE). You want to validate new features using the A/B testing method. You have the following requirements for deploying new container image releases:
•	There is no downtime when new container images are deployed.
•	New production releases are tested and verified using a subset of production users.

What should you do?

**A.** 1. Configure your CI/CD pipeline to update the Deployment manifest file by replacing the container version with the latest version.
2. Recreate the Pods in your cluster by applying the Deployment manifest file.
3. Validate the application's performance by comparing its functionality with the previous release version, and roll back if an issue arises.

**B.** 1. Create a second namespace on GKE for the new release version.
2. Create a Deployment configuration for the second namespace with the desired number of Pods.
3. Deploy new container versions in the second namespace.
4. Update the Ingress configuration to route traffic to the namespace with the new container versions.

**C.** 1. Install the Anthos Service Mesh on your GKE cluster.
2. Create two Deployments on the GKE cluster, and label them with different version names.
3. Implement an Istio routing rule to send a small percentage of traffic to the Deployment that references the new version of the application.

**D.** 1. Implement a rolling update pattern by replacing the Pods gradually with the new release version.
2. Validate the application's performance for the new subset of users during the rollout, and roll back if an issue arises.

**Respuesta de la fuente:** B

**Explicación:** Option B is the expected answer in this exam context because it describes a Blue/Green deployment strategy, which inherently provides zero downtime by keeping the old environment running while the new one is prepared.
By deploying to a separate namespace and then switching traffic via Ingress, you satisfy the requirement for no downtime during image deployment and allow for validation of the new release against production traffic.
The most tempting alternative, Option C (using Anthos Service Mesh/Istio), is technically superior for granular A/B testing percentages, but exams often prioritize the structural separation and fail-safe nature of Blue/Green deployments (Option B) over service mesh complexity when 'no downtime' and 'validation' are the primary constraints.

## Pregunta 240

Contexto: [topics:726](#topics-726)
Your team manages a large Google Kubernetes Engine (GKE) cluster. Several application teams currently use the same namespace to develop microservices for the cluster. Your organization plans to onboard additional teams to create microservices. You need to configure multiple environments while ensuring the security and optimal performance of each team’s work. You want to minimize cost and follow Google-recommended best practices. What should you do?

**A.** Create new role-based access controls (RBAC) for each team in the existing cluster, and define resource quotas.

**B.** Create a new namespace for each environment in the existing cluster, and define resource quotas.

**C.** Create a new GKE cluster for each team.

**D.** Create a new namespace for each team in the existing cluster, and define resource quotas.

**Respuesta de la fuente:** D

**Explicación:** Google recommends using namespaces to isolate workloads and define resource quotas within a single cluster for multiple teams, ensuring security and performance without the high cost and operational overhead of maintaining separate clusters (Option C). Option D is correct because it provides logical separation and resource management per team. Option B is incorrect because it focuses on environments rather than team isolation, which does not adequately address the need to secure distinct team workloads.

## Pregunta 241

Contexto: [topics:726](#topics-726)
You have deployed a Java application to Cloud Run. Your application requires access to a database hosted on Cloud SQL. Due to regulatory requirements, your connection to the Cloud SQL instance must use its internal IP address. How should you configure the connectivity while following Google-recommended best practices?

**A.** Configure your Cloud Run service with a Cloud SQL connection.

**B.** Configure your Cloud Run service to use a Serverless VPC Access connector.

**C.** Configure your application to use the Cloud SQL Java connector.

**D.** Configure your application to connect to an instance of the Cloud SQL Auth proxy.

**Respuesta de la fuente:** B

**Explicación:** Cloud Run is a serverless service that does not inherently reside within your VPC network, so it cannot directly access Cloud SQL via internal IP without a bridge. A Serverless VPC Access connector provides the necessary private network path from Cloud Run to your VPC resources, satisfying both the connectivity and regulatory requirements for internal IP usage. Option C (Java Connector) handles authentication and encryption but does not establish the underlying network route to a private IP address.

## Pregunta 242

Contexto: [topics:726](#topics-726)
Your application stores customers’ content in a Cloud Storage bucket, with each object being encrypted with the customer's encryption key. The key for each object in Cloud Storage is entered into your application by the customer. You discover that your application is receiving an HTTP 4xx error when reading the object from Cloud Storage. What is a possible cause of this error?

**A.** You attempted the read operation on the object with the customer's base64-encoded key.

**B.** You attempted the read operation without the base64-encoded SHA256 hash of the encryption key.

**C.** You entered the same encryption algorithm specified by the customer when attempting the read operation.

**D.** You attempted the read operation on the object with the base64-encoded SHA256 hash of the customer's key.

**Respuesta de la fuente:** B

**Explicación:** When using Customer-Supplied Encryption Keys (CSEK) in Google Cloud Storage, the REST API requires both the base64-encoded encryption key and its base64-encoded SHA256 hash. Omitting the SHA256 hash results in an HTTP 400 Bad Request error because the server cannot verify the integrity of the provided key.
Option A is incorrect because providing the correct base64-encoded key (without the hash) is only partially wrong; the specific missing component causing the standard validation failure in this context is the hash verification value.

## Pregunta 243

Contexto: [topics:726](#topics-726)
You have two Google Cloud projects, named Project A and Project B. You need to create a Cloud Function in Project A that saves the output in a Cloud Storage bucket in Project B. You want to follow the principle of least privilege. What should you do?

**A.** 1. Create a Google service account in Project B.
2. Deploy the Cloud Function with the service account in Project A.
3. Assign this service account the roles/storage.objectCreator role on the storage bucket residing in Project B.

**B.** 1. Create a Google service account in Project A
2. Deploy the Cloud Function with the service account in Project A.
3. Assign this service account the roles/storage.objectCreator role on the storage bucket residing in Project B.

**C.** 1. Determine the default App Engine service account (PROJECT_ID@appspot.gserviceaccount.com) in Project A.
2. Deploy the Cloud Function with the default App Engine service account in Project A.
3. Assign the default App Engine service account the roles/storage.objectCreator role on the storage bucket residing in Project B.

**D.** 1. Determine the default App Engine service account (PROJECT_ID@appspot.gserviceaccount.com) in Project B.
2. Deploy the Cloud Function with the default App Engine service account in Project A.
3. Assign the default App Engine service account the roles/storage.objectCreator role on the storage bucket residing in Project B.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Cloud Functions must run under a service account defined within the same project (Project A). By creating a dedicated service account in Project A and granting it only the `roles/storage.objectCreator` permission on the specific bucket in Project B, you adhere to the principle of least privilege without using overly permissive default accounts.
Option A is incorrect because a Cloud Function cannot be deployed with a service account that resides in a different project than the function itself.

## Pregunta 244

Contexto: [topics:726](#topics-726)
A governmental regulation was recently passed that affects your application. For compliance purposes, you are now required to send a duplicate of specific application logs from your application’s project to a project that is restricted to the security team. What should you do?

**A.** Create user-defined log buckets in the security team’s project. Configure a Cloud Logging sink to route your application’s logs to log buckets in the security team’s project.

**B.** Create a job that copies the logs from the _Required log bucket into the security team’s log bucket in their project.

**C.** Modify the _Default log bucket sink rules to reroute the logs into the security team’s log bucket.

**D.** Create a job that copies the System Event logs from the _Required log bucket into the security team’s log bucket in their project.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Cloud Logging sinks are the designated mechanism for routing and replicating log entries to destinations outside the current project, such as another project's log buckets. This ensures real-time compliance and automation without manual intervention.

Options B and D are incorrect because using Dataflow jobs introduces latency and operational overhead compared to native sink routing. Option C is incorrect because modifying the _Default sink alters the destination for all logs, which violates the requirement to send only specific application logs and disrupts standard logging behavior.

## Pregunta 245

Contexto: [topics:726](#topics-726)
You plan to deploy a new Go application to Cloud Run. The source code is stored in Cloud Source Repositories. You need to configure a fully managed, automated, continuous deployment pipeline that runs when a source code commit is made. You want to use the simplest deployment solution. What should you do?

**A.** Configure a cron job on your workstations to periodically run gcloud run deploy --source in the working directory.

**B.** Configure a Jenkins trigger to run the container build and deploy process for each source code commit to Cloud Source Repositories.

**C.** Configure continuous deployment of new revisions from a source repository for Cloud Run using buildpacks.

**D.** Use Cloud Build with a trigger configured to run the container build and deploy process for each source code commit to Cloud Source Repositories.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Cloud Build triggers provide a fully managed, native CI/CD pipeline that automatically reacts to source code commits in Cloud Source Repositories without requiring infrastructure maintenance.
Option C is incorrect because configuring continuous deployment via buildpacks typically relies on a one-time gcloud command or local setup, whereas Cloud Build offers a persistent, event-driven automated pipeline specifically designed for this requirement.

## Pregunta 246

Contexto: [topics:726](#topics-726)
Your team has created an application that is hosted on a Google Kubernetes Engine (GKE) cluster. You need to connect the application to a legacy REST service that is deployed in two GKE clusters in two different regions. You want to connect your application to the target service in a way that is resilient. You also want to be able to run health checks on the legacy service on a separate port. How should you set up the connection? (Choose two.)

**A.** Use Traffic Director with a sidecar proxy to connect the application to the service.

**B.** Use a proxyless Traffic Director configuration to connect the application to the service.

**C.** Configure the legacy service's firewall to allow health checks originating from the proxy.

**D.** Configure the legacy service's firewall to allow health checks originating from the application.

**E.** Configure the legacy service's firewall to allow health checks originating from the Traffic Director control plane.

**Respuesta de la fuente:** A, C

**Explicación:** Option A is correct because using Traffic Director with a sidecar proxy (Envoy) enables intelligent load balancing and failover across the two GKE clusters, ensuring resilience. Option C is correct because health checks are performed by the global load balancer infrastructure, which originates from the proxy's perspective in this context; therefore, the firewall must permit traffic from these proxies to accurately assess service health.
Option B is incorrect because proxyless configurations (while possible via gRPC or specific clients) generally lack the standardized, robust health-check integration and transparency features provided by the Envoy sidecar model in standard GKE Traffic Director setups. Option D is incorrect because applications do not perform infrastructure-level health checks for load balancing purposes; this is handled by the proxy/load balancer.

## Pregunta 247

Contexto: [topics:726](#topics-726)
You have an application running in a production Google Kubernetes Engine (GKE) cluster. You use Cloud Deploy to automatically deploy your application to your production GKE cluster. As part of your development process, you are planning to make frequent changes to the application’s source code and need to select the tools to test the changes before pushing them to your remote source code repository. Your toolset must meet the following requirements:
•	Test frequent local changes automatically.
•	Local deployment emulates production deployment.

Which tools should you use to test building and running a container on your laptop using minimal resources?

**A.** Docker Compose and dockerd

**B.** Terraform and kubeadm

**C.** Minikube and Skaffold

**D.** kaniko and Tekton

**Respuesta de la fuente:** C

**Explicación:** Minikube provides a lightweight, single-node Kubernetes cluster locally to emulate the production GKE environment with minimal resource overhead. Skaffold automates the build, push, and deploy workflow for local development, satisfying the requirement for testing frequent changes automatically.
Terraform and kubeadm (Option B) are overly complex for local laptop testing and do not provide an automated inner-loop development experience.

## Pregunta 248

Contexto: [topics:726](#topics-726)
You are deploying a Python application to Cloud Run using Cloud Source Repositories and Cloud Build. The Cloud Build pipeline is shown below:

[Imagen: sin descripción]

You want to optimize deployment times and avoid unnecessary steps. What should you do?
Imagen · question_text · sin descripción
![Imagen original](imagenes/2d86d0afcf8851278761.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
steps:
~ name: python
entrypoint: pip
args: ["install", -r, requirements.txt, --user]
- name: 'gcr.io/cloud-builders/docker*
args: ["build', '-t',
*us-central1-docker .pkg.dev/$(PROJECT_ID) /${_REPO_NAME) /myimage:$(SHORT_SHA}',
~ name: 'gcr.io/cloud-builders/docker*
args: [‘push', ‘us-centrall-
docker pkg. dev/$ ( PROJECT_ID}/${_REPO_NAME) /myimage:${SHORT_SHA}"]
- name: google/cloud-sdk
args: [‘gcloud', ‘run’, ‘deploy’, ‘helloworld-${SHORT_SHA}',
*--image=us-central1-
docker .pkg.dev/$ ( PROJECT_ID}/${_REPO_NAME) /myimage:${SHORT_SHA)',
‘--region', ‘us-centrall', '--platform', 'managed',
*--allow-unauthenticated"]
```

**A.** Remove the step that pushes the container to Artifact Registry.

**B.** Deploy a new Docker registry in a VPC, and use Cloud Build worker pools inside the VPC to run the build pipeline.

**C.** Store image artifacts in a Cloud Storage bucket in the same region as the Cloud Run instance.

**D.** Add the --cache-from argument to the Docker build step in your build config file.

**Respuesta de la fuente:** D

**Explicación:** The --cache-from argument enables Docker layer caching, which significantly reduces build times by reusing unchanged layers from previous builds. This is a standard optimization technique for speeding up CI/CD pipelines without altering the architecture. Removing the push step (A) breaks the deployment process, and deploying a new registry (B) or using Cloud Storage (C) adds unnecessary complexity and does not address the build time inefficiency.

## Pregunta 249

Contexto: [topics:726](#topics-726)
You are developing an event-driven application. You have created a topic to receive messages sent to Pub/Sub. You want those messages to be processed in real time. You need the application to be independent from any other system and only incur costs when new messages arrive. How should you configure the architecture?

**A.** Deploy the application on Compute Engine. Use a Pub/Sub push subscription to process new messages in the topic.

**B.** Deploy your code on Cloud Functions. Use a Pub/Sub trigger to invoke the Cloud Function. Use the Pub/Sub API to create a pull subscription to the Pub/Sub topic and read messages from it.

**C.** Deploy the application on Google Kubernetes Engine. Use the Pub/Sub API to create a pull subscription to the Pub/Sub topic and read messages from it.

**D.** Deploy your code on Cloud Functions. Use a Pub/Sub trigger to handle new messages in the topic.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Cloud Functions are serverless compute services that automatically scale and only incur costs when executed (invoked), satisfying the requirement to minimize costs while processing messages in real time via a Pub/Sub trigger. Option B is incorrect because it suggests manually creating a pull subscription using the API, which contradicts the event-driven nature of Cloud Functions where the platform manages subscriptions automatically through triggers.

## Pregunta 250

Contexto: [topics:726](#topics-726)
You have an application running on Google Kubernetes Engine (GKE). The application is currently using a logging library and is outputting to standard output. You need to export the logs to Cloud Logging, and you need the logs to include metadata about each request. You want to use the simplest method to accomplish this. What should you do?

**A.** Change your application’s logging library to the Cloud Logging library, and configure your application to export logs to Cloud Logging.

**B.** Update your application to output logs in JSON format, and add the necessary metadata to the JSON.

**C.** Update your application to output logs in CSV format, and add the necessary metadata to the CSV.

**D.** Install the Fluent Bit agent on each of your GKE nodes, and have the agent export all logs from /var/log.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 251

Contexto: [topics:726](#topics-726)
You are working on a new application that is deployed on Cloud Run and uses Cloud Functions. Each time new features are added, new Cloud Functions and Cloud Run services are deployed. You use ENV variables to keep track of the services and enable interservice communication, but the maintenance of the ENV variables has become difficult. You want to implement dynamic discovery in a scalable way. What should you do?

**A.** Configure your microservices to use the Cloud Run Admin and Cloud Functions APIs to query for deployed Cloud Run services and Cloud Functions in the Google Cloud project.

**B.** Create a Service Directory namespace. Use API calls to register the services during deployment, and query during runtime.

**C.** Rename the Cloud Functions and Cloud Run services endpoint is using a well-documented naming convention.

**D.** Deploy Hashicorp Consul on a single Compute Engine instance. Register the services with Consul during deployment, and query during runtime.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Service Directory is the native solution for service discovery, allowing you to register and query services dynamically via API calls without maintaining static environment variables.
Option A is incorrect because using Admin APIs for runtime discovery imposes unnecessary load and latency compared to a dedicated service registry.
Option C relies on naming conventions which do not support dynamic IP/endpoint resolution or health checks.
Option D introduces external infrastructure overhead (running Consul on Compute Engine) that contradicts the goal of using fully managed, scalable Google Cloud services.

## Pregunta 252

Contexto: [topics:726](#topics-726)
You work for a financial services company that has a container-first approach. Your team develops microservices applications. A Cloud Build pipeline creates the container image, runs regression tests, and publishes the image to Artifact Registry. You need to ensure that only containers that have passed the regression tests are deployed to Google Kubernetes Engine (GKE) clusters. You have already enabled Binary Authorization on the GKE clusters. What should you do next?

**A.** Create an attestor and a policy. After a container image has successfully passed the regression tests, use Cloud Build to run Kritis Signer to create an attestation for the container image.

**B.** Deploy Voucher Server and Voucher Client components. After a container image has successfully passed the regression tests, run Voucher Client as a step in the Cloud Build pipeline.

**C.** Set the Pod Security Standard level to Restricted for the relevant namespaces. Use Cloud Build to digitally sign the container images that have passed the regression tests.

**D.** Create an attestor and a policy. Create an attestation for the container images that have passed the regression tests as a step in the Cloud Build pipeline.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Binary Authorization relies on attestors and policies to enforce deployment rules, and Kritis Signer (or the underlying `gcloud` attestation commands) is the specific mechanism used within Cloud Build to create the required digital signatures (attestations) for container images. Option D is tempting but vague; while it mentions creating an attestation, Option A correctly identifies the integration pattern of using Kritis/Cloud Build steps to generate that attestation after successful testing, which is the standard documented procedure for automating this workflow in Google Cloud.

Reference: Google Cloud Binary Authorization documentation on integrating with Cloud Build.

## Pregunta 253

Contexto: [topics:726](#topics-726)
You are reviewing and updating your Cloud Build steps to adhere to best practices. Currently, your build steps include:

1. Pull the source code from a source repository.
2. Build a container image
3. Upload the built image to Artifact Registry.

You need to add a step to perform a vulnerability scan of the built container image, and you want the results of the scan to be available to your deployment pipeline running in Google Cloud. You want to minimize changes that could disrupt other teams’ processes. What should you do?

**A.** Enable Binary Authorization, and configure it to attest that no vulnerabilities exist in a container image.

**B.** Upload the built container images to your Docker Hub instance, and scan them for vulnerabilities.

**C.** Enable the Container Scanning API in Artifact Registry, and scan the built container images for vulnerabilities.

**D.** Add Artifact Registry to your Aqua Security instance, and scan the built container images for vulnerabilities.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because enabling the Container Scanning API in Artifact Registry provides an automated, native Google Cloud mechanism to scan images immediately upon upload. This approach minimizes disruption by leveraging existing infrastructure without introducing third-party tools or complex policy attestations that other teams might not have configured.

Option A is incorrect because Binary Authorization is designed for enforcing deployment policies based on attestations, not primarily for generating the initial vulnerability scan results needed by the pipeline. Options B and D introduce external services (Docker Hub, Aqua Security) which violate the requirement to keep results within Google Cloud and minimize cross-team disruptions.

## Pregunta 254

Contexto: [topics:726](#topics-726)
You are developing an online gaming platform as a microservices application on Google Kubernetes Engine (GKE). Users on social media are complaining about long loading times for certain URL requests to the application. You need to investigate performance bottlenecks in the application and identify which HTTP requests have a significantly high latency span in user requests. What should you do?

**A.** Configure GKE workload metrics using kubectl. Select all Pods to send their metrics to Cloud Monitoring. Create a custom dashboard of application metrics in Cloud Monitoring to determine performance bottlenecks of your GKE cluster.

**B.** Update your microservices to log HTTP request methods and URL paths to STDOUT. Use the logs router to send container logs to Cloud Logging. Create filters in Cloud Logging to evaluate the latency of user requests across different methods and URL paths.

**C.** Instrument your microservices by installing the OpenTelemetry tracing package. Update your application code to send traces to Trace for inspection and analysis. Create an analysis report on Trace to analyze user requests.

**D.** Install tcpdump on your GKE nodes. Run tcpdump to capture network traffic over an extended period of time to collect data. Analyze the data files using Wireshark to determine the cause of high latency.

**Respuesta de la fuente:** C

**Explicación:** Cloud Trace is specifically designed for distributed tracing, allowing you to visualize the path of a request across multiple microservices and pinpoint high-latency spans. Option A (Monitoring) provides aggregate metrics like CPU usage but lacks the granular request-level trace data needed to identify specific slow HTTP paths. Option B (Logging) can record latency per log entry but does not provide the end-to-end correlation of a single user request across services that tracing offers.

## Pregunta 255

Contexto: [topics:726](#topics-726)
You need to load-test a set of REST API endpoints that are deployed to Cloud Run. The API responds to HTTP POST requests. Your load tests must meet the following requirements:
•	Load is initiated from multiple parallel threads.
•	User traffic to the API originates from multiple source IP addresses.
•	Load can be scaled up using additional test instances.

You want to follow Google-recommended best practices. How should you configure the load testing?

**A.** Create an image that has cURL installed, and configure cURL to run a test plan. Deploy the image in a managed instance group, and run one instance of the image for each VM.

**B.** Create an image that has cURL installed, and configure cURL to run a test plan. Deploy the image in an unmanaged instance group, and run one instance of the image for each VM.

**C.** Deploy a distributed load testing framework on a private Google Kubernetes Engine cluster. Deploy additional Pods as needed to initiate more traffic and support the number of concurrent users.

**D.** Download the container image of a distributed load testing framework on Cloud Shell. Sequentially start several instances of the container on Cloud Shell to increase the load on the API.

**Respuesta de la fuente:** C

**Explicación:** Google's official architecture guides recommend using Google Kubernetes Engine (GKE) for distributed load testing because it allows scaling out worker pods to generate high concurrency from multiple source IPs.
Deploying a distributed framework on GKE satisfies the requirements for parallel threads, multiple source origins via distinct pod IPs, and horizontal scalability by adding more pods.
Option D is incorrect because Cloud Shell is an interactive development environment with resource limits, not a scalable infrastructure suitable for generating significant load or managing multiple external IP addresses effectively.

## Pregunta 256

Contexto: [topics:726](#topics-726)
Your team is creating a serverless web application on Cloud Run. The application needs to access images stored in a private Cloud Storage bucket. You want to give the application Identity and Access Management (IAM) permission to access the images in the bucket, while also securing the services using Google-recommended best practices. What should you do?

**A.** Enforce signed URLs for the desired bucket. Grant the Storage Object Viewer IAM role on the bucket to the Compute Engine default service account.

**B.** Enforce public access prevention for the desired bucket. Grant the Storage Object Viewer IAM role on the bucket to the Compute Engine default service account.

**C.** Enforce signed URLs for the desired bucket. Create and update the Cloud Run service to use a user-managed service account. Grant the Storage Object Viewer IAM role on the bucket to the service account.

**D.** Enforce public access prevention for the desired bucket. Create and update the Cloud Run service to use a user-managed service account. Grant the Storage Object Viewer IAM role on the bucket to the service account.

**Respuesta de la fuente:** D

**Explicación:** Enforcing Public Access Prevention ensures the bucket remains private regardless of individual ACL settings, preventing accidental data exposure. Using a dedicated user-managed service account adheres to the principle of least privilege by isolating permissions from the default Compute Engine service account, which is shared across many resources.

## Pregunta 257

Contexto: [topics:726](#topics-726)
You are using Cloud Run to host a global ecommerce web application. Your company’s design team is creating a new color scheme for the web app. You have been tasked with determining whether the new color scheme will increase sales. You want to conduct testing on live production traffic. How should you design the study?

**A.** Use an external HTTP(S) load balancer to route a predetermined percentage of traffic to two different color schemes of your application. Analyze the results to determine whether there is a statistically significant difference in sales.

**B.** Use an external HTTP(S) load balancer to route traffic to the original color scheme while the new deployment is created and tested. After testing is complete, reroute all traffic to the new color scheme. Analyze the results to determine whether there is a statistically significant difference in sales.

**C.** Use an external HTTP(S) load balancer to mirror traffic to the new version of your application. Analyze the results to determine whether there is a statistically significant difference in sales.

**D.** Enable a feature flag that displays the new color scheme to half of all users. Monitor sales to see whether they increase for this group of users.

**Respuesta de la fuente:** A

**Explicación:** Option A is the standard infrastructure approach for A/B testing on Google Cloud using an external HTTP(S) load balancer. The load balancer can route a weighted percentage of traffic to different Cloud Run revisions, allowing you to test two distinct color schemes (images) simultaneously on live production users and compare sales data.

Option D is incorrect in this specific exam context because it suggests implementing application-level feature flags without specifying the managed service (e.g., Firebase Remote Config), whereas Option A leverages the built-in capabilities of Google Cloud networking services to achieve the goal directly and reliably.

## Pregunta 258

Contexto: [topics:726](#topics-726)
You are a developer at a large corporation. You manage three Google Kubernetes Engine clusters on Google Cloud. Your team’s developers need to switch from one cluster to another regularly without losing access to their preferred development tools. You want to configure access to these multiple clusters while following Google-recommended best practices. What should you do?

**A.** Ask the developers to use Cloud Shell and run gcloud container clusters get-credential to switch to another cluster.

**B.** In a configuration file, define the clusters, users, and contexts. Share the file with the developers and ask them to use kubect1 contig to add cluster, user, and context details.

**C.** Ask the developers to install the gcloud CLI on their workstation and run gcloud container clusters get-credentials to switch to another cluster.

**D.** Ask the developers to open three terminals on their workstation and use kubect1 config to configure access to each cluster.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because `gcloud container clusters get-credentials` automatically retrieves the specific cluster credentials and merges them into the local kubeconfig file, allowing developers to use their preferred CLI tools without manually managing certificates or endpoints. This method follows Google-recommended best practices for GKE access management.

Option A is incorrect because Cloud Shell is a web-based environment that may not integrate with or replace the developer's preferred local workstation tools. Option B is less optimal because it requires manual configuration of cluster details rather than leveraging the automated credential retrieval provided by the gcloud SDK.

## Pregunta 259

Contexto: [topics:726](#topics-726)
You are a lead developer working on a new retail system that runs on Cloud Run and Firestore. A web UI requirement is for the user to be able to browse through all products. A few months after go-live, you notice that Cloud Run instances are terminated with HTTP 500: Container instances are exceeding memory limits errors during busy times. This error coincides with spikes in the number of Firestore queries.

You need to prevent Cloud Run from crashing and decrease the number of Firestore queries. You want to use a solution that optimizes system performance. What should you do?

**A.** Modify the query that returns the product list using cursors with limits.

**B.** Create a custom index over the products.

**C.** Modify the query that returns the product list using integer offsets.

**D.** Modify the Cloud Run configuration to increase the memory limits.

**Respuesta de la fuente:** A

**Explicación:** Using cursors with limits (pagination) prevents the application from fetching all products in a single query, significantly reducing memory usage and preventing OOM crashes. This approach is superior to integer offsets because Firestore queries with large offsets are expensive and inefficient, while increasing memory limits only treats the symptom without addressing the root cause of inefficient data retrieval.

## Pregunta 260

Contexto: [topics:726](#topics-726)
You are a developer at a large organization. Your team uses Git for source code management (SCM). You want to ensure that your team follows Google-recommended best practices to manage code to drive higher rates of software delivery. Which SCM process should your team use?

**A.** Each developer commits their code to the main branch before each product release, conducts testing, and rolls back if integration issues are detected.

**B.** Each group of developers copies the repository, commits their changes to their repository, and merges their code into the main repository before each product release.

**C.** Each developer creates a branch for their own work, commits their changes to their branch, and merges their code into the main branch daily.

**D.** Each group of developers creates a feature branch from the main branch for their work, commits their changes to their branch, and merges their code into the main branch after the change advisory board approves it.

**Respuesta de la fuente:** D

**Explicación:** Option D is the correct answer because it aligns with enterprise governance standards often tested in certification exams, where a Change Advisory Board (CAB) approval ensures risk management and formal verification before merging changes in a large organization. While Google advocates for Trunk-Based Development (daily merges), certification questions for 'large organizations' typically prioritize structured change control processes over pure agile speed to ensure stability. Option C is tempting but lacks the necessary governance layer (CAB approval) required by the question's context of organizational policy and risk mitigation.

## Pregunta 261

Contexto: [topics:726](#topics-726)
You have a web application that publishes messages to Pub/Sub. You plan to build new versions of the application locally and want to quickly test Pub/Sub integration for each new build. How should you configure local testing?

**A.** Install Cloud Code on the integrated development environment (IDE). Navigate to Cloud APIs, and enable Pub/Sub against a valid Google Project ID. When developing locally, configure your application to call pubsub.googleapis.com.

**B.** Install the Pub/Sub emulator using gcloud, and start the emulator with a valid Google Project ID. When developing locally, configure your application to use the local emulator with ${gcloud beta emulators pubsub env-init}.

**C.** In the Google Cloud console, navigate to the API Library, and enable the Pub/Sub API. When developing locally, configure your application to call pubsub.googleapis.com.

**D.** Install the Pub/Sub emulator using gcloud, and start the emulator with a valid Google Project IWhen developing locally, configure your application to use the local emulator by exporting the PUBSUB_EMULATOR_HOST variable.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it uses the Pub/Sub emulator for local testing, which avoids costs and latency associated with calling the live service. The command `gcloud beta emulators pubsub env-init` is the recommended method to automatically configure the necessary environment variables (like `PUBSUB_EMULATOR_HOST`) for your application to connect to the local emulator.

Option D is incorrect because it contains a typo in the setup step ('Project IWhen' instead of 'Project ID') and suggests manually exporting variables, whereas the env-init command is the standard automated approach described in official documentation for integrating with gcloud emulators.

## Pregunta 262

Contexto: [topics:726](#topics-726)
Your ecommerce application receives external requests and forwards them to third-party API services for credit card processing, shipping, and inventory management as shown in the diagram.

[Imagen: sin descripción]

Your customers are reporting that your application is running slowly at unpredictable times. The application doesn’t report any metrics. You need to determine the cause of the inconsistent performance. What should you do?
Imagen · question_text · sin descripción
![Imagen original](imagenes/b567a87363fe139e1c76.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Google Cloud
Credit Card
—— :
Processing
Kubernetes
noe wel (13) Shipping
Cloud Load
```

**A.** Install the OpenTelemetry library for your respective language, and instrument your application.

**B.** Install the Ops Agent inside your container and configure it to gather application metrics.

**C.** Modify your application to read and forward the X-Cloud-Trace-Context header when it calls the downstream services.

**D.** Enable Managed Service for Prometheus on the Google Kubernetes Engine cluster to gather application metrics.

**Respuesta de la fuente:** A

**Explicación:** OpenTelemetry is the correct choice because it enables application-level instrumentation, which is required since the application currently reports no metrics. Installing the library allows you to capture traces and metrics for downstream API calls, directly identifying bottlenecks in credit card processing or shipping services that cause unpredictable latency.
Option B (Ops Agent) and D (Managed Prometheus) are incorrect because they primarily gather infrastructure or container-level metrics but cannot automatically trace internal application logic or external HTTP calls without prior application instrumentation. Option C is insufficient on its own because forwarding trace headers does not generate the necessary telemetry data if the application is not instrumented to capture it.

## Pregunta 263

Contexto: [topics:726](#topics-726)
You are developing a new application. You want the application to be triggered only when a given file is updated in your Cloud Storage bucket. Your trigger might change, so your process must support different types of triggers. You want the configuration to be simple so that multiple team members can update the triggers in the future. What should you do?

**A.** Configure Cloud Storage events to be sent to Pub/Sub, and use Pub/Sub events to trigger a Cloud Build job that executes your application.

**B.** Create an Eventarc trigger that monitors your Cloud Storage bucket for a specific filename, and set the target as Cloud Run.

**C.** Configure a Cloud Function that executes your application and is triggered when an object is updated in Cloud Storage.

**D.** Configure a Firebase function that executes your application and is triggered when an object is updated in Cloud Storage.

**Respuesta de la fuente:** B

**Explicación:** Eventarc is the recommended modern solution for triggering Cloud Run from Cloud Storage events, offering flexible filtering (e.g., by filename patterns) and decoupling the trigger configuration from the application code. This architecture supports the requirement for simplicity in maintenance, as multiple team members can update trigger conditions via Eventarc without redeploying the application.

Option C is a strong alternative but uses first-generation Cloud Functions, which are being deprecated in favor of the second-generation functions that rely on Eventarc for this exact use case; therefore, B represents the more future-proof and aligned architecture.

## Pregunta 264

Contexto: [topics:726](#topics-726)
You are defining your system tests for an application running in Cloud Run in a Google Cloud project. You need to create a testing environment that is isolated from the production environment. You want to fully automate the creation of the testing environment with the least amount of effort and execute automated tests. What should you do?

**A.** Using Cloud Build, execute Terraform scripts to create a new Google Cloud project and a Cloud Run instance of your application in the Google Cloud project.

**B.** Using Cloud Build, execute a Terraform script to deploy a new Cloud Run revision in the existing Google Cloud project. Use traffic splitting to send traffic to your test environment.

**C.** Using Cloud Build, execute gcloud commands to create a new Google Cloud project and a Cloud Run instance of your application in the Google Cloud project.

**D.** Using Cloud Build, execute gcloud commands to deploy a new Cloud Run revision in the existing Google Cloud project. Use traffic splitting to send traffic to your test environment.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it satisfies both key requirements: isolation and automation. Creating a separate Google Cloud project ensures the test environment is fully isolated from production, avoiding conflicts with IAM policies or quotas. Using Terraform within Cloud Build provides a robust, declarative Infrastructure-as-Code (IaC) approach that allows for the full automation of creating both the new project and the Cloud Run service with minimal manual effort.

Options B and D are incorrect because they deploy into the existing production project, failing to meet the isolation requirement. Option C is less optimal than A because using raw gcloud commands for provisioning complex infrastructure like a new project alongside application deployment is generally less maintainable and harder to automate reliably compared to the structured, idempotent nature of Terraform.

## Pregunta 265

Contexto: [topics:726](#topics-726)
You are a cluster administrator for Google Kubernetes Engine (GKE). Your organization’s clusters are enrolled in a release channel. You need to be informed of relevant events that affect your GKE clusters, such as available upgrades and security bulletins. What should you do?

**A.** Configure cluster notifications to be sent to a Pub/Sub topic.

**B.** Execute a scheduled query against the google_cloud_release_notes BigQuery dataset.

**C.** Query the GKE API for available versions.

**D.** Create an RSS subscription to receive a daily summary of the GKE release notes.

**Respuesta de la fuente:** A

**Explicación:** Google Kubernetes Engine provides a dedicated Cluster Notifications feature that allows administrators to subscribe to events such as upgrades and security bulletins via Cloud Pub/Sub topics. This mechanism directly addresses the requirement to be informed of relevant cluster events in an automated, programmable manner.

While RSS feeds (Option D) exist for general release notes, they do not provide real-time, event-driven alerts for specific cluster instances as effectively as Pub/Sub notifications.

## Pregunta 266

Contexto: [topics:726](#topics-726)
You are tasked with using C++ to build and deploy a microservice for an application hosted on Google Cloud. The code needs to be containerized and use several custom software libraries that your team has built. You do not want to maintain the underlying infrastructure of the application. How should you deploy the microservice?

**A.** Use Cloud Functions to deploy the microservice.

**B.** Use Cloud Build to create the container, and deploy it on Cloud Run.

**C.** Use Cloud Shell to containerize your microservice, and deploy it on a Container-Optimized OS Compute Engine instance.

**D.** Use Cloud Shell to containerize your microservice, and deploy it on standard Google Kubernetes Engine.

**Respuesta de la fuente:** B

**Explicación:** Cloud Run is the serverless container platform on Google Cloud that allows you to deploy containers without managing the underlying infrastructure, directly addressing the requirement to avoid infrastructure maintenance.
Cloud Build is the correct service to compile the C++ code and package it into a container image, especially given the need for custom libraries.
While Cloud Functions (A) is serverless, it has limited language support that often excludes native C++ execution without significant workarounds.
GKE (D) and Compute Engine (C) require manual management of clusters or VMs, violating the constraint to not maintain infrastructure.

## Pregunta 267

Contexto: [topics:726](#topics-726)
You need to containerize a web application that will be hosted on Google Cloud behind a global load balancer with SSL certificates. You don’t have the time to develop authentication at the application level, and you want to offload SSL encryption and management from your application. You want to configure the architecture using managed services where possible. What should you do?

**A.** Host the application on Google Kubernetes Engine, and deploy an NGINX Ingress Controller to handle authentication.

**B.** Host the application on Google Kubernetes Engine, and deploy cert-manager to manage SSL certificates.

**C.** Host the application on Compute Engine, and configure Cloud Endpoints for your application.

**D.** Host the application on Google Kubernetes Engine, and use Identity-Aware Proxy (IAP) with Cloud Load Balancing and Google-managed certificates.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Identity-Aware Proxy (IAP) provides managed authentication without requiring application-level code, satisfying the constraint of no development time for auth. Additionally, Cloud Load Balancing with Google-managed certificates handles SSL termination and certificate management offloading as requested.
Option A is incorrect because using an NGINX Ingress Controller requires managing the ingress controller itself and does not inherently provide managed authentication services like IAP.

## Pregunta 268

Contexto: [topics:726](#topics-726)
You manage a system that runs on stateless Compute Engine VMs and Cloud Run instances. Cloud Run is connected to a VPC, and the ingress setting is set to Internal. You want to schedule tasks on Cloud Run. You create a service account and grant it the roles/run.invoker Identity and Access Management (IAM) role. When you create a schedule and test it, a 403 Permission Denied error is returned in Cloud Logging. What should you do?

**A.** Grant the service account the roles/run.developer IAM role.

**B.** Configure a cron job on the Compute Engine VMs to trigger Cloud Run on schedule.

**C.** Change the Cloud Run ingress setting to 'Internal and Cloud Load Balancing.'

**D.** Use Cloud Scheduler with Pub/Sub to invoke Cloud Run.

**Respuesta de la fuente:** D

**Explicación:** When Cloud Run ingress is set to 'Internal', the service rejects direct HTTP requests from public endpoints, which causes Cloud Scheduler's default HTTP target mode to fail with a 403 error. Using Cloud Scheduler to publish messages to Pub/Sub leverages Google Cloud's internal integration pathways, allowing the scheduled trigger to invoke the Cloud Run service securely without exposing it to public internet traffic or requiring ingress configuration changes.

## Pregunta 269

Contexto: [topics:726](#topics-726)
You work on an application that relies on Cloud Spanner as its main datastore. New application features have occasionally caused performance regressions. You want to prevent performance issues by running an automated performance test with Cloud Build for each commit made. If multiple commits are made at the same time, the tests might run concurrently. What should you do?

**A.** Create a new project with a random name for every build. Load the required data. Delete the project after the test is run.

**B.** Create a new Cloud Spanner instance for every build. Load the required data. Delete the Cloud Spanner instance after the test is run.

**C.** Create a project with a Cloud Spanner instance and the required data. Adjust the Cloud Build build file to automatically restore the data to its previous state after the test is run.

**D.** Start the Cloud Spanner emulator locally. Load the required data. Shut down the emulator after the test is run.

**Respuesta de la fuente:** B

**Explicación:** Creating a new Cloud Spanner instance per build (Option B) provides the necessary isolation for concurrent automated performance tests, ensuring that parallel runs do not interfere with each other's data or metrics.
The Cloud Spanner emulator (Option D) is explicitly unsuitable here because it does not replicate the distributed architecture of production Spanner, making its performance characteristics inaccurate for detecting regressions in a real-world datastore context.

## Pregunta 270

Contexto: [topics:726](#topics-726)
Your company's security team uses Identity and Access Management (IAM) to track which users have access to which resources. You need to create a version control system that can integrate with your security team's processes. You want your solution to support fast release cycles and frequent merges to your main branch to minimize merge conflicts. What should you do?

**A.** Create a Cloud Source Repositories repository, and use trunk-based development.

**B.** Create a Cloud Source Repositories repository, and use feature-based development.

**C.** Create a GitHub repository, mirror it to a Cloud Source Repositories repository, and use trunk-based development.

**D.** Create a GitHub repository, mirror it to a Cloud Source Repositories repository, and use feature-based development.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Cloud Source Repositories (CSR) provides native integration with Google Cloud IAM for access control, satisfying the security requirement without external dependencies. Additionally, trunk-based development explicitly supports frequent merges to the main branch and minimizes merge conflicts, aligning with the stated need for fast release cycles.
Options C and D are incorrect because introducing GitHub adds unnecessary complexity and latency via mirroring, while Option B is wrong as feature-based development (using long-lived branches) increases the risk of merge conflicts.

## Pregunta 271

Contexto: [topics:726](#topics-726)
You recently developed an application that monitors a large number of stock prices. You need to configure Pub/Sub to receive messages and update the current stock price in an in-memory database. A downstream service needs the most up-to-date prices in the in-memory database to perform stock trading transactions. Each message contains three pieces or information:

• Stock symbol
• Stock price
• Timestamp for the update

How should you set up your Pub/Sub subscription?

**A.** Create a push subscription with exactly-once delivery enabled.

**B.** Create a pull subscription with both ordering and exactly-once delivery turned off.

**C.** Create a pull subscription with ordering enabled, using the stock symbol as the ordering key.

**D.** Create a push subscription with both ordering and exactly-once delivery turned off.

**Respuesta de la fuente:** C

**Explicación:** Correct Answer: C

Ordering is critical because a downstream trading service must process stock price updates for a specific symbol in strict chronological sequence to prevent stale data from overwriting newer values. By setting the ordering key to the 'Stock symbol', Pub/Sub guarantees that all messages for the same ticker are delivered in publication order, ensuring the in-memory database reflects the true current state. Pull subscriptions provide the necessary control to handle backpressure and ensure acknowledgments before processing, which is vital for maintaining data integrity in high-throughput scenarios. Exactly-once delivery is unnecessary here because idempotency can be handled by timestamp comparison, and it adds significant latency overhead not required when the latest message supersedes older ones.

## Pregunta 272

Contexto: [topics:726](#topics-726)
You are a developer at a social media company. The company runs their social media website on-premises and uses MySQL as a backend to store user profiles and user posts. Your company plans to migrate to Google Cloud, and your learn will migrate user profile information to Firestore. You are tasked with designing the Firestore collections. What should you do?

**A.** Create one root collection for user profiles, and create one root collection for user posts.

**B.** Create one root collection for user profiles, and create one subcollection for each user's posts.

**C.** Create one root collection for user profiles, and store each user's post as a nested list in the user profile document.

**D.** Create one root collection for user posts, and create one subcollection for each user's profile.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Firestore supports unbounded arrays and nested objects within a single document only up to 1 MiB, making Option C impractical for a user's potentially large number of posts.
Storing posts as subcollections (Option B) leverages Firestore's hierarchical data model, ensuring that each user's posts scale independently without hitting the size limit of their profile document while maintaining clear ownership relationships.
Option A is less efficient for retrieving all posts by a specific user compared to a direct subcollection query, and Option D inverts the logical relationship between users and their content.

## Pregunta 273

Contexto: [topics:726](#topics-726)
Your team recently deployed an application on Google Kubernetes Engine (GKE). You are monitoring your application and want to be alerted when the average memory consumption of your containers is under 20% or above 80%. How should you configure the alerts?

**A.** Create a Cloud Function that consumes the Monitoring API. Create a schedule to trigger the Cloud Function hourly and alert you if the average memory consumption is outside the defined range.

**B.** In Cloud Monitoring, create an alerting policy to notify you if the average memory consumption is outside the defined range.

**C.** Create a Cloud Function that runs on a schedule, executes kubectl top on all the workloads on the cluster, and sends an email alert if the average memory consumption is outside the defined range.

**D.** Write a script that pulls the memory consumption of the instance at the OS level and sends an email alert if the average memory consumption is outside the defined range.

**Respuesta de la fuente:** B

**Explicación:** Cloud Monitoring is the native, serverless solution for GKE metrics, allowing you to define alerting policies based on standard metrics like container memory usage without managing infrastructure.
Options A and C introduce unnecessary complexity by requiring custom Cloud Functions and schedules, which increase maintenance overhead and latency.
Option D fails because it monitors OS-level instance memory rather than individual container metrics, missing the specific requirement to track container consumption.

## Pregunta 274

Contexto: [topics:726](#topics-726)
You manage a microservice-based ecommerce platform on Google Cloud that sends confirmation emails to a third-party email service provider using a Cloud Function. Your company just launched a marketing campaign, and some customers are reporting that they have not received order confirmation emails. You discover that the services triggering the Cloud Function are receiving HTTP 500 errors. You need to change the way emails are handled to minimize email loss. What should you do?

**A.** Increase the Cloud Function's timeout to nine minutes.

**B.** Configure the sender application to publish the outgoing emails in a message to a Pub/Sub topic. Update the Cloud Function configuration to consume the Pub/Sub queue.

**C.** Configure the sender application to write emails to Memorystore and then trigger the Cloud Function. When the function is triggered, it reads the email details from Memorystore and sends them to the email service.

**D.** Configure the sender application to retry the execution of the Cloud Function every one second if a request fails.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because implementing Pub/Sub decouples the order processing system from the email sending logic, creating a durable buffer that persists messages even if the Cloud Function or third-party service experiences transient failures. This architecture inherently supports retry mechanisms and horizontal scaling, ensuring no emails are lost during high traffic spikes caused by the marketing campaign.

Option D is incorrect because client-side retries without backoff can overwhelm the failing downstream service or the Cloud Function itself, potentially exacerbating HTTP 500 errors rather than resolving them. Options A and C fail to address the fundamental lack of durability; increasing timeouts does not guarantee success for persistent failures, and Memorystore is primarily a caching layer that lacks the robust message queueing and persistence guarantees needed to prevent data loss in this context.

## Pregunta 275

Contexto: [topics:726](#topics-726)
You have a web application that publishes messages to Pub/Sub. You plan to build new versions of the application locally and need to quickly test Pub/Sub integration for each new build. How should you configure local testing?

**A.** In the Google Cloud console, navigate to the API Library, and enable the Pub/Sub API. When developing locally configure your application to call pubsub.googleapis.com.

**B.** Install the Pub/Sub emulator using gcloud, and start the emulator with a valid Google Project ID. When developing locally, configure your applicat.cn to use the local emulator by exporting the PUBSUB_EMULATOR_HOST variable.

**C.** Run the gcloud config set api_endpoint_overrides/pubsub https://pubsubemulator.googleapis.com.com/ command to change the Pub/Sub endpoint prior to starting the application.

**D.** Install Cloud Code on the integrated development environment (IDE). Navigate to Cloud APIs, and enable Pub/Sub against a valid Google Project IWhen developing locally, configure your application to call pubsub.googleapis.com.

**Respuesta de la fuente:** B

**Explicación:** To efficiently test Pub/Sub integration locally without incurring cloud costs or requiring network access to Google Cloud, you should use the local Pub/Sub emulator. Option B is correct because it installs the emulator via gcloud and correctly instructs to set the `PUBSUB_EMULATOR_HOST` environment variable, which redirects client library calls to the local instance. Option A is incorrect because calling the production API (`pubsub.googleapis.com`) incurs costs and does not provide an isolated local test environment.

## Pregunta 276

Contexto: [topics:726](#topics-726)
You recently developed an application that monitors a large number of stock prices. You need to configure Pub/Sub to receive a high volume messages and update the current stock price in a single large in-memory database. A downstream service needs the most up-to-date prices in the in-memory database to perform stock trading transactions. Each message contains three pieces or information:
•	Stock symbol
•	Stock price
•	Timestamp for the update

How should you set up your Pub/Sub subscription?

**A.** Create a pull subscription with exactly-once delivery enabled.

**B.** Create a push subscription with both ordering and exactly-once delivery turned off.

**C.** Create a push subscription with exactly-once delivery enabled.

**D.** Create a pull subscription with both ordering and exactly-once delivery turned off.

**Respuesta de la fuente:** D

**Explicación:** Option D is the correct answer because exactly-once delivery (eliminating A and C) and message ordering are unnecessary overheads that reduce throughput for high-volume stock updates where only the latest value matters. Push subscriptions (eliminating B and C as viable 'exactly-once' candidates in older exam contexts, though technically push doesn't support EOD) introduce latency; a pull subscription allows the consumer to control the rate of ingestion into the in-memory database without dropping messages due to downstream processing limits or HTTP timeout issues.

## Pregunta 277

Contexto: [topics:726](#topics-726)
Your team has created an application that is hosted on a Google Kubemetes Engine (GKE) cluster. You need to connect the application to a legacy REST service that is deployed in two GKE clusters in two different regions. You want to connect your application to the legacy service in a way that is resilient and requires the fewest number of steps. You also want to be able to run probe-based health checks on the legacy service on a separate port. How should you set up the connection? (Choose two.)

**A.** Use Traffic Director with a sidecar proxy to connect the application to the service.

**B.** Set up a proxyless Traffic Director configuration for the application.

**C.** Configure the legacy service's firewall to allow health checks originating from the sidecar proxy.

**D.** Configure the legacy service's firewall to allow health checks originating from the application.

**E.** Configure the legacy service's firewall to allow health checks originating from the Traffic Director control plane.

**Respuesta de la fuente:** A, C

**Explicación:** Traffic Director with a sidecar proxy (A) provides the necessary resilience and least-privilege connection method for cross-region GKE traffic without requiring complex proxyless configurations.
Since Traffic Director uses Envoy sidecars to perform health checks via TCP/HTTP probes on separate ports, the legacy service's firewall must explicitly allow these check origins from the sidecar infrastructure (C), not directly from the application pods.

## Pregunta 278

Contexto: [topics:726](#topics-726)
You are monitoring a web application that is written in Go and deployed in Google Kubernetes Engine. You notice an increase in CPU and memory utilization. You need to determine which function is consuming the most CPU and memory resources. What should you do?

**A.** Add print commands to the application source code to log when each function is called, and redeploy the application.

**B.** Create a Cloud Logging query that gathers the web application s logs. Write a Python script that calculates the difference between the timestamps from the beginning and the end of the application's longest functions to identify time-intensive functions.

**C.** Import OpenTelemetry and Trace export packages into your application, and create the trace provider. Review the latency data for your application on the Trace overview page, and identify which functions cause the most latency.

**D.** Import the Cloud Profiler package into your application, and initialize the Profiler agent. Review the generated flame graph in the Google Cloud console to identify time-intensive functions.

**Respuesta de la fuente:** D

**Explicación:** Google Cloud Profiler is the correct tool because it performs continuous, low-overhead profiling to collect CPU and memory usage data per function, visualizing results via flame graphs in the Google Cloud Console. This directly answers the requirement to identify specific functions consuming resources without manual code instrumentation or log parsing.
Option C (OpenTelemetry) is incorrect because tracing focuses on request latency and flow rather than granular resource consumption metrics like CPU and memory usage.

## Pregunta 279

Contexto: [topics:726](#topics-726)
You are developing a flower ordering application. Currently you have three microservices:
•	Order Service (receives the orders)
•	Order Fulfillment Service (processes the orders)
•	Notification Service (notifies the customer when the order is filled)

You need to determine how the services will communicate with each other. You want incoming orders to be processed quickly and you need to collect order information for fulfillment. You also want to make sure orders are not lost between your services and are able to communicate asynchronously. How should the requests be processed?

**A.** [Imagen: sin descripción]
Imagen · choices[0].text · sin descripción
![Imagen original](imagenes/4a1355320aab992e9cb0.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Order request — Order Service — Order Fulfillment Service — Notification Service
Google Cloud
GKE
clove Order Lg Order Futitnent Netiscation
CO— ch et —~ & sevice + GB) sevice + (B) service
Balancing 2d fod Poon
```

**B.** [Imagen: sin descripción]
Imagen · choices[1].text · sin descripción
![Imagen original](imagenes/10b1e9ca5ed2ab4c7302.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Order request — Order Service + Cloud Storage bucket — Order Fulfillment Service — Cloud Storage
bucket — Notification Service
Google Cloud
Cloud
Storage
G—-AS —-eam gor oor
Balancing Ped Ped Poe
fos]
ea
```

**C.** [Imagen: sin descripción]
Imagen · choices[2].text · sin descripción
![Imagen original](imagenes/364e2d13d0778ebbacab.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Order request — Order Service — Firestore database — Order Fulfillment Service — Firestore database —
Notification Service
Google Cloud
2
:
one te co tina setn
Co-he— os os B seve
```

**D.** [Imagen: sin descripción]
Imagen · choices[3].text · sin descripción
![Imagen original](imagenes/b5e5a6d3251c5fb3f4ef.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Order request — Order Service — Pub/Sub queue — Order Fulfillment Service — Firestore database —
Pub/Sub queue — Notification Service
Google Cloud
thy pws
GKE
cont ae ovr seston
O-aAS os ox @ me
| |
```

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it utilizes Cloud Pub/Sub to decouple the microservices, ensuring asynchronous communication and preventing data loss if a downstream service is temporarily unavailable.
This architecture allows the Order Service to publish messages immediately for quick processing while Fulfillment and Notification services consume them at their own pace, meeting all stated requirements.

## Pregunta 280

Contexto: [topics:726](#topics-726)
You recently deployed an application to GKE where Pods are writing files to a Compute Engine persistent disk. You have created a PersistentVolumeClaim (PVC) and a PersistentVolume (PV) object on Kubernetes for the disk, and you reference the PVC in the deployment manifest file.

You recently expanded the size of the persistent disk because the application has used up almost all of the disk space. You have logged on to one of the Pods, and you notice that the disk expansion is not visible in the container file system. What should you do?

**A.** Set the spec.capacity.storage value of the PV object to match the size of the persistent disk. Apply the updated configuration by using kubectl.

**B.** Recreate the application Pods by running the kubectl delete deployment DEPLOYMENT_NAME && kubectl apply deployment.yaml command, where the DEPLOYMENT_NAME parameter is the name of your deployment and deployment.yaml is its manifest file.

**C.** Set the spec.resources.requests.storage value of the PVC object to match the size of the persistent disk. Apply the updated configuration by using kubectl.

**D.** In the Pod, resize the disk partition to the maximum value by using the fdisk or parted utility.

**Respuesta de la fuente:** C

**Explicación:** In Kubernetes, the PersistentVolumeClaim (PVC) acts as the request for storage; to make an expanded underlying disk visible to the Pod, you must update the PVC's spec.resources.requests.storage to match the new size.
Kubernetes controllers will then reconcile this change with the underlying PersistentVolume and propagate the new capacity to the mounted filesystem.
Updating the PV directly (Option A) is incorrect because PV objects are typically managed by the storage provisioner or controller, and manual edits may be overwritten or ignored without a corresponding PVC request update.

## Pregunta 281

Contexto: [topics:726](#topics-726)
You work for an ecommerce company. You are designing a new Orders API that will be exposed through Apigee. In your Apigee organization, you created two new environments named orders-test and orders-prod. You plan to use unique URLs named test.lnk-42.com/api/v1/orders and Ink-42.com/api/v1/orders for each environment. You need to ensure that each environment only uses the assigned URL. What should you do?

**A.** 1. Attach orders-test and orders-prod to the orders environment group.
2. Add each hostname to the appropriate environment.

**B.** 1. Attach orders-test and orders-prod to the orders environment group.
2. Add each hostname to the orders environment group.

**C.** 1. Attach orders-test to the test environment group, and attach orders-prod to the production environment group.
2. Add each hostname to the appropriate environment.

**D.** 1. Attach orders-test to the test environment group, and attach orders-prod to the production environment group.
2. Add each hostname to the appropriate environment group.

**Respuesta de la fuente:** D

**Explicación:** In Apigee, hostnames are configured at the Environment Group level, not on individual environments. To ensure that specific URLs route traffic exclusively to their designated environment (e.g., test or prod), you must attach each environment to its corresponding group and define the hostname within that group configuration. Options A, B, and C fail because they either attempt to assign hostnames to individual environments (which is not supported) or mix up where the hostname binding occurs.

## Pregunta 282

Contexto: [topics:726](#topics-726)
You are developing an application that uses microservices architecture that includes Cloud Run, Bigtable, and Pub/Sub. You want to conduct the testing and debugging process as quickly as possible to create a minimally viable product with minimal cost. What should you do?

**A.** Use Cloud Shell Editor and Cloud Shell to deploy the application, and test the functionality by using the Google Cloud console in the project.

**B.** Use emulators to test the functionality of cloud resources locally, and deploy the code to your Google Cloud project.

**C.** Use Cloud Build to create a pipeline, and add the unit testing stage and the manual approval stage. Deploy the code to your Google Cloud project.

**D.** Use Cloud Code to develop, deploy, and test microservices resources. Use Cloud Logging to review the resource logs.

**Respuesta de la fuente:** B

**Explicación:** Using local emulators for Bigtable and Pub/Sub allows you to simulate cloud services without incurring API costs or waiting for remote provisioning, which directly addresses the goals of minimal cost and speed.
This approach enables rapid iteration and debugging on your local machine before committing resources to the live Google Cloud environment.

## Pregunta 283

Contexto: [topics:726](#topics-726)
You are a lead developer at an organization that recently integrated several Google Cloud services. These services are located within Virtual Private Cloud (VPC) environments that are secured with VPC Service Controls and Private Service Connect endpoints. Developers across your organization use different operating systems, development frameworks, and integrated development environments (IDEs). You need to recommend a developer environment that will ensure consistency in the developer process and improve the overall developer experience. You want this solution to:

• Enforce consistent security controls.
• Have access to Google Cloud resources and applications within the VPC.
• Allow the installation of custom tools and utilities on the development environments.

What solution should you recommend?

**A.** Use Cloud Workstations, and allow developers to create their own custom images.

**B.** Use Cloud Workstations with preconfigured base images. For custom tools and utilities, use custom images that are rebuilt weekly.

**C.** Use the Cloud Code extension with the IDEs that are used across the organization. Configure Cloud VPN to enable VPC access.

**D.** Use the Cloud Code extension with the IDEs that are used across the organization. Use Identity-Aware Proxy to enable access to the services in the VPC.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Cloud Workstations runs within the VPC, ensuring native access to resources protected by VPC Service Controls and Private Service Connect without requiring complex network configurations like VPN. It enforces consistency through preconfigured base images while allowing controlled flexibility for custom tools via regularly rebuilt custom images.
Options C and D are incorrect because they rely on local IDEs connected via Cloud Code, which struggle to maintain a consistent environment across different operating systems and frameworks, and often face connectivity challenges with strict VPC security controls compared to the managed, in-VPC nature of Workstations.

## Pregunta 284

Contexto: [topics:726](#topics-726)
You are preparing to conduct a load test on your Cloud Run service by using JMeter. You need to orchestrate the steps and services to use for an effective load test and analysis. You want to follow Google-recommended practices. What should you do?

**A.** Install JMeter on your local machine, create a log sink to BigQuery, and use Looker to analyze the results.

**B.** Set up a Compute Engine instance, install JMeter on the instance, create a log sink to a Cloud Storage bucket, and use Looker Studio to analyze the results.

**C.** Set up a Compute Engine instance, install JMeter on the instance, create a log sink to a Cloud Storage bucket, and use Looker to analyze the results.

**D.** Set up a Compute Engine instance, install JMeter on the instance, create a log sink to BigQuery, and use Looker Studio to analyze the results.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because running JMeter on a Compute Engine instance ensures scalability and network proximity compared to a local machine. BigQuery serves as the appropriate sink for structured log data required for deep performance analysis, while Looker Studio provides the visualization layer to interpret that data. Option B is incorrect because Cloud Storage lacks the analytical querying capabilities of BigQuery necessary for detailed load test metrics.

## Pregunta 285

Contexto: [topics:726](#topics-726)
You are designing a Node.js-based mobile news feed application that stores data on Google Cloud. You need to select the application's database. You want the database to have zonal resiliency out of the box, low latency responses, ACID compliance, an optional middle tier, semi-structured data storage, and network-partition-tolerant and offline-mode client libraries. What should you do?

**A.** Configure Firestore and use the Firestore client library in the app.

**B.** Configure Bigtable and use the Bigtable client in the app.

**C.** Configure Cloud SQL and use the Google Client Library for Cloud SQL in the app.

**D.** Configure BigQuery and use the BigQuery REST API in the app.

**Respuesta de la fuente:** A

**Explicación:** Firestore is the only option that supports offline persistence and network-partition-tolerant client libraries essential for mobile applications, alongside ACID transactions for semi-structured NoSQL data. Bigtable lacks general-purpose ACID compliance across documents, Cloud SQL requires active network connectivity without native offline SDK support, and BigQuery is an analytics warehouse unsuitable for low-latency transactional feeds.

## Pregunta 286

Contexto: [topics:726](#topics-726)
You are developing an application component to capture user behavior data and stream the data to BigQuery. You plan to use the BigQuery Storage Write API. You need to ensure that the data that arrives in BigQuery does not have any duplicates. You want to use the simplest operational method to achieve this. What should you do?

**A.** Create a write stream in the default type.

**B.** Create a write stream in the committed type.

**C.** Configure a Kafka cluster. Use a primary universally unique identifier (UUID) for duplicate messages.

**D.** Configure a Pub/Sub topic. Use Cloud Functions to subscribe to the topic and remove any duplicates.

**Respuesta de la fuente:** B

**Explicación:** Committed write streams in the BigQuery Storage Write API are designed to guarantee exactly-once delivery by default, effectively handling deduplication without requiring additional infrastructure. This makes them the simplest operational method compared to Default streams (which only offer at-least-once delivery) or external solutions like Kafka or Pub/Sub.
Reference: Google Cloud documentation on BigQuery Storage Write API stream types.

## Pregunta 287

Contexto: [topics:726](#topics-726)
You maintain a popular mobile game deployed on Google Cloud services that include Firebase, Firestore, and Cloud Functions. Recently, the game experienced a surge in usage, and the application encountered HTTP 429 RESOURCE_EXHAUSTED errors when accessing the Firestore API. The application has now stabilized. You want to quickly fix this issue because your company has a marketing campaign next week and you expect another surge in usage. What should you do?

**A.** Request a quota increase, and modify the application code to retry the Firestore API call with fixed backoff.

**B.** Request a quota increase, and modify the application code to retry the Firestore API call with exponential backoff.

**C.** Optimize database queries to reduce read/write operations, and modify the application code to retry the Firestore API call with fixed backoff.

**D.** Optimize database queries to reduce read/write operations, and modify the application code to retry the Firestore API call with exponential backoff.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because requesting a quota increase is the fastest administrative action to resolve HTTP 429 errors immediately before the campaign, whereas optimizing queries (Options C and D) requires code changes and testing that take longer. Additionally, exponential backoff is the standard best practice for retrying API calls during resource exhaustion, making it superior to fixed backoff used in Option A.

## Pregunta 288

Contexto: [topics:726](#topics-726)
You are developing a mobile application that allows users to create and manage to-do lists. Your application has the following requirements:

• Store and synchronize data between different mobile devices.
• Support offline access.
• Provide real-time updates on each user's device.

You need to implement a database solution while minimizing operational effort. Which approach should you use?

**A.** Create a Cloud SQL for MySQL instance. Implement a data model to store to-do list information. Create indexes for the most heavily and frequently used queries.

**B.** Create a Bigtable instance. Design a database schema to avoid hotspots when writing data. Use a Bigtable change stream to capture data changes.

**C.** Use Firestore as the database. Configure Firestore offline persistence to cache a copy of the Firestore data. Listen to document changes to update applications whenever there are document changes.

**D.** Implement a SQLite database on each user's device. Use a scheduled job to synchronize each device database with a copy stored in Cloud Storage.

**Respuesta de la fuente:** C

**Explicación:** Firestore is the optimal choice because it natively supports real-time listeners for updates and built-in offline persistence, directly satisfying all three requirements with minimal development effort.
Alternative A (Cloud SQL) requires complex custom logic for real-time synchronization and offline handling, while B (Bigtable) is overengineered for this use case. D (SQLite + Cloud Storage) lacks native real-time capabilities and involves significant synchronization overhead.

## Pregunta 289

Contexto: [topics:726](#topics-726)
You manage an application deployed on GKE clusters across multiple environments. You are using Cloud Build to run user acceptance testing (UAT) tests. You have integrated Cloud Build with Artifact Analysis, and enabled the Binary Authorization API in all Google Cloud projects hosting your environments. You want only container images that have passed certain automated UAT tests to be deployed to the production environment. You have already created an attestor. What should you do next?

**A.** After the UAT phase, sign the attestation with a key stored as a Kubernetes secret. Add a GKE cluster-specific rule in Binary Authorization for the UAT Google Cloud project.

**B.** After the UAT phase, sign the attestation with a key stored as a Kubernetes secret. Add a GKE cluster-specific rule in Binary Authorization for the production Google Cloud project policy.

**C.** After the UAT phase, sign the attestation with a key stored in Cloud Key Management Service (KMS). Add a default rule in Binary Authorization for the UAT Google Cloud project.

**D.** After the UAT phase, sign the attestation with a key stored in Cloud Key Management Service (KMS). Add a GKE cluster-specific rule in Binary Authorization for the production Google Cloud project policy.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it follows Google Cloud security best practices by using Cloud KMS (instead of Kubernetes secrets) to securely store and manage the signing key for attestations. Furthermore, Binary Authorization policies must be configured in the production project where the deployment occurs, specifically using a GKE cluster-specific rule to enforce that only attested images are deployed to the target environment.

## Pregunta 290

Contexto: [topics:726](#topics-726)
You work for a company that operates an ecommerce website. You are developing a new integration that will manage all order fulfillment steps after orders are placed. You have created multiple Cloud Functions to process each order. You need to orchestrate the execution of the functions, using the output of each function to determine the flow. You want to minimize the latency of this process. What should you do?

**A.** Use Workflows to call the functions, and use callbacks to handle the execution logic.

**B.** Use Workflows to call the functions, and use conditional jumps to handle the execution logic.

**C.** Use Cloud Composer to call the functions, and use an Apache Airflow HTTP operator to handle the execution logic.

**D.** Use Cloud Composer to call the functions, and use an Apache Airflow operator to handle the execution logic.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Workflows is the native serverless orchestration service designed to execute a sequence of functions and services with minimal latency compared to container-based solutions like Cloud Composer (Airflow). The specific requirement to use the output of each function to determine the flow mandates the use of conditional jumps within the Workflow definition, which dynamically controls execution paths based on runtime data.

## Pregunta 291

Contexto: [topics:726](#topics-726)
You are currently pushing container images to Artifact Registry and deploying a containerized microservices application to GKE. After deploying the application, you notice that the services do not behave as expected. You use the kubectl get pods command to inspect the state of the application Pods, and discover that one of the Pods has a state of CrashLoopBackoff. How should you troubleshoot the Pod?

**A.** Connect to the problematic Pod by running the kubectl exec -it POD_NAME - /bin/bash command where the POD_NAME parameter is the name of the problematic Pod. Inspect the logs in the /var/log/messages folder to determine the root cause.

**B.** Execute the gcloud projects get-iam-policy PROJECT_ID command where the PROJECT_ID parameter is the name of the project where your Artifact Registry resides. Inspect the IAM bindings of the node pool s service account. Validate if the service account has the roles/artifactregistry.reader role.

**C.** Run the kubectl logs POD_NAME command where the POD_NAME parameter is the name of the problematic Pod. Analyze the logs of the Pod from previous runs to determine the root cause of failed start attempts of the Pod.

**D.** In the Google Cloud console, navigate to Cloud Logging in the project of the cluster’s VPC. Enter a filter to show denied egress traffic to the Private Google Access CIDR range. Validate if egress traffic is denied from your GKE cluster to the Private Google Access CIDR range.

**Respuesta de la fuente:** C

**Explicación:** When a Pod enters CrashLoopBackOff state, the most immediate and effective troubleshooting step is to examine the application logs generated by the container during its failed startup attempts. Running kubectl logs with the --previous flag retrieves stdout/stderr from the previous container instance, revealing specific errors like missing config or code exceptions that caused the crash.

Option A is incorrect because containers typically lack /var/log/messages (which is an OS-level log) and the shell might not even be available if the image does not contain bash.

## Pregunta 292

Contexto: [topics:726](#topics-726)
You use Cloud Build to build and test container images prior to deploying them to Cloud Run. Your images are stored in Artifact Registry. You need to ensure that only container images that have passed testing are deployed. You want to minimize operational overhead. What should you do?

**A.** Deploy a new revision to a Cloud Run service. Assign a tag that allows access to the revision at a specific URL without serving traffic. Test that revision again. Migrate the traffic to the Cloud Run service after you confirm that the new revision is performing as expected.

**B.** Enable Binary Authorization on your Cloud Run service. Create an attestation if the container image has passed all tests. Configure Binary Authorization to allow only images with appropriate attestation to be deployed to the Cloud Run service.

**C.** Create a GKE cluster. Verify that all tests have passed, and then deploy the image to the GKE cluster.

**D.** Configure build provenance on your Cloud Build pipeline. Verify that all the tests have passed, and then deploy the image to a Cloud Run service.

**Respuesta de la fuente:** B

**Explicación:** Binary Authorization is the native GCP mechanism designed to enforce admission policies for container images based on verified attestations, ensuring that only trusted artifacts reach production.
By integrating attestation creation into Cloud Build upon test success, you automate the policy enforcement without managing additional infrastructure, thereby minimizing operational overhead as required.

## Pregunta 293

Contexto: [topics:726](#topics-726)
You are developing a scalable web application for internal users. Your organization uses Google Workspace. You need to set up authentication to the application for the users, and then deploy the application on Google Cloud. You plan to use cloud-native features, and you want to minimize infrastructure management effort. What should you do? (Choose two.)

**A.** Create a Compute Engine VM, configure a web server, and deploy the application in a VPC.

**B.** Containerize the application, and deploy it as a Cloud Run service.

**C.** Configure Cloud SQL database with a table containing the users and password hashes. Add an authentication screen to ensure that only internal users can access the application.

**D.** Configure Identity Aware Proxy, and grant the roles/iap.httpsResourceAccessor IAM role to the users that need to access the application.

**E.** Configure Identity Aware Proxy, and grant the roles/iap.tunnelResourceAccessor IAM role to the users that need to access the application.

**Respuesta de la fuente:** B, D

**Explicación:** Cloud Run is a fully managed serverless platform that automatically scales and eliminates infrastructure management, directly satisfying the requirement to minimize effort while ensuring scalability.
Identity-Aware Proxy (IAP) leverages Google Workspace credentials for secure authentication without requiring custom code, and the roles/iap.httpsResourceAccessor role specifically grants access to web applications over HTTPS.

## Pregunta 294

Contexto: [topics:726](#topics-726)
You work for an ecommerce company, and you are responsible for deploying and managing multiple APIs. The operations team wants to review the traffic patterns in the orders-prod and users-prod environments. These are the only environments in the store-prod environment group. You want to follow Google-recommended practices. What should you do?

**A.** Assign the Apigee Analytics Viewer IAM role to the operations team for both environments. Use Cloud Monitoring to review traffic patterns.

**B.** Assign the Apigee Analytics Viewer IAM role to the operations team for both environments. Use Apigee API Analytics to review traffic patterns.

**C.** Assign the Apigee API Reader IAM role to each user of the operations team for both environments. Use Cloud Monitoring to review traffic patterns.

**D.** Assign the Apigee API Reader IAM role to each user of the operations team for both environments. Use Apigee API Analytics to review traffic patterns.

**Respuesta de la fuente:** B

**Explicación:** Apigee API Analytics is the specialized tool designed to monitor and visualize API-specific traffic patterns, such as request counts, latency, and error rates, whereas Cloud Monitoring focuses primarily on infrastructure metrics. Assigning the Apigee Analytics Viewer IAM role follows the principle of least privilege by granting only read access to analytics data without exposing configuration or management permissions.

## Pregunta 295

Contexto: [topics:726](#topics-726)
You are migrating a containerized application to Cloud Run. You plan to use Cloud Build to build your container image and push it to Artifact Registry, and you plan to use Cloud Deploy to deploy the image to production. You need to ensure that only secure images are deployed to production. What should you do?

**A.** Use Cloud Armor in front of Cloud Run to protect the container image from threats.

**B.** Use Artifact Analysis to scan the image for vulnerabilities. Use Cloud Key Management Service to encrypt the image to be deployed to production.

**C.** Use Secret Manager to store the encrypted image. Deploy this image to production.

**D.** Use Binary Authorization to enforce a policy that only allows images that have been signed with a trusted key to be deployed to production.

**Respuesta de la fuente:** D

**Explicación:** Binary Authorization enforces admission control policies that verify container image signatures against trusted keys before deployment, ensuring only authorized images run in production.
Option A is incorrect because Cloud Armor provides WAF/DDoS protection at the network edge and does not validate image integrity during deployment.

## Pregunta 296

Contexto: [topics:726](#topics-726)
Your team uses Cloud Storage for a video and image application that was recently migrated to Google Cloud. Following a viral surge, users are reporting application instability, coinciding with a 10x increase in HTTP 429 error codes from Cloud Storage APIs. You need to resolve the errors and establish a long-term solution. You want to ensure that the application remains stable if the load increases again in the future. What should you do?

**A.** Optimize the application code to reduce unnecessary calls to Cloud Storage APIs to prevent HTTP 429 errors.

**B.** Compress the video and images files to reduce their size, and minimize storage costs and bandwidth usage. Implement a custom throttling mechanism in the application that limits the number of concurrent API calls.

**C.** Migrate all image and video data to Firestore. Replace the Cloud Storage APIs in the application code with the new Firestore database.

**D.** Implement a retry strategy with exponential backoff for requests that encounter HTTP 429 errors.

**Respuesta de la fuente:** D

**Explicación:** HTTP 429 errors indicate that the application has exceeded Cloud Storage's request rate limits due to the viral surge. Implementing a retry strategy with exponential backoff (Option D) is the standard best practice for handling these transient throttling errors, allowing the application to gracefully recover without overwhelming the API further.

Option A is incorrect because optimizing code addresses efficiency but does not solve the immediate stability issue caused by legitimate high-volume traffic exceeding hard rate limits.

## Pregunta 297

Contexto: [topics:726](#topics-726)
You are developing a container build pipeline for an application hosted on GKE. You have the following requirements:

• Only images that are created using your build pipeline should be deployed on your GKE cluster.
• All code and build artifacts should remain within your environment and protected from data exfiltration.

How should you build the pipeline?

**A.** 1. Create a build pipeline by using Cloud Build with the default worker pool.
2. Deploy container images to a private container registry in your VPC.
3. Create a VPC firewall policy in your project that denies all egress and ingress traffic to public networks.

**B.** 1. Create a build pipeline by using Cloud Build with a private worker pool.
2. Use VPC Service Controls to place all components and services in your CI/CD pipeline inside a security perimeter.
3. Configure your GKE cluster to only allow container images signed by Binary Authorization.

**C.** 1. Create a build pipeline by using Cloud Build with a private worker pool.
2. Configure the CI/CD pipeline to build container images and store them in Artifact Registry.
3. Configure Artifact Registry to encrypt container images by using customer-managed encryption keys (CMEK).

**D.** 1. Create a build pipeline by using Cloud Build with the default worker pool.
2. Configure the CI/CD pipeline to build container images and store them in Artifact Registry.
3. Configure your GKE cluster to only allow container images signed by Binary Authorization.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because using a private worker pool and VPC Service Controls ensures build artifacts remain within your environment, preventing data exfiltration. Additionally, Binary Authorization enforces the requirement that only images from the trusted pipeline are deployed to GKE.

Option A is incorrect because default worker pools do not guarantee network isolation or prevent data exfiltration as effectively as private pools with service controls. Options C and D fail to adequately address either the data exfiltration risk (C) or the restricted deployment source requirement (D uses default pools).

## Pregunta 298

Contexto: [topics:726](#topics-726)
You are a developer at a company that operates an ecommerce website. The website stores the customer order data in a Cloud SQL for PostgreSQL database. Data scientists on the marketing team access this data to run their reports. Every time they run these reports, the website's performance is negatively affected. You want to provide access to up-to-date customer order datasets without affecting your website. What should you do?

**A.** Configure Cloud Scheduler to run an hourly Cloud Function that exports the data from the Cloud SQL database into CSV format and sends the data to a Cloud Storage bucket.

**B.** Set up a Bigtable table for the data science team. Configure the application to perform dual writes to both Cloud SQL and Bigtable simultaneously.

**C.** Set up a BigQuery dataset for the data science team. Configure Datastream to replicate the relevant Cloud SQL tables in BigQuery.

**D.** Create a clone of the PostgreSQL database instance for the data science team. Schedule a job to create a new clone every 15 minutes.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because BigQuery is a serverless data warehouse optimized for analytics, preventing heavy reporting queries from impacting the transactional performance of the Cloud SQL database. Datastream provides continuous, near-real-time replication, ensuring data scientists have up-to-date information without requiring manual export schedules or application code changes.

Option A is incorrect because exporting to CSV hourly introduces significant data staleness compared to continuous replication. Option B is wrong because Bigtable is a NoSQL key-value store not suited for relational analytics like customer order reports, and dual writes add unnecessary complexity. Option D is impractical because cloning a database every 15 minutes is resource-intensive and does not provide real-time data access.

## Pregunta 299

Contexto: [topics:726](#topics-726)
You are developing a web application by using Cloud Run and Cloud Storage. You are notified of a production issue that you need to troubleshoot immediately. You need to implement a workaround that requires you to execute a script on a Git repository. Your corporate laptop is unavailable but you have your personal computer. You can use your corporate credentials to access the required Git repository and Google Cloud resources. You want to fix the issue as quickly and efficiently as possible while minimizing additional cost. What should you do?

**A.** Create and launch a workstation with Cloud Workstations on your personal computer. Authenticate and set up API access in the workstation. Clone the Git repository and execute the workaround script. Ensure that the issue has been fixed.

**B.** Install VS Code and the extension Cloud Code for VS Code on your personal computer. Check the Cloud Run logs in Cloud Code to confirm the error. Execute the workaround script. Ensure that the issue has been fixed.

**C.** Connect to the Google Cloud console and open Cloud Shell on your personal computer. Clone the Git repository and execute the workaround script. Ensure that the issue has been fixed.

**D.** Download and install the gcloud CLI on your personal computer. Authenticate and set up API access. Clone the Git repository and execute the workaround script. Ensure that the issue has been fixed.

**Respuesta de la fuente:** C

**Explicación:** Cloud Shell (Option C) is the optimal solution because it provides an immediate, pre-configured Linux environment with the gcloud CLI and git already installed, accessible via any browser without local setup. This meets the requirements for speed ('immediately') and cost minimization by avoiding the provisioning of compute instances like Cloud Workstations or the time-consuming installation of local tools.

Option B is incorrect because installing VS Code and extensions locally takes more time than opening a pre-existing web shell, violating the 'quickly' constraint. Option A is wrong because Cloud Workstations incur compute costs and require setup time, failing the 'minimizing additional cost' and speed criteria.

## Pregunta 300

Contexto: [topics:726](#topics-726)
You are using App Engine and Cloud SQL for PostgreSQL to develop an application. You want to test your application code locally before deploying new application versions to the development environment that is shared with other developers. You need to set up your App Engine local development environment to test your application while keeping all traffic to Cloud SQL instances encrypted and authenticated to Cloud IAM and PostgreSQL. What should you do before starting the local development server?

**A.** Install PostgreSQL on your local workstation. Run a local PostgreSQL database on your workstation. Configure the application to connect to a PostgreSQL instance on localhost.

**B.** Download and install the Cloud SQL Auth Proxy to your local development environment. Configure the Cloud SQL Auth Proxy to connect to the Cloud SQL instance and run the proxy. Configure the application to connect to a PostgreSQL instance on localhost.

**C.** Deploy a Compute Engine instance, and install HAProxy on the instance. Configure Cloud SQL Auth Proxy on the instance, and use the instance’s service account to authenticate to Cloud SQL. Configure the application to connect to the Compute Engine instance's IP address.

**D.** Configure your local development server to connect to the private IP address of the Cloud SQL instance. Encrypt database entries with a cryptographic library before submitting them to the database. Store the decryption key as an environment variable in App Engine.

**Respuesta de la fuente:** B

**Explicación:** The Cloud SQL Auth Proxy is the recommended tool for local development because it automatically handles SSL/TLS encryption and authenticates connections using a service account's credentials, satisfying both security requirements.
Option A is incorrect because running a local database does not test the integration with Cloud SQL nor ensure IAM-based authentication to the cloud instance.

## Pregunta 301

Contexto: [topics:726](#topics-726)
You are developing a public web application on Cloud Run. You expose the Cloud Run service directly with its public IP address. You are now running a load test to ensure that your application is resilient against high traffic loads. You notice that your application performs as expected when you initiate light traffic. However, when you generate high loads, your web server runs slowly and returns error messages. How should you troubleshoot this issue?

**A.** Check the network traffic to Cloud Run in Cloud Monitoring to validate whether a traffic spike occurred. If necessary, enable traffic splitting on the Cloud Run instance to route some of the traffic to a previous instance revision.

**B.** Check the min-instances value for your Cloud Run service. If necessary, increase the min-instances value to match the maximum number of virtual users in your load test.

**C.** Check whether Cloud Armor is detecting distributed denial of service (DDoS) attacks and is blocking traffic before the traffic is routed to your Cloud Run service. If necessary, disable any Cloud Armor policies in your project.

**D.** Check whether the Cloud Run service has scaled to a number of instances that equals the max-instances value. If necessary, increase the max-instances value.

**Respuesta de la fuente:** D

**Explicación:** Cloud Run automatically scales instances based on traffic up to a defined maximum limit (max-instances). If the service hits this ceiling during high load, new requests are queued or rejected, causing latency and errors. Increasing max-instances allows more concurrent requests to be handled simultaneously. Option B is incorrect because min-instances only addresses cold-start latency by keeping idle instances ready, not capacity limits under heavy load.

## Pregunta 302

Contexto: [topics:726](#topics-726)
You are developing a new image processing application that needs to handle various tasks, such as resizing, cropping, and watermarking images. You also need to monitor the workflow and ensure that it scales efficiently when there are large volumes of images. You want to automate the image processing tasks and workflow monitoring with the least effort. What should you do?

**A.** Employ Cloud Composer to manage the image processing workflows. Use Dataproc for workflow monitoring and analytics.

**B.** Use Cloud Run to deploy the image processing functions. Use Apigee to expose the API. Use Cloud Logging for workflow monitoring.

**C.** Implement Workflows to orchestrate the image processing tasks. Use Cloud Logging for workflow monitoring.

**D.** Use Cloud Build to trigger Cloud Functions for the image processing tasks. Use Cloud Monitoring for workflow monitoring.

**Respuesta de la fuente:** C

**Explicación:** Google Cloud Workflows is specifically designed to orchestrate sequences of tasks across various GCP services, making it the ideal low-effort solution for automating multi-step image processing pipelines like resizing and watermarking. It natively integrates with Cloud Logging for monitoring execution steps and errors without requiring complex infrastructure setup.

Option B is incorrect because Cloud Run is a compute service for running containers rather than an orchestration engine, meaning it would require significant additional code to manage the state and sequence of dependent tasks.

## Pregunta 303

Contexto: [topics:726](#topics-726)
You are developing a web application that will be deployed to production on Cloud Run. The application consists of multiple microservices, some of which will be publicly accessible and others that will only be accessible after authentication by Google identities. You need to ensure that only authenticated users can access the restricted services, while allowing unrestricted access to the public services of the application. You want to use the most secure approach while minimizing management overhead and complexity. How should you configure access?

**A.** Enable Identity-Aware Proxy (IAP) for all microservices. Develop a new microservice that checks the authentication requirements for each application and controls access to the respective services.

**B.** Enable Identity-Aware Proxy (IAP) for all microservices. Manage access control lists (ACLs) for the restricted services, and configure allAuthenticatedUsers access to the public services.

**C.** Use Cloud Endpoints with Firebase Authentication for all microservices. Configure Firebase rules to manage access control lists (ACLs) for each service, allowing access to the public services.

**D.** Configure separate Cloud Run services for the public and restricted microservices. Enable Identity-Aware Proxy (IAP) only for the restricted services, and configure the Cloud Run ingress settings to ‘Internal and Cloud Load Balancing’.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it aligns with the principle of least privilege by enabling Identity-Aware Proxy (IAP) only on services requiring authentication, thereby minimizing overhead. Public services remain accessible without IAP configuration, while restricted services leverage GCP's native IAM enforcement. Options A and B are incorrect as they impose unnecessary complexity and cost by applying IAP to all microservices. Option C is suboptimal because using Firebase Authentication with Cloud Endpoints introduces additional management overhead compared to using GCP's built-in IAM for Google identities.

## Pregunta 304

Contexto: [topics:726](#topics-726)
You are the lead developer for a company that provides a financial risk calculation API. The API is built on Cloud Run and has a gRPC interface. You frequently develop optimizations to the risk calculators. You want to enable these optimizations for select customers who registered to try out the optimizations prior to rolling out the optimization to all customers. Your CI/CD pipeline has built a new image and stored it in the Artifact Registry.

Which rollout strategy should you use?

**A.** Migrate the traffic to the new service by setting Cloud Run’s traffic split based on the percentage of registered customers.

**B.** Migrate the traffic to the new service by using a blue/green deployment approach.

**C.** Migrate the traffic to the new service by using a feature flag for registered customers.

**D.** Migrate the traffic to the new service and enable session affinity for Cloud Run.

**Respuesta de la fuente:** C

**Explicación:** Feature flags allow for precise, user-level control over feature availability, ensuring only registered customers see the optimizations regardless of which service revision handles their request.
Traffic splitting (A) routes based on percentage rather than specific customer identity, while blue/green deployments (B) and session affinity (D) typically shift traffic at the infrastructure or session level, failing to target individual opted-in users accurately.

## Pregunta 305

Contexto: [topics:726](#topics-726)
Your ecommerce application has a rapidly growing user base, and it is experiencing performance issues due to excessive requests to your backend API. Your team develops and manages this API. The Cloud SQL backend database is struggling to handle the high demand, leading to latency and timeouts. You need to implement a solution that optimizes API performance and improves user experience. What should you do?

**A.** Use Apigee to expose your API. Use Memorystore for Redis to cache frequently accessed data. Implement exponential backoff in the application to retry failed requests.

**B.** Use Apigee to expose your API. Implement rate limiting and access control policies in Apigee to control API traffic. Use Pub/Sub to queue requests to prevent database overload.

**C.** Use Cloud Load Balancing to expose your API. Use Cloud CDN in front of the load balancer to cache responses. Implement exponential backoff to retry failed requests.

**D.** Use Cloud Load Balancing to expose your API. Increase the memory for the database instances to handle more concurrent requests. Implement a custom rate-limiting mechanism in your application code to control API requests.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Memorystore for Redis significantly reduces Cloud SQL load by caching frequent reads, directly addressing the database performance bottleneck. Apigee provides essential API management capabilities for scaling and security, while exponential backoff prevents application-level retries from exacerbating system overload during transient failures.
Option B is incorrect because Pub/Sub introduces unnecessary latency for interactive ecommerce transactions that require immediate responses, making it unsuitable for this real-time use case.

## Pregunta 306

Contexto: [topics:726](#topics-726)
You need to deploy a new feature into production on Cloud Run. Your company’s SRE team mandates gradual deployments to avoid large downtimes caused by code change errors. You want to configure this deployment with minimal effort. What should you do?

**A.** Configure the application’s frontend load balancer to toggle between the new and old revisions.

**B.** Configure the application code to send a small percentage of users to the newly deployed revision.

**C.** Deploy the feature with “Serve this revision immediately” unchecked, and configure the new revision to serve a small percentage of traffic. Check for errors, and increase traffic to the revision as appropriate.

**D.** Deploy the feature with “Serve this revision immediately” checked. Check for errors, roll back to the previous revision, and repeat the process until you have verified that the deployment is bug-free.

**Respuesta de la fuente:** C

**Explicación:** Cloud Run natively supports gradual traffic migration by allowing you to deploy a revision without making it the default target ('Serve this revision immediately' unchecked) and then explicitly assigning a specific percentage of traffic to it. This approach provides built-in, granular control over rollout velocity with minimal configuration effort, aligning directly with SRE mandates for low-risk deployments. Option A is incorrect because managing load balancer toggling manually introduces significant operational overhead and does not leverage Cloud Run's native deployment capabilities.

## Pregunta 307

Contexto: [topics:726](#topics-726)
You are developing an external-facing application on GKE that provides a streaming API to users. You want to offer two subscription tiers, “basic" and “premium", to users based on the number of API requests that each client application is allowed to make each day. You want to design the application architecture to provide subscription tiers to users while following Google-recommended practices. What should you do?

**A.** 1. Configure the service on GKE as a backend to an Apigee proxy.
2. Provide API keys to users to identify client applications.
3. Configure a Quota policy in Apigee for API keys based on the subscription tier.

**B.** 1. Configure the service on GKE as a backend to an Apigee proxy.
2. Provide API keys to users to identify client applications.
3. Configure a SpikeArrest policy in Apigee for API keys based on the subscription tier.

**C.** 1. Configure the service on GKE as a backend to two new projects, each with a separate Application Load Balancer.
2. Configure the quota "Queries per second (QPS) per region per network” for each project individually.
3. Provide users with API endpoints based on the subscription tier.

**D.** 1. Deploy the application to two GKE clusters, one for each subscription tier. Configure each cluster to have a separate Ingress.
2. Configure each cluster as a backend to an Apigee proxy.
3. Provide API keys to users to identify client applications.
4. Configure separate rate limits for client applications based on the subscription tier.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Apigee's Quota policy is specifically designed to enforce usage limits over a defined period (e.g., daily requests), which directly addresses the requirement for tiered subscription limits.
In contrast, Option B uses SpikeArrest, which manages burst traffic and instantaneous rate limits rather than cumulative daily quotas, making it unsuitable for this specific billing logic.

## Pregunta 308

Contexto: [topics:726](#topics-726)
Your organization has users and groups configured in an external identity provider (IdP). You want to leverage the same external IdP to allow Google Cloud console access to all employees. You also want to personalize the sign-in experience by displaying the user's name and photo when users access the Google Cloud console. What should you do?

**A.** Configure workforce identity federation with the external IdP, and set up attribute mapping.

**B.** Configure a service account for each individual by using the user name and photo, and grant permissions for each user to impersonate their respective service accounts.

**C.** Configure workload identity federation to get the external IdP tokens, and use these tokens to sign in to the Google Cloud console.

**D.** Create a Google group that includes organization email IDs for all users. Ask users to use the same name, work email ID, and password to register and sign in.

**Respuesta de la fuente:** A

**Explicación:** Workforce Identity Federation is the correct mechanism for integrating an external IdP to manage employee access to Google Cloud without creating separate Google accounts. Attribute mapping is specifically required to transfer user profile data, such as names and photos, from the IdP to Google Cloud to personalize the sign-in experience.

Option B is incorrect because service accounts are designed for machine-to-machine communication and automation, not for interactive human user sign-ins. Option C refers to Workload Identity Federation, which is intended for serverless environments or virtual machines accessing resources, rather than console access for employees.

## Pregunta 309

Contexto: [topics:726](#topics-726)
You are developing a new API that creates requests on an asynchronous message service. Requests will be consumed by different services. You need to expose the API by using a gRPC interface while minimizing infrastructure management overhead. How should you deploy the API?

**A.** Deploy your API to App Engine. Create a Pub/Sub topic, and configure your API to push messages to the topic.

**B.** Deploy your API as a Cloud Run service. Create a Pub/Sub topic, and configure your API to push messages to the topic.

**C.** Deploy your API to a GKE cluster. Create a Kafka cluster, and configure your API to write messages to the cluster.

**D.** Deploy your API on a Compute Engine instance. Create a Kafka cluster, and configure your API to write messages to the cluster.

**Respuesta de la fuente:** B

**Explicación:** Cloud Run is the correct choice because it is a fully managed serverless platform that supports gRPC services natively while eliminating infrastructure management overhead.
In contrast, App Engine (Option A) does not support gRPC traffic, and options involving GKE or Compute Engine with Kafka (Options C and D) require significantly more manual infrastructure maintenance.

## Pregunta 310

Contexto: [topics:726](#topics-726)
You are about to deploy an application hosted on a Compute Engine instance with Windows OS and Cloud SQL. You plan to use the Cloud SQL Auth Proxy for connectivity to the Cloud SQL instance. You plan to follow Google-recommended practices and the principle of least privilege. You have already created a custom service account. What should you do next?

**A.** Create and assign a custom role with the cloudsql.instances.connect permission to the custom service account. Adjust the Cloud SQL Auth Proxy start command to specify your instance connection name.

**B.** Grant the custom service account the roles/cloudsql.client role. Adjust the Cloud SQL Auth Proxy start command to use the --unix-socket CLI option.

**C.** Grant the custom service account the roles/cloudsql.editor role.

**D.** Grant the custom service account the roles/cloudsql.viewer role. Adjust the Cloud SQL Auth Proxy start command to specify your instance connection name.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it adheres to the principle of least privilege by granting only the necessary `cloudsql.instances.connect` permission via a custom role, while correctly specifying the instance connection name for the proxy on Windows. Option B is incorrect because the `--unix-socket` flag is not supported on Windows, which is the specified OS in the scenario.

## Pregunta 311

Contexto: [topics:726](#topics-726)
You are developing a secure document sharing platform. The platform allows users to share documents with other users who may be external to their organization. Access to these documents should be revoked after a configurable time period. The documents are stored in Cloud Storage. How should you configure Cloud Storage to support this functionality?

**A.** Create signed policy documents on the Cloud Storage bucket.

**B.** Apply access control list (ACL) permissions to the Cloud Storage bucket.

**C.** Generate a signed URL for each document the user wants to share.

**D.** Grant the Storage Object Viewer IAM role to all authenticated users.

**Respuesta de la fuente:** C

**Explicación:** Signed URLs allow you to grant temporary access to specific Cloud Storage objects with a configurable expiration time, directly satisfying the requirement for revocation after a set period. In contrast, ACLs and IAM roles (Options B and D) provide persistent permissions that are difficult to revoke automatically on a per-object, time-based schedule without additional logic.

## Pregunta 312

Contexto: [topics:726](#topics-726)
You work for an environmental agency in a large city. You are developing a new monitoring platform that will capture air quality readings from thousands of locations in the city. You want the air quality reading devices to send and receive their data payload to the newly created RESTful backend systems every minute by using a curl command. The backend systems are running in a single cloud region and are using Premium Tier networking. You need to connect the devices to the backend while minimizing the daily average latency, measured by using Time to First Byte (TTFB). How should you build this service?

**A.** 1. Run the air quality devices’ backends on Compute Engine VMs.
2. Create a weighted round robin routing policy on Cloud DNS.
3. Configure the air quality devices to connect by using this DNS.

**B.** 1. Run the air quality devices’ backends on Compute Engine VMs.
2. Create a round robin routing policy on Cloud DNS for these Compute Engine VMs.
3. Configure the air quality devices to connect by using this DNS.

**C.** 1. Run the air quality devices' backends in a managed instance group.
2. Create an external passthrough Network Load Balancer to connect to the managed instance group.
3. Configure a connection between the air quality devices and the Network Load Balancer.

**D.** 1 Run the air quality devices' backends in a managed instance group.
2. Create an external Application Load Balancer, and connect it to the managed instance group.
3. Configure a connection between the air quality devices and the Application Load Balancer.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because the Application Load Balancer (ALB) performs Layer 7 load balancing, which is required for RESTful HTTP/HTTPS traffic and offers superior global anycast IPs to minimize TTFB by routing requests to the closest backend instance. In contrast, Option C uses a Network Load Balancer (L4), which lacks HTTP-aware features and has higher latency for this specific protocol, while Options A and B rely on DNS-based resolution which introduces higher initial connection latency compared to an anycast IP.

## Pregunta 313

Contexto: [topics:726](#topics-726)
Your infrastructure team is responsible for creating and managing Compute Engine VMs. Your team uses the Google Cloud console and gcloud CLI to provision resources for the development environment. You need to ensure that all Compute Engine VMs are labeled correctly for compliance reasons. In case of missing labels, you need to implement corrective actions so the labels are configured accordingly without changing the current deployment process. You want to use the most scalable approach. What should you do?

**A.** Use a Cloud Audit Logs trigger to invoke a Cloud Function when a Compute Engine VM is created. Check for missing labels and assign them if necessary.

**B.** Deploy resources with Terraform. Use the gcloud terraform vet command with a policy to ensure that every Compute Engine VM that is provisioned by Terraform has labels set.

**C.** Write a script to check all Compute Engine VMs for missing labels regularly by using Cloud Scheduler. Use the script to assign the labels.

**D.** Check all Compute Engine VMs for missing labels regularly. Use the console to assign the labels.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because using Cloud Audit Logs to trigger a Cloud Function provides an event-driven, automated way to enforce labeling at the moment of VM creation without altering the existing provisioning workflow (Console or gcloud). This approach ensures immediate compliance and scales automatically with infrastructure changes.

The most tempting alternative, Option C, involves polling via Cloud Scheduler, which introduces latency between resource creation and correction rather than enforcing rules in real-time. Additionally, Options B and D violate the requirement to avoid changing the current deployment process or manual intervention.

## Pregunta 314

Contexto: [topics:726](#topics-726)
You are developing a discussion portal that is built on Cloud Run. Incoming external requests are routed through a set of microservices before a response is sent. Some of these microservices connect to databases. You need to run a load test to identify any bottlenecks in the application when it is under load. You want to follow Google-recommended practices. What should you do?

**A.** Modify the response to include a time series that shows elapsed time per service. Use Log Analytics in Cloud Logging to create a heatmap that exposes any service that could be a bottleneck.

**B.** Configure Cloud Trace to capture the requests from the load testing clients. Review the timings in Cloud Trace.

**C.** Expose the latency metrics per service for each request. Configure Google Cloud Managed Service for Prometheus, and use it to scrape and analyze the metrics.

**D.** Add log statements that capture elapsed time. Analyze the logs and metrics by using BigQuery.

**Respuesta de la fuente:** B

**Explicación:** Cloud Trace is the recommended Google Cloud service for analyzing distributed application latency and identifying bottlenecks in microservice architectures like Cloud Run. It provides end-to-end request tracing, allowing you to visualize the timing of each service call and pinpoint specific performance issues.

Option A is incorrect because Cloud Logging is primarily for audit and error tracking, not real-time latency distribution analysis via heatmaps. Option C is less direct than Trace for identifying specific bottleneck services within a single request's lifecycle, as Prometheus focuses on aggregated metrics rather than distributed traces. Option D is inefficient because BigQuery is not designed for real-time latency analysis and requires significant manual log parsing.

## Pregunta 315

Contexto: [topics:726](#topics-726)
Your team currently uses Bigtable as their database backend. In your application's app profile, you notice that the connection to the Bigtable cluster is specified as single-cluster routing, and the cluster’s connection logic is configured to conduct manual failover when the cluster is unavailable. You want to optimize the application code to have more efficient and highly available Bigtable connectivity. What should you do?

**A.** Set up Memcached so that queries hit the cache layer first and automatically get data from Bigtable in the event of a cache miss.

**B.** Increase the Bigtable client’s connection pool size.

**C.** Configure a Dataflow template, and use a Beam connector to stream data changes.

**D.** Configure the app profile to use multi-cluster routing.

**Respuesta de la fuente:** D

**Explicación:** Multi-cluster routing within an App Profile allows the Bigtable client to automatically route read and write requests across multiple clusters in different zones, ensuring high availability if one cluster fails.
Changing from single-cluster to multi-cluster routing eliminates the need for manual failover logic by leveraging Bigtable's built-in redundancy features.
Options A, B, and C address caching, connection pooling, or data streaming, none of which directly improve the inherent availability of the database connectivity itself in the event of a cluster outage.

## Pregunta 316

Contexto: [topics:726](#topics-726)
You work for an ecommerce company. Your company is migrating multiple applications to Google Cloud, and you are assisting with the migration of one of the applications. The application is currently deployed on a VM without any OS dependencies. You have created a Dockerfile and used it to upload a new image to Artifact Registry. You want to minimize the infrastructure and operational complexity. What should you do?

**A.** Deploy the image to Cloud Run.

**B.** Deploy the image to a GKE Autopilot cluster.

**C.** Deploy the image to a GKE Standard cluster.

**D.** Deploy the image to a Compute Engine instance.

**Respuesta de la fuente:** A

**Explicación:** Cloud Run is the correct choice because it is a fully managed serverless platform that automatically scales and manages infrastructure, directly addressing the requirement to minimize operational complexity. Unlike GKE Autopilot or Standard clusters, Cloud Run abstracts away node management entirely, requiring only container images without cluster configuration.

GKE Autopilot (Option B) is the most tempting alternative as it also simplifies cluster management; however, it still involves managing Kubernetes resources and namespaces, which adds more operational overhead than deploying directly to Cloud Run.

## Pregunta 317

Contexto: [topics:726](#topics-726)
You recently deployed an Apigee API proxy to your organization across two regions. Both regions are configured with a separate backend that is hosting the API. You need to configure Apigee to route traffic to the appropriate local region backend. What should you do?

[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/4dbef8e21f73d76e1d74.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Apigee Instance Apigee Instance
Region 1 Region 2
| |
Backend Region 1 Backend Region 2
```

**A.** Create a TargetEndpoint with a weighted load balancing algorithm. Configure the API proxy to use the same weights for each region's backend.

**B.** Configure a regional internal Application Load Balancer in each region, and use health checks to verify that each backend is active. Create a DNS A record that contains the IP addresses of both regions' load balancers. Configure a Targetserver for each region that uses this DNS name.

**C.** Configure a global external Application Load Balancer and configure each region’s backend with a different regional backend service. Each region communicates to this single global external Application Load Balancer as its TargetServer.

**D.** Configure a TargetServer for each region's backend host names. Configure the API proxy to choose the TargetServer based on the system.region.name flow variable.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because the `system.region.name` flow variable explicitly identifies the runtime region of the proxy instance, allowing the API proxy to dynamically select the corresponding local backend TargetServer. This ensures requests are routed to the nearest available backend, minimizing latency and adhering to regional routing requirements.

Options A, B, and C fail to ensure regional affinity: weighted load balancing (A) distributes traffic arbitrarily rather than by proximity, while using global or shared DNS/load balancers (B and C) does not guarantee that a request handled by a specific region's proxy is routed to that same region's backend.

## Pregunta 318

Contexto: [topics:726](#topics-726)
You are a developer that works for a local concert venue. Customers use your company’s website to purchase tickets for events. You need to provide customers with immediate confirmation when a selected seat has been reserved. How should you design the ticket ordering process?

**A.** Add the seat reservation to a Cloud Tasks queue, which triggers Workflows to process the seat reservation.

**B.** Publish the seat reservation to a Pub/Sub topic. Configure the backend service to use Eventarc to process the seat reservation on GKE.

**C.** Upload the seat reservation to a Cloud Storage bucket, which triggers an event to a Cloud Run service that processes the orders.

**D.** Submit the seat reservation in an HTTP POST request to an Application Load Balancer. Configure the Application Load Balancer to distribute the request to a Compute Engine managed instance group that processes the reservation.

**Respuesta de la fuente:** D

**Explicación:** The requirement for *immediate* confirmation necessitates synchronous processing where the response is returned directly to the client upon completion. Option D uses an Application Load Balancer with Compute Engine instances to handle HTTP POST requests synchronously, ensuring the user receives a real-time confirmation once the reservation logic finishes.

Options A, B, and C rely on asynchronous patterns (Cloud Tasks, Pub/Sub/Eventarc, or Cloud Storage triggers), which introduce latency or decouple the acknowledgment from the actual processing completion, failing to guarantee immediate feedback to the customer.

## Pregunta 319

Contexto: [topics:726](#topics-726)
You work for a financial services company that has a container-first approach. Your team develops microservices applications. You have a Cloud Build pipeline that creates a container image, runs regression tests, and publishes the image to Artifact Registry. You need to ensure that only containers that have passed the regression tests are deployed to GKE clusters. You have already enabled Binary Authorization on the GKE clusters. What should you do next?

**A.** Deploy Voucher Server and Voucher Client components. After a container image has passed the regression tests, run Voucher Client as a step in the Cloud Build pipeline.

**B.** Create an attestor and a policy. Run a vulnerability scan to create an attestation for the container image as a step in the Cloud Build pipeline.

**C.** Create an attestor and a policy. Create an attestation for the container images that have passed the regression tests as a step in the Cloud Build pipeline.

**D.** Set the Pod Security Standard level to Restricted for the relevant namespaces. Digitally sign the container images that have passed the regression tests as a step in the Cloud Build pipeline.

**Respuesta de la fuente:** C

**Explicación:** Binary Authorization enforces admission control by requiring container images to be signed or attested before deployment. To ensure only tested images are deployed, you must create an attestor (representing the trusted party that ran tests) and a policy, then generate an attestation in the Cloud Build pipeline upon test success.

Option A is incorrect because Voucher has been deprecated in favor of Binary Authorization. Option B is wrong because it specifies vulnerability scanning rather than regression testing, which does not meet the specific requirement. Option D fails because Pod Security Standards control runtime permissions, not image provenance or build-stage validation.

## Pregunta 320

Contexto: [topics:726](#topics-726)
You have an application running in production on Cloud Run. Your team needs to change one of the application’s services to return a new field. You want to test the new revision on 10% of your clients using the least amount of effort. You also need to keep your service backward compatible.

What should you do?

**A.** Replace the current service with the new revision. Deploy the new revision with no traffic allocated. After the deployment, split the traffic between the previous service and the new revision.

**B.** Update the current service with the new changes. Deploy the new revision. After the deployment, split the traffic between the current service and the new revision.

**C.** Update the current service with the new changes. Deploy the new revision with no traffic allocated. Split the traffic between the current service and the new revision.

**D.** Replace the current service with the new revision. Deploy the new revision. Create a load balancer to split the traffic between the previous service and the new revision.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because deploying the new revision with no traffic allocated ensures that no clients receive untested code until you are ready to explicitly route a specific percentage (10%) of traffic to it. This controlled rollout minimizes risk and effort by leveraging Cloud Run's built-in traffic splitting capabilities without disrupting existing users or requiring external load balancers.

Option B is the most tempting alternative because it seems simpler, but it fails to ensure backward compatibility during the testing phase; if the new revision has issues, all traffic could be negatively impacted before you have a chance to limit exposure to just 10%.

## Pregunta 321

Contexto: [topics:726](#topics-726)
Your team plans to use AlloyDB as their database backend for an upcoming application release. Your application is currently hosted in a different project and network than the AlloyDB instances. You need to securely connect your application to the AlloyDB instance while keeping the projects isolated. You want to minimize additional operations and follow Google-recommended practices. How should you configure the network for database connectivity?

**A.** Provision a Shared VPC project where both the application project and the AlloyDB project are service projects.

**B.** Use AlloyDB Auth Proxy and configure the application project’s firewall to allow connections to port 5433.

**C.** Provision a service account from the AlloyDB project. Use this service account’s JSON key file as the --credentials-file to connect to the AlloyDB instance.

**D.** Ask the database team to provision AlloyDB databases in the same project and network as the application.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because the AlloyDB Auth Proxy handles SSL encryption and IAM authentication securely over public IPs without requiring complex VPC peering or Private Service Connect, satisfying the goal of minimizing operational overhead.
Option A is incorrect because Shared VPC alone does not grant access to the internal Google service network where AlloyDB resides; it requires additional configuration like Private Service Connect, which adds complexity.
Options C and D are inferior as JSON keys are less secure than IAM-based auth via the Proxy, and consolidating projects violates the requirement to keep them isolated.

## Pregunta 322

Contexto: [topics:726](#topics-726)
You have an on-premises containerized service written in the current stable version of Python 3 that is available only to users in the United States. The service has high traffic during the day and no traffic at night. You need to migrate this application to Google Cloud and track error logs after the migration in Error Reporting. You want to minimize the cost and effort of these tasks. What should you do?

**A.** Deploy the code on Cloud Run. Configure your code to write errors to standard error.

**B.** Deploy the code on Cloud Run. Configure your code to stream errors to a Cloud Storage bucket.

**C.** Deploy the code on a GKE Autopilot cluster. Configure your code to write error logs to standard error.

**D.** Deploy the code on a GKE Autopilot cluster. Configure your code to write error logs to a Cloud Storage bucket.

**Respuesta de la fuente:** A

**Explicación:** Cloud Run is the optimal choice because it is serverless and scales to zero, minimizing costs during periods of no traffic (night) while handling high daytime traffic without managing infrastructure. Writing errors to standard error (stderr) allows Cloud Run to automatically capture and forward these logs to Cloud Logging, which integrates natively with Error Reporting for minimal effort.
GKE Autopilot incurs higher baseline costs due to cluster overhead and does not scale to zero in the same seamless manner as Cloud Run for simple containerized services.

## Pregunta 323

Contexto: [topics:726](#topics-726)
Your team is developing a new application that is packaged as a container and stored in Artifact Registry. You are responsible for configuring the CI/CD pipelines that use Cloud Build. Containers may be pushed manually as a local development effort or in an emergency. Every time a new container is pushed to Artifact Registry, you need to trigger another Cloud Build pipeline that executes a vulnerability scan. You want to implement this requirement using the least amount of effort. What should you do?

**A.** Configure Artifact Registry to publish a message to a Pub/Sub topic when a new image is pushed. Configure the vulnerability scan pipeline to be triggered by the Pub/Sub message.

**B.** Configure the Cloud Build Cl pipeline that publishes the new image to send a message to a Pub/Sub topic that triggers the vulnerability scan pipeline.

**C.** Configure Artifact Registry to publish a message to a Pub/Sub topic when a new image is pushed. Configure Pub/Sub to invoke a Cloud Function that triggers the vulnerability scan pipeline.

**D.** Use Cloud Scheduler to periodically check for new versions of the container in Artifact Registry and trigger the vulnerability scan pipeline.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 324

Contexto: [topics:726](#topics-726)
You have an application running on a GKE cluster. Your application has a stateless web frontend, and has a high-availability requirement. Your cluster is set to automatically upgrade, and some of your nodes need to be drained. You need to ensure that the application has a serving capacity of 10% of the Pods prior to the drain. What should you do?

**A.** Configure a Vertical Pod Autoscaler (VPA) to increase the memory and CPU by 10% and set the updateMode to Auto.

**B.** Configure the Pod replica count to be 10% more than the current replica count.

**C.** Configure a Pod Disruption Budget (PDB) value to have a minAvailable value of 10%.

**D.** Configure the Horizontal Pod Autoscaler (HPA) maxReplicas value to 10% more than the current replica count.

**Respuesta de la fuente:** C

**Explicación:** Pod Disruption Budgets (PDBs) are specifically designed to limit the number of Pods of an application that can be down simultaneously during voluntary disruptions like node drains.
Setting `minAvailable` to 10% ensures that at least 10% of the Pods remain running while nodes are being drained, directly satisfying the availability requirement.
Option B is incorrect because increasing replica count addresses scaling needs but does not prevent Kubernetes from draining all replicas if no PDB constraints are in place.

## Pregunta 325

Contexto: [topics:726](#topics-726)
You are designing an application that shares PDF files containing time-sensitive information with users. The PDF files are saved in Cloud Storage. You need to provide secure access to the files.

You have the following requirements:
• Users should only have access to files that they are allowed to view.
• Users should be able to request to read, write, or delete the PDF files for 24 hours.

Not all users of the application have a Google account. How should you provide access to data objects?

**A.** Configure the application to generate signed URLs with an expiration time of 24 hours. Share the signed URLs with users. Attach the signed URL to the PDF files that users require access to.

**B.** Provide users with the Service Account Token Creator IAM role to impersonate the application's service account. Assign the Cloud Storage User IAM role to the application's service account to access the Cloud Storage bucket. Rotate the application's service account key every 24 hours.

**C.** Generate a service account that grants access to the POF files. Configure the application to provide users with a download link to the service account's key file. Set an expiration time of 24 hours to the service account Keys. Instruct users to authenticate by using the service account key file.

**D.** Assign the Storage Object User IAM role to users that request access to the PDF files. Set an IAM condition on the role to expire after 24 hours.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 326

Contexto: [topics:726](#topics-726)
You have developed a Python application that you want to containerize and deploy to Cloud Run. You have developed a Cloud Build pipeline with the following steps:

[Imagen: sin descripción]

After triggering the pipeline, you notice in the Cloud Build logs that the final step of the pipeline fails and the container is unable to be deployed to Cloud Run. What is the cause of this issue, and how should you resolve it?
Imagen · question_text · sin descripción
![Imagen original](imagenes/16f0a735b26f438fd5c5.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
steps:
- name: python
entrypoint: pip
args: ["install", -r'
5	1	4	1	1	4	331	74	163	13	84.671425	equirements.txt -user
- name: python
entrypoint: python
args: ["-m", “pytest", junituml=s{SHORT_SHA)_test_log.xml"]
- name: 'gcr.io/cloud-builders/docker'
args: ["build', '-t', ‘us-centrali-
docker.pkg.dev/$ {PROJECT_ID}/${_ARTIFACT_REGISTRY_REPO}/myimage:${SHORT_SHA}', '.']
- nam
google/cloud-sdk
args: ['gcloud', 'run', 'deploy', ‘helloworld-${SHORT_SHA}', '--image=us-centrall-
docker.pkg.dev/$ {PROJECT_ID}/${_ARTIFACT_REGISTRY_REPO} /myimage:${SHORT_SHA}", '--region', 'us-centrall', '--
platform', 'managed', '--allow-unautherticated']
```

**A.** The final step uses a Cloud Run instance name that does not match the container name. Update the deployment step so that the Cloud Run instance name matches the container name, and rerun the pipeline.

**B.** The Docker container image has not been pushed to Artifact Registry. Add a step to the pipeline to push the application container image to Artifact Registry, and rerun the pipeline.

**C.** Cloud Run does not allow unauthenticated invocations. Remove the --allow-unauthenticated parameter to enforce authentication on the application, and rerun the pipeline.

**D.** Unit tests in the pipeline are failing. Update the application code so that all unit tests pass, and rerun the pipeline.

**Respuesta de la fuente:** B

**Explicación:** The Cloud Run deployment command specifies the service image using an Artifact Registry path (e.g., gcr.io/PROJECT/IMAGE), but the provided Cloud Build pipeline only includes steps to build the Docker image and run tests. Without an explicit step to push the built image to a container registry, Cloud Run cannot pull the artifact, causing the deployment to fail. Option B correctly identifies this missing 'push' step as the root cause.

## Pregunta 327

Contexto: [topics:726](#topics-726)
Your infrastructure team uses Terraform Cloud and manages Google Cloud resources by using Terraform configuration files. You want to configure an infrastructure as code pipeline that authenticates to Google Cloud APIs. You want to use the most secure approach and minimize changes to the configuration. How should you configure the authentication?

**A.** Use Terraform on GKE. Create a Kubernetes service account to execute the Terraform code. Use workload identity federation to authenticate as the Google service account.

**B.** Install Terraform on a Compute Engine VM. Configure the VM by using a service account that has the required permissions to manage the Google Cloud resources.

**C.** Configure Terraform Cloud to use workload identity federation to authenticate to the Google Cloud APIs.

**D.** Create a service account that has the required permissions to manage the Google Cloud resources, and import the service account key to Terraform Cloud. Use this service account to authenticate to the Google Cloud APIs.

**Respuesta de la fuente:** C

**Explicación:** Workload Identity Federation (Option C) is the most secure approach because it eliminates the need to create and manage long-lived service account keys, reducing the risk of key leakage or compromise. It seamlessly integrates Terraform Cloud with Google Cloud using temporary tokens, minimizing configuration changes compared to setting up custom infrastructure like GKE or Compute Engine VMs. Option D is tempting but less secure due to the risks associated with storing and rotating static service account keys in Terraform Cloud.

## Pregunta 328

Contexto: [topics:726](#topics-726)
Your team has created an application that is hosted on a GKE cluster. You need to connect the application to a REST service that is deployed in two GKE clusters in two different regions. How should you set up the connection and health checks? (Choose two.)

**A.** Use Cloud Service Mesh with sidecar proxies to connect the application to the REST service.

**B.** Use Cloud Service Mesh with proxyless gRPC to connect the application to the REST service.

**C.** Configure the REST service's firewall to allow health checks originating from the GKE service’s IP ranges.

**D.** Configure the REST service's firewall to allow health checks originating from the GKE control plane’s IP ranges.

**E.** Configure the REST service's firewall to allow health checks originating from the GKE check probe’s IP ranges.

**Respuesta de la fuente:** A, E

**Explicación:** Cloud Service Mesh with sidecar proxies (Option A) is the standard GKE solution for managing secure, multi-cluster service-to-service communication across regions via Istio. For health checks to function correctly, firewall rules must explicitly allow traffic from the specific IP ranges used by GKE's health check probes (Option E), rather than the control plane or general service IPs.

## Pregunta 329

Contexto: [topics:726](#topics-726)
You are using the latest stable version of Python 3 to develop an API that stores data in a Cloud SQL database. You need to perform CRUD operations on the production database securely and reliably with minimal effort. What should you do?

**A.** 1. Use Cloud Composer to manage the connection to the Cloud SQL database from your Python application.
2. Grant an IAM role to the service account that includes the composer.worker permission.

**B.** 1. Use the Cloud SQL API to connect to the Cloud SQL database from your Python application.
2. Grant an IAM role to the service account that includes the cloudsql.instances.login permission.

**C.** 1. Use the Cloud SQL connector library for Python to connect to the Cloud SQL database through a Cloud SQL Auth Proxy.
2. Grant an IAM role to the service account that includes the cloudsql.instances.connect permission.

**D.** 1. Use the Cloud SQL emulator to connect to the Cloud SQL database from Cloud Shell
2. Grant an IAM role to the user that includes the cloudsql.instances.login permission.

**Respuesta de la fuente:** C

**Explicación:** The Cloud SQL Connector library for Python is the recommended solution for secure, reliable connectivity because it automatically handles SSL/TLS encryption and rotation of ephemeral certificates without requiring static passwords or complex proxy management. It requires only the `cloudsql.instances.connect` IAM permission, ensuring least-privilege access while minimizing development effort compared to manual connection setups.

## Pregunta 330

Contexto: [topics:726](#topics-726)
Your company manages an application that captures stock data in an internal database. You need to create an API that provides real-time stock data to users. You want to return stock data to users as quickly as possible, and you want your solution to be highly scalable. What should you do?

**A.** Create a BigQuery dataset and table to act as the internal database. Query the table when user requests are received.

**B.** Create a Memorystore for Redis instance to store all stock market data. Query this database when user requests are received.

**C.** Create a Bigtable instance. Query the table when user requests are received. Configure a Pub/Sub topic to queue user requests that your API will respond to.

**D.** Create a Memorystore for Redis instance, and use this database to store the most accessed stock data. Query this instance first when user requests are received, and fall back to the internal database.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because implementing Redis as a caching layer for frequently accessed data significantly reduces latency compared to querying the primary database directly, thereby improving response times.

This pattern also enhances scalability by offloading read traffic from the internal database, preventing bottlenecks during high-demand periods.

Option B is incorrect because storing all stock market data in Redis would likely exceed memory capacity limits and incur unnecessary costs, whereas caching only hot data is cost-effective and efficient.

## Pregunta 331

Contexto: [topics:726](#topics-726)
You are designing a microservices architecture for a new application that will be deployed on Cloud Run. The application requires high-throughput communication between the internal microservices. You want to use the most effective, lowest latency communication protocol for this application. What should you do?

**A.** Configure the Cloud Run service to use HTTP/2. Implement gRPC for communication between the microservices. Use streaming gRPCs when a large amount of data has to be sent.

**B.** Implement the microservices with the REST API communication protocol. Use Apigee with rate-limiting to provide the best QoS for high-priority services.

**C.** Use SOAP to build the microservices API, and use XML as the data format for communication across the microservices. Define SOAP data contracts for each microservice.

**D.** Use HTTP REST to communicate across the microservices. Implement pagination and add indexing to your database.

**Respuesta de la fuente:** A

**Explicación:** gRPC utilizes HTTP/2 as its underlying transport protocol, providing features like multiplexing and header compression that significantly reduce latency compared to HTTP/1.1 REST APIs. It uses Protocol Buffers for efficient binary serialization, making it the most effective choice for high-throughput internal communication.
Option B is incorrect because REST over HTTP typically incurs higher overhead due to text-based payloads (like JSON) and lacks native multiplexing benefits of HTTP/2.

## Pregunta 332

Contexto: [topics:726](#topics-726)
Your company recently modernized their monolith ecommerce site to a microservices application in GKE. Your team uses Google Cloud's operations suite for monitoring and logging. You want to improve the logging indexing and searchabilty in Cloud Logging across your microservices with the least amount of effort. What should you do?

**A.** Ask the SRE team to enable Managed Service for Prometheus on your GKE cluster.

**B.** Reconfigure your applications to write logs to an emptyDir volume. Configure a sidecar agent to read the logs and send them to the Cloud Logging API.

**C.** Update your microservices code to emit logs in JSON format.

**D.** Instrument your microservices code with OpenTelemetry libraries.

**Respuesta de la fuente:** C

**Explicación:** Cloud Logging automatically parses and indexes fields from JSON-formatted logs, significantly improving searchability and indexing efficiency without requiring complex custom configurations.
In contrast, options like Prometheus (A) focus on metrics rather than log indexing, while sidecar agents (B) or OpenTelemetry libraries (D) introduce additional architectural complexity and setup overhead that contradicts the requirement for the 'least amount of effort'.

## Pregunta 333

Contexto: [topics:726](#topics-726)
You recently developed an application that will be hosted on Cloud Run. You need to conduct a load test. You want to analyze the load test logs second by second to understand your Cloud Run service's response to rapid traffic spikes. You want to minimize effort. How should you analyze the logs?

**A.** Use estimation to extrapolate performance from summary monitoring charts.

**B.** Analyze the log data in BigQuery by configuring a BigQuery log sink with the appropriate inclusion filter for your application.

**C.** Use Cloud Monitoring’s default log console for analysis.

**D.** Analyze the log data in Cloud SQL for PostgreSQL by pushing logs to a Pub/Sub topic. Use Dataflow to process and ingest the logs.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because exporting logs to BigQuery allows for precise SQL-based analysis with second-level granularity, directly meeting the requirement to analyze response times during rapid spikes.
In contrast, Option A relies on estimation rather than actual log data, failing the specific analysis requirement, while Options C and D involve either insufficient query capabilities or significantly higher setup effort, respectively.

## Pregunta 334

Contexto: [topics:726](#topics-726)
You are a developer of a new customer-facing help desk chat service that is built on Cloud Run. Your customers use the chat option on your website to get support. The application saves each transcript as a text file with a unique identifier in a Cloud Storage bucket. After the conversation is done and before the chat window is closed, the customer receives a link to the chat transcript. You want to provide access to the chat transcript link for 2 hours. You need to configure this access using an approach that prioritizes security and follows Google-recommended practices. What should you do?

**A.** Set the ACL permission on the Cloud Storage bucket. Set the permission of each text file to allUsers with READER access. Delete each text file 2 hours after itis created.

**B.** Set the permission on the Cloud Storage bucket with the text files to allUsers. Delete each text file 2 hours after itis created.

**C.** Create a new Cloud Storage bucket for each user. Grant the user access to the bucket with a conditional IAM role that expires after 2 hours.

**D.** Create a signed URL for each text file that expires after 2 hours.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 335

Contexto: [topics:726](#topics-726)
You are responsible for managing the security of internal applications in your company. The applications are deployed on Cloud Run, and use Secret Manager to store passwords needed to access internal databases. Each application can cache secrets for up to 15 minutes. You need to determine how to rotate the secrets. You want to avoid application downtime. What should you do?

**A.** Store the new username and password in the secret. Reference the latest version of any secret required, and cache the secret for 15 minutes.

**B.** Design the applications to retrieve the Latest secret payload on application startup, and continue to use the secret for the duration of the application run.

**C.** Store the new password in the secret. Reference the latest version of any secret required, and cache the secret for 15 minutes.

**D.** Store the new password in the secret. Design the applications to reference a specific secret version. Change the code to reference the new version, and schedule the deployment of the application during a maintenance window.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 336

Contexto: [topics:726](#topics-726)
You are developing a new ecommerce application that uses Cloud Functions. You want to expose your application's APIs to public users while maintaining a high level of security. You need to ensure that only authorized users can access your APIs and that all API traffic is encrypted and protected from unauthorized access. You want to use the most scalable and secure approach. What should you do?

**A.** Deploy your Cloud Functions behind Cloud Load Balancing, and use Cloud Armor to protect your APIs from distributed denial of service (DDoS) attacks.

**B.** Deploy your Cloud Functions with Security Command Center enabled, and use IAM to manage access to your APIs.

**C.** Deploy your Cloud Functions behind an Apigee proxy and use Apigee’s authentication and authorization features to secure your APIs.

**D.** Deploy your Cloud Functions behind a Cloud API Gateway proxy. Create and use an API key to authorize users to access your APIs.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 337

Contexto: [topics:726](#topics-726)
You are deploying a microservices application to GKE. One microservice needs to download files from a Cloud Storage bucket. You have an IAM service account with the Storage Object Viewer role on the project with the bucket. You need to configure your application to access the Cloud Storage bucket while following Google-recommended practices. What should you do?

**A.** Assign the IAM service account to the cluster’s node pool. Configure the application to authenticate to the bucket by using Application Default Credentials.

**B.** Assign the IAM service account to the cluster’s node pool. Encrypt the IAM service account key file by using a symmetric block cipher, and store the encrypted file on a persistent volume. Store the encryption key in Secret Manager.

**C.** Create a Kubernetes service account. Create a Kubernetes secret with a base64-encoded IAM service account key file. Annotate the Kubernetes secret with the Kubernetes service account. Assign the Kubernetes ServiceAccount to the Pods that need to access the bucket.

**D.** Create a Kubernetes service account. Use an IAM policy to bind the IAM service account to a Kubernetes service account. Annotate the Kubernetes ServiceAccount object with the name of the bound IAM service account. Assign the Kubernetes ServiceAccount to the Pods that need to access the bucket.

**Respuesta de la fuente:** D

**Explicación:** Option D describes Workload Identity, which is the Google-recommended best practice for GKE. It securely binds IAM service accounts to Kubernetes service accounts, allowing pods to access Cloud resources without managing long-lived service account keys.
Option A is incorrect because assigning an IAM role to a node pool grants excessive permissions to all workloads on those nodes, violating the principle of least privilege.

## Pregunta 338

Contexto: [topics:726](#topics-726)
You are developing a short-term image hosting service where end users around the world can upload images that are up to 20MB, and the images will be automatically deleted after 10 days. You need to determine how the images should be stored while minimizing cost. How should you store the images?

**A.** Write the image to a Cloud Storage bucket. Create a lifecycle configuration that deletes objects 10 days older than their creation date.

**B.** Write the images to Spanner. Configure a row deletion policy on the table that deletes rows 10 days older than their creation date.

**C.** Write the images to Firestore. Deploy a Cloud Scheduler-invoked Cloud Run service that queries for documents written 10 days prior to today and deletes them.

**D.** Write the images to Bigtable. Configure a garbage collection policy for the column family that deletes cells 10 days older than their creation date.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 339

Contexto: [topics:726](#topics-726)
You are developing a new ecommerce website for your company. You want customers to receive a customized email notification when they place an order. You need to configure this email service while minimizing deployment effort. What should you do?

**A.** Create a Cloud Function that is triggered by a create type event in Firestore,

**B.** Create an email-sending application hosted on Compute Engine that is invoked by an HTTP request.

**C.** Create an email notification channel, and set up an alerting policy that is based on log metrics from a create type event.

**D.** Use Pub/Sub to send an email when the orders/ API returns an HTTP response of 200 OK.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Cloud Functions are serverless and event-driven, automatically executing code in response to Firestore data changes without requiring infrastructure management. This directly satisfies the requirement to minimize deployment effort compared to managing Compute Engine instances (Option B). Options C and D are unsuitable because alerting policies are designed for system monitoring rather than transactional business notifications, and Pub/Sub alone does not provide the execution environment needed to process and send emails.

## Pregunta 340

Contexto: [topics:726](#topics-726)
You are developing an online chat application where users can upload profile pictures. Uploaded profile pictures must comply with content policies. You need to detect inappropriate images and label those images automatically when they are uploaded. In the future, this process will need to be expanded to include additional processing tasks such as watermarking and image compression.

You want to simplify orchestration and minimize operational overhead of the image scanning and labeling steps while also ensuring that additional steps can be added and removed easily later on. What should you do?

**A.** Save user-uploaded images to a temporary Cloud Storage bucket. Implement code on the backend server to retrieve the image content and call the Vision API to process each new uploaded image.

**B.** Save user-uploaded images to a Cloud Storage bucket. Configure a Cloud Function that is triggered when a new image is uploaded and calls one or more Cloud Run services. Create additional Cloud Run services that call the Vision API to process each new uploaded image.

**C.** Save user-uploaded images to a Cloud Storage bucket. Configure a Cloud Function that is triggered when a new image is uploaded and publishes a message to a Pub/Sub topic. Deploy microservices in GKE that subscribe to the Pub/Sub topic and call the Vision API to process each new uploaded image.

**D.** Save user-uploaded images to a Cloud Storage bucket. Create an Eventarc trigger that connects the bucket to the Workflows event receiver when a new image is uploaded. Create a workflow in Workflows with multiple Cloud Functions that call the Vision API to process each new uploaded image.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Cloud Workflows provides a serverless orchestration layer that allows you to define the sequence of processing steps as code, making it trivial to add or remove tasks like watermarking without redeploying infrastructure. This approach minimizes operational overhead by avoiding the management of containers (GKE/Cloud Run) while leveraging Eventarc for simple, reliable trigger-to-workflow integration.

Option B is tempting but less optimal because using Cloud Functions to call multiple Cloud Run services introduces unnecessary complexity in managing individual service endpoints and connections, whereas Workflows handles the orchestration logic natively.

## Pregunta 341

Contexto: [topics:726](#topics-726)
Your application named ecom-web-app is deployed in three GKE clusters: ecom-web-app-dev, ecom-web-app-qa, and ecom-web-app-prod. You need to ensure that only trusted container images are deployed to the ecom-web-app-prod GKE cluster in the production environment while following Google-recommended practices. What should you do?

**A.** Set up Binary Authorization, and define cluster-specific rules in clusterAdmissionRules nodes in the policy YAML file.

**B.** Set up Binary Authorization, and exempt any container images that are not deployed to the ecom-web-app-prod GKE cluster.

**C.** Set up an image verification process that scans the container images in Artifact Registry for vulnerabilities and tags the image versions that fail the scan as untrusted.

**D.** Set up an image verification process by using Cloud Functions where the function is invoked when a container image is built in Cloud Build and ensures that only trusted container images are stored in Artifact Registry.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 342

Contexto: [topics:726](#topics-726)
You are responsible for improving the security of your Cloud Run services to protect these services against supply chain threats. You need to ensure that there are adequate security controls such as SLSA Level 3 builds for container images and non-falsifiable provenance for container images by using Google Cloud tools. What should you do?

**A.** Ask developers to build container images locally and ensure strict version controls by using Container Registry.

**B.** Use Cloud Build to build container images. Configure a Binary Authorization policy on the Cloud Run job.

**C.** Use Cloud Deploy to generate authenticated and non-falsifiable build provenance for container images.

**D.** Use Cloud Build to build container images. Use Cloud Scheduler to automate delivery of your applications to a series of target environments in a defined sequence.

**Respuesta de la fuente:** C

**Explicación:** Cloud Deploy, when configured with Cloud Build adapters, supports SLSA Level 3 by generating authenticated and non-falsifiable provenance for container images, directly addressing the question's specific requirements.

Option B is incorrect because while Binary Authorization enforces deployment policies, it does not inherently generate the detailed build provenance required for SLSA Level 3 compliance.

## Pregunta 343

Contexto: [topics:726](#topics-726)
There are three teams developing an ecommerce application in the same Google Cloud project. Team A will build a set of RESTful APIs that exposes some core functionalities for the application. Team B and Team C will make requests to those APIs in their downstream processes running on Cloud Run services. You need to propose a solution for exposing the APIs in a way that maximizes security and minimizes management overhead for the three teams. How should you design this solution?

**A.** 1. Team A uses service accounts to authorize Cloud API Gateway. Team B and Team C each create a service account, export their service account's key, and store each key in a separate secret in Secret Manager.
2. Team B and Team C use this service account key to create an OAuth token to access the APIs.

**B.** 1. Team A uses Apigee hybrid to create an API key and shares that key with Team B and Team C.
2. Team B and Team C store the API key in a secret in Secret Manager, and use this API key to access the API endpoint.

**C.** 1. Team A uses an API key to authorize Cloud API Gateway and shares the key with Team B and Team C.
2. Team B and Team C store the API key in a secret in Secret Manager, and use this API key to access the API endpoint.

**D.** 1. Team A uses service accounts to authorize Cloud API Gateway. Team B and Team C each create a service account that has access to the APIs.
2. Team B and Team C access the APIs in the Cloud Run service running their processes by using the service accounts attached to their service.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 344

Contexto: [topics:726](#topics-726)
Your application team is developing an ecommerce application. Your team has developed a new functionality that has a dependency on a third-party service. This third-party service will be deployed in a few days. However, you have been unable to ensure the reliability of this service. You need to choose a deployment strategy for the ecommerce application that will avoid disruption and can be rolled back quickly if issues are discovered. What should you do?

**A.** Deploy the new functionality by using an A/B deployment strategy.

**B.** Deploy the new functionality to all users by using a blue/green deployment strategy.

**C.** Use a feature flag to enable the new functionality to users on demand. Gradually enable the new functionality to more users.

**D.** Gradually roll out the new functionality by using a rolling updates deployment strategy. Start with a small subset of users and increase the number of users over time.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 345

Contexto: [topics:726](#topics-726)
You work for an organization that manages an ecommerce site. Your application is deployed behind an external Application Load Balancer. You need to test a new product recommendation algorithm. You plan to use A/B testing to determine the new algorithm’s effect on sales in a randomized way. How should you test this feature?

**A.** Split traffic between versions using weights.

**B.** Enable the new recommendation feature flag on a single instance.

**C.** Mirror traffic to the new version of your application.

**D.** Use HTTP header-based routing.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 346

Contexto: [topics:726](#topics-726)
You maintain a CI/CD pipeline for an application running on GKE. You use Cloud Build to create container images and push the images to Artifact Registry. When you build the image, you use the latest tag in your pipeline.

You recently had to roll back a deployment 24 hours after rollout. The rollback process was difficult because the latest tag had been overwritten. You need to prevent this issue in the future. You want to use the most efficient approach. What should you do?

**A.** Rebuild the Docker image for each environment, and tag it with the specific environment name.

**B.** Build a separate Docker image for each new version of the application, and tag it with the version number.

**C.** Implement Helm charts to manage your container deployments.

**D.** Use a Docker registry to store the container images, and create separate repositories for each version of the application.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 347

Contexto: [topics:726](#topics-726)
You are designing a microservices application on GKE that will expose a public API to users. Users will interact with the application by using OAuth 2.0, and illegitimate requests should receive a 403 response code. You need the API to be resilient against distributed denial of service (DDoS) attacks and critical security risks such as SQL injection (SQL) and cross-site scripting (XSS).

You want to design the application's architecture while following Google-recommended practices. What should you do?

**A.** Install Service Mesh in your GKE cluster. Configure Service Mesh user authentication to integrate the service hosted on GKE by using an OpenID Connect-compliant identity provider. Expose the application externally by using an Istio Ingress Gateway. Use VPC firewall rules to restrict Ingress traffic to the Ingress gateway.

**B.** Run an Apache HTTP server on Cloud Run to expose a service with a public IP address. Configure the Apache HTTP server as a reverse proxy to only forward valid requests to the API hosted on GKE.

**C.** Use an external Application Load Balancer with Cloud Armor. Integrate Cloud Armor with reCAPTCHA Enterprise. Configure the load balancer to forward traffic to the application hosted on GKE.

**D.** Use an external Application Load Balancer with Cloud Armor, and configure the load balancer to forward requests to Apigee to check the validity of the API requests. Configure GKE as the application's backend.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Cloud Armor provides Layer 3/4 DDoS protection and WAF rules to mitigate SQL injection and XSS, while reCAPTCHA Enterprise effectively validates users before they reach the backend. This aligns with Google's recommended architecture for securing public APIs on GKE by placing security controls at the edge.

Option D is less optimal because Apigee is primarily an API management tool focused on traffic governance and monetization, whereas Cloud Armor is the dedicated service for infrastructure-level DDoS mitigation and web application firewalling.

## Pregunta 348

Contexto: [topics:726](#topics-726)
You are compiling a compliance report on vulnerability metadata for a specific set of images identified by Artifact Analysis. Metadata from images scanned more than 30 days ago are missing from the compliance report. You need to access the vulnerability metadata for these older images. What should you do?

**A.** Create a Pub/Sub subscription to pull from Artifact Analysis topics.

**B.** Check Artifact Analysis storage buckets in Cloud Storage.

**C.** Push or pull the images from Artifact Registry.

**D.** Check Cloud Trace logs for Artifact Analysis findings.

**Respuesta de la fuente:** B

**Explicación:** Artifact Analysis automatically archives vulnerability scan results to Cloud Storage buckets for long-term retention beyond the 30-day API availability window. Accessing these storage buckets allows you to retrieve the historical metadata required for your compliance report.
Option A is incorrect because Pub/Sub subscriptions only capture real-time events starting from subscription creation, not historical data. Option C is incorrect because Artifact Registry stores container images, not their historical vulnerability scan metadata.

## Pregunta 349

Contexto: [topics:726](#topics-726)
Your team runs a Python job that reads millions of customer record files stored in a Cloud Storage bucket. To comply with regulatory requirements, you need to ensure that customer data is immediately deleted once the job is completed. You want to minimize the time required to complete this task. What should you do?

**A.** Add a final step in the job that deletes all the objects in the bucket in bulk by using batch requests to the Cloud Storage API.

**B.** Configure Object Lifecycle Management on the Cloud Storage bucket that deletes all the objects in the bucket at the end of the job execution.

**C.** Remove the bucket from the Google Cloud console when the job is completed

**D.** Use the gcloud CLI to execute the gcloud storage rm --recursive gs://BUCKET_NAME/ command.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because using batch requests via the Cloud Storage API allows for the immediate, programmatic deletion of specific objects as part of the job's final step, ensuring regulatory compliance without delay.
Option B is incorrect because Object Lifecycle Management relies on scheduled age-based rules and does not guarantee immediate deletion at the exact moment the job completes.
Options C and D are inappropriate because removing the bucket entirely risks losing other unrelated data, and CLI commands are less integrated into an automated job workflow than a code-based API call.

## Pregunta 350

Contexto: [topics:726](#topics-726)
You are a developer at a regulated financial company and are the lead of a risk calculation application that is running on Cloud Run. Binary Authorization for Cloud Run has been enabled as an organization policy, and there is one attestor. All applications in the company are attested. Each application's image is deployed as part of a CI/CD pipeline during a 1-hour change window at 11 PM local time. There is a new security issue that requires you to deploy a critical fix before the next change window. You have created a new image with the fix, and your manager has approved the image in an email message. What should you do?

**A.** Add the image to the exempt image patterns in the Binary Authorization policy.

**B.** Sign the image with your private key and ask the project admin to change the public key in the attestor.

**C.** Change the organization policy to temporarily disable Binary Authorization, and deploy the image.

**D.** Use the breakglass approach to deploy the image.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 351

Contexto: [topics:726](#topics-726)
You have a Cloud Run service that needs to connect to a Cloud SQL instance in a different project. You provisioned the Cloud Run service account with the Cloud SQL Client IAM role on the project that is hosting Cloud SQL. However, when you test the connection, the connection fails. You want to fix the connection failure while following Google-recommended practices. What should you do?

**A.** Add the cloudsql.instances.connect IAM permission to the Cloud Run service account.

**B.** Request additional API quota for Cloud SQL Auth Proxy,

**C.** Enable the Cloud SQL Admin API in both projects.

**D.** Migrate the Cloud SQL instance into the same project as the Cloud Run service.

**Respuesta de la fuente:** C

**Explicación:** The Cloud SQL Admin API must be enabled in the project hosting the client application (Cloud Run) to allow it to retrieve instance metadata and establish connections, even if IAM roles are correctly assigned.
Option A is incorrect because the cloudsql.instances.connect permission is already included in the Cloud SQL Client role mentioned in the scenario.

## Pregunta 352

Contexto: [topics:726](#topics-726)
You developed a Python script that retrieves information from files that are uploaded to Cloud Storage and writes the information to Bigtable. You have completed testing on your local environment and created the python-script service account with the Bigtable User IAM role. You want to deploy the code with the appropriate authentication while following Google-recommended practices. What should you do?

**A.** 1. Deploy your code to Cloud Functions. Create a Cloud Storage trigger.
2. Configure IAM binding for authentication.

**B.** 1. Deploy your code to Cloud Functions. Create a Cloud Storage trigger.
2. Create a service account key for authentication

**C.** 1. Deploy your image to Cloud Run. Create a trigger in Cloud Scheduler that triggers the service every minute.
2. Configure IAM binding for authentication.

**D.** 1. Deploy your image to Cloud Run. Create a trigger in Cloud Scheduler that triggers the service every minute.
2. Create a service account key for authentication.

**Respuesta de la fuente:** A

**Explicación:** Cloud Functions is the recommended serverless service for event-driven processing of Cloud Storage uploads, eliminating polling solutions like Cloud Scheduler (C and D). Following Google security best practices, you should use IAM bindings to grant the necessary roles to the function's service account rather than managing long-lived service account keys (B), which are a security risk.

## Pregunta 353

Contexto: [topics:726](#topics-726)
You are a developer at a large organization. Your team uses Git for source code management (SCM). You want to ensure that your team follows Google-recommended best practices to manage code to drive higher rates of software delivery. Which SCM process should your team use?

**A.** Each developer commits their code to the main branch before each product release, conducts testing, and rolls back if integration issues are detected.

**B.** Each group of developers copies the repository, commits their changes to their repository, and merges their code into the main repository before each product release.

**C.** Each developer creates a branch for their own work, commits their changes to their branch, and merges their code into the main branch daily.

**D.** Each group of developers creates a feature branch from the main branch for their work, commits their changes to their branch, and merges their code into the main branch before each major release.

**Respuesta de la fuente:** C

**Explicación:** Google-recommended best practices emphasize trunk-based development with frequent integration to maximize delivery velocity and minimize merge conflicts. Option C correctly describes this by having developers merge small, incremental changes into the main branch daily.
Option D is the most tempting alternative but is incorrect because waiting until major releases to merge leads to significant 'integration hell' and large, risky batches of code, which contradicts the goal of driving higher rates of software delivery.

## Pregunta 354

Contexto: [topics:726](#topics-726)
You work for an ecommerce company. You are developing a new application with the following requirements:
• The application must have access to the most up-to-date data at all times.
• Due to company policy, data older than 30 days must be automatically deleted.

You need to determine which service should host the database, and how to configure the data deletion. You want to use the most efficient solution. What should you do?

**A.** Configure Spanner to host the database. Use Data Catalog to delete data older than 30 days.

**B.** Configure Spanner to host the database. Create a time-to-live policy that deletes data older than 30 days.

**C.** Configure Bigtable to host the database. Create a time-to-live policy that deletes data older than 30 days.

**D.** Configure Bigtable to host the database. Create a garbage collection policy in Bigtable that deletes data older than 30 days.

**Respuesta de la fuente:** B

**Explicación:** Cloud Spanner is the correct choice because it provides strong consistency and ACID compliance, which are essential for ecommerce applications requiring access to the most up-to-date data at all times.
TTL (Time-to-Live) policies in Spanner efficiently automate the deletion of rows older than 30 days based on timestamp columns, satisfying the retention requirement without manual intervention.
Bigtable is incorrect because it provides eventual consistency by default, which does not guarantee immediate read-your-writes consistency required for 'most up-to-date' data access.

## Pregunta 355

Contexto: [topics:726](#topics-726)
Your application in production has recently been experiencing reliability issues, and you are unsure how the application will behave in the event of an unexpected failure. You want to assess the application's resilience. What should you do?

**A.** Write end-to-end tests to determine how different microservices interact. Validate that all tests pass.

**B.** Perform chaos engineering by intentionally introducing failures into the system. Observe how the application behaves, and ensure that it is able to recover from a failure.

**C.** Test individual units of code for a critical portion of the application's code. Ensure that unit tests are part of the Cloud Build pipeline.

**D.** Perform load testing of the application, and use JMeter for the critical endpoints of the application. Ensure that the application performs as expected under a heavy load.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 356

Contexto: [topics:726](#topics-726)
Your team is responsible for developing multiple microservices. These microservices are deployed in Cloud Run and connected to a Cloud SQL instance. You typically conduct tests in a local environment prior to deploying new features. However, the external IP was recently removed from your Cloud SQL instance, and you are unable to perform the tests. You need to connect to the database to conduct tests with the most updated data. You want to follow Google-recommended practices. What should you do?

**A.** Export the data from the database to a Cloud Storage bucket. Create a database on your computer and import the data.

**B.** Create a Cloud VPN tunnel from your computer to your Google Cloud project, and connect to the Cloud SQL instance.

**C.** Add your IP as an authorized network on the Cloud SQL instance.

**D.** Create a VM in the same VPC as the Cloud SQL instance. Connect to the VM by using Identity-Aware Proxy for TCP forwarding. Install and configure the Cloud SQL Auth Proxy.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 357

Contexto: [topics:726](#topics-726)
You have an application running on Cloud Run that receives a large volume of traffic. You need to deploy a new version of the application. You want your deployment process to minimize the risk of downtime while following Google-recommended practices. What should you do?

**A.** Use Cloud Run emulator to test changes locally before deploying the new version of the application to the production Cloud Run service.

**B.** Use Cloud Build to create a pipeline, and configure a test stage before the deployment stage. When all tests pass, deploy the application to Cloud Run, and direct 100% of users to this new version of the application. Roll back if any issues are detected.

**C.** Use Cloud Load Balancing to route a percentage of production traffic to a separate Cloud Run service running the new version of the application. If performance meets expectations, gradually increase the percentage of users until the new Cloud Run service reaches 100%.

**D.** Use traffic splitting to have a small percentage of users test out new features on the new revision of the application on the production Cloud Run service. If performance meets expectations, gradually increase the percentage of users until it reaches 100%.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 358

Contexto: [topics:726](#topics-726)
You are a developer at an ecommerce company. You are tasked with developing a globally consistent shopping cart for logged-in users across both mobile and desktop clients. You need to configure how the items that are added to users’ carts are stored. How should you configure this cart service?

**A.** Store the carts in a separate Memorystore for Redis instance, and configure each user's IP address as the key.

**B.** Store the carts in a separate Firestore document, and configure each user ID as the document's key.

**C.** Insert the carts in a separate Spanner table, and configure each user's encrypted password as the primary key.

**D.** Create and store the carts in the shopping-cart HTTP cookie.

**Respuesta de la fuente:** B

**Explicación:** Firestore is a NoSQL document database designed for low-latency, globally distributed access, making it ideal for syncing user state across mobile and desktop clients in real time. Using the stable User ID as the key ensures consistency regardless of device or IP changes. Option A uses IP addresses, which are volatile and unreliable for identifying specific logged-in users. Options C and D use inappropriate storage mechanisms (relational database with secure-but-sensitive keys or ephemeral client-side cookies) that lack scalability or security.

## Pregunta 359

Contexto: [topics:726](#topics-726)
You are deploying a containerized application to GKE. You have set up a build pipeline by using Cloud Build that builds a Java application and pushes the application container image to Artifact Registry. Your build pipeline executes multiple sequential steps that reference Docker container images with the same layers.

You notice that the Cloud Build pipeline runs are taking longer than expected to complete. How should you optimize the Docker image build process?

**A.** Add the --squash parameter to the Docker build steps to combine newly built layers into a single layer.

**B.** Configure Cloud Build to use a private pool in your VPC for pipeline executions.

**C.** Specify the cached image by adding the --cache-from argument in your build config file with the image as a cache source.

**D.** Store container artifacts on Cloud Storage. Configure Cloud CDN on the Cloud Storage bucket to enable caching on edge locations.

**Respuesta de la fuente:** C

**Explicación:** Cloud Build executions occur on ephemeral build machines that do not persist Docker layer caches between runs. By specifying --cache-from in the build config, you explicitly instruct Docker to pull and reuse previously built image layers from Artifact Registry, significantly reducing rebuild time for unchanged steps.

Option A is incorrect because squashing images combines layers into one, which increases the size of the final image and forces Cloud Build to re-push a larger artifact every time, rather than skipping work via caching.

## Pregunta 360

Contexto: [topics:726](#topics-726)
You are developing a dashboard that aggregates temperature readings from thousands of IoT devices monitoring a city's ambient temperature. You expect a large amount of viewing traffic resulting in a large amount of data egress once the dashboard is live. The dashboard temperature display data doesn't need to be real-time and can tolerate a few seconds of lag. You decide to deploy Memorystore for Redis as the storage backend. You want to ensure that the dashboard will be highly available. How should you configure the service in Memorystore for Redis?

**A.** Update Memorystore for Redis to the latest version.

**B.** Configure Memorystore to use read replicas.

**C.** Use Private Service Access to enable low-latency network throughput.

**D.** Set up Serverless VPC Access to avoid receiving traffic over the internet.

**Respuesta de la fuente:** B

**Explicación:** Configuring read replicas is the correct approach to ensure high availability for Memorystore for Redis, as it provides synchronous replication to a standby node that takes over automatically if the primary fails. Additionally, read replicas help distribute the heavy read traffic expected from the dashboard, preventing performance bottlenecks on the primary instance. While Private Service Access improves network connectivity and security, it does not directly address service availability or redundancy. Similarly, updating the version or using Serverless VPC Access are maintenance or networking tasks that do not configure the database for high availability.

## Pregunta 361

Contexto: [topics:726](#topics-726)
You are responsible for developing a new ecommerce application that is running on Cloud Run. You need to connect your application to a Cloud SQL database that is in a separate project. This project is on an isolated network dedicated to multiple databases without a public IP. You need to connect your application to this database. What should you do?

**A.** Create a Private Service Connect endpoint on your network. Create a Serverless VPC Access connector on your project. Use Cloud SQL Language Connectors to create an internal connection.

**B.** Configure VPC Network Peering between both networks. In Cloud Run, create a Cloud SQL connection that uses the internal IP. Use Cloud SQL Language Connectors to interact with the database.

**C.** Configure private services access on your project. In Cloud Run, create a Cloud SQL connection. Use Cloud SQL Language Connectors to interact with the database.

**D.** Create a subnet on your VPC. Create a Serverless VPC Access connector on your project using the new subnet. In Cloud Run, create a Cloud SQL connection. Use Cloud SQL Language Connectors to interact with the database.

**Respuesta de la fuente:** D

**Explicación:** Cloud Run is a serverless environment without direct VPC connectivity, so it requires a Serverless VPC Access connector to reach resources on a private network. Option D correctly creates the necessary subnet and connector infrastructure to bridge Cloud Run to the isolated Cloud SQL instance using internal IP connections.
Option A is incorrect because Private Service Connect endpoints are typically used for receiving traffic from external projects or connecting to specific Google services via PSC, not as the standard method for bridging Serverless VPC Access to a private Cloud SQL instance in another project's isolated network.

## Pregunta 362

Contexto: [topics:726](#topics-726)
You are deploying new workloads on a GKE Autopilot mode cluster. You need to ensure that the Pods are scheduled on nodes that use Arm architecture CPUs. The cluster currently has no Arm-based CPUs. You want to minimize cluster operations. How should you ensure that the workloads on the GKE cluster will use Arm-based CPU nodes?

**A.** Apply Pod tolerations to request GKE to avoid scheduling Pods on nodes that do not have Arm-based CPUs.

**B.** Apply node taints on node pools to tell GKE to only schedule your workloads on Arm-based CPU nodes.

**C.** Deploy a new cluster in GKE Standard mode, and set up a node pool with Arm-based CPU nodes. Use nodeSelector in your manifest to ensure that Pods are scheduled in this node pool.

**D.** Request the Scale-out compute class and the arm64 architecture in your manifest.

**Respuesta de la fuente:** D

**Explicación:** In GKE Autopilot, you do not manage node pools or apply manual taints/tolerations; instead, you declare resource requirements in the Pod manifest. Setting `architecture: arm64` and requesting the Scale-out compute class signals Autopilot to dynamically provision Arm-based nodes that match these constraints.
Option C is incorrect because deploying a Standard cluster contradicts the premise of using Autopilot mode, while Options A and B rely on manual node management mechanisms not available or appropriate in Autopilot.

## Pregunta 363

Contexto: [topics:726](#topics-726)
You are developing a new Python 3 API that needs to be deployed to Cloud Run. Your Cloud Run service sits behind an Apigee proxy. You need to ensure that the Cloud Run service is running with the already deployed Apigee proxy. You want to conduct this testing as quickly as possible. What should you do?

**A.** Store the service code as a zip file in a Cloud Storage bucket. Deploy your application by using the gcloud run deploy --source command, and test the integration by pointing Apigee to Cloud Run.

**B.** Use the Cloud Run emulator to test your application locally. Test the integration by pointing Apigee to your local Cloud Run emulator.

**C.** Build a container image locally, and push the image to Artifact Registry. Deploy the Image to Cloud Run, and test the integration by pointing Apigee to Cloud Run.

**D.** Deploy your application directly from the current directory by using the gcloud run deploy --source command, and test the integration by pointing Apigee to Cloud Run.

**Respuesta de la fuente:** D

**Explicación:** The `gcloud run deploy --source` command automates the build and push process directly from your local code, eliminating manual steps to package a ZIP file (Option A) or pre-build container images (Option C). This direct deployment method is faster than managing artifacts manually while providing a live Cloud Run environment for Apigee integration testing. Option B is incorrect because Apigee cannot point to a local emulator for production-like integration tests.

## Pregunta 364

Contexto: [topics:726](#topics-726)
Your company is planning a global event. You need to configure an event registration portal for the event. You have decided to deploy the registration service by using Cloud Run. Your company’s marketing team does not want to advertise the Cloud Run service URL. They want the registration portal to be accessed by using a personalized hostname or path in your custom domain URL pattern, for example, <service>.example.com. How should you configure access to the service while following Google-recommended practices?

**A.** Configure Cloud Armor to block traffic on the Cloud Run service URL and allow reroutes from only the custom domain URL pattern.

**B.** Set up an HAProxy on Compute Engine, and add routing rules for a custom domain to the Cloud Run service URL.

**C.** Add a global external Application Load Balancer in front of the service, and configure a DNS record that points to the load balancer’s IP address.

**D.** Create a CNAME record that points to the Cloud Run service URL.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Cloud Run services do not support static IP addresses or direct custom domain mapping via simple DNS records (like CNAME) without a proxy. To route traffic from a custom domain to a Cloud Run service while adhering to Google-recommended practices, you must use an Application Load Balancer as a frontend. The ALB provides the necessary stable endpoint and SSL termination for your custom domain. Option D is incorrect because Cloud Run URLs are dynamic and cannot be pointed to via a simple CNAME record; they require a load balancer or serverless networking configuration to handle reverse proxying.

## Pregunta 365

Contexto: [topics:726](#topics-726)
You are building a Workflow to process complex data analytics for your application. You plan to use the Workflow to execute a Cloud Run job while following Google-recommended practices. What should you do?

**A.** Create a Pub/Sub topic, and subscribe the Cloud Run job to the topic.

**B.** Configure an Eventarc trigger to invoke the Cloud Run job, and include the trigger in a step of the Workflow.

**C.** Use the Cloud Run Admin API connector to execute the Cloud Run job within the Workflow.

**D.** Determine the entry point of the Cloud Run job, and send an HTTP request from the Workflow.

**Respuesta de la fuente:** C

**Explicación:** Google recommends using Standard Connectors within Cloud Workflows to invoke other Google Cloud services, as they abstract away authentication and API complexity.
Using the Cloud Run Admin API connector (Choice C) is the most efficient and supported method for triggering a Cloud Run job directly from a Workflow step.
Other options like setting up Pub/Sub subscriptions or Eventarc triggers introduce unnecessary decoupling or external configuration that contradicts the goal of direct orchestration within the workflow definition.

## Pregunta 366

Contexto: [topics:726](#topics-726)
You are developing an application that needs to connect to a Cloud SQL for PostgreSQL database by using the Cloud SQL Auth Proxy. The Cloud SQL Auth Proxy is hosted in a different Google Cloud VPC network. The Cloud SQL for PostgreSQL instance has public and private IP addresses. You are required to use the private IP for security reasons. When testing the connection to the Cloud SQL instance, you can connect by using the public IP address, but you are unable to connect by using the private IP address. How should you fix this issue?

**A.** Run the Cloud SQL Auth Proxy as a background service.

**B.** Add the --private-ip option when starting the Cloud SQL Auth Proxy.

**C.** Set up VPC Network Peering between your VPC and the VPC where the Cloud SQL instance is deployed.

**D.** Grant yourself the IAM role that provides access to the Cloud SQL instance.

**Respuesta de la fuente:** C

**Explicación:** The Cloud SQL instance is located in a different VPC, and the Auth Proxy is hosted in your current VPC. To communicate over the private IP address, a direct network route must exist between the two VPCs, which is established by setting up VPC Network Peering.

Using the public IP would not meet the security requirement, and adding the `--private-ip` flag (Option B) does not create the necessary network connectivity path between isolated VPCs.

## Pregunta 367

Contexto: [topics:726](#topics-726)
You are developing a custom job scheduler that must have a persistent cache containing entries of all Compute Engine VMs that are in a running state (not deleted, stopped, or suspended). The job scheduler checks this cache and only sends jobs to the available Compute Engine VMs in the cache. You need to ensure that the available Compute Engine instance cache is not stale. What should you do?

**A.** Set up an organization-level Cloud Storage log sink with a filter to capture the audit log events for Compute Engine. Configure an Eventarc trigger that executes when the Cloud Storage bucket is updated and sends these events to the application to update the cache.

**B.** Set up a Cloud Asset Inventory real-time feed of insert and delete events with the asset types filter set to compute.googleapis.com/Instance. Configure an Eventarc trigger that sends these events to the application to update the cache.

**C.** Set up an organization-level Pub/Sub log sink with a filter to capture the audit log events for Compute Engine. Configure an Eventarc trigger that sends these events to the application to update the cache.

**D.** Set up an organization-level BigQuery log sink. Configure the application to query this BigQuery table every minute to retrieve the last minute’s events and update the cache.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because using a Pub/Sub log sink to capture Compute Engine audit logs ensures immediate, push-based notification of VM state changes (running, stopped, suspended) via Eventarc, preventing cache staleness. Option A is incorrect because Cloud Storage sinks are designed for long-term storage, not real-time event delivery; Eventarc does not trigger on Cloud Storage bucket updates in this context. Option B is suboptimal as Asset Inventory feeds track resource existence rather than specific runtime state transitions like stopping or suspending. Option D introduces significant latency due to polling BigQuery every minute, allowing the cache to become stale during that interval.

## Pregunta 368

Contexto: [topics:726](#topics-726)
You have a GKE cluster that has three TPU nodes. You are running an ML training job on the cluster, and you observe log entries in Cloud Logging similar to the one below. To identify the root cause of a performance issue, you need to view all stdout logs from the containers running on the TPU nodes. What should you do?

[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/d82408c56c822e643b2a.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
insertId: gvgk7r5qeShvogif
labels: {
compute .googleapis.com/resource_name: gke-tpu-9243ec28-wwi5
k8s-pod/batch_kubernetes_io/controller-uid: 443a3128-xxx090
k8s-pod/batch_kubernetes_io/job-name: my-training-job
k8s-pod/controller-uid: 443a3128-xxx090
k8s-pod/job-name:
)
logName:
'my-training-job"
projects/gke-tpu-demo-project/logs/stdout
2:39.6521225892"
receiveTimestamp: 2025-01-26T0
4	1	9	1	2	0	4	294	105	12	-1	
5	1	9	1	2	1	4	297	84	8	93.056389	resource:
5	1	9	1	2	2	104	294	5	12	89.415192	{
4	1	9	1	3	0	24	320	85	12	-1	
5	1	9	1	3	1	24	320	64	11	92.594833	labels:
5	1	9	1	3	2	105	320	4	12	49.055595	(
4	1	9	1	4	0	43	347	235	15	-1	
5	1	9	1	4	1	43	347	125	15	90.506058	cluster_name:
5	1	9	1	4	2	182	347	96	13	89.293106	tpu-test"
container_name: tensorflow
location: us-central2-b
namespace_name: default
pod_name: my-training-job-17418
project_id: gke-tpu-demo-project
type: k8s_container
}
severity: INFO
textPayload: 
4	1	13	1	2	0	24	635	840	15	-1	
5	1	13	1	2	1	24	635	46	13	19.047871	0
5	1	13	1	2	2	95	644	291	2	17.222748	nn
5	1	13	1	2	3	391	636	4	13	85.692192	]
5	1	13	1	2	4	410	641	7	2	85.692192	-
5	1	13	1	2	5	429	637	36	9	96.257362	ETA:
5	1	13	1	2	6	480	636	47	10	93.035614	13:36
5	1	13	1	2	7	539	641	7	2	92.075768	-
5	1	13	1	2	8	559	636	44	10	95.999275	loss:
5	1	13	1	2	9	618	636	57	10	93.110580	2.3238
5	1	13	1	2	10	687	641	8	2	92.845818	-
5	1	13	1	2	11	707	639	85	11	96.797470	accuracy:
5	1	13	1	2	12	807	636	57	10	96.546959	0.0469
4	1	13	1	3	0	4	688	839	14	-1	
5	1	13	1	3	1	4	688	66	12	88.116531	937/938
5	1	13	1	3	2	86	689	3	12	88.116531	[
5	1	13	1	3	3	382	689	13	12	0.000000	«]
5	1	13	1	3	4	410	694	8	1	86.025597	-
5	1	13	1	3	5	429	689	36	10	88.393936	ETA:
5	1	13	1	3	6	479	689	18	10	91.060875	0s
5	1	13	1	3	7	509	694	8	1	89.602882	-
5	1	13	1	3	8	529	689	27	10	96.889542	loss:
5	1	13	1	3	9	588	689	57	10	93.017944	0.2184
5	1	13	1	3	10	657	694	8	1	89.691582	-
5	1	13	1	3	11	677	692	85	10	96.490112	accuracy:
5	1	13	1	3	12	777	689	66	10	95.451851	0.9349
timestamp: 2025-01-26T05:52:38.9629501152'
2	1	17	0	0	0	5	741	4	12	-1	
3	1	17	1	0	0	5	741	4	12	-1	
4	1	17	1	1	0	5	741	4	12	-1	
5	1	17	1	1	1	5	741	4	12	91.110222	}

```

**A.** Run the following log query in Cloud Logging:
[Imagen: sin descripción]
Imagen · choices[0].text · sin descripción
![Imagen original](imagenes/35ecd93d1b7ad3887a8c.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
resource.type="k8s_container’
labels."k8s-pod/batch_kubernetes_io/job-name"
log _id("stdout")
my-training-job
```

**B.** Run the following log query in Cloud Logging:
[Imagen: sin descripción]
Imagen · choices[1].text · sin descripción
![Imagen original](imagenes/e0f266827596f923ba1a.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
resource.type="k8s_containe:
labels. compute.
5	1	4	1	1	3	163	30	277	16	20.454964	googleapis.com/resource_name'
2	1	5	0	0	0	5	57	154	15	-1	
3	1	5	1	0	0	5	57	154	15	-1	
4	1	5	1	1	0	5	57	154	15	-1	
5	1	5	1	1	1	5	57	59	15	6.492109	log_id
5	1	5	1	1	2	68	57	91	12	6.492109	(stdout")
gke-tpu-9243ec28.*
```

**C.** Run the following command in Cloud Shell:
[Imagen: sin descripción]
Imagen · choices[2].text · sin descripción
![Imagen original](imagenes/136ec75ac0d6ae73d444.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
gcloud logging read 'resource.type="k8s_node"
labels."compute.googleapis.com/resource_name"
log_id("stdout") '
= gke-tpu-9243ec28.*
```

**D.** Run the following command in Cloud Shell:
[Imagen: sin descripción]
Imagen · choices[3].text · sin descripción
![Imagen original](imagenes/4b3d6fa5265755d0b002.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
gcloud logging read 'resource.type="k8s_node"
labels."k8s-pod/batch_kubernetes_io/job-name" = my-training-job
log_id("stdout")
```

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 369

Contexto: [topics:726](#topics-726)
You have a Cloud Run service that connects to a Cloud SQL Enterprise edition database instance using the default Cloud SQL connection. You need to enable more than 100 connections per Cloud Run instance. What should you do?

**A.** Increase the queries per minute quota limit of the Cloud SQL Admin API.

**B.** Increase the max_connection flag in Cloud SQL for PostgresSQL.

**C.** Upgrade to Cloud SQL Enterprise Plus edition.

**D.** Use Cloud SQL Auth Proxy in a sidecar.

**Respuesta de la fuente:** C

**Explicación:** The default Cloud SQL Client library used in Cloud Run enforces a maximum connection pool size of 100 connections per instance. To exceed this limit, you must upgrade to the Cloud SQL Enterprise Plus edition, which supports higher concurrent connection counts and advanced performance features.
Option D (Sidecar Proxy) is incorrect because while it allows manual configuration of max connections, the question specifically highlights the limitation of the 'default' connection method, and upgrading to Enterprise Plus is the architectural change required to support significantly higher connection densities beyond standard limits.

## Pregunta 370

Contexto: [topics:726](#topics-726)
You are developing a new mobile game that will be deployed on GKE and Cloud Run as a set of microservices. Currently, there are no projections for the game’s user volume.

You need to store the following data types:
•	Data type 1: leaderboard data
•	Data type 2: player profiles, chats, and news feed
•	Data type 3: player clickstream data for BI

You need to identify a data storage solution that is easy to use, cost-effective, scalable, and supports offline caching on the user’s device. Which data storage option should you choose for the different data types?

**A.** •	Data type 1: Memorystore
•	Data type 2: Firestore
•	Data type 3: BigQuery

**B.** •	Data type 1: Memorystore
•	Data type 2: Spanner
•	Data type 3: Bigtable

**C.** •	Data type 1: Firestore
•	Data type 2: Cloud SQL
•	Data type 3: BigQuery

**D.** •	Data type 1: Firestore
•	Data type 2: Firestore
•	Data type 3: BigQuery

**Respuesta de la fuente:** D

**Explicación:** Firestore is the optimal choice for Data Types 1 and 2 because it natively supports offline caching on client devices and scales automatically without complex administration, meeting the 'easy to use' and 'offline' requirements. BigQuery is the standard GCP solution for storing large-scale clickstream data for Business Intelligence analysis. Option A is incorrect because Memorystore (Redis) is a server-side cache that does not provide native offline persistence on user mobile devices.

## Pregunta 371

Contexto: [topics:726](#topics-726)
Your team developed a web-based game that has many simultaneous players. Recently, users have started to complain that the leaderboard tallies the top scores too slowly. You investigated the issue and discovered that the application stack is currently using Cloud SQL for PostgreSQL. You want to improve the leaderboard performance as much as possible to provide a better user experience. What should you do?

**A.** Re-implement the leaderboard data to be stored in Memorystore for Redis.

**B.** Optimize the SQL queries to minimize slow-running queries.

**C.** Migrate the database and store the data in AlloyDB.

**D.** Update Cloud SQL for PostgreSQL to the latest version.

**Respuesta de la fuente:** A

**Explicación:** Cloud Memorystore for Redis is an in-memory data store optimized for low-latency, high-throughput access patterns typical of real-time leaderboards with many simultaneous users.
While optimizing SQL queries (B) provides incremental improvements, migrating the leaderboard logic to a key-value store like Redis fundamentally addresses the bottleneck by moving from disk-based relational storage to fast in-memory operations.

## Pregunta 372

Contexto: [topics:726](#topics-726)
You are a developer at a large corporation. You manage three GKE clusters. Your team’s developers need to switch from one cluster to another regularly on the same workstation. You want to configure individual access to these multiple clusters securely while following Google-recommended practices. What should you do?

**A.** Ask the developers to use Cloud Shell and run the gcloud container clusters get-credentials command to switch to another cluster.

**B.** Ask the developers to open three terminals on their workstation and use the kubectl config set command to configure access to each cluster.

**C.** Ask the developers to install the gcloud CLI on their workstation and run the gcloud container clusters get-credentials command to switch to another cluster.

**D.** In a text file, define the clusters, users, and contexts. Email the file to the developers and ask them to use the kubectl config set command to add cluster, user, and context details to the file.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because the `gcloud container clusters get-credentials` command automates the secure configuration of kubectl contexts by downloading server certificates and configuring access tokens, adhering to Google Cloud's recommended identity-based authentication practices.

Option A is less optimal as it restricts developers to Cloud Shell rather than their local workstations, violating the requirement to configure access on their specific machines.

Options B and D are incorrect because manually managing cluster details or sharing configuration files violates security best practices regarding credential management and context switching automation.

## Pregunta 373

Contexto: [topics:726](#topics-726)
You are tasked with using C++ to build and deploy a microservice for an application hosted on Google Cloud. The code needs to be containerized and use several custom software libraries that your team has built. You want to minimize maintenance of the application’s underlying infrastructure. How should you deploy the microservice?

**A.** Use Cloud Run functions to deploy the microservice.

**B.** Use Cloud Build to create the container, and deploy it on Cloud Run.

**C.** Use Cloud Shell to containerize your microservice, and deploy it on GKE Standard.

**D.** Use Cloud Shell to containerize your microservice, and deploy it on a Container-Optimized OS Compute Engine instance.

**Respuesta de la fuente:** B

**Explicación:** Cloud Run is the ideal choice because it supports custom container images (allowing C++ and specific libraries) while fully managing the underlying infrastructure, directly satisfying the requirement to minimize maintenance overhead.
Option A (Cloud Functions) is less suitable as it is primarily designed for event-driven code snippets rather than full microservices with complex custom dependencies, though Second Generation functions support containers, Cloud Run is the standard serverless container service.

## Pregunta 374

Contexto: [topics:726](#topics-726)
You are a developer that works for a local concert venue. Customers use your company’s website to purchase tickets for events. You need to provide customers with immediate confirmation when a selected seat has been reserved. How should you design the ticket ordering process?

**A.** Upload the seat reservation to a Cloud Storage bucket, which triggers an event to the backend service that processes the seat reservation.

**B.** Submit the seat reservation in an HTTP POST request to an Application Load Balancer. Configure the Application Load Balancer to distribute the request to the backend service that processes the seat reservation.

**C.** Add the seat reservation to a Cloud Tasks queue, which triggers Workflows to process the seat reservation.

**D.** Publish the seat reservation to a Pub/Sub topic. Configure the backend service to subscribe to the topic to process the seat reservation.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because an HTTP POST request via an Application Load Balancer provides a synchronous communication path, ensuring the client receives an immediate response and confirmation of the reservation.
Options A, C, and D utilize asynchronous patterns (Cloud Storage triggers, Cloud Tasks queues, and Pub/Sub topics) where the processing happens in the background, preventing the system from providing the required immediate confirmation to the user.

## Pregunta 375

Contexto: [topics:726](#topics-726)
You recently deployed an API to process hotel room requests. You need to enforce a quota on incoming API requests that allows no more than 1000 API search requests by each customer for every successful booking by that customer. You want the quota to reset every 24 hours. You want to prioritize the speed of the API over allowing exactly 1000 searches for every booking. What should you do?

**A.** Configure an Apigee Quota policy with the Synchronous setting set to false. Reset the quota on every booking or when 24 hours have passed.

**B.** Store a query counter in a Firestore document that uses the customer ID as the key. Reset the counter to zero when a booking occurs or 24 hours have passed. Deny a search request if the user’s counter is over 1000.

**C.** Store a query counter in memory that counts the number of search requests by each customer. Reset the counter to zero when a booking occurs or 24 hours have passed. Deny a search request if the user’s counter is over 1000.

**D.** In BigQuery, store a table row for each search and booking request along with the customer ID and current time. Query the table for the number of prior search and booking requests made in the last 24 hours. Deny the search request if the number of prior search requests is 1000 times more than the number of prior booking requests.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 376

Contexto: [topics:726](#topics-726)
Your team is trying to reduce their cloud spend, and you want to evaluate your GKE Autopilot cluster costs. When reviewing the manifests, you see that resource requests are currently not specified. Your application is stateless and fault-tolerant, and there are no specific hardware or memory requirements on nodes. You want to modify the cluster to be scalable and cost-effective as quickly as possible while maintaining a cluster with sufficient computing resources. What should you do?

**A.** Request that your Pods run as Spot Pods, and use the cloud.google.com/gke-spot=true label in your YAML manifest.

**B.** Request the Balanced compute class in your YAML manifest.

**C.** In the YAML deployment configuration manifest, request and set the maximum CPU to 5 vCPU.

**D.** Set up Cloud Trace and Cloud Monitoring, identify the maximum memory used in the past 30 days, and set the YAML manifest to request that amount of memory.

**Respuesta de la fuente:** A

**Explicación:** Answer A is correct because GKE Autopilot automatically manages node provisioning and scaling based on resource requests, making Spot instances the most effective way to reduce costs for stateless, fault-tolerant workloads. Using the `cloud.google.com/gke-spot=true` label allows Pods to run on preemptible VMs at a significantly lower price without requiring manual configuration of hardware or memory limits.

The tempting alternative, D, is incorrect because it introduces unnecessary latency and complexity; manually calculating and setting resource requests based on historical data contradicts the 'as quickly as possible' requirement and ignores Autopilot's ability to optimize costs dynamically when Spot instances are enabled. Options B and C are also suboptimal: B refers to a concept not directly applicable via simple YAML labels in Autopilot for cost reduction, and C limits scalability by capping CPU rather than leveraging cheaper compute resources.

## Pregunta 377

Contexto: [topics:726](#topics-726)
You are building an application that will store frequently accessed data in a Memorystore for Redis Cluster instance. You would like to make the application resilient to network issues. You need to ensure that the application handles client disconnections from a Redis instance gracefully to minimize disruption and ensure stability of the application. What should you do?

**A.** Immediately terminate the application instance upon detecting a Redis disconnection to force a restart, and wait for clients to reconnect to the cache as soon as the application becomes available.

**B.** Configure the Redis client to reconnect after a fixed delay of 60 seconds.

**C.** Use Memorystore’s automatic failover mechanisms to make the Redis cache available in a secondary zone.

**D.** Implement exponential backoff with a jitter when reconnecting after a disconnection. Configure client-side caching to serve data during brief outages.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because implementing exponential backoff with jitter prevents the thundering herd problem where simultaneous reconnection attempts overwhelm the Redis cluster during recovery. Additionally, client-side caching provides a fallback data source, ensuring application stability and minimizing user disruption during brief network outages.

Option C is incorrect because Memorystore for Redis High Availability (which includes automatic failover) does not support secondary zones; it only supports high availability within the same zone.

## Pregunta 378

Contexto: [topics:726](#topics-726)
You have an application running in Cloud Run that validates bucket names based on your organization’s compliance rule. You want the Cloud Run application to receive a notification as quickly as possible each time a new Cloud Storage bucket is created, and send an alert to the project owner if the bucket name is not in compliance. You need to configure the notification while following Google-recommended practices. What should you do?

**A.** Create a log-based metric with an alerting policy that sends a notification using the webhook to the Cloud Run endpoint.

**B.** Configure an Eventarc trigger using the storage.buckets.create filter that sends a notification to the Cloud Run endpoint.

**C.** Configure a log-based alerting policy using the storage.buckets.create filter in the audit logs that sends a notification to the Cloud Run webhook.

**D.** Configure a log-based alerting policy using the storage.buckets.create filter in the audit logs that sends a notification to a Pub/Sub topic that is pushed to the Cloud Run service.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 379

Contexto: [topics:726](#topics-726)
You are customizing a VM instance for development and need to choose either SSD or Standard Persistent Disks for your VM. Your team’s cloud architect is not currently available for you to consult. You need to quickly determine the advantages and disadvantages of using SSD or Standard storage. What should you do?

**A.** Use Gemini Cloud Assist, and prompt “What is the difference between SSD and Standard Persistent Disks?”

**B.** Request help on internet forums such as Reddit or Stack Overflow.

**C.** Review the Google Cloud documentation on Persistent Disks.

**D.** Review reference architectures that match your application in the Cloud Architecture Center.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.