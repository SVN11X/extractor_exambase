# professional machine learning engineer

339 / 339 preguntas. Cobertura completa: True.

Respuestas de la fuente; revisión técnica pendiente. Las imágenes permanecen en sus campos de origen.

339 respuestas conservadas; 0 pendientes.

<a id="topics-106"></a>
## Contexto topics:106
name:
Topic 1


## Pregunta 1

Contexto: [topics:106](#topics-106)
You are building an ML model to detect anomalies in real-time sensor data. You will use Pub/Sub to handle incoming requests. You want to store the results for analytics and visualization. How should you configure the pipeline?

**A.** 1 = Dataflow, 2 = AI Platform, 3 = BigQuery

**B.** 1 = DataProc, 2 = AutoML, 3 = Cloud Bigtable

**C.** 1 = BigQuery, 2 = AutoML, 3 = Cloud Functions

**D.** 1 = BigQuery, 2 = AI Platform, 3 = Cloud Storage

**Respuesta de la fuente:** A

**Explicación:** Cloud Dataflow is the ideal service for processing real-time Pub/Sub data streams, making it the correct first component.
Vertex AI (formerly AI Platform) provides managed services for running anomaly detection models on this incoming stream.
BigQuery serves as a scalable data warehouse optimized for storing results and enabling advanced analytics and visualization.

## Pregunta 2

Contexto: [topics:106](#topics-106)
Your organization wants to make its internal shuttle service route more efficient. The shuttles currently stop at all pick-up points across the city every 30 minutes between 7 am and 10 am. The development team has already built an application on Google Kubernetes Engine that requires users to confirm their presence and shuttle station one day in advance. What approach should you take?

**A.** 1. Build a tree-based regression model that predicts how many passengers will be picked up at each shuttle station. 2. Dispatch an appropriately sized shuttle and provide the map with the required stops based on the prediction.

**B.** 1. Build a tree-based classification model that predicts whether the shuttle should pick up passengers at each shuttle station. 2. Dispatch an available shuttle and provide the map with the required stops based on the prediction.

**C.** 1. Define the optimal route as the shortest route that passes by all shuttle stations with confirmed attendance at the given time under capacity constraints. 2. Dispatch an appropriately sized shuttle and indicate the required stops on the map.

**D.** 1. Build a reinforcement learning model with tree-based classification models that predict the presence of passengers at shuttle stops as agents and a reward function around a distance-based metric. 2. Dispatch an appropriately sized shuttle and provide the map with the required stops based on the simulated outcome.

**Respuesta de la fuente:** C

**Explicación:** The problem states that user presence is already confirmed in advance, eliminating the need for predictive machine learning models like regression or classification.
Since the set of stops is known deterministically, applying a classical optimization algorithm to find the shortest route under capacity constraints is the most accurate and efficient approach.
Machine learning introduces unnecessary complexity and potential error where exact data is available.

## Pregunta 3

Contexto: [topics:106](#topics-106)
You were asked to investigate failures of a production line component based on sensor readings. After receiving the dataset, you discover that less than 1% of the readings are positive examples representing failure incidents. You have tried to train several classification models, but none of them converge. How should you resolve the class imbalance problem?

**A.** Use the class distribution to generate 10% positive examples.

**B.** Use a convolutional neural network with max pooling and softmax activation.

**C.** Downsample the data with upweighting to create a sample with 10% positive examples.

**D.** Remove negative examples until the numbers of positive and negative examples are equal.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because downsampling the majority class while upweighting the minority class reduces the computational burden that causes models to fail to converge on highly imbalanced data.
This technique preserves a representative subset of the negative examples while ensuring the rare positive cases have sufficient influence on the loss function, addressing both convergence and imbalance issues as recommended by ML best practices.

## Pregunta 4

Contexto: [topics:106](#topics-106)
You want to rebuild your ML pipeline for structured data on Google Cloud. You are using PySpark to conduct data transformations at scale, but your pipelines are taking over 12 hours to run. To speed up development and pipeline run time, you want to use a serverless tool and SQL syntax. You have already moved your raw data into Cloud Storage. How should you build the pipeline on Google Cloud while meeting the speed and processing requirements?

**A.** Use Data Fusion's GUI to build the transformation pipelines, and then write the data into BigQuery.

**B.** Convert your PySpark into SparkSQL queries to transform the data, and then run your pipeline on Dataproc to write the data into BigQuery.

**C.** Ingest your data into Cloud SQL, convert your PySpark commands into SQL queries to transform the data, and then use federated queries from BigQuery for machine learning.

**D.** Ingest your data into BigQuery using BigQuery Load, convert your PySpark commands into BigQuery SQL queries to transform the data, and then write the transformations to a new table.

**Respuesta de la fuente:** D

**Explicación:** BigQuery is a fully serverless data warehouse that supports standard SQL, directly meeting the requirements for a serverless tool and SQL syntax.
Data Fusion relies on a GUI rather than SQL for pipeline construction, while Dataproc and Cloud SQL require infrastructure management (clusters or instances) and are not purely serverless in the context of this specific optimization goal.

## Pregunta 5

Contexto: [topics:106](#topics-106)
You manage a team of data scientists who use a cloud-based backend system to submit training jobs. This system has become very difficult to administer, and you want to use a managed service instead. The data scientists you work with use many different frameworks, including Keras, PyTorch, theano, Scikit-learn, and custom libraries. What should you do?

**A.** Use the AI Platform custom containers feature to receive training jobs using any framework.

**B.** Configure Kubeflow to run on Google Kubernetes Engine and receive training jobs through TF Job.

**C.** Create a library of VM images on Compute Engine, and publish these images on a centralized repository.

**D.** Set up Slurm workload manager to receive jobs that can be scheduled to run on your cloud infrastructure.

**Respuesta de la fuente:** A

**Explicación:** The question requires a managed service that supports diverse ML frameworks like Keras, PyTorch, and custom libraries.
Vertex AI (formerly AI Platform) provides a fully managed environment where the custom containers feature allows you to run training jobs using any framework or dependency configuration.
Other options involve self-managing infrastructure (Kubeflow on GKE, Compute Engine VMs, Slurm), which contradicts the requirement for a managed service.

## Pregunta 6

Contexto: [topics:106](#topics-106)
You work for an online retail company that is creating a visual search engine. You have set up an end-to-end ML pipeline on Google Cloud to classify whether an image contains your company's product. Expecting the release of new products in the near future, you configured a retraining functionality in the pipeline so that new data can be fed into your ML models. You also want to use AI Platform's continuous evaluation service to ensure that the models have high accuracy on your test dataset. What should you do?

**A.** Keep the original test dataset unchanged even if newer products are incorporated into retraining.

**B.** Extend your test dataset with images of the newer products when they are introduced to retraining.

**C.** Replace your test dataset with images of the newer products when they are introduced to retraining.

**D.** Update your test dataset with images of the newer products when your evaluation metrics drop below a pre-decided threshold.

**Respuesta de la fuente:** B

**Explicación:** The goal is to evaluate the model's ability to classify both existing and new products accurately. Extending the test dataset (Option B) ensures that evaluation metrics reflect performance on the full scope of products currently in circulation.
Replacing or keeping the test set static would lead to biased evaluations that do not account for the new data distribution introduced by retraining.

## Pregunta 7

Contexto: [topics:106](#topics-106)
You need to build classification workflows over several structured datasets currently stored in BigQuery. Because you will be performing the classification several times, you want to complete the following steps without writing code: exploratory data analysis, feature selection, model building, training, and hyperparameter tuning and serving. What should you do?

**A.** Configure AutoML Tables to perform the classification task.

**B.** Run a BigQuery ML task to perform logistic regression for the classification.

**C.** Use AI Platform Notebooks to run the classification model with pandas library.

**D.** Use AI Platform to run the classification model job configured for hyperparameter tuning.

**Respuesta de la fuente:** A

**Explicación:** The requirement to complete exploratory data analysis, feature selection, model building, training, and hyperparameter tuning 'without writing code' specifically points to a no-code/low-code AutoML solution.

Google Cloud's AutoML Tables is designed for structured datasets in BigQuery and automatically handles the entire ML lifecycle, including automatic feature engineering and hyperparameter tuning, without requiring manual code implementation.

In contrast, BigQuery ML (Option B) requires writing SQL queries to define and train models, while AI Platform options (C and D) involve significant coding effort using libraries like pandas or custom job configurations.

## Pregunta 8

Contexto: [topics:106](#topics-106)
You work for a public transportation company and need to build a model to estimate delay times for multiple transportation routes. Predictions are served directly to users in an app in real time. Because different seasons and population increases impact the data relevance, you will retrain the model every month. You want to follow Google-recommended best practices. How should you configure the end-to-end architecture of the predictive model?

**A.** Configure Kubeflow Pipelines to schedule your multi-step workflow from training to deploying your model.

**B.** Use a model trained and deployed on BigQuery ML, and trigger retraining with the scheduled query feature in BigQuery.

**C.** Write a Cloud Functions script that launches a training and deploying job on AI Platform that is triggered by Cloud Scheduler.

**D.** Use Cloud Composer to programmatically schedule a Dataflow job that executes the workflow from training to deploying your model.

**Respuesta de la fuente:** A

**Explicación:** Kubeflow Pipelines is the Google-recommended standard for orchestrating end-to-end machine learning workflows, including training and deployment, on GCP.
Unlike BigQuery ML or Dataflow, which focus on specific processing tasks rather than full workflow orchestration with failure handling,
Kubeflow provides native support for portable, scalable ML pipelines that align with Vertex AI best practices.

## Pregunta 9

Contexto: [topics:106](#topics-106)
You are developing ML models with AI Platform for image segmentation on CT scans. You frequently update your model architectures based on the newest available research papers, and have to rerun training on the same dataset to benchmark their performance. You want to minimize computation costs and manual intervention while having version control for your code. What should you do?

**A.** Use Cloud Functions to identify changes to your code in Cloud Storage and trigger a retraining job.

**B.** Use the gcloud command-line tool to submit training jobs on AI Platform when you update your code.

**C.** Use Cloud Build linked with Cloud Source Repositories to trigger retraining when new code is pushed to the repository.

**D.** Create an automated workflow in Cloud Composer that runs daily and looks for changes in code in Cloud Storage using a sensor.

**Respuesta de la fuente:** C

**Explicación:** Cloud Build provides native integration with source control systems like Cloud Source Repositories, satisfying the requirement for version control.
It enables automated triggers on code pushes, ensuring zero manual intervention for retraining jobs.
This CI/CD approach is more cost-effective and efficient than using a daily polling mechanism (Cloud Composer) or manual CLI commands.

## Pregunta 10

Contexto: [topics:106](#topics-106)
Your team needs to build a model that predicts whether images contain a driver's license, passport, or credit card. The data engineering team already built the pipeline and generated a dataset composed of 10,000 images with driver's licenses, 1,000 images with passports, and 1,000 images with credit cards. You now have to train a model with the following label map: ['drivers_license', 'passport', 'credit_card']. Which loss function should you use?

**A.** Categorical hinge

**B.** Binary cross-entropy

**C.** Categorical cross-entropy

**D.** Sparse categorical cross-entropy

**Respuesta de la fuente:** D

**Explicación:** The problem describes a multi-class classification task with mutually exclusive classes (an image is either a driver's license, passport, or credit card, but not multiple simultaneously).
Sparse categorical cross-entropy is the appropriate loss function for such problems because it accepts integer-encoded labels directly, avoiding the memory overhead of one-hot encoding required by standard categorical cross-entropy.

## Pregunta 11

Contexto: [topics:106](#topics-106)
You are designing an ML recommendation model for shoppers on your company's ecommerce website. You will use Recommendations AI to build, test, and deploy your system. How should you develop recommendations that increase revenue while following best practices?

**A.** Use the "Other Products You May Like" recommendation type to increase the click-through rate.

**B.** Use the "Frequently Bought Together" recommendation type to increase the shopping cart size for each order.

**C.** Import your user events and then your product catalog to make sure you have the highest quality event stream.

**D.** Because it will take time to collect and record product data, use placeholder values for the product catalog to test the viability of the model.

**Respuesta de la fuente:** B

**Explicación:** The 'Frequently Bought Together' recommendation type is specifically designed for shopping cart expansion, with a default optimization objective of increasing revenue per order.
This directly addresses the goal of increasing revenue by suggesting complementary items that customers are likely to purchase alongside their current selections.
In contrast, 'Other Products You May Like' optimizes for click-through rate, and placeholder data violates best practices for catalog integrity.

## Pregunta 12

Contexto: [topics:106](#topics-106)
You are designing an architecture with a serverless ML system to enrich customer support tickets with informative metadata before they are routed to a support agent. You need a set of models to predict ticket priority, predict ticket resolution time, and perform sentiment analysis to help agents make strategic decisions when they process support requests. Tickets are not expected to have any domain-specific terms or jargon.
The proposed architecture has the following flow:
[Imagen: sin descripción]
Which endpoints should the Enrichment Cloud Functions call?
Imagen · question_text · sin descripción
![Imagen original](imagenes/99f5fcd8e4bb749d18dc.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
User writes a Helpdesk
support ticket Platform
Create Ticket
Firebase
Cloud Functions
| Offline
Enrichment Endpoint 1 |, | | Classification
Training
Cloud Functions
A Regression
Endpoint2_ |||
Pein Training
(Experience,
category, type,
impact, seniority)
Endpoint 3
```

**A.** 1 = AI Platform, 2 = AI Platform, 3 = AutoML Vision

**B.** 1 = AI Platform, 2 = AI Platform, 3 = AutoML Natural Language

**C.** 1 = AI Platform, 2 = AI Platform, 3 = Cloud Natural Language API

**D.** 1 = Cloud Natural Language API, 2 = AI Platform, 3 = Cloud Vision API

**Respuesta de la fuente:** C

**Explicación:** Endpoints 1 and 2 must be AI Platform because they host custom models for predicting ticket priority (classification) and resolution time (regression), which are not standard off-the-shelf features.
Endpoint 3 should be the Cloud Natural Language API because it provides built-in sentiment analysis out-of-the-box, eliminating the need for AutoML training since the tickets lack domain-specific jargon.

## Pregunta 13

Contexto: [topics:106](#topics-106)
You have trained a deep neural network model on Google Cloud. The model has low loss on the training data, but is performing worse on the validation data. You want the model to be resilient to overfitting. Which strategy should you use when retraining the model?

**A.** Apply a dropout parameter of 0.2, and decrease the learning rate by a factor of 10.

**B.** Apply a L2 regularization parameter of 0.4, and decrease the learning rate by a factor of 10.

**C.** Run a hyperparameter tuning job on AI Platform to optimize for the L2 regularization and dropout parameters.

**D.** Run a hyperparameter tuning job on AI Platform to optimize for the learning rate, and increase the number of neurons by a factor of 2.

**Respuesta de la fuente:** C

**Explicación:** The model exhibits overfitting, indicated by low training loss but poor validation performance. Regularization techniques like Dropout and L2 regularization are specifically designed to constrain model complexity and improve generalization.
Hyperparameter tuning (Option C) is the optimal strategy because it systematically finds the best regularization strengths, whereas fixed values (A, B) may not be effective for this specific model. Option D worsens overfitting by increasing model capacity.

## Pregunta 14

Contexto: [topics:106](#topics-106)
You built and manage a production system that is responsible for predicting sales numbers. Model accuracy is crucial, because the production model is required to keep up with market changes. Since being deployed to production, the model hasn't changed; however the accuracy of the model has steadily deteriorated.
What issue is most likely causing the steady decline in model accuracy?

**A.** Poor data quality

**B.** Lack of model retraining

**C.** Too few layers in the model for capturing information

**D.** Incorrect data split ratio during model training, evaluation, validation, and test

**Respuesta de la fuente:** B

**Explicación:** The scenario describes concept drift, where the statistical properties of the target variable change over time due to market dynamics. Since the model was deployed without updates, it fails to capture new patterns, necessitating retraining on recent data to maintain accuracy.

## Pregunta 15

Contexto: [topics:106](#topics-106)
You have been asked to develop an input pipeline for an ML training model that processes images from disparate sources at a low latency. You discover that your input data does not fit in memory. How should you create a dataset following Google-recommended best practices?

**A.** Create a tf.data.Dataset.prefetch transformation.

**B.** Convert the images to tf.Tensor objects, and then run Dataset.from_tensor_slices().

**C.** Convert the images to tf.Tensor objects, and then run tf.data.Dataset.from_tensors().

**D.** Convert the images into TFRecords, store the images in Cloud Storage, and then use the tf.data API to read the images for training.

**Respuesta de la fuente:** D

**Explicación:** When input data is too large to fit in memory, Google recommends using the TFRecord format to store data efficiently on disk (e.g., Cloud Storage). You then use the `tf.data` API (specifically `TFRecordDataset`) to read and process this external data stream during training. Options A, B, and C are unsuitable because they either assume data is already in memory or are optimizations applied after the dataset has been constructed from an appropriate source.

## Pregunta 16

Contexto: [topics:106](#topics-106)
You are an ML engineer at a large grocery retailer with stores in multiple regions. You have been asked to create an inventory prediction model. Your model's features include region, location, historical demand, and seasonal popularity. You want the algorithm to learn from new inventory data on a daily basis. Which algorithms should you use to build the model?

**A.** Classification

**B.** Reinforcement Learning

**C.** Recurrent Neural Networks (RNN)

**D.** Convolutional Neural Networks (CNN)

**Respuesta de la fuente:** C

**Explicación:** Inventory prediction based on historical demand and seasonal trends is a time-series forecasting problem, which requires handling sequential data dependencies. Recurrent Neural Networks (RNNs) are specifically designed to process such sequential inputs by maintaining an internal state that captures temporal patterns from previous time steps.

While Reinforcement Learning involves learning through interaction and rewards, it is not the standard approach for direct prediction tasks using historical datasets. Classification is unsuitable as the output is a continuous quantity (inventory levels), and CNNs are primarily optimized for spatial data like images rather than sequential time-series data.

## Pregunta 17

Contexto: [topics:106](#topics-106)
You are building a real-time prediction engine that streams files which may contain Personally Identifiable Information (PII) to Google Cloud. You want to use the
Cloud Data Loss Prevention (DLP) API to scan the files. How should you ensure that the PII is not accessible by unauthorized individuals?

**A.** Stream all files to Google Cloud, and then write the data to BigQuery. Periodically conduct a bulk scan of the table using the DLP API.

**B.** Stream all files to Google Cloud, and write batches of the data to BigQuery. While the data is being written to BigQuery, conduct a bulk scan of the data using the DLP API.

**C.** Create two buckets of data: Sensitive and Non-sensitive. Write all data to the Non-sensitive bucket. Periodically conduct a bulk scan of that bucket using the DLP API, and move the sensitive data to the Sensitive bucket.

**D.** Create three buckets of data: Quarantine, Sensitive, and Non-sensitive. Write all data to the Quarantine bucket. Periodically conduct a bulk scan of that bucket using the DLP API, and move the data to either the Sensitive or Non-Sensitive bucket.

**Respuesta de la fuente:** D

**Explicación:** The correct architecture for scanning streaming data with Cloud DLP involves an intermediate quarantine stage to prevent unauthorized access before classification.
By writing all incoming files to a Quarantine bucket with restricted access, you ensure PII is never exposed in unrestricted storage.
The DLP API then scans this isolated data and moves confirmed sensitive items to a highly secure Sensitive bucket or non-sensitive items to a standard bucket, satisfying the requirement to prevent unauthorized access during the ingestion process.

## Pregunta 18

Contexto: [topics:106](#topics-106)
You work for a large hotel chain and have been asked to assist the marketing team in gathering predictions for a targeted marketing strategy. You need to make predictions about user lifetime value (LTV) over the next 20 days so that marketing can be adjusted accordingly. The customer dataset is in BigQuery, and you are preparing the tabular data for training with AutoML Tables. This data has a time signal that is spread across multiple columns. How should you ensure that
AutoML fits the best model to your data?

**A.** Manually combine all columns that contain a time signal into an array. AIlow AutoML to interpret this array appropriately. Choose an automatic data split across the training, validation, and testing sets.

**B.** Submit the data for training without performing any manual transformations. AIlow AutoML to handle the appropriate transformations. Choose an automatic data split across the training, validation, and testing sets.

**C.** Submit the data for training without performing any manual transformations, and indicate an appropriate column as the Time column. AIlow AutoML to split your data based on the time signal provided, and reserve the more recent data for the validation and testing sets.

**D.** Submit the data for training without performing any manual transformations. Use the columns that have a time signal to manually split your data. Ensure that the data in your validation set is from 30 days after the data in your training set and that the data in your testing sets from 30 days after your validation set.

**Respuesta de la fuente:** D

**Explicación:** The correct answer is D because the time signal is spread across multiple columns, preventing AutoML Tables from automatically identifying a single Time column for chronological splitting.
Without manual intervention, automatic splitting would likely cause data leakage by mixing past and future data points.
Manual splitting ensures that training, validation, and test sets are strictly separated by time, with the most recent data reserved for testing to accurately reflect real-world predictive performance.

## Pregunta 19

Contexto: [topics:106](#topics-106)
You have written unit tests for a Kubeflow Pipeline that require custom libraries. You want to automate the execution of unit tests with each new push to your development branch in Cloud Source Repositories. What should you do?

**A.** Write a script that sequentially performs the push to your development branch and executes the unit tests on Cloud Run.

**B.** Using Cloud Build, set an automated trigger to execute the unit tests when changes are pushed to your development branch.

**C.** Set up a Cloud Logging sink to a Pub/Sub topic that captures interactions with Cloud Source Repositories. Configure a Pub/Sub trigger for Cloud Run, and execute the unit tests on Cloud Run.

**D.** Set up a Cloud Logging sink to a Pub/Sub topic that captures interactions with Cloud Source Repositories. Execute the unit tests using a Cloud Function that is triggered when messages are sent to the Pub/Sub topic.

**Respuesta de la fuente:** B

**Explicación:** Cloud Build is the native GCP service designed for CI/CD workflows, allowing you to create triggers that automatically execute build steps (such as unit tests) when changes are pushed to a source repository.
Options A, C, and D propose overly complex or architecturally incorrect patterns by relying on Cloud Run, Cloud Functions, or manual scripting instead of using the dedicated automation features of Cloud Build.

## Pregunta 20

Contexto: [topics:106](#topics-106)
You are training an LSTM-based model on AI Platform to summarize text using the following job submission script: gcloud ai-platform jobs submit training $JOB_NAME \
--package-path $TRAINER_PACKAGE_PATH \
--module-name $MAIN_TRAINER_MODULE \
--job-dir $JOB_DIR \
--region $REGION \
--scale-tier basic \
-- \
--epochs 20 \
--batch_size=32 \
--learning_rate=0.001 \
You want to ensure that training time is minimized without significantly compromising the accuracy of your model. What should you do?

**A.** Modify the 'epochs' parameter.

**B.** Modify the 'scale-tier' parameter.

**C.** Modify the 'batch size' parameter.

**D.** Modify the 'learning rate' parameter.

**Respuesta de la fuente:** B

**Explicación:** Modifying the scale-tier upgrades the hardware resources (e.g., from CPU to GPU/TPU) without altering model hyperparameters, directly reducing training time while maintaining identical model accuracy. In contrast, changing epochs, batch size, or learning rate involves hyperparameter tuning that risks degrading model performance.

## Pregunta 21

Contexto: [topics:106](#topics-106)
You have deployed multiple versions of an image classification model on AI Platform. You want to monitor the performance of the model versions over time. How should you perform this comparison?

**A.** Compare the loss performance for each model on a held-out dataset.

**B.** Compare the loss performance for each model on the validation data.

**C.** Compare the receiver operating characteristic (ROC) curve for each model using the What-If Tool.

**D.** Compare the mean average precision across the models using the Continuous Evaluation feature.

**Respuesta de la fuente:** D

**Explicación:** The question specifically asks about monitoring deployed models on AI Platform over time. Continuous Evaluation is the dedicated GCP service feature designed to periodically evaluate model predictions against ground truth labels and track metrics like Mean Average Precision.
While loss and validation data are used during training, they are not the primary mechanism for ongoing production monitoring via platform-native tools.

## Pregunta 22

Contexto: [topics:106](#topics-106)
You trained a text classification model. You have the following SignatureDefs:
[Imagen: sin descripción]
You started a TensorFlow-serving component server and tried to send an HTTP request to get a prediction using: headers = {"content-type": "application/json"} json_response = requests.post('http: //localhost:8501/v1/models/text_model:predict', data=data, headers=headers)
What is the correct way to write the predict request?
Imagen · question_text · sin descripción
![Imagen original](imagenes/41ace605b3d455b7d5d0.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
signature_def['serving_default']:
The given SavedModel SignatureDef contains the following input (s):
inputs['text'] tensor_info:
dtype: DT_STRING
shape: (-1, 2)
name: serving_default_text: 0
The given SavedModel SignatureDef contains the following output(s):
outputs ['Softmax'] tensor_info:
dtype: DT_FLOAT
shape: (-1, 2)
name: StatefulPartitionedCall:0
Method name is: tensorflow/serving/predict
```

**A.** data = json.dumps({"signature_name": "seving_default", "instances" [['ab', 'bc', 'cd']]})

**B.** data = json.dumps({"signature_name": "serving_default", "instances" [['a', 'b', 'c', 'd', 'e', 'f']]})

**C.** data = json.dumps({"signature_name": "serving_default", "instances" [['a', 'b', 'c'], ['d', 'e', 'f']]})

**D.** data = json.dumps({"signature_name": "serving_default", "instances" [['a', 'b'], ['c', 'd'], ['e', 'f']]})

**Respuesta de la fuente:** D

**Explicación:** The SignatureDef image shows the input tensor shape as (-1, 2), where -1 denotes a dynamic batch dimension (any number of instances) and 2 denotes the fixed feature length for each instance.
Option D provides a list of three instances (rows), each containing exactly two elements (columns), satisfying the required inner dimension of 2.
Options A, B, and C violate this constraint by providing rows with 3 or more elements.

## Pregunta 23

Contexto: [topics:106](#topics-106)
Your organization's call center has asked you to develop a model that analyzes customer sentiments in each call. The call center receives over one million calls daily, and data is stored in Cloud Storage. The data collected must not leave the region in which the call originated, and no Personally Identifiable Information (PII) can be stored or analyzed. The data science team has a third-party tool for visualization and access which requires a SQL ANSI-2011 compliant interface. You need to select components for data processing and for analytics. How should the data pipeline be designed?
[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/ef996f2bd4991de026f0.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Google Speech- Cloud Data Loss
to-Text API Prevention API
| |
Cloud Storage | ——+ 1
```

**A.** 1= Dataflow, 2= BigQuery

**B.** 1 = Pub/Sub, 2= Datastore

**C.** 1 = Dataflow, 2 = Cloud SQL

**D.** 1 = Cloud Function, 2= Cloud SQL

**Respuesta de la fuente:** A

**Explicación:** Dataflow is the appropriate choice for processing over one million daily calls because it provides scalable, unified stream and batch data processing capabilities suitable for high-volume sentiment analysis pipelines. BigQuery is the correct analytics component as it natively supports ANSI-2011 SQL compliance, handles large-scale data warehousing efficiently, and offers robust region-locking features to ensure PII and data residency requirements are met.

## Pregunta 24

Contexto: [topics:106](#topics-106)
You are an ML engineer at a global shoe store. You manage the ML models for the company's website. You are asked to build a model that will recommend new products to the user based on their purchase behavior and similarity with other users. What should you do?

**A.** Build a classification model

**B.** Build a knowledge-based filtering model

**C.** Build a collaborative-based filtering model

**D.** Build a regression model using the features as predictors

**Respuesta de la fuente:** C

**Explicación:** Collaborative filtering is the standard technique for recommender systems that predicts user preferences based on patterns of interactions and similarities among users or items.

The scenario explicitly requires leveraging 'purchase behavior' (interactions) and 'similarity with other users,' which aligns directly with collaborative filtering's core mechanism.

Classification and regression models address different predictive tasks, while knowledge-based filtering relies on explicit domain rules rather than behavioral similarity.

## Pregunta 25

Contexto: [topics:106](#topics-106)
You work for a social media company. You need to detect whether posted images contain cars. Each training example is a member of exactly one class. You have trained an object detection neural network and deployed the model version to AI Platform Prediction for evaluation. Before deployment, you created an evaluation job and attached it to the AI Platform Prediction model version. You notice that the precision is lower than your business requirements allow. How should you adjust the model's final layer softmax threshold to increase precision?

**A.** Increase the recall.

**B.** Decrease the recall.

**C.** Increase the number of false positives.

**D.** Decrease the number of false negatives.

**Respuesta de la fuente:** B

**Explicación:** Precision is defined as True Positives divided by the sum of True Positives and False Positives (TP / (TP + FP)). In classification tasks, precision and recall have an inverse relationship: increasing the threshold to improve precision reduces the number of positive predictions, which inherently lowers recall. Therefore, decreasing recall is the necessary trade-off to achieve higher precision.

## Pregunta 26

Contexto: [topics:106](#topics-106)
You are responsible for building a unified analytics environment across a variety of on-premises data marts. Your company is experiencing data quality and security challenges when integrating data across the servers, caused by the use of a wide range of disconnected tools and temporary solutions. You need a fully managed, cloud-native data integration service that will lower the total cost of work and reduce repetitive work. Some members on your team prefer a codeless interface for building Extract, Transform, Load (ETL) process. Which service should you use?

**A.** Dataflow

**B.** Dataprep

**C.** Apache Flink

**D.** Cloud Data Fusion

**Respuesta de la fuente:** D

**Explicación:** Cloud Data Fusion is the correct choice because it is a fully managed, cloud-native data integration service that provides a visual, codeless interface for building ETL/ELT pipelines. This directly addresses the requirement for a no-code solution to integrate on-premises data marts and reduce repetitive manual work.

## Pregunta 27

Contexto: [topics:106](#topics-106)
You are an ML engineer at a regulated insurance company. You are asked to develop an insurance approval model that accepts or rejects insurance applications from potential customers. What factors should you consider before building the model?

**A.** Redaction, reproducibility, and explainability

**B.** Traceability, reproducibility, and explainability

**C.** Federated learning, reproducibility, and explainability

**D.** Differential privacy, federated learning, and explainability

**Respuesta de la fuente:** B

**Explicación:** In regulated industries like insurance, models must satisfy strict compliance and audit requirements. Traceability ensures data lineage and decision history are recorded for audits; reproducibility guarantees consistent results across runs for validation; explainability allows stakeholders to understand why specific applications were approved or rejected.

## Pregunta 28

Contexto: [topics:106](#topics-106)
You are training a Resnet model on AI Platform using TPUs to visually categorize types of defects in automobile engines. You capture the training profile using the
Cloud TPU profiler plugin and observe that it is highly input-bound. You want to reduce the bottleneck and speed up your model training process. Which modifications should you make to the tf.data dataset? (Choose two.)

**A.** Use the interleave option for reading data.

**B.** Reduce the value of the repeat parameter.

**C.** Increase the buffer size for the shuttle option.

**D.** Set the prefetch option equal to the training batch size.

**E.** Decrease the batch size argument in your transformation.

**Respuesta de la fuente:** A, D

**Explicación:** When a training job is input-bound, the TPUs are idle while waiting for data. Using `interleave` (Option A) allows multiple files to be read and processed in parallel, significantly increasing I/O throughput. Setting `prefetch` (Option D) overlaps data preprocessing with model training execution, ensuring that the next batch is ready before the current one finishes processing.

## Pregunta 29

Contexto: [topics:106](#topics-106)
You have trained a model on a dataset that required computationally expensive preprocessing operations. You need to execute the same preprocessing at prediction time. You deployed the model on AI Platform for high-throughput online prediction. Which architecture should you use?

**A.** Validate the accuracy of the model that you trained on preprocessed data. Create a new model that uses the raw data and is available in real time. Deploy the new model onto AI Platform for online prediction.

**B.** Send incoming prediction requests to a Pub/Sub topic. Transform the incoming data using a Dataflow job. Submit a prediction request to AI Platform using the transformed data. Write the predictions to an outbound Pub/Sub queue.

**C.** Stream incoming prediction request data into Cloud Spanner. Create a view to abstract your preprocessing logic. Query the view every second for new records. Submit a prediction request to AI Platform using the transformed data. Write the predictions to an outbound Pub/Sub queue.

**D.** Send incoming prediction requests to a Pub/Sub topic. Set up a Cloud Function that is triggered when messages are published to the Pub/Sub topic. Implement your preprocessing logic in the Cloud Function. Submit a prediction request to AI Platform using the transformed data. Write the predictions to an outbound Pub/Sub queue.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Cloud Dataflow provides the necessary autoscaling and high-throughput capabilities required for computationally expensive preprocessing tasks.
While Cloud Functions (Option D) have concurrency limits and execution timeouts that make them unsuitable for heavy processing, Dataflow handles large volumes of data transformations efficiently in a streaming architecture.

## Pregunta 30

Contexto: [topics:106](#topics-106)
Your team trained and tested a DNN regression model with good results. Six months after deployment, the model is performing poorly due to a change in the distribution of the input data. How should you address the input differences in production?

**A.** Create alerts to monitor for skew, and retrain the model.

**B.** Perform feature selection on the model, and retrain the model with fewer features.

**C.** Retrain the model, and select an L2 regularization parameter with a hyperparameter tuning service.

**D.** Perform feature selection on the model, and retrain the model on a monthly basis with fewer features.

**Respuesta de la fuente:** A

**Explicación:** The scenario describes data drift or serving skew, where the production input distribution diverges from the training data. Monitoring for this skew allows you to detect degradation early and triggers retraining with updated data that reflects current patterns. Feature selection or regularization (options B, C, D) addresses model complexity or overfitting, not the fundamental mismatch between training and production data distributions.

## Pregunta 31

Contexto: [topics:106](#topics-106)
You need to train a computer vision model that predicts the type of government ID present in a given image using a GPU-powered virtual machine on Compute
Engine. You use the following parameters:
✑ Optimizer: SGD
✑ Image shape = 224×224
✑ Batch size = 64
✑ Epochs = 10
✑ Verbose =2
During training you encounter the following error: ResourceExhaustedError: Out Of Memory (OOM) when allocating tensor. What should you do?

**A.** Change the optimizer.

**B.** Reduce the batch size.

**C.** Change the learning rate.

**D.** Reduce the image shape.

**Respuesta de la fuente:** B

**Explicación:** A ResourceExhaustedError (OOM) occurs when the GPU lacks sufficient memory to hold the batch of tensors being processed. Reducing the batch size is the most direct and effective way to lower memory consumption without altering the model architecture or degrading input resolution quality. While reducing image dimensions also saves memory, it compromises feature extraction capability and potential model accuracy.

## Pregunta 32

Contexto: [topics:106](#topics-106)
You developed an ML model with AI Platform, and you want to move it to production. You serve a few thousand queries per second and are experiencing latency issues. Incoming requests are served by a load balancer that distributes them across multiple Kubeflow CPU-only pods running on Google Kubernetes Engine
(GKE). Your goal is to improve the serving latency without changing the underlying infrastructure. What should you do?

**A.** Significantly increase the max_batch_size TensorFlow Serving parameter.

**B.** Switch to the tensorflow-model-server-universal version of TensorFlow Serving.

**C.** Significantly increase the max_enqueued_batches TensorFlow Serving parameter.

**D.** Recompile TensorFlow Serving using the source to support CPU-specific optimizations. Instruct GKE to choose an appropriate baseline minimum CPU platform for serving nodes.

**Respuesta de la fuente:** D

**Explicación:** The correct answer is D. The question specifies CPU-only pods and asks to improve latency without changing the underlying infrastructure (i.e., not adding more nodes).

Recompiling TensorFlow Serving with CPU-specific optimizations (such as using specific instruction sets like AVX2 or AVX-512 that match the node's baseline minimum CPU platform) can significantly speed up inference operations.

This is a software/configuration-level optimization that leverages existing hardware capabilities more efficiently, directly addressing latency issues without altering the infrastructure topology.

## Pregunta 33

Contexto: [topics:106](#topics-106)
You have a demand forecasting pipeline in production that uses Dataflow to preprocess raw data prior to model training and prediction. During preprocessing, you employ Z-score normalization on data stored in BigQuery and write it back to BigQuery. New training data is added every week. You want to make the process more efficient by minimizing computation time and manual intervention. What should you do?

**A.** Normalize the data using Google Kubernetes Engine.

**B.** Translate the normalization algorithm into SQL for use with BigQuery.

**C.** Use the normalizer_fn argument in TensorFlow's Feature Column API.

**D.** Normalize the data with Apache Spark using the Dataproc connector for BigQuery.

**Respuesta de la fuente:** B

**Explicación:** Translating the normalization algorithm into SQL for use with BigQuery minimizes computation time by leveraging BigQuery's serverless infrastructure and built-in functions (such as `ML.STANDARD_SCALER`) directly on the data without moving it. This approach eliminates the overhead of extracting data to Dataflow, GKE, or Dataproc for processing and writing it back, thereby reducing manual intervention and complexity.

## Pregunta 34

Contexto: [topics:106](#topics-106)
You need to design a customized deep neural network in Keras that will predict customer purchases based on their purchase history. You want to explore model performance using multiple model architectures, store training data, and be able to compare the evaluation metrics in the same dashboard. What should you do?

**A.** Create multiple models using AutoML Tables.

**B.** Automate multiple training runs using Cloud Composer.

**C.** Run multiple training jobs on AI Platform with similar job names.

**D.** Create an experiment in Kubeflow Pipelines to organize multiple runs.

**Respuesta de la fuente:** D

**Explicación:** Kubeflow Pipelines provides a dedicated 'Experiment' abstraction designed specifically to group and organize multiple training runs. This feature allows you to systematically compare evaluation metrics, model artifacts, and hyperparameters across different architectures within a unified dashboard. Other options like AutoML Tables lack architectural customization, while AI Platform jobs require manual organization without native experiment grouping capabilities.

## Pregunta 35

Contexto: [topics:106](#topics-106)
You are developing a Kubeflow pipeline on Google Kubernetes Engine. The first step in the pipeline is to issue a query against BigQuery. You plan to use the results of that query as the input to the next step in your pipeline. You want to achieve this in the easiest way possible. What should you do?

**A.** Use the BigQuery console to execute your query, and then save the query results into a new BigQuery table.

**B.** Write a Python script that uses the BigQuery API to execute queries against BigQuery. Execute this script as the first step in your Kubeflow pipeline.

**C.** Use the Kubeflow Pipelines domain-specific language to create a custom component that uses the Python BigQuery client library to execute queries.

**D.** Locate the Kubeflow Pipelines repository on GitHub. Find the BigQuery Query Component, copy that component's URL, and use it to load the component into your pipeline. Use the component to execute queries against BigQuery.

**Respuesta de la fuente:** D

**Explicación:** The question asks for the easiest way to integrate BigQuery into a Kubeflow pipeline. Option D is correct because Kubeflow Pipelines provides pre-built, reusable components in its GitHub repository (Component Store), allowing you to load existing functionality via `load_component_from_url` without writing custom code.

Creating a custom component (Option C) or writing a raw Python script (Option B) requires more development effort. Option A is manual and does not integrate programmatically with the pipeline execution.

## Pregunta 36

Contexto: [topics:106](#topics-106)
You are building a model to predict daily temperatures. You split the data randomly and then transformed the training and test datasets. Temperature data for model training is uploaded hourly. During testing, your model performed with 97% accuracy; however, after deploying to production, the model's accuracy dropped to 66%. How can you make your production model more accurate?

**A.** Normalize the data for the training, and test datasets as two separate steps.

**B.** Split the training and test data based on time rather than a random split to avoid leakage.

**C.** Add more data to your test set to ensure that you have a fair distribution and sample for testing.

**D.** Apply data transformations before splitting, and cross-validate to make sure that the transformations are applied to both the training and test sets.

**Respuesta de la fuente:** B

**Explicación:** Daily temperature data exhibits temporal patterns, making it a time-series problem where random splitting causes data leakage by allowing future information to influence the model.
By splitting based on time (chronological order), you ensure the model only learns from past data, accurately simulating production conditions and preventing inflated test accuracy.

## Pregunta 37

Contexto: [topics:106](#topics-106)
You are developing models to classify customer support emails. You created models with TensorFlow Estimators using small datasets on your on-premises system, but you now need to train the models using large datasets to ensure high performance. You will port your models to Google Cloud and want to minimize code refactoring and infrastructure overhead for easier migration from on-prem to cloud. What should you do?

**A.** Use AI Platform for distributed training.

**B.** Create a cluster on Dataproc for training.

**C.** Create a Managed Instance Group with autoscaling.

**D.** Use Kubeflow Pipelines to train on a Google Kubernetes Engine cluster.

**Respuesta de la fuente:** A

**Explicación:** AI Platform (now Vertex AI) supports running TensorFlow Estimator code with minimal refactoring compared to GKE/Kubeflow solutions, which require containerization and complex orchestration setups. It handles infrastructure management automatically, directly addressing the requirement to minimize infrastructure overhead while enabling distributed training on large datasets.

## Pregunta 38

Contexto: [topics:106](#topics-106)
You have trained a text classification model in TensorFlow using AI Platform. You want to use the trained model for batch predictions on text data stored in
BigQuery while minimizing computational overhead. What should you do?

**A.** Export the model to BigQuery ML.

**B.** Deploy and version the model on AI Platform.

**C.** Use Dataflow with the SavedModel to read the data from BigQuery.

**D.** Submit a batch prediction job on AI Platform that points to the model location in Cloud Storage.

**Respuesta de la fuente:** A

**Explicación:** To minimize computational overhead, the best approach is to perform inference within BigQuery itself rather than moving data out or managing external compute resources.
BigQuery ML allows you to import TensorFlow models directly using SQL (OPTIONS model_type='TENSORFLOW'), enabling predictions on native BigQuery tables without additional infrastructure management.

## Pregunta 39

Contexto: [topics:106](#topics-106)
You work with a data engineering team that has developed a pipeline to clean your dataset and save it in a Cloud Storage bucket. You have created an ML model and want to use the data to refresh your model as soon as new data is available. As part of your CI/CD workflow, you want to automatically run a Kubeflow
Pipelines training job on Google Kubernetes Engine (GKE). How should you architect this workflow?

**A.** Configure your pipeline with Dataflow, which saves the files in Cloud Storage. After the file is saved, start the training job on a GKE cluster.

**B.** Use App Engine to create a lightweight python client that continuously polls Cloud Storage for new files. As soon as a file arrives, initiate the training job.

**C.** Configure a Cloud Storage trigger to send a message to a Pub/Sub topic when a new file is available in a storage bucket. Use a Pub/Sub-triggered Cloud Function to start the training job on a GKE cluster.

**D.** Use Cloud Scheduler to schedule jobs at a regular interval. For the first step of the job, check the timestamp of objects in your Cloud Storage bucket. If there are no new files since the last run, abort the job.

**Respuesta de la fuente:** C

**Explicación:** Option C is the correct architecture because it utilizes a serverless event-driven pattern. Cloud Storage triggers publish events to Pub/Sub upon file upload, and a Cloud Function subscribes to these events to immediately initiate the Kubeflow Pipeline on GKE. This ensures the model refreshes as soon as data arrives without the latency or resource waste associated with polling (Option B) or fixed schedules (Option D).

## Pregunta 40

Contexto: [topics:106](#topics-106)
You have a functioning end-to-end ML pipeline that involves tuning the hyperparameters of your ML model using AI Platform, and then using the best-tuned parameters for training. Hypertuning is taking longer than expected and is delaying the downstream processes. You want to speed up the tuning job without significantly compromising its effectiveness. Which actions should you take? (Choose two.)

**A.** Decrease the number of parallel trials.

**B.** Decrease the range of floating-point values.

**C.** Set the early stopping parameter to TRUE.

**D.** Change the search algorithm from Bayesian search to random search.

**E.** Decrease the maximum number of trials during subsequent training phases.

**Respuesta de la fuente:** C, E

**Explicación:** To speed up hyperparameter tuning while maintaining effectiveness, you should enable early stopping (C) to terminate trials that show no improvement and decrease the maximum number of trials (E) to reduce the total search space explored. Decreasing parallel trials (A) increases wall-clock time by reducing concurrency, and random search (D) is generally less efficient than Bayesian search at finding optimal points.

## Pregunta 41

Contexto: [topics:106](#topics-106)
Your team is building an application for a global bank that will be used by millions of customers. You built a forecasting model that predicts customers' account balances 3 days in the future. Your team will use the results in a new feature that will notify users when their account balance is likely to drop below $25. How should you serve your predictions?

**A.** 1. Create a Pub/Sub topic for each user. 2. Deploy a Cloud Function that sends a notification when your model predicts that a user's account balance will drop below the $25 threshold.

**B.** 1. Create a Pub/Sub topic for each user. 2. Deploy an application on the App Engine standard environment that sends a notification when your model predicts that a user's account balance will drop below the $25 threshold.

**C.** 1. Build a notification system on Firebase. 2. Register each user with a user ID on the Firebase Cloud Messaging server, which sends a notification when the average of all account balance predictions drops below the $25 threshold.

**D.** 1. Build a notification system on Firebase. 2. Register each user with a user ID on the Firebase Cloud Messaging server, which sends a notification when your model predicts that a user's account balance will drop below the $25 threshold.

**Respuesta de la fuente:** D

**Explicación:** Options A and B are incorrect because creating a Pub/Sub topic for each user violates GCP quotas (typically ~10,000 topics per project) and does not scale to millions of customers.
Option C is incorrect because it sends notifications based on the average balance, failing to notify individual users about their specific low balances.
Option D is correct as Firebase Cloud Messaging (FCM) is specifically designed for sending targeted push notifications to large numbers of registered devices efficiently.

## Pregunta 42

Contexto: [topics:106](#topics-106)
You work for an advertising company and want to understand the effectiveness of your company's latest advertising campaign. You have streamed 500 MB of campaign data into BigQuery. You want to query the table, and then manipulate the results of that query with a pandas dataframe in an AI Platform notebook.
What should you do?

**A.** Use AI Platform Notebooks' BigQuery cell magic to query the data, and ingest the results as a pandas dataframe.

**B.** Export your table as a CSV file from BigQuery to Google Drive, and use the Google Drive API to ingest the file into your notebook instance.

**C.** Download your table from BigQuery as a local CSV file, and upload it to your AI Platform notebook instance. Use pandas.read_csv to ingest he file as a pandas dataframe.

**D.** From a bash cell in your AI Platform notebook, use the bq extract command to export the table as a CSV file to Cloud Storage, and then use gsutil cp to copy the data into the notebook. Use pandas.read_csv to ingest the file as a pandas dataframe.

**Respuesta de la fuente:** A

**Explicación:** Option A is the correct answer because AI Platform Notebooks (now Vertex AI Workbench) natively supports BigQuery cell magic (`%%bigquery`), which allows you to execute SQL queries directly within a notebook cell and automatically store the results in a pandas DataFrame.
This approach is the most efficient and integrated method, avoiding the unnecessary overhead of exporting data to CSV files and manually transferring them via Cloud Storage or Google Drive, as suggested in options B, C, and D.

## Pregunta 43

Contexto: [topics:106](#topics-106)
You are an ML engineer at a global car manufacture. You need to build an ML model to predict car sales in different cities around the world. Which features or feature crosses should you use to train city-specific relationships between car type and number of sales?

**A.** Thee individual features: binned latitude, binned longitude, and one-hot encoded car type.

**B.** One feature obtained as an element-wise product between latitude, longitude, and car type.

**C.** One feature obtained as an element-wise product between binned latitude, binned longitude, and one-hot encoded car type.

**D.** Two feature crosses as an element-wise product: the first between binned latitude and one-hot encoded car type, and the second between binned longitude and one-hot encoded car type.

**Respuesta de la fuente:** C

**Explicación:** To capture city-specific relationships, the model must combine geographic location (latitude and longitude) with car type in a single feature cross. Raw continuous values like latitude and longitude should be binned before crossing to prevent high cardinality and allow the model to learn non-linear spatial patterns effectively. Option C correctly bins both coordinates and one-hot encodes car type for a unified cross, whereas separate crosses (Option D) fail to represent the specific intersection of a city's unique coordinate pair with car preferences.

## Pregunta 44

Contexto: [topics:106](#topics-106)
You work for a large technology company that wants to modernize their contact center. You have been asked to develop a solution to classify incoming calls by product so that requests can be more quickly routed to the correct support team. You have already transcribed the calls using the Speech-to-Text API. You want to minimize data preprocessing and development time. How should you build the model?

**A.** Use the AI Platform Training built-in algorithms to create a custom model.

**B.** Use AutoMlL Natural Language to extract custom entities for classification.

**C.** Use the Cloud Natural Language API to extract custom entities for classification.

**D.** Build a custom model to identify the product keywords from the transcribed calls, and then run the keywords through a classification algorithm.

**Respuesta de la fuente:** B

**Explicación:** The Cloud Natural Language API (Option C) only supports a fixed set of entity types and does not allow for custom entity extraction or custom classification training. To classify calls by specific company products with minimal development time and preprocessing, AutoML Natural Language (Option B) is the correct choice as it allows you to train custom models on your specific data without writing code.

## Pregunta 45

Contexto: [topics:106](#topics-106)
You are training a TensorFlow model on a structured dataset with 100 billion records stored in several CSV files. You need to improve the input/output execution performance. What should you do?

**A.** Load the data into BigQuery, and read the data from BigQuery.

**B.** Load the data into Cloud Bigtable, and read the data from Bigtable.

**C.** Convert the CSV files into shards of TFRecords, and store the data in Cloud Storage.

**D.** Convert the CSV files into shards of TFRecords, and store the data in the Hadoop Distributed File System (HDFS).

**Respuesta de la fuente:** C

**Explicación:** TFRecords are TensorFlow's optimized binary format, which significantly reduces parsing overhead compared to CSV files, thereby improving I/O throughput.
Storing these shards in Cloud Storage provides scalable, high-performance access suitable for large-scale distributed training on Google Cloud Platform.

## Pregunta 46

Contexto: [topics:106](#topics-106)
As the lead ML Engineer for your company, you are responsible for building ML models to digitize scanned customer forms. You have developed a TensorFlow model that converts the scanned images into text and stores them in Cloud Storage. You need to use your ML model on the aggregated data collected at the end of each day with minimal manual intervention. What should you do?

**A.** Use the batch prediction functionality of AI Platform.

**B.** Create a serving pipeline in Compute Engine for prediction.

**C.** Use Cloud Functions for prediction each time a new data point is ingested.

**D.** Deploy the model on AI Platform and create a version of it for online inference.

**Respuesta de la fuente:** A

**Explicación:** The requirement to process aggregated data at the end of each day indicates a batch processing scenario rather than real-time online inference, making AI Platform Batch Prediction the appropriate service.
Additionally, using a fully managed service like AI Platform ensures minimal manual intervention compared to maintaining infrastructure on Compute Engine or Cloud Functions.

## Pregunta 47

Contexto: [topics:106](#topics-106)
You recently joined an enterprise-scale company that has thousands of datasets. You know that there are accurate descriptions for each table in BigQuery, and you are searching for the proper BigQuery table to use for a model you are building on AI Platform. How should you find the data that you need?

**A.** Use Data Catalog to search the BigQuery datasets by using keywords in the table description.

**B.** Tag each of your model and version resources on AI Platform with the name of the BigQuery table that was used for training.

**C.** Maintain a lookup table in BigQuery that maps the table descriptions to the table ID. Query the lookup table to find the correct table ID for the data that you need.

**D.** Execute a query in BigQuery to retrieve all the existing table names in your project using the INFORMATION_SCHEMA metadata tables that are native to BigQuery. Use the result o find the table that you need.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Data Catalog is the enterprise-grade metadata management service designed specifically to discover and organize data across large-scale environments.
It allows users to search for resources using tags, labels, and descriptions without needing to write SQL queries against INFORMATION_SCHEMA tables.
This makes it the most efficient method for finding specific BigQuery tables among thousands of datasets.

## Pregunta 48

Contexto: [topics:106](#topics-106)
You started working on a classification problem with time series data and achieved an area under the receiver operating characteristic curve (AUC ROC) value of
99% for training data after just a few experiments. You haven't explored using any sophisticated algorithms or spent any time on hyperparameter tuning. What should your next step be to identify and fix the problem?

**A.** Address the model overfitting by using a less complex algorithm.

**B.** Address data leakage by applying nested cross-validation during model training.

**C.** Address data leakage by removing features highly correlated with the target value.

**D.** Address the model overfitting by tuning the hyperparameters to reduce the AUC ROC value.

**Respuesta de la fuente:** B

**Explicación:** An unusually high AUC-ROC (99%) on training data with minimal effort strongly indicates data leakage rather than overfitting.
Removing features highly correlated with the target (Option C) is dangerous because legitimate, powerful predictors will also be highly correlated; you should remove features only if they contain information not available at prediction time, not simply based on correlation strength.
Nested cross-validation (Option B) is the correct next step to properly evaluate model performance and detect leakage by ensuring the validation set is strictly independent of the training process.

## Pregunta 49

Contexto: [topics:106](#topics-106)
You work for an online travel agency that also sells advertising placements on its website to other companies. You have been asked to predict the most relevant web banner that a user should see next. Security is important to your company. The model latency requirements are 300ms@p99, the inventory is thousands of web banners, and your exploratory analysis has shown that navigation context is a good predictor. You want to Implement the simplest solution. How should you configure the prediction pipeline?

**A.** Embed the client on the website, and then deploy the model on AI Platform Prediction.

**B.** Embed the client on the website, deploy the gateway on App Engine, and then deploy the model on AI Platform Prediction.

**C.** Embed the client on the website, deploy the gateway on App Engine, deploy the database on Cloud Bigtable for writing and for reading the user's navigation context, and then deploy the model on AI Platform Prediction.

**D.** Embed the client on the website, deploy the gateway on App Engine, deploy the database on Memorystore for writing and for reading the user's navigation context, and then deploy the model on Google Kubernetes Engine.

**Respuesta de la fuente:** C

**Explicación:** Option C is the correct choice because it satisfies all constraints: security (via the App Engine gateway protecting backend services), latency (Bigtable provides low-latency reads for navigation context to meet the 300ms p99 requirement), and simplicity (AI Platform Prediction simplifies model deployment compared to GKE). Option A lacks a secure gateway, B and D fail to explicitly handle the storage and retrieval of user navigation context required for prediction.

## Pregunta 50

Contexto: [topics:106](#topics-106)
Your team is building a convolutional neural network (CNN)-based architecture from scratch. The preliminary experiments running on your on-premises CPU-only infrastructure were encouraging, but have slow convergence. You have been asked to speed up model training to reduce time-to-market. You want to experiment with virtual machines (VMs) on Google Cloud to leverage more powerful hardware. Your code does not include any manual device placement and has not been wrapped in Estimator model-level abstraction. Which environment should you train your model on?

**A.** AVM on Compute Engine and 1 TPU with all dependencies installed manually.

**B.** AVM on Compute Engine and 8 GPUs with all dependencies installed manually.

**C.** A Deep Learning VM with an n1-standard-2 machine and 1 GPU with all libraries pre-installed.

**D.** A Deep Learning VM with more powerful CPU e2-highcpu-16 machines with all libraries pre-installed.

**Respuesta de la fuente:** C

**Explicación:** CNN training is computationally intensive and benefits significantly from GPU acceleration, making CPU-only options (D) inefficient despite the powerful CPU.
Using standard Compute Engine VMs requires manual dependency installation, which contradicts the goal of reducing time-to-market compared to Deep Learning VMs with pre-installed libraries.
Option C provides a GPU for accelerated training and pre-installed frameworks, addressing both performance speed and setup ease without requiring manual device placement code.

## Pregunta 51

Contexto: [topics:106](#topics-106)
You work on a growing team of more than 50 data scientists who all use AI Platform. You are designing a strategy to organize your jobs, models, and versions in a clean and scalable way. Which strategy should you choose?

**A.** Set up restrictive IAM permissions on the AI Platform notebooks so that only a single user or group can access a given instance.

**B.** Separate each data scientist's work into a different project to ensure that the jobs, models, and versions created by each data scientist are accessible only to that user.

**C.** Use labels to organize resources into descriptive categories. Apply a label to each created resource so that users can filter the results by label when viewing or monitoring the resources.

**D.** Set up a BigQuery sink for Cloud Logging logs that is appropriately filtered to capture information about AI Platform resource usage. In BigQuery, create a SQL view that maps users to the resources they are using

**Respuesta de la fuente:** C

**Explicación:** Labels are the recommended mechanism for organizing AI Platform resources (jobs, models, and versions) because they allow users to tag resources with key-value pairs for flexible filtering and monitoring without the administrative overhead of separate projects.
Option B is incorrect because creating a project per data scientist creates excessive management complexity, while Option A addresses access control rather than resource organization.

## Pregunta 52

Contexto: [topics:106](#topics-106)
You are training a deep learning model for semantic image segmentation with reduced training time. While using a Deep Learning VM Image, you receive the following error: The resource 'projects/deeplearning-platforn/zones/europe-west4-c/acceleratorTypes/nvidia-tesla-k80' was not found. What should you do?

**A.** Ensure that you have GPU quota in the selected region.

**B.** Ensure that the required GPU is available in the selected region.

**C.** Ensure that you have preemptible GPU quota in the selected region.

**D.** Ensure that the selected GPU has enough GPU memory for the workload.

**Respuesta de la fuente:** B

**Explicación:** The error message explicitly states that the accelerator type 'nvidia-tesla-k80' was not found in the specified zone, indicating a regional availability issue rather than a quota restriction. GPUs like the K80 are not available in all Google Cloud regions or zones; therefore, you must select a region where the specific GPU type is supported.

## Pregunta 53

Contexto: [topics:106](#topics-106)
Your team is working on an NLP research project to predict political affiliation of authors based on articles they have written. You have a large training dataset that is structured like this:
[Imagen: sin descripción]
You followed the standard 80%-10%-10% data distribution across the training, testing, and evaluation subsets. How should you distribute the training examples across the train-test-eval subsets while maintaining the 80-10-10 proportion?
Imagen · question_text · sin descripción
![Imagen original](imagenes/4410d686318e7deefc60.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
AuthorA:Political Party A
Textal:
Texta2:
AuthorB:Political Party B
TextBl
TextB2:
AuthorC:Political Party B
AuthorD:Political Party A
TextDl:
[Sentenceall,
[Sentencea21,
[SentenceB11,
[SentenceB21,
[Sentencecl1,
[Sentencec21,
[SentenceD11,
[Sentencep21,
SentenceAl2,
SentenceA22,
SentenceBl2,
SentenceB22,
SentenceCl2,
Sentencec22,
SentenceD12,
SentenceD22,
SentenceAl3,
Sentencea23,
SentenceB13,
SentenceB23,
SentenceC13,
Sentencec23,
SentenceD13,
SentenceD23,
```

**A.** Distribute texts randomly across the train-test-eval subsets: Train set: [TextA1, TextB2, ...] Test set: [TextA2, TextC1, TextD2, ...] Eval set: [TextB1, TextC2, TextD1, ...]

**B.** Distribute authors randomly across the train-test-eval subsets: (*) Train set: [TextA1, TextA2, TextD1, TextD2, ...] Test set: [TextB1, TextB2, ...] Eval set: [TexC1,TextC2 ...]

**C.** Distribute sentences randomly across the train-test-eval subsets: Train set: [SentenceA11, SentenceA21, SentenceB11, SentenceB21, SentenceC11, SentenceD21 ...] Test set: [SentenceA12, SentenceA22, SentenceB12, SentenceC22, SentenceC12, SentenceD22 ...] Eval set: [SentenceA13, SentenceA23, SentenceB13, SentenceC23, SentenceC13, SentenceD31 ...]

**D.** Distribute paragraphs of texts (i.e., chunks of consecutive sentences) across the train-test-eval subsets: Train set: [SentenceA11, SentenceA12, SentenceD11, SentenceD12 ...] Test set: [SentenceA13, SentenceB13, SentenceB21, SentenceD23, SentenceC12, SentenceD13 ...] Eval set: [SentenceA11, SentenceA22, SentenceB13, SentenceD22, SentenceC23, SentenceD11 ...]

**Respuesta de la fuente:** B

**Explicación:** The target label is the political affiliation of the **author**, not the individual text, paragraph, or sentence.
If you split by text, paragraph, or sentence (Options A, C, D), multiple examples from the same author will appear in both the training and testing sets. This causes data leakage because the model can learn specific stylistic features unique to that author rather than generalizable linguistic patterns of political affiliation.
To evaluate true generalization performance, you must split by the highest level of independence—the author—ensuring no author's data appears in more than one subset (Option B).

## Pregunta 54

Contexto: [topics:106](#topics-106)
Your team has been tasked with creating an ML solution in Google Cloud to classify support requests for one of your platforms. You analyzed the requirements and decided to use TensorFlow to build the classifier so that you have full control of the model's code, serving, and deployment. You will use Kubeflow pipelines for the ML platform. To save time, you want to build on existing resources and use managed services instead of building a completely new model. How should you build the classifier?

**A.** Use the Natural Language API to classify support requests.

**B.** Use AutoML Natural Language to build the support requests classifier.

**C.** Use an established text classification model on AI Platform to perform transfer learning.

**D.** Use an established text classification model on AI Platform as-is to classify support requests.

**Respuesta de la fuente:** C

**Explicación:** The requirement to use TensorFlow and maintain full control over the model's code eliminates fully managed APIs like Natural Language API (A) and AutoML (B), which are opaque black-box services.
While option D uses existing resources, it applies the model 'as-is,' which cannot correctly classify new support request categories without retraining.
Option C is correct because transfer learning allows you to fine-tune an established pre-trained TensorFlow model on your specific data, satisfying both the need for custom control and the efficiency of building on existing resources.

## Pregunta 55

Contexto: [topics:106](#topics-106)
You recently joined a machine learning team that will soon release a new project. As a lead on the project, you are asked to determine the production readiness of the ML components. The team has already tested features and data, model development, and infrastructure. Which additional readiness check should you recommend to the team?

**A.** Ensure that training is reproducible.

**B.** Ensure that all hyperparameters are tuned.

**C.** Ensure that model performance is monitored.

**D.** Ensure that feature expectations are captured in the schema.

**Respuesta de la fuente:** C

**Explicación:** The question states that model development (which includes ensuring reproducibility and hyperparameter tuning) has already been tested. Therefore, the remaining critical check for production readiness is establishing monitoring to detect data drift or performance degradation once the model is live.

## Pregunta 56

Contexto: [topics:106](#topics-106)
You work for a credit card company and have been asked to create a custom fraud detection model based on historical data using AutoML Tables. You need to prioritize detection of fraudulent transactions while minimizing false positives. Which optimization objective should you use when training the model?

**A.** An optimization objective that minimizes Log loss

**B.** An optimization objective that maximizes the Precision at a Recall value of 0.50

**C.** An optimization objective that maximizes the area under the precision-recall curve (AUC PR) value

**D.** An optimization objective that maximizes the area under the receiver operating characteristic curve (AUC ROC) value

**Respuesta de la fuente:** C

**Explicación:** Credit card fraud detection involves highly imbalanced data where the positive class (fraud) is rare. In such scenarios, AUC ROC can be misleadingly optimistic because it accounts for true negatives, which are abundant and dominate the metric.
AUC PR focuses on Precision and Recall, ignoring true negatives, making it the superior objective for maximizing detection of the minority class while controlling false positives.

## Pregunta 57

Contexto: [topics:106](#topics-106)
Your company manages a video sharing website where users can watch and upload videos. You need to create an ML model to predict which newly uploaded videos will be the most popular so that those videos can be prioritized on your company's website. Which result should you use to determine whether the model is successful?

**A.** The model predicts videos as popular if the user who uploads them has over 10,000 likes.

**B.** The model predicts 97.5% of the most popular clickbait videos measured by number of clicks.

**C.** The model predicts 95% of the most popular videos measured by watch time within 30 days of being uploaded.

**D.** The Pearson correlation coefficient between the log-transformed number of views after 7 days and 30 days after publication is equal to 0.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it defines model success using a clear, quantifiable business metric (popularity measured by watch time) with specific parameters (95% accuracy within 30 days).

In contrast, A relies on an arbitrary uploader threshold irrelevant to video content quality, B focuses on clickbait which is a negative user experience metric, and D describes a scenario of no correlation, indicating failure rather than success.

## Pregunta 58

Contexto: [topics:106](#topics-106)
You are working on a Neural Network-based project. The dataset provided to you has columns with different ranges. While preparing the data for model training, you discover that gradient optimization is having difficulty moving weights to a good solution. What should you do?

**A.** Use feature construction to combine the strongest features.

**B.** Use the representation transformation (normalization) technique.

**C.** Improve the data cleaning step by removing features with missing values.

**D.** Change the partitioning step to reduce the dimension of the test set and have a larger training set.

**Respuesta de la fuente:** B

**Explicación:** When features have significantly different ranges, gradient descent updates weights unevenly, causing slow convergence or oscillation. Normalization (feature scaling) brings all inputs to a similar scale, ensuring that the optimization algorithm can efficiently find the global minimum with consistent step sizes.

## Pregunta 59

Contexto: [topics:106](#topics-106)
Your data science team needs to rapidly experiment with various features, model architectures, and hyperparameters. They need to track the accuracy metrics for various experiments and use an API to query the metrics over time. What should they use to track and report their experiments while minimizing manual effort?

**A.** Use Kubeflow Pipelines to execute the experiments. Export the metrics file, and query the results using the Kubeflow Pipelines API.

**B.** Use AI Platform Training to execute the experiments. Write the accuracy metrics to BigQuery, and query the results using the BigQuery API.

**C.** Use AI Platform Training to execute the experiments. Write the accuracy metrics to Cloud Monitoring, and query the results using the Monitoring API.

**D.** Use AI Platform Notebooks to execute the experiments. Collect the results in a shared Google Sheets file, and query the results using the Google Sheets API.

**Respuesta de la fuente:** A

**Explicación:** Kubeflow Pipelines provides built-in support for experiment tracking and metric export via its SDK, allowing users to log metrics directly during pipeline execution.
This native integration minimizes manual effort compared to writing custom code to send data to BigQuery or Cloud Monitoring, while avoiding the scalability limitations of Google Sheets.

## Pregunta 60

Contexto: [topics:106](#topics-106)
You work for a bank and are building a random forest model for fraud detection. You have a dataset that includes transactions, of which 1% are identified as fraudulent. Which data transformation strategy would likely improve the performance of your classifier?

**A.** Write your data in TFRecords.

**B.** Z-normalize all the numeric features.

**C.** Oversample the fraudulent transaction 10 times.

**D.** Use one-hot encoding on all categorical features.

**Respuesta de la fuente:** C

**Explicación:** The dataset exhibits severe class imbalance, with only 1% of transactions being fraudulent. Oversampling the minority class (fraud) balances the data distribution, allowing the random forest model to learn distinguishing features of fraud rather than ignoring it as noise.

## Pregunta 61

Contexto: [topics:106](#topics-106)
You are using transfer learning to train an image classifier based on a pre-trained EfficientNet model. Your training dataset has 20,000 images. You plan to retrain the model once per day. You need to minimize the cost of infrastructure. What platform components and configuration environment should you use?

**A.** A Deep Learning VM with 4 V100 GPUs and local storage.

**B.** A Deep Learning VM with 4 V100 GPUs and Cloud Storage.

**C.** A Google Kubernetes Engine cluster with a V100 GPU Node Pool and an NFS Server

**D.** An AI Platform Training job using a custom scale tier with 4 V100 GPUs and Cloud Storage

**Respuesta de la fuente:** D

**Explicación:** AI Platform Training (now Vertex AI) is a fully managed service designed for batch training jobs, offering better cost efficiency than always-on VMs or complex GKE clusters for this workload. Using Cloud Storage eliminates the overhead and performance bottlenecks associated with local disk management or NFS syncing for large datasets. This configuration minimizes infrastructure costs by avoiding manual cluster management while ensuring scalable, reliable data access.

## Pregunta 62

Contexto: [topics:106](#topics-106)
While conducting an exploratory analysis of a dataset, you discover that categorical feature A has substantial predictive power, but it is sometimes missing. What should you do?

**A.** Drop feature A if more than 15% of values are missing. Otherwise, use feature A as-is.

**B.** Compute the mode of feature A and then use it to replace the missing values in feature A.

**C.** Replace the missing values with the values of the feature with the highest Pearson correlation with feature A.

**D.** Add an additional class to categorical feature A for missing values. Create a new binary feature that indicates whether feature A is missing.

**Respuesta de la fuente:** D

**Explicación:** Dropping a high-predictive-power feature (A) is suboptimal as it discards valuable information. Mode imputation (B) can introduce bias and mask the fact that data is missing, potentially distorting the feature's distribution. Replacing with values from a correlated feature (C) is technically unsound for categorical data and introduces noise. Adding a dedicated missing category (D) explicitly preserves the missingness pattern, allowing the model to learn distinct behaviors for known vs. unknown values without losing predictive power.

## Pregunta 63

Contexto: [topics:106](#topics-106)
You work for a large retailer and have been asked to segment your customers by their purchasing habits. The purchase history of all customers has been uploaded to BigQuery. You suspect that there may be several distinct customer segments, however you are unsure of how many, and you don’t yet understand the commonalities in their behavior. You want to find the most efficient solution. What should you do?

**A.** Create a k-means clustering model using BigQuery ML. Allow BigQuery to automatically optimize the number of clusters.

**B.** Create a new dataset in Dataprep that references your BigQuery table. Use Dataprep to identify similarities within each column.

**C.** Use the Data Labeling Service to label each customer record in BigQuery. Train a model on your labeled data using AutoML Tables. Review the evaluation metrics to understand whether there is an underlying pattern in the data.

**D.** Get a list of the customer segments from your company’s Marketing team. Use the Data Labeling Service to label each customer record in BigQuery according to the list. Analyze the distribution of labels in your dataset using Data Studio.

**Respuesta de la fuente:** A

**Explicación:** The scenario describes an unsupervised learning problem where the number of clusters is unknown and labels are absent, making K-means clustering in BigQuery ML the ideal choice.
BigQuery ML allows for efficient analysis directly on the existing data without the overhead of moving data to Dataprep or manually labeling records via Data Labeling Service.

## Pregunta 64

Contexto: [topics:106](#topics-106)
You recently designed and built a custom neural network that uses critical dependencies specific to your organization’s framework. You need to train the model using a managed training service on Google Cloud. However, the ML framework and related dependencies are not supported by AI Platform Training. Also, both your model and your data are too large to fit in memory on a single machine. Your ML framework of choice uses the scheduler, workers, and servers distribution structure. What should you do?

**A.** Use a built-in model available on AI Platform Training.

**B.** Build your custom container to run jobs on AI Platform Training.

**C.** Build your custom containers to run distributed training jobs on AI Platform Training.

**D.** Reconfigure your code to a ML framework with dependencies that are supported by AI Platform Training.

**Respuesta de la fuente:** C

**Explicación:** Since the organization's ML framework and dependencies are not supported by AI Platform Training, a custom container is required to encapsulate these specific binaries and libraries. Additionally, because the model and data exceed the memory capacity of a single machine, distributed training is necessary to partition the workload across multiple workers.

## Pregunta 65

Contexto: [topics:106](#topics-106)
While monitoring your model training’s GPU utilization, you discover that you have a native synchronous implementation. The training data is split into multiple files. You want to reduce the execution time of your input pipeline. What should you do?

**A.** Increase the CPU load

**B.** Add caching to the pipeline

**C.** Increase the network bandwidth

**D.** Add parallel interleave to the pipeline

**Respuesta de la fuente:** D

**Explicación:** The input pipeline bottleneck arises from a native synchronous implementation that processes one file at a time, leaving the GPU idle while waiting for data.
Adding parallel interleave allows the system to prefetch and process multiple files concurrently, effectively overlapping I/O operations with computation.
This parallelism increases throughput and reduces overall execution time by keeping the GPU utilization high.

## Pregunta 66

Contexto: [topics:106](#topics-106)
Your data science team is training a PyTorch model for image classification based on a pre-trained RestNet model. You need to perform hyperparameter tuning to optimize for several parameters. What should you do?

**A.** Convert the model to a Keras model, and run a Keras Tuner job.

**B.** Run a hyperparameter tuning job on AI Platform using custom containers.

**C.** Create a Kuberflow Pipelines instance, and run a hyperparameter tuning job on Katib.

**D.** Convert the model to a TensorFlow model, and run a hyperparameter tuning job on AI Platform.

**Respuesta de la fuente:** B

**Explicación:** Vertex AI (formerly AI Platform) supports hyperparameter tuning for custom containers, allowing you to train PyTorch models without converting them to TensorFlow or Keras.
Converting frameworks (Options A and D) adds unnecessary complexity and potential performance overhead, while Option C introduces Kubernetes-level infrastructure management that is not required for standard hyperparameter tuning on GCP.
Therefore, running the job using custom containers on Vertex AI is the most direct and supported approach.

## Pregunta 67

Contexto: [topics:106](#topics-106)
You have a large corpus of written support cases that can be classified into 3 separate categories: Technical Support, Billing Support, or Other Issues. You need to quickly build, test, and deploy a service that will automatically classify future written requests into one of the categories. How should you configure the pipeline?

**A.** Use the Cloud Natural Language API to obtain metadata to classify the incoming cases.

**B.** Use AutoML Natural Language to build and test a classifier. Deploy the model as a REST API.

**C.** Use BigQuery ML to build and test a logistic regression model to classify incoming requests. Use BigQuery ML to perform inference.

**D.** Create a TensorFlow model using Google’s BERT pre-trained model. Build and test a classifier, and deploy the model using Vertex AI.

**Respuesta de la fuente:** B

**Explicación:** AutoML Natural Language is the optimal choice because it automates the model training process, allowing you to quickly build and test a custom classifier without requiring deep machine learning expertise. It natively supports deploying the trained model as a REST API, which directly satisfies the requirement for rapid deployment and integration with incoming support requests.

## Pregunta 68

Contexto: [topics:106](#topics-106)
You need to quickly build and train a model to predict the sentiment of customer reviews with custom categories without writing code. You do not have enough data to train a model from scratch. The resulting model should have high predictive performance. Which service should you use?

**A.** AutoML Natural Language

**B.** Cloud Natural Language API

**C.** AI Hub pre-made Jupyter Notebooks

**D.** AI Platform Training built-in algorithms

**Respuesta de la fuente:** A

**Explicación:** AutoML Natural Language is the correct choice because it allows for custom category classification without writing code and leverages transfer learning to train effective models on small datasets. Cloud Natural Language API only provides generic sentiment scores, not custom categories, while options C and D require coding expertise.

## Pregunta 69

Contexto: [topics:106](#topics-106)
You need to build an ML model for a social media application to predict whether a user’s submitted profile photo meets the requirements. The application will inform the user if the picture meets the requirements. How should you build a model to ensure that the application does not falsely accept a non-compliant picture?

**A.** Use AutoML to optimize the model’s recall in order to minimize false negatives.

**B.** Use AutoML to optimize the model’s F1 score in order to balance the accuracy of false positives and false negatives.

**C.** Use Vertex AI Workbench user-managed notebooks to build a custom model that has three times as many examples of pictures that meet the profile photo requirements.

**D.** Use Vertex AI Workbench user-managed notebooks to build a custom model that has three times as many examples of pictures that do not meet the profile photo requirements.

**Respuesta de la fuente:** A

**Explicación:** The goal is to prevent 'false acceptance' of non-compliant images. If we define the positive class as 'compliant', a false negative is a compliant image rejected by the system, which is not the concern. However, in ML certification contexts for this specific question pattern, 'positive' often refers to the event of interest or violation. Let's re-evaluate based on standard definitions:

If Positive = Compliant Image:
- True Positive: Compliant accepted.
- False Negative: Compliant rejected (bad for user experience, but not the stated goal).
- False Positive: Non-compliant accepted (This is the error we want to avoid).
- To minimize False Positives, we need high Precision. Optimizing Recall does not guarantee low False Positives; it guarantees finding all positives.

If Positive = Non-Compliant Image (Violation):
- True Positive: Non-compliant rejected.
- False Negative: Non-compliant accepted (This is the error we want to avoid).
- To minimize False Negatives, we need high Recall. The model must catch *all* non-compliant images.

The question states: "ensure that the application does not falsely accept a non-compliant picture." This means we want to minimize cases where a non-compliant picture is missed by the filter. In fraud detection or safety-critical contexts, the 'bad' event is often the positive class for optimization purposes. If we treat 'Non-Compliant' as the Positive class, then falsely accepting one is a False Negative. Minimizing False Negatives requires optimizing for Recall.

Therefore, Option A is correct because it optimizes Recall to ensure almost all non-compliant (positive) images are detected and rejected.

## Pregunta 70

Contexto: [topics:106](#topics-106)
You lead a data science team at a large international corporation. Most of the models your team trains are large-scale models using high-level TensorFlow APIs on AI Platform with GPUs. Your team usually takes a few weeks or months to iterate on a new version of a model. You were recently asked to review your team’s spending. How should you reduce your Google Cloud compute costs without impacting the model’s performance?

**A.** Use AI Platform to run distributed training jobs with checkpoints.

**B.** Use AI Platform to run distributed training jobs without checkpoints.

**C.** Migrate to training with Kuberflow on Google Kubernetes Engine, and use preemptible VMs with checkpoints.

**D.** Migrate to training with Kuberflow on Google Kubernetes Engine, and use preemptible VMs without checkpoints.

**Respuesta de la fuente:** C

**Explicación:** Preemptible VMs offer significant cost reductions compared to standard VMs, making them ideal for reducing compute costs. However, since preemptible VMs can be terminated with short notice, training jobs must utilize checkpoints to save progress and resume from the last saved state without losing performance or starting over.

## Pregunta 71

Contexto: [topics:106](#topics-106)
You need to train a regression model based on a dataset containing 50,000 records that is stored in BigQuery. The data includes a total of 20 categorical and numerical features with a target variable that can include negative values. You need to minimize effort and training time while maximizing model performance. What approach should you take to train this regression model?

**A.** Create a custom TensorFlow DNN model

**B.** Use BQML XGBoost regression to train the model.

**C.** Use AutoML Tables to train the model without early stopping.

**D.** Use AutoML Tables to train the model with RMSLE as the optimization objective.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because BigQuery ML (BQML) XGBoost allows training directly via SQL within BigQuery, minimizing data movement and setup effort compared to custom TensorFlow models.
It handles regression tasks effectively with mixed feature types, aligning with the goal of maximizing performance while minimizing time.
Option C is incorrect because disabling early stopping increases training duration, violating the constraint to minimize training time.
Option D is invalid because RMSLE requires non-negative target values, but the dataset includes negative targets.

## Pregunta 72

Contexto: [topics:106](#topics-106)
You are building a linear model with over 100 input features, all with values between –1 and 1. You suspect that many features are non-informative. You want to remove the non-informative features from your model while keeping the informative ones in their original form. Which technique should you use?

**A.** Use principal component analysis (PCA) to eliminate the least informative features.

**B.** Use L1 regularization to reduce the coefficients of uninformative features to 0.

**C.** After building your model, use Shapley values to determine which features are the most informative.

**D.** Use an iterative dropout technique to identify which features do not degrade the model when removed.

**Respuesta de la fuente:** B

**Explicación:** L1 regularization (Lasso) induces sparsity by driving the coefficients of non-informative features to exactly zero, effectively performing feature selection. This satisfies the requirement to remove uninformative features while retaining the original form of the remaining informative features, unlike PCA which creates new transformed variables.

## Pregunta 73

Contexto: [topics:106](#topics-106)
You work for a global footwear retailer and need to predict when an item will be out of stock based on historical inventory data Customer behavior is highly dynamic since footwear demand is influenced by many different factors. You want to serve models that are trained on all available data, but track your performance on specific subsets of data before pushing to production. What is the most streamlined and reliable way to perform this validation?

**A.** Use then TFX ModelValidator tools to specify performance metrics for production readiness.

**B.** Use k-fold cross-validation as a validation strategy to ensure that your model is ready for production.

**C.** Use the last relevant week of data as a validation set to ensure that your model is performing accurately on current data.

**D.** Use the entire dataset and treat the area under the receiver operating characteristics curve (AUC ROC) as the main metric.

**Respuesta de la fuente:** A

**Explicación:** The question requires a streamlined way to validate model performance on specific subsets before production deployment. TFX ModelValidator is explicitly designed for this purpose, allowing users to define validation specifications and thresholds for different slices of data.
Option C is incorrect because using only one week of data lacks statistical significance for generalization, while Option B (k-fold) violates temporal integrity in time-series forecasting.

## Pregunta 74

Contexto: [topics:106](#topics-106)
You have deployed a model on Vertex AI for real-time inference. During an online prediction request, you get an “Out of Memory” error. What should you do?

**A.** Use batch prediction mode instead of online mode.

**B.** Send the request again with a smaller batch of instances.

**C.** Use base64 to encode your data before using it for prediction.

**D.** Apply for a quota increase for the number of prediction requests.

**Respuesta de la fuente:** B

**Explicación:** An 'Out of Memory' error during online prediction typically indicates that the payload size exceeds the memory limits of the serving container for a single request.
Reducing the number of instances per request (batch size) lowers the memory footprint required to process that specific prediction, resolving the error.
Batch prediction (A) is unsuitable for real-time use cases, while encoding (C) or quota increases (D) do not address resource exhaustion during inference.

## Pregunta 75

Contexto: [topics:106](#topics-106)
You work at a subscription-based company. You have trained an ensemble of trees and neural networks to predict customer churn, which is the likelihood that customers will not renew their yearly subscription. The average prediction is a 15% churn rate, but for a particular customer the model predicts that they are 70% likely to churn. The customer has a product usage history of 30%, is located in New York City, and became a customer in 1997. You need to explain the difference between the actual prediction, a 70% churn rate, and the average prediction. You want to use Vertex Explainable AI. What should you do?

**A.** Train local surrogate models to explain individual predictions.

**B.** Configure sampled Shapley explanations on Vertex Explainable AI.

**C.** Configure integrated gradients explanations on Vertex Explainable AI.

**D.** Measure the effect of each feature as the weight of the feature multiplied by the feature value.

**Respuesta de la fuente:** B

**Explicación:** The model is an ensemble of trees and neural networks, which classifies as a non-differentiable or complex ensemble model. Vertex AI documentation explicitly recommends Sampled Shapley for explaining individual predictions in such ensembles, whereas Integrated Gradients are designed for differentiable neural networks. Therefore, configuring Sampled Shapley provides the correct attribution values to explain the deviation from the average prediction.

## Pregunta 76

Contexto: [topics:106](#topics-106)
You are working on a classification problem with time series data. After conducting just a few experiments using random cross-validation, you achieved an Area Under the Receiver Operating Characteristic Curve (AUC ROC) value of 99% on the training data. You haven’t explored using any sophisticated algorithms or spent any time on hyperparameter tuning. What should your next step be to identify and fix the problem?

**A.** Address the model overfitting by using a less complex algorithm and use k-fold cross-validation.

**B.** Address data leakage by applying nested cross-validation during model training.

**C.** Address data leakage by removing features highly correlated with the target value.

**D.** Address the model overfitting by tuning the hyperparameters to reduce the AUC ROC value.

**Respuesta de la fuente:** B

**Explicación:** Using random cross-validation on time series data breaks temporal dependencies, allowing future information to leak into the training set and causing unrealistically high performance. Nested cross-validation is the correct approach to properly validate time series models while preventing data leakage.

## Pregunta 77

Contexto: [topics:106](#topics-106)
You need to execute a batch prediction on 100 million records in a BigQuery table with a custom TensorFlow DNN regressor model, and then store the predicted results in a BigQuery table. You want to minimize the effort required to build this inference pipeline. What should you do?

**A.** Import the TensorFlow model with BigQuery ML, and run the ml.predict function.

**B.** Use the TensorFlow BigQuery reader to load the data, and use the BigQuery API to write the results to BigQuery.

**C.** Create a Dataflow pipeline to convert the data in BigQuery to TFRecords. Run a batch inference on Vertex AI Prediction, and write the results to BigQuery.

**D.** Load the TensorFlow SavedModel in a Dataflow pipeline. Use the BigQuery I/O connector with a custom function to perform the inference within the pipeline, and write the results to BigQuery.

**Respuesta de la fuente:** A

**Explicación:** BigQuery ML allows you to import custom TensorFlow models (in SavedModel format) and perform batch predictions directly using the ML.PREDICT function.
This approach eliminates the need to build external data pipelines with Dataflow or Vertex AI, thereby minimizing development effort as requested.

## Pregunta 78

Contexto: [topics:106](#topics-106)
You are creating a deep neural network classification model using a dataset with categorical input values. Certain columns have a cardinality greater than 10,000 unique values. How should you encode these categorical values as input into the model?

**A.** Convert each categorical value into an integer value.

**B.** Convert the categorical string data to one-hot hash buckets.

**C.** Map the categorical variables into a vector of boolean values.

**D.** Convert each categorical value into a run-length encoded string.

**Respuesta de la fuente:** B

**Explicación:** For categorical features with high cardinality (e.g., >10,000 unique values), standard one-hot encoding creates an excessively wide sparse vector that is computationally inefficient and prone to overfitting. Hashing into buckets (Option B) maps these numerous categories into a fixed number of features using a hash function, effectively reducing dimensionality while preserving the ability of the model to learn patterns from the categorical data without implying ordinal relationships.

## Pregunta 79

Contexto: [topics:106](#topics-106)
You need to train a natural language model to perform text classification on product descriptions that contain millions of examples and 100,000 unique words. You want to preprocess the words individually so that they can be fed into a recurrent neural network. What should you do?

**A.** Create a hot-encoding of words, and feed the encodings into your model.

**B.** Identify word embeddings from a pre-trained model, and use the embeddings in your model.

**C.** Sort the words by frequency of occurrence, and use the frequencies as the encodings in your model.

**D.** Assign a numerical value to each word from 1 to 100,000 and feed the values as inputs in your model.

**Respuesta de la fuente:** B

**Explicación:** Word embeddings (Option B) are the standard preprocessing technique for feeding text into recurrent neural networks because they convert words into dense, low-dimensional vectors that capture semantic meaning and context. Unlike one-hot encoding (Option A), which creates sparse, high-dimensional inputs inefficient for large vocabularies, or simple integer mapping (Option D), which lacks semantic information, embeddings allow the model to learn relationships between words effectively.

## Pregunta 80

Contexto: [topics:106](#topics-106)
You work for an online travel agency that also sells advertising placements on its website to other companies. You have been asked to predict the most relevant web banner that a user should see next. Security is important to your company. The model latency requirements are 300ms@p99, the inventory is thousands of web banners, and your exploratory analysis has shown that navigation context is a good predictor. You want to Implement the simplest solution. How should you configure the prediction pipeline?

**A.** Embed the client on the website, and then deploy the model on AI Platform Prediction.

**B.** Embed the client on the website, deploy the gateway on App Engine, deploy the database on Firestore for writing and for reading the user’s navigation context, and then deploy the model on AI Platform Prediction.

**C.** Embed the client on the website, deploy the gateway on App Engine, deploy the database on Cloud Bigtable for writing and for reading the user’s navigation context, and then deploy the model on AI Platform Prediction.

**D.** Embed the client on the website, deploy the gateway on App Engine, deploy the database on Memorystore for writing and for reading the user’s navigation context, and then deploy the model on Google Kubernetes Engine.

**Respuesta de la fuente:** C

**Explicación:** The requirement for the 'simplest solution' points to AI Platform Prediction (now Vertex AI) rather than GKE, as it is a fully managed service requiring less infrastructure overhead.
Regarding data storage, Cloud Bigtable is preferred over Firestore here because it is specifically designed for low-latency, high-throughput read/write operations necessary for real-time navigation context tracking.
Although Firestore is simpler to set up generally, Bigtable's performance characteristics align better with the strict 300ms p99 latency constraint in a prediction pipeline context.

## Pregunta 81

Contexto: [topics:106](#topics-106)
Your data science team has requested a system that supports scheduled model retraining, Docker containers, and a service that supports autoscaling and monitoring for online prediction requests. Which platform components should you choose for this system?

**A.** Vertex AI Pipelines and App Engine

**B.** Vertex AI Pipelines, Vertex AI Prediction, and Vertex AI Model Monitoring

**C.** Cloud Composer, BigQuery ML, and Vertex AI Prediction

**D.** Cloud Composer, Vertex AI Training with custom containers, and App Engine

**Respuesta de la fuente:** B

**Explicación:** Vertex AI Pipelines provides the orchestration and scheduling capabilities required for model retraining workflows. Vertex AI Prediction handles online prediction with built-in autoscaling, while Vertex AI Model Monitoring ensures the system meets the monitoring requirements. Option B is the only choice that consolidates all these specific ML lifecycle needs within the Vertex AI ecosystem.

## Pregunta 82

Contexto: [topics:106](#topics-106)
You are profiling the performance of your TensorFlow model training time and notice a performance issue caused by inefficiencies in the input data pipeline for a single 5 terabyte CSV file dataset on Cloud Storage. You need to optimize the input pipeline performance. Which action should you try first to increase the efficiency of your pipeline?

**A.** Preprocess the input CSV file into a TFRecord file.

**B.** Randomly select a 10 gigabyte subset of the data to train your model.

**C.** Split into multiple CSV files and use a parallel interleave transformation.

**D.** Set the reshuffle_each_iteration parameter to true in the tf.data.Dataset.shuffle method.

**Respuesta de la fuente:** C

**Explicación:** A single large file creates a serialization bottleneck because only one worker can read it at a time, preventing parallelization. Splitting the data into multiple files allows `tf.data.Dataset` to use parallel interleaving, enabling multiple workers to read and process shards simultaneously for immediate I/O throughput gains. Converting to TFRecord (Option A) is a more invasive format change that should be attempted only after verifying that file-level parallelism does not resolve the bottleneck.

## Pregunta 83

Contexto: [topics:106](#topics-106)
You need to design an architecture that serves asynchronous predictions to determine whether a particular mission-critical machine part will fail. Your system collects data from multiple sensors from the machine. You want to build a model that will predict a failure in the next N minutes, given the average of each sensor’s data from the past 12 hours. How should you design the architecture?

**A.** 1. HTTP requests are sent by the sensors to your ML model, which is deployed as a microservice and exposes a REST API for prediction
2. Your application queries a Vertex AI endpoint where you deployed your model.
3. Responses are received by the caller application as soon as the model produces the prediction.

**B.** 1. Events are sent by the sensors to Pub/Sub, consumed in real time, and processed by a Dataflow stream processing pipeline.
2. The pipeline invokes the model for prediction and sends the predictions to another Pub/Sub topic.
3. Pub/Sub messages containing predictions are then consumed by a downstream system for monitoring.

**C.** 1. Export your data to Cloud Storage using Dataflow.
2. Submit a Vertex AI batch prediction job that uses your trained model in Cloud Storage to perform scoring on the preprocessed data.
3. Export the batch prediction job outputs from Cloud Storage and import them into Cloud SQL.

**D.** 1. Export the data to Cloud Storage using the BigQuery command-line tool
2. Submit a Vertex AI batch prediction job that uses your trained model in Cloud Storage to perform scoring on the preprocessed data.
3. Export the batch prediction job outputs from Cloud Storage and import them into BigQuery.

**Respuesta de la fuente:** B

**Explicación:** The question requires an asynchronous architecture for near-real-time predictive maintenance using sliding window aggregates (12-hour averages).
Option B correctly implements this by using Pub/Sub and Dataflow to ingest sensor streams, compute the required rolling averages, and invoke the model asynchronously.
This decouples ingestion from prediction, ensuring low latency without blocking sensors, which aligns with Google Cloud best practices for online/streaming predictive maintenance.
Options A is synchronous (REST API), while C and D represent batch processing, which introduces unnecessary latency for minute-level failure predictions.

## Pregunta 84

Contexto: [topics:106](#topics-106)
Your company manages an application that aggregates news articles from many different online sources and sends them to users. You need to build a recommendation model that will suggest articles to readers that are similar to the articles they are currently reading. Which approach should you use?

**A.** Create a collaborative filtering system that recommends articles to a user based on the user’s past behavior.

**B.** Encode all articles into vectors using word2vec, and build a model that returns articles based on vector similarity.

**C.** Build a logistic regression model for each user that predicts whether an article should be recommended to a user.

**D.** Manually label a few hundred articles, and then train an SVM classifier based on the manually classified articles that categorizes additional articles into their respective categories.

**Respuesta de la fuente:** B

**Explicación:** The requirement is to find articles similar to the one currently being read, which necessitates content-based filtering rather than collaborative filtering. Word2vec encodes text into vector representations that capture semantic meaning, allowing for direct similarity comparisons between documents based on their content. Collaborative filtering (A) relies on historical user interaction data, which does not directly address immediate content similarity or handle the 'cold start' problem effectively in this context.

## Pregunta 85

Contexto: [topics:106](#topics-106)
You work for a large social network service provider whose users post articles and discuss news. Millions of comments are posted online each day, and more than 200 human moderators constantly review comments and flag those that are inappropriate. Your team is building an ML model to help human moderators check content on the platform. The model scores each comment and flags suspicious comments to be reviewed by a human. Which metric(s) should you use to monitor the model’s performance?

**A.** Number of messages flagged by the model per minute

**B.** Number of messages flagged by the model per minute confirmed as being inappropriate by humans.

**C.** Precision and recall estimates based on a random sample of 0.1% of raw messages each minute sent to a human for review

**D.** Precision and recall estimates based on a sample of messages flagged by the model as potentially inappropriate each minute

**Respuesta de la fuente:** D

**Explicación:** To calculate Precision and Recall effectively in a highly imbalanced dataset (where inappropriate content is rare), sampling only from the flagged results (Option D) provides a robust estimate of Precision with manageable human review costs. Option C's random sample of raw messages is statistically likely to miss enough positive instances to yield unreliable Recall estimates, while Options A and B provide incomplete metrics lacking False Negatives or False Positives.

## Pregunta 86

Contexto: [topics:106](#topics-106)
You are a lead ML engineer at a retail company. You want to track and manage ML metadata in a centralized way so that your team can have reproducible experiments by generating artifacts. Which management solution should you recommend to your team?

**A.** Store your tf.logging data in BigQuery.

**B.** Manage all relational entities in the Hive Metastore.

**C.** Store all ML metadata in Google Cloud’s operations suite.

**D.** Manage your ML workflows with Vertex ML Metadata.

**Respuesta de la fuente:** D

**Explicación:** Vertex ML Metadata is the specific Google Cloud service designed for recording, tracking, and managing metadata artifacts from ML experiments to ensure reproducibility.
It provides a centralized repository for experiment parameters, metrics, and model lineage, unlike BigQuery (data storage), Hive Metastore (tabular data schema), or Cloud Operations Suite (infrastructure monitoring).

## Pregunta 87

Contexto: [topics:106](#topics-106)
You have been given a dataset with sales predictions based on your company’s marketing activities. The data is structured and stored in BigQuery, and has been carefully managed by a team of data analysts. You need to prepare a report providing insights into the predictive capabilities of the data. You were asked to run several ML models with different levels of sophistication, including simple models and multilayered neural networks. You only have a few hours to gather the results of your experiments. Which Google Cloud tools should you use to complete this task in the most efficient and self-serviced way?

**A.** Use BigQuery ML to run several regression models, and analyze their performance.

**B.** Read the data from BigQuery using Dataproc, and run several models using SparkML.

**C.** Use Vertex AI Workbench user-managed notebooks with scikit-learn code for a variety of ML algorithms and performance metrics.

**D.** Train a custom TensorFlow model with Vertex AI, reading the data from BigQuery featuring a variety of ML algorithms.

**Respuesta de la fuente:** A

**Explicación:** BigQuery ML is the most efficient choice because the data is already stored in BigQuery, eliminating the time-consuming step of exporting or reading data into external environments.
It supports a variety of model types, including linear regression and Deep Neural Networks (DNNs), allowing you to run different levels of sophistication using simple SQL commands within the few hours available.

## Pregunta 88

Contexto: [topics:106](#topics-106)
You are an ML engineer at a bank. You have developed a binary classification model using AutoML Tables to predict whether a customer will make loan payments on time. The output is used to approve or reject loan requests. One customer’s loan request has been rejected by your model, and the bank’s risks department is asking you to provide the reasons that contributed to the model’s decision. What should you do?

**A.** Use local feature importance from the predictions.

**B.** Use the correlation with target values in the data summary page.

**C.** Use the feature importance percentages in the model evaluation page.

**D.** Vary features independently to identify the threshold per feature that changes the classification.

**Respuesta de la fuente:** A

**Explicación:** The question requires explaining the decision for a single specific prediction (one customer's loan request), which necessitates local interpretability rather than global model statistics.

In AutoML Tables, "Explain Predictions" provides Local Feature Importance, quantifying exactly how each feature contributed to that specific outcome, making it the correct tool for this use case.

Global feature importance (Option C) describes overall model behavior but cannot explain individual predictions.

## Pregunta 89

Contexto: [topics:106](#topics-106)
You work for a magazine distributor and need to build a model that predicts which customers will renew their subscriptions for the upcoming year. Using your company’s historical data as your training set, you created a TensorFlow model and deployed it to AI Platform. You need to determine which customer attribute has the most predictive power for each prediction served by the model. What should you do?

**A.** Use AI Platform notebooks to perform a Lasso regression analysis on your model, which will eliminate features that do not provide a strong signal.

**B.** Stream prediction results to BigQuery. Use BigQuery’s CORR(X1, X2) function to calculate the Pearson correlation coefficient between each feature and the target variable.

**C.** Use the AI Explanations feature on AI Platform. Submit each prediction request with the ‘explain’ keyword to retrieve feature attributions using the sampled Shapley method.

**D.** Use the What-If tool in Google Cloud to determine how your model will perform when individual features are excluded. Rank the feature importance in order of those that caused the most significant performance drop when removed from the model.

**Respuesta de la fuente:** C

**Explicación:** The question specifically requires determining predictive power for *each prediction served*, which is the exact use case for Vertex AI Explainable AI (AI Explanations).
By submitting a prediction request with the 'explain' keyword, the service returns feature attributions using the sampled Shapley method, indicating how much each input feature contributed to that specific model output.
Other options like correlation analysis or What-If tool provide broader model-level insights or historical analyses rather than per-prediction feature importance.

## Pregunta 90

Contexto: [topics:106](#topics-106)
You are working on a binary classification ML algorithm that detects whether an image of a classified scanned document contains a company’s logo. In the dataset, 96% of examples don’t have the logo, so the dataset is very skewed. Which metrics would give you the most confidence in your model?

**A.** F-score where recall is weighed more than precision

**B.** RMSE

**C.** F1 score

**D.** F-score where precision is weighed more than recall

**Respuesta de la fuente:** A

**Explicación:** In highly imbalanced classification tasks, missing positive instances (low recall) is often more critical than false alarms because the minority class is sparse and easy to ignore. By weighting recall more than precision in the F-score (F-beta with beta > 1), the metric penalizes the model heavily for failing to detect the rare logos, which aligns with the goal of ensuring sensitive detection in skewed datasets.

## Pregunta 91

Contexto: [topics:106](#topics-106)
You work on the data science team for a multinational beverage company. You need to develop an ML model to predict the company’s profitability for a new line of naturally flavored bottled waters in different locations. You are provided with historical data that includes product types, product sales volumes, expenses, and profits for all regions. What should you use as the input and output for your model?

**A.** Use latitude, longitude, and product type as features. Use profit as model output.

**B.** Use latitude, longitude, and product type as features. Use revenue and expenses as model outputs.

**C.** Use product type and the feature cross of latitude with longitude, followed by binning, as features. Use profit as model output.

**D.** Use product type and the feature cross of latitude with longitude, followed by binning, as features. Use revenue and expenses as model outputs.

**Respuesta de la fuente:** C

**Explicación:** The objective is to predict profitability, which corresponds directly to the 'profits' column in the provided dataset, making profit the correct output label. Raw latitude and longitude coordinates are continuous values that must be bucketized (binned) before being crossed to create meaningful interaction features representing specific geographic regions. Option C correctly identifies profit as the target and applies feature engineering techniques (feature crossing with binning) suitable for spatial data.

## Pregunta 92

Contexto: [topics:106](#topics-106)
You work as an ML engineer at a social media company, and you are developing a visual filter for users’ profile photos. This requires you to train an ML model to detect bounding boxes around human faces. You want to use this filter in your company’s iOS-based mobile phone application. You want to minimize code development and want the model to be optimized for inference on mobile phones. What should you do?

**A.** Train a model using AutoML Vision and use the “export for Core ML” option.

**B.** Train a model using AutoML Vision and use the “export for Coral” option.

**C.** Train a model using AutoML Vision and use the “export for TensorFlow.js” option.

**D.** Train a custom TensorFlow model and convert it to TensorFlow Lite (TFLite).

**Respuesta de la fuente:** A

**Explicación:** The requirement to minimize code development points to using AutoML Vision rather than training a custom TensorFlow model. Since the target platform is an iOS application, exporting the model for Core ML is the correct optimization, as Core ML is Apple's native framework for running machine learning models on iOS and macOS devices.

## Pregunta 93

Contexto: [topics:106](#topics-106)
You have been asked to build a model using a dataset that is stored in a medium-sized (~10 GB) BigQuery table. You need to quickly determine whether this data is suitable for model development. You want to create a one-time report that includes both informative visualizations of data distributions and more sophisticated statistical analyses to share with other ML engineers on your team. You require maximum flexibility to create your report. What should you do?

**A.** Use Vertex AI Workbench user-managed notebooks to generate the report.

**B.** Use the Google Data Studio to create the report.

**C.** Use the output from TensorFlow Data Validation on Dataflow to generate the report.

**D.** Use Dataprep to create the report.

**Respuesta de la fuente:** A

**Explicación:** Vertex AI Workbench provides a fully managed JupyterLab environment with direct access to BigQuery and rich Python libraries like Pandas, Matplotlib, and Seaborn. This combination offers the maximum flexibility required for both custom visualizations and sophisticated statistical analyses that dedicated BI tools or rigid validation pipelines cannot match.

## Pregunta 94

Contexto: [topics:106](#topics-106)
You work on an operations team at an international company that manages a large fleet of on-premises servers located in few data centers around the world. Your team collects monitoring data from the servers, including CPU/memory consumption. When an incident occurs on a server, your team is responsible for fixing it. Incident data has not been properly labeled yet. Your management team wants you to build a predictive maintenance solution that uses monitoring data from the VMs to detect potential failures and then alerts the service desk team. What should you do first?

**A.** Train a time-series model to predict the machines’ performance values. Configure an alert if a machine’s actual performance values significantly differ from the predicted performance values.

**B.** Implement a simple heuristic (e.g., based on z-score) to label the machines’ historical performance data. Train a model to predict anomalies based on this labeled dataset.

**C.** Develop a simple heuristic (e.g., based on z-score) to label the machines’ historical performance data. Test this heuristic in a production environment.

**D.** Hire a team of qualified analysts to review and label the machines’ historical performance data. Train a model based on this manually labeled dataset.

**Respuesta de la fuente:** B

**Explicación:** The goal is to build a predictive maintenance solution using machine learning, which requires labeled historical data for training. Since incident data is unlabeled, you must first generate labels; using a heuristic like z-score on historical data (Option B) provides the necessary supervised signal to train an anomaly detection model. Option C is incorrect because it stops at testing the heuristic itself rather than building the required ML solution, and it suggests testing directly in production, which violates standard safety practices.

## Pregunta 95

Contexto: [topics:106](#topics-106)
You are developing an ML model that uses sliced frames from video feed and creates bounding boxes around specific objects. You want to automate the following steps in your training pipeline: ingestion and preprocessing of data in Cloud Storage, followed by training and hyperparameter tuning of the object model using Vertex AI jobs, and finally deploying the model to an endpoint. You want to orchestrate the entire pipeline with minimal cluster management. What approach should you use?

**A.** Use Kubeflow Pipelines on Google Kubernetes Engine.

**B.** Use Vertex AI Pipelines with TensorFlow Extended (TFX) SDK.

**C.** Use Vertex AI Pipelines with Kubeflow Pipelines SDK.

**D.** Use Cloud Composer for the orchestration.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 96

Contexto: [topics:106](#topics-106)
You are training an object detection machine learning model on a dataset that consists of three million X-ray images, each roughly 2 GB in size. You are using Vertex AI Training to run a custom training application on a Compute Engine instance with 32-cores, 128 GB of RAM, and 1 NVIDIA P100 GPU. You notice that model training is taking a very long time. You want to decrease training time without sacrificing model performance. What should you do?

**A.** Increase the instance memory to 512 GB and increase the batch size.

**B.** Replace the NVIDIA P100 GPU with a v3-32 TPU in the training job.

**C.** Enable early stopping in your Vertex AI Training job.

**D.** Use the tf.distribute.Strategy API and run a distributed training job.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 97

Contexto: [topics:106](#topics-106)
You are a data scientist at an industrial equipment manufacturing company. You are developing a regression model to estimate the power consumption in the company’s manufacturing plants based on sensor data collected from all of the plants. The sensors collect tens of millions of records every day. You need to schedule daily training runs for your model that use all the data collected up to the current date. You want your model to scale smoothly and require minimal development work. What should you do?

**A.** Train a regression model using AutoML Tables.

**B.** Develop a custom TensorFlow regression model, and optimize it using Vertex AI Training.

**C.** Develop a custom scikit-learn regression model, and optimize it using Vertex AI Training.

**D.** Develop a regression model using BigQuery ML.

**Respuesta de la fuente:** D

**Explicación:** BigQuery ML is the correct choice because it integrates directly with BigQuery, allowing you to train models on tens of millions of daily records without moving data or managing infrastructure. This approach scales smoothly with the growing historical dataset and requires minimal development work compared to setting up custom training pipelines in Vertex AI.

AutoML Tables has row limits (typically 200 million rows) that would be exceeded quickly given the high volume of daily sensor data, making it unsuitable for long-term, cumulative training.

## Pregunta 98

Contexto: [topics:106](#topics-106)
You built a custom ML model using scikit-learn. Training time is taking longer than expected. You decide to migrate your model to Vertex AI Training, and you want to improve the model’s training time. What should you try out first?

**A.** Migrate your model to TensorFlow, and train it using Vertex AI Training.

**B.** Train your model in a distributed mode using multiple Compute Engine VMs.

**C.** Train your model with DLVM images on Vertex AI, and ensure that your code utilizes NumPy and SciPy internal methods whenever possible.

**D.** Train your model using Vertex AI Training with GPUs.

**Respuesta de la fuente:** C

**Explicación:** Scikit-learn is a CPU-bound library that does not natively support GPU acceleration or distributed training across multiple VMs, making options A, B, and D ineffective for reducing training time.
Option C is correct because using optimized Vertex AI Deep Learning VM (DLVM) images ensures the underlying system libraries are tuned for performance, while leveraging NumPy and SciPy internal methods allows scikit-learn to exploit vectorized operations and efficient memory handling.

## Pregunta 99

Contexto: [topics:106](#topics-106)
You are an ML engineer at a travel company. You have been researching customers’ travel behavior for many years, and you have deployed models that predict customers’ vacation patterns. You have observed that customers’ vacation destinations vary based on seasonality and holidays; however, these seasonal variations are similar across years. You want to quickly and easily store and compare the model versions and performance statistics across years. What should you do?

**A.** Store the performance statistics in Cloud SQL. Query that database to compare the performance statistics across the model versions.

**B.** Create versions of your models for each season per year in Vertex AI. Compare the performance statistics across the models in the Evaluate tab of the Vertex AI UI.

**C.** Store the performance statistics of each pipeline run in Kubeflow under an experiment for each season per year. Compare the results across the experiments in the Kubeflow UI.

**D.** Store the performance statistics of each version of your models using seasons and years as events in Vertex ML Metadata. Compare the results across the slices.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 100

Contexto: [topics:106](#topics-106)
You are an ML engineer at a manufacturing company. You need to build a model that identifies defects in products based on images of the product taken at the end of the assembly line. You want your model to preprocess the images with lower computation to quickly extract features of defects in products. Which approach should you use to build the model?

**A.** Reinforcement learning

**B.** Recommender system

**C.** Recurrent Neural Networks (RNN)

**D.** Convolutional Neural Networks (CNN)

**Respuesta de la fuente:** D

**Explicación:** Convolutional Neural Networks (CNNs) are specifically designed for processing grid-like data such as images, making them the standard choice for visual tasks like defect detection.
They utilize convolutional layers to efficiently extract spatial hierarchies of features with significantly lower computational overhead compared to fully connected networks or sequence models like RNNs.

## Pregunta 101

Contexto: [topics:106](#topics-106)
You are developing an ML model intended to classify whether X-ray images indicate bone fracture risk. You have trained a ResNet architecture on Vertex AI using a TPU as an accelerator, however you are unsatisfied with the training time and memory usage. You want to quickly iterate your training code but make minimal changes to the code. You also want to minimize impact on the model’s accuracy. What should you do?

**A.** Reduce the number of layers in the model architecture.

**B.** Reduce the global batch size from 1024 to 256.

**C.** Reduce the dimensions of the images used in the model.

**D.** Configure your model to use bfloat16 instead of float32.

**Respuesta de la fuente:** D

**Explicación:** Using bfloat16 (D) reduces memory usage by half compared to float32 and accelerates training on TPUs with minimal code changes, as it is a native TPU data type.
Unlike reducing layers or image dimensions, switching to bfloat16 preserves model accuracy and architecture complexity while addressing the performance constraints.

## Pregunta 102

Contexto: [topics:106](#topics-106)
You have successfully deployed to production a large and complex TensorFlow model trained on tabular data. You want to predict the lifetime value (LTV) field for each subscription stored in the BigQuery table named subscription. subscriptionPurchase in the project named my-fortune500-company-project.

You have organized all your training code, from preprocessing data from the BigQuery table up to deploying the validated model to the Vertex AI endpoint, into a TensorFlow Extended (TFX) pipeline. You want to prevent prediction drift, i.e., a situation when a feature data distribution in production changes significantly over time. What should you do?

**A.** Implement continuous retraining of the model daily using Vertex AI Pipelines.

**B.** Add a model monitoring job where 10% of incoming predictions are sampled 24 hours.

**C.** Add a model monitoring job where 90% of incoming predictions are sampled 24 hours.

**D.** Add a model monitoring job where 10% of incoming predictions are sampled every hour.

**Respuesta de la fuente:** B

**Explicación:** Vertex AI Model Monitoring is the designated service for detecting prediction drift in deployed endpoints.
Sampling 10% of predictions every day (Option B) provides statistically significant insights into distribution changes while minimizing computational costs and storage overhead compared to higher frequencies or sample sizes.

## Pregunta 103

Contexto: [topics:106](#topics-106)
You recently developed a deep learning model using Keras, and now you are experimenting with different training strategies. First, you trained the model using a single GPU, but the training process was too slow. Next, you distributed the training across 4 GPUs using tf.distribute.MirroredStrategy (with no other changes), but you did not observe a decrease in training time. What should you do?

**A.** Distribute the dataset with tf.distribute.Strategy.experimental_distribute_dataset

**B.** Create a custom training loop.

**C.** Use a TPU with tf.distribute.TPUStrategy.

**D.** Increase the batch size.

**Respuesta de la fuente:** D

**Explicación:** When using tf.distribute.MirroredStrategy, the global batch size is split across replicas.
If you keep the original single-GPU batch size, each GPU processes a very small slice (e.g., 1/4th), leading to low utilization and no speedup.
Increasing the global batch size ensures each GPU receives a larger per-replica batch, maximizing computational throughput.

## Pregunta 104

Contexto: [topics:106](#topics-106)
You work for a gaming company that has millions of customers around the world. All games offer a chat feature that allows players to communicate with each other in real time. Messages can be typed in more than 20 languages and are translated in real time using the Cloud Translation API. You have been asked to build an ML system to moderate the chat in real time while assuring that the performance is uniform across the various languages and without changing the serving infrastructure.

You trained your first model using an in-house word2vec model for embedding the chat messages translated by the Cloud Translation API. However, the model has significant differences in performance across the different languages. How should you improve it?

**A.** Add a regularization term such as the Min-Diff algorithm to the loss function.

**B.** Train a classifier using the chat messages in their original language.

**C.** Replace the in-house word2vec with GPT-3 or T5.

**D.** Remove moderation for languages for which the false positive rate is too high.

**Respuesta de la fuente:** B

**Explicación:** The current performance disparity stems from inconsistencies in the Cloud Translation API's output quality across different languages. Training on original language messages bypasses these translation errors and noise, ensuring uniform input quality for the classifier. This approach maintains existing infrastructure while directly addressing the root cause of the variance.

## Pregunta 105

Contexto: [topics:106](#topics-106)
You work for a gaming company that develops massively multiplayer online (MMO) games. You built a TensorFlow model that predicts whether players will make in-app purchases of more than $10 in the next two weeks. The model’s predictions will be used to adapt each user’s game experience. User data is stored in BigQuery. How should you serve your model while optimizing cost, user experience, and ease of management?

**A.** Import the model into BigQuery ML. Make predictions using batch reading data from BigQuery, and push the data to Cloud SQL

**B.** Deploy the model to Vertex AI Prediction. Make predictions using batch reading data from Cloud Bigtable, and push the data to Cloud SQL.

**C.** Embed the model in the mobile application. Make predictions after every in-app purchase event is published in Pub/Sub, and push the data to Cloud SQL.

**D.** Embed the model in the streaming Dataflow pipeline. Make predictions after every in-app purchase event is published in Pub/Sub, and push the data to Cloud SQL.

**Respuesta de la fuente:** A

**Explicación:** The requirement to predict purchases 'in the next two weeks' implies a batch prediction workflow rather than real-time inference. BigQuery ML allows you to import and serve your existing TensorFlow model directly within the data warehouse where the user data resides, eliminating the need for data movement or external serving infrastructure. This approach optimizes cost by avoiding the latency and overhead of streaming architectures while simplifying management through an integrated serverless solution.

## Pregunta 106

Contexto: [topics:106](#topics-106)
You are building a linear regression model on BigQuery ML to predict a customer’s likelihood of purchasing your company’s products. Your model uses a city name variable as a key predictive component. In order to train and serve the model, your data must be organized in columns. You want to prepare your data using the least amount of coding while maintaining the predictable variables. What should you do?

**A.** Use TensorFlow to create a categorical variable with a vocabulary list. Create the vocabulary file, and upload it as part of your model to BigQuery ML.

**B.** Create a new view with BigQuery that does not include a column with city information

**C.** Use Cloud Data Fusion to assign each city to a region labeled as 1, 2, 3, 4, or 5, and then use that number to represent the city in the model.

**D.** Use Dataprep to transform the state column using a one-hot encoding method, and make each city a column with binary values.

**Respuesta de la fuente:** D

**Explicación:** Linear regression models require numerical inputs, so categorical text data like city names must be converted. One-hot encoding transforms each unique category into a separate binary column, which preserves the independent nature of each city without imposing an arbitrary ordinal relationship.
Option D is correct because Dataprep provides a low-code interface to perform this transformation efficiently.

## Pregunta 107

Contexto: [topics:106](#topics-106)
You are an ML engineer at a bank that has a mobile application. Management has asked you to build an ML-based biometric authentication for the app that verifies a customer’s identity based on their fingerprint. Fingerprints are considered highly sensitive personal information and cannot be downloaded and stored into the bank databases. Which learning strategy should you recommend to train and deploy this ML mode?

**A.** Data Loss Prevention API

**B.** Federated learning

**C.** MD5 to encrypt data

**D.** Differential privacy

**Respuesta de la fuente:** B

**Explicación:** Federated learning is the correct strategy because it enables model training on decentralized edge devices (mobile phones) without transferring raw sensitive data to a central server. This directly addresses the requirement that fingerprint data cannot be downloaded or stored in bank databases, ensuring privacy while still allowing the global model to improve via aggregated parameter updates.

## Pregunta 108

Contexto: [topics:106](#topics-106)
You are experimenting with a built-in distributed XGBoost model in Vertex AI Workbench user-managed notebooks. You use BigQuery to split your data into training and validation sets using the following queries:

CREATE OR REPLACE TABLE ‘myproject.mydataset.training‘ AS
(SELECT * FROM ‘myproject.mydataset.mytable‘ WHERE RAND() <= 0.8);

CREATE OR REPLACE TABLE ‘myproject.mydataset.validation‘ AS
(SELECT * FROM ‘myproject.mydataset.mytable‘ WHERE RAND() <= 0.2);

After training the model, you achieve an area under the receiver operating characteristic curve (AUC ROC) value of 0.8, but after deploying the model to production, you notice that your model performance has dropped to an AUC ROC value of 0.65. What problem is most likely occurring?

**A.** There is training-serving skew in your production environment.

**B.** There is not a sufficient amount of training data.

**C.** The tables that you created to hold your training and validation records share some records, and you may not be using all the data in your initial table.

**D.** The RAND() function generated a number that is less than 0.2 in both instances, so every record in the validation table will also be in the training table.

**Respuesta de la fuente:** C

**Explicación:** The provided SQL queries use independent RAND() calls for training and validation splits, which is statistically invalid. Because the random numbers are generated separately, rows can overlap between sets or be excluded from both, leading to data leakage and an unrepresentative validation set.
This flawed splitting process causes the high validation AUC (0.8) to fail in production (0.65), as the model was not trained on a proper, exclusive partition of the data.

## Pregunta 109

Contexto: [topics:106](#topics-106)
During batch training of a neural network, you notice that there is an oscillation in the loss. How should you adjust your model to ensure that it converges?

**A.** Decrease the size of the training batch.

**B.** Decrease the learning rate hyperparameter.

**C.** Increase the learning rate hyperparameter.

**D.** Increase the size of the training batch.

**Respuesta de la fuente:** B

**Explicación:** Oscillations in the loss function during training typically indicate that the learning rate is too high, causing the optimizer to overshoot the minimum of the loss landscape. Decreasing the learning rate allows for smaller, more controlled updates, which helps the model converge smoothly toward the optimal parameters.

## Pregunta 110

Contexto: [topics:106](#topics-106)
You work for a toy manufacturer that has been experiencing a large increase in demand. You need to build an ML model to reduce the amount of time spent by quality control inspectors checking for product defects. Faster defect detection is a priority. The factory does not have reliable Wi-Fi. Your company wants to implement the new ML model as soon as possible. Which model should you use?

**A.** AutoML Vision Edge mobile-high-accuracy-1 model

**B.** AutoML Vision Edge mobile-low-latency-1 model

**C.** AutoML Vision model

**D.** AutoML Vision Edge mobile-versatile-1 model

**Respuesta de la fuente:** B

**Explicación:** The factory lacks reliable Wi-Fi, necessitating an edge-based model like AutoML Vision Edge to operate offline. Among the edge options, the 'mobile-low-latency-1' variant is specifically optimized for speed, directly addressing the priority of faster defect detection and reducing inspector time.

## Pregunta 111

Contexto: [topics:106](#topics-106)
You need to build classification workflows over several structured datasets currently stored in BigQuery. Because you will be performing the classification several times, you want to complete the following steps without writing code: exploratory data analysis, feature selection, model building, training, and hyperparameter tuning and serving. What should you do?

**A.** Train a TensorFlow model on Vertex AI.

**B.** Train a classification Vertex AutoML model.

**C.** Run a logistic regression job on BigQuery ML.

**D.** Use scikit-learn in Notebooks with pandas library.

**Respuesta de la fuente:** B

**Explicación:** Vertex AI AutoML is specifically designed to automate the entire machine learning lifecycle—including exploratory data analysis, feature selection, training, and hyperparameter tuning—without requiring users to write code. While BigQuery ML supports model building via SQL, it does not provide an automated, no-code interface for the full pipeline steps listed (such as automatic EDA or hyperparameter optimization) in the same comprehensive way AutoML does.

## Pregunta 112

Contexto: [topics:106](#topics-106)
You are an ML engineer in the contact center of a large enterprise. You need to build a sentiment analysis tool that predicts customer sentiment from recorded phone conversations. You need to identify the best approach to building a model while ensuring that the gender, age, and cultural differences of the customers who called the contact center do not impact any stage of the model development pipeline and results. What should you do?

**A.** Convert the speech to text and extract sentiments based on the sentences.

**B.** Convert the speech to text and build a model based on the words.

**C.** Extract sentiment directly from the voice recordings.

**D.** Convert the speech to text and extract sentiment using syntactical analysis.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because analyzing sentiment at the sentence level captures semantic context more effectively than isolated words (Option B), while avoiding audio features like pitch and tone (Option C) that often correlate with gender, age, or cultural background. Sentence-level analysis reduces bias by focusing on the explicit meaning of the text rather than acoustic characteristics or rigid syntactic structures.

## Pregunta 113

Contexto: [topics:106](#topics-106)
You need to analyze user activity data from your company’s mobile applications. Your team will use BigQuery for data analysis, transformation, and experimentation with ML algorithms. You need to ensure real-time ingestion of the user activity data into BigQuery. What should you do?

**A.** Configure Pub/Sub to stream the data into BigQuery.

**B.** Run an Apache Spark streaming job on Dataproc to ingest the data into BigQuery.

**C.** Run a Dataflow streaming job to ingest the data into BigQuery.

**D.** Configure Pub/Sub and a Dataflow streaming job to ingest the data into BigQuery,

**Respuesta de la fuente:** A

**Explicación:** BigQuery supports direct streaming inserts from Google Cloud Pub/Sub, eliminating the need for an intermediate processing step like Dataflow when complex transformations are not required.
Since the question specifies that transformation and ML experimentation will occur within BigQuery, using Pub/Sub to stream data directly to BigQuery is the most efficient and simplified architecture.

## Pregunta 114

Contexto: [topics:106](#topics-106)
You work for a gaming company that manages a popular online multiplayer game where teams with 6 players play against each other in 5-minute battles. There are many new players every day. You need to build a model that automatically assigns available players to teams in real time. User research indicates that the game is more enjoyable when battles have players with similar skill levels. Which business metrics should you track to measure your model’s performance?

**A.** Average time players wait before being assigned to a team

**B.** Precision and recall of assigning players to teams based on their predicted versus actual ability

**C.** User engagement as measured by the number of battles played daily per user

**D.** Rate of return as measured by additional revenue generated minus the cost of developing a new model

**Respuesta de la fuente:** C

**Explicación:** The question specifically asks for **business metrics** to measure the model's performance in the context of user enjoyment.

User engagement (C), measured by daily battles per user, is a direct business indicator of whether players are enjoying the game enough to continue playing, which aligns with the goal of balanced matches.

Precision and recall (B) are technical/algorithmic metrics, not business metrics. Wait time (A) measures latency, not enjoyment or balance. ROI (D) is a financial metric but too broad and delayed to directly measure the immediate impact on player enjoyment from match balancing.

## Pregunta 115

Contexto: [topics:106](#topics-106)
You are building an ML model to predict trends in the stock market based on a wide range of factors. While exploring the data, you notice that some features have a large range. You want to ensure that the features with the largest magnitude don’t overfit the model. What should you do?

**A.** Standardize the data by transforming it with a logarithmic function.

**B.** Apply a principal component analysis (PCA) to minimize the effect of any particular feature.

**C.** Use a binning strategy to replace the magnitude of each feature with the appropriate bin number.

**D.** Normalize the data by scaling it to have values between 0 and 1.

**Respuesta de la fuente:** D

**Explicación:** Normalization scales feature values to a specific range, typically [0, 1], ensuring that features with larger magnitudes do not disproportionately influence the model's weight updates or distance calculations. This prevents high-magnitude features from dominating the learning process, thereby reducing the risk of overfitting to those specific scales.

## Pregunta 116

Contexto: [topics:106](#topics-106)
You work for a biotech startup that is experimenting with deep learning ML models based on properties of biological organisms. Your team frequently works on early-stage experiments with new architectures of ML models, and writes custom TensorFlow ops in C++. You train your models on large datasets and large batch sizes. Your typical batch size has 1024 examples, and each example is about 1 MB in size. The average size of a network with all weights and embeddings is 20 GB. What hardware should you choose for your models?

**A.** A cluster with 2 n1-highcpu-64 machines, each with 8 NVIDIA Tesla V100 GPUs (128 GB GPU memory in total), and a n1-highcpu-64 machine with 64 vCPUs and 58 GB RAM

**B.** A cluster with 2 a2-megagpu-16g machines, each with 16 NVIDIA Tesla A100 GPUs (640 GB GPU memory in total), 96 vCPUs, and 1.4 TB RAM

**C.** A cluster with an n1-highcpu-64 machine with a v2-8 TPU and 64 GB RAM

**D.** A cluster with 4 n1-highcpu-96 machines, each with 96 vCPUs and 86 GB RAM

**Respuesta de la fuente:** D

**Explicación:** The scenario specifies that the team frequently writes custom TensorFlow ops in C++. Google Cloud documentation and best practices indicate that TPUs (Option C) are optimized for standard deep learning frameworks but do not fully support custom CPU operations, making them unsuitable here.

While GPUs (Options A and B) are powerful for standard training, they also have limited compatibility with arbitrary custom C++ ops compared to general-purpose CPUs. Option D provides a cluster of high-CPU machines, which is the recommended hardware for workloads requiring custom CPU-bound operations or when GPU/TPU acceleration cannot be utilized due to custom code constraints.

## Pregunta 117

Contexto: [topics:106](#topics-106)
You are an ML engineer at an ecommerce company and have been tasked with building a model that predicts how much inventory the logistics team should order each month. Which approach should you take?

**A.** Use a clustering algorithm to group popular items together. Give the list to the logistics team so they can increase inventory of the popular items.

**B.** Use a regression model to predict how much additional inventory should be purchased each month. Give the results to the logistics team at the beginning of the month so they can increase inventory by the amount predicted by the model.

**C.** Use a time series forecasting model to predict each item's monthly sales. Give the results to the logistics team so they can base inventory on the amount predicted by the model.

**D.** Use a classification model to classify inventory levels as UNDER_STOCKED, OVER_STOCKED, and CORRECTLY_STOCKEGive the report to the logistics team each month so they can fine-tune inventory levels.

**Respuesta de la fuente:** C

**Explicación:** Inventory demand is inherently temporal, exhibiting patterns like seasonality and trends that require historical context to predict accurately. Time series forecasting models are specifically designed to analyze these sequential data points to forecast future values, making them the standard approach for inventory planning.

## Pregunta 118

Contexto: [topics:106](#topics-106)
You are building a TensorFlow model for a financial institution that predicts the impact of consumer spending on inflation globally. Due to the size and nature of the data, your model is long-running across all types of hardware, and you have built frequent checkpointing into the training process. Your organization has asked you to minimize cost. What hardware should you choose?

**A.** A Vertex AI Workbench user-managed notebooks instance running on an n1-standard-16 with 4 NVIDIA P100 GPUs

**B.** A Vertex AI Workbench user-managed notebooks instance running on an n1-standard-16 with an NVIDIA P100 GPU

**C.** A Vertex AI Workbench user-managed notebooks instance running on an n1-standard-16 with a non-preemptible v3-8 TPU

**D.** A Vertex AI Workbench user-managed notebooks instance running on an n1-standard-16 with a preemptible v3-8 TPU

**Respuesta de la fuente:** D

**Explicación:** The requirement to minimize cost points directly to preemptible instances, which offer significant discounts compared to non-preemptible options.
The implementation of frequent checkpointing ensures that training progress is preserved if the instance is terminated unexpectedly, mitigating the primary risk of using preemptible hardware.
Therefore, a preemptible v3-8 TPU provides the optimal balance of high-performance acceleration and lowest possible expense.

## Pregunta 119

Contexto: [topics:106](#topics-106)
You work for a company that provides an anti-spam service that flags and hides spam posts on social media platforms. Your company currently uses a list of 200,000 keywords to identify suspected spam posts. If a post contains more than a few of these keywords, the post is identified as spam. You want to start using machine learning to flag spam posts for human review. What is the main advantage of implementing machine learning for this business case?

**A.** Posts can be compared to the keyword list much more quickly.

**B.** New problematic phrases can be identified in spam posts.

**C.** A much longer keyword list can be used to flag spam posts.

**D.** Spam posts can be flagged using far fewer keywords.

**Respuesta de la fuente:** B

**Explicación:** Machine learning excels at pattern recognition rather than simple rule matching. It can identify complex relationships and new variations in spam tactics that static keyword lists cannot detect.

## Pregunta 120

Contexto: [topics:106](#topics-106)
One of your models is trained using data provided by a third-party data broker. The data broker does not reliably notify you of formatting changes in the data. You want to make your model training pipeline more robust to issues like this. What should you do?

**A.** Use TensorFlow Data Validation to detect and flag schema anomalies.

**B.** Use TensorFlow Transform to create a preprocessing component that will normalize data to the expected distribution, and replace values that don’t match the schema with 0.

**C.** Use tf.math to analyze the data, compute summary statistics, and flag statistical anomalies.

**D.** Use custom TensorFlow functions at the start of your model training to detect and flag known formatting errors.

**Respuesta de la fuente:** A

**Explicación:** TensorFlow Data Validation (TFDV) is specifically designed to detect schema changes and data anomalies, which directly addresses the issue of unreliable notifications from third-party data brokers.
By using TFDV, you can automatically flag inconsistencies such as unexpected column types or missing values before they disrupt model training.

## Pregunta 121

Contexto: [topics:106](#topics-106)
You work for a company that is developing a new video streaming platform. You have been asked to create a recommendation system that will suggest the next video for a user to watch. After a review by an AI Ethics team, you are approved to start development. Each video asset in your company’s catalog has useful metadata (e.g., content type, release date, country), but you do not have any historical user event data. How should you build the recommendation system for the first version of the product?

**A.** Launch the product without machine learning. Present videos to users alphabetically, and start collecting user event data so you can develop a recommender model in the future.

**B.** Launch the product without machine learning. Use simple heuristics based on content metadata to recommend similar videos to users, and start collecting user event data so you can develop a recommender model in the future.

**C.** Launch the product with machine learning. Use a publicly available dataset such as MovieLens to train a model using the Recommendations AI, and then apply this trained model to your data.

**D.** Launch the product with machine learning. Generate embeddings for each video by training an autoencoder on the content metadata using TensorFlow. Cluster content based on the similarity of these embeddings, and then recommend videos from the same cluster.

**Respuesta de la fuente:** B

**Explicación:** Since there is no historical user event data, collaborative filtering (Option C) is impossible, and advanced ML techniques like autoencoders (Option D) are over-engineered for an initial launch without user interaction signals. Option B is the most pragmatic approach: it utilizes available content metadata to provide immediate value through heuristic-based recommendations while simultaneously establishing a data collection pipeline for future model development.

## Pregunta 122

Contexto: [topics:106](#topics-106)
You recently built the first version of an image segmentation model for a self-driving car. After deploying the model, you observe a decrease in the area under the curve (AUC) metric. When analyzing the video recordings, you also discover that the model fails in highly congested traffic but works as expected when there is less traffic. What is the most likely reason for this result?

**A.** The model is overfitting in areas with less traffic and underfitting in areas with more traffic.

**B.** AUC is not the correct metric to evaluate this classification model.

**C.** Too much data representing congested areas was used for model training.

**D.** Gradients become small and vanish while backpropagating from the output to input nodes.

**Respuesta de la fuente:** A

**Explicación:** The model's success in low-traffic scenarios suggests it has learned those patterns well, likely to the point of overfitting if the training data was dominated by such cases.
Conversely, its failure in congested traffic indicates underfitting for that specific scenario, implying insufficient representation or learning of complex crowded scenes during training.

## Pregunta 123

Contexto: [topics:106](#topics-106)
You are developing an ML model to predict house prices. While preparing the data, you discover that an important predictor variable, distance from the closest school, is often missing and does not have high variance. Every instance (row) in your data is important. How should you handle the missing data?

**A.** Delete the rows that have missing values.

**B.** Apply feature crossing with another column that does not have missing values.

**C.** Predict the missing values using linear regression.

**D.** Replace the missing values with zeros.

**Respuesta de la fuente:** C

**Explicación:** The scenario specifies that every data instance is important, which rules out deleting rows (Option A) as it causes valuable data loss. Predicting missing values using linear regression (Option C) is a robust imputation technique that preserves the dataset integrity and leverages relationships with other variables to estimate accurate values.

## Pregunta 124

Contexto: [topics:106](#topics-106)
You are an ML engineer responsible for designing and implementing training pipelines for ML models. You need to create an end-to-end training pipeline for a TensorFlow model. The TensorFlow model will be trained on several terabytes of structured data. You need the pipeline to include data quality checks before training and model quality checks after training but prior to deployment. You want to minimize development time and the need for infrastructure maintenance. How should you build and orchestrate your training pipeline?

**A.** Create the pipeline using Kubeflow Pipelines domain-specific language (DSL) and predefined Google Cloud components. Orchestrate the pipeline using Vertex AI Pipelines.

**B.** Create the pipeline using TensorFlow Extended (TFX) and standard TFX components. Orchestrate the pipeline using Vertex AI Pipelines.

**C.** Create the pipeline using Kubeflow Pipelines domain-specific language (DSL) and predefined Google Cloud components. Orchestrate the pipeline using Kubeflow Pipelines deployed on Google Kubernetes Engine.

**D.** Create the pipeline using TensorFlow Extended (TFX) and standard TFX components. Orchestrate the pipeline using Kubeflow Pipelines deployed on Google Kubernetes Engine.

**Respuesta de la fuente:** B

**Explicación:** TensorFlow Extended (TFX) provides pre-built, end-to-end components specifically designed for TensorFlow models, including dedicated tools for data quality (TensorFlow Data Validation) and model validation checks.
Orchestrating with Vertex AI Pipelines offers a fully managed service that minimizes infrastructure maintenance compared to self-managing Kubeflow on GKE.

## Pregunta 125

Contexto: [topics:106](#topics-106)
You manage a team of data scientists who use a cloud-based backend system to submit training jobs. This system has become very difficult to administer, and you want to use a managed service instead. The data scientists you work with use many different frameworks, including Keras, PyTorch, theano, scikit-learn, and custom libraries. What should you do?

**A.** Use the Vertex AI Training to submit training jobs using any framework.

**B.** Configure Kubeflow to run on Google Kubernetes Engine and submit training jobs through TFJob.

**C.** Create a library of VM images on Compute Engine, and publish these images on a centralized repository.

**D.** Set up Slurm workload manager to receive jobs that can be scheduled to run on your cloud infrastructure.

**Respuesta de la fuente:** A

**Explicación:** Vertex AI Training is a fully managed service that eliminates the administrative overhead of maintaining custom backend infrastructure.
It natively supports a wide variety of machine learning frameworks, including PyTorch, Keras, scikit-learn, and custom code, meeting the requirement for framework agility without requiring self-managed clusters like Kubeflow or Slurm.

## Pregunta 126

Contexto: [topics:106](#topics-106)
You are training an object detection model using a Cloud TPU v2. Training time is taking longer than expected. Based on this simplified trace obtained with a Cloud TPU profile, what action should you take to decrease training time in a cost-efficient way?

[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/94958dbbd20998e4744d.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Extract Extract
step 1 Step 2
CPUs
Transform 1 ‘Transform 2
Network
TPUs
Time
Train2
```

**A.** Move from Cloud TPU v2 to Cloud TPU v3 and increase batch size.

**B.** Move from Cloud TPU v2 to 8 NVIDIA V100 GPUs and increase batch size.

**C.** Rewrite your input function to resize and reshape the input images.

**D.** Rewrite your input function using parallel reads, parallel processing, and prefetch.

**Respuesta de la fuente:** D

**Explicación:** The profile indicates a significant bottleneck in HostToDevice and DeviceToHost transfer times, suggesting the TPU is idle while waiting for data from the host CPU. Optimizing the input pipeline with parallel reads, processing, and prefetching allows the CPU to feed data faster, keeping the TPU fully utilized without incurring additional hardware costs.

## Pregunta 127

Contexto: [topics:106](#topics-106)
While performing exploratory data analysis on a dataset, you find that an important categorical feature has 5% null values. You want to minimize the bias that could result from the missing values. How should you handle the missing values?

**A.** Remove the rows with missing values, and upsample your dataset by 5%.

**B.** Replace the missing values with the feature’s mean.

**C.** Replace the missing values with a placeholder category indicating a missing value.

**D.** Move the rows with missing values to your validation dataset.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because introducing a dedicated 'missing' category preserves the informational content of the null values without imposing arbitrary assumptions about their underlying distribution. This prevents the bias introduced by listwise deletion (Option A) and avoids the conceptual error of applying numerical statistics like the mean to categorical data (Option B).

## Pregunta 128

Contexto: [topics:106](#topics-106)
You are an ML engineer on an agricultural research team working on a crop disease detection tool to detect leaf rust spots in images of crops to determine the presence of a disease. These spots, which can vary in shape and size, are correlated to the severity of the disease. You want to develop a solution that predicts the presence and severity of the disease with high accuracy. What should you do?

**A.** Create an object detection model that can localize the rust spots.

**B.** Develop an image segmentation ML model to locate the boundaries of the rust spots.

**C.** Develop a template matching algorithm using traditional computer vision libraries.

**D.** Develop an image classification ML model to predict the presence of the disease.

**Respuesta de la fuente:** B

**Explicación:** The requirement is to predict both presence and severity, where severity correlates with the shape and size of rust spots.
Image segmentation (B) provides pixel-level classification, allowing precise measurement of spot boundaries, area, and morphology.
This granularity enables accurate severity assessment, unlike object detection which uses bounding boxes or classification which only outputs a label.

## Pregunta 129

Contexto: [topics:106](#topics-106)
You have been asked to productionize a proof-of-concept ML model built using Keras. The model was trained in a Jupyter notebook on a data scientist’s local machine. The notebook contains a cell that performs data validation and a cell that performs model analysis. You need to orchestrate the steps contained in the notebook and automate the execution of these steps for weekly retraining. You expect much more training data in the future. You want your solution to take advantage of managed services while minimizing cost. What should you do?

**A.** Move the Jupyter notebook to a Notebooks instance on the largest N2 machine type, and schedule the execution of the steps in the Notebooks instance using Cloud Scheduler.

**B.** Write the code as a TensorFlow Extended (TFX) pipeline orchestrated with Vertex AI Pipelines. Use standard TFX components for data validation and model analysis, and use Vertex AI Pipelines for model retraining.

**C.** Rewrite the steps in the Jupyter notebook as an Apache Spark job, and schedule the execution of the job on ephemeral Dataproc clusters using Cloud Scheduler.

**D.** Extract the steps contained in the Jupyter notebook as Python scripts, wrap each script in an Apache Airflow BashOperator, and run the resulting directed acyclic graph (DAG) in Cloud Composer.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because TensorFlow Extended (TFX) provides standardized, production-grade components for data validation and model analysis that directly map to the notebook's logic. Vertex AI Pipelines offers a fully managed orchestration service designed for scalable ML workflows, satisfying the requirement to use managed services while minimizing operational overhead compared to self-managed Airflow or Dataproc clusters.

## Pregunta 130

Contexto: [topics:106](#topics-106)
You are working on a system log anomaly detection model for a cybersecurity organization. You have developed the model using TensorFlow, and you plan to use it for real-time prediction. You need to create a Dataflow pipeline to ingest data via Pub/Sub and write the results to BigQuery. You want to minimize the serving latency as much as possible. What should you do?

**A.** Containerize the model prediction logic in Cloud Run, which is invoked by Dataflow.

**B.** Load the model directly into the Dataflow job as a dependency, and use it for prediction.

**C.** Deploy the model to a Vertex AI endpoint, and invoke this endpoint in the Dataflow job.

**D.** Deploy the model in a TFServing container on Google Kubernetes Engine, and invoke it in the Dataflow job.

**Respuesta de la fuente:** B

**Explicación:** To minimize serving latency in a Dataflow pipeline, you should avoid the network overhead introduced by external HTTP calls to services like Vertex AI or Cloud Run. Loading the model directly into the Dataflow worker as a dependency allows for local inference, eliminating round-trip communication delays and ensuring the lowest possible latency for real-time predictions.

## Pregunta 131

Contexto: [topics:106](#topics-106)
You are an ML engineer at a mobile gaming company. A data scientist on your team recently trained a TensorFlow model, and you are responsible for deploying this model into a mobile application. You discover that the inference latency of the current model doesn’t meet production requirements. You need to reduce the inference time by 50%, and you are willing to accept a small decrease in model accuracy in order to reach the latency requirement. Without training a new model, which model optimization technique for reducing latency should you try first?

**A.** Weight pruning

**B.** Dynamic range quantization

**C.** Model distillation

**D.** Dimensionality reduction

**Respuesta de la fuente:** B

**Explicación:** The question explicitly requires optimizing the model 'without training a new model,' which excludes weight pruning and model distillation as they require retraining or fine-tuning. Dynamic range quantization is a post-training optimization technique that converts floating-point weights to integers (e.g., int8), reducing memory footprint and enabling faster inference on mobile hardware without any additional training.

## Pregunta 132

Contexto: [topics:106](#topics-106)
You work on a data science team at a bank and are creating an ML model to predict loan default risk. You have collected and cleaned hundreds of millions of records worth of training data in a BigQuery table, and you now want to develop and compare multiple models on this data using TensorFlow and Vertex AI. You want to minimize any bottlenecks during the data ingestion state while considering scalability. What should you do?

**A.** Use the BigQuery client library to load data into a dataframe, and use tf.data.Dataset.from_tensor_slices() to read it.

**B.** Export data to CSV files in Cloud Storage, and use tf.data.TextLineDataset() to read them.

**C.** Convert the data into TFRecords, and use tf.data.TFRecordDataset() to read them.

**D.** Use TensorFlow I/O’s BigQuery Reader to directly read the data.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because TensorFlow I/O’s BigQuery Reader allows direct streaming of data from BigQuery into the TensorFlow pipeline without requiring intermediate exports or memory-intensive DataFrame loading. This approach minimizes ingestion bottlenecks by leveraging BigQuery's parallel processing capabilities and avoids the latency and storage overhead associated with converting to TFRecords or CSV files for hundreds of millions of records.

## Pregunta 133

Contexto: [topics:106](#topics-106)
You have recently created a proof-of-concept (POC) deep learning model. You are satisfied with the overall architecture, but you need to determine the value for a couple of hyperparameters. You want to perform hyperparameter tuning on Vertex AI to determine both the appropriate embedding dimension for a categorical feature used by your model and the optimal learning rate. You configure the following settings:
•	For the embedding dimension, you set the type to INTEGER with a minValue of 16 and maxValue of 64.
•	For the learning rate, you set the type to DOUBLE with a minValue of 10e-05 and maxValue of 10e-02.

You are using the default Bayesian optimization tuning algorithm, and you want to maximize model accuracy. Training time is not a concern. How should you set the hyperparameter scaling for each hyperparameter and the maxParallelTrials?

**A.** Use UNIT_LINEAR_SCALE for the embedding dimension, UNIT_LOG_SCALE for the learning rate, and a large number of parallel trials.

**B.** Use UNIT_LINEAR_SCALE for the embedding dimension, UNIT_LOG_SCALE for the learning rate, and a small number of parallel trials.

**C.** Use UNIT_LOG_SCALE for the embedding dimension, UNIT_LINEAR_SCALE for the learning rate, and a large number of parallel trials.

**D.** Use UNIT_LOG_SCALE for the embedding dimension, UNIT_LINEAR_SCALE for the learning rate, and a small number of parallel trials.

**Respuesta de la fuente:** B

**Explicación:** The embedding dimension is an integer parameter, so UNIT_LINEAR_SCALE is appropriate to sample values uniformly across the range [16, 64]. The learning rate spans several orders of magnitude (10^-5 to 10^-2), requiring UNIT_LOG_SCALE to ensure effective sampling across all magnitudes. Since training time is not a concern and the goal is to maximize accuracy using Bayesian optimization, using a small number of parallel trials is preferred because it allows the algorithm to use information from previous results to guide subsequent searches more efficiently than running many trials in parallel.

## Pregunta 134

Contexto: [topics:106](#topics-106)
You are the Director of Data Science at a large company, and your Data Science team has recently begun using the Kubeflow Pipelines SDK to orchestrate their training pipelines. Your team is struggling to integrate their custom Python code into the Kubeflow Pipelines SDK. How should you instruct them to proceed in order to quickly integrate their code with the Kubeflow Pipelines SDK?

**A.** Use the func_to_container_op function to create custom components from the Python code.

**B.** Use the predefined components available in the Kubeflow Pipelines SDK to access Dataproc, and run the custom code there.

**C.** Package the custom Python code into Docker containers, and use the load_component_from_file function to import the containers into the pipeline.

**D.** Deploy the custom Python code to Cloud Functions, and use Kubeflow Pipelines to trigger the Cloud Function.

**Respuesta de la fuente:** A

**Explicación:** The func_to_container_op function is specifically designed to convert standard Python functions into containerized pipeline components. This allows the team to integrate custom code quickly without manually writing Dockerfiles or YAML component definitions.

## Pregunta 135

Contexto: [topics:106](#topics-106)
You work for the AI team of an automobile company, and you are developing a visual defect detection model using TensorFlow and Keras. To improve your model performance, you want to incorporate some image augmentation functions such as translation, cropping, and contrast tweaking. You randomly apply these functions to each training batch. You want to optimize your data processing pipeline for run time and compute resources utilization. What should you do?

**A.** Embed the augmentation functions dynamically in the tf.Data pipeline.

**B.** Embed the augmentation functions dynamically as part of Keras generators.

**C.** Use Dataflow to create all possible augmentations, and store them as TFRecords.

**D.** Use Dataflow to create the augmentations dynamically per training run, and stage them as TFRecords.

**Respuesta de la fuente:** A

**Explicación:** Embedding augmentation functions in the tf.data pipeline allows for on-the-fly processing during training, which eliminates the storage overhead of pre-generating augmented data.

This approach leverages tf.data's built-in optimization capabilities, such as parallelization and prefetching, to ensure efficient compute resource utilization compared to Keras generators or batch processing with Dataflow.

## Pregunta 136

Contexto: [topics:106](#topics-106)
You work for an online publisher that delivers news articles to over 50 million readers. You have built an AI model that recommends content for the company’s weekly newsletter. A recommendation is considered successful if the article is opened within two days of the newsletter’s published date and the user remains on the page for at least one minute.

All the information needed to compute the success metric is available in BigQuery and is updated hourly. The model is trained on eight weeks of data, on average its performance degrades below the acceptable baseline after five weeks, and training time is 12 hours. You want to ensure that the model’s performance is above the acceptable baseline while minimizing cost. How should you monitor the model to determine when retraining is necessary?

**A.** Use Vertex AI Model Monitoring to detect skew of the input features with a sample rate of 100% and a monitoring frequency of two days.

**B.** Schedule a cron job in Cloud Tasks to retrain the model every week before the newsletter is created.

**C.** Schedule a weekly query in BigQuery to compute the success metric.

**D.** Schedule a daily Dataflow job in Cloud Composer to compute the success metric.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because the success metric data resides entirely in BigQuery, allowing direct and cost-efficient computation via scheduled queries without additional infrastructure.
Weekly monitoring aligns with the model's five-week degradation cycle, ensuring performance issues are detected before impact while minimizing compute costs compared to daily checks or continuous streaming pipelines.

## Pregunta 137

Contexto: [topics:106](#topics-106)
You deployed an ML model into production a year ago. Every month, you collect all raw requests that were sent to your model prediction service during the previous month. You send a subset of these requests to a human labeling service to evaluate your model’s performance. After a year, you notice that your model's performance sometimes degrades significantly after a month, while other times it takes several months to notice any decrease in performance. The labeling service is costly, but you also need to avoid large performance degradations. You want to determine how often you should retrain your model to maintain a high level of performance while minimizing cost. What should you do?

**A.** Train an anomaly detection model on the training dataset, and run all incoming requests through this model. If an anomaly is detected, send the most recent serving data to the labeling service.

**B.** Identify temporal patterns in your model’s performance over the previous year. Based on these patterns, create a schedule for sending serving data to the labeling service for the next year.

**C.** Compare the cost of the labeling service with the lost revenue due to model performance degradation over the past year. If the lost revenue is greater than the cost of the labeling service, increase the frequency of model retraining; otherwise, decrease the model retraining frequency.

**D.** Run training-serving skew detection batch jobs every few days to compare the aggregate statistics of the features in the training dataset with recent serving data. If skew is detected, send the most recent serving data to the labeling service.

**Respuesta de la fuente:** D

**Explicación:** Training-serving skew detection identifies statistical discrepancies between the training data and live serving data, which are primary indicators of model performance degradation (e.g., due to concept or covariate drift).
By running these checks frequently but only sending data for expensive human labeling when skew is detected, you minimize labeling costs while ensuring timely retraining.
This approach optimizes the trade-off between cost and maintaining high model performance better than fixed schedules or reactive revenue analysis.

## Pregunta 138

Contexto: [topics:106](#topics-106)
You work for a company that manages a ticketing platform for a large chain of cinemas. Customers use a mobile app to search for movies they’re interested in and purchase tickets in the app. Ticket purchase requests are sent to Pub/Sub and are processed with a Dataflow streaming pipeline configured to conduct the following steps:
1. Check for availability of the movie tickets at the selected cinema.
2. Assign the ticket price and accept payment.
3. Reserve the tickets at the selected cinema.
4. Send successful purchases to your database.

Each step in this process has low latency requirements (less than 50 milliseconds). You have developed a logistic regression model with BigQuery ML that predicts whether offering a promo code for free popcorn increases the chance of a ticket purchase, and this prediction should be added to the ticket purchase process. You want to identify the simplest way to deploy this model to production while adding minimal latency. What should you do?

**A.** Run batch inference with BigQuery ML every five minutes on each new set of tickets issued.

**B.** Export your model in TensorFlow format, and add a tfx_bsl.public.beam.RunInference step to the Dataflow pipeline.

**C.** Export your model in TensorFlow format, deploy it on Vertex AI, and query the prediction endpoint from your streaming pipeline.

**D.** Convert your model with TensorFlow Lite (TFLite), and add it to the mobile app so that the promo code and the incoming request arrive together in Pub/Sub.

**Respuesta de la fuente:** D

**Explicación:** To minimize latency in a streaming pipeline with strict sub-50ms requirements, server-side options like Vertex AI (Option C) introduce network overhead that may exceed the limit. Option A is batch-oriented and unsuitable for real-time inference.
Deploying the model to the mobile app via TensorFlow Lite (Option D) allows prediction at the edge before the request reaches Pub/Sub, eliminating backend processing latency entirely and integrating the promo decision seamlessly into the user's initial interaction.

## Pregunta 139

Contexto: [topics:106](#topics-106)
You work on a team in a data center that is responsible for server maintenance. Your management team wants you to build a predictive maintenance solution that uses monitoring data to detect potential server failures. Incident data has not been labeled yet. What should you do first?

**A.** Train a time-series model to predict the machines’ performance values. Configure an alert if a machine’s actual performance values significantly differ from the predicted performance values.

**B.** Develop a simple heuristic (e.g., based on z-score) to label the machines’ historical performance data. Use this heuristic to monitor server performance in real time.

**C.** Develop a simple heuristic (e.g., based on z-score) to label the machines’ historical performance data. Train a model to predict anomalies based on this labeled dataset.

**D.** Hire a team of qualified analysts to review and label the machines’ historical performance data. Train a model based on this manually labeled dataset.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 140

Contexto: [topics:106](#topics-106)
You work for a retailer that sells clothes to customers around the world. You have been tasked with ensuring that ML models are built in a secure manner. Specifically, you need to protect sensitive customer data that might be used in the models. You have identified four fields containing sensitive data that are being used by your data science team: AGE, IS_EXISTING_CUSTOMER, LATITUDE_LONGITUDE, and SHIRT_SIZE. What should you do with the data before it is made available to the data science team for training purposes?

**A.** Tokenize all of the fields using hashed dummy values to replace the real values.

**B.** Use principal component analysis (PCA) to reduce the four sensitive fields to one PCA vector.

**C.** Coarsen the data by putting AGE into quantiles and rounding LATITUDE_LONGTTUDE into single precision. The other two fields are already as coarse as possible.

**D.** Remove all sensitive data fields, and ask the data science team to build their models using non-sensitive data.

**Respuesta de la fuente:** A

**Explicación:** Tokenization via hashing (Option A) preserves the uniqueness of values without revealing sensitive information, allowing models to process categorical identifiers securely. Unlike coarsening (Option C), which introduces noise and loses granular detail, or removing data entirely (Option D), tokenization maintains the full informational utility required for model training while ensuring privacy.

## Pregunta 141

Contexto: [topics:106](#topics-106)
You work for a magazine publisher and have been tasked with predicting whether customers will cancel their annual subscription. In your exploratory data analysis, you find that 90% of individuals renew their subscription every year, and only 10% of individuals cancel their subscription. After training a NN Classifier, your model predicts those who cancel their subscription with 99% accuracy and predicts those who renew their subscription with 82% accuracy. How should you interpret these results?

**A.** This is not a good result because the model should have a higher accuracy for those who renew their subscription than for those who cancel their subscription.

**B.** This is not a good result because the model is performing worse than predicting that people will always renew their subscription.

**C.** This is a good result because predicting those who cancel their subscription is more difficult, since there is less data for this group.

**D.** This is a good result because the accuracy across both groups is greater than 80%.

**Respuesta de la fuente:** C

**Explicación:** The primary goal is to identify customers who will cancel their subscription (the minority class). The model achieves 99% accuracy on this specific, difficult target despite the severe class imbalance (90/10 split), which indicates effective learning of the cancellation pattern.
Option C correctly highlights that achieving such high precision on the underrepresented group is a significant success in imbalanced classification scenarios.

## Pregunta 142

Contexto: [topics:106](#topics-106)
You have built a model that is trained on data stored in Parquet files. You access the data through a Hive table hosted on Google Cloud. You preprocessed these data with PySpark and exported it as a CSV file into Cloud Storage. After preprocessing, you execute additional steps to train and evaluate your model. You want to parametrize this model training in Kubeflow Pipelines. What should you do?

**A.** Remove the data transformation step from your pipeline.

**B.** Containerize the PySpark transformation step, and add it to your pipeline.

**C.** Add a ContainerOp to your pipeline that spins a Dataproc cluster, runs a transformation, and then saves the transformed data in Cloud Storage.

**D.** Deploy Apache Spark at a separate node pool in a Google Kubernetes Engine cluster. Add a ContainerOp to your pipeline that invokes a corresponding transformation job for this Spark instance.

**Respuesta de la fuente:** C

**Explicación:** Dataproc is the recommended fully managed service on Google Cloud for running Apache Spark workloads efficiently at scale. Using a ContainerOp to trigger a Dataproc cluster allows the Kubeflow Pipeline to handle large-scale PySpark transformations without the overhead of managing Spark resources directly within GKE.

## Pregunta 143

Contexto: [topics:106](#topics-106)
You have developed an ML model to detect the sentiment of users’ posts on your company's social media page to identify outages or bugs. You are using Dataflow to provide real-time predictions on data ingested from Pub/Sub. You plan to have multiple training iterations for your model and keep the latest two versions live after every run. You want to split the traffic between the versions in an 80:20 ratio, with the newest model getting the majority of the traffic. You want to keep the pipeline as simple as possible, with minimal management required. What should you do?

**A.** Deploy the models to a Vertex AI endpoint using the traffic-split=0=80, PREVIOUS_MODEL_ID=20 configuration.

**B.** Wrap the models inside an App Engine application using the --splits PREVIOUS_VERSION=0.2, NEW_VERSION=0.8 configuration

**C.** Wrap the models inside a Cloud Run container using the REVISION1=20, REVISION2=80 revision configuration.

**D.** Implement random splitting in Dataflow using beam.Partition() with a partition function calling a Vertex AI endpoint.

**Respuesta de la fuente:** A

**Explicación:** Vertex AI Endpoints natively support traffic splitting between multiple deployed models using the --traffic-split flag, satisfying the requirement for minimal management. This feature allows you to direct specific percentages of inference requests (e.g., 80% to the new model, 20% to the previous) without custom code or intermediate services like Dataflow or Cloud Run.

## Pregunta 144

Contexto: [topics:106](#topics-106)
You are developing an image recognition model using PyTorch based on ResNet50 architecture. Your code is working fine on your local laptop on a small subsample. Your full dataset has 200k labeled images. You want to quickly scale your training workload while minimizing cost. You plan to use 4 V100 GPUs. What should you do?

**A.** Create a Google Kubernetes Engine cluster with a node pool that has 4 V100 GPUs. Prepare and submit a TFJob operator to this node pool.

**B.** Create a Vertex AI Workbench user-managed notebooks instance with 4 V100 GPUs, and use it to train your model.

**C.** Package your code with Setuptools, and use a pre-built container. Train your model with Vertex AI using a custom tier that contains the required GPUs.

**D.** Configure a Compute Engine VM with all the dependencies that launches the training. Train your model with Vertex AI using a custom tier that contains the required GPUs.

**Respuesta de la fuente:** C

**Explicación:** Option A is incorrect because TFJob operators are designed for TensorFlow, whereas the scenario specifies a PyTorch model.
Option B is less suitable because Vertex AI Workbench notebooks are intended for interactive development and prototyping rather than managed, scalable training jobs, making them less cost-effective for this workload.
Option C is the correct approach as it leverages Vertex AI Custom Training, which allows you to package your PyTorch code using Setuptools and run it on a pre-built container with custom GPU specifications. This method provides a serverless, pay-per-use environment that minimizes operational overhead and cost compared to managing persistent VMs or clusters.

## Pregunta 145

Contexto: [topics:106](#topics-106)
You have trained a DNN regressor with TensorFlow to predict housing prices using a set of predictive features. Your default precision is tf.float64, and you use a standard TensorFlow estimator:

[Imagen: sin descripción]

Your model performs well, but just before deploying it to production, you discover that your current serving latency is 10ms @ 90 percentile and you currently serve on CPUs. Your production requirements expect a model latency of 8ms @ 90 percentile. You're willing to accept a small decrease in performance in order to reach the latency requirement.
Therefore your plan is to improve latency while evaluating how much the model's prediction decreases. What should you first try to quickly lower the serving latency?
Imagen · question_text · sin descripción
![Imagen original](imagenes/5dab808de6163c379fc9.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
estimator = tf.estimator.DNNRegressor (
feature_columns=[YOUR_LIST_OF_FEATURES],
hidden_units=[1024, 512, 256],
dropout=None)
```

**A.** Switch from CPU to GPU serving.

**B.** Apply quantization to your SavedModel by reducing the floating point precision to tf.float16.

**C.** Increase the dropout rate to 0.8 and retrain your model.

**D.** Increase the dropout rate to 0.8 in _PREDICT mode by adjusting the TensorFlow Serving parameters.

**Respuesta de la fuente:** B

**Explicación:** Quantization reduces model size and inference latency by converting weights from tf.float64 to lower-precision formats like tf.float16 or int8, which accelerates computation on CPUs and reduces memory bandwidth usage.
This optimization is quick to apply post-training compared to hardware changes or retraining, and it allows for evaluating the trade-off between latency improvement and potential minor accuracy degradation.

## Pregunta 146

Contexto: [topics:106](#topics-106)
You work on the data science team at a manufacturing company. You are reviewing the company’s historical sales data, which has hundreds of millions of records. For your exploratory data analysis, you need to calculate descriptive statistics such as mean, median, and mode; conduct complex statistical tests for hypothesis testing; and plot variations of the features over time. You want to use as much of the sales data as possible in your analyses while minimizing computational resources. What should you do?

**A.** Visualize the time plots in Google Data Studio. Import the dataset into Vertex Al Workbench user-managed notebooks. Use this data to calculate the descriptive statistics and run the statistical analyses.

**B.** Spin up a Vertex Al Workbench user-managed notebooks instance and import the dataset. Use this data to create statistical and visual analyses.

**C.** Use BigQuery to calculate the descriptive statistics. Use Vertex Al Workbench user-managed notebooks to visualize the time plots and run the statistical analyses.

**D.** Use BigQuery to calculate the descriptive statistics, and use Google Data Studio to visualize the time plots. Use Vertex Al Workbench user-managed notebooks to run the statistical analyses.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 147

Contexto: [topics:106](#topics-106)
Your data science team needs to rapidly experiment with various features, model architectures, and hyperparameters. They need to track the accuracy metrics for various experiments and use an API to query the metrics over time. What should they use to track and report their experiments while minimizing manual effort?

**A.** Use Vertex Al Pipelines to execute the experiments. Query the results stored in MetadataStore using the Vertex Al API.

**B.** Use Vertex Al Training to execute the experiments. Write the accuracy metrics to BigQuery, and query the results using the BigQuery API.

**C.** Use Vertex Al Training to execute the experiments. Write the accuracy metrics to Cloud Monitoring, and query the results using the Monitoring API.

**D.** Use Vertex Al Workbench user-managed notebooks to execute the experiments. Collect the results in a shared Google Sheets file, and query the results using the Google Sheets API.

**Respuesta de la fuente:** A

**Explicación:** Vertex AI Pipelines automates the orchestration of ML workflows, enabling rapid experimentation with minimal manual intervention. Vertex ML Metadata automatically tracks experiment runs, hyperparameters, and metrics like accuracy, eliminating the need for custom logging solutions. The Vertex AI API provides programmatic access to this metadata store, allowing for efficient querying and comparison of experimental results over time.

## Pregunta 148

Contexto: [topics:106](#topics-106)
You are training an ML model using data stored in BigQuery that contains several values that are considered Personally Identifiable Information (PII). You need to reduce the sensitivity of the dataset before training your model. Every column is critical to your model. How should you proceed?

**A.** Using Dataflow, ingest the columns with sensitive data from BigQuery, and then randomize the values in each sensitive column.

**B.** Use the Cloud Data Loss Prevention (DLP) API to scan for sensitive data, and use Dataflow with the DLP API to encrypt sensitive values with Format Preserving Encryption.

**C.** Use the Cloud Data Loss Prevention (DLP) API to scan for sensitive data, and use Dataflow to replace all sensitive data by using the encryption algorithm AES-256 with a salt.

**D.** Before training, use BigQuery to select only the columns that do not contain sensitive data. Create an authorized view of the data so that sensitive values cannot be accessed by unauthorized individuals.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Format Preserving Encryption (FPE) allows sensitive PII values to be encrypted while maintaining the original data type and format. This ensures that every column remains usable for machine learning training without altering the statistical distribution or rendering the data unreadable, unlike randomization or standard encryption which would degrade model utility.

## Pregunta 149

Contexto: [topics:106](#topics-106)
You recently deployed an ML model. Three months after deployment, you notice that your model is underperforming on certain subgroups, thus potentially leading to biased results. You suspect that the inequitable performance is due to class imbalances in the training data, but you cannot collect more data. What should you do? (Choose two.)

**A.** Remove training examples of high-performing subgroups, and retrain the model.

**B.** Add an additional objective to penalize the model more for errors made on the minority class, and retrain the model

**C.** Remove the features that have the highest correlations with the majority class.

**D.** Upsample or reweight your existing training data, and retrain the model

**E.** Redeploy the model, and provide a label explaining the model's behavior to users.

**Respuesta de la fuente:** B, D

**Explicación:** To address class imbalance without new data, you should use techniques that balance the influence of minority classes during training.

Option B (cost-sensitive learning) penalizes errors on minority samples more heavily, forcing the model to prioritize their accurate classification.

Option D (upsampling or reweighting) adjusts the dataset distribution so the model encounters underrepresented patterns more frequently or with higher importance, thereby reducing bias.

## Pregunta 150

Contexto: [topics:106](#topics-106)
You are working on a binary classification ML algorithm that detects whether an image of a classified scanned document contains a company’s logo. In the dataset, 96% of examples don’t have the logo, so the dataset is very skewed. Which metric would give you the most confidence in your model?

**A.** Precision

**B.** Recall

**C.** RMSE

**D.** F1 score

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 151

Contexto: [topics:106](#topics-106)
While running a model training pipeline on Vertex Al, you discover that the evaluation step is failing because of an out-of-memory error. You are currently using TensorFlow Model Analysis (TFMA) with a standard Evaluator TensorFlow Extended (TFX) pipeline component for the evaluation step. You want to stabilize the pipeline without downgrading the evaluation quality while minimizing infrastructure overhead. What should you do?

**A.** Include the flag -runner=DataflowRunner in beam_pipeline_args to run the evaluation step on Dataflow.

**B.** Move the evaluation step out of your pipeline and run it on custom Compute Engine VMs with sufficient memory.

**C.** Migrate your pipeline to Kubeflow hosted on Google Kubernetes Engine, and specify the appropriate node parameters for the evaluation step.

**D.** Add tfma.MetricsSpec () to limit the number of metrics in the evaluation step.

**Respuesta de la fuente:** A

**Explicación:** TensorFlow Model Analysis (TFMA) uses Apache Beam for distributed processing. By default, the Evaluator may run on a local runner, which is susceptible to out-of-memory errors on large datasets.
Switching to DataflowRunner (Option A) offloads this work to Google Cloud's serverless managed service, providing automatic scaling and parallelism to handle memory-intensive tasks.
This stabilizes the pipeline without reducing evaluation metrics or adding infrastructure management overhead, unlike moving to custom VMs or Kubeflow.

## Pregunta 152

Contexto: [topics:106](#topics-106)
You are developing an ML model using a dataset with categorical input variables. You have randomly split half of the data into training and test sets. After applying one-hot encoding on the categorical variables in the training set, you discover that one categorical variable is missing from the test set. What should you do?

**A.** Use sparse representation in the test set.

**B.** Randomly redistribute the data, with 70% for the training set and 30% for the test set

**C.** Apply one-hot encoding on the categorical variables in the test data

**D.** Collect more data representing all categories

**Respuesta de la fuente:** C

**Explicación:** In a production or validation workflow, you must apply the same transformation logic derived from the training set to the test set to maintain feature space consistency. One-hot encoding should be fitted on the training data and then transformed on the test data; any categories in the test set that were unseen during training are typically ignored (dropped) rather than generating new columns, ensuring the input vector dimensions match.
Reference: Scikit-learn preprocessing guidelines for categorical features.

## Pregunta 153

Contexto: [topics:106](#topics-106)
You work for a bank and are building a random forest model for fraud detection. You have a dataset that includes transactions, of which 1% are identified as fraudulent. Which data transformation strategy would likely improve the performance of your classifier?

**A.** Modify the target variable using the Box-Cox transformation.

**B.** Z-normalize all the numeric features.

**C.** Oversample the fraudulent transaction 10 times.

**D.** Log transform all numeric features.

**Respuesta de la fuente:** C

**Explicación:** The dataset exhibits significant class imbalance with only 1% fraudulent transactions. Oversampling the minority class addresses this bias by providing the Random Forest model with more examples of fraud, thereby improving its ability to detect fraudulent patterns.

## Pregunta 154

Contexto: [topics:106](#topics-106)
You are developing a classification model to support predictions for your company’s various products. The dataset you were given for model development has class imbalance You need to minimize false positives and false negatives What evaluation metric should you use to properly train the model?

**A.** F1 score

**B.** Recall

**C.** Accuracy

**D.** Precision

**Respuesta de la fuente:** A

**Explicación:** The F1 score is the correct metric because it is the harmonic mean of precision and recall, effectively balancing the trade-off between minimizing false positives and false negatives.
Accuracy is misleading in imbalanced datasets as it can be high even if the model fails to predict the minority class.
Since the goal is to optimize both error types simultaneously, F1 provides a more robust evaluation than using precision or recall alone.

## Pregunta 155

Contexto: [topics:106](#topics-106)
You are training an object detection machine learning model on a dataset that consists of three million X-ray images, each roughly 2 GB in size. You are using Vertex AI Training to run a custom training application on a Compute Engine instance with 32-cores, 128 GB of RAM, and 1 NVIDIA P100 GPU. You notice that model training is taking a very long time. You want to decrease training time without sacrificing model performance. What should you do?

**A.** Increase the instance memory to 512 GB, and increase the batch size.

**B.** Replace the NVIDIA P100 GPU with a K80 GPU in the training job.

**C.** Enable early stopping in your Vertex AI Training job.

**D.** Use the tf.distribute.Strategy API and run a distributed training job.

**Respuesta de la fuente:** D

**Explicación:** The tf.distribute.Strategy API enables data parallelism, allowing the training workload to be distributed across the 32 CPU cores and GPU resources of the Compute Engine instance. This significantly accelerates processing for large datasets like 3 million X-ray images without reducing model performance or stopping training prematurely.

## Pregunta 156

Contexto: [topics:106](#topics-106)
You need to build classification workflows over several structured datasets currently stored in BigQuery. Because you will be performing the classification several times, you want to complete the following steps without writing code: exploratory data analysis, feature selection, model building, training, and hyperparameter tuning and serving. What should you do?

**A.** Train a TensorFlow model on Vertex AI.

**B.** Train a classification Vertex AutoML model.

**C.** Run a logistic regression job on BigQuery ML.

**D.** Use scikit-learn in Vertex AI Workbench user-managed notebooks with pandas library.

**Respuesta de la fuente:** B

**Explicación:** Vertex AutoML Tables is the managed service designed to build ML models from structured data (like BigQuery) with a no-code interface. It automates the entire pipeline requested—EDA, feature selection, model building, training, and hyperparameter tuning—allowing users to deploy models without writing code.
In contrast, TensorFlow (A), BigQuery ML (C), and Vertex AI Workbench with scikit-learn (D) all require writing SQL or Python code.

## Pregunta 157

Contexto: [topics:106](#topics-106)
You recently developed a deep learning model. To test your new model, you trained it for a few epochs on a large dataset. You observe that the training and validation losses barely changed during the training run. You want to quickly debug your model. What should you do first?

**A.** Verify that your model can obtain a low loss on a small subset of the dataset

**B.** Add handcrafted features to inject your domain knowledge into the model

**C.** Use the Vertex AI hyperparameter tuning service to identify a better learning rate

**D.** Use hardware accelerators and train your model for more epochs

**Respuesta de la fuente:** A

**Explicación:** When training and validation losses fail to decrease, the priority is to isolate whether the issue stems from the model architecture/code or the dataset/infrastructure. Testing on a small subset allows for rapid iteration to verify if the model can overfit (learn) at all; if it cannot, there is likely a bug in the implementation or hyperparameters rather than insufficient data.

## Pregunta 158

Contexto: [topics:106](#topics-106)
You are a data scientist at an industrial equipment manufacturing company. You are developing a regression model to estimate the power consumption in the company’s manufacturing plants based on sensor data collected from all of the plants. The sensors collect tens of millions of records every day. You need to schedule daily training runs for your model that use all the data collected up to the current date. You want your model to scale smoothly and require minimal development work. What should you do?

**A.** Develop a custom TensorFlow regression model, and optimize it using Vertex AI Training.

**B.** Develop a regression model using BigQuery ML.

**C.** Develop a custom scikit-learn regression model, and optimize it using Vertex AI Training.

**D.** Develop a custom PyTorch regression model, and optimize it using Vertex AI Training.

**Respuesta de la fuente:** B

**Explicación:** BigQuery ML is the optimal choice because it provides a serverless, low-code environment that directly trains models on existing data within BigQuery, satisfying the 'minimal development work' requirement.
It natively handles massive datasets (tens of millions of records) without requiring custom infrastructure management or external framework integration like TensorFlow or scikit-learn.

## Pregunta 159

Contexto: [topics:106](#topics-106)
Your organization manages an online message board. A few months ago, you discovered an increase in toxic language and bullying on the message board. You deployed an automated text classifier that flags certain comments as toxic or harmful. Now some users are reporting that benign comments referencing their religion are being misclassified as abusive. Upon further inspection, you find that your classifier's false positive rate is higher for comments that reference certain underrepresented religious groups. Your team has a limited budget and is already overextended. What should you do?

**A.** Add synthetic training data where those phrases are used in non-toxic ways.

**B.** Remove the model and replace it with human moderation.

**C.** Replace your model with a different text classifier.

**D.** Raise the threshold for comments to be considered toxic or harmful.

**Respuesta de la fuente:** A

**Explicación:** The correct answer is A because it directly addresses the root cause: model bias against underrepresented groups. Adding synthetic training data containing benign religious references teaches the classifier to distinguish between toxic and non-toxic contexts, thereby reducing false positives without incurring the high cost or loss of automation efficiency associated with human moderation (Option B) or replacing the entire system (Option C). While raising the threshold (Option D) might temporarily reduce false positives, it compromises the model's ability to detect actual toxicity (increasing false negatives) and fails to correct the underlying algorithmic bias.

## Pregunta 160

Contexto: [topics:106](#topics-106)
You work for a magazine distributor and need to build a model that predicts which customers will renew their subscriptions for the upcoming year. Using your company’s historical data as your training set, you created a TensorFlow model and deployed it to Vertex AI. You need to determine which customer attribute has the most predictive power for each prediction served by the model. What should you do?

**A.** Stream prediction results to BigQuery. Use BigQuery’s CORR(X1, X2) function to calculate the Pearson correlation coefficient between each feature and the target variable.

**B.** Use Vertex Explainable AI. Submit each prediction request with the explain' keyword to retrieve feature attributions using the sampled Shapley method.

**C.** Use Vertex AI Workbench user-managed notebooks to perform a Lasso regression analysis on your model, which will eliminate features that do not provide a strong signal.

**D.** Use the What-If tool in Google Cloud to determine how your model will perform when individual features are excluded. Rank the feature importance in order of those that caused the most significant performance drop when removed from the model.

**Respuesta de la fuente:** B

**Explicación:** Vertex Explainable AI uses the sampled Shapley method to calculate feature attributions for each individual prediction request. This directly answers the requirement to determine predictive power at the level of 'each prediction served' by providing specific importance scores per instance.
Other options like BigQuery correlations (A) measure global statistical relationships rather than model-specific attributions, while Lasso (C) and What-If (D) are not standard methods for per-prediction attribution in this context.

## Pregunta 161

Contexto: [topics:106](#topics-106)
You are an ML engineer at a manufacturing company. You are creating a classification model for a predictive maintenance use case. You need to predict whether a crucial machine will fail in the next three days so that the repair crew has enough time to fix the machine before it breaks. Regular maintenance of the machine is relatively inexpensive, but a failure would be very costly. You have trained several binary classifiers to predict whether the machine will fail, where a prediction of 1 means that the ML model predicts a failure.

You are now evaluating each model on an evaluation dataset. You want to choose a model that prioritizes detection while ensuring that more than 50% of the maintenance jobs triggered by your model address an imminent machine failure. Which model should you choose?

**A.** The model with the highest area under the receiver operating characteristic curve (AUC ROC) and precision greater than 0.5

**B.** The model with the lowest root mean squared error (RMSE) and recall greater than 0.5.

**C.** The model with the highest recall where precision is greater than 0.5.

**D.** The model with the highest precision where recall is greater than 0.5.

**Respuesta de la fuente:** C

**Explicación:** The requirement to prioritize detection means maximizing recall, as recall measures the proportion of actual failures correctly identified.
The constraint that more than 50% of triggered jobs address imminent failures defines a precision threshold greater than 0.5.
Therefore, the optimal strategy is to select the model with the highest recall while satisfying the minimum precision requirement.

## Pregunta 162

Contexto: [topics:106](#topics-106)
You built a custom ML model using scikit-learn. Training time is taking longer than expected. You decide to migrate your model to Vertex AI Training, and you want to improve the model’s training time. What should you try out first?

**A.** Train your model in a distributed mode using multiple Compute Engine VMs.

**B.** Train your model using Vertex AI Training with CPUs.

**C.** Migrate your model to TensorFlow, and train it using Vertex AI Training.

**D.** Train your model using Vertex AI Training with GPUs.

**Respuesta de la fuente:** B

**Explicación:** Scikit-learn primarily relies on CPU-based computations and lacks native GPU support for most algorithms, making GPU acceleration (Option D) ineffective without significant code changes. Vertex AI provides prebuilt containers with native scikit-learn support optimized for CPU instances, allowing for immediate migration with minimal code modification.

Distributed training (Option A) adds complexity and is a subsequent optimization step, while switching frameworks (Option C) violates the goal of migrating the existing model.

## Pregunta 163

Contexto: [topics:106](#topics-106)
You are an ML engineer at a retail company. You have built a model that predicts a coupon to offer an ecommerce customer at checkout based on the items in their cart. When a customer goes to checkout, your serving pipeline, which is hosted on Google Cloud, joins the customer's existing cart with a row in a BigQuery table that contains the customers' historic purchase behavior and uses that as the model's input. The web team is reporting that your model is returning predictions too slowly to load the coupon offer with the rest of the web page. How should you speed up your model's predictions?

**A.** Attach an NVIDIA P100 GPU to your deployed model’s instance.

**B.** Use a low latency database for the customers’ historic purchase behavior.

**C.** Deploy your model to more instances behind a load balancer to distribute traffic.

**D.** Create a materialized view in BigQuery with the necessary data for predictions.

**Respuesta de la fuente:** B

**Explicación:** The bottleneck is the high-latency join operation in BigQuery, which is optimized for batch analytical processing rather than low-latency singleton reads required for real-time serving. Moving the historical purchase data to a low-latency database (like Redis, Cloud Memorystore, or Datastore) allows the serving pipeline to retrieve customer context instantly before sending it to the model, significantly reducing end-to-end prediction time.

## Pregunta 164

Contexto: [topics:106](#topics-106)
You work for a small company that has deployed an ML model with autoscaling on Vertex AI to serve online predictions in a production environment. The current model receives about 20 prediction requests per hour with an average response time of one second. You have retrained the same model on a new batch of data, and now you are canary testing it, sending ~10% of production traffic to the new model. During this canary test, you notice that prediction requests for your new model are taking between 30 and 180 seconds to complete. What should you do?

**A.** Submit a request to raise your project quota to ensure that multiple prediction services can run concurrently.

**B.** Turn off auto-scaling for the online prediction service of your new model. Use manual scaling with one node always available.

**C.** Remove your new model from the production environment. Compare the new model and existing model codes to identify the cause of the performance bottleneck.

**D.** Remove your new model from the production environment. For a short trial period, send all incoming prediction requests to BigQuery. Request batch predictions from your new model, and then use the Data Labeling Service to validate your model’s performance before promoting it to production.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 165

Contexto: [topics:106](#topics-106)
You want to train an AutoML model to predict house prices by using a small public dataset stored in BigQuery. You need to prepare the data and want to use the simplest, most efficient approach. What should you do?

**A.** Write a query that preprocesses the data by using BigQuery and creates a new table. Create a Vertex AI managed dataset with the new table as the data source.

**B.** Use Dataflow to preprocess the data. Write the output in TFRecord format to a Cloud Storage bucket.

**C.** Write a query that preprocesses the data by using BigQuery. Export the query results as CSV files, and use those files to create a Vertex AI managed dataset.

**D.** Use a Vertex AI Workbench notebook instance to preprocess the data by using the pandas library. Export the data as CSV files, and use those files to create a Vertex AI managed dataset.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Vertex AI supports creating managed datasets directly from BigQuery tables or SQL queries, eliminating the need to export data.
This approach is the simplest and most efficient as it avoids ETL overhead, format conversion (like CSV), and moving data outside the managed environment.

## Pregunta 166

Contexto: [topics:106](#topics-106)
You developed a Vertex AI ML pipeline that consists of preprocessing and training steps and each set of steps runs on a separate custom Docker image. Your organization uses GitHub and GitHub Actions as CI/CD to run unit and integration tests. You need to automate the model retraining workflow so that it can be initiated both manually and when a new version of the code is merged in the main branch. You want to minimize the steps required to build the workflow while also allowing for maximum flexibility. How should you configure the CI/CD workflow?

**A.** Trigger a Cloud Build workflow to run tests, build custom Docker images, push the images to Artifact Registry, and launch the pipeline in Vertex AI Pipelines.

**B.** Trigger GitHub Actions to run the tests, launch a job on Cloud Run to build custom Docker images, push the images to Artifact Registry, and launch the pipeline in Vertex AI Pipelines.

**C.** Trigger GitHub Actions to run the tests, build custom Docker images, push the images to Artifact Registry, and launch the pipeline in Vertex AI Pipelines.

**D.** Trigger GitHub Actions to run the tests, launch a Cloud Build workflow to build custom Docker images, push the images to Artifact Registry, and launch the pipeline in Vertex AI Pipelines.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it adheres to the principle of separating concerns: GitHub Actions handles repository-specific logic like testing and triggering on merge events, while delegating infrastructure tasks to Google Cloud services.
Cloud Build is the native, optimized service for building Docker images and pushing them to Artifact Registry, ensuring better performance and reliability than running these resource-intensive tasks within GitHub Actions runners.
This hybrid approach minimizes complexity by using each tool for its intended purpose, providing maximum flexibility and robustness for the CI/CD pipeline.

## Pregunta 167

Contexto: [topics:106](#topics-106)
You are working with a dataset that contains customer transactions. You need to build an ML model to predict customer purchase behavior. You plan to develop the model in BigQuery ML, and export it to Cloud Storage for online prediction. You notice that the input data contains a few categorical features, including product category and payment method. You want to deploy the model as quickly as possible. What should you do?

**A.** Use the TRANSFORM clause with the ML.ONE_HOT_ENCODER function on the categorical features at model creation and select the categorical and non-categorical features.

**B.** Use the ML.ONE_HOT_ENCODER function on the categorical features and select the encoded categorical features and non-categorical features as inputs to create your model.

**C.** Use the CREATE MODEL statement and select the categorical and non-categorical features.

**D.** Use the ML.MULTI_HOT_ENCODER function on the categorical features, and select the encoded categorical features and non-categorical features as inputs to create your model.

**Respuesta de la fuente:** C

**Explicación:** BigQuery ML automatically detects and processes categorical features (such as product category and payment method) when you pass them directly to the CREATE MODEL statement.
Manually applying ML.ONE_HOT_ENCODER is unnecessary for standard deployment and adds complexity, while using the TRANSFORM clause restricts the model inputs exclusively to the transformed columns, which would exclude non-categorical features unless also explicitly listed in the transform block.
Therefore, simply selecting both categorical and non-categorical features in the CREATE MODEL statement is the fastest and most efficient approach.

## Pregunta 168

Contexto: [topics:106](#topics-106)
You need to develop an image classification model by using a large dataset that contains labeled images in a Cloud Storage bucket. What should you do?

**A.** Use Vertex AI Pipelines with the Kubeflow Pipelines SDK to create a pipeline that reads the images from Cloud Storage and trains the model.

**B.** Use Vertex AI Pipelines with TensorFlow Extended (TFX) to create a pipeline that reads the images from Cloud Storage and trains the model.

**C.** Import the labeled images as a managed dataset in Vertex AI and use AutoML to train the model.

**D.** Convert the image dataset to a tabular format using Dataflow Load the data into BigQuery and use BigQuery ML to train the model.

**Respuesta de la fuente:** C

**Explicación:** The question asks for the appropriate method to develop an image classification model using a large dataset in Cloud Storage.
Vertex AI AutoML (Option C) is designed specifically for image classification tasks where users provide labeled images in Cloud Storage, automating the training process without requiring custom pipeline code.
While TFX and Kubeflow (Options A and B) are powerful for building complex, custom ML pipelines, they are overkill if the goal is simply to train a standard image classification model using managed services.
BigQuery ML (Option D) is not suitable for raw image data as it requires tabular or pre-processed feature formats.

## Pregunta 169

Contexto: [topics:106](#topics-106)
You are developing a model to detect fraudulent credit card transactions. You need to prioritize detection, because missing even one fraudulent transaction could severely impact the credit card holder. You used AutoML to tram a model on users' profile information and credit card transaction data After training the initial model, you notice that the model is failing to detect many fraudulent transactions. How should you adjust the training parameters in AutoML to improve model performance? (Choose two.)

**A.** Increase the score threshold

**B.** Decrease the score threshold.

**C.** Add more positive examples to the training set

**D.** Add more negative examples to the training set

**E.** Reduce the maximum number of node hours for training

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 170

Contexto: [topics:106](#topics-106)
You need to deploy a scikit-leam classification model to production. The model must be able to serve requests 24/7, and you expect millions of requests per second to the production application from 8 am to 7 pm. You need to minimize the cost of deployment. What should you do?

**A.** Deploy an online Vertex AI prediction endpoint. Set the max replica count to 1

**B.** Deploy an online Vertex AI prediction endpoint. Set the max replica count to 100

**C.** Deploy an online Vertex AI prediction endpoint with one GPU per replica. Set the max replica count to 1

**D.** Deploy an online Vertex AI prediction endpoint with one GPU per replica. Set the max replica count to 100

**Respuesta de la fuente:** B

**Explicación:** scikit-learn is a CPU-based library and does not support GPU acceleration for inference, making options with GPUs (C and D) technically incorrect.
Between the CPU options, serving millions of requests per second requires significant parallelism; setting the max replica count to 1 (Option A) would create a severe bottleneck and fail to meet the performance requirements.
Setting the max replica count to 100 (Option B) provides the necessary capacity to handle the high-volume traffic during peak hours while allowing Vertex AI's autoscaling to minimize costs by reducing replicas during non-peak times.

## Pregunta 171

Contexto: [topics:106](#topics-106)
You work with a team of researchers to develop state-of-the-art algorithms for financial analysis. Your team develops and debugs complex models in TensorFlow. You want to maintain the ease of debugging while also reducing the model training time. How should you set up your training environment?

**A.** Configure a v3-8 TPU VM. SSH into the VM to train and debug the model.

**B.** Configure a v3-8 TPU node. Use Cloud Shell to SSH into the Host VM to train and debug the model.

**C.** Configure a n1 -standard-4 VM with 4 NVIDIA P100 GPUs. SSH into the VM and use ParameterServerStraregv to train the model.

**D.** Configure a n1-standard-4 VM with 4 NVIDIA P100 GPUs. SSH into the VM and use MultiWorkerMirroredStrategy to train the model.

**Respuesta de la fuente:** D

**Explicación:** Option D is the correct answer because it provides a GPU-accelerated environment (4 NVIDIA P100 GPUs) that significantly reduces training time compared to CPU-only setups or TPUs in certain contexts. Using SSH into a VM offers a standard Linux environment, making it easier to debug complex models using familiar tools than the more restricted TPU host environment. Although MultiWorkerMirroredStrategy is technically for distributed training across multiple workers, in the context of this specific certification question, it represents the advanced scaling strategy intended to reduce time while maintaining SSH-based debugging accessibility.

## Pregunta 172

Contexto: [topics:106](#topics-106)
You created an ML pipeline with multiple input parameters. You want to investigate the tradeoffs between different parameter combinations. The parameter options are
•	Input dataset
•	Max tree depth of the boosted tree regressor
•	Optimizer learning rate

You need to compare the pipeline performance of the different parameter combinations measured in F1 score, time to train, and model complexity. You want your approach to be reproducible, and track all pipeline runs on the same platform. What should you do?

**A.** 1. Use BigQueryML to create a boosted tree regressor, and use the hyperparameter tuning capability.
2. Configure the hyperparameter syntax to select different input datasets: max tree depths, and optimizer learning rates. Choose the grid search option.

**B.** 1. Create a Vertex AI pipeline with a custom model training job as part of the pipeline. Configure the pipeline’s parameters to include those you are investigating.
2. In the custom training step, use the Bayesian optimization method with F1 score as the target to maximize.

**C.** 1. Create a Vertex AI Workbench notebook for each of the different input datasets.
2. In each notebook, run different local training jobs with different combinations of the max tree depth and optimizer learning rate parameters.
3. After each notebook finishes, append the results to a BigQuery table.

**D.** 1. Create an experiment in Vertex AI Experiments.
2. Create a Vertex AI pipeline with a custom model training job as part of the pipeline. Configure the pipeline’s parameters to include those you are investigating.
3. Submit multiple runs to the same experiment, using different values for the parameters.

**Respuesta de la fuente:** D

**Explicación:** Vertex AI Experiments is the dedicated service for tracking and comparing multiple runs of an ML pipeline to analyze parameter tradeoffs.
It allows you to group runs within a single experiment, ensuring reproducibility by logging all configurations, metrics (F1 score, time), and artifacts in one place.
Using Vertex AI Pipelines provides the structured workflow needed to execute these custom training jobs consistently.

## Pregunta 173

Contexto: [topics:106](#topics-106)
You received a training-serving skew alert from a Vertex AI Model Monitoring job running in production. You retrained the model with more recent training data, and deployed it back to the Vertex AI endpoint, but you are still receiving the same alert. What should you do?

**A.** Update the model monitoring job to use a lower sampling rate.

**B.** Update the model monitoring job to use the more recent training data that was used to retrain the model.

**C.** Temporarily disable the alert. Enable the alert again after a sufficient amount of new production traffic has passed through the Vertex AI endpoint.

**D.** Temporarily disable the alert until the model can be retrained again on newer training data. Retrain the model again after a sufficient amount of new production traffic has passed through the Vertex AI endpoint.

**Respuesta de la fuente:** B

**Explicación:** Vertex AI Model Monitoring compares production data against a baseline derived from the training dataset specified in the monitoring job configuration. Since the model was retrained but the monitoring job still references the old training data, it continues to detect skew based on the outdated baseline. Updating the monitoring job to use the new training data aligns the reference distribution with the current model's expectations.

## Pregunta 174

Contexto: [topics:106](#topics-106)
You developed a custom model by using Vertex AI to forecast the sales of your company’s products based on historical transactional data. You anticipate changes in the feature distributions and the correlations between the features in the near future. You also expect to receive a large volume of prediction requests. You plan to use Vertex AI Model Monitoring for drift detection and you want to minimize the cost. What should you do?

**A.** Use the features for monitoring. Set a monitoring-frequency value that is higher than the default.

**B.** Use the features for monitoring. Set a prediction-sampling-rate value that is closer to 1 than 0.

**C.** Use the features and the feature attributions for monitoring. Set a monitoring-frequency value that is lower than the default.

**D.** Use the features and the feature attributions for monitoring. Set a prediction-sampling-rate value that is closer to 0 than 1.

**Respuesta de la fuente:** D

**Explicación:** To detect changes in feature distributions and correlations effectively, you must monitor both features and their attributions, making options A and B insufficient.
Since the goal is to minimize cost amidst a large volume of requests, lowering the prediction-sampling-rate (closer to 0) reduces the number of predictions logged for analysis without sacrificing statistical significance for drift detection.
In contrast, increasing monitoring frequency or sampling rate would increase costs.

## Pregunta 175

Contexto: [topics:106](#topics-106)
You have recently trained a scikit-learn model that you plan to deploy on Vertex AI. This model will support both online and batch prediction. You need to preprocess input data for model inference. You want to package the model for deployment while minimizing additional code. What should you do?

**A.** 1. Upload your model to the Vertex AI Model Registry by using a prebuilt scikit-ieam prediction container.
2. Deploy your model to Vertex AI Endpoints, and create a Vertex AI batch prediction job that uses the instanceConfig.instanceType setting to transform your input data.

**B.** 1. Wrap your model in a custom prediction routine (CPR). and build a container image from the CPR local model.
2. Upload your scikit learn model container to Vertex AI Model Registry.
3. Deploy your model to Vertex AI Endpoints, and create a Vertex AI batch prediction job

**C.** 1. Create a custom container for your scikit learn model.
2. Define a custom serving function for your model.
3. Upload your model and custom container to Vertex AI Model Registry.
4. Deploy your model to Vertex AI Endpoints, and create a Vertex AI batch prediction job.

**D.** 1. Create a custom container for your scikit learn model.
2. Upload your model and custom container to Vertex AI Model Registry.
3. Deploy your model to Vertex AI Endpoints, and create a Vertex AI batch prediction job that uses the instanceConfig.instanceType setting to transform your input data.

**Respuesta de la fuente:** B

**Explicación:** Pre-built scikit-learn containers only handle prediction, not input preprocessing. Custom Prediction Routines (CPR) allow you to define pre/post-processing logic with minimal code by handling the server infrastructure automatically, unlike full custom containers which require manual Docker and HTTP server setup.

## Pregunta 176

Contexto: [topics:106](#topics-106)
You work for a food product company. Your company’s historical sales data is stored in BigQuery.You need to use Vertex AI’s custom training service to train multiple TensorFlow models that read the data from BigQuery and predict future sales. You plan to implement a data preprocessing algorithm that performs mm-max scaling and bucketing on a large number of features before you start experimenting with the models. You want to minimize preprocessing time, cost, and development effort. How should you configure this workflow?

**A.** Write the transformations into Spark that uses the spark-bigquery-connector, and use Dataproc to preprocess the data.

**B.** Write SQL queries to transform the data in-place in BigQuery.

**C.** Add the transformations as a preprocessing layer in the TensorFlow models.

**D.** Create a Dataflow pipeline that uses the BigQuerylO connector to ingest the data, process it, and write it back to BigQuery.

**Respuesta de la fuente:** B

**Explicación:** Performing preprocessing in BigQuery using SQL (Option B) leverages the data warehouse's massively parallel processing capabilities to minimize time and cost. This approach avoids the overhead of moving data to Spark or Dataflow clusters and eliminates the need for complex custom code development, satisfying all optimization criteria.

## Pregunta 177

Contexto: [topics:106](#topics-106)
You have created a Vertex AI pipeline that includes two steps. The first step preprocesses 10 TB data completes in about 1 hour, and saves the result in a Cloud Storage bucket. The second step uses the processed data to train a model. You need to update the model’s code to allow you to test different algorithms. You want to reduce pipeline execution time and cost while also minimizing pipeline changes. What should you do?

**A.** Add a pipeline parameter and an additional pipeline step. Depending on the parameter value, the pipeline step conducts or skips data preprocessing, and starts model training.

**B.** Create another pipeline without the preprocessing step, and hardcode the preprocessed Cloud Storage file location for model training.

**C.** Configure a machine with more CPU and RAM from the compute-optimized machine family for the data preprocessing step.

**D.** Enable caching for the pipeline job, and disable caching for the model training step.

**Respuesta de la fuente:** D

**Explicación:** Vertex AI Pipeline caching allows reusing outputs from previous runs when inputs and code remain unchanged. Since the preprocessing step processes static data, enabling its cache avoids redundant computation of the 10 TB dataset, significantly reducing time and cost. Disabling caching for the model training step ensures that changes to the algorithm code are executed fresh rather than returning stale cached results.

## Pregunta 178

Contexto: [topics:106](#topics-106)
You work for a bank. You have created a custom model to predict whether a loan application should be flagged for human review. The input features are stored in a BigQuery table. The model is performing well, and you plan to deploy it to production. Due to compliance requirements the model must provide explanations for each prediction. You want to add this functionality to your model code with minimal effort and provide explanations that are as accurate as possible. What should you do?

**A.** Create an AutoML tabular model by using the BigQuery data with integrated Vertex Explainable AI.

**B.** Create a BigQuery ML deep neural network model and use the ML.EXPLAIN_PREDICT method with the num_integral_steps parameter.

**C.** Upload the custom model to Vertex AI Model Registry and configure feature-based attribution by using sampled Shapley with input baselines.

**D.** Update the custom serving container to include sampled Shapley-based explanations in the prediction outputs.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Vertex AI Model Registry supports Explainable AI for custom-trained models without requiring you to rebuild the model (unlike A and B).
Using sampled Shapley with input baselines provides accurate, feature-based attribution while minimizing development effort compared to modifying a custom serving container (Option D).

## Pregunta 179

Contexto: [topics:106](#topics-106)
You recently used XGBoost to train a model in Python that will be used for online serving. Your model prediction service will be called by a backend service implemented in Golang running on a Google Kubernetes Engine (GKE) cluster. Your model requires pre and postprocessing steps. You need to implement the processing steps so that they run at serving time. You want to minimize code changes and infrastructure maintenance, and deploy your model into production as quickly as possible. What should you do?

**A.** Use FastAPI to implement an HTTP server. Create a Docker image that runs your HTTP server, and deploy it on your organization’s GKE cluster.

**B.** Use FastAPI to implement an HTTP server. Create a Docker image that runs your HTTP server, Upload the image to Vertex AI Model Registry and deploy it to a Vertex AI endpoint.

**C.** Use the Predictor interface to implement a custom prediction routine. Build the custom container, upload the container to Vertex AI Model Registry and deploy it to a Vertex AI endpoint.

**D.** Use the XGBoost prebuilt serving container when importing the trained model into Vertex AI. Deploy the model to a Vertex AI endpoint. Work with the backend engineers to implement the pre- and postprocessing steps in the Golang backend service.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it uses a Custom Prediction Routine (CPR) to encapsulate the XGBoost model along with its required pre- and post-processing logic within a single custom container.
This approach minimizes infrastructure maintenance by leveraging Vertex AI's managed endpoint service while avoiding the need for backend engineers in Golang to replicate complex Python processing steps.
Unlike Option D, which pushes processing to the client, or Options A/B, which require manual server setup, CPRs provide a standardized, low-maintenance way to deploy full-pipeline models quickly.

## Pregunta 180

Contexto: [topics:106](#topics-106)
You recently deployed a pipeline in Vertex AI Pipelines that trains and pushes a model to a Vertex AI endpoint to serve real-time traffic. You need to continue experimenting and iterating on your pipeline to improve model performance. You plan to use Cloud Build for CI/CD You want to quickly and easily deploy new pipelines into production, and you want to minimize the chance that the new pipeline implementations will break in production. What should you do?

**A.** Set up a CI/CD pipeline that builds and tests your source code. If the tests are successful, use the Google. Cloud console to upload the built container to Artifact Registry and upload the compiled pipeline to Vertex AI Pipelines.

**B.** Set up a CI/CD pipeline that builds your source code and then deploys built artifacts into a pre-production environment. Run unit tests in the pre-production environment. If the tests are successful deploy the pipeline to production.

**C.** Set up a CI/CD pipeline that builds and tests your source code and then deploys built artifacts into a pre-production environment. After a successful pipeline run in the pre-production environment, deploy the pipeline to production.

**D.** Set up a CI/CD pipeline that builds and tests your source code and then deploys built artifacts into a pre-production environment. After a successful pipeline run in the pre-production environment, rebuild the source code and deploy the artifacts to production.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it implements a proper staging workflow: building and testing code locally, then validating the full pipeline execution in a pre-production environment before promoting to production. This approach minimizes risk by catching integration or runtime errors that unit tests alone (Option B) might miss, while avoiding unnecessary manual steps (Option A) or redundant rebuilds (Option D).

## Pregunta 181

Contexto: [topics:106](#topics-106)
You work for a bank with strict data governance requirements. You recently implemented a custom model to detect fraudulent transactions. You want your training code to download internal data by using an API endpoint hosted in your project’s network. You need the data to be accessed in the most secure way, while mitigating the risk of data exfiltration. What should you do?

**A.** Enable VPC Service Controls for peerings, and add Vertex AI to a service perimeter.

**B.** Create a Cloud Run endpoint as a proxy to the data. Use Identity and Access Management (IAM) authentication to secure access to the endpoint from the training job.

**C.** Configure VPC Peering with Vertex AI, and specify the network of the training job.

**D.** Download the data to a Cloud Storage bucket before calling the training job.

**Respuesta de la fuente:** A

**Explicación:** VPC Service Controls are specifically designed to enforce service perimeters that restrict data access and mitigate the risk of data exfiltration. By adding Vertex AI to a service perimeter, you ensure that sensitive internal data accessed during training remains within the secure boundary, satisfying strict data governance requirements.

## Pregunta 182

Contexto: [topics:106](#topics-106)
You are deploying a new version of a model to a production Vertex Al endpoint that is serving traffic. You plan to direct all user traffic to the new model. You need to deploy the model with minimal disruption to your application. What should you do?

**A.** 1. Create a new endpoint
2. Create a new model. Set it as the default version. Upload the model to Vertex AI Model Registry
3. Deploy the new model to the new endpoint
4. Update Cloud DNS to point to the new endpoint

**B.** 1. Create a new endpoint
2. Create a new model. Set the parentModel parameter to the model ID of the currently deployed model and set it as the default version. Upload the model to Vertex AI Model Registry
3. Deploy the new model to the new endpoint, and set the new model to 100% of the traffic.

**C.** 1. Create a new model. Set the parentModel parameter to the model ID of the currently deployed model. Upload the model to Vertex AI Model Registry.
2. Deploy the new model to the existing endpoint, and set the new model to 100% of the traffic

**D.** 1. Create a new model. Set it as the default version. Upload the model to Vertex AI Model Registry
2. Deploy the new model to the existing endpoint

**Respuesta de la fuente:** C

**Explicación:** Deploying to the existing endpoint preserves the current URL, eliminating the need for DNS updates and preventing service interruption. Setting the `parentModel` parameter establishes lineage for version tracking without affecting runtime behavior. Finally, explicitly allocating 100% of traffic to the new model ensures a clean cutover from the previous version.

## Pregunta 183

Contexto: [topics:106](#topics-106)
You are training an ML model on a large dataset. You are using a TPU to accelerate the training process. You notice that the training process is taking longer than expected. You discover that the TPU is not reaching its full capacity. What should you do?

**A.** Increase the learning rate

**B.** Increase the number of epochs

**C.** Decrease the learning rate

**D.** Increase the batch size

**Respuesta de la fuente:** D

**Explicación:** TPUs are designed for high-throughput matrix operations and require large amounts of data to keep their processing units fully utilized. A small batch size results in underutilization because the TPU waits for data or processes fewer elements than its architecture supports efficiently. Increasing the batch size ensures that the TPU receives sufficient data volume to maximize computational throughput, thereby reducing training time.

## Pregunta 184

Contexto: [topics:106](#topics-106)
You work for a retail company. You have a managed tabular dataset in Vertex AI that contains sales data from three different stores. The dataset includes several features, such as store name and sale timestamp. You want to use the data to train a model that makes sales predictions for a new store that will open soon. You need to split the data between the training, validation, and test sets. What approach should you use to split the data?

**A.** Use Vertex AI manual split, using the store name feature to assign one store for each set

**B.** Use Vertex AI default data split

**C.** Use Vertex AI chronological split, and specify the sales timestamp feature as the time variable

**D.** Use Vertex AI random split, assigning 70% of the rows to the training set, 10% to the validation set, and 20% to the test set

**Respuesta de la fuente:** C

**Explicación:** The dataset contains timestamps, indicating it is time-series data where temporal patterns (such as seasonality) are critical for accurate sales prediction.
A chronological split ensures the model trains on historical data and validates/tests on more recent data, preventing data leakage that occurs with random splits when future data influences training.
Vertex AI explicitly supports this by allowing users to specify a timestamp column for chronological splitting.

## Pregunta 185

Contexto: [topics:106](#topics-106)
You have developed a BigQuery ML model that predicts customer chum, and deployed the model to Vertex AI Endpoints. You want to automate the retraining of your model by using minimal additional code when model feature values change. You also want to minimize the number of times that your model is retrained to reduce training costs. What should you do?

**A.** 1 Enable request-response logging on Vertex AI Endpoints
2. Schedule a TensorFlow Data Validation job to monitor prediction drift
3. Execute model retraining if there is significant distance between the distributions

**B.** 1. Enable request-response logging on Vertex AI Endpoints
2. Schedule a TensorFlow Data Validation job to monitor training/serving skew
3. Execute model retraining if there is significant distance between the distributions

**C.** 1. Create a Vertex AI Model Monitoring job configured to monitor prediction drift
2. Configure alert monitoring to publish a message to a Pub/Sub queue when a monitoring alert is detected
3. Use a Cloud Function to monitor the Pub/Sub queue, and trigger retraining in BigQuery

**D.** 1. Create a Vertex AI Model Monitoring job configured to monitor training/serving skew
2. Configure alert monitoring to publish a message to a Pub/Sub queue when a monitoring alert is detected
3. Use a Cloud Function to monitor the Pub/Sub queue, and trigger retraining in BigQuery

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 186

Contexto: [topics:106](#topics-106)
You have been tasked with deploying prototype code to production. The feature engineering code is in PySpark and runs on Dataproc Serverless. The model training is executed by using a Vertex AI custom training job. The two steps are not connected, and the model training must currently be run manually after the feature engineering step finishes. You need to create a scalable and maintainable production process that runs end-to-end and tracks the connections between steps. What should you do?

**A.** Create a Vertex AI Workbench notebook. Use the notebook to submit the Dataproc Serverless feature engineering job. Use the same notebook to submit the custom model training job. Run the notebook cells sequentially to tie the steps together end-to-end.

**B.** Create a Vertex AI Workbench notebook. Initiate an Apache Spark context in the notebook and run the PySpark feature engineering code. Use the same notebook to run the custom model training job in TensorFlow. Run the notebook cells sequentially to tie the steps together end-to-end.

**C.** Use the Kubeflow pipelines SDK to write code that specifies two components:
- The first is a Dataproc Serverless component that launches the feature engineering job
- The second is a custom component wrapped in the create_custom_training_job_from_component utility that launches the custom model training job
Create a Vertex AI Pipelines job to link and run both components

**D.** Use the Kubeflow pipelines SDK to write code that specifies two components
- The first component initiates an Apache Spark context that runs the PySpark feature engineering code
- The second component runs the TensorFlow custom model training code
Create a Vertex AI Pipelines job to link and run both components.

**Respuesta de la fuente:** C

**Explicación:** Vertex AI Pipelines (built on Kubeflow) provides the necessary orchestration to create a scalable, maintainable end-to-end workflow that tracks dependencies between steps.
Option C correctly leverages existing infrastructure by using a Dataproc Serverless component for PySpark and the specific Vertex AI utility for custom training, avoiding the anti-pattern of running production workloads inside notebooks or manually managing Spark contexts.

## Pregunta 187

Contexto: [topics:106](#topics-106)
You recently deployed a scikit-learn model to a Vertex AI endpoint. You are now testing the model on live production traffic. While monitoring the endpoint, you discover twice as many requests per hour than expected throughout the day. You want the endpoint to efficiently scale when the demand increases in the future to prevent users from experiencing high latency. What should you do?

**A.** Deploy two models to the same endpoint, and distribute requests among them evenly

**B.** Configure an appropriate minReplicaCount value based on expected baseline traffic

**C.** Set the target utilization percentage in the autoscailngMetricSpecs configuration to a higher value

**D.** Change the model’s machine type to one that utilizes GPUs

**Respuesta de la fuente:** B

**Explicación:** Vertex AI endpoints use autoscaling to manage replica counts based on traffic. Setting an appropriate `minReplicaCount` ensures that sufficient resources are pre-provisioned to handle the observed higher baseline load, preventing cold-start latency spikes.
Option C is incorrect because increasing the target utilization percentage would delay scaling triggers, potentially worsening latency during peaks.

## Pregunta 188

Contexto: [topics:106](#topics-106)
You work at a bank. You have a custom tabular ML model that was provided by the bank’s vendor. The training data is not available due to its sensitivity. The model is packaged as a Vertex AI Model serving container, which accepts a string as input for each prediction instance. In each string, the feature values are separated by commas. You want to deploy this model to production for online predictions and monitor the feature distribution over time with minimal effort. What should you do?

**A.** 1. Upload the model to Vertex AI Model Registry, and deploy the model to a Vertex AI endpoint
2. Create a Vertex AI Model Monitoring job with feature drift detection as the monitoring objective, and provide an instance schema

**B.** 1. Upload the model to Vertex AI Model Registry, and deploy the model to a Vertex AI endpoint
2. Create a Vertex AI Model Monitoring job with feature skew detection as the monitoring objective, and provide an instance schema

**C.** 1. Refactor the serving container to accept key-value pairs as input format
2. Upload the model to Vertex AI Model Registry, and deploy the model to a Vertex AI endpoint
3. Create a Vertex AI Model Monitoring job with feature drift detection as the monitoring objective.

**D.** 1. Refactor the serving container to accept key-value pairs as input format
2. Upload the model to Vertex AI Model Registry, and deploy the model to a Vertex AI endpoint
3. Create a Vertex AI Model Monitoring job with feature skew detection as the monitoring objective

**Respuesta de la fuente:** A

**Explicación:** Feature skew requires comparing serving data against training data, which is impossible here since the training data is unavailable; thus, feature drift (comparing current predictions against a historical baseline) is the correct monitoring objective. Vertex AI Model Monitoring supports parsing comma-separated string inputs via an instance schema, allowing you to monitor feature distributions without refactoring the serving container, thereby satisfying the 'minimal effort' requirement.

## Pregunta 189

Contexto: [topics:106](#topics-106)
You are implementing a batch inference ML pipeline in Google Cloud. The model was developed using TensorFlow and is stored in SavedModel format in Cloud Storage. You need to apply the model to a historical dataset containing 10 TB of data that is stored in a BigQuery table. How should you perform the inference?

**A.** Export the historical data to Cloud Storage in Avro format. Configure a Vertex AI batch prediction job to generate predictions for the exported data

**B.** Import the TensorFlow model by using the CREATE MODEL statement in BigQuery ML. Apply the historical data to the TensorFlow model

**C.** Export the historical data to Cloud Storage in CSV format. Configure a Vertex AI batch prediction job to generate predictions for the exported data

**D.** Configure a Vertex AI batch prediction job to apply the model to the historical data in BigQuery

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because BigQuery ML supports importing TensorFlow SavedModel files for inference directly within the data warehouse.

This approach avoids the 100 GB table size limit imposed by Vertex AI batch prediction jobs when reading directly from BigQuery, making it suitable for the 10 TB dataset.

## Pregunta 190

Contexto: [topics:106](#topics-106)
You recently deployed a model to a Vertex AI endpoint. Your data drifts frequently, so you have enabled request-response logging and created a Vertex AI Model Monitoring job. You have observed that your model is receiving higher traffic than expected. You need to reduce the model monitoring cost while continuing to quickly detect drift. What should you do?

**A.** Replace the monitoring job with a DataFlow pipeline that uses TensorFlow Data Validation (TFDV)

**B.** Replace the monitoring job with a custom SQL script to calculate statistics on the features and predictions in BigQuery

**C.** Decrease the sample_rate parameter in the RandomSampleConfig of the monitoring job

**D.** Increase the monitor_interval parameter in the ScheduleConfig of the monitoring job

**Respuesta de la fuente:** C

**Explicación:** Decreasing the sample_rate parameter directly reduces the volume of data analyzed per monitoring cycle, which lowers the associated BigQuery storage and compute costs.
Since Vertex AI Model Monitoring is already configured for drift detection, adjusting the sampling rate preserves the existing monitoring schedule (monitor_interval), ensuring that frequent drift events are still detected promptly without unnecessary overhead.

## Pregunta 191

Contexto: [topics:106](#topics-106)
You work for a retail company. You have created a Vertex AI forecast model that produces monthly item sales predictions. You want to quickly create a report that will help to explain how the model calculates the predictions. You have one month of recent actual sales data that was not included in the training dataset. How should you generate data for your report?

**A.** Create a batch prediction job by using the actual sales data. Compare the predictions to the actuals in the report.

**B.** Create a batch prediction job by using the actual sales data, and configure the job settings to generate feature attributions. Compare the results in the report.

**C.** Generate counterfactual examples by using the actual sales data. Create a batch prediction job using the actual sales data and the counterfactual examples. Compare the results in the report.

**D.** Train another model by using the same training dataset as the original, and exclude some columns. Using the actual sales data create one batch prediction job by using the new model and another one with the original model. Compare the two sets of predictions in the report.

**Respuesta de la fuente:** B

**Explicación:** The requirement is to explain how the model calculates predictions, which necessitates understanding feature contributions rather than just prediction accuracy. Vertex AI AutoML supports generating feature attributions during batch prediction jobs, providing a breakdown of each feature's impact on specific predictions.
This technique directly addresses the need for model interpretability and explanation without requiring additional training or complex counterfactual generation.

## Pregunta 192

Contexto: [topics:106](#topics-106)
Your team has a model deployed to a Vertex AI endpoint. You have created a Vertex AI pipeline that automates the model training process and is triggered by a Cloud Function. You need to prioritize keeping the model up-to-date, but also minimize retraining costs. How should you configure retraining?

**A.** Configure Pub/Sub to call the Cloud Function when a sufficient amount of new data becomes available

**B.** Configure a Cloud Scheduler job that calls the Cloud Function at a predetermined frequency that fits your team’s budget

**C.** Enable model monitoring on the Vertex AI endpoint. Configure Pub/Sub to call the Cloud Function when anomalies are detected

**D.** Enable model monitoring on the Vertex AI endpoint. Configure Pub/Sub to call the Cloud Function when feature drift is detected

**Respuesta de la fuente:** D

**Explicación:** Feature drift monitoring detects significant changes in the input data distribution compared to the training baseline, which directly impacts model accuracy and relevance.
Triggering retraining only upon drift detection ensures the model stays up-to-date while avoiding unnecessary compute costs associated with fixed schedules or irrelevant anomaly alerts.

## Pregunta 193

Contexto: [topics:106](#topics-106)
Your company stores a large number of audio files of phone calls made to your customer call center in an on-premises database. Each audio file is in wav format and is approximately 5 minutes long. You need to analyze these audio files for customer sentiment. You plan to use the Speech-to-Text API You want to use the most efficient approach. What should you do?

**A.** 1. Upload the audio files to Cloud Storage
2. Call the speech:longrunningrecognize API endpoint to generate transcriptions
3. Call the predict method of an AutoML sentiment analysis model to analyze the transcriptions.

**B.** 1. Upload the audio files to Cloud Storage.
2. Call the speech:longrunningrecognize API endpoint to generate transcriptions
3. Create a Cloud Function that calls the Natural Language API by using the analyzeSentiment method

**C.** 1. Iterate over your local files in Python
2. Use the Speech-to-Text Python library to create a speech.RecognitionAudio object, and set the content to the audio file data
3. Call the speech:recognize API endpoint to generate transcriptions
4. Call the predict method of an AutoML sentiment analysis model to analyze the transcriptions.

**D.** 1. Iterate over your local files in Python
2. Use the Speech-to-Text Python Library to create a speech.RecognitionAudio object and set the content to the audio file data
3. Call the speech:longrunningrecognize API endpoint to generate transcriptions.
4. Call the Natural Language API by using the analyzeSentiment method

**Respuesta de la fuente:** B

**Explicación:** Options C and D are incorrect because they involve local processing of a large dataset, which is inefficient and violates the constraint of uploading to Cloud Storage for scalability. Option A is less efficient than B because using AutoML requires training a model on labeled data, whereas the Natural Language API provides immediate sentiment analysis capabilities without this overhead.
Option B is the correct choice as it uses `speech:longrunningrecognize` for efficient asynchronous processing of large audio files stored in Cloud Storage and leverages the serverless, auto-scaling capability of Cloud Functions to invoke the built-in Natural Language API for direct sentiment analysis.

## Pregunta 194

Contexto: [topics:106](#topics-106)
You work for a social media company. You want to create a no-code image classification model for an iOS mobile application to identify fashion accessories. You have a labeled dataset in Cloud Storage. You need to configure a training workflow that minimizes cost and serves predictions with the lowest possible latency. What should you do?

**A.** Train the model by using AutoML, and register the model in Vertex AI Model Registry. Configure your mobile application to send batch requests during prediction.

**B.** Train the model by using AutoML Edge, and export it as a Core ML model. Configure your mobile application to use the .mlmodel file directly.

**C.** Train the model by using AutoML Edge, and export the model as a TFLite model. Configure your mobile application to use the .tflite file directly.

**D.** Train the model by using AutoML, and expose the model as a Vertex AI endpoint. Configure your mobile application to invoke the endpoint during prediction.

**Respuesta de la fuente:** B

**Explicación:** AutoML Edge is specifically designed for on-device ML and optimizes models for mobile efficiency, meeting the no-code requirement.
Exporting to Core ML ensures native iOS integration, enabling local inference that eliminates network latency entirely.
Running predictions locally also removes ongoing Vertex AI endpoint costs, satisfying both low-latency and cost-minimization goals.

## Pregunta 195

Contexto: [topics:106](#topics-106)
You work for a retail company. You have been asked to develop a model to predict whether a customer will purchase a product on a given day. Your team has processed the company’s sales data, and created a table with the following rows:
•	Customer_id
•	Product_id
•	Date
•	Days_since_last_purchase (measured in days)
•	Average_purchase_frequency (measured in 1/days)
•	Purchase (binary class, if customer purchased product on the Date)

You need to interpret your model’s results for each individual prediction. What should you do?

**A.** Create a BigQuery table. Use BigQuery ML to build a boosted tree classifier. Inspect the partition rules of the trees to understand how each prediction flows through the trees.

**B.** Create a Vertex AI tabular dataset. Train an AutoML model to predict customer purchases. Deploy the model to a Vertex AI endpoint and enable feature attributions. Use the “explain” method to get feature attribution values for each individual prediction.

**C.** Create a BigQuery table. Use BigQuery ML to build a logistic regression classification model. Use the values of the coefficients of the model to interpret the feature importance, with higher values corresponding to more importance

**D.** Create a Vertex AI tabular dataset. Train an AutoML model to predict customer purchases. Deploy the model to a Vertex AI endpoint. At each prediction, enable L1 regularization to detect non-informative features.

**Respuesta de la fuente:** B

**Explicación:** Vertex AI AutoML provides built-in feature attribution capabilities that explain individual predictions by calculating the contribution of each feature to the output. This directly addresses the requirement for local interpretability per prediction, whereas coefficients (Option C) or tree rules (Option A) offer global or structural insights rather than instance-specific explanations.

## Pregunta 196

Contexto: [topics:106](#topics-106)
You work for a company that captures live video footage of checkout areas in their retail stores. You need to use the live video footage to build a model to detect the number of customers waiting for service in near real time. You want to implement a solution quickly and with minimal effort. How should you build the model?

**A.** Use the Vertex AI Vision Occupancy Analytics model.

**B.** Use the Vertex AI Vision Person/vehicle detector model.

**C.** Train an AutoML object detection model on an annotated dataset by using Vertex AutoML.

**D.** Train a Seq2Seq+ object detection model on an annotated dataset by using Vertex AutoML.

**Respuesta de la fuente:** A

**Explicación:** The Vertex AI Vision Occupancy Analytics model is a pre-trained solution specifically designed to count people in video streams, satisfying the requirement for minimal effort and quick implementation. Options C and D are incorrect because training custom AutoML models requires data annotation and significant training time, which contradicts the goal of speed. Option B is less suitable than A because it only detects individuals without providing the specific occupancy counting logic needed to determine wait times.

## Pregunta 197

Contexto: [topics:106](#topics-106)
You work as an analyst at a large banking firm. You are developing a robust scalable ML pipeline to tram several regression and classification models. Your primary focus for the pipeline is model interpretability. You want to productionize the pipeline as quickly as possible. What should you do?

**A.** Use Tabular Workflow for Wide & Deep through Vertex AI Pipelines to jointly train wide linear models and deep neural networks

**B.** Use Google Kubernetes Engine to build a custom training pipeline for XGBoost-based models

**C.** Use Tabular Workflow for TabNet through Vertex AI Pipelines to train attention-based models

**D.** Use Cloud Composer to build the training pipelines for custom deep learning-based models

**Respuesta de la fuente:** C

**Explicación:** The primary requirement is model interpretability combined with rapid productionization. TabNet is a deep learning model specifically designed for tabular data that offers inherent interpretability through its sequential attention mechanism, allowing clear feature attributions.
Vertex AI Tabular Workflows provide pre-built pipelines that minimize development time compared to custom orchestration on GKE or Cloud Composer.

## Pregunta 198

Contexto: [topics:106](#topics-106)
You developed a Transformer model in TensorFlow to translate text. Your training data includes millions of documents in a Cloud Storage bucket. You plan to use distributed training to reduce training time. You need to configure the training job while minimizing the effort required to modify code and to manage the cluster’s configuration. What should you do?

**A.** Create a Vertex AI custom training job with GPU accelerators for the second worker pool. Use tf.distribute.MultiWorkerMirroredStrategy for distribution.

**B.** Create a Vertex AI custom distributed training job with Reduction Server. Use N1 high-memory machine type instances for the first and second pools, and use N1 high-CPU machine type instances for the third worker pool.

**C.** Create a training job that uses Cloud TPU VMs. Use tf.distribute.TPUStrategy for distribution.

**D.** Create a Vertex AI custom training job with a single worker pool of A2 GPU machine type instances. Use tf.distribute.MirroredStrategv for distribution.

**Respuesta de la fuente:** A

**Explicación:** Vertex AI Custom Training is a managed service that handles cluster provisioning and scaling, directly minimizing the effort to manage cluster configuration.
Using tf.distribute.MultiWorkerMirroredStrategy allows for distributed training across multiple GPU workers with minimal code changes compared to other strategies or hardware-specific adaptations.
Option C (TPUs) often requires specific code modifications to handle model compatibility and data input, which contradicts the goal of minimizing code modification effort.
Option D uses a single worker pool, failing to utilize distributed training for speed reduction, while Option B adds unnecessary complexity with Reduction Servers.

## Pregunta 199

Contexto: [topics:106](#topics-106)
You are developing a process for training and running your custom model in production. You need to be able to show lineage for your model and predictions. What should you do?

**A.** 1. Create a Vertex AI managed dataset.
2. Use a Vertex AI training pipeline to train your model.
3. Generate batch predictions in Vertex AI.

**B.** 1. Use a Vertex AI Pipelines custom training job component to tram your model.
2. Generate predictions by using a Vertex AI Pipelines model batch predict component.

**C.** 1. Upload your dataset to BigQuery.
2. Use a Vertex AI custom training job to train your model.
3. Generate predictions by using Vertex Al SDK custom prediction routines.

**D.** 1. Use Vertex AI Experiments to train your model.
2. Register your model in Vertex AI Model Registry.
3. Generate batch predictions in Vertex AI.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 200

Contexto: [topics:106](#topics-106)
You work for a hotel and have a dataset that contains customers’ written comments scanned from paper-based customer feedback forms, which are stored as PDF files. Every form has the same layout. You need to quickly predict an overall satisfaction score from the customer comments on each form. How should you accomplish this task?

**A.** Use the Vision API to parse the text from each PDF file. Use the Natural Language API analyzeSentiment feature to infer overall satisfaction scores.

**B.** Use the Vision API to parse the text from each PDF file. Use the Natural Language API analyzeEntitySentiment feature to infer overall satisfaction scores.

**C.** Uptrain a Document AI custom extractor to parse the text in the comments section of each PDF file. Use the Natural Language API analyzeSentiment feature to infer overall satisfaction scores.

**D.** Uptrain a Document AI custom extractor to parse the text in the comments section of each PDF file. Use the Natural Language API analyzeEntitySentiment feature to infer overall satisfaction scores.

**Respuesta de la fuente:** C

**Explicación:** Document AI is the appropriate tool for extracting text from PDFs with a consistent layout, as it provides higher accuracy and structure-aware parsing than the generic Vision API.
Using analyzeSentiment is correct because the goal is to determine an overall satisfaction score (document-level sentiment), whereas analyzeEntitySentiment would only provide scores for specific named entities.

## Pregunta 201

Contexto: [topics:106](#topics-106)
You developed a Vertex AI pipeline that trains a classification model on data stored in a large BigQuery table. The pipeline has four steps, where each step is created by a Python function that uses the KubeFlow v2 API. The components have the following names:

[Imagen: sin descripción]

You launch your Vertex AI pipeline as the following:

[Imagen: sin descripción]

You perform many model iterations by adjusting the code and parameters of the training step. You observe high costs associated with the development, particularly the data export and preprocessing steps. You need to reduce model development costs. What should you do?
Imagen · question_text · sin descripción
![Imagen original](imagenes/0aa86d23f494343784f2.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
dt=datetime.now().strftime ("tytmtdtH8M$s")
f"export-{dt}.yaml", f"preprocess-{dt}.yaml", £"train-(dt).yaml",
f£"calibrate-{dt}.yaml"
```
Imagen · question_text · sin descripción
![Imagen original](imagenes/97499db9e5699aaabaa6.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
job = aip.Pipelinegob(
display_name="my-awesome-pipeline",
template_path:
job_id
ipeline. json",
my-awesome-pipeline-{dt}",
parameter_values=params,
enable_caching=True,
location="europe-west1"
```

**A.** Change the components’ YAML filenames to export.yaml, preprocess,yaml, f "train-
{dt}.yaml", f"calibrate-{dt).vaml".

**B.** Add the {"kubeflow.v1.caching": True} parameter to the set of params provided to your PipelineJob.

**C.** Move the first step of your pipeline to a separate step, and provide a cached path to Cloud Storage as an input to the main pipeline.

**D.** Change the name of the pipeline to f"my-awesome-pipeline-{dt}".

**Respuesta de la fuente:** A

**Explicación:** Vertex AI Pipelines (based on Kubeflow) use component signatures to determine cache hits. If component names or inputs change dynamically (e.g., via timestamps), the system treats each run as a new component, bypassing caching and re-executing expensive export/preprocessing steps.

Renaming components to static filenames ensures that when only the training step changes, the identical export and preprocess steps are recognized as cached results, preventing redundant execution and reducing costs.

## Pregunta 202

Contexto: [topics:106](#topics-106)
You work for a startup that has multiple data science workloads. Your compute infrastructure is currently on-premises, and the data science workloads are native to PySpark. Your team plans to migrate their data science workloads to Google Cloud. You need to build a proof of concept to migrate one data science job to Google Cloud. You want to propose a migration process that requires minimal cost and effort. What should you do first?

**A.** Create a n2-standard-4 VM instance and install Java, Scala, and Apache Spark dependencies on it.

**B.** Create a Google Kubernetes Engine cluster with a basic node pool configuration, install Java, Scala, and Apache Spark dependencies on it.

**C.** Create a Standard (1 master, 3 workers) Dataproc cluster, and run a Vertex AI Workbench notebook instance on it.

**D.** Create a Vertex AI Workbench notebook with instance type n2-standard-4.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google Cloud Dataproc is a fully managed Apache Spark service that minimizes infrastructure setup and maintenance effort compared to manual VM (A) or GKE (B) configurations. Using a Standard cluster with Vertex AI Workbench provides an immediate, interactive environment for executing PySpark workloads, satisfying the 'proof of concept' requirement with minimal cost and operational overhead. While D offers a notebook, it lacks the inherent distributed computing context of a Dataproc cluster required to validate migration of native PySpark jobs efficiently.

## Pregunta 203

Contexto: [topics:106](#topics-106)
You work for a bank. You have been asked to develop an ML model that will support loan application decisions. You need to determine which Vertex AI services to include in the workflow. You want to track the model’s training parameters and the metrics per training epoch. You plan to compare the performance of each version of the model to determine the best model based on your chosen metrics. Which Vertex AI services should you use?

**A.** Vertex ML Metadata, Vertex AI Feature Store, and Vertex AI Vizier

**B.** Vertex AI Pipelines, Vertex AI Experiments, and Vertex AI Vizier

**C.** Vertex ML Metadata, Vertex AI Experiments, and Vertex AI TensorBoard

**D.** Vertex AI Pipelines, Vertex AI Feature Store, and Vertex AI TensorBoard

**Respuesta de la fuente:** C

**Explicación:** Vertex ML Metadata is required to centrally store and track training parameters, metrics, and lineage information for model comparison. Vertex AI Experiments organizes these training runs, allowing you to manage and compare different model versions based on their performance. Vertex AI TensorBoard provides the specific visualization capabilities needed to analyze detailed metrics per training epoch, fulfilling the requirement to observe training behavior over time.

## Pregunta 204

Contexto: [topics:106](#topics-106)
You work for an auto insurance company. You are preparing a proof-of-concept ML application that uses images of damaged vehicles to infer damaged parts. Your team has assembled a set of annotated images from damage claim documents in the company’s database. The annotations associated with each image consist of a bounding box for each identified damaged part and the part name. You have been given a sufficient budget to train models on Google Cloud. You need to quickly create an initial model. What should you do?

**A.** Download a pre-trained object detection model from TensorFlow Hub. Fine-tune the model in Vertex AI Workbench by using the annotated image data.

**B.** Train an object detection model in AutoML by using the annotated image data.

**C.** Create a pipeline in Vertex AI Pipelines and configure the AutoMLTrainingJobRunOp component to train a custom object detection model by using the annotated image data.

**D.** Train an object detection model in Vertex AI custom training by using the annotated image data.

**Respuesta de la fuente:** B

**Explicación:** The requirement is to 'quickly create an initial model' for object detection using annotated bounding box data. Vertex AI AutoML Vision provides a no-code solution that automatically handles feature engineering and hyperparameter tuning, significantly accelerating the development process compared to manual custom training or fine-tuning pre-trained models.

## Pregunta 205

Contexto: [topics:106](#topics-106)
You are analyzing customer data for a healthcare organization that is stored in Cloud Storage. The data contains personally identifiable information (PII). You need to perform data exploration and preprocessing while ensuring the security and privacy of sensitive fields. What should you do?

**A.** Use the Cloud Data Loss Prevention (DLP) API to de-identify the PII before performing data exploration and preprocessing.

**B.** Use customer-managed encryption keys (CMEK) to encrypt the PII data at rest, and decrypt the PII data during data exploration and preprocessing.

**C.** Use a VM inside a VPC Service Controls security perimeter to perform data exploration and preprocessing.

**D.** Use Google-managed encryption keys to encrypt the PII data at rest, and decrypt the PII data during data exploration and preprocessing.

**Respuesta de la fuente:** A

**Explicación:** The Cloud Data Loss Prevention (DLP) API is specifically designed to inspect and de-identify sensitive information like PII before further processing.
De-identification techniques, such as masking or pseudonymization, allow analysts to explore data patterns without exposing raw personal details.
This approach directly addresses the privacy requirement by minimizing the risk of accidental exposure during preprocessing.

## Pregunta 206

Contexto: [topics:106](#topics-106)
You are building a predictive maintenance model to preemptively detect part defects in bridges. You plan to use high definition images of the bridges as model inputs. You need to explain the output of the model to the relevant stakeholders so they can take appropriate action. How should you build the model?

**A.** Use scikit-learn to build a tree-based model, and use SHAP values to explain the model output.

**B.** Use scikit-learn to build a tree-based model, and use partial dependence plots (PDP) to explain the model output.

**C.** Use TensorFlow to create a deep learning-based model, and use Integrated Gradients to explain the model output.

**D.** Use TensorFlow to create a deep learning-based model, and use the sampled Shapley method to explain the model output.

**Respuesta de la fuente:** C

**Explicación:** High-definition images require a deep learning model (like those built with TensorFlow) rather than scikit-learn tree-based models, which are ill-suited for raw pixel data.
Integrated Gradients is the recommended explanation method for deep learning image models because it attributes predictions to specific pixels, helping stakeholders identify defect locations.

## Pregunta 207

Contexto: [topics:106](#topics-106)
You work for a hospital that wants to optimize how it schedules operations. You need to create a model that uses the relationship between the number of surgeries scheduled and beds used. You want to predict how many beds will be needed for patients each day in advance based on the scheduled surgeries. You have one year of data for the hospital organized in 365 rows.

The data includes the following variables for each day:
•	Number of scheduled surgeries
•	Number of beds occupied
•	Date

You want to maximize the speed of model development and testing. What should you do?

**A.** Create a BigQuery table. Use BigQuery ML to build a regression model, with number of beds as the target variable, and number of scheduled surgeries and date features (such as day of week) as the predictors.

**B.** Create a BigQuery table. Use BigQuery ML to build an ARIMA model, with number of beds as the target variable, and date as the time variable.

**C.** Create a Vertex AI tabular dataset. Train an AutoML regression model, with number of beds as the target variable, and number of scheduled minor surgeries and date features (such as day of the week) as the predictors.

**D.** Create a Vertex AI tabular dataset. Train a Vertex AI AutoML Forecasting model, with number of beds as the target variable, number of scheduled surgeries as a covariate and date as the time variable.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 208

Contexto: [topics:106](#topics-106)
You recently developed a wide and deep model in TensorFlow. You generated training datasets using a SQL script that preprocessed raw data in BigQuery by performing instance-level transformations of the data. You need to create a training pipeline to retrain the model on a weekly basis. The trained model will be used to generate daily recommendations. You want to minimize model development and training time. How should you develop the training pipeline?

**A.** Use the Kubeflow Pipelines SDK to implement the pipeline. Use the BigQueryJobOp component to run the preprocessing script and the CustomTrainingJobOp component to launch a Vertex AI training job.

**B.** Use the Kubeflow Pipelines SDK to implement the pipeline. Use the DataflowPythonJobOp component to preprocess the data and the CustomTrainingJobOp component to launch a Vertex AI training job.

**C.** Use the TensorFlow Extended SDK to implement the pipeline Use the ExampleGen component with the BigQuery executor to ingest the data the Transform component to preprocess the data, and the Trainer component to launch a Vertex AI training job.

**D.** Use the TensorFlow Extended SDK to implement the pipeline Implement the preprocessing steps as part of the input_fn of the model. Use the ExampleGen component with the BigQuery executor to ingest the data and the Trainer component to launch a Vertex AI training job.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it leverages the existing BigQuery SQL script for preprocessing via `BigQueryJobOp`, avoiding the development overhead of reimplementing logic in Python or TFX.
Using `CustomTrainingJobOp` within Kubeflow Pipelines provides a streamlined orchestration solution that integrates directly with Vertex AI, minimizing both model development effort and pipeline complexity compared to full TFX implementation.

## Pregunta 209

Contexto: [topics:106](#topics-106)
You are training a custom language model for your company using a large dataset. You plan to use the Reduction Server strategy on Vertex AI. You need to configure the worker pools of the distributed training job. What should you do?

**A.** Configure the machines of the first two worker pools to have GPUs, and to use a container image where your training code runs. Configure the third worker pool to have GPUs, and use the reductionserver container image.

**B.** Configure the machines of the first two worker pools to have GPUs and to use a container image where your training code runs. Configure the third worker pool to use the reductionserver container image without accelerators, and choose a machine type that prioritizes bandwidth.

**C.** Configure the machines of the first two worker pools to have TPUs and to use a container image where your training code runs. Configure the third worker pool without accelerators, and use the reductionserver container image without accelerators, and choose a machine type that prioritizes bandwidth.

**D.** Configure the machines of the first two pools to have TPUs, and to use a container image where your training code runs. Configure the third pool to have TPUs, and use the reductionserver container image.

**Respuesta de la fuente:** B

**Explicación:** The Reduction Server strategy on Vertex AI is designed for distributed training using GPUs and the NCCL library, making TPUs incompatible for this specific configuration.
Worker pools running the actual model training code require GPU acceleration to handle computational loads.
The dedicated reduction server pool handles gradient aggregation and communication; therefore, it should use CPU-only machines with high network bandwidth rather than GPUs or TPUs to optimize cost and efficiency.

## Pregunta 210

Contexto: [topics:106](#topics-106)
You have trained a model by using data that was preprocessed in a batch Dataflow pipeline. Your use case requires real-time inference. You want to ensure that the data preprocessing logic is applied consistently between training and serving. What should you do?

**A.** Perform data validation to ensure that the input data to the pipeline is the same format as the input data to the endpoint.

**B.** Refactor the transformation code in the batch data pipeline so that it can be used outside of the pipeline. Use the same code in the endpoint.

**C.** Refactor the transformation code in the batch data pipeline so that it can be used outside of the pipeline. Share this code with the end users of the endpoint.

**D.** Batch the real-time requests by using a time window and then use the Dataflow pipeline to preprocess the batched requests. Send the preprocessed requests to the endpoint.

**Respuesta de la fuente:** B

**Explicación:** To prevent training-serving skew, the exact same transformation logic used during batch training must be applied to real-time inference data. Refactoring this code for reuse within the serving endpoint ensures consistency without introducing the latency of batching (D) or relying on insufficient format validation (A). Sharing code with end users (C) is incorrect as it externalizes processing and does not guarantee the endpoint applies the logic correctly.

## Pregunta 211

Contexto: [topics:106](#topics-106)
You need to develop a custom TensorFlow model that will be used for online predictions. The training data is stored in BigQuery You need to apply instance-level data transformations to the data for model training and serving. You want to use the same preprocessing routine during model training and serving. How should you configure the preprocessing routine?

**A.** Create a BigQuery script to preprocess the data, and write the result to another BigQuery table.

**B.** Create a pipeline in Vertex AI Pipelines to read the data from BigQuery and preprocess it using a custom preprocessing component.

**C.** Create a preprocessing function that reads and transforms the data from BigQuery. Create a Vertex AI custom prediction routine that calls the preprocessing function at serving time.

**D.** Create an Apache Beam pipeline to read the data from BigQuery and preprocess it by using TensorFlow Transform and Dataflow.

**Respuesta de la fuente:** D

**Explicación:** TensorFlow Transform (TFT) is the standard solution for applying consistent instance-level transformations to both training data and online serving requests. It generates a SavedModel containing the preprocessing logic, which ensures that the exact same code path used during training is executed at inference time.
Using Apache Beam with Dataflow allows TFT to process large datasets from BigQuery efficiently while guaranteeing consistency between training and serving.

## Pregunta 212

Contexto: [topics:106](#topics-106)
You are pre-training a large language model on Google Cloud. This model includes custom TensorFlow operations in the training loop. Model training will use a large batch size, and you expect training to take several weeks. You need to configure a training architecture that minimizes both training time and compute costs. What should you do?

**A.** Implement 8 workers of a2-megagpu-16g machines by using tf.distribute.MultiWorkerMirroredStrategy.

**B.** Implement a TPU Pod slice with -accelerator-type=v4-l28 by using tf.distribute.TPUStrategy.

**C.** Implement 16 workers of c2d-highcpu-32 machines by using tf.distribute.MirroredStrategy.

**D.** Implement 16 workers of a2-highgpu-8g machines by using tf.distribute.MultiWorkerMirroredStrategy.

**Respuesta de la fuente:** A

**Explicación:** Option B is incorrect because TPUs have strict compatibility constraints and generally do not support custom TensorFlow operations in the training loop.
Option C is unsuitable as CPU-only instances cannot handle the heavy parallel computation required for LLM training efficiently.
Between the GPU options, Option A uses a2-megagpu-16g machines which provide higher memory capacity per device compared to the 8G variant in Option D.
Higher memory allows for larger batch sizes without offloading, reducing synchronization overhead and overall training time/cost when using MultiWorkerMirroredStrategy.

## Pregunta 213

Contexto: [topics:106](#topics-106)
You are building a TensorFlow text-to-image generative model by using a dataset that contains billions of images with their respective captions. You want to create a low maintenance, automated workflow that reads the data from a Cloud Storage bucket collects statistics, splits the dataset into training/validation/test datasets performs data transformations trains the model using the training/validation datasets, and validates the model by using the test dataset. What should you do?

**A.** Use the Apache Airflow SDK to create multiple operators that use Dataflow and Vertex AI services. Deploy the workflow on Cloud Composer.

**B.** Use the MLFlow SDK and deploy it on a Google Kubernetes Engine cluster. Create multiple components that use Dataflow and Vertex AI services.

**C.** Use the Kubeflow Pipelines (KFP) SDK to create multiple components that use Dataflow and Vertex AI services. Deploy the workflow on Vertex AI Pipelines.

**D.** Use the TensorFlow Extended (TFX) SDK to create multiple components that use Dataflow and Vertex AI services. Deploy the workflow on Vertex AI Pipelines.

**Respuesta de la fuente:** D

**Explicación:** Google Cloud documentation explicitly recommends using TensorFlow Extended (TFX) for ML workflows involving TensorFlow, as it provides pre-built components for the specific steps described: data ingestion, statistics collection, dataset splitting, and model training.

In contrast, Kubeflow Pipelines is generally recommended for other use cases or when custom component orchestration is required, making TFX the more appropriate and low-maintenance choice for a standard TensorFlow pipeline.

## Pregunta 214

Contexto: [topics:106](#topics-106)
You are developing an ML pipeline using Vertex AI Pipelines. You want your pipeline to upload a new version of the XGBoost model to Vertex AI Model Registry and deploy it to Vertex AI Endpoints for online inference. You want to use the simplest approach. What should you do?

**A.** Use the Vertex AI REST API within a custom component based on a vertex-ai/prediction/xgboost-cpu image

**B.** Use the Vertex AI ModelEvaluationOp component to evaluate the model

**C.** Use the Vertex AI SDK for Python within a custom component based on a python:3.10 image

**D.** Chain the Vertex AI ModelUploadOp and ModelDeployOp components together

**Respuesta de la fuente:** D

**Explicación:** The question asks for the simplest approach to upload and deploy a model using Vertex AI Pipelines.
Vertex AI provides pre-built components, specifically ModelUploadOp and ModelDeployOp, designed to handle these tasks directly without requiring custom code.
Using these built-in operators reduces complexity compared to writing custom Python scripts or interacting with REST APIs manually.

## Pregunta 215

Contexto: [topics:106](#topics-106)
You work for an online retailer. Your company has a few thousand short lifecycle products. Your company has five years of sales data stored in BigQuery. You have been asked to build a model that will make monthly sales predictions for each product. You want to use a solution that can be implemented quickly with minimal effort. What should you do?

**A.** Use Prophet on Vertex AI Training to build a custom model.

**B.** Use Vertex AI Forecast to build a NN-based model.

**C.** Use BigQuery ML to build a statistical ARIMA_PLUS model.

**D.** Use TensorFlow on Vertex AI Training to build a custom model.

**Respuesta de la fuente:** C

**Explicación:** The requirement for minimal effort and quick implementation points to BigQuery ML because the data already resides in BigQuery, eliminating the need for data movement or external training environments. The ARIMA_PLUS model is specifically designed for time-series forecasting within SQL queries, handling seasonality and trends automatically with just a few lines of code, whereas Vertex AI options require more complex setup and coding.

## Pregunta 216

Contexto: [topics:106](#topics-106)
You are creating a model training pipeline to predict sentiment scores from text-based product reviews. You want to have control over how the model parameters are tuned, and you will deploy the model to an endpoint after it has been trained. You will use Vertex AI Pipelines to run the pipeline. You need to decide which Google Cloud pipeline components to use. What components should you choose?

**A.** TabularDatasetCreateOp, CustomTrainingJobOp, and EndpointCreateOp

**B.** TextDatasetCreateOp, AutoMLTextTrainingOp, and EndpointCreateOp

**C.** TabularDatasetCreateOp. AutoMLTextTrainingOp, and ModelDeployOp

**D.** TextDatasetCreateOp, CustomTrainingJobOp, and ModelDeployOp

**Respuesta de la fuente:** D

**Explicación:** TextDatasetCreateOp is required because the input data consists of text-based product reviews, whereas TabularDatasetCreateOp is designed for structured tabular data. CustomTrainingJobOp must be selected over AutoMLTextTrainingOp to satisfy the requirement for explicit control over model parameter tuning and hyperparameters. Finally, ModelDeployOp is the correct component to deploy the trained model to an endpoint within a Vertex AI Pipeline, as EndpointCreateOp only creates the endpoint resource without deploying the model.

## Pregunta 217

Contexto: [topics:106](#topics-106)
Your team frequently creates new ML models and runs experiments. Your team pushes code to a single repository hosted on Cloud Source Repositories. You want to create a continuous integration pipeline that automatically retrains the models whenever there is any modification of the code. What should be your first step to set up the CI pipeline?

**A.** Configure a Cloud Build trigger with the event set as "Pull Request"

**B.** Configure a Cloud Build trigger with the event set as "Push to a branch"

**C.** Configure a Cloud Function that builds the repository each time there is a code change

**D.** Configure a Cloud Function that builds the repository each time a new branch is created

**Respuesta de la fuente:** B

**Explicación:** Cloud Build is the native CI/CD service on Google Cloud, making it the correct tool for automating pipelines triggered by repository changes. Setting the trigger event to 'Push to a branch' ensures that the pipeline executes immediately upon any code modification committed to the repository, fulfilling the requirement to retrain models whenever code changes occur.

## Pregunta 218

Contexto: [topics:106](#topics-106)
You have built a custom model that performs several memory-intensive preprocessing tasks before it makes a prediction. You deployed the model to a Vertex AI endpoint, and validated that results were received in a reasonable amount of time. After routing user traffic to the endpoint, you discover that the endpoint does not autoscale as expected when receiving multiple requests. What should you do?

**A.** Use a machine type with more memory

**B.** Decrease the number of workers per machine

**C.** Increase the CPU utilization target in the autoscaling configurations.

**D.** Decrease the CPU utilization target in the autoscaling configurations

**Respuesta de la fuente:** D

**Explicación:** Vertex AI endpoints primarily utilize CPU utilization as the metric for autoscaling decisions. When memory-intensive tasks cause resource contention that inhibits scaling, lowering the CPU utilization target triggers scale-out events more aggressively at lower usage levels.
This compensates for the lag in response to actual load spikes, ensuring capacity increases before resources are fully saturated.

## Pregunta 219

Contexto: [topics:106](#topics-106)
Your company manages an ecommerce website. You developed an ML model that recommends additional products to users in near real time based on items currently in the user’s cart. The workflow will include the following processes:

1. The website will send a Pub/Sub message with the relevant data and then receive a message with the prediction from Pub/Sub
2. Predictions will be stored in BigQuery
3. The model will be stored in a Cloud Storage bucket and will be updated frequently

You want to minimize prediction latency and the effort required to update the model. How should you reconfigure the architecture?

**A.** Write a Cloud Function that loads the model into memory for prediction. Configure the function to be triggered when messages are sent to Pub/Sub.

**B.** Create a pipeline in Vertex AI Pipelines that performs preprocessing, prediction, and postprocessing. Configure the pipeline to be triggered by a Cloud Function when messages are sent to Pub/Sub.

**C.** Expose the model as a Vertex AI endpoint. Write a custom DoFn in a Dataflow job that calls the endpoint for prediction.

**D.** Use the RunInference API with WatchFilePattern in a Dataflow job that wraps around the model and serves predictions.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because the `RunInference` API in Dataflow allows models to be served directly within the streaming pipeline, minimizing latency by avoiding external network calls to a separate endpoint.
Additionally, using `WatchFilePattern` automatically detects and loads new model versions from Cloud Storage without requiring manual redeployment or pipeline restarts, thus minimizing the effort required for frequent updates.

## Pregunta 220

Contexto: [topics:106](#topics-106)
You are collaborating on a model prototype with your team. You need to create a Vertex AI Workbench environment for the members of your team and also limit access to other employees in your project. What should you do?

**A.** 1. Create a new service account and grant it the Notebook Viewer role
2. Grant the Service Account User role to each team member on the service account
3. Grant the Vertex AI User role to each team member
4. Provision a Vertex AI Workbench user-managed notebook instance that uses the new service account

**B.** 1. Grant the Vertex AI User role to the default Compute Engine service account
2. Grant the Service Account User role to each team member on the default Compute Engine service account
3. Provision a Vertex AI Workbench user-managed notebook instance that uses the default Compute Engine service account.

**C.** 1. Create a new service account and grant it the Vertex AI User role
2. Grant the Service Account User role to each team member on the service account
3. Grant the Notebook Viewer role to each team member.
4. Provision a Vertex AI Workbench user-managed notebook instance that uses the new service account

**D.** 1. Grant the Vertex AI User role to the primary team member
2. Grant the Notebook Viewer role to the other team members
3. Provision a Vertex AI Workbench user-managed notebook instance that uses the primary user’s account

**Respuesta de la fuente:** C

**Explicación:** Answer C is correct because it follows security best practices by creating a dedicated service account for the workload rather than using the default Compute Engine account. The service account holds the 'Vertex AI User' role to perform ML tasks, while team members are granted the 'Service Account User' role to impersonate it and the 'Notebook Viewer' role to access the interface.
This separation ensures that only authorized team members can interact with the Vertex AI environment via the specific service account, preventing unauthorized access by other project employees.

## Pregunta 221

Contexto: [topics:106](#topics-106)
You work at a leading healthcare firm developing state-of-the-art algorithms for various use cases. You have unstructured textual data with custom labels. You need to extract and classify various medical phrases with these labels. What should you do?

**A.** Use the Healthcare Natural Language API to extract medical entities

**B.** Use a BERT-based model to fine-tune a medical entity extraction model

**C.** Use AutoML Entity Extraction to train a medical entity extraction model

**D.** Use TensorFlow to build a custom medical entity extraction model

**Respuesta de la fuente:** C

**Explicación:** The scenario specifies the need to extract entities using custom labels from unstructured text. The Healthcare Natural Language API (Option A) uses a fixed ontology and does not support user-defined custom labels.
AutoML Entity Extraction (Option C) is specifically designed to allow users to train custom models with their own annotated data and custom categories, making it the correct solution for this requirement.

## Pregunta 222

Contexto: [topics:106](#topics-106)
You developed a custom model by using Vertex AI to predict your application's user churn rate. You are using Vertex AI Model Monitoring for skew detection. The training data stored in BigQuery contains two sets of features - demographic and behavioral. You later discover that two separate models trained on each set perform better than the original model. You need to configure a new model monitoring pipeline that splits traffic among the two models. You want to use the same prediction-sampling-rate and monitoring-frequency for each model. You also want to minimize management effort. What should you do?

**A.** Keep the training dataset as is. Deploy the models to two separate endpoints, and submit two Vertex AI Model Monitoring jobs with appropriately selected feature-thresholds parameters.

**B.** Keep the training dataset as is. Deploy both models to the same endpoint and submit a Vertex AI Model Monitoring job with a monitoring-config-from-file parameter that accounts for the model IDs and feature selections.

**C.** Separate the training dataset into two tables based on demographic and behavioral features. Deploy the models to two separate endpoints, and submit two Vertex AI Model Monitoring jobs.

**D.** Separate the training dataset into two tables based on demographic and behavioral features. Deploy both models to the same endpoint, and submit a Vertex AI Model Monitoring job with a monitoring-config-from-file parameter that accounts for the model IDs and training datasets.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it minimizes management effort by using a single endpoint and a single monitoring job configured via `monitoring-config-from-file`.
This file allows you to specify distinct configurations for each model ID and their respective feature sets within one unified job, avoiding the overhead of managing multiple endpoints or separate data tables.

## Pregunta 223

Contexto: [topics:106](#topics-106)
You work for a pharmaceutical company based in Canada. Your team developed a BigQuery ML model to predict the number of flu infections for the next month in Canada. Weather data is published weekly, and flu infection statistics are published monthly. You need to configure a model retraining policy that minimizes cost. What should you do?

**A.** Download the weather and flu data each week. Configure Cloud Scheduler to execute a Vertex AI pipeline to retrain the model weekly.

**B.** Download the weather and flu data each month. Configure Cloud Scheduler to execute a Vertex AI pipeline to retrain the model monthly.

**C.** Download the weather and flu data each week. Configure Cloud Scheduler to execute a Vertex AI pipeline to retrain the model every month.

**D.** Download the weather data each week, and download the flu data each month. Deploy the model to a Vertex AI endpoint with feature drift monitoring, and retrain the model if a monitoring alert is detected.

**Respuesta de la fuente:** D

**Explicación:** Option D minimizes cost by avoiding fixed-schedule retraining, which incurs compute expenses regardless of whether the model's performance has degraded. Instead, it leverages Vertex AI feature drift monitoring to trigger retraining only when significant changes in input data distributions are detected, ensuring resources are used strictly when necessary.

## Pregunta 224

Contexto: [topics:106](#topics-106)
You are building a MLOps platform to automate your company’s ML experiments and model retraining. You need to organize the artifacts for dozens of pipelines. How should you store the pipelines’ artifacts?

**A.** Store parameters in Cloud SQL, and store the models’ source code and binaries in GitHub.

**B.** Store parameters in Cloud SQL, store the models’ source code in GitHub, and store the models’ binaries in Cloud Storage.

**C.** Store parameters in Vertex ML Metadata, store the models’ source code in GitHub, and store the models’ binaries in Cloud Storage.

**D.** Store parameters in Vertex ML Metadata and store the models’ source code and binaries in GitHub.

**Respuesta de la fuente:** C

**Explicación:** Vertex ML Metadata is the dedicated service for tracking ML pipeline parameters and lineage, making it superior to general-purpose databases like Cloud SQL.
Cloud Storage is the recommended scalable solution for storing large model binaries, whereas GitHub is intended only for versioning source code.

## Pregunta 225

Contexto: [topics:106](#topics-106)
You work for a telecommunications company. You’re building a model to predict which customers may fail to pay their next phone bill. The purpose of this model is to proactively offer at-risk customers assistance such as service discounts and bill deadline extensions. The data is stored in BigQuery and the predictive features that are available for model training include:

- Customer_id
- Age
- Salary (measured in local currency)
- Sex
- Average bill value (measured in local currency)
- Number of phone calls in the last month (integer)
- Average duration of phone calls (measured in minutes)

You need to investigate and mitigate potential bias against disadvantaged groups, while preserving model accuracy.

What should you do?

**A.** Determine whether there is a meaningful correlation between the sensitive features and the other features. Train a BigQuery ML boosted trees classification model and exclude the sensitive features and any meaningfully correlated features.

**B.** Train a BigQuery ML boosted trees classification model with all features. Use the ML.GLOBAL_EXPLAIN method to calculate the global attribution values for each feature of the model. If the feature importance value for any of the sensitive features exceeds a threshold, discard the model and tram without this feature.

**C.** Train a BigQuery ML boosted trees classification model with all features. Use the ML.EXPLAIN_PREDICT method to calculate the attribution values for each feature for each customer in a test set. If for any individual customer, the importance value for any feature exceeds a predefined threshold, discard the model and train the model again without this feature.

**D.** Define a fairness metric that is represented by accuracy across the sensitive features. Train a BigQuery ML boosted trees classification model with all features. Use the trained model to make predictions on a test set. Join the data back with the sensitive features, and calculate a fairness metric to investigate whether it meets your requirements.

**Respuesta de la fuente:** D

**Explicación:** Option D is the correct approach because it defines a specific fairness metric (such as equalized odds or demographic parity) to quantitatively assess model performance across sensitive groups. This method allows you to measure bias after training without prematurely discarding potentially useful features, ensuring that mitigation strategies are based on actual measured impact rather than assumptions about correlation.

## Pregunta 226

Contexto: [topics:106](#topics-106)
You recently trained a XGBoost model that you plan to deploy to production for online inference. Before sending a predict request to your model’s binary, you need to perform a simple data preprocessing step. This step exposes a REST API that accepts requests in your internal VPC Service Controls and returns predictions. You want to configure this preprocessing step while minimizing cost and effort. What should you do?

**A.** Store a pickled model in Cloud Storage. Build a Flask-based app, package the app in a custom container image, and deploy the model to Vertex AI Endpoints.

**B.** Build a Flask-based app, package the app and a pickled model in a custom container image, and deploy the model to Vertex AI Endpoints.

**C.** Build a custom predictor class based on XGBoost Predictor from the Vertex AI SDK, package it and a pickled model in a custom container image based on a Vertex built-in image, and deploy the model to Vertex AI Endpoints.

**D.** Build a custom predictor class based on XGBoost Predictor from the Vertex AI SDK, and package the handler in a custom container image based on a Vertex built-in container image. Store a pickled model in Cloud Storage, and deploy the model to Vertex AI Endpoints.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it leverages the Vertex AI SDK's built-in XGBoost Predictor, minimizing development effort by avoiding a full Flask application from scratch. Storing the model in Cloud Storage separates concerns, reducing container image size and allowing model updates without redeploying the container, which minimizes operational cost and effort.

## Pregunta 227

Contexto: [topics:106](#topics-106)
You work at a bank. You need to develop a credit risk model to support loan application decisions. You decide to implement the model by using a neural network in TensorFlow. Due to regulatory requirements, you need to be able to explain the model’s predictions based on its features. When the model is deployed, you also want to monitor the model’s performance over time. You decided to use Vertex AI for both model development and deployment. What should you do?

**A.** Use Vertex Explainable AI with the sampled Shapley method, and enable Vertex AI Model Monitoring to check for feature distribution drift.

**B.** Use Vertex Explainable AI with the sampled Shapley method, and enable Vertex AI Model Monitoring to check for feature distribution skew.

**C.** Use Vertex Explainable AI with the XRAI method, and enable Vertex AI Model Monitoring to check for feature distribution drift.

**D.** Use Vertex Explainable AI with the XRAI method, and enable Vertex AI Model Monitoring to check for feature distribution skew.

**Respuesta de la fuente:** A

**Explicación:** The credit risk model processes structured tabular data, not images; therefore, the Sampled Shapley method is appropriate for feature attribution, while XRAI (explainable AI for image regions) is irrelevant. To monitor performance degradation over time due to changes in input data characteristics, you must detect feature distribution drift rather than skew, which typically refers to inconsistencies between training and prediction pipelines.

## Pregunta 228

Contexto: [topics:106](#topics-106)
You are investigating the root cause of a misclassification error made by one of your models. You used Vertex AI Pipelines to train and deploy the model. The pipeline reads data from BigQuery. creates a copy of the data in Cloud Storage in TFRecord format, trains the model in Vertex AI Training on that copy, and deploys the model to a Vertex AI endpoint. You have identified the specific version of that model that misclassified, and you need to recover the data this model was trained on. How should you find that copy of the data?

**A.** Use Vertex AI Feature Store. Modify the pipeline to use the feature store, and ensure that all training data is stored in it. Search the feature store for the data used for the training.

**B.** Use the lineage feature of Vertex AI Metadata to find the model artifact. Determine the version of the model and identify the step that creates the data copy and search in the metadata for its location.

**C.** Use the logging features in the Vertex AI endpoint to determine the timestamp of the model’s deployment. Find the pipeline run at that timestamp. Identify the step that creates the data copy, and search in the logs for its location.

**D.** Find the job ID in Vertex AI Training corresponding to the training for the model. Search in the logs of that job for the data used for the training.

**Respuesta de la fuente:** B

**Explicación:** Vertex AI Metadata provides built-in lineage tracking that records the relationships between model artifacts and their training inputs within Vertex AI Pipelines. By tracing the lineage of the specific misclassified model version, you can identify the exact pipeline run and retrieve the URI of the TFRecord data copy stored in Cloud Storage without relying on transient logs.

## Pregunta 229

Contexto: [topics:106](#topics-106)
You work for a manufacturing company. You need to train a custom image classification model to detect product defects at the end of an assembly line. Although your model is performing well, some images in your holdout set are consistently mislabeled with high confidence. You want to use Vertex AI to understand your model’s results. What should you do?

**A.** Configure feature-based explanations by using Integrated Gradients. Set visualization type to PIXELS, and set clip_percent_upperbound to 95.

**B.** Create an index by using Vertex AI Matching Engine. Query the index with your mislabeled images.

**C.** Configure feature-based explanations by using XRAI. Set visualization type to OUTLINES, and set polarity to positive.

**D.** Configure example-based explanations. Specify the embedding output layer to be used for the latent space representation.

**Respuesta de la fuente:** D

**Explicación:** The scenario describes mislabeled images in the holdout set, which is a specific use case for example-based explanations in Vertex AI.
According to Google Cloud documentation, example-based explanations help identify why models make mistakes by retrieving similar examples from the training data to diagnose issues like data drift or labeling errors.
Feature-based explanations (A and C) highlight influential features but do not directly retrieve similar training instances to explain misclassification patterns as effectively as example-based methods in this context.

## Pregunta 230

Contexto: [topics:106](#topics-106)
You are training models in Vertex AI by using data that spans across multiple Google Cloud projects. You need to find, track, and compare the performance of the different versions of your models. Which Google Cloud services should you include in your ML workflow?

**A.** Dataplex, Vertex AI Feature Store, and Vertex AI TensorBoard

**B.** Vertex AI Pipelines, Vertex AI Feature Store, and Vertex AI Experiments

**C.** Dataplex, Vertex AI Experiments, and Vertex AI ML Metadata

**D.** Vertex AI Pipelines, Vertex AI Experiments, and Vertex AI Metadata

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 231

Contexto: [topics:106](#topics-106)
You are using Keras and TensorFlow to develop a fraud detection model. Records of customer transactions are stored in a large table in BigQuery. You need to preprocess these records in a cost-effective and efficient way before you use them to train the model. The trained model will be used to perform batch inference in BigQuery. How should you implement the preprocessing workflow?

**A.** Implement a preprocessing pipeline by using Apache Spark, and run the pipeline on Dataproc. Save the preprocessed data as CSV files in a Cloud Storage bucket.

**B.** Load the data into a pandas DataFrame. Implement the preprocessing steps using pandas transformations, and train the model directly on the DataFrame.

**C.** Perform preprocessing in BigQuery by using SQL. Use the BigQueryClient in TensorFlow to read the data directly from BigQuery.

**D.** Implement a preprocessing pipeline by using Apache Beam, and run the pipeline on Dataflow. Save the preprocessed data as CSV files in a Cloud Storage bucket.

**Respuesta de la fuente:** C

**Explicación:** Option C is the most cost-effective and efficient approach because it leverages BigQuery's built-in SQL capabilities for preprocessing, avoiding the overhead of managing separate compute clusters like Dataproc or Dataflow.
By using the TensorFlow BigQuery client to read data directly, you eliminate the need for intermediate storage exports (e.g., CSVs), reducing latency and egress costs while streamlining the end-to-end workflow.

## Pregunta 232

Contexto: [topics:106](#topics-106)
You need to use TensorFlow to train an image classification model. Your dataset is located in a Cloud Storage directory and contains millions of labeled images. Before training the model, you need to prepare the data. You want the data preprocessing and model training workflow to be as efficient, scalable, and low maintenance as possible. What should you do?

**A.** 1. Create a Dataflow job that creates sharded TFRecord files in a Cloud Storage directory.
2. Reference tf.data.TFRecordDataset in the training script.
3. Train the model by using Vertex AI Training with a V100 GPU.

**B.** 1. Create a Dataflow job that moves the images into multiple Cloud Storage directories, where each directory is named according to the corresponding label
2. Reference tfds.folder_dataset:ImageFolder in the training script.
3. Train the model by using Vertex AI Training with a V100 GPU.

**C.** 1. Create a Jupyter notebook that uses an nt-standard-64 V100 GPU Vertex AI Workbench instance.
2. Write a Python script that creates sharded TFRecord files in a directory inside the instance.
3. Reference tf.data.TFRecordDataset in the training script.
4. Train the model by using the Workbench instance.

**D.** 1. Create a Jupyter notebook that uses an n1-standard-64, V100 GPU Vertex AI Workbench instance.
2. Write a Python script that copies the images into multiple Cloud Storage directories, where each. directory is named according to the corresponding label.
3. Reference tfds.foladr_dataset.ImageFolder in the training script.
4. Train the model by using the Workbench instance.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it uses Dataflow to efficiently preprocess millions of images into sharded TFRecord files stored in Cloud Storage, which minimizes I/O overhead during training. TFRecords are the preferred format for large-scale TensorFlow training due to their binary efficiency and support for parallel reading via tf.data.TFRecordDataset. Using Vertex AI Training ensures the workflow is managed, scalable, and low-maintenance compared to manual processing on a single Workbench instance.

## Pregunta 233

Contexto: [topics:106](#topics-106)
You are building a custom image classification model and plan to use Vertex AI Pipelines to implement the end-to-end training. Your dataset consists of images that need to be preprocessed before they can be used to train the model. The preprocessing steps include resizing the images, converting them to grayscale, and extracting features. You have already implemented some Python functions for the preprocessing tasks. Which components should you use in your pipeline?

**A.** DataprocSparkBatchOp and CustomTrainingJobOp

**B.** DataflowPythonJobOp, WaitGcpResourcesOp, and CustomTrainingJobOp

**C.** dsl.ParallelFor, dsl.component, and CustomTrainingJobOp

**D.** ImageDatasetImportDataOp, dsl.component, and AutoMLImageTrainingJobRunOp

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 234

Contexto: [topics:106](#topics-106)
You work for a retail company that is using a regression model built with BigQuery ML to predict product sales. This model is being used to serve online predictions. Recently you developed a new version of the model that uses a different architecture (custom model). Initial analysis revealed that both models are performing as expected. You want to deploy the new version of the model to production and monitor the performance over the next two months. You need to minimize the impact to the existing and future model users. How should you deploy the model?

**A.** Import the new model to the same Vertex AI Model Registry as a different version of the existing model. Deploy the new model to the same Vertex AI endpoint as the existing model, and use traffic splitting to route 95% of production traffic to the BigQuery ML model and 5% of production traffic to the new model.

**B.** Import the new model to the same Vertex AI Model Registry as the existing model. Deploy the models to one Vertex AI endpoint. Route 95% of production traffic to the BigQuery ML model and 5% of production traffic to the new model.

**C.** Import the new model to the same Vertex AI Model Registry as the existing model. Deploy each model to a separate Vertex AI endpoint.

**D.** Deploy the new model to a separate Vertex AI endpoint. Create a Cloud Run service that routes the prediction requests to the corresponding endpoints based on the input feature values.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it leverages Vertex AI traffic splitting on a shared endpoint, allowing for a controlled A/B test (95/5) without requiring changes to existing client code. This minimizes impact by keeping the primary model stable while validating the new custom model in production with a small subset of traffic.

## Pregunta 235

Contexto: [topics:106](#topics-106)
You are using Vertex AI and TensorFlow to develop a custom image classification model. You need the model’s decisions and the rationale to be understandable to your company’s stakeholders. You also want to explore the results to identify any issues or potential biases. What should you do?

**A.** 1. Use TensorFlow to generate and visualize features and statistics.
2. Analyze the results together with the standard model evaluation metrics.

**B.** 1. Use TensorFlow Profiler to visualize the model execution.
2. Analyze the relationship between incorrect predictions and execution bottlenecks.

**C.** 1. Use Vertex Explainable AI to generate example-based explanations.
2. Visualize the results of sample inputs from the entire dataset together with the standard model evaluation metrics.

**D.** 1. Use Vertex Explainable AI to generate feature attributions. Aggregate feature attributions over the entire dataset.
2. Analyze the aggregation result together with the standard model evaluation metrics.

**Respuesta de la fuente:** D

**Explicación:** Vertex Explainable AI provides feature attributions (such as SHAP values) that identify which input features most influenced specific predictions, making model decisions understandable to stakeholders. Aggregating these attributions across the entire dataset reveals systematic patterns or biases that individual examples might not show, allowing for a comprehensive analysis of model fairness and performance alongside standard metrics.

## Pregunta 236

Contexto: [topics:106](#topics-106)
You work for a large retailer, and you need to build a model to predict customer chum. The company has a dataset of historical customer data, including customer demographics purchase history, and website activity. You need to create the model in BigQuery ML and thoroughly evaluate its performance. What should you do?

**A.** Create a linear regression model in BigQuery ML, and register the model in Vertex AI Model Registry. Evaluate the model performance in Vertex AI .

**B.** Create a logistic regression model in BigQuery ML and register the model in Vertex AI Model Registry. Evaluate the model performance in Vertex AI .

**C.** Create a linear regression model in BigQuery ML. Use the ML.EVALUATE function to evaluate the model performance.

**D.** Create a logistic regression model in BigQuery ML. Use the ML.CONFUSION_MATRIX function to evaluate the model performance.

**Respuesta de la fuente:** B

**Explicación:** Customer churn prediction is a binary classification problem, which requires logistic regression rather than linear regression.
Vertex AI provides comprehensive evaluation tools and model registry capabilities that allow for thorough performance assessment beyond the basic metrics available in BigQuery ML.

## Pregunta 237

Contexto: [topics:106](#topics-106)
You are developing a model to identify traffic signs in images extracted from videos taken from the dashboard of a vehicle. You have a dataset of 100,000 images that were cropped to show one out of ten different traffic signs. The images have been labeled accordingly for model training, and are stored in a Cloud Storage bucket. You need to be able to tune the model during each training run. How should you train the model?

**A.** Train a model for object detection by using Vertex AI AutoML.

**B.** Train a model for image classification by using Vertex AI AutoML.

**C.** Develop the model training code for object detection, and train a model by using Vertex AI custom training.

**D.** Develop the model training code for image classification, and train a model by using Vertex AI custom training.

**Respuesta de la fuente:** D

**Explicación:** The images are already cropped to contain a single traffic sign, which defines the problem as image classification rather than object detection (which would require bounding box coordinates for locating multiple objects). Vertex AI AutoML provides limited control over hyperparameters and model architecture, whereas Vertex AI custom training allows you to develop specific training code to tune the model as required by the prompt.

## Pregunta 238

Contexto: [topics:106](#topics-106)
You have deployed a scikit-team model to a Vertex AI endpoint using a custom model server. You enabled autoscaling: however, the deployed model fails to scale beyond one replica, which led to dropped requests. You notice that CPU utilization remains low even during periods of high load. What should you do?

**A.** Attach a GPU to the prediction nodes

**B.** Increase the number of workers in your model server

**C.** Schedule scaling of the nodes to match expected demand

**D.** Increase the minReplicaCount in your DeployedModel configuration

**Respuesta de la fuente:** B

**Explicación:** Vertex AI autoscaling for custom containers is triggered by metrics like CPU utilization or request latency. Since CPU utilization remains low despite high load, the single worker per replica is unable to saturate the available compute resources, preventing the threshold for scaling out from being reached.
Increasing the number of workers allows the model server to process more concurrent requests in parallel, thereby increasing CPU utilization and triggering autoscaling when needed.

## Pregunta 239

Contexto: [topics:106](#topics-106)
You work for a pet food company that manages an online forum. Customers upload photos of their pets on the forum to share with others. About 20 photos are uploaded daily. You want to automatically and in near real time detect whether each uploaded photo has an animal. You want to prioritize time and minimize cost of your application development and deployment. What should you do?

**A.** Send user-submitted images to the Cloud Vision API. Use object localization to identify all objects in the image and compare the results against a list of animals.

**B.** Download an object detection model from TensorFlow Hub. Deploy the model to a Vertex AI endpoint. Send new user-submitted images to the model endpoint to classify whether each photo has an animal.

**C.** Manually label previously submitted images with bounding boxes around any animals. Build an AutoML object detection model by using Vertex AI. Deploy the model to a Vertex AI endpoint Send new user-submitted images to your model endpoint to detect whether each photo has an animal.

**D.** Manually label previously submitted images as having animals or not. Create an image dataset on Vertex AI. Train a classification model by using Vertex AutoML to distinguish the two classes. Deploy the model to a Vertex AI endpoint. Send new user-submitted images to your model endpoint to classify whether each photo has an animal.

**Respuesta de la fuente:** A

**Explicación:** The requirement to minimize development time and cost favors using a pre-built managed service over training custom models. The Cloud Vision API provides immediate object detection capabilities without the need for data labeling, model training, or infrastructure management.
Options B, C, and D involve significant overhead in downloading, configuring, labeling, training, and deploying custom models, which contradicts the priority of speed and cost efficiency.

## Pregunta 240

Contexto: [topics:106](#topics-106)
You work at a mobile gaming startup that creates online multiplayer games. Recently, your company observed an increase in players cheating in the games, leading to a loss of revenue and a poor user experience You built a binary classification model to determine whether a player cheated after a completed game session, and then send a message to other downstream systems to ban the player that cheated. Your model has performed well during testing, and you now need to deploy the model to production. You want your serving solution to provide immediate classifications after a completed game session to avoid further loss of revenue. What should you do?

**A.** Import the model into Vertex AI Model Registry. Use the Vertex Batch Prediction service to run batch inference jobs.

**B.** Save the model files in a Cloud Storage bucket. Create a Cloud Function to read the model files and make online inference requests on the Cloud Function.

**C.** Save the model files in a VM. Load the model files each time there is a prediction request, and run an inference job on the VM

**D.** Import the model into Vertex AI Model Registry. Create a Vertex AI endpoint that hosts the model, and make online inference requests.

**Respuesta de la fuente:** D

**Explicación:** The requirement for 'immediate classifications' necessitates online inference rather than batch processing. Vertex AI Endpoints provide a managed, scalable service specifically designed for low-latency real-time predictions, ensuring instant response times after a game session concludes. In contrast, Batch Prediction introduces delay, while VMs or Cloud Functions lack the optimized infrastructure and automatic scaling capabilities of a dedicated ML serving platform.

## Pregunta 241

Contexto: [topics:106](#topics-106)
You have created a Vertex AI pipeline that automates custom model training. You want to add a pipeline component that enables your team to most easily collaborate when running different executions and comparing metrics both visually and programmatically. What should you do?

**A.** Add a component to the Vertex AI pipeline that logs metrics to a BigQuery table. Query the table to compare different executions of the pipeline. Connect BigQuery to Looker Studio to visualize metrics.

**B.** Add a component to the Vertex AI pipeline that logs metrics to a BigQuery table. Load the table into a pandas DataFrame to compare different executions of the pipeline. Use Matplotlib to visualize metrics.

**C.** Add a component to the Vertex AI pipeline that logs metrics to Vertex ML Metadata. Use Vertex AI Experiments to compare different executions of the pipeline. Use Vertex AI TensorBoard to visualize metrics.

**D.** Add a component to the Vertex AI pipeline that logs metrics to Vertex ML Metadata. Load the Vertex ML Metadata into a pandas DataFrame to compare different executions of the pipeline. Use Matplotlib to visualize metrics.

**Respuesta de la fuente:** C

**Explicación:** Vertex ML Metadata acts as the centralized system for tracking experiment runs and metrics, while Vertex AI Experiments provides a dedicated interface to visually compare these runs side-by-side. Additionally, Vertex AI TensorBoard integrates with this metadata to offer rich visualizations of training metrics. This native integration within Vertex AI fulfills both the programmatic and visual collaboration requirements more efficiently than building custom solutions with BigQuery or pandas.

## Pregunta 242

Contexto: [topics:106](#topics-106)
Your team is training a large number of ML models that use different algorithms, parameters, and datasets. Some models are trained in Vertex AI Pipelines, and some are trained on Vertex AI Workbench notebook instances. Your team wants to compare the performance of the models across both services. You want to minimize the effort required to store the parameters and metrics. What should you do?

**A.** Implement an additional step for all the models running in pipelines and notebooks to export parameters and metrics to BigQuery.

**B.** Create a Vertex AI experiment. Submit all the pipelines as experiment runs. For models trained on notebooks log parameters and metrics by using the Vertex AI SDK.

**C.** Implement all models in Vertex AI Pipelines Create a Vertex AI experiment, and associate all pipeline runs with that experiment.

**D.** Store all model parameters and metrics as model metadata by using the Vertex AI Metadata API.

**Respuesta de la fuente:** B

**Explicación:** Vertex AI Experiments provides a centralized location to track and compare model performance across different training environments, satisfying the goal of minimizing storage effort.
Submitting Vertex AI Pipeline runs as experiment runs automatically captures parameters and metrics without code changes.
Using the Vertex AI SDK allows notebook-based training to log data directly to the same experiment, ensuring unified comparison.

## Pregunta 243

Contexto: [topics:106](#topics-106)
You work on a team that builds state-of-the-art deep learning models by using the TensorFlow framework. Your team runs multiple ML experiments each week, which makes it difficult to track the experiment runs. You want a simple approach to effectively track, visualize, and debug ML experiment runs on Google Cloud while minimizing any overhead code. How should you proceed?

**A.** Set up Vertex AI Experiments to track metrics and parameters. Configure Vertex AI TensorBoard for visualization.

**B.** Set up a Cloud Function to write and save metrics files to a Cloud Storage bucket. Configure a Google Cloud VM to host TensorBoard locally for visualization.

**C.** Set up a Vertex AI Workbench notebook instance. Use the instance to save metrics data in a Cloud Storage bucket and to host TensorBoard locally for visualization.

**D.** Set up a Cloud Function to write and save metrics files to a BigQuery table. Configure a Google Cloud VM to host TensorBoard locally for visualization.

**Respuesta de la fuente:** A

**Explicación:** Vertex AI Experiments is the native Google Cloud solution designed specifically for tracking ML metrics and parameters with minimal code changes. It integrates seamlessly with Vertex AI TensorBoard to provide centralized visualization without the operational overhead of managing custom Cloud Functions, VMs, or local storage infrastructure found in other options.

## Pregunta 244

Contexto: [topics:106](#topics-106)
Your work for a textile manufacturing company. Your company has hundreds of machines, and each machine has many sensors. Your team used the sensory data to build hundreds of ML models that detect machine anomalies. Models are retrained daily, and you need to deploy these models in a cost-effective way. The models must operate 24/7 without downtime and make sub millisecond predictions. What should you do?

**A.** Deploy a Dataflow batch pipeline and a Vertex AI Prediction endpoint.

**B.** Deploy a Dataflow batch pipeline with the Runlnference API, and use model refresh.

**C.** Deploy a Dataflow streaming pipeline and a Vertex AI Prediction endpoint with autoscaling.

**D.** Deploy a Dataflow streaming pipeline with the Runlnference API, and use automatic model refresh.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Dataflow streaming pipelines enable the continuous, low-latency processing required for sub-millisecond predictions.

The RunInference API allows models to be invoked directly within the pipeline, reducing latency and infrastructure costs compared to external endpoints.

Automatic model refresh ensures that daily retraining updates are applied without downtime or manual redeployment.

## Pregunta 245

Contexto: [topics:106](#topics-106)
You are developing an ML model that predicts the cost of used automobiles based on data such as location, condition, model type, color, and engine/battery efficiency. The data is updated every night. Car dealerships will use the model to determine appropriate car prices. You created a Vertex AI pipeline that reads the data splits the data into training/evaluation/test sets performs feature engineering trains the model by using the training dataset and validates the model by using the evaluation dataset. You need to configure a retraining workflow that minimizes cost. What should you do?

**A.** Compare the training and evaluation losses of the current run. If the losses are similar, deploy the model to a Vertex AI endpoint. Configure a cron job to redeploy the pipeline every night.

**B.** Compare the training and evaluation losses of the current run. If the losses are similar, deploy the model to a Vertex AI endpoint with training/serving skew threshold model monitoring. When the model monitoring threshold is triggered redeploy the pipeline.

**C.** Compare the results to the evaluation results from a previous run. If the performance improved deploy the model to a Vertex AI endpoint. Configure a cron job to redeploy the pipeline every night.

**D.** Compare the results to the evaluation results from a previous run. If the performance improved deploy the model to a Vertex AI endpoint with training/serving skew threshold model monitoring. When the model monitoring threshold is triggered redeploy the pipeline.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it minimizes cost by triggering retraining only when necessary, rather than on a fixed nightly schedule (Options A and C).
Comparing evaluation results to previous runs ensures that a new model is deployed only if it demonstrates improved performance.
Adding training/serving skew monitoring allows the system to detect distribution shifts between training data and live production data automatically, initiating retraining specifically when the model's accuracy degrades in production.

## Pregunta 246

Contexto: [topics:106](#topics-106)
You recently used BigQuery ML to train an AutoML regression model. You shared results with your team and received positive feedback. You need to deploy your model for online prediction as quickly as possible. What should you do?

**A.** Retrain the model by using BigQuery ML, and specify Vertex AI as the model registry. Deploy the model from Vertex AI Model Registry to a Vertex AI endpoint,

**B.** Retrain the model by using Vertex Al Deploy the model from Vertex AI Model. Registry to a Vertex AI endpoint.

**C.** Alter the model by using BigQuery ML, and specify Vertex AI as the model registry. Deploy the model from Vertex AI Model Registry to a Vertex AI endpoint.

**D.** Export the model from BigQuery ML to Cloud Storage. Import the model into Vertex AI Model Registry. Deploy the model to a Vertex AI endpoint.

**Respuesta de la fuente:** C

**Explicación:** To deploy a BigQuery ML model for online prediction on Vertex AI without retraining, you should use the ALTER MODEL statement to register the existing model directly with the Vertex AI Model Registry. This native integration allows immediate deployment to a Vertex AI endpoint, whereas exporting to Cloud Storage (Option D) is an unnecessary manual step that is also unsupported for AutoML models.

## Pregunta 247

Contexto: [topics:106](#topics-106)
You built a deep learning-based image classification model by using on-premises data. You want to use Vertex AI to deploy the model to production. Due to security concerns, you cannot move your data to the cloud. You are aware that the input data distribution might change over time. You need to detect model performance changes in production. What should you do?

**A.** Use Vertex Explainable AI for model explainability. Configure feature-based explanations.

**B.** Use Vertex Explainable AI for model explainability. Configure example-based explanations.

**C.** Create a Vertex AI Model Monitoring job. Enable training-serving skew detection for your model.

**D.** Create a Vertex AI Model Monitoring job. Enable feature attribution skew and drift detection for your model.

**Respuesta de la fuente:** D

**Explicación:** Since the training data remains on-premises and is not available in the cloud, Vertex AI cannot calculate Training-Serving Skew (Option C), which requires comparing production data against historical training data. Therefore, Feature Attribution Drift detection (Option D) is the correct choice, as it monitors changes in feature contributions over time without needing access to the original training dataset.

## Pregunta 248

Contexto: [topics:106](#topics-106)
You trained a model packaged it with a custom Docker container for serving, and deployed it to Vertex AI Model Registry. When you submit a batch prediction job, it fails with this error: "Error model server never became ready. Please validate that your model file or container configuration are valid. " There are no additional errors in the logs. What should you do?

**A.** Add a logging configuration to your application to emit logs to Cloud Logging

**B.** Change the HTTP port in your model’s configuration to the default value of 8080

**C.** Change the healthRoute value in your model’s configuration to /healthcheck

**D.** Pull the Docker image locally, and use the docker run command to launch it locally. Use the docker logs command to explore the error logs

**Respuesta de la fuente:** D

**Explicación:** The error 'model server never became ready' indicates a failure in the container's startup or health check process. Running the container locally (Option D) allows you to inspect detailed application logs via 'docker logs', which are not visible in Vertex AI, enabling precise identification of missing dependencies, configuration errors, or runtime failures.

## Pregunta 249

Contexto: [topics:106](#topics-106)
You are developing an ML model to identify your company’s products in images. You have access to over one million images in a Cloud Storage bucket. You plan to experiment with different TensorFlow models by using Vertex AI Training. You need to read images at scale during training while minimizing data I/O bottlenecks. What should you do?

**A.** Load the images directly into the Vertex AI compute nodes by using Cloud Storage FUSE. Read the images by using the tf.data.Dataset.from_tensor_slices function

**B.** Create a Vertex AI managed dataset from your image data. Access the AIP_TRAINING_DATA_URI environment variable to read the images by using the tf.data.Dataset.list_files function.

**C.** Convert the images to TFRecords and store them in a Cloud Storage bucket. Read the TFRecords by using the tf.data.TFRecordDataset function.

**D.** Store the URLs of the images in a CSV file. Read the file by using the tf.data.experimental.CsvDataset function.

**Respuesta de la fuente:** C

**Explicación:** Option C is the correct approach because TFRecords are a binary format optimized for TensorFlow’s data pipeline, significantly reducing I/O overhead compared to reading individual image files.
Using `tf.data.TFRecordDataset` allows for efficient sequential reads and batch processing of large datasets stored in Cloud Storage, which minimizes network latency and parsing bottlenecks during distributed training.

## Pregunta 250

Contexto: [topics:106](#topics-106)
You work at an ecommerce startup. You need to create a customer churn prediction model. Your company’s recent sales records are stored in a BigQuery table. You want to understand how your initial model is making predictions. You also want to iterate on the model as quickly as possible while minimizing cost. How should you build your first model?

**A.** Export the data to a Cloud Storage bucket. Load the data into a pandas DataFrame on Vertex AI Workbench and train a logistic regression model with scikit-learn.

**B.** Create a tf.data.Dataset by using the TensorFlow BigQueryClient. Implement a deep neural network in TensorFlow.

**C.** Prepare the data in BigQuery and associate the data with a Vertex AI dataset. Create an AutoMLTabularTrainingJob to tram a classification model.

**D.** Export the data to a Cloud Storage bucket. Create a tf.data.Dataset to read the data from Cloud Storage. Implement a deep neural network in TensorFlow.

**Respuesta de la fuente:** C

**Explicación:** Vertex AI AutoML Tabular is the optimal choice because it automates feature engineering and model selection, allowing for rapid iteration with minimal coding overhead.
It leverages data directly from BigQuery to reduce export costs and automatically enables Vertex Explainable AI, which satisfies the requirement to understand how predictions are made without manual implementation of explainability tools.

## Pregunta 251

Contexto: [topics:106](#topics-106)
You are developing a training pipeline for a new XGBoost classification model based on tabular data. The data is stored in a BigQuery table. You need to complete the following steps:

1. Randomly split the data into training and evaluation datasets in a 65/35 ratio
2. Conduct feature engineering
3. Obtain metrics for the evaluation dataset
4. Compare models trained in different pipeline executions

How should you execute these steps?

**A.** 1. Using Vertex AI Pipelines, add a component to divide the data into training and evaluation sets, and add another component for feature engineering.
2. Enable autologging of metrics in the training component.
3. Compare pipeline runs in Vertex AI Experiments.

**B.** 1. Using Vertex AI Pipelines, add a component to divide the data into training and evaluation sets, and add another component for feature engineering.
2. Enable autologging of metrics in the training component.
3. Compare models using the artifacts’ lineage in Vertex ML Metadata.

**C.** 1. In BigQuery ML, use the CREATE MODEL statement with BOOSTED_TREE_CLASSIFIER as the model type and use BigQuery to handle the data splits.
2. Use a SQL view to apply feature engineering and train the model using the data in that view.
3. Compare the evaluation metrics of the models by using a SQL query with the ML.TRAINING_INFO statement.

**D.** 1. In BigQuery ML, use the CREATE MODEL statement with BOOSTED_TREE_CLASSIFIER as the model type and use BigQuery to handle the data splits.
2. Use ML TRANSFORM to specify the feature engineering transformations and tram the model using the data in the table.
3. Compare the evaluation metrics of the models by using a SQL query with the ML.TRAINING_INFO statement.

**Respuesta de la fuente:** A

**Explicación:** Vertex AI Pipelines provides the orchestration framework needed to sequence data splitting and feature engineering components reliably.
Autologging within the training component automatically captures metrics, while Vertex AI Experiments is the dedicated service designed for comparing results across different pipeline runs.
BigQuery ML lacks native integration with these workflow orchestration and experiment tracking tools.

## Pregunta 252

Contexto: [topics:106](#topics-106)
You work for a company that sells corporate electronic products to thousands of businesses worldwide. Your company stores historical customer data in BigQuery. You need to build a model that predicts customer lifetime value over the next three years. You want to use the simplest approach to build the model and you want to have access to visualization tools. What should you do?

**A.** Create a Vertex AI Workbench notebook to perform exploratory data analysis. Use IPython magics to create a new BigQuery table with input features. Use the BigQuery console to run the CREATE MODEL statement. Validate the results by using the ML.EVALUATE and ML.PREDICT statements.

**B.** Run the CREATE MODEL statement from the BigQuery console to create an AutoML model. Validate the results by using the ML.EVALUATE and ML.PREDICT statements.

**C.** Create a Vertex AI Workbench notebook to perform exploratory data analysis and create input features. Save the features as a CSV file in Cloud Storage. Import the CSV file as a new BigQuery table. Use the BigQuery console to run the CREATE MODEL statement. Validate the results by using the ML.EVALUATE and ML.PREDICT statements.

**D.** Create a Vertex AI Workbench notebook to perform exploratory data analysis. Use IPython magics to create a new BigQuery table with input features, create the model, and validate the results by using the CREATE MODEL, ML.EVALUATE, and ML.PREDICT statements.

**Respuesta de la fuente:** D

**Explicación:** Option D is the correct answer because it offers the simplest consolidated workflow by using Vertex AI Workbench notebooks for both exploratory data analysis and model creation. The requirement for 'access to visualization tools' is best satisfied within the notebook environment using Python libraries, which BigQuery ML alone does natively provide. Additionally, using IPython magics allows seamless execution of CREATE MODEL, ML.EVALUATE, and ML.PREDICT statements directly from the notebook, avoiding the complexity of exporting data or managing separate console sessions.

## Pregunta 253

Contexto: [topics:106](#topics-106)
You work for a delivery company. You need to design a system that stores and manages features such as parcels delivered and truck locations over time. The system must retrieve the features with low latency and feed those features into a model for online prediction. The data science team will retrieve historical data at a specific point in time for model training. You want to store the features with minimal effort. What should you do?

**A.** Store features in Bigtable as key/value data.

**B.** Store features in Vertex AI Feature Store.

**C.** Store features as a Vertex AI dataset, and use those features to train the models hosted in Vertex AI endpoints.

**D.** Store features in BigQuery timestamp partitioned tables, and use the BigQuery Storage Read API to serve the features.

**Respuesta de la fuente:** B

**Explicación:** Vertex AI Feature Store is the purpose-built service for managing ML features, addressing the requirement for minimal operational effort. It supports low-latency online serving for real-time predictions and provides point-in-time consistency for historical training data, satisfying all specified constraints.

## Pregunta 254

Contexto: [topics:106](#topics-106)
You are working on a prototype of a text classification model in a managed Vertex AI Workbench notebook. You want to quickly experiment with tokenizing text by using a Natural Language Toolkit (NLTK) library. How should you add the library to your Jupyter kernel?

**A.** Install the NLTK library from a terminal by using the pip install nltk command.

**B.** Write a custom Dataflow job that uses NLTK to tokenize your text and saves the output to Cloud Storage.

**C.** Create a new Vertex AI Workbench notebook with a custom image that includes the NLTK library.

**D.** Install the NLTK library from a Jupyter cell by using the !pip install nltk --user command.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because using `!pip install nltk --user` directly within a Jupyter cell allows for immediate installation of the library into the notebook's Python environment without requiring external terminal access or rebuilding container images. The `--user` flag ensures the package is installed in the user-specific directory, preventing permission errors and conflicts with system-managed packages in the managed Vertex AI Workbench environment.

## Pregunta 255

Contexto: [topics:106](#topics-106)
You have recently used TensorFlow to train a classification model on tabular data. You have created a Dataflow pipeline that can transform several terabytes of data into training or prediction datasets consisting of TFRecords. You now need to productionize the model, and you want the predictions to be automatically uploaded to a BigQuery table on a weekly schedule. What should you do?

**A.** Import the model into Vertex AI and deploy it to a Vertex AI endpoint. On Vertex AI Pipelines, create a pipeline that uses the DataflowPythonJobOp and the ModelBacthPredictOp components.

**B.** Import the model into Vertex AI and deploy it to a Vertex AI endpoint. Create a Dataflow pipeline that reuses the data processing logic sends requests to the endpoint, and then uploads predictions to a BigQuery table.

**C.** Import the model into Vertex AI. On Vertex AI Pipelines, create a pipeline that uses the
DataflowPvthonJobOp and the ModelBatchPredictOp components.

**D.** Import the model into BigQuery. Implement the data processing logic in a SQL query. On Vertex AI Pipelines create a pipeline that uses the BigquervQueryJobOp and the BigqueryPredictModelJobOp components.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because batch prediction tasks should utilize Vertex AI's managed ModelBatchPredictOp rather than deploying an online endpoint, which incurs unnecessary latency and cost for scheduled jobs.
DataflowPythonJobOp allows the existing Dataflow transformation logic to be encapsulated within a Vertex AI Pipeline component, ensuring the data preparation step integrates seamlessly with the batch prediction job.
The ModelBatchPredictOp natively supports writing results directly to BigQuery tables, fulfilling the requirement for automatic weekly uploads without requiring custom Dataflow code for data ingestion.

## Pregunta 256

Contexto: [topics:106](#topics-106)
You work for an online grocery store. You recently developed a custom ML model that recommends a recipe when a user arrives at the website. You chose the machine type on the Vertex AI endpoint to optimize costs by using the queries per second (QPS) that the model can serve, and you deployed it on a single machine with 8 vCPUs and no accelerators.

A holiday season is approaching and you anticipate four times more traffic during this time than the typical daily traffic. You need to ensure that the model can scale efficiently to the increased demand. What should you do?

**A.** 1. Maintain the same machine type on the endpoint.
2. Set up a monitoring job and an alert for CPU usage.
3. If you receive an alert, add a compute node to the endpoint.

**B.** 1. Change the machine type on the endpoint to have 32 vCPUs.
2. Set up a monitoring job and an alert for CPU usage.
3. If you receive an alert, scale the vCPUs further as needed.

**C.** 1. Maintain the same machine type on the endpoint Configure the endpoint to enable autoscaling based on vCPU usage.
2. Set up a monitoring job and an alert for CPU usage.
3. If you receive an alert, investigate the cause.

**D.** 1. Change the machine type on the endpoint to have a GPU. Configure the endpoint to enable autoscaling based on the GPU usage.
2. Set up a monitoring job and an alert for GPU usage.
3. If you receive an alert, investigate the cause.

**Respuesta de la fuente:** C

**Explicación:** Vertex AI endpoints support autoscaling, which automatically adjusts the number of machine instances based on demand metrics like CPU usage. Since the current machine type (8 vCPUs, no accelerator) is sufficient for typical traffic and appropriate for a recommendation model, enabling autoscaling allows the system to handle the fourfold traffic increase efficiently without manual intervention or unnecessary GPU costs.

## Pregunta 257

Contexto: [topics:106](#topics-106)
You recently trained an XGBoost model on tabular data. You plan to expose the model for internal use as an HTTP microservice. After deployment, you expect a small number of incoming requests. You want to productionize the model with the least amount of effort and latency. What should you do?

**A.** Deploy the model to BigQuery ML by using CREATE MODEL with the BOOSTED_TREE_REGRESSOR statement, and invoke the BigQuery API from the microservice.

**B.** Build a Flask-based app. Package the app in a custom container on Vertex AI, and deploy it to Vertex AI Endpoints.

**C.** Build a Flask-based app. Package the app in a Docker image, and deploy it to Google Kubernetes Engine in Autopilot mode.

**D.** Use a prebuilt XGBoost Vertex container to create a model, and deploy it to Vertex AI Endpoints.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because using a prebuilt Vertex AI container for XGBoost eliminates the overhead of building and maintaining custom application code or infrastructure, satisfying the 'least amount of effort' requirement. Unlike Flask-based solutions (B and C) which require manual coding, or BigQuery ML (A) which involves API latency and data movement, Vertex AI Endpoints provide a managed, low-latency serving platform optimized for direct model inference.

## Pregunta 258

Contexto: [topics:106](#topics-106)
You work for an international manufacturing organization that ships scientific products all over the world. Instruction manuals for these products need to be translated to 15 different languages. Your organization’s leadership team wants to start using machine learning to reduce the cost of manual human translations and increase translation speed. You need to implement a scalable solution that maximizes accuracy and minimizes operational overhead. You also want to include a process to evaluate and fix incorrect translations. What should you do?

**A.** Create a workflow using Cloud Function triggers. Configure a Cloud Function that is triggered when documents are uploaded to an input Cloud Storage bucket. Configure another Cloud Function that translates the documents using the Cloud Translation API, and saves the translations to an output Cloud Storage bucket. Use human reviewers to evaluate the incorrect translations.

**B.** Create a Vertex AI pipeline that processes the documents launches, an AutoML Translation training job, evaluates the translations and deploys the model to a Vertex AI endpoint with autoscaling and model monitoring. When there is a predetermined skew between training and live data, re-trigger the pipeline with the latest data.

**C.** Use AutoML Translation to train a model. Configure a Translation Hub project, and use the trained model to translate the documents. Use human reviewers to evaluate the incorrect translations.

**D.** Use Vertex AI custom training jobs to fine-tune a state-of-the-art open source pretrained model with your data. Deploy the model to a Vertex AI endpoint with autoscaling and model monitoring. When there is a predetermined skew between the training and live data, configure a trigger to run another training job with the latest data.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it leverages AutoML Translation to create a custom model that maximizes accuracy for the organization's specific scientific terminology, addressing the core requirement. Translation Hub provides a managed workflow solution that minimizes operational overhead compared to building custom infrastructure with Cloud Functions or custom training jobs. Including human reviewers establishes the necessary feedback loop to evaluate and correct translations, ensuring quality control.

## Pregunta 259

Contexto: [topics:106](#topics-106)
You have developed an application that uses a chain of multiple scikit-learn models to predict the optimal price for your company’s products. The workflow logic is shown in the diagram. Members of your team use the individual models in other solution workflows. You want to deploy this workflow while ensuring version control for each individual model and the overall workflow. Your application needs to be able to scale down to zero. You want to minimize the compute resource utilization and the manual effort required to manage this solution. What should you do?

[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/ebe66007a5628a3bfc5b.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Input
ModelA —®* Model B
t—* ModelD ——® Prediction
ModelC ———~
```

**A.** Expose each individual model as an endpoint in Vertex AI Endpoints. Create a custom container endpoint to orchestrate the workflow.

**B.** Create a custom container endpoint for the workflow that loads each model’s individual files Track the versions of each individual model in BigQuery.

**C.** Expose each individual model as an endpoint in Vertex AI Endpoints. Use Cloud Run to orchestrate the workflow.

**D.** Load each model’s individual files into Cloud Run. Use Cloud Run to orchestrate the workflow. Track the versions of each individual model in BigQuery.

**Respuesta de la fuente:** C

**Explicación:** Vertex AI Endpoints provide built-in version control and management for individual machine learning models, satisfying the requirement to track versions efficiently. Cloud Run is selected for orchestration because it supports scaling down to zero when idle, which minimizes compute resource utilization and reduces manual management effort compared to custom container endpoints.

## Pregunta 260

Contexto: [topics:106](#topics-106)
You are developing a model to predict whether a failure will occur in a critical machine part. You have a dataset consisting of a multivariate time series and labels indicating whether the machine part failed. You recently started experimenting with a few different preprocessing and modeling approaches in a Vertex AI Workbench notebook. You want to log data and track artifacts from each run. How should you set up your experiments?

**A.** 1. Use the Vertex AI SDK to create an experiment and set up Vertex ML Metadata.
2. Use the log_time_series_metrics function to track the preprocessed data, and use the log_merrics function to log loss values.

**B.** 1. Use the Vertex AI SDK to create an experiment and set up Vertex ML Metadata.
2. Use the log_time_series_metrics function to track the preprocessed data, and use the log_metrics function to log loss values.

**C.** 1. Create a Vertex AI TensorBoard instance and use the Vertex AI SDK to create an experiment and associate the TensorBoard instance.
2. Use the assign_input_artifact method to track the preprocessed data and use the log_time_series_metrics function to log loss values.

**D.** 1. Create a Vertex AI TensorBoard instance, and use the Vertex AI SDK to create an experiment and associate the TensorBoard instance.
2. Use the log_time_series_metrics function to track the preprocessed data, and use the log_metrics function to log loss values.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 261

Contexto: [topics:106](#topics-106)
You are developing a recommendation engine for an online clothing store. The historical customer transaction data is stored in BigQuery and Cloud Storage. You need to perform exploratory data analysis (EDA), preprocessing and model training. You plan to rerun these EDA, preprocessing, and training steps as you experiment with different types of algorithms. You want to minimize the cost and development effort of running these steps as you experiment. How should you configure the environment?

**A.** Create a Vertex AI Workbench user-managed notebook using the default VM instance, and use the %%bigquerv magic commands in Jupyter to query the tables.

**B.** Create a Vertex AI Workbench managed notebook to browse and query the tables directly from the JupyterLab interface.

**C.** Create a Vertex AI Workbench user-managed notebook on a Dataproc Hub, and use the %%bigquery magic commands in Jupyter to query the tables.

**D.** Create a Vertex AI Workbench managed notebook on a Dataproc cluster, and use the spark-bigquery-connector to access the tables.

**Respuesta de la fuente:** B

**Explicación:** Vertex AI Workbench managed notebooks are designed to minimize setup effort and cost by providing a pre-configured environment with integrated data access.
This allows for seamless browsing and querying of BigQuery and Cloud Storage directly within JupyterLab without manual infrastructure management.

## Pregunta 262

Contexto: [topics:106](#topics-106)
You recently deployed a model to a Vertex AI endpoint and set up online serving in Vertex AI Feature Store. You have configured a daily batch ingestion job to update your featurestore. During the batch ingestion jobs, you discover that CPU utilization is high in your featurestore’s online serving nodes and that feature retrieval latency is high. You need to improve online serving performance during the daily batch ingestion. What should you do?

**A.** Schedule an increase in the number of online serving nodes in your featurestore prior to the batch ingestion jobs

**B.** Enable autoscaling of the online serving nodes in your featurestore

**C.** Enable autoscaling for the prediction nodes of your DeployedModel in the Vertex AI endpoint

**D.** Increase the worker_count in the ImportFeatureValues request of your batch ingestion job

**Respuesta de la fuente:** A

**Explicación:** Autoscaling is reactive and cannot keep up with the sudden traffic spikes caused by batch ingestion jobs, leading to continued latency issues during the ramp-up period.
Since the batch ingestion schedule is known in advance, pre-provisioning (scheduling an increase in nodes) ensures sufficient resources are immediately available to handle the load.
This approach aligns with Google Cloud best practices for managing predictable bursts of traffic in Vertex AI Feature Store.

## Pregunta 263

Contexto: [topics:106](#topics-106)
You are developing a custom TensorFlow classification model based on tabular data. Your raw data is stored in BigQuery. contains hundreds of millions of rows, and includes both categorical and numerical features. You need to use a MaxMin scaler on some numerical features, and apply a one-hot encoding to some categorical features such as SKU names. Your model will be trained over multiple epochs. You want to minimize the effort and cost of your solution. What should you do?

**A.** 1. Write a SQL query to create a separate lookup table to scale the numerical features.
2. Deploy a TensorFlow-based model from Hugging Face to BigQuery to encode the text features.
3. Feed the resulting BigQuery view into Vertex AI Training.

**B.** 1. Use BigQuery to scale the numerical features.
2. Feed the features into Vertex AI Training.
3. Allow TensorFlow to perform the one-hot text encoding.

**C.** 1. Use TFX components with Dataflow to encode the text features and scale the numerical features.
2. Export results to Cloud Storage as TFRecords.
3. Feed the data into Vertex AI Training.

**D.** 1. Write a SQL query to create a separate lookup table to scale the numerical features.
2. Perform the one-hot text encoding in BigQuery.
3. Feed the resulting BigQuery view into Vertex AI Training.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 264

Contexto: [topics:106](#topics-106)
You work for a retail company. You have been tasked with building a model to determine the probability of churn for each customer. You need the predictions to be interpretable so the results can be used to develop marketing campaigns that target at-risk customers. What should you do?

**A.** Build a random forest regression model in a Vertex AI Workbench notebook instance. Configure the model to generate feature importances after the model is trained.

**B.** Build an AutoML tabular regression model. Configure the model to generate explanations when it makes predictions.

**C.** Build a custom TensorFlow neural network by using Vertex AI custom training. Configure the model to generate explanations when it makes predictions.

**D.** Build a random forest classification model in a Vertex AI Workbench notebook instance. Configure the model to generate feature importances after the model is trained.

**Respuesta de la fuente:** D

**Explicación:** Churn prediction is a classification problem (predicting if a customer will leave or stay), not a regression problem, which eliminates options A and B.
Between the remaining classification models, Random Forests are inherently more interpretable than neural networks because they provide feature importances, allowing marketers to understand which factors drive churn.
Therefore, building a random forest classification model is the best choice for meeting the interpretability requirement.

## Pregunta 265

Contexto: [topics:106](#topics-106)
You work for a company that is developing an application to help users with meal planning. You want to use machine learning to scan a corpus of recipes and extract each ingredient (e.g., carrot, rice, pasta) and each kitchen cookware (e.g., bowl, pot, spoon) mentioned. Each recipe is saved in an unstructured text file. What should you do?

**A.** Create a text dataset on Vertex AI for entity extraction Create two entities called “ingredient” and “cookware”, and label at least 200 examples of each entity. Train an AutoML entity extraction model to extract occurrences of these entity types. Evaluate performance on a holdout dataset.

**B.** Create a multi-label text classification dataset on Vertex AI. Create a test dataset, and label each recipe that corresponds to its ingredients and cookware. Train a multi-class classification model. Evaluate the model’s performance on a holdout dataset.

**C.** Use the Entity Analysis method of the Natural Language API to extract the ingredients and cookware from each recipe. Evaluate the model's performance on a prelabeled dataset.

**D.** Create a text dataset on Vertex AI for entity extraction. Create as many entities as there are different ingredients and cookware. Train an AutoML entity extraction model to extract those entities. Evaluate the model’s performance on a holdout dataset.

**Respuesta de la fuente:** A

**Explicación:** The task requires extracting specific mentions of ingredients and cookware from unstructured text, which is a classic Named Entity Recognition (NER) problem suited for AutoML Natural Language entity extraction.
Option A correctly defines two high-level entity types ('ingredient' and 'cookware') rather than attempting to label every possible individual item, making it scalable and manageable.
Option B describes multi-label classification, which categorizes the entire document rather than extracting specific text spans.
Option C uses a pre-built API that identifies generic entities (e.g., PRODUCT, LOCATION) but cannot be customized to recognize domain-specific terms like 'lemongrass' as an 'ingredient' without custom model training.

## Pregunta 266

Contexto: [topics:106](#topics-106)
You work for an organization that operates a streaming music service. You have a custom production model that is serving a “next song” recommendation based on a user's recent listening history. Your model is deployed on a Vertex AI endpoint. You recently retrained the same model by using fresh data. The model received positive test results offline. You now want to test the new model in production while minimizing complexity. What should you do?

**A.** Create a new Vertex AI endpoint for the new model and deploy the new model to that new endpoint. Build a service to randomly send 5% of production traffic to the new endpoint. Monitor end-user metrics such as listening time. If end-user metrics improve between models over time, gradually increase the percentage of production traffic sent to the new endpoint.

**B.** Capture incoming prediction requests in BigQuery. Create an experiment in Vertex AI Experiments. Run batch predictions for both models using the captured data. Use the user’s selected song to compare the models performance side by side. If the new model’s performance metrics are better than the previous model, deploy the new model to production.

**C.** Deploy the new model to the existing Vertex AI endpoint. Use traffic splitting to send 5% of production traffic to the new model. Monitor end-user metrics, such as listening time. If end-user metrics improve between models over time, gradually increase the percentage of production traffic sent to the new model.

**D.** Configure a model monitoring job for the existing Vertex AI endpoint. Configure the monitoring job to detect prediction drift and set a threshold for alerts. Update the model on the endpoint from the previous model to the new model. If you receive an alert of prediction drift, revert to the previous model.

**Respuesta de la fuente:** C

**Explicación:** Vertex AI supports deploying multiple models to a single endpoint and managing traffic distribution via built-in traffic splitting, which directly addresses the requirement to minimize complexity. Option C leverages this native feature to conduct an A/B test without the overhead of creating new endpoints or external routing services (Option A). Option B relies on offline batch predictions rather than real-time production testing, while Option D uses drift monitoring for stability rather than comparative performance validation.

## Pregunta 267

Contexto: [topics:106](#topics-106)
You created a model that uses BigQuery ML to perform linear regression. You need to retrain the model on the cumulative data collected every week. You want to minimize the development effort and the scheduling cost. What should you do?

**A.** Use BigQuery’s scheduling service to run the model retraining query periodically.

**B.** Create a pipeline in Vertex AI Pipelines that executes the retraining query, and use the Cloud Scheduler API to run the query weekly.

**C.** Use Cloud Scheduler to trigger a Cloud Function every week that runs the query for retraining the model.

**D.** Use the BigQuery API Connector and Cloud Scheduler to trigger Workflows every week that retrains the model.

**Respuesta de la fuente:** A

**Explicación:** BigQuery’s built-in scheduling service allows you to automatically retrain models on a defined schedule without writing additional code or managing external services. This approach directly minimizes development effort and avoids the overhead costs associated with configuring Cloud Functions, Vertex AI Pipelines, or Workflows.

## Pregunta 268

Contexto: [topics:106](#topics-106)
You want to migrate a scikit-learn classifier model to TensorFlow. You plan to train the TensorFlow classifier model using the same training set that was used to train the scikit-learn model, and then compare the performances using a common test set. You want to use the Vertex AI Python SDK to manually log the evaluation metrics of each model and compare them based on their F1 scores and confusion matrices. How should you log the metrics?

**A.** Use the aiplatform.log_classification_metrics function to log the F1 score, and use the aiplatform.log_metrics function to log the confusion matrix.

**B.** Use the aiplatform.log_classification_metrics function to log the F1 score and the confusion matrix.

**C.** Use the aiplatform.log_metrics function to log the F1 score and the confusion matrix.

**D.** Use the aiplatform.log_metrics function to log the F1 score: and use the aiplatform.log_classification_metrics function to log the confusion matrix.

**Respuesta de la fuente:** D

**Explicación:** The aiplatform.log_classification_metrics function is specifically designed for classification-specific artifacts like confusion matrices and ROC curves.
The generic aiplatform.log_metrics function is used for logging standard scalar metrics such as F1 scores, accuracy, or precision.
Therefore, you must use log_metrics for the F1 score and log_classification_metrics for the confusion matrix.

## Pregunta 269

Contexto: [topics:106](#topics-106)
You are developing a model to help your company create more targeted online advertising campaigns. You need to create a dataset that you will use to train the model. You want to avoid creating or reinforcing unfair bias in the model. What should you do? (Choose two.)

**A.** Include a comprehensive set of demographic features

**B.** Include only the demographic groups that most frequently interact with advertisements

**C.** Collect a random sample of production traffic to build the training dataset

**D.** Collect a stratified sample of production traffic to build the training dataset

**E.** Conduct fairness tests across sensitive categories and demographics on the trained model

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 270

Contexto: [topics:106](#topics-106)
You are developing an ML model in a Vertex AI Workbench notebook. You want to track artifacts and compare models during experimentation using different approaches. You need to rapidly and easily transition successful experiments to production as you iterate on your model implementation. What should you do?

**A.** 1. Initialize the Vertex SDK with the name of your experiment. Log parameters and metrics for each experiment, and attach dataset and model artifacts as inputs and outputs to each execution.
2. After a successful experiment create a Vertex AI pipeline.

**B.** 1. Initialize the Vertex SDK with the name of your experiment. Log parameters and metrics for each experiment, save your dataset to a Cloud Storage bucket, and upload the models to Vertex AI Model Registry.
2. After a successful experiment, create a Vertex AI pipeline.

**C.** 1. Create a Vertex AI pipeline with parameters you want to track as arguments to your PipelineJob. Use the Metrics, Model, and Dataset artifact types from the Kubeflow Pipelines DSL as the inputs and outputs of the components in your pipeline.
2. Associate the pipeline with your experiment when you submit the job.

**D.** 1. Create a Vertex AI pipeline. Use the Dataset and Model artifact types from the Kubeflow Pipelines DSL as the inputs and outputs of the components in your pipeline.
2. In your training component, use the Vertex AI SDK to create an experiment run. Configure the log_params and log_metrics functions to track parameters and metrics of your experiment.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because the Vertex AI SDK for Python allows direct logging of parameters, metrics, and artifacts (like datasets and models) to Vertex AI Experiments from within a notebook environment. This integrated approach satisfies the requirement for rapid iteration and easy tracking without the overhead of manually managing Cloud Storage or defining complex pipeline structures during the experimentation phase.

## Pregunta 271

Contexto: [topics:106](#topics-106)
You recently created a new Google Cloud project. After testing that you can submit a Vertex AI Pipeline job from the Cloud Shell, you want to use a Vertex AI Workbench user-managed notebook instance to run your code from that instance. You created the instance and ran the code but this time the job fails with an insufficient permissions error. What should you do?

**A.** Ensure that the Workbench instance that you created is in the same region of the Vertex AI Pipelines resources you will use.

**B.** Ensure that the Vertex AI Workbench instance is on the same subnetwork of the Vertex AI Pipeline resources that you will use.

**C.** Ensure that the Vertex AI Workbench instance is assigned the Identity and Access Management (IAM) Vertex AI User role.

**D.** Ensure that the Vertex AI Workbench instance is assigned the Identity and Access Management (IAM) Notebooks Runner role.

**Respuesta de la fuente:** C

**Explicación:** The error is explicitly an 'insufficient permissions' issue, indicating a lack of Identity and Access Management (IAM) rights rather than a networking or regional misconfiguration.
To submit Vertex AI Pipeline jobs, the service account running the notebook must have the `Vertex AI User` role, which grants necessary permissions such as `aiplatform.pipelineJobs.create`.
The `Notebooks Runner` role is insufficient because it only allows execution of notebook code and does not confer permissions to manage or submit external Vertex AI resources like pipelines.

## Pregunta 272

Contexto: [topics:106](#topics-106)
You work for a semiconductor manufacturing company. You need to create a real-time application that automates the quality control process. High-definition images of each semiconductor are taken at the end of the assembly line in real time. The photos are uploaded to a Cloud Storage bucket along with tabular data that includes each semiconductor’s batch number, serial number, dimensions, and weight. You need to configure model training and serving while maximizing model accuracy. What should you do?

**A.** Use Vertex AI Data Labeling Service to label the images, and tram an AutoML image classification model. Deploy the model, and configure Pub/Sub to publish a message when an image is categorized into the failing class.

**B.** Use Vertex AI Data Labeling Service to label the images, and train an AutoML image classification model. Schedule a daily batch prediction job that publishes a Pub/Sub message when the job completes.

**C.** Convert the images into an embedding representation. Import this data into BigQuery, and train a BigQuery ML K-means clustering model with two clusters. Deploy the model and configure Pub/Sub to publish a message when a semiconductor’s data is categorized into the failing cluster.

**D.** Import the tabular data into BigQuery, use Vertex AI Data Labeling Service to label the data and train an AutoML tabular classification model. Deploy the model, and configure Pub/Sub to publish a message when a semiconductor’s data is categorized into the failing class.

**Respuesta de la fuente:** A

**Explicación:** Vertex AI AutoML Image Classification is the most appropriate choice for maximizing accuracy on high-definition visual data for quality control.
Option A enables real-time inference by integrating with Pub/Sub, ensuring immediate feedback upon image upload.
Other options fail because batch prediction (B) lacks real-time capability, BigQuery ML K-means (C) uses unsupervised clustering which is less accurate for classification than supervised AutoML, and tabular-only models (D) ignore the rich visual features in the images.

## Pregunta 273

Contexto: [topics:106](#topics-106)
You work for a rapidly growing social media company. Your team builds TensorFlow recommender models in an on-premises CPU cluster. The data contains billions of historical user events and 100,000 categorical features. You notice that as the data increases, the model training time increases. You plan to move the models to Google Cloud. You want to use the most scalable approach that also minimizes training time. What should you do?

**A.** Deploy the training jobs by using TPU VMs with TPUv3 Pod slices, and use the TPUEmbeading API

**B.** Deploy the training jobs in an autoscaling Google Kubernetes Engine cluster with CPUs

**C.** Deploy a matrix factorization model training job by using BigQuery ML

**D.** Deploy the training jobs by using Compute Engine instances with A100 GPUs, and use the tf.nn.embedding_lookup API

**Respuesta de la fuente:** A

**Explicación:** The scenario involves a recommender system with billions of events and 100,000 categorical features, which creates significant lookup bottlenecks during training.
TPUv3 Pod slices provide the necessary distributed computing power for scalable training, while the TPUEmbedding API is specifically optimized to handle large-scale embedding lookups efficiently.
This combination minimizes training time by offloading and parallelizing the most compute-intensive part of the process, unlike standard CPU or GPU implementations which struggle with such high-dimensional sparse data.

## Pregunta 274

Contexto: [topics:106](#topics-106)
You are training and deploying updated versions of a regression model with tabular data by using Vertex AI Pipelines, Vertex AI Training, Vertex AI Experiments, and Vertex AI Endpoints. The model is deployed in a Vertex AI endpoint, and your users call the model by using the Vertex AI endpoint. You want to receive an email when the feature data distribution changes significantly, so you can retrigger the training pipeline and deploy an updated version of your model. What should you do?

**A.** Use Vertex Al Model Monitoring. Enable prediction drift monitoring on the endpoint, and specify a notification email.

**B.** In Cloud Logging, create a logs-based alert using the logs in the Vertex Al endpoint. Configure Cloud Logging to send an email when the alert is triggered.

**C.** In Cloud Monitoring create a logs-based metric and a threshold alert for the metric. Configure Cloud Monitoring to send an email when the alert is triggered.

**D.** Export the container logs of the endpoint to BigQuery. Create a Cloud Function to run a SQL query over the exported logs and send an email. Use Cloud Scheduler to trigger the Cloud Function.

**Respuesta de la fuente:** A

**Explicación:** Vertex AI Model Monitoring is the specialized service designed to detect data drift and prediction quality issues in deployed models.
By enabling prediction drift monitoring, you can configure automated alerts for significant changes in feature distribution without building custom logging or query pipelines.

## Pregunta 275

Contexto: [topics:106](#topics-106)
You have trained an XGBoost model that you plan to deploy on Vertex AI for online prediction. You are now uploading your model to Vertex AI Model Registry, and you need to configure the explanation method that will serve online prediction requests to be returned with minimal latency. You also want to be alerted when feature attributions of the model meaningfully change over time. What should you do?

**A.** 1. Specify sampled Shapley as the explanation method with a path count of 5.
2. Deploy the model to Vertex AI Endpoints.
3. Create a Model Monitoring job that uses prediction drift as the monitoring objective.

**B.** 1. Specify Integrated Gradients as the explanation method with a path count of 5.
2. Deploy the model to Vertex AI Endpoints.
3. Create a Model Monitoring job that uses prediction drift as the monitoring objective.

**C.** 1. Specify sampled Shapley as the explanation method with a path count of 50.
2. Deploy the model to Vertex AI Endpoints.
3. Create a Model Monitoring job that uses training-serving skew as the monitoring objective.

**D.** 1. Specify Integrated Gradients as the explanation method with a path count of 50.
2. Deploy the model to Vertex AI Endpoints.
3. Create a Model Monitoring job that uses training-serving skew as the monitoring objective.

**Respuesta de la fuente:** A

**Explicación:** For XGBoost models on Vertex AI, Sampled Shapley is the supported explanation method, whereas Integrated Gradients is restricted to specific neural network types. To minimize latency for online predictions, a lower path count (5) reduces computational overhead compared to a higher count (50). Additionally, Prediction Drift monitoring detects changes in model behavior and feature attributions over time, which aligns with the requirement to alert on meaningful shifts in feature importance.

## Pregunta 276

Contexto: [topics:106](#topics-106)
You work at a gaming startup that has several terabytes of structured data in Cloud Storage. This data includes gameplay time data, user metadata, and game metadata. You want to build a model that recommends new games to users that requires the least amount of coding. What should you do?

**A.** Load the data in BigQuery. Use BigQuery ML to train an Autoencoder model.

**B.** Load the data in BigQuery. Use BigQuery ML to train a matrix factorization model.

**C.** Read data to a Vertex AI Workbench notebook. Use TensorFlow to train a two-tower model.

**D.** Read data to a Vertex AI Workbench notebook. Use TensorFlow to train a matrix factorization model.

**Respuesta de la fuente:** B

**Explicación:** The requirement for the 'least amount of coding' points directly to BigQuery ML, as it allows model training using SQL queries without writing custom code in notebooks (eliminating C and D). Among the remaining options, matrix factorization is the standard algorithmic approach for building collaborative filtering recommendation systems, whereas autoencoders are primarily used for anomaly detection or data compression. Therefore, using BigQuery ML to train a matrix factorization model satisfies both constraints.

## Pregunta 277

Contexto: [topics:106](#topics-106)
You work for a large bank that serves customers through an application hosted in Google Cloud that is running in the US and Singapore. You have developed a PyTorch model to classify transactions as potentially fraudulent or not. The model is a three-layer perceptron that uses both numerical and categorical features as input, and hashing happens within the model.

You deployed the model to the us-central1 region on nl-highcpu-16 machines, and predictions are served in real time. The model's current median response latency is 40 ms. You want to reduce latency, especially in Singapore, where some customers are experiencing the longest delays. What should you do?

**A.** Attach an NVIDIA T4 GPU to the machines being used for online inference.

**B.** Change the machines being used for online inference to nl-highcpu-32.

**C.** Deploy the model to Vertex AI private endpoints in the us-central1 and asia-southeast1 regions, and allow the application to choose the appropriate endpoint.

**D.** Create another Vertex AI endpoint in the asia-southeast1 region, and allow the application to choose the appropriate endpoint.

**Respuesta de la fuente:** C

**Explicación:** The primary cause of high latency in Singapore is network distance to the us-central1 model, so deploying a regional endpoint in asia-southeast1 reduces physical transmission delays.
Option C is superior to D because it specifies Vertex AI private endpoints, which are required for a bank application to maintain security and compliance by avoiding public internet traffic.

## Pregunta 278

Contexto: [topics:106](#topics-106)
You need to train an XGBoost model on a small dataset. Your training code requires custom dependencies. You want to minimize the startup time of your training job. How should you set up your Vertex AI custom training job?

**A.** Store the data in a Cloud Storage bucket, and create a custom container with your training application. In your training application, read the data from Cloud Storage and train the model.

**B.** Use the XGBoost prebuilt custom container. Create a Python source distribution that includes the data and installs the dependencies at runtime. In your training application, load the data into a pandas DataFrame and train the model.

**C.** Create a custom container that includes the data. In your training application, load the data into a pandas DataFrame and train the model.

**D.** Store the data in a Cloud Storage bucket, and use the XGBoost prebuilt custom container to run your training application. Create a Python source distribution that installs the dependencies at runtime. In your training application, read the data from Cloud Storage and train the model.

**Respuesta de la fuente:** A

**Explicación:** Option A is the correct answer because building a custom container allows you to bake in all required dependencies during the image build process, eliminating the runtime overhead of installing them via source distributions (as seen in options B and D).

Regarding data handling, storing small datasets in Cloud Storage keeps the container image lean, ensuring faster pull and startup times compared to bundling data inside the image (Option C), while the network latency for small files is negligible.

## Pregunta 279

Contexto: [topics:106](#topics-106)
You are creating an ML pipeline for data processing, model training, and model deployment that uses different Google Cloud services. You have developed code for each individual task, and you expect a high frequency of new files. You now need to create an orchestration layer on top of these tasks. You only want this orchestration pipeline to run if new files are present in your dataset in a Cloud Storage bucket. You also want to minimize the compute node costs. What should you do?

**A.** Create a pipeline in Vertex AI Pipelines. Configure the first step to compare the contents of the bucket to the last time the pipeline was run. Use the scheduler API to run the pipeline periodically.

**B.** Create a Cloud Function that uses a Cloud Storage trigger and deploys a Cloud Composer directed acyclic graph (DAG).

**C.** Create a pipeline in Vertex AI Pipelines. Create a Cloud Function that uses a Cloud Storage trigger and deploys the pipeline.

**D.** Deploy a Cloud Composer directed acyclic graph (DAG) with a GCSObjectUpdateSensor class that detects when a new file is added to the Cloud Storage bucket.

**Respuesta de la fuente:** C

**Explicación:** Option C is the correct answer because it leverages Vertex AI Pipelines for serverless orchestration, eliminating the ongoing infrastructure costs associated with maintaining a Cloud Composer (Airflow) environment.
By using a Cloud Function triggered by Cloud Storage events, the pipeline executes only when new files are detected, satisfying the requirement to minimize compute node costs while handling high-frequency data updates efficiently.

## Pregunta 280

Contexto: [topics:106](#topics-106)
You are using Kubeflow Pipelines to develop an end-to-end PyTorch-based MLOps pipeline. The pipeline reads data from BigQuery, processes the data, conducts feature engineering, model training, model evaluation, and deploys the model as a binary file to Cloud Storage. You are writing code for several different versions of the feature engineering and model training steps, and running each new version in Vertex AI Pipelines. Each pipeline run is taking over an hour to complete. You want to speed up the pipeline execution to reduce your development time, and you want to avoid additional costs. What should you do?

**A.** Comment out the part of the pipeline that you are not currently updating.

**B.** Enable caching in all the steps of the Kubeflow pipeline.

**C.** Delegate feature engineering to BigQuery and remove it from the pipeline.

**D.** Add a GPU to the model training step.

**Respuesta de la fuente:** B

**Explicación:** Enabling caching allows Kubeflow Pipelines to reuse the outputs of steps whose inputs and code have not changed. Since you are only modifying specific steps like feature engineering or training, cached results from unchanged upstream steps (like data loading) prevent redundant computation, significantly reducing execution time without incurring extra resource costs.

## Pregunta 281

Contexto: [topics:106](#topics-106)
You work at a large organization that recently decided to move their ML and data workloads to Google Cloud. The data engineering team has exported the structured data to a Cloud Storage bucket in Avro format. You need to propose a workflow that performs analytics, creates features, and hosts the features that your ML models use for online prediction. How should you configure the pipeline?

**A.** Ingest the Avro files into Cloud Spanner to perform analytics. Use a Dataflow pipeline to create the features, and store them in Vertex AI Feature Store for online prediction.

**B.** Ingest the Avro files into BigQuery to perform analytics. Use a Dataflow pipeline to create the features, and store them in Vertex AI Feature Store for online prediction.

**C.** Ingest the Avro files into Cloud Spanner to perform analytics. Use a Dataflow pipeline to create the features, and store them in BigQuery for online prediction.

**D.** Ingest the Avro files into BigQuery to perform analytics. Use BigQuery SQL to create features and store them in a separate BigQuery table for online prediction.

**Respuesta de la fuente:** B

**Explicación:** BigQuery is the optimal service for performing analytics on large structured datasets like Avro files, whereas Cloud Spanner is designed for transactional workloads.
Vertex AI Feature Store is specifically built to host and serve features with low latency required for online prediction, unlike BigQuery which has higher query latency.

## Pregunta 282

Contexto: [topics:106](#topics-106)
You work at an organization that maintains a cloud-based communication platform that integrates conventional chat, voice, and video conferencing into one platform. The audio recordings are stored in Cloud Storage. All recordings have an 8 kHz sample rate and are more than one minute long. You need to implement a new feature in the platform that will automatically transcribe voice call recordings into a text for future applications, such as call summarization and sentiment analysis. How should you implement the voice call transcription feature following Google-recommended best practices?

**A.** Use the original audio sampling rate, and transcribe the audio by using the Speech-to-Text API with synchronous recognition.

**B.** Use the original audio sampling rate, and transcribe the audio by using the Speech-to-Text API with asynchronous recognition.

**C.** Upsample the audio recordings to 16 kHz, and transcribe the audio by using the Speech-to-Text API with synchronous recognition.

**D.** Upsample the audio recordings to 16 kHz, and transcribe the audio by using the Speech-to-Text API with asynchronous recognition.

**Respuesta de la fuente:** B

**Explicación:** Google recommends using asynchronous recognition for audio files longer than 60 seconds to handle processing time and cost efficiency.
Additionally, while 16 kHz is preferred, Google advises against re-sampling (upsampling) when the native source rate is 8 kHz, as this can introduce artifacts without significant benefit for telephony-quality audio.

## Pregunta 283

Contexto: [topics:106](#topics-106)
You work for a multinational organization that has recently begun operations in Spain. Teams within your organization will need to work with various Spanish documents, such as business, legal, and financial documents. You want to use machine learning to help your organization get accurate translations quickly and with the least effort. Your organization does not require domain-specific terms or jargon. What should you do?

**A.** Create a Vertex AI Workbench notebook instance. In the notebook, extract sentences from the documents, and train a custom AutoML text model.

**B.** Use Google Translate to translate 1,000 phrases from Spanish to English. Using these translated pairs, train a custom AutoML Translation model.

**C.** Use the Document Translation feature of the Cloud Translation API to translate the documents.

**D.** Create a Vertex AI Workbench notebook instance. In the notebook, convert the Spanish documents into plain text, and create a custom TensorFlow seq2seq translation model.

**Respuesta de la fuente:** C

**Explicación:** The requirement for the least effort and quick translation without domain-specific customization points to using a pre-built service rather than training custom models.
The Cloud Translation API's Document Translation feature is specifically designed to translate entire documents while preserving formatting, requiring minimal setup compared to creating notebooks or training AutoML/TensorFlow models.

## Pregunta 284

Contexto: [topics:106](#topics-106)
You have a custom job that runs on Vertex AI on a weekly basis. The job is implemented using a proprietary ML workflow that produces the datasets, models, and custom artifacts, and sends them to a Cloud Storage bucket. Many different versions of the datasets and models were created. Due to compliance requirements, your company needs to track which model was used for making a particular prediction, and needs access to the artifacts for each model. How should you configure your workflows to meet these requirements?

**A.** Use the Vertex AI Metadata API inside the custom job to create context, execution, and artifacts for each model, and use events to link them together.

**B.** Create a Vertex AI experiment, and enable autologging inside the custom job.

**C.** Configure a TensorFlow Extended (TFX) ML Metadata database, and use the ML Metadata API.

**D.** Register each model in Vertex AI Model Registry, and use model labels to store the related dataset and model information.

**Respuesta de la fuente:** A

**Explicación:** Vertex AI Metadata API is designed to track the lineage of ML pipelines by managing Artifacts, Executions, Contexts, and Events.
This allows you to explicitly link specific dataset versions and custom job executions to the resulting model artifacts.
Such granular tracking satisfies the compliance requirement to identify exactly which model version was used for any given prediction.

## Pregunta 285

Contexto: [topics:106](#topics-106)
You have recently developed a custom model for image classification by using a neural network. You need to automatically identify the values for learning rate, number of layers, and kernel size. To do this, you plan to run multiple jobs in parallel to identify the parameters that optimize performance. You want to minimize custom code development and infrastructure management. What should you do?

**A.** Train an AutoML image classification model.

**B.** Create a custom training job that uses the Vertex AI Vizier SDK for parameter optimization.

**C.** Create a Vertex AI hyperparameter tuning job.

**D.** Create a Vertex AI pipeline that runs different model training jobs in parallel.

**Respuesta de la fuente:** C

**Explicación:** Vertex AI Hyperparameter Tuning is specifically designed to optimize model parameters like learning rate and kernel size by automatically running parallel training jobs with different parameter combinations.

This service directly addresses the requirement to minimize custom code and infrastructure management, whereas using the Vizier SDK (Option B) requires additional development effort. Option A refers to AutoML, which builds a new model rather than tuning an existing custom neural network.

## Pregunta 286

Contexto: [topics:106](#topics-106)
You work for a company that builds bridges for cities around the world. To track the progress of projects at the construction sites, your company has set up cameras at each location. Each hour, the cameras take a picture that is sent to a Cloud Storage bucket. A team of specialists reviews the images, filters important ones, and then annotates specific objects in them. You want to propose using an ML solution that will help the company scale and reduce costs. You need the solution to have minimal up-front cost. What method should you propose?

**A.** Train an AutoML object detection model to annotate the objects in the images to help specialists with the annotation task.

**B.** Use the Cloud Vision API to automatically annotate objects in the images to help specialists with the annotation task.

**C.** Create a BigQuery ML classification model to classify important images. Use the model to predict which new images are important to help specialists with the filtering task.

**D.** Use Vertex AI to train an open source object detection to annotate the objects in the images to help specialists with the annotation task.

**Respuesta de la fuente:** B

**Explicación:** The Cloud Vision API is a pre-trained, pay-per-use service that requires no model training, thereby satisfying the requirement for minimal up-front cost. In contrast, AutoML and custom Vertex AI models incur significant training fees and preparation overhead. BigQuery ML is designed primarily for tabular data analysis and is not suitable for image processing tasks.

## Pregunta 287

Contexto: [topics:106](#topics-106)
You are tasked with building an MLOps pipeline to retrain tree-based models in production. The pipeline will include components related to data ingestion, data processing, model training, model evaluation, and model deployment. Your organization primarily uses PySpark-based workloads for data preprocessing. You want to minimize infrastructure management effort. How should you set up the pipeline?

**A.** Set up a TensorFlow Extended (TFX) pipeline on Vertex AI Pipelines to orchestrate the MLOps pipeline. Write a custom component for the PySpark-based workloads on Dataproc.

**B.** Set up a Vertex AI Pipelines to orchestrate the MLOps pipeline. Use the predefined Dataproc component for the PySpark-based workloads.

**C.** Set up Kubeflow Pipelines on Google Kubernetes Engine to orchestrate the MLOps pipeline. Write a custom component for the PySparkbased workloads on Dataproc.

**D.** Set up Cloud Composer to orchestrate the MLOps pipeline. Use Dataproc workflow templates for the PySpark-based workloads in Cloud Composer.

**Respuesta de la fuente:** B

**Explicación:** Vertex AI Pipelines is the fully managed orchestration service that best minimizes infrastructure management effort compared to Kubeflow or Cloud Composer.
Using the predefined Dataproc component eliminates the need to write and maintain custom connectors for PySpark workloads, further reducing operational overhead.

## Pregunta 288

Contexto: [topics:106](#topics-106)
You have developed an AutoML tabular classification model that identifies high-value customers who interact with your organization's website. You plan to deploy the model to a new Vertex AI endpoint that will integrate with your website application. You expect higher traffic to the website during nights and weekends. You need to configure the model endpoint's deployment settings to minimize latency and cost. What should you do?

**A.** Configure the model deployment settings to use an n1-standard-32 machine type.

**B.** Configure the model deployment settings to use an n1-standard-4 machine type. Set the minReplicaCount value to 1 and the maxReplicaCount value to 8.

**C.** Configure the model deployment settings to use an n1-standard-4 machine type and a GPU accelerator. Set the minReplicaCount value to 1 and the maxReplicaCount value to 4.

**D.** Configure the model deployment settings to use an n1-standard-8 machine type and a GPU accelerator.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it balances cost and latency by using an appropriately sized machine type (n1-standard-4) with autoscaling (minReplicaCount 1 to maxReplicaCount 8) to handle variable traffic. Tabular classification models typically run efficiently on CPUs, making GPU accelerators in options C and D unnecessary and more expensive. Option A uses a significantly larger machine that incurs higher costs without providing proportional benefits for this workload.

## Pregunta 289

Contexto: [topics:106](#topics-106)
You developed a BigQuery ML linear regressor model by using a training dataset stored in a BigQuery table. New data is added to the table every minute. You are using Cloud Scheduler and Vertex AI Pipelines to automate hourly model training, and use the model for direct inference. The feature preprocessing logic includes quantile bucketization and MinMax scaling on data received in the last hour. You want to minimize storage and computational overhead. What should you do?

**A.** Preprocess and stage the data in BigQuery prior to feeding it to the model during training and inference.

**B.** Use the TRANSFORM clause in the CREATE MODEL statement in the SQL query to calculate the required statistics.

**C.** Create a component in the Vertex AI Pipelines directed acyclic graph (DAG) to calculate the required statistics, and pass the statistics on to subsequent components.

**D.** Create SQL queries to calculate and store the required statistics in separate BigQuery tables that are referenced in the CREATE MODEL statement.

**Respuesta de la fuente:** B

**Explicación:** The TRANSFORM clause in BigQuery ML performs feature preprocessing directly within the model creation and evaluation process, eliminating the need for intermediate data storage. This approach minimizes both storage costs (by avoiding separate tables for preprocessed data or statistics) and computational overhead (by integrating preprocessing into a single SQL execution). Options A, C, and D introduce additional components or storage requirements that contradict the goal of minimizing overhead.

## Pregunta 290

Contexto: [topics:106](#topics-106)
You developed a Python module by using Keras to train a regression model. You developed two model architectures, linear regression and deep neural network (DNN), within the same module. You are using the training_method argument to select one of the two methods, and you are using the learning_rate and num_hidden_layers arguments in the DNN. You plan to use Vertex AI's hypertuning service with a budget to perform 100 trials. You want to identify the model architecture and hyperparameter values that minimize training loss and maximize model performance. What should you do?

**A.** Run one hypertuning job for 100 trials. Set num_hidden_layers as a conditional hyperparameter based on its parent hyperparameter training_method, and set learning_rate as a non-conditional hyperparameter.

**B.** Run two separate hypertuning jobs, a linear regression job for 50 trials, and a DNN job for 50 trials. Compare their final performance on a common validation set, and select the set of hyperparameters with the least training loss.

**C.** Run one hypertuning job with training_method as the hyperparameter for 50 trials. Select the architecture with the lowest training loss, and further hypertune it and its corresponding hyperparameters tor 50 trials.

**D.** Run one hypertuning job for 100 trials. Set num_hidden_layers and learning_rate as conditional hyperparameters based on their parent hyperparameter training_method.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 291

Contexto: [topics:106](#topics-106)
You work for a hospital. You received approval to collect the necessary patient data, and you trained a Vertex AI tabular AutoML model that calculates patients' risk score for hospital admission. You deployed the model. However, you're concerned that patient demographics might change over time and alter the feature interactions and impact prediction accuracy. You want to be alerted if feature interactions change, and you want to understand the importance of the features for the predictions. You want your alerting approach to minimize cost. What should you do?

**A.** Create a feature drift monitoring job. Set the sampling rate to 1 and the monitoring frequency to weekly.

**B.** Create a feature drift monitoring job. Set the sampling rate to 0.1 and the monitoring frequency to weekly.

**C.** Create a feature attribution drift monitoring job. Set the sampling rate to 1 and the monitoring frequency to weekly.

**D.** Create a feature attribution drift monitoring job. Set the sampling rate to 0.1 and the monitoring frequency to weekly.

**Respuesta de la fuente:** D

**Explicación:** Feature attribution drift monitoring is required because the goal is to detect changes in feature interactions and their impact on predictions, not just changes in raw feature distributions.
To minimize cost as specified, a sampling rate of 0.1 (10%) should be used instead of 1 (100%), reducing the computational overhead of calculating attributions for every prediction.

## Pregunta 292

Contexto: [topics:106](#topics-106)
You are developing a TensorFlow Extended (TFX) pipeline with standard TFX components. The pipeline includes data preprocessing steps. After the pipeline is deployed to production, it will process up to 100 TB of data stored in BigQuery. You need the data preprocessing steps to scale efficiently, publish metrics and parameters to Vertex AI Experiments, and track artifacts by using Vertex ML Metadata. How should you configure the pipeline run?

**A.** Run the TFX pipeline in Vertex AI Pipelines. Configure the pipeline to use Vertex AI Training jobs with distributed processing.

**B.** Run the TFX pipeline in Vertex AI Pipelines. Set the appropriate Apache Beam parameters in the pipeline to run the data preprocessing steps in Dataflow.

**C.** Run the TFX pipeline in Dataproc by using the Apache Beam TFX orchestrator. Set the appropriate Vertex AI permissions in the job to publish metadata in Vertex AI.

**D.** Run the TFX pipeline in Dataflow by using the Apache Beam TFX orchestrator. Set the appropriate Vertex AI permissions in the job to publish metadata in Vertex AI.

**Respuesta de la fuente:** B

**Explicación:** Vertex AI Pipelines is the recommended orchestrator for TFX pipelines on Google Cloud to ensure native integration with Vertex ML Metadata and Vertex AI Experiments.
By configuring Apache Beam parameters within the pipeline, you offload the computationally intensive data preprocessing steps to Dataflow, which provides the necessary distributed processing power to scale efficiently for 100 TB of data.

## Pregunta 293

Contexto: [topics:106](#topics-106)
You are developing a batch process that will train a custom model and perform predictions. You need to be able to show lineage for both your model and the batch predictions. What should you do?

**A.** 1. Upload your dataset to BigQuery.
2. Use a Vertex AI custom training job to train your model.
3. Generate predictions by using Vertex AI SDK custom prediction routines.

**B.** 1. Use Vertex AI Experiments to evaluate model performance during training.
2. Register your model in Vertex AI Model Registry.
3. Generate batch predictions in Vertex AI.

**C.** 1. Create a Vertex AI managed dataset.
2. Use a Vertex AI training pipeline to train your model.
3. Generate batch predictions in Vertex AI.

**D.** 1. Use a Vertex AI Pipelines custom training job component to train your model.
2. Generate predictions by using a Vertex AI Pipelines model batch predict component.

**Respuesta de la fuente:** D

**Explicación:** Vertex AI Pipelines (based on Kubeflow) automatically track the lineage of data and models by logging metadata for every component in the workflow.
Using specific components like custom training and batch predict ensures that the inputs, outputs, and execution details are recorded within the pipeline run.
This built-in tracking provides the complete traceability required for both model creation and prediction tasks without manual implementation.

## Pregunta 294

Contexto: [topics:106](#topics-106)
You work for a company that sells corporate electronic products to thousands of businesses worldwide. Your company stores historical customer data in BigQuery. You need to build a model that predicts customer lifetime value over the next three years. You want to use the simplest approach to build the model. What should you do?

**A.** Create a Vertex AI Workbench notebook. Use IPython magic to run the CREATE MODEL statement to create an ARIMA model.

**B.** Access BigQuery Studio in the Google Cloud console. Run the CREATE MODEL statement in the SQL editor to create an AutoML regression model.

**C.** Create a Vertex AI Workbench notebook. Use IPython magic to run the CREATE MODEL statement to create an AutoML regression model.

**D.** Access BigQuery Studio in the Google Cloud console. Run the CREATE MODEL statement in the SQL editor to create an ARIMA model.

**Respuesta de la fuente:** B

**Explicación:** The requirement for the 'simplest approach' points to using BigQuery ML directly within the SQL editor in BigQuery Studio, avoiding the overhead of setting up a Vertex AI Workbench notebook environment.
For predicting Customer Lifetime Value (a continuous numerical target), an AutoML regression model is the appropriate choice, as ARIMA is designed for time-series forecasting rather than general feature-based regression.

## Pregunta 295

Contexto: [topics:106](#topics-106)
You work at a retail company, and are tasked with developing an ML model to predict product sales. Your company’s historical sales data is stored in BigQuery and includes features such as date, store location, product category, and promotion details. You need to choose the most effective combination of a BigQuery ML model and feature engineering to maximize prediction accuracy. What should you do?

**A.** Use a linear regression model. Perform one-hot encoding on categorical features, and create additional features based on the date, such as day of the week or month.

**B.** Use a boosted tree model. Perform label encoding on categorical features, and transform the date column into numeric values.

**C.** Use an autoencoder model. Perform label encoding on categorical features, and normalize the date column.

**D.** Use a matrix factorization model. Perform one-hot encoding on categorical features, and create interaction features between the store location and product category variables.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 296

Contexto: [topics:106](#topics-106)
Your organization’s employee onboarding team wants you to build an interactive self-help tool for new employees. The tool needs to receive queries from users and provide answers from the organization’s internal documentation. This documentation is spread across standalone documents such as PDF files. You want to build a solution quickly while minimizing maintenance overhead. What should you do?

**A.** Create a custom chatbot user interface hosted on App Engine. Use Vertex AI to fine-tune a Gemini model on the organization’s internal documentation. Send users’ queries to the fine-tuned model by using the custom chatbot and return the model’s responses to the users.

**B.** Deploy an internal website to a Google Kubernetes Engine (GKE) cluster. Build a search index by ingesting all of the organization’s internal documentation. Use Vertex AI Vector Search to implement a semantic search that retrieves results from the search index based on the query entered into the search box.

**C.** Use Vertex AI Agent Builder to create an agent. Securely index the organization’s internal documentation to the agent’s datastore. Send users’ queries to the agent and return the agent’s grounded responses to the users.

**D.** Deploy an internal website to a Google Kubernetes Engine (GKE) cluster. Organize the relevant internal documentation into sections. Collect user feedback on website content and store it in BigQuery. Request that the onboarding team regularly update the links based on user feedback.

**Respuesta de la fuente:** C

**Explicación:** Vertex AI Agent Builder is specifically designed for low-code creation of generative AI agents grounded in private data like PDFs, directly addressing the need for quick development and minimal maintenance. It handles ingestion, indexing, and retrieval (RAG) automatically, whereas fine-tuning (Option A) is complex and GKE deployments (Options B/D) require significant infrastructure management.

## Pregunta 297

Contexto: [topics:106](#topics-106)
You work for an ecommerce company that wants to automatically classify products in images to improve user experience. You have a substantial dataset of labeled images depicting various unique products. You need to implement a solution for identifying custom products that is scalable, effective, and can be rapidly deployed. What should you do?

**A.** Develop a rule-based system to categorize the images.

**B.** Use a TensorFlow deep learning model that is trained on the image dataset.

**C.** Use a pre-trained object detection model from Model Garden.

**D.** Use AutoML Vision to train a model using the image dataset.

**Respuesta de la fuente:** D

**Explicación:** AutoML Vision is the optimal choice because it automates the model development lifecycle, allowing for rapid deployment without requiring deep learning expertise.
It leverages Google's infrastructure to ensure scalability and effectiveness by automatically optimizing model architecture and hyperparameters on your provided labeled dataset.
Unlike rule-based systems, it handles complex visual patterns better, and unlike manual TensorFlow implementation, it significantly reduces development time and operational overhead.

## Pregunta 298

Contexto: [topics:106](#topics-106)
Your team is developing a customer support chatbot for a healthcare company that processes sensitive patient information. You need to ensure that all personally identifiable information (PII) captured during customer conversations is protected prior to storing or analyzing the data. What should you do?

**A.** Use the Cloud Natural Language API to identify and redact PII in chatbot conversations.

**B.** Use the Cloud Natural Language API to classify and categorize all data, including PII, in chatbot conversations.

**C.** Use the DLP API to encrypt PII in chatbot conversations before storing the data.

**D.** Use the DLP API to scan and de-identify PII in chatbot conversations before storing the data.

**Respuesta de la fuente:** D

**Explicación:** The Cloud Data Loss Prevention (DLP) API is the specialized service designed to discover and de-identify sensitive data like PII, whereas the Natural Language API focuses on sentiment analysis and entity recognition without specific privacy controls. De-identification techniques such as redaction or pseudonymization effectively remove identifiable information while preserving the utility of the data for analytics, which aligns with the requirement to protect PII prior to storage.

## Pregunta 299

Contexto: [topics:106](#topics-106)
Your team is experimenting with developing smaller, distilled LLMs for a specific domain. You have performed batch inference on a dataset by using several variations of your distilled LLMs and stored the batch inference outputs in Cloud Storage. You need to create an evaluation workflow that integrates with your existing Vertex AI pipeline to assess the performance of the LLM versions while also tracking artifacts. What should you do?

**A.** Develop a custom Python component that reads the batch inference outputs from Cloud Storage, calculates evaluation metrics, and writes the results to a BigQuery table.

**B.** Use a Dataflow component that processes the batch inference outputs from Cloud Storage, calculates evaluation metrics in a distributed manner, and writes the results to a BigQuery table.

**C.** Create a custom Vertex AI Pipelines component that reads the batch inference outputs from Cloud Storage, calculates evaluation metrics, and writes the results to a BigQuery table.

**D.** Use the Automatic side-by-side (AutoSxS) pipeline component that processes the batch inference outputs from Cloud Storage, aggregates evaluation metrics, and writes the results to a BigQuery table.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 300

Contexto: [topics:106](#topics-106)
You work for a bank. You need to train a model by using unstructured data stored in Cloud Storage that predicts whether credit card transactions are fraudulent. The data needs to be converted to a structured format to facilitate analysis in BigQuery. Company policy requires that data containing personally identifiable information (PII) remain in Cloud Storage. You need to implement a scalable solution that preserves the data’s value for analysis. What should you do?

**A.** Use BigQuery’s authorized views and column-level access controls to restrict access to PII within the dataset.

**B.** Use the DLP API to de-identify the sensitive data before loading it into BigQuery.

**C.** Store the unstructured data in a separate PII-compliant BigQuery database.

**D.** Remove the sensitive data from the files manually before loading them into BigQuery.

**Respuesta de la fuente:** B

**Explicación:** The Data Loss Prevention (DLP) API is specifically designed to identify and de-identify sensitive information like PII in a scalable, automated manner.
By using the DLP API to mask or replace PII before loading data into BigQuery, you satisfy the policy requirement that raw PII remains only in Cloud Storage while still enabling analysis on structured, safe data.

## Pregunta 301

Contexto: [topics:106](#topics-106)
You are an ML engineer at a bank. You need to build a solution that provides transparent and understandable explanations for AI-driven decisions for loan approvals, credit limits, and interest rates. You want to build this system to require minimal operational overhead. What should you do?

**A.** Deploy the Learning Interpretability Tool (LIT) on App Engine to provide explainability and visualization of the output.

**B.** Use Vertex Explainable AI to generate feature attributions, and use feature-based explanations for your models.

**C.** Use AutoML Tables with built-in explainability features, and use Shapley values for explainability.

**D.** Deploy pre-trained models from TensorFlow Hub to provide explainability using visualization tools.

**Respuesta de la fuente:** B

**Explicación:** Vertex AI Explanations is the dedicated managed service for model interpretability that minimizes operational overhead by handling infrastructure scaling and maintenance.
It provides standardized feature attributions required for regulatory transparency in banking without the need to build or maintain custom explanation tools.

## Pregunta 302

Contexto: [topics:106](#topics-106)
You are building an application that extracts information from invoices and receipts. You want to implement this application with minimal custom code and training. What should you do?

**A.** Use the Cloud Vision API with TEXT_DETECTION type to extract text from the invoices and receipts, and use a pre-built natural language processing (NLP) model to parse the extracted text.

**B.** Use the Cloud Document AI API to extract information from the invoices and receipts.

**C.** Use Vertex AI Agent Builder with the pre-built Layout Parser model to extract information from the invoices and receipts.

**D.** Train an AutoML Natural Language model to classify and extract information from the invoices and receipts.

**Respuesta de la fuente:** B

**Explicación:** Cloud Document AI is purpose-built for processing structured documents like invoices and receipts, offering pre-trained models that extract specific fields (e.g., dates, totals, vendors) without custom training. Cloud Vision is designed for general object/text detection rather than structured data extraction, while AutoML requires significant training effort. Vertex AI Agent Builder is not the standard service for this document processing task.

## Pregunta 303

Contexto: [topics:106](#topics-106)
You work for a media company that operates a streaming movie platform where users can search for movies in a database. The existing search algorithm uses keyword matching to return results. Recently, you have observed an increase in searches using complex semantic queries that include the movies’ metadata such as the actor, genre, and director.

You need to build a revamped search solution that will provide better results, and you need to build this proof of concept as quickly as possible. How should you build the search platform?

**A.** Use a foundational large language model (LLM) from Model Garden as the search platform’s backend.

**B.** Configure Vertex AI Vector Search as the search platform’s backend.

**C.** Use a BERT-based model and host it on a Vertex AI endpoint.

**D.** Create the search platform through Vertex AI Agent Builder.

**Respuesta de la fuente:** D

**Explicación:** The requirement to build a proof of concept as quickly as possible while handling semantic queries points to Vertex AI Agent Builder (formerly Enterprise Search). Unlike Vector Search, which requires manual embedding generation and index management, Agent Builder provides a managed service that natively supports hybrid search (combining keyword and semantic understanding) with minimal setup time. This makes it the most efficient choice for rapidly deploying a revamped search solution without the overhead of custom model training or infrastructure configuration.

## Pregunta 304

Contexto: [topics:106](#topics-106)
You are an AI engineer that works for a popular video streaming platform. You built a classification model using PyTorch to predict customer churn. Each week, the customer retention team plans to contact customers that have been identified as at risk of churning with personalized offers. You want to deploy the model while minimizing maintenance effort. What should you do?

**A.** Use Vertex AI’s prebuilt containers for prediction. Deploy the container on Cloud Run to generate online predictions.

**B.** Use Vertex AI’s prebuilt containers for prediction. Deploy the model on Google Kubernetes Engine (GKE), and configure the model for batch prediction.

**C.** Deploy the model to a Vertex AI endpoint, and configure the model for batch prediction. Schedule the batch prediction to run weekly.

**D.** Deploy the model to a Vertex AI endpoint, and configure the model for online prediction. Schedule a job to query this endpoint weekly.

**Respuesta de la fuente:** C

**Explicación:** Batch prediction is the appropriate choice because the predictions are needed weekly in bulk for a retention campaign, rather than in real-time. By using Vertex AI Batch Prediction, you avoid the overhead of maintaining infrastructure for online endpoints (like GKE or Cloud Run) and the cost of keeping an endpoint active constantly. Scheduling the job automates the process entirely, thereby minimizing ongoing maintenance effort.

## Pregunta 305

Contexto: [topics:106](#topics-106)
Your company recently migrated several of is ML models to Google Cloud. You have started developing models in Vertex AI. You need to implement a system that tracks model artifacts and model lineage. You want to create a simple, effective solution that can also be reused for future models. What should you do?

**A.** Use a combination of Vertex AI Pipelines and the Vertex AI SDK to integrate metadata tracking into the ML workflow.

**B.** Use Vertex AI Pipelines for model artifacts and MLflow for model lineage.

**C.** Use Vertex AI Experiments for model artifacts and use Vertex ML Metadata for model lineage.

**D.** Implement a scheduled metadata tracking solution using Cloud Composer and Cloud Run functions.

**Respuesta de la fuente:** A

**Explicación:** Vertex AI Metadata is the native service specifically designed to track machine learning artifacts and lineage automatically when used with Vertex AI Pipelines.
Integrating tracking via the Vertex AI SDK within these pipelines provides a simple, reusable solution without introducing third-party tools like MLflow or complex custom infrastructure.

## Pregunta 306

Contexto: [topics:106](#topics-106)
You work for a large retailer, and you need to build a model to predict customer chum. The company has a dataset of historical customer data, including customer demographics purchase history, and website activity. You need to create the model in BigQuery ML and thoroughly evaluate its performance. What should you do?

**A.** Create a linear regression model in BigQuery ML, and register the model in Vertex AI Model Registry. Use Vertex AI to evaluate the model performance.

**B.** Create a logistic regression model in BigQuery ML, and register the model in Vertex AI Model Registry. Use ML.ARIMA_EVALUATE function to evaluate the model performance.

**C.** Create a linear regression model in BigQuery ML. Use the ML.EVALUATE function to evaluate the model performance.

**D.** Create a logistic regression model in BigQuery ML. Use the ML.CONFUSION_MATRIX function to evaluate the model performance.

**Respuesta de la fuente:** D

**Explicación:** Customer churn prediction is a binary classification problem, making logistic regression the appropriate model type in BigQuery ML. The ML.CONFUSION_MATRIX function provides specific metrics (like precision and recall) essential for evaluating classification models, whereas linear regression and ARIMA are unsuitable for this task.

## Pregunta 307

Contexto: [topics:106](#topics-106)
You are an AI architect at a popular photo sharing social media platform. Your organization's content moderation team currently scans images uploaded by users and removes explicit images manually. You want to implement an AI service to automatically prevent users from uploading explicit images. What should you do?

**A.** Train an image clustering model by using TensorFlow in a Vertex AI Workbench instance. Deploy this model to a Vertex AI endpoint and configure it for online inference. Run this model each time a new image is uploaded to identify and block inappropriate uploads.

**B.** Develop a custom TensorFlow model in a Vertex AI Workbench instance. Train the model on a dataset of manually labeled images. Deploy the model to a Vertex AI endpoint. Run periodic batch inference to identify inappropriate uploads and report them to the content moderation team.

**C.** Create a dataset using manually labeled images. Ingest this dataset into AutoML. Train an image classification model and deploy into a Vertex AI endpoint. Integrate this endpoint with the image upload process to identify and block inappropriate uploads. Monitor predictions and periodically retrain the model.

**D.** Send a copy of every user-uploaded image to a Cloud Storage bucket. Configure a Cloud Run function that triggers the Cloud Vision API to detect explicit content each time a new image is uploaded. Report the classifications to the content moderation team for review.

**Respuesta de la fuente:** C

**Explicación:** The requirement is to automatically prevent uploads in real-time, which necessitates online inference rather than batch processing or post-upload review. While the Cloud Vision API (Option D) is a valid pre-trained service, Option C correctly describes the full lifecycle of implementing a custom ML solution: creating labeled data, using AutoML for classification, deploying for immediate prediction during upload, and maintaining model accuracy through monitoring and retraining.

## Pregunta 308

Contexto: [topics:106](#topics-106)
You are an ML engineer at a bank. The bank's leadership team wants to reduce the number of loan defaults. The bank has labeled historic data about loan defaults stored in BigQuery. You have been asked to use AI to support the loan application process. For compliance reasons, you need to provide explanations for loan rejections. What should you do?

**A.** Import the historic loan default data into AutoML. Train and deploy a linear regression model to predict default probability. Report the probability of default for each loan application.

**B.** Create a custom application that uses the Gemini large language model (LLM). Provide the historic data as context to the model, and prompt the model to predict customer defaults. Report the prediction and explanation provided by the LLM for each loan application.

**C.** Train and deploy a BigQuery ML classification model trained on historic loan default data. Enable feature-based explanations for each prediction. Report the prediction, probability of default, and feature attributions for each loan application.

**D.** Load the historic loan default data into a Vertex AI Workbench instance. Train a deep learning classification model using TensorFlow to predict loan default. Run inference for each loan application, and report the predictions.

**Respuesta de la fuente:** C

**Explicación:** The question explicitly requires providing explanations for loan rejections to meet compliance standards. BigQuery ML (Option C) supports training classification models directly on existing data and features a built-in EXPLAIN() function that provides feature-based attributions (SHAP values), ensuring each prediction is accompanied by the specific factors influencing the outcome. Other options either use incorrect model types like regression for binary defaults or lack native, integrated explanation capabilities suitable for regulated financial auditing.

## Pregunta 309

Contexto: [topics:106](#topics-106)
You are developing a natural language processing model that analyzes customer feedback to identify positive, negative, and neutral experiences. During the testing phase, you notice that the model demonstrates a significant bias against certain demographic groups, leading to skewed analysis results. You want to address this issue following Google's responsible AI practices. What should you do?

**A.** Use Vertex AI's model evaluation lo assess bias in the model's predictions, and use post-processing to adjust outputs for identified demographic discrepancies.

**B.** Implement a more complex model architecture that can capture nuanced patterns in language to reduce bias.

**C.** Audit the training dataset to identify underrepresented groups and augment the dataset with additional samples before retraining the model.

**D.** Use Vertex Explainable AI to generate explanations and systematically adjust the predictions to address identified biases.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google's Responsible AI practices emphasize addressing bias at its source: the training data. By auditing and augmenting the dataset to ensure balanced representation of demographic groups, you mitigate the root cause of skewed predictions rather than applying superficial post-processing fixes.

## Pregunta 310

Contexto: [topics:106](#topics-106)
You recently deployed an image classification model on Google Cloud. You used Cloud Build to build a CI/CD pipeline for the model. You need to ensure that the model stays up-to-date with data and code changes by using an efficient retraining process. What should you do?

**A.** Use Cloud Run functions to monitor data drift in real time and trigger a Vertex AI Training job to retrain the model when data drift exceeds a predetermined threshold.

**B.** Configure a Git repository trigger in Cloud Build to initiate retraining when there are new code commits to the model's repository and a Pub/Sub trigger when there is new data in Cloud Storage.

**C.** Use Cloud Scheduler to initiate a daily retraining job in Vertex AI Pipelines.

**D.** Configure Cloud Composer to orchestrate a weekly retraining job that includes data extraction from BigQuery, model retraining with Vertex AI Training, and model deployment to a Vertex AI endpoint.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it directly addresses the requirement for an efficient retraining process by triggering only when necessary—specifically on code commits via Cloud Build and new data ingestion via Pub/Sub. This event-driven approach avoids the wasteful periodic retraining of options C and D, and unlike option A, it correctly handles code changes alongside data drift.

## Pregunta 311

Contexto: [topics:106](#topics-106)
You lead a data science team that is working on a computationally intensive project involving running several experiments. Your team is geographically distributed and requires a platform that provides the most effective real-time collaboration and rapid experimentation. You plan to add GPUs to speed up your experimentation cycle, and you want to avoid having to manually set up the infrastructure. You want to use the Google-recommended approach. What should you do?

**A.** Configure a managed Dataproc cluster for large-scale data processing. Configure individual Jupyter notebooks on VMs that each team member uses for experimentation and model development.

**B.** Use Colab Enterprise with Cloud Storage for data management. Use a Git repository for version control.

**C.** Use Vertex AI Workbench and Cloud Storage for data management. Use a Git repository for version control.

**D.** Configure a distributed JupyterLab instance that each team member can access on a Compute Engine VM. Use a shared code repository for version control.

**Respuesta de la fuente:** C

**Explicación:** Vertex AI Workbench is the recommended solution for production-grade, computationally intensive data science projects requiring managed infrastructure and Git integration. It provides pre-configured notebook environments with native GPU support, eliminating manual infrastructure setup while offering greater control and scalability than Colab Enterprise.

## Pregunta 312

Contexto: [topics:106](#topics-106)
You need to train a ControlNet model with Stable Diffusion XL for an image editing use case. You want to train this model as quickly as possible. Which hardware configuration should you choose to train your model?

**A.** Configure one a2-highgpu-1g instance with an NVIDIA A100 GPU with 80 GB of RAM. Use float32 precision during model training.

**B.** Configure one a2-highgpu-1g instance with an NVIDIA A100 GPU with 80 GB of RAM. Use bfloat16 quantization during model training.

**C.** Configure four n1-standard-16 instances, each with one NVIDIA Tesla T4 GPU with 16 GB of RAM. Use float32 precision during model training.

**D.** Configure four n1-standard-16 instances, each with one NVIDIA Tesla T4 GPU with 16 GB of RAM. Use floar16 quantization during model training.

**Respuesta de la fuente:** B

**Explicación:** The NVIDIA A100 GPU with 80 GB VRAM is required to handle the memory demands of training Stable Diffusion XL and ControlNet, ruling out the Tesla T4 options (C and D) due to their insufficient 16 GB memory. Between the remaining A100 options, using bfloat16 precision (B) is faster than float32 (A) because it reduces memory bandwidth requirements and computational load while maintaining training accuracy.

## Pregunta 313

Contexto: [topics:106](#topics-106)
You are the lead ML engineer on a mission-critical project that involves analyzing massive datasets using Apache Spark. You need to establish a robust environment that allows your team to rapidly prototype Spark models using Jupyter notebooks. What is the fastest way to achieve this?

**A.** Set up a Vertex AI Workbench instance with a Spark kernel.

**B.** Use Colab Enterprise with a Spark kernel.

**C.** Set up a Dataproc cluster with Spark and use Jupyter notebooks.

**D.** Configure a Compute Engine instance with Spark and use Jupyter notebooks.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 314

Contexto: [topics:106](#topics-106)
You are training a large-scale deep learning model on a Cloud TPU. While monitoring the training progress through Tensorboard, you observe that the TPU utilization is consistently low and there are delays between the completion of one training step and the start of the next step. You want to improve TPU utilization and overall training performance. How should you address this issue?

**A.** Apply tf.data.Detaset.map with vectorized operations and parallelization.

**B.** Use tf.data.Detaset.interleave with multiple data sources.

**C.** Use tf.data.Detaset.cache on the dataset after the first epoch.

**D.** Implement tf.data.Detaset.prefetch in the data pipeline.

**Respuesta de la fuente:** D

**Explicación:** The low TPU utilization and idle time between steps indicate that the accelerator is waiting for data preprocessing to complete.
tf.data.Dataset.prefetch() overlaps data preparation with model execution by preparing the next batch in the background while the current batch is being processed.
This concurrency eliminates the delay, ensuring the TPU remains fully utilized without stalling for input.

## Pregunta 315

Contexto: [topics:106](#topics-106)
You are building an ML pipeline to process and analyze both steaming and batch datasets. You need the pipeline to handle data validation, preprocessing, model training, and model deployment in a consistent and automated way. You want to design an efficient and scalable solution that captures model training metadata and is easily reproducible. You want to be able to reuse custom components for different parts of your pipeline. What should you do?

**A.** Use Cloud Composer for distributed processing of batch and streaming data in the pipeline.

**B.** Use Dataflow for distributed processing of batch and streaming data in the pipeline.

**C.** Use Cloud Build to build and push Docker images for each pipeline component.

**D.** Implement an orchestration framework such as Kubeflow Pipelines or Vertex AI Pipelines.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Kubeflow and Vertex AI Pipelines are specifically designed for ML workflows that require component reusability, reproducibility, and metadata tracking. In contrast, Cloud Composer (A) and Dataflow (B) focus on general orchestration or data processing rather than end-to-end ML lifecycle management, while Cloud Build (C) handles image creation but lacks pipeline orchestration capabilities.

## Pregunta 316

Contexto: [topics:106](#topics-106)
You are developing an ML model on Vertex AI that needs to meet specific interpretability requirements for regulatory compliance. You want to use a combination of model architectures and modeling techniques to maximize accuracy and interpretability. How should you create the model?

**A.** Use a convolutional neural network (CNN)-based deep learning model architecture, and use local interpretable model-agnostic explanations (LIME) for interpretability.

**B.** Use a recurrent neural network (RNN)-based deep learning model architecture, and use integrated gradients for interpretability.

**C.** Use a boosted decision tree-based model architecture, and use SHAP values for interpretability.

**D.** Use a long short-term memory (LSTM)-based model architecture, and use local interpretable model-agnostic explanations (LIME) for interpretability.

**Respuesta de la fuente:** C

**Explicación:** Boosted decision trees are inherently more interpretable than deep learning architectures like CNNs, RNNs, or LSTMs, which are considered 'black box' models.
SHAP (SHapley Additive exPlanations) provides a rigorous mathematical framework for explaining model predictions that is widely accepted in regulatory compliance contexts.

## Pregunta 317

Contexto: [topics:106](#topics-106)
You have developed a fraud detection model for a large financial institution using Vertex AI. The model achieves high accuracy, but the stakeholders are concerned about the model's potential for bias based on customer demographics. You have been asked to provide insights into the model's decision-making process and identify any fairness issues. What should you do?

**A.** Create feature groups using Vertex AI Feature Store to segregate customer demographic features and non-demographic features. Retrain the model using only non-demographic features.

**B.** Use feature attribution in Vertex AI to analyze model predictions and the impact of each feature on the model's predictions.

**C.** Enable Vertex AI Model Monitoring to detect training-serving skew. Configure an alert to send an email when the skew or drift for a modes feature exceeds a predefined threshold. Re-train the model by appending new data to existing raining data.

**D.** Compile a dataset of unfair predictions. Use Vertex AI Vector Search to identify similar data points in the model's predictions. Report these data points to the stakeholders.

**Respuesta de la fuente:** B

**Explicación:** Feature attribution techniques, such as SHAP values available in Vertex AI, quantify the contribution of each input feature to individual predictions. This allows you to identify if demographic features are disproportionately influencing decisions, directly addressing concerns about model bias and fairness. Retaining or removing features (Option A) is a mitigation strategy that should only be applied after analysis confirms bias, not as an initial diagnostic step.

## Pregunta 318

Contexto: [topics:106](#topics-106)
You developed an ML model using Vertex AI and deployed it to a Vertex AI endpoint. You anticipate that the model will need to be retrained as new data becomes available. You have configured a Vertex AI Model Monitoring Job. You need to monitor the model for feature attribution drift and establish continuous evaluation metrics. What should you do?

**A.** Set up alerts using Cloud Logging, and use the Vertex AI console to review feature attributions.

**B.** Set up alerts using Cloud Logging, and use Looker Studio to create a dashboard that visualizes feature attribution drift. Review the dashboard periodically.

**C.** Enable request-response logging for the Vertex AI endpoint, and set up alerts using Pub/Sub. Create a Cloud Run function to run TensorFlow Data Validation on your dataset.

**D.** Enable request-response logging for the Vertex AI endpoint, and set up alerts using Cloud Logging. Review the feature attributions in the Google Cloud console when an alert is received.

**Respuesta de la fuente:** D

**Explicación:** Vertex AI Model Monitoring relies on request-response logging to analyze input/output data for drift and skew. Therefore, you must enable request-response logging (as stated in D) rather than relying solely on the monitoring job configuration mentioned in A or B. While option C suggests external tools like TFDV, Vertex AI Model Monitoring provides built-in capabilities to monitor feature attribution drift directly within the console without needing custom Cloud Run functions.

## Pregunta 319

Contexto: [topics:106](#topics-106)
You work as an ML researcher at an investment bank, and you are experimenting with the Gemma large language model (LLM). You plan to deploy the model for an internal use case. You need to have full control of the mode's underlying infrastructure and minimize the model's inference time. Which serving configuration should you use for this task?

**A.** Deploy the model on a Vertex AI endpoint manually by creating a custom inference container.

**B.** Deploy the model on a Google Kubernetes Engine (GKE) cluster by using the deployment options in Model Garden.

**C.** Deploy the model on a Vertex AI endpoint by using one-click deployment in Model Garden.

**D.** Deploy the model on a Google Kubernetes Engine (GKE) cluster manually by cresting a custom yaml manifest.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 320

Contexto: [topics:106](#topics-106)
You are an ML researcher and are evaluating multiple deep learning-based model architectures and hyperparameter configurations. You need to implement a robust solution to track the progress of each model iteration, visualize key metrics, gain insights into model internals, and optimize training performance.

You want your solution to have the most efficient and powerful approach to compare the models and have the strongest visualization abilities. How should you bull this solution?

**A.** Use Vertex AI TensorBoard for in-depth visualization and analysis, and use BigQuery for experiment tracking and analysis.

**B.** Use Vertex AI TensorBoard for visualizing training progress and model behavior, and use Vertex AI Feature Store to stove and manage experiment data for analysis and reproducibility.

**C.** Use Vertex AI Experiments for tracking iterations and comparison, and use Vertex AI TensorBoard for visualization and analysis of the training metrics and model architecture.

**D.** Use Vertex AI Experiments for tracking iterations and comparison, and use BigQuery and Looker Studio for visualization and analysis of the training metrics and model architecture.

**Respuesta de la fuente:** C

**Explicación:** Vertex AI Experiments is specifically designed to log and compare model iterations, hyperparameters, and metrics, fulfilling the tracking requirement.
Vertex AI TensorBoard provides robust visualization capabilities for training progress, model internals, and embeddings.
Using these two integrated GCP services together offers the most efficient workflow without the overhead of third-party or generic analytics tools like BigQuery.

## Pregunta 321

Contexto: [topics:106](#topics-106)
You are developing a model to detect fraudulent credit card transactions. You need to prioritize detection, because missing even one fraudulent transaction could severely impact the credit card holder. You used AutoML to train a model on users' profile information and credit card transaction data. After training the initial model, you notice that the model is failing to detect many fraudulent transactions. How should you increase the number of fraudulent transactions that are detected?

**A.** Add more non-fraudulent examples to the training set.

**B.** Reduce the maximum number of node hours for training.

**C.** Increase the probability threshold to classify a fraudulent transaction.

**D.** Decrease the probability threshold to classify a fraudulent transaction.

**Respuesta de la fuente:** D

**Explicación:** To increase the number of detected fraudulent transactions (improve recall), you must lower the classification threshold so that predictions with lower confidence are flagged as fraud.
Raising the threshold would make the model more conservative, reducing detection rates, which contradicts the goal of minimizing missed cases.

## Pregunta 322

Contexto: [topics:106](#topics-106)
You work at an organization that maintains a cloud-based communication platform that integrates conventional chat, voice, and video conferencing into one platform. The audio recordings are stored in Cloud Storage. All recordings have a 16 kHz sample rate and are more than one minute long. You need to implement a new feature in the platform that will automatically transcribe voice call recordings into text for future applications, such as call summarization and sentiment analysis. How should you implement the voice call transcription feature while following Google-recommended practices?

**A.** Use the original audio sampling rate, and transcribe the audio by using the Speech-to-Text API with synchronous recognition.

**B.** Use the original audio sampling rate, and transcribe the audio by using the Speech-to-Text API with asynchronous recognition.

**C.** Downsample the audio recordings to 8 kHz, and transcribe the audio by using the Speech-to-Text API with synchronous recognition.

**D.** Downsample the audio recordings to 8 kHz, and transcribe the audio by using the Speech-to-Text API with asynchronous recognition.

**Respuesta de la fuente:** B

**Explicación:** You should retain the original 16 kHz sample rate because it provides higher fidelity audio suitable for accurate transcription compared to downsampled 8 kHz audio.
Asynchronous recognition is the recommended practice for processing large files or batches of recordings (such as those exceeding one minute) for later use, whereas synchronous recognition has a strict limit on input size and blocks execution until completion.

## Pregunta 323

Contexto: [topics:106](#topics-106)
You have created multiple versions of an ML model and have imported them to Vertex AI Model Registry. You want to perform A/B testing to identify the best performing model using the simplest approach. What should you do?

**A.** Split incoming traffic to distribute prediction requests among the versions. Monitor the performance of each version using Vertex AI's built-in monitoring tools.

**B.** Split incoming traffic among Google Kubernetes Engine (GKE) clusters, and use Traffic Director to distribute prediction requests to different versions. Monitor the performance of each version using Cloud Monitoring.

**C.** Split incoming traffic to distribute prediction requests among the versions. Monitor the performance of each version using Looker Studio dashboards that compare logged data for each version.

**D.** Split incoming traffic among separate Cloud Run instances of deployed models. Monitor the performance of each version using Cloud Monitoring.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it leverages Vertex AI's native model deployment features to split traffic among endpoint instances directly within the same service, minimizing infrastructure overhead. Using built-in monitoring tools within Vertex AI eliminates the need to set up external services like GKE, Cloud Run, or Looker Studio dashboards, satisfying the requirement for the 'simplest approach'.

## Pregunta 324

Contexto: [topics:106](#topics-106)
You need to train an XGBoost model on a small dataset. Your training code requires custom dependencies. You need to set up a Vertex AI custom training job. You want to minimize the startup time of the training job while following Google-recommended practices. What should you do?

**A.** Create a custom container that includes the data and the custom dependencies. In your training application, load the data into a pandas DataFrame and train the model.

**B.** Store the data in a Cloud Storage bucket, and use the XGBoost prebuilt custom container to run your training application. Create a Python source distribution that installs the custom dependencies at runtime. In your training application, read the data from Cloud Storage and train the model.

**C.** Use the XGBoost prebuilt custom container. Create a Python source distribution that includes the data and installs the custom dependencies at runtime. In your training application, load the data into a pandas DataFrame and train the model.

**D.** Store the data in a Cloud Storage bucket, and create a custom container with your training application and its custom dependencies. In your training application, read the data from Cloud Storage and train the model.

**Respuesta de la fuente:** D

**Explicación:** To minimize startup time, you must pre-build a custom container image with all custom dependencies installed, avoiding the latency of installing packages at runtime.

Storing data in Cloud Storage rather than baking it into the container follows Google-recommended practices by separating code from data and preventing unnecessarily large image sizes.

## Pregunta 325

Contexto: [topics:106](#topics-106)
You are building an ML model to predict customer churn for a subscription service. You have trained your model on Vertex AI using historical data, and deployed it to a Vertex AI endpoint for real-time predictions. After a few weeks, you notice that the model's performance, measured by AUC (area under the ROC curve), has dropped significantly in production compared to its performance during training. How should you troubleshoot this problem?

**A.** Monitor the training/serving skew of feature values for requests sent to the endpoint.

**B.** Monitor the resource utilization of the endpoint, such as CPU and memory usage, to identify potential bottlenecks in performance.

**C.** Enable Vertex Explainable AI feature attribution to analyze model predictions and understand the impact of each feature on the model's predictions.

**D.** Monitor the latency of the endpoint to determine whether predictions are being served within the expected time frame.

**Respuesta de la fuente:** A

**Explicación:** The scenario describes model performance degradation in production compared to training, which indicates data drift or training-serving skew.
Monitoring the statistical distribution of feature values between training and serving data helps identify if the input data in production has diverged from the training set.
Vertex AI Model Monitoring is specifically designed to detect these skews and drifts, making it the appropriate troubleshooting step.

## Pregunta 326

Contexto: [topics:106](#topics-106)
You work at an organization that manages a popular payment app. You built a fraudulent transaction detection model by using scikit-learn and deployed it to a Vertex AI endpoint. The endpoint is currently using 1 e2-standard-2 machine with 2 vCPUs and 8 GB of memory. You discover that traffic on the gateway fluctuates to four times more than the endpoint's capacity. You need to address this issue by using the most cost-effective approach. What should you do?

**A.** Re-deploy the model with a TPU accelerator.

**B.** Change the machine type to e2-highcpu-32 with 32 vCPUs and 32 GB of memory.

**C.** Set up a monitoring job and an alert for CPU usage. If you receive an alert, scale the vCPUs as needed.

**D.** Increase the number of maximum replicas to 6 nodes, each with 1 e2-standard-2 machine.

**Respuesta de la fuente:** D

**Explicación:** Vertex AI supports horizontal autoscaling by adjusting the number of replicas, which is the most cost-effective method for handling fluctuating traffic compared to vertical scaling or adding expensive accelerators.
Since scikit-learn does not utilize TPUs (ruling out A) and the current machine type is adequate per-request but lacks concurrency (ruling out B), increasing replica count directly addresses the capacity gap.
Option C is reactive and inefficient, whereas Option D proactively scales out to handle the 4x traffic surge with minimal overhead.

## Pregunta 327

Contexto: [topics:106](#topics-106)
You are developing an AI text generator that will be able to dynamically adapt its generated responses to mirror the writing style of the user and mimic famous authors if their style is detected. You have a large dataset of various authors' works, and you plan to host the model on a custom VM. You want to use the most effective model. What should you do?

**A.** Deploy Llama 3 from Model Garden, and use prompt engineering techniques.

**B.** Fine-tune a BERT-based model from TensorFlow Hub.

**C.** Fine-tune Llama 3 from Model Garden on Vertex AI Pipelines.

**D.** Use the Gemini 1.5 Flash foundational model to build the text generator.

**Respuesta de la fuente:** C

**Explicación:** The requirement to mimic specific authors based on a large custom dataset necessitates fine-tuning rather than simple prompting or zero-shot inference.
Llama 3 is an open-weight model available in Model Garden that supports fine-tuning on Vertex AI Pipelines, allowing you to adapt its behavior using your proprietary data.
In contrast, Gemini models are primarily accessed via API and do not offer the same level of customizable fine-tuning for this specific use case on custom VMs.

## Pregunta 328

Contexto: [topics:106](#topics-106)
You are a lead ML architect at a small company that is migrating from on-premises to Google Cloud. Your company has limited resources and expertise in cloud infrastructure. You want to serve your models from Google Cloud as soon as possible. You want to use a scalable, reliable, and cost-effective solution that requires no additional resources. What should you do?

**A.** Configure Compute Engine VMs to host your models.

**B.** Create a Cloud Run function to deploy your models as serverless functions.

**C.** Create a managed cluster on Google Kubernetes Engine (GKE), and deploy your models as containers.

**D.** Deploy your models on Vertex AI endpoints.

**Respuesta de la fuente:** D

**Explicación:** Vertex AI endpoints are a fully managed ML serving solution that abstracts away infrastructure management, aligning with the constraint of limited cloud expertise.
Unlike Compute Engine or GKE, it eliminates the need to manage VMs or cluster orchestration, satisfying the 'no additional resources' and 'scalable, reliable' requirements efficiently.

## Pregunta 329

Contexto: [topics:106](#topics-106)
You deployed a conversational application that uses a large language model (LLM). The application has 1,000 users. You collect user feedback about the verbosity and accuracy of the model 's responses. The user feedback indicates that the responses are factually correct but users want different levels of verbosity depending on the type of question. You want the model to return responses that are more consistent with users' expectations, and you want to use a scalable solution. What should you do?

**A.** Implement a keyword-based routing layer. If the user's input contains the words "detailed" or "description," return a verbose response. If the user's input contains the word "fact." re-prompt the language model to summarize the response and return a concise response.

**B.** Ask users to provide examples of responses with the appropriate verbosity as a list of question and answer pairs. Use this dataset to perform supervised fine tuning of the foundational model. Re-evaluate the verbosity of responses with the tuned model.

**C.** Ask users to indicate all scenarios where they expect concise responses versus verbose responses. Modify the application 's prompt to include these scenarios and their respective verbosity levels. Re-evaluate the verbosity of responses with updated prompts.

**D.** Experiment with other proprietary and open-source LLMs. Perform A/B testing by setting each model as your application's default model. Choose a model based on the results.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 330

Contexto: [topics:106](#topics-106)
You are using Vertex AI to manage your ML models and datasets. You recently updated one of your models. You want to track and compare the new version with the previous one and incorporate dataset versioning. What should you do?

**A.** Use Vertex AI TensorBoard to visualize the training metrics of the new model version, and use Data Catalog to manage dataset versioning.

**B.** Use Vertex AI Model Monitoring to monitor the performance of the new model version, and use Vertex AI Training to manage dataset versioning.

**C.** Use Vertex AI Experiments to track and compare model artifacts and versions, and use Vertex ML Metadata to manage dataset versioning.

**D.** Use Vertex AI Experiments to track and compare model artifacts and versions, and use Vertex AI managed datasets to manage dataset versioning.

**Respuesta de la fuente:** D

**Explicación:** Vertex AI Experiments is the correct tool for tracking and comparing model artifacts and versions, as it provides a centralized dashboard for experiment runs.
For dataset versioning, Vertex AI Managed Datasets supports creating specific versions of data, which is the recommended higher-level approach for managing data lineage in training pipelines compared to the lower-level Vertex ML Metadata.

## Pregunta 331

Contexto: [topics:106](#topics-106)
You are creating a retraining policy for a customer churn prediction model deployed in Vertex AI. New training data is added weekly. You want to implement a model retraining process that minimizes cost and effort. What should you do?

**A.** Retrain the model when a significant shift in the distribution of customer attributes is detected in the production data compared to the training data.

**B.** Retrain the model when the model's latency increases by 10% due to increased traffic.

**C.** Retrain the model when the model accuracy drops by 10% on the new training dataset.

**D.** Retrain the model every week when new training data is available.

**Respuesta de la fuente:** A

**Explicación:** Retraining only when significant data drift is detected minimizes computational costs and effort by avoiding unnecessary training runs.
Unlike fixed schedules (D), this approach triggers updates solely when model performance degradation is likely due to concept or covariate shift.
Accuracy-based triggers (C) may fail to detect bias shifts in underrepresented classes that distribution analysis can catch.

## Pregunta 332

Contexto: [topics:106](#topics-106)
You are an AI engineer with an apparel retail company. The sales team has observed seasonal sales patterns over the past 5-6 years. The sales team analyzes and visualizes the weekly sales data stored in CSV files. You have been asked to estimate weekly sales for future seasons to optimize inventory and personnel workloads. You want to use the most efficient approach. What should you do?

**A.** Upload the files into Cloud Storage. Use Python to preprocess and load the tabular data into BigQuery. Use time series forecasting models to predict weekly sales.

**B.** Upload the files into Cloud Storage. Use Python to preprocess and load the tabular data into BigQuery. Train a logistic regression model by using BigQuery ML to predict each product's weekly sales as one of three categories: high, medium, or low.

**C.** Load the files into BigQuery. Preprocess data by using BigQuery SQL. Connect BigQuery to Looker. Create a Looker dashboard that shows weekly sales trends in real time and can slice and dice the data based on relevant filters.

**D.** Create a custom conversational application using Vertex AI Agent Builder. Include code that enables file upload functionality, and upload the files. Use few-shot prompting and retrieval-augmented generation (RAG) to predict future sales trends by using the Gemini large language model (LLM).

**Respuesta de la fuente:** A

**Explicación:** The goal is to predict future numerical values (weekly sales), which requires a regression-based time series forecasting model rather than classification or simple visualization.
Option A correctly identifies this need by using time series forecasting on historical data to estimate future trends, aligning with standard practices for inventory optimization.

## Pregunta 333

Contexto: [topics:106](#topics-106)
Your company's business stakeholders want to understand the factors driving customer churn to inform their business strategy. You need to build a customer churn prediction model that prioritizes simple interpretability of your model's results. You need to choose the ML framework and modeling technique that will explain which features led to the prediction. What should you do?

**A.** Build a TensorFlow deep neural network (DNN) model, and use SHAP values for feature importance analysis.

**B.** Build a PyTorch long short-term memory (LSTM) network, and use attention mechanisms for interpretability.

**C.** Build a logistic regression model in scikit-learn, and interpret the model's output coefficients to understand feature impact.

**D.** Build a linear regression model in scikit-learn, and interpret the model's standardized coefficients to understand feature impact.

**Respuesta de la fuente:** C

**Explicación:** Customer churn prediction is a binary classification problem, making logistic regression the appropriate choice over linear regression, which is designed for continuous targets.
Logistic regression offers inherent interpretability through its coefficients, directly showing the impact of each feature on the likelihood of churn without requiring complex post-hoc explanation methods like SHAP or attention mechanisms.

## Pregunta 334

Contexto: [topics:106](#topics-106)
You are responsible for managing and monitoring a Vertex AI model that is deployed in production. You want to automatically retrain the model when its performance deteriorates. What should you do?

**A.** Create a Vertex AI Model Monitoring job to track the model's performance with production data, and trigger retraining when specific metrics drop below predefined thresholds.

**B.** Collect feedback from end users, and retrain the model based on their assessment of its performance.

**C.** Configure a scheduled job to evaluate the model's performance on a static dataset, and retrain the model if the performance drops below predefined thresholds.

**D.** Use Vertex Explainable AI to analyze feature attributions and identify potential biases in the model. Retrain when significant shifts in feature importance or biases are detected.

**Respuesta de la fuente:** A

**Explicación:** Vertex AI Model Monitoring is the specific service designed to continuously evaluate deployed models against production traffic.
It detects performance drift and data skew by comparing live predictions with historical baselines or labeled data.
The service supports automated actions, such as triggering a retraining pipeline when metrics fall below defined thresholds.

## Pregunta 335

Contexto: [topics:106](#topics-106)
You have recently developed a new ML model in a Jupyter notebook. You want to establish a reliable and repeatable model training process that tracks the versions and lineage of your model artifacts. You plan to retrain your model weekly. How should you operationalize your training process?

**A.** 1. Create an instance of the CustomTrainingJob class with the Vertex AI SDK to train your model.
2. Using the Notebooks API, create a scheduled execution to run the training code weekly.

**B.** 1. Create an instance of the CustomJob class with the Vertex AI SDK to train your model.
2. Use the Metadata API to register your model as a model artifact.
3. Using the Notebooks API, create a scheduled execution to run the training code weekly.

**C.** 1. Create a managed pipeline in Vertex AI Pipelines to train your model by using a Vertex AI CustomTrainingJobOp component.
2. Use the ModelUploadOp component to upload your model to Vertex AI Model Registry.
3. Use Cloud Scheduler and Cloud Run functions to run the Vertex AI pipeline weekly.

**D.** 1. Create a managed pipeline in Vertex AI Pipelines to train your model using a Vertex AI HyperParameterTuningJobRunOp component.
2. Use the ModelUploadOp component to upload your model to Vertex AI Model Registry.
3. Use Cloud Scheduler and Cloud Run functions to run the Vertex AI pipeline weekly.

**Respuesta de la fuente:** C

**Explicación:** Vertex AI Pipelines is the recommended service for creating reliable, repeatable ML workflows that automatically track lineage and versioning of model artifacts.
Using CustomTrainingJobOp within a pipeline allows you to define the training process declaratively, while ModelUploadOp ensures the resulting model is registered in the Vertex AI Model Registry for proper version control.
Cloud Scheduler can then be configured to trigger this pipeline execution on a weekly basis, fulfilling the scheduling requirement without relying on notebook-specific APIs.

## Pregunta 336

Contexto: [topics:106](#topics-106)
You have developed a custom ML model using Vertex AI and want to deploy it for online serving. You need to optimize the model's serving performance by ensuring that the model can handle high throughput while minimizing latency. You want to use the simplest solution. What should you do?

**A.** Deploy the model to a Vertex AI endpoint resource to automatically scale the serving backend based on the throughput. Configure the endpoint's autoscaling settings to minimize latency.

**B.** Implement a containerized serving solution using Cloud Run. Configure the concurrency settings to handle multiple requests simultaneously.

**C.** Apply simplification techniques such as model pruning and quantization to reduce the model's size and complexity. Retrain the model using Vertex AI to improve its performance, latency, memory, and throughput.

**D.** Enable request-response logging for the model hosted in Vertex AI. Use Looker Studio to analyze the logs, identify bottlenecks, and optimize the model accordingly.

**Respuesta de la fuente:** A

**Explicación:** Deploying to a Vertex AI Endpoint (Option A) is the simplest and most native solution for online serving within the Vertex AI ecosystem. It provides built-in autoscaling capabilities that automatically adjust resources based on throughput demand, directly addressing the requirements for high throughput and low latency without requiring manual container management or model retraining.

## Pregunta 337

Contexto: [topics:106](#topics-106)
Your company needs to generate product summaries for vendors. You evaluate a foundation model from Model Garden for text summarization and find the style of the summaries are not aligned with your company's brand voice. How should you improve this LLM-based summarization model to better meet your business objectives?

**A.** Replace the pre-trained model with another model in Model Garden.

**B.** Fine-tune the model using a company-specific dataset.

**C.** Increase the model's temperature parameter.

**D.** Tune the token output limit in the response.

**Respuesta de la fuente:** B

**Explicación:** Fine-tuning adapts a pre-trained foundation model to specific patterns, tones, and styles present in your proprietary dataset, directly addressing the brand voice misalignment.
Replacing the model (A) relies on finding another off-the-shelf model that accidentally matches your voice, which is unlikely.
Adjusting temperature (C) controls randomness/creativity but does not alter stylistic norms, while changing token limits (D) only affects response length.

## Pregunta 338

Contexto: [topics:106](#topics-106)
You built a custom Vertex AI pipeline job that preprocesses images and trains an object detection model. The pipeline currently uses 1 n1-standard-8 machine with 1 NVIDIA Tesla V100 GPU. You want to reduce the model training time without compromising model accuracy. What should you do?

**A.** Reduce the number of layers in your object detection model.

**B.** Train the same model on a stratified subset of your dataset.

**C.** Update the WorkerPoolSpec to use a machine with 24 vCPUs and 1 NVIDIA Tesla V100 GPU.

**D.** Update the WorkerPoolSpec to use a machine with 24 vCPUs and 3 NVIDIA Tesla V100 GPUs.

**Respuesta de la fuente:** D

**Explicación:** To reduce training time without compromising accuracy, you must increase computational power rather than altering the model architecture or dataset size.
Options A and B would negatively impact model accuracy or generalization.
Option C increases CPU resources, but deep learning training is GPU-bound, so extra vCPUs provide minimal benefit.
Option D adds three V100 GPUs, significantly increasing parallel processing capacity to accelerate training while maintaining the same model and data.

## Pregunta 339

Contexto: [topics:106](#topics-106)
You are a SQL analyst. You need to utilize a TensorFlow customer segmentation model stored In Cloud Storage. You want to use the simplest and most efficient approach. What should you do?

**A.** Import the model into Vertex AI Model Registry. Deploy the model to a Vertex AI endpoint, and use SQL for inference in BigQuery.

**B.** Deploy the model by using TensorFlow Serving, and call for inference from BigQuery.

**C.** Convert the model into a BigQuery ML model, and use SQL for inference.

**D.** Import the model into BigQuery, and use SQL for inference.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.