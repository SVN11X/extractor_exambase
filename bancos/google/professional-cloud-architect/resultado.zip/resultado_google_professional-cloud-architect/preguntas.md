# professional cloud architect

155 / 360 preguntas. Cobertura completa: False.

Respuestas de la fuente; revisión técnica pendiente. Las imágenes permanecen en sus campos de origen.

155 respuestas conservadas; 0 pendientes.

<a id="topics-92"></a>
## Contexto topics:92
name:
Topic 1


## Pregunta 1

Contexto: [topics:92](#topics-92)
Your company has decided to make a major revision of their API in order to create better experiences for their developers. They need to keep the old version of the API available and deployable, while allowing new customers and testers to try out the new API. They want to keep the same SSL and DNS records in place to serve both APIs.
What should they do?

**A.** Configure a new load balancer for the new version of the API

**B.** Reconfigure old clients to use a new endpoint for the new API

**C.** Have the old API forward traffic to the new API based on the path

**D.** Use separate backend pools for each API path behind the load balancer

**Respuesta de la fuente:** D

**Explicación:** Using separate backend pools for each API path allows the load balancer to route traffic based on URL paths while maintaining a single IP address, SSL certificate, and DNS record. This satisfies the requirement to keep existing configuration intact while supporting parallel deployment of both API versions.

## Pregunta 2

Contexto: [topics:92](#topics-92)
Your company plans to migrate a multi-petabyte data set to the cloud. The data set must be available 24hrs a day. Your business analysts have experience only with using a SQL interface.
How should you store the data to optimize it for ease of analysis?

**A.** Load data into Google BigQuery

**B.** Insert data into Google Cloud SQL

**C.** Put flat files into Google Cloud Storage

**D.** Stream data into Google Cloud Datastore

**Respuesta de la fuente:** A

**Explicación:** BigQuery is the correct choice because it is a serverless data warehouse specifically designed for analyzing massive datasets (petabyte-scale) using standard SQL, aligning with the analysts' skills.
In contrast, Cloud SQL is an OLTP database that does not scale effectively to petabytes and is unsuitable for heavy analytical workloads, while Cloud Storage lacks native SQL query capabilities without additional tools.

## Pregunta 3

Contexto: [topics:92](#topics-92)
The operations manager asks you for a list of recommended practices that she should consider when migrating a J2EE application to the cloud.
Which three practices should you recommend? (Choose three.)

**A.** Port the application code to run on Google App Engine

**B.** Integrate Cloud Dataflow into the application to capture real-time metrics

**C.** Instrument the application with a monitoring tool like Stackdriver Debugger

**D.** Select an automation framework to reliably provision the cloud infrastructure

**E.** Deploy a continuous integration tool with automated testing in a staging environment

**F.** Migrate from MySQL to a managed NoSQL database like Google Cloud Datastore or Bigtable

**Respuesta de la fuente:** C, D, E

**Explicación:** The correct practices focus on universal cloud migration strategies rather than specific vendor lock-in steps.
Instrumenting with monitoring tools (C) ensures visibility and reliability in the new environment, while automation frameworks (D) enable consistent, reliable infrastructure provisioning essential for cloud scalability.
Implementing CI/CD with automated testing (E) guarantees code quality and stability during the transition process.

## Pregunta 4

Contexto: [topics:92](#topics-92)
A news feed web service has the following code running on Google App Engine. During peak load, users report that they can see news articles they already viewed.
What is the most likely cause of this problem?
[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/4ce30aba71fc77480182.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
import news
from flask import Flask, redirect, request
from flask.ext.api import status
from google.appengine.api import users
app = Flask(_name_)
sessions = {}
Gapp. route ("/”)
def homepage ():
user = users.get_current_user()
if not user:
return “Invalid login”,
status.HTTP_401_UNAUTHORIZED
if user not in session
sessions[user] = {“viewed”: []}
news_articles = news.get_new_news (user, sessions [user]
(viewed”])
sessions [user] [“viewed”] +- [n["id”] for n
in news_articles]
return news. render (news_articles)
if _name, main”:
app. run ()
```

**A.** The session variable is local to just a single instance

**B.** The session variable is being overwritten in Cloud Datastore

**C.** The URL of the API needs to be modified to prevent caching

**D.** The HTTP Expires header needs to be set to -1 stop caching

**Respuesta de la fuente:** A

**Explicación:** Google App Engine automatically scales by spinning up new instances to handle peak traffic, routing requests from the same user to different instances. Since the `sessions` variable is stored in local memory (in-memory dictionary), it is not shared across these instances. Consequently, when a request lands on a different instance that lacks the user's session history, previously viewed articles are shown again.

## Pregunta 5

Contexto: [topics:92](#topics-92)
An application development team believes their current logging tool will not meet their needs for their new cloud-based product. They want a better tool to capture errors and help them analyze their historical log data. You want to help them find a solution that meets their needs.
What should you do?

**A.** Direct them to download and install the Google StackDriver logging agent

**B.** Send them a list of online resources about logging best practices

**C.** Help them define their requirements and assess viable logging tools

**D.** Help them upgrade their current tool to take advantage of any new features

**Respuesta de la fuente:** C

**Explicación:** As a cloud architect, the primary responsibility is to understand specific business and technical requirements before recommending a solution.
The question states the team believes their current tool is insufficient but does not define precise metrics (e.g., retention periods, volume, integration needs), making it premature to select a specific tool like Stackdriver or suggest an upgrade.
Option C correctly prioritizes defining these requirements to ensure the selected logging solution effectively addresses error capture and historical analysis needs.

## Pregunta 6

Contexto: [topics:92](#topics-92)
You need to reduce the number of unplanned rollbacks of erroneous production deployments in your company's web hosting platform. Improvement to the QA/
Test processes accomplished an 80% reduction.
Which additional two approaches can you take to further reduce the rollbacks? (Choose two.)

**A.** Introduce a green-blue deployment model

**B.** Replace the QA environment with canary releases

**C.** Fragment the monolithic platform into microservices

**D.** Reduce the platform's dependency on relational database systems

**E.** Replace the platform's relational database systems with a NoSQL database

**Respuesta de la fuente:** A, C

**Explicación:** Blue-green deployment (A) allows for instant rollback by switching traffic between two identical environments, directly mitigating the impact of erroneous releases.
Fragmenting a monolithic platform into microservices (C) reduces the blast radius of failures and simplifies isolated testing, further decreasing the likelihood of system-wide rollbacks.

## Pregunta 7

Contexto: [topics:92](#topics-92)
To reduce costs, the Director of Engineering has required all developers to move their development infrastructure resources from on-premises virtual machines
(VMs) to Google Cloud Platform. These resources go through multiple start/stop events during the day and require state to persist. You have been asked to design the process of running a development environment in Google Cloud while providing cost visibility to the finance department.
Which two steps should you take? (Choose two.)

**A.** Use the - -no-auto-delete flag on all persistent disks and stop the VM

**B.** Use the - -auto-delete flag on all persistent disks and terminate the VM

**C.** Apply VM CPU utilization label and include it in the BigQuery billing export

**D.** Use Google BigQuery billing export and labels to associate cost to groups

**E.** Store all state into local SSD, snapshot the persistent disks, and terminate the VM

**F.** Store all state in Google Cloud Storage, snapshot the persistent disks, and terminate the VM

**Respuesta de la fuente:** A, D

**Explicación:** Option A is correct because using the `--no-auto-delete` flag ensures that persistent disks are retained when VMs are stopped or deleted, satisfying the requirement for state persistence.
Option D is correct because exporting billing data to BigQuery and applying labels allows the finance department to aggregate and analyze costs by specific groups or teams, providing the required cost visibility.

## Pregunta 8

Contexto: [topics:92](#topics-92)
Your company wants to track whether someone is present in a meeting room reserved for a scheduled meeting. There are 1000 meeting rooms across 5 offices on 3 continents. Each room is equipped with a motion sensor that reports its status every second. The data from the motion detector includes only a sensor ID and several different discrete items of information. Analysts will use this data, together with information about account owners and office locations.
Which database type should you use?

**A.** Flat file

**B.** NoSQL

**C.** Relational

**D.** Blobstore

**Respuesta de la fuente:** B

**Explicación:** The scenario involves high-volume IoT data (1 million records per second) with a semi-structured schema ('several different discrete items'). NoSQL databases, such as Bigtable or Cloud Datastore, are designed for this type of unstructured or semi-structured time-series data, offering the necessary horizontal scalability and write performance.
Relational databases struggle with this volume and schema flexibility, while flat files lack query capability and blobstores are unsuitable for structured sensor metadata.

## Pregunta 9

Contexto: [topics:92](#topics-92)
You set up an autoscaling instance group to serve web traffic for an upcoming launch. After configuring the instance group as a backend service to an HTTP(S) load balancer, you notice that virtual machine (VM) instances are being terminated and re-launched every minute. The instances do not have a public IP address.
You have verified the appropriate web response is coming from each instance using the curl command. You want to ensure the backend is configured correctly.
What should you do?

**A.** Ensure that a firewall rules exists to allow source traffic on HTTP/HTTPS to reach the load balancer.

**B.** Assign a public IP to each instance and configure a firewall rule to allow the load balancer to reach the instance public IP.

**C.** Ensure that a firewall rule exists to allow load balancer health checks to reach the instances in the instance group.

**D.** Create a tag on each instance with the name of the load balancer. Configure a firewall rule with the name of the load balancer as the source and the instance tag as the destination.

**Respuesta de la fuente:** C

**Explicación:** The cyclical termination and relaunching of VMs indicate that the health checks are failing, causing the autoscaler to replace instances it considers unhealthy.
Since you confirmed the web application is responding correctly via curl, the issue lies in network access for the load balancer's health check probes rather than the application itself.
Firewall rules must explicitly allow inbound traffic from Google Cloud's health check IP ranges (130.211.0.0/22 and 35.191.0.0/16) to ensure the load balancer can reach the backend instances.

## Pregunta 10

Contexto: [topics:92](#topics-92)
You write a Python script to connect to Google BigQuery from a Google Compute Engine virtual machine. The script is printing errors that it cannot connect to
BigQuery.
What should you do to fix the script?

**A.** Install the latest BigQuery API client library for Python

**B.** Run your script on a new virtual machine with the BigQuery access scope enabled

**C.** Create a new service account with BigQuery access and execute your script with that user

**D.** Install the bq component for gcloud with the command gcloud components install bq.

**Respuesta de la fuente:** C

**Explicación:** Creating a dedicated service account with the appropriate BigQuery IAM roles aligns with Google Cloud best practices for application authentication, ensuring least-privilege access.
While default Compute Engine metadata-based scopes (Option B) are a legacy mechanism and often restricted or deprecated, using a specific service account provides explicit, manageable, and secure permissions for the script.

## Pregunta 11

Contexto: [topics:92](#topics-92)
Your customer is moving an existing corporate application to Google Cloud Platform from an on-premises data center. The business owners require minimal user disruption. There are strict security team requirements for storing passwords.
What authentication strategy should they use?

**A.** Use G Suite Password Sync to replicate passwords into Google

**B.** Federate authentication via SAML 2.0 to the existing Identity Provider

**C.** Provision users in Google using the Google Cloud Directory Sync tool

**D.** Ask users to set their Google password to match their corporate password

**Respuesta de la fuente:** B

**Explicación:** Federating authentication via SAML 2.0 (Option B) ensures that password storage and validation remain with the on-premises Identity Provider, satisfying strict security requirements against storing passwords in Google Cloud. This approach also minimizes user disruption by allowing Single Sign-On (SSO), so users continue using their existing corporate credentials without needing to manage separate passwords or undergo a migration of credential data.

## Pregunta 12

Contexto: [topics:92](#topics-92)
Your company has successfully migrated to the cloud and wants to analyze their data stream to optimize operations. They do not have any existing code for this analysis, so they are exploring all their options. These options include a mix of batch and stream processing, as they are running some hourly jobs and live- processing some data as it comes in.
Which technology should they use for this?

**A.** Google Cloud Dataproc

**B.** Google Cloud Dataflow

**C.** Google Container Engine with Bigtable

**D.** Google Compute Engine with Google BigQuery

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Dataflow is the optimal choice because it provides a unified service for both batch and stream processing within a single API.
This directly addresses the requirement to handle hourly jobs and live data ingestion without maintaining existing code or managing complex infrastructure like Dataproc clusters.

## Pregunta 13

Contexto: [topics:92](#topics-92)
Your customer is receiving reports that their recently updated Google App Engine application is taking approximately 30 seconds to load for some of their users.
This behavior was not reported before the update.
What strategy should you take?

**A.** Work with your ISP to diagnose the problem

**B.** Open a support ticket to ask for network capture and flow data to diagnose the problem, then roll back your application

**C.** Roll back to an earlier known good release initially, then use Stackdriver Trace and Logging to diagnose the problem in a development/test/staging environment

**D.** Roll back to an earlier known good release, then push the release again at a quieter period to investigate. Then use Stackdriver Trace and Logging to diagnose the problem

**Respuesta de la fuente:** C

**Explicación:** Since the latency issue began immediately after a deployment, the highest priority is to restore service stability by rolling back to the last known good version.
Investigating in a development or staging environment using Stackdriver Trace and Logging allows you to diagnose root causes safely without impacting production users or risking further downtime.

## Pregunta 14

Contexto: [topics:92](#topics-92)
A production database virtual machine on Google Compute Engine has an ext4-formatted persistent disk for data files. The database is about to run out of storage space.
How can you remediate the problem with the least amount of downtime?

**A.** In the Cloud Platform Console, increase the size of the persistent disk and use the resize2fs command in Linux.

**B.** Shut down the virtual machine, use the Cloud Platform Console to increase the persistent disk size, then restart the virtual machine

**C.** In the Cloud Platform Console, increase the size of the persistent disk and verify the new space is ready to use with the fdisk command in Linux

**D.** In the Cloud Platform Console, create a new persistent disk attached to the virtual machine, format and mount it, and configure the database service to move the files to the new disk

**E.** In the Cloud Platform Console, create a snapshot of the persistent disk restore the snapshot to a new larger disk, unmount the old disk, mount the new disk and restart the database service

**Respuesta de la fuente:** A

**Explicación:** Google Compute Engine supports resizing persistent disks online while the virtual machine is running, eliminating the need for downtime associated with shutting down or restarting the instance.
Once the disk size is increased via the console, the ext4 file system must be expanded using the `resize2fs` command, which can be executed on a mounted filesystem to make the new space immediately available.
Other options involve unnecessary reboots (B, E) or incorrect tools like `fdisk`, which manages partition tables rather than resizing existing ext4 volumes (C).

## Pregunta 15

Contexto: [topics:92](#topics-92)
Your application needs to process credit card transactions. You want the smallest scope of Payment Card Industry (PCI) compliance without compromising the ability to analyze transactional data and trends relating to which payment methods are used.
How should you design your architecture?

**A.** Create a tokenizer service and store only tokenized data

**B.** Create separate projects that only process credit card data

**C.** Create separate subnetworks and isolate the components that process credit card data

**D.** Streamline the audit discovery phase by labeling all of the virtual machines (VMs) that process PCI data

**E.** Enable Logging export to Google BigQuery and use ACLs and views to scope the data shared with the auditor

**Respuesta de la fuente:** A

**Explicación:** Tokenization replaces sensitive Primary Account Numbers (PANs) with non-sensitive equivalents called tokens, which are outside the scope of PCI DSS.
By storing only tokenized data for analysis, you significantly reduce the number of systems handling sensitive cardholder data, thereby minimizing compliance scope while preserving the ability to analyze transaction trends.

## Pregunta 16

Contexto: [topics:92](#topics-92)
You have been asked to select the storage system for the click-data of your company's large portfolio of websites. This data is streamed in from a custom website analytics package at a typical rate of 6,000 clicks per minute. With bursts of up to 8,500 clicks per second. It must have been stored for future analysis by your data science and user experience teams.
Which storage infrastructure should you choose?

**A.** Google Cloud SQL

**B.** Google Cloud Bigtable

**C.** Google Cloud Storage

**D.** Google Cloud Datastore

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Bigtable is the optimal choice because it is a managed NoSQL database designed specifically for high-throughput, low-latency workloads involving large-scale time-series and event data like clickstreams.

It can easily handle the specified write volume of up to 8,500 clicks per second with bursts, whereas Cloud SQL would struggle with such high write concurrency, Cloud Storage lacks structured query capabilities for analysis, and Datastore is less suitable for this specific high-velocity ingestion pattern.

## Pregunta 17

Contexto: [topics:92](#topics-92)
You are creating a solution to remove backup files older than 90 days from your backup Cloud Storage bucket. You want to optimize ongoing Cloud Storage spend.
What should you do?

**A.** Write a lifecycle management rule in XML and push it to the bucket with gsutil

**B.** Write a lifecycle management rule in JSON and push it to the bucket with gsutil

**C.** Schedule a cron script using gsutil ls —lr gs://backups/** to find and remove items older than 90 days

**D.** Schedule a cron script using gsutil ls —l gs://backups/** to find and remove items older than 90 days and schedule it with cron

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Cloud Storage lifecycle management configurations must be defined in JSON format when using the `gsutil` command-line tool. Implementing a native lifecycle rule automatically handles object deletion based on age, which is more cost-effective and reliable than managing custom cron scripts (Options C and D). Option A is incorrect because `gsutil` does not accept XML for this specific operation.

## Pregunta 18

Contexto: [topics:92](#topics-92)
Your company is forecasting a sharp increase in the number and size of Apache Spark and Hadoop jobs being run on your local datacenter. You want to utilize the cloud to help you scale this upcoming demand with the least amount of operations work and code change.
Which product should you use?

**A.** Google Cloud Dataflow

**B.** Google Cloud Dataproc

**C.** Google Compute Engine

**D.** Google Kubernetes Engine

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Dataproc is the managed service specifically designed to run Apache Spark and Hadoop jobs.
It allows you to leverage existing code with minimal operational overhead by handling cluster management and scaling automatically.

## Pregunta 19

Contexto: [topics:92](#topics-92)
The database administration team has asked you to help them improve the performance of their new database server running on Google Compute Engine. The database is for importing and normalizing their performance statistics and is built with MySQL running on Debian Linux. They have an n1-standard-8 virtual machine with 80 GB of SSD persistent disk.
What should they change to get better performance from this system?

**A.** Increase the virtual machine's memory to 64 GB

**B.** Create a new virtual machine running PostgreSQL

**C.** Dynamically resize the SSD persistent disk to 500 GB

**D.** Migrate their performance metrics warehouse to BigQuery

**E.** Modify all of their batch jobs to use bulk inserts into the database

**Respuesta de la fuente:** C

**Explicación:** On Google Compute Engine, the IOPS and throughput of an SSD persistent disk are directly determined by its size (up to a maximum cap defined by the instance type). By increasing the disk size from 80 GB to 500 GB, the available IOPS increases significantly (from ~2,400 to ~15,000), which directly improves database performance for import and normalization tasks without requiring a VM shutdown or migration. Increasing memory alone (Option A) does not increase disk IOPS, and migrating to BigQuery (Option D) is an architectural change rather than a direct performance tuning of the existing MySQL server.

## Pregunta 20

Contexto: [topics:92](#topics-92)
You want to optimize the performance of an accurate, real-time, weather-charting application. The data comes from 50,000 sensors sending 10 readings a second, in the format of a timestamp and sensor reading.
Where should you store the data?

**A.** Google BigQuery

**B.** Google Cloud SQL

**C.** Google Cloud Bigtable

**D.** Google Cloud Storage

**Respuesta de la fuente:** C

**Explicación:** Google Cloud Bigtable is the correct choice because it is a NoSQL database designed for high-throughput, low-latency ingestion of massive datasets, making it ideal for real-time IoT time-series data.
Unlike relational databases (Cloud SQL) which struggle with such high write volumes, or analytics warehouses (BigQuery) and storage systems (GCS) which are optimized for batch processing rather than real-time random access, Bigtable efficiently handles the 500,000 writes per second required by the sensor network.

## Pregunta 21

Contexto: [topics:92](#topics-92)
Your company's user-feedback portal comprises a standard LAMP stack replicated across two zones. It is deployed in the us-central1 region and uses autoscaled managed instance groups on all layers, except the database. Currently, only a small group of select customers have access to the portal. The portal meets a
99,99% availability SLA under these conditions. However next quarter, your company will be making the portal available to all users, including unauthenticated users. You need to develop a resiliency testing strategy to ensure the system maintains the SLA once they introduce additional user load.
What should you do?

**A.** Capture existing users input, and replay captured user load until autoscale is triggered on all layers. At the same time, terminate all resources in one of the zones

**B.** Create synthetic random user input, replay synthetic load until autoscale logic is triggered on at least one layer, and introduce "chaos" to the system by terminating random resources on both zones

**C.** Expose the new system to a larger group of users, and increase group size each day until autoscale logic is triggered on all layers. At the same time, terminate random resources on both zones

**D.** Capture existing users input, and replay captured user load until resource utilization crosses 80%. Also, derive estimated number of users based on existing user's usage of the app, and deploy enough resources to handle 200% of expected load

**Respuesta de la fuente:** B

**Explicación:** Resilience testing focuses on validating system behavior during failure conditions, which requires introducing chaos (resource termination) rather than just measuring load. Option B is correct because it simulates realistic failures across both zones using synthetic load that accounts for the new unauthenticated traffic profile, ensuring the SLA holds under unexpected stress. Option A is insufficient as it only tests single-zone loss and relies on outdated user patterns, while D describes capacity planning rather than resilience testing.

## Pregunta 22

Contexto: [topics:92](#topics-92)
One of the developers on your team deployed their application in Google Container Engine with the Dockerfile below. They report that their application deployments are taking too long.
[Imagen: sin descripción]
You want to optimize this Dockerfile for faster deployment times without adversely affecting the app's functionality.
Which two actions should you take? (Choose two.)
Imagen · question_text · sin descripción
![Imagen original](imagenes/0722ecab9a02ee9e5738.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
FROM ubuntu:16.
copy . /sre
RUN apt-get update && apt-get install -y python python-pip
RUN pip install -r requirements.txt
```

**A.** Remove Python after running pip

**B.** Remove dependencies from requirements.txt

**C.** Use a slimmed-down base image like Alpine Linux

**D.** Use larger machine types for your Google Container Engine node pools

**E.** Copy the source after he package dependencies (Python and pip) are installed

**Respuesta de la fuente:** C, E

**Explicación:** Using a slimmed-down base image like Alpine Linux (C) significantly reduces the overall container size, leading to faster download and deployment times.
Copying source code after installing dependencies (E) leverages Docker's layer caching mechanism; since application code changes more frequently than requirements, this ensures dependency installation layers are reused during rebuilds.

## Pregunta 23

Contexto: [topics:92](#topics-92)
Your solution is producing performance bugs in production that you did not see in staging and test environments. You want to adjust your test and deployment procedures to avoid this problem in the future.
What should you do?

**A.** Deploy fewer changes to production

**B.** Deploy smaller changes to production

**C.** Increase the load on your test and staging environments

**D.** Deploy changes to a small subset of users before rolling out to production

**Respuesta de la fuente:** C

**Explicación:** Performance bugs that appear in production but not in staging are typically caused by differences in traffic volume or concurrency levels.
Increasing the load on test and staging environments ensures these non-functional requirements are validated before a full production rollout,
thereby catching performance issues during the testing phase as requested.

## Pregunta 24

Contexto: [topics:92](#topics-92)
A small number of API requests to your microservices-based application take a very long time. You know that each request to the API can traverse many services.
You want to know which service takes the longest in those cases.
What should you do?

**A.** Set timeouts on your application so that you can fail requests faster

**B.** Send custom metrics for each of your requests to Stackdriver Monitoring

**C.** Use Stackdriver Monitoring to look for insights that show when your API latencies are high

**D.** Instrument your application with Stackdriver Trace in order to break down the request latencies at each microservice

**Respuesta de la fuente:** D

**Explicación:** Stackdriver Trace (now Cloud Trace) is a distributed tracing system designed to visualize request paths across microservices.
It breaks down latency at each service hop, allowing you to identify the specific bottleneck causing slow API responses.
Monitoring and timeouts manage symptoms or aggregate data but do not provide the granular service-level breakdown needed here.

## Pregunta 25

Contexto: [topics:92](#topics-92)
During a high traffic portion of the day, one of your relational databases crashes, but the replica is never promoted to a master. You want to avoid this in the future.
What should you do?

**A.** Use a different database

**B.** Choose larger instances for your database

**C.** Create snapshots of your database more regularly

**D.** Implement routinely scheduled failovers of your databases

**Respuesta de la fuente:** D

**Explicación:** The core issue is that the replica failed to promote during a critical failure, indicating a potential flaw in the automated failover configuration or health checks.
Routine scheduled failovers allow administrators to proactively test the promotion process and validate that the replica correctly assumes the master role before a real crisis occurs.
While scaling up (Option B) might prevent resource-based crashes, it does not address the specific operational failure of the promotion mechanism itself.

## Pregunta 26

Contexto: [topics:92](#topics-92)
Your organization requires that metrics from all applications be retained for 5 years for future analysis in possible legal proceedings.
Which approach should you use?

**A.** Grant the security team access to the logs in each Project

**B.** Configure Stackdriver Monitoring for all Projects, and export to BigQuery

**C.** Configure Stackdriver Monitoring for all Projects with the default retention policies

**D.** Configure Stackdriver Monitoring for all Projects, and export to Google Cloud Storage

**Respuesta de la fuente:** D

**Explicación:** Options A and C are incorrect because Stackdriver Logging/Monitoring default retention is only 30 days, which fails the 5-year requirement.
Option D is the best choice because exporting to Google Cloud Storage (specifically using Archive or Coldline classes) provides a cost-effective solution for long-term data retention required for legal proceedings.
While BigQuery (Option B) supports analysis, it is generally more expensive for passive archival storage of large volumes of historical data compared to Cloud Storage.

## Pregunta 27

Contexto: [topics:92](#topics-92)
Your company has decided to build a backup replica of their on-premises user authentication PostgreSQL database on Google Cloud Platform. The database is 4
TB, and large updates are frequent. Replication requires private address space communication.
Which networking approach should you use?

**A.** Google Cloud Dedicated Interconnect

**B.** Google Cloud VPN connected to the data center network

**C.** A NAT and TLS translation gateway installed on-premises

**D.** A Google Compute Engine instance with a VPN server installed connected to the data center network

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Dedicated Interconnect is the correct choice because it provides a direct, private physical connection between on-premises infrastructure and GCP.
This ensures high bandwidth and low latency required for replicating a large (4 TB) database with frequent updates, while keeping traffic off the public internet to satisfy the private address space requirement.
VPN solutions traverse the public internet, which poses security risks and potential bandwidth limitations for such heavy data loads.

## Pregunta 28

Contexto: [topics:92](#topics-92)
Auditors visit your teams every 12 months and ask to review all the Google Cloud Identity and Access Management (Cloud IAM) policy changes in the previous 12 months. You want to streamline and expedite the analysis and audit process.
What should you do?

**A.** Create custom Google Stackdriver alerts and send them to the auditor

**B.** Enable Logging export to Google BigQuery and use ACLs and views to scope the data shared with the auditor

**C.** Use cloud functions to transfer log entries to Google Cloud SQL and use ACLs and views to limit an auditor's view

**D.** Enable Google Cloud Storage (GCS) log export to audit logs into a GCS bucket and delegate access to the bucket

**Respuesta de la fuente:** B

**Explicación:** To streamline and expedite the audit process, you need a tool that allows for rapid querying and analysis of large datasets, which Cloud Storage buckets do not provide efficiently. BigQuery enables auditors to run SQL queries against exported logs directly, significantly reducing the time required to review IAM policy changes compared to downloading or parsing raw files from GCS.
Reference: Google Cloud documentation on audit logging scenarios recommends BigQuery for interactive analysis and streamlining audits.

## Pregunta 29

Contexto: [topics:92](#topics-92)
You are designing a large distributed application with 30 microservices. Each of your distributed microservices needs to connect to a database back-end. You want to store the credentials securely.
Where should you store the credentials?

**A.** In the source code

**B.** In an environment variable

**C.** In a secret management system

**D.** In a config file that has restricted access through ACLs

**Respuesta de la fuente:** C

**Explicación:** A secret management system is the industry standard for securing credentials in distributed architectures because it provides centralized storage, encryption at rest, and fine-grained access controls.
Unlike source code or config files, it prevents accidental exposure through version control and simplifies credential rotation without redeploying services.
Environment variables are less secure as they can be exposed via process listings, making a dedicated secret manager the most robust choice for protecting sensitive data.

## Pregunta 30

Contexto: [topics:92](#topics-92)
A lead engineer wrote a custom tool that deploys virtual machines in the legacy data center. He wants to migrate the custom tool to the new cloud environment.
You want to advocate for the adoption of Google Cloud Deployment Manager.
What are two business risks of migrating to Cloud Deployment Manager? (Choose two.)

**A.** Cloud Deployment Manager uses Python

**B.** Cloud Deployment Manager APIs could be deprecated in the future

**C.** Cloud Deployment Manager is unfamiliar to the company's engineers

**D.** Cloud Deployment Manager requires a Google APIs service account to run

**E.** Cloud Deployment Manager can be used to permanently delete cloud resources

**F.** Cloud Deployment Manager only supports automation of Google Cloud resources

**Respuesta de la fuente:** C, F

**Explicación:** Choice C represents a business risk because migrating to an unfamiliar tool introduces a learning curve, leading to potential deployment errors and productivity loss during the transition period. Choice F is a business risk related to vendor lock-in and strategic flexibility; since Deployment Manager only supports Google Cloud resources, it cannot automate hybrid or multi-cloud infrastructure, potentially forcing the company to maintain legacy tools or adopt additional solutions for non-GCP assets.

## Pregunta 31

Contexto: [topics:92](#topics-92)
A development manager is building a new application. He asks you to review his requirements and identify what cloud technologies he can use to meet them. The application must:
1. Be based on open-source technology for cloud portability
2. Dynamically scale compute capacity based on demand
3. Support continuous software delivery
4. Run multiple segregated copies of the same application stack
5. Deploy application bundles using dynamic templates
6. Route network traffic to specific services based on URL
Which combination of technologies will meet all of his requirements?

**A.** Google Kubernetes Engine, Jenkins, and Helm

**B.** Google Kubernetes Engine and Cloud Load Balancing

**C.** Google Kubernetes Engine and Cloud Deployment Manager

**D.** Google Kubernetes Engine, Jenkins, and Cloud Load Balancing

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Helm satisfies the specific requirement to 'deploy application bundles using dynamic templates' via its chart templating engine.
Jenkins addresses the need for 'continuous software delivery' through CI/CD pipelines.
Google Kubernetes Engine (GKE) handles open-source portability, dynamic scaling, segregated copies via namespaces, and URL-based routing via Ingress resources.

## Pregunta 32

Contexto: [topics:92](#topics-92)
You have created several pre-emptible Linux virtual machine instances using Google Compute Engine. You want to properly shut down your application before the virtual machines are preempted.
What should you do?

**A.** Create a shutdown script named k99.shutdown in the /etc/rc.6.d/ directory

**B.** Create a shutdown script registered as a xinetd service in Linux and configure a Stackdriver endpoint check to call the service

**C.** Create a shutdown script and use it as the value for a new metadata entry with the key shutdown-script in the Cloud Platform Console when you create the new virtual machine instance

**D.** Create a shutdown script, registered as a xinetd service in Linux, and use the gcloud compute instances add-metadata command to specify the service URL as the value for a new metadata entry with the key shutdown-script-url

**Respuesta de la fuente:** C

**Explicación:** Google Compute Engine executes shutdown scripts specified via instance metadata keys like `shutdown-script` or `shutdown-script-url` when an instance is preempted.
Option C correctly uses the `shutdown-script` key to provide script contents directly, which works for both new and existing instances (via `gcloud compute instances add-metadata`).
Option D is incorrect because `shutdown-script-url` requires a Cloud Storage URL, not an internal xinetd service URL.

## Pregunta 33

Contexto: [topics:92](#topics-92)
Your organization has a 3-tier web application deployed in the same network on Google Cloud Platform. Each tier (web, API, and database) scales independently of the others. Network traffic should flow through the web to the API tier and then on to the database tier. Traffic should not flow between the web and the database tier.
How should you configure the network?

**A.** Add each tier to a different subnetwork

**B.** Set up software based firewalls on individual VMs

**C.** Add tags to each tier and set up routes to allow the desired traffic flow

**D.** Add tags to each tier and set up firewall rules to allow the desired traffic flow

**Respuesta de la fuente:** D

**Explicación:** Network segmentation in GCP is primarily enforced using VPC firewall rules rather than just subnetwork boundaries. By assigning network tags to each tier and configuring specific ingress/egress firewall rules, you can explicitly allow traffic from Web to API and API to Database while denying direct communication between Web and Database. Routing only determines the path of packets and does not provide the access control necessary to block unwanted traffic flows.

## Pregunta 34

Contexto: [topics:92](#topics-92)
Your development team has installed a new Linux kernel module on the batch servers in Google Compute Engine (GCE) virtual machines (VMs) to speed up the nightly batch process. Two days after the installation, 50% of the batch servers failed the nightly batch run. You want to collect details on the failure to pass back to the development team.
Which three actions should you take? (Choose three.)

**A.** Use Stackdriver Logging to search for the module log entries

**B.** Read the debug GCE Activity log using the API or Cloud Console

**C.** Use gcloud or Cloud Console to connect to the serial console and observe the logs

**D.** Identify whether a live migration event of the failed server occurred, using in the activity log

**E.** Adjust the Google Stackdriver timeline to match the failure time, and observe the batch server metrics

**F.** Export a debug VM into an image, and run the image on a local server where kernel log messages will be displayed on the native screen

**Respuesta de la fuente:** A, C, E

**Explicación:** No conservada en esta captura.

## Pregunta 35

Contexto: [topics:92](#topics-92)
Your company wants to try out the cloud with low risk. They want to archive approximately 100 TB of their log data to the cloud and test the analytics features available to them there, while also retaining that data as a long-term disaster recovery backup.
Which two steps should you take? (Choose two.)

**A.** Load logs into Google BigQuery

**B.** Load logs into Google Cloud SQL

**C.** Import logs into Google Stackdriver

**D.** Insert logs into Google Cloud Bigtable

**E.** Upload log files into Google Cloud Storage

**Respuesta de la fuente:** A, E

**Explicación:** Google Cloud Storage is the appropriate solution for archiving 100 TB of log data as a long-term disaster recovery backup due to its durability, scalability, and cost-effective storage classes like Coldline or Archive. Google BigQuery should be used to load the logs for analytics because it is a serverless, highly scalable data warehouse designed specifically for analyzing large datasets efficiently.

## Pregunta 36

Contexto: [topics:92](#topics-92)
You created a pipeline that can deploy your source code changes to your infrastructure in instance groups for self-healing. One of the changes negatively affects your key performance indicator. You are not sure how to fix it, and investigation could take up to a week.
What should you do?

**A.** Log in to a server, and iterate on the fox locally

**B.** Revert the source code change, and rerun the deployment pipeline

**C.** Log into the servers with the bad code change, and swap in the previous code

**D.** Change the instance group template to the previous one, and delete all instances

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it adheres to the principle of treating infrastructure as code by reverting the change at its source (the repository).
This ensures that any subsequent pipeline executions or deployments will not reintroduce the broken code, maintaining consistency between the source of truth and the deployed infrastructure.
Manual interventions like Options A and C violate automation best practices, while Option D creates state inconsistency between the instance group configuration and the version control system.

## Pregunta 37

Contexto: [topics:92](#topics-92)
Your organization wants to control IAM policies for different departments independently, but centrally.
Which approach should you take?

**A.** Multiple Organizations with multiple Folders

**B.** Multiple Organizations, one for each department

**C.** A single Organization with Folders for each department

**D.** A single Organization with multiple projects, each with a central owner

**Respuesta de la fuente:** C

**Explicación:** A single Organization with Folders (Choice C) is the correct approach because folders allow you to group resources and apply IAM policies at an intermediate level between the organization root and individual projects. This structure enables centralized governance through organization policies while granting departments independent administrative control over their specific folder and its contained projects.

Using multiple organizations (Choices A and B) creates silos that complicate centralized management, and modeling departments as single projects (Choice D) limits each department to only one project, which is typically insufficient for real-world needs.

## Pregunta 38

Contexto: [topics:92](#topics-92)
You deploy your custom Java application to Google App Engine. It fails to deploy and gives you the following stack trace.
What should you do?
[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/bd10155238fd39676838.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
java.lang.SecurityException: SHAl digest error for
com/Altostrat/Cloakedservlet.class
at com.google.appengine. runtime. Request process
-d36f818a24b8cfld (Request. java)
at
sun.security.util.ManifestEntryVerifier.verify
(Mani festEntryVeri fier. java:210)
at java.util. jar.JarvVerifier.processEntry
(Jarverifier.java:218)
at java.util. jar.JarvVerifier.update
(Jarverifier.java:205)
at
java.util. jar.JarvVerifiersverifierstream. read
(Jarverifier.java:428)
at sun.misc.Resource.getBytes
(Resource. java:124)
at java.net .URL.ClassLoader.defineClass
(URLClassLoader. java:273)
at sun.reflect .GeneratedMethodAccessorS. invoke
(Unknown Source)
at
sun. reflect .DelegatingMethodAccessorImp1. invoke
(DelegatingMethodAccessorImpl. java: 43)
at java.lang.reflect Method. invoke
(Method. java: 616)
at java.lang.ClassLoader.loadClass
(ClassLoader. java:266)
```

**A.** Upload missing JAR files and redeploy your application.

**B.** Digitally sign all of your JAR files and redeploy your application

**C.** Recompile the CLoakedServlet class using and MD5 hash instead of SHA1

**Respuesta de la fuente:** B

**Explicación:** The error trace indicates a `java.security.SignatureException` with an invalid SHA1 digest, which signifies that the JAR file's digital signature does not match its contents. This usually occurs when a JAR is modified after being signed or if the signature metadata is corrupt. To resolve this integrity mismatch, you must digitally sign all JAR files again to ensure the signatures are valid and consistent with the deployed code.

## Pregunta 39

Contexto: [topics:92](#topics-92)
You are designing a mobile chat application. You want to ensure people cannot spoof chat messages, by providing a message were sent by a specific user.
What should you do?

**A.** Tag messages client side with the originating user identifier and the destination user.

**B.** Encrypt the message client side using block-based encryption with a shared key.

**C.** Use public key infrastructure (PKI) to encrypt the message client side using the originating user's private key.

**D.** Use a trusted certificate authority to enable SSL connectivity between the client application and the server.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because using the originating user's private key to encrypt (sign) a message provides non-repudiation and integrity. Only the holder of the private key could have performed this operation, ensuring the recipient can verify the specific user's identity via the corresponding public key.

Option A is insecure as client-side tags are easily modified. Option B fails because shared keys do not provide unique originator identification (non-repudiation). Option D secures the transport channel but does not inherently bind the message content to a specific sender within the application layer.

## Pregunta 40

Contexto: [topics:92](#topics-92)
As part of implementing their disaster recovery plan, your company is trying to replicate their production MySQL database from their private data center to their
GCP project using a Google Cloud VPN connection. They are experiencing latency issues and a small amount of packet loss that is disrupting the replication.
What should they do?

**A.** Configure their replication to use UDP.

**B.** Configure a Google Cloud Dedicated Interconnect.

**C.** Restore their database daily using Google Cloud SQL.

**D.** Add additional VPN connections and load balance them.

**E.** Send the replicated transaction to Google Cloud Pub/Sub.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Dedicated Interconnect provides a private, Layer 2 connection with higher throughput, lower latency, and greater consistency than an IPsec VPN over the public internet.
This dedicated physical link eliminates the packet loss and latency issues caused by the unpredictable nature of the public network.

## Pregunta 41

Contexto: [topics:92](#topics-92)
Your customer support tool logs all email and chat conversations to Cloud Bigtable for retention and analysis. What is the recommended approach for sanitizing this data of personally identifiable information or payment card information before initial storage?

**A.** Hash all data using SHA256

**B.** Encrypt all data using elliptic curve cryptography

**C.** De-identify the data with the Cloud Data Loss Prevention API

**D.** Use regular expressions to find and redact phone numbers, email addresses, and credit card numbers

**Respuesta de la fuente:** C

**Explicación:** The Cloud Data Loss Prevention (DLP) API is the recommended Google Cloud service for automatically discovering, classifying, and de-identifying sensitive data like PII and payment card information.
Unlike manual regex approaches, it uses advanced inspection templates to accurately detect and redact sensitive content with high precision.
Hashing or encrypting data does not sanitize it by removing identifiers, whereas DLP specifically performs the required de-identification before storage.

## Pregunta 42

Contexto: [topics:92](#topics-92)
You are using Cloud Shell and need to install a custom utility for use in a few weeks. Where can you store the file so it is in the default execution path and persists across sessions?

**A.** ~/bin

**B.** Cloud Storage

**C.** /google/scripts

**D.** /usr/local/bin

**Respuesta de la fuente:** A

**Explicación:** Cloud Shell provides a persistent 5GB disk mounted at the $HOME directory, which survives session restarts.
Placing files in ~/bin ensures they are stored on this persistent volume and are automatically included in the user's PATH environment variable for easy execution.

## Pregunta 43

Contexto: [topics:92](#topics-92)
You want to create a private connection between your instances on Compute Engine and your on-premises data center. You require a connection of at least 20
Gbps. You want to follow Google-recommended practices. How should you set up the connection?

**A.** Create a VPC and connect it to your on-premises data center using Dedicated Interconnect.

**B.** Create a VPC and connect it to your on-premises data center using a single Cloud VPN.

**C.** Create a Cloud Content Delivery Network (Cloud CDN) and connect it to your on-premises data center using Dedicated Interconnect.

**D.** Create a Cloud Content Delivery Network (Cloud CDN) and connect it to your on-premises datacenter using a single Cloud VPN.

**Respuesta de la fuente:** A

**Explicación:** Dedicated Interconnect provides a private, high-bandwidth physical connection supporting speeds up to 100 Gbps, which satisfies the requirement of at least 20 Gbps.
Cloud VPN is unsuitable for this bandwidth level, as it typically caps at lower throughput (often cited around 3-30 Gbps depending on configuration) and traverses the public internet.
Cloud CDN is a content distribution service, not a method for establishing site-to-site network connectivity between on-premises data centers and Compute Engine instances.

## Pregunta 44

Contexto: [topics:92](#topics-92)
You are analyzing and defining business processes to support your startup's trial usage of GCP, and you don't yet know what consumer demand for your product will be. Your manager requires you to minimize GCP service costs and adhere to Google best practices. What should you do?

**A.** Utilize free tier and sustained use discounts. Provision a staff position for service cost management.

**B.** Utilize free tier and sustained use discounts. Provide training to the team about service cost management.

**C.** Utilize free tier and committed use discounts. Provision a staff position for service cost management.

**D.** Utilize free tier and committed use discounts. Provide training to the team about service cost management.

**Respuesta de la fuente:** B

**Explicación:** Sustained Use Discounts are automatic and ideal for unpredictable workloads during a trial phase, whereas Committed Use Discounts require long-term commitments unsuited to unknown demand.
Providing training empowers the existing team to manage costs effectively without the financial burden of provisioning a dedicated staff position for a startup.

## Pregunta 45

Contexto: [topics:92](#topics-92)
You are building a continuous deployment pipeline for a project stored in a Git source repository and want to ensure that code changes can be verified before deploying to production. What should you do?

**A.** Use Spinnaker to deploy builds to production using the red/black deployment strategy so that changes can easily be rolled back.

**B.** Use Spinnaker to deploy builds to production and run tests on production deployments.

**C.** Use Jenkins to build the staging branches and the master branch. Build and deploy changes to production for 10% of users before doing a complete rollout.

**D.** Use Jenkins to monitor tags in the repository. Deploy staging tags to a staging environment for testing. After testing, tag the repository for production and deploy that to the production environment.

**Respuesta de la fuente:** D

**Explicación:** The requirement is to verify changes *before* deploying to production. Option D describes a process where code is deployed to a staging environment for testing prior to the final production deployment, which directly satisfies this constraint.
Other options either deploy directly to production (A, B, C) or perform verification on live production traffic, failing the 'before' condition.

## Pregunta 46

Contexto: [topics:92](#topics-92)
You have an outage in your Compute Engine managed instance group: all instances keep restarting after 5 seconds. You have a health check configured, but autoscaling is disabled. Your colleague, who is a Linux expert, offered to look into the issue. You need to make sure that he can access the VMs. What should you do?

**A.** Grant your colleague the IAM role of project Viewer

**B.** Perform a rolling restart on the instance group

**C.** Disable the health check for the instance group. Add his SSH key to the project-wide SSH Keys

**D.** Disable autoscaling for the instance group. Add his SSH key to the project-wide SSH Keys

**Respuesta de la fuente:** C

**Explicación:** The instances are restarting because the health check is failing, which causes the managed instance group to terminate and recreate them, preventing any persistent SSH connection. Disabling the health check stops this automatic recreation cycle, allowing the VMs to remain running long enough for troubleshooting. Adding the colleague's SSH key to project-wide metadata grants the necessary OS-level access to log in to the instances.

## Pregunta 47

Contexto: [topics:92](#topics-92)
Your company is migrating its on-premises data center into the cloud. As part of the migration, you want to integrate Google Kubernetes Engine (GKE) for workload orchestration. Parts of your architecture must also be PCI DSS-compliant. Which of the following is most accurate?

**A.** App Engine is the only compute platform on GCP that is certified for PCI DSS hosting.

**B.** GKE cannot be used under PCI DSS because it is considered shared hosting.

**C.** GKE and GCP provide the tools you need to build a PCI DSS-compliant environment.

**D.** All Google Cloud services are usable because Google Cloud Platform is certified PCI-compliant.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because GCP operates under a shared responsibility model where Google secures the underlying infrastructure (including GKE), but the customer must configure security controls to meet PCI DSS requirements.
Options A and B are incorrect because GKE is not restricted from PCI DSS use, nor is App Engine the only certified platform.
Option D is inaccurate because GCP certification does not automatically render all services usable in a compliant environment without proper customer-side configuration.

## Pregunta 48

Contexto: [topics:92](#topics-92)
Your company has multiple on-premises systems that serve as sources for reporting. The data has not been maintained well and has become degraded over time.
You want to use Google-recommended practices to detect anomalies in your company data. What should you do?

**A.** Upload your files into Cloud Storage. Use Cloud Datalab to explore and clean your data.

**B.** Upload your files into Cloud Storage. Use Cloud Dataprep to explore and clean your data.

**C.** Connect Cloud Datalab to your on-premises systems. Use Cloud Datalab to explore and clean your data.

**D.** Connect Cloud Dataprep to your on-premises systems. Use Cloud Dataprep to explore and clean your data.

**Respuesta de la fuente:** B

**Explicación:** Cloud Dataprep is the Google-recommended tool for visually exploring, cleaning, and detecting anomalies in data due to its built-in profiling features.
Cloud Dataprep does not support direct connections to on-premises systems; it requires data to be ingested via supported sources like Cloud Storage first.
Therefore, uploading files to Cloud Storage before using Dataprep is the correct workflow, whereas options involving direct on-prem connectivity or Datalab (which lacks OOTB anomaly detection) are incorrect.

## Pregunta 49

Contexto: [topics:92](#topics-92)
Google Cloud Platform resources are managed hierarchically using organization, folders, and projects. When Cloud Identity and Access Management (IAM) policies exist at these different levels, what is the effective policy at a particular node of the hierarchy?

**A.** The effective policy is determined only by the policy set at the node

**B.** The effective policy is the policy set at the node and restricted by the policies of its ancestors

**C.** The effective policy is the union of the policy set at the node and policies inherited from its ancestors

**D.** The effective policy is the intersection of the policy set at the node and policies inherited from its ancestors

**Respuesta de la fuente:** C

**Explicación:** In Google Cloud IAM, resources inherit allow policies from their parent nodes in the hierarchy (Organization, Folder, Project).
The effective policy at a specific node is calculated as the union of the policies set directly on that node and all policies inherited from its ancestors.
This means permissions granted at higher levels are combined with local permissions, ensuring access is additive rather than restrictive.

## Pregunta 50

Contexto: [topics:92](#topics-92)
You are migrating your on-premises solution to Google Cloud in several phases. You will use Cloud VPN to maintain a connection between your on-premises systems and Google Cloud until the migration is completed. You want to make sure all your on-premise systems remain reachable during this period. How should you organize your networking in Google Cloud?

**A.** Use the same IP range on Google Cloud as you use on-premises

**B.** Use the same IP range on Google Cloud as you use on-premises for your primary IP range and use a secondary range that does not overlap with the range you use on-premises

**C.** Use an IP range on Google Cloud that does not overlap with the range you use on-premises

**D.** Use an IP range on Google Cloud that does not overlap with the range you use on-premises for your primary IP range and use a secondary range with the same IP range as you use on-premises

**Respuesta de la fuente:** C

**Explicación:** To establish a Cloud VPN connection between on-premises networks and Google Cloud, the IP address ranges must not overlap.
If primary or secondary subnets in the VPC share IP addresses with on-premises systems, routing ambiguity prevents proper connectivity.
Therefore, you must use an IP range on Google Cloud that is distinct from your on-premises network.

## Pregunta 51

Contexto: [topics:92](#topics-92)
You have found an error in your App Engine application caused by missing Cloud Datastore indexes. You have created a YAML file with the required indexes and want to deploy these new indexes to Cloud Datastore. What should you do?

**A.** Point gcloud datastore create-indexes to your configuration file

**B.** Upload the configuration file to App Engine's default Cloud Storage bucket, and have App Engine detect the new indexes

**C.** In the GCP Console, use Datastore Admin to delete the current indexes and upload the new configuration file

**D.** Create an HTTP request to the built-in python module to send the index configuration file to your application

**Respuesta de la fuente:** A

**Explicación:** To deploy new Cloud Datastore indexes defined in a YAML file, you must use the Google Cloud SDK command line tool.
The correct procedure is to run `gcloud datastore create-indexes` and point it to your local index configuration file (typically `index.yaml`).
This command explicitly instructs the service to build the specified composite indexes.

## Pregunta 52

Contexto: [topics:92](#topics-92)
You have an application that will run on Compute Engine. You need to design an architecture that takes into account a disaster recovery plan that requires your application to fail over to another region in case of a regional outage. What should you do?

**A.** Deploy the application on two Compute Engine instances in the same project but in a different region. Use the first instance to serve traffic, and use the HTTP load balancing service to fail over to the standby instance in case of a disaster.

**B.** Deploy the application on a Compute Engine instance. Use the instance to serve traffic, and use the HTTP load balancing service to fail over to an instance on your premises in case of a disaster.

**C.** Deploy the application on two Compute Engine instance groups, each in the same project but in a different region. Use the first instance group to serve traffic, and use the HTTP load balancing service to fail over to the standby instance group in case of a disaster.

**D.** Deploy the application on two Compute Engine instance groups, each in a separate project and a different region. Use the first instance group to serve traffic, and use the HTTP load balancing service to fail over to the standby instance group in case of a disaster.

**Respuesta de la fuente:** C

**Explicación:** HTTP Load Balancing in Google Cloud requires backend services to be configured with Instance Groups; you cannot attach individual Compute Engine instances directly to an external HTTP load balancer.
Therefore, options A and B are technically invalid because they attempt to use standalone instances as backends.
Option C is the correct architectural choice because it utilizes Managed Instance Groups (MIGs) in different regions within the same project, ensuring proper health checking, traffic routing, and consistent management for disaster recovery failover.

## Pregunta 53

Contexto: [topics:92](#topics-92)
You are deploying an application on App Engine that needs to integrate with an on-premises database. For security purposes, your on-premises database must not be accessible through the public internet. What should you do?

**A.** Deploy your application on App Engine standard environment and use App Engine firewall rules to limit access to the open on-premises database.

**B.** Deploy your application on App Engine standard environment and use Cloud VPN to limit access to the on-premises database.

**C.** Deploy your application on App Engine flexible environment and use App Engine firewall rules to limit access to the on-premises database.

**D.** Deploy your application on App Engine flexible environment and use Cloud VPN to limit access to the on-premises database.

**Respuesta de la fuente:** D

**Explicación:** App Engine Flexible environment instances run within the Compute Engine network, allowing direct connectivity to VPC resources such as Cloud VPN tunnels. This enables secure access to on-premises databases without exposing them to the public internet, which App Engine Standard (in the context of this legacy question) could not do directly.

## Pregunta 54

Contexto: [topics:92](#topics-92)
You are working in a highly secured environment where public Internet access from the Compute Engine VMs is not allowed. You do not yet have a VPN connection to access an on-premises file server. You need to install specific software on a Compute Engine instance. How should you install the software?

**A.** Upload the required installation files to Cloud Storage. Configure the VM on a subnet with a Private Google Access subnet. Assign only an internal IP address to the VM. Download the installation files to the VM using gsutil.

**B.** Upload the required installation files to Cloud Storage and use firewall rules to block all traffic except the IP address range for Cloud Storage. Download the files to the VM using gsutil.

**C.** Upload the required installation files to Cloud Source Repositories. Configure the VM on a subnet with a Private Google Access subnet. Assign only an internal IP address to the VM. Download the installation files to the VM using gcloud.

**D.** Upload the required installation files to Cloud Source Repositories and use firewall rules to block all traffic except the IP address range for Cloud Source Repositories. Download the files to the VM using gsutil.

**Respuesta de la fuente:** A

**Explicación:** The environment prohibits public Internet access, making Private Google Access the required mechanism for the VM to reach Cloud Storage via internal IP only.
Cloud Storage is designed for general file hosting and supports gsutil for transfers, whereas Cloud Source Repositories is a source control system unsuitable for binary installation files.

## Pregunta 55

Contexto: [topics:92](#topics-92)
Your company is moving 75 TB of data into Google Cloud. You want to use Cloud Storage and follow Google-recommended practices. What should you do?

**A.** Move your data onto a Transfer Appliance. Use a Transfer Appliance Rehydrator to decrypt the data into Cloud Storage.

**B.** Move your data onto a Transfer Appliance. Use Cloud Dataprep to decrypt the data into Cloud Storage.

**C.** Install gsutil on each server that contains data. Use resumable transfers to upload the data into Cloud Storage.

**D.** Install gsutil on each server containing data. Use streaming transfers to upload the data into Cloud Storage.

**Respuesta de la fuente:** A

**Explicación:** Google recommends the Transfer Appliance for offline transfers when the data volume is large (typically >10-20 TB) or when network transfer would take longer than a week, which applies to this 75 TB scenario.
The appliance hardware includes a built-in rehydrator process to decrypt and upload the data directly to Cloud Storage upon arrival at the Google datacenter.
Options using gsutil (C and D) are less efficient for this volume due to potential network latency and cost, while Cloud Dataprep (B) is an ETL tool, not a migration decryption utility.

## Pregunta 56

Contexto: [topics:92](#topics-92)
You have an application deployed on Google Kubernetes Engine using a Deployment named echo-deployment. The deployment is exposed using a Service called echo-service. You need to perform an update to the application with minimal downtime to the application. What should you do?

**A.** Use kubectl set image deployment/echo-deployment <new-image>

**B.** Use the rolling update functionality of the Instance Group behind the Kubernetes cluster

**C.** Update the deployment yaml file with the new container image. Use kubectl delete deployment/echo-deployment and kubectl create —f <yaml-file>

**D.** Update the service yaml file which the new container image. Use kubectl delete service/echo-service and kubectl create —f <yaml-file>

**Respuesta de la fuente:** A

**Explicación:** The `kubectl set image` command directly updates the container image in the Deployment specification, which automatically triggers a rolling update strategy.
This default strategy ensures that existing Pods remain available while new ones are created, resulting in minimal downtime as required by the scenario.

## Pregunta 57

Contexto: [topics:92](#topics-92)
Your company is using BigQuery as its enterprise data warehouse. Data is distributed over several Google Cloud projects. All queries on BigQuery need to be billed on a single project. You want to make sure that no query costs are incurred on the projects that contain the data. Users should be able to query the datasets, but not edit them.
How should you configure users' access roles?

**A.** Add all users to a group. Grant the group the role of BigQuery user on the billing project and BigQuery dataViewer on the projects that contain the data.

**B.** Add all users to a group. Grant the group the roles of BigQuery dataViewer on the billing project and BigQuery user on the projects that contain the data.

**C.** Add all users to a group. Grant the group the roles of BigQuery jobUser on the billing project and BigQuery dataViewer on the projects that contain the data.

**D.** Add all users to a group. Grant the group the roles of BigQuery dataViewer on the billing project and BigQuery jobUser on the projects that contain the data.

**Respuesta de la fuente:** C

**Explicación:** Assigning BigQuery jobUser to the billing project allows users to run queries billed to that project without granting unnecessary permissions to create or modify datasets.

Assigning BigQuery dataViewer to the data projects provides read-only access to the tables, ensuring users cannot edit the data.

This combination satisfies the requirements for centralized billing and least-privilege access.

## Pregunta 58

Contexto: [topics:92](#topics-92)
You have developed an application using Cloud ML Engine that recognizes famous paintings from uploaded images. You want to test the application and allow specific people to upload images for the next 24 hours. Not all users have a Google Account. How should you have users upload images?

**A.** Have users upload the images to Cloud Storage. Protect the bucket with a password that expires after 24 hours.

**B.** Have users upload the images to Cloud Storage using a signed URL that expires after 24 hours.

**C.** Create an App Engine web application where users can upload images. Configure App Engine to disable the application after 24 hours. Authenticate users via Cloud Identity.

**D.** Create an App Engine web application where users can upload images for the next 24 hours. Authenticate users via Cloud Identity.

**Respuesta de la fuente:** B

**Explicación:** Signed URLs provide temporary, authenticated access to Cloud Storage objects without requiring users to have Google Accounts or manage credentials. This fits the requirement for non-Google Account users and allows precise control via a 24-hour expiration timestamp.
Cloud Storage buckets do not support password protection with time-based expiration (Option A), making signed URLs the correct mechanism for secure, time-limited access.

## Pregunta 59

Contexto: [topics:92](#topics-92)
Your web application must comply with the requirements of the European Union's General Data Protection Regulation (GDPR). You are responsible for the technical architecture of your web application. What should you do?

**A.** Ensure that your web application only uses native features and services of Google Cloud Platform, because Google already has various certifications and provides "pass-on" compliance when you use native features.

**B.** Enable the relevant GDPR compliance setting within the GCPConsole for each of the services in use within your application.

**C.** Ensure that Cloud Security Scanner is part of your test planning strategy in order to pick up any compliance gaps.

**D.** Define a design for the security of data in your web application that meets GDPR requirements.

**Respuesta de la fuente:** D

**Explicación:** GDPR compliance is a shared responsibility; while GCP provides infrastructure security certifications, the customer must design their application architecture to meet specific data protection requirements like encryption and access controls.
Option D correctly identifies that defining a compliant data security design is the primary architectural task, whereas the other options are either insufficient alone or technically inaccurate.

## Pregunta 60

Contexto: [topics:92](#topics-92)
You need to set up Microsoft SQL Server on GCP. Management requires that there's no downtime in case of a data center outage in any of the zones within a
GCP region. What should you do?

**A.** Configure a Cloud SQL instance with high availability enabled.

**B.** Configure a Cloud Spanner instance with a regional instance configuration.

**C.** Set up SQL Server on Compute Engine, using Always On Availability Groups using Windows Failover Clustering. Place nodes in different subnets.

**D.** Set up SQL Server Always On Availability Groups using Windows Failover Clustering. Place nodes in different zones.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 61

Contexto: [topics:92](#topics-92)
The development team has provided you with a Kubernetes Deployment file. You have no infrastructure yet and need to deploy the application. What should you do?

**A.** Use gcloud to create a Kubernetes cluster. Use Deployment Manager to create the deployment.

**B.** Use gcloud to create a Kubernetes cluster. Use kubectl to create the deployment.

**C.** Use kubectl to create a Kubernetes cluster. Use Deployment Manager to create the deployment.

**D.** Use kubectl to create a Kubernetes cluster. Use kubectl to create the deployment.

**Respuesta de la fuente:** B

**Explicación:** In Google Cloud, the gcloud CLI is used to provision infrastructure resources like GKE clusters, whereas kubectl is the standard tool for interacting with Kubernetes APIs to create workloads such as Deployments.
Deployment Manager is for provisioning GCP resources and does not handle Kubernetes object creation directly, making option B the correct workflow.

## Pregunta 62

Contexto: [topics:92](#topics-92)
You need to evaluate your team readiness for a new GCP project. You must perform the evaluation and create a skills gap plan which incorporates the business goal of cost optimization. Your team has deployed two GCP projects successfully to date. What should you do?

**A.** Allocate budget for team training. Set a deadline for the new GCP project.

**B.** Allocate budget for team training. Create a roadmap for your team to achieve Google Cloud certification based on job role.

**C.** Allocate budget to hire skilled external consultants. Set a deadline for the new GCP project.

**D.** Allocate budget to hire skilled external consultants. Create a roadmap for your team to achieve Google Cloud certification based on job role.

**Respuesta de la fuente:** B

**Explicación:** The requirement to create a 'skills gap plan' necessitates a structured evaluation of current competencies against best practices.
Creating a roadmap for role-based certification provides this framework and ensures the team learns specific cost optimization techniques, whereas simply setting a deadline does not address skill deficiencies.

## Pregunta 63

Contexto: [topics:92](#topics-92)
You are designing an application for use only during business hours. For the minimum viable product release, you'd like to use a managed product that automatically `scales to zero` so you don't incur costs when there is no activity.
Which primary compute resource should you choose?

**A.** Cloud Functions

**B.** Compute Engine

**C.** Google Kubernetes Engine

**D.** AppEngine flexible environment

**Respuesta de la fuente:** A

**Explicación:** Cloud Functions is a fully managed serverless compute service that supports scaling to zero instances when there are no requests, eliminating costs during inactivity.
Compute Engine requires manual management or instance scheduling and does not scale to zero automatically by default.
Google Kubernetes Engine incurs control plane costs even if node pools scale down, as at least one node is typically required for system pods.
App Engine Flexible Environment maintains a minimum of one instance running at all times to reduce latency, preventing it from scaling to zero.

## Pregunta 64

Contexto: [topics:92](#topics-92)
You are creating an App Engine application that uses Cloud Datastore as its persistence layer. You need to retrieve several root entities for which you have the identifiers. You want to minimize the overhead in operations performed by Cloud Datastore. What should you do?

**A.** Create the Key object for each Entity and run a batch get operation

**B.** Create the Key object for each Entity and run multiple get operations, one operation for each entity

**C.** Use the identifiers to create a query filter and run a batch query operation

**D.** Use the identifiers to create a query filter and run multiple query operations, one operation for each entity

**Respuesta de la fuente:** A

**Explicación:** To minimize overhead when entity keys or identifiers are already known, you should use a batch get operation rather than queries.

Batching multiple lookups into a single API call significantly reduces network latency and server-side processing costs compared to individual get operations.

Using query filters (Options C and D) is inefficient here because the specific entities are already identified by key, making direct retrieval faster and cheaper than scanning indexes.

## Pregunta 65

Contexto: [topics:92](#topics-92)
You need to upload files from your on-premises environment to Cloud Storage. You want the files to be encrypted on Cloud Storage using customer-supplied encryption keys. What should you do?

**A.** Supply the encryption key in a .boto configuration file. Use gsutil to upload the files.

**B.** Supply the encryption key using gcloud config. Use gsutil to upload the files to that bucket.

**C.** Use gsutil to upload the files, and use the flag --encryption-key to supply the encryption key.

**D.** Use gsutil to create a bucket, and use the flag --encryption-key to supply the encryption key. Use gsutil to upload the files to that bucket.

**Respuesta de la fuente:** A

**Explicación:** To use Customer-Supplied Encryption Keys (CSEK) with gsutil, you must configure the encryption key in the .boto configuration file.
The --encryption-key flag is specific to the gcloud storage command and is not supported by gsutil, making Option C incorrect despite similar syntax.

## Pregunta 66

Contexto: [topics:92](#topics-92)
Your customer wants to capture multiple GBs of aggregate real-time key performance indicators (KPIs) from their game servers running on Google Cloud Platform and monitor the KPIs with low latency. How should they capture the KPIs?

**A.** Store time-series data from the game servers in Google Bigtable, and view it using Google Data Studio.

**B.** Output custom metrics to Stackdriver from the game servers, and create a Dashboard in Stackdriver Monitoring Console to view them.

**C.** Schedule BigQuery load jobs to ingest analytics files uploaded to Cloud Storage every ten minutes, and visualize the results in Google Data Studio.

**D.** Insert the KPIs into Cloud Datastore entities, and run ad hoc analysis and visualizations of them in Cloud Datalab.

**Respuesta de la fuente:** B

**Explicación:** The requirement for low-latency monitoring of real-time KPIs is best met by Stackdriver Monitoring (now Cloud Monitoring), which is purpose-built for collecting custom metrics and providing immediate visualization via dashboards.
Other options like BigQuery or Data Studio are designed for batch analytics or historical reporting, introducing latency that violates the real-time constraint.

## Pregunta 67

Contexto: [topics:92](#topics-92)
You have a Python web application with many dependencies that requires 0.1 CPU cores and 128 MB of memory to operate in production. You want to monitor and maximize machine utilization. You also want to reliably deploy new versions of the application. Which set of steps should you take?

**A.** Perform the following: 1. Create a managed instance group with f1-micro type machines. 2. Use a startup script to clone the repository, check out the production branch, install the dependencies, and start the Python app. 3. Restart the instances to automatically deploy new production releases.

**B.** Perform the following: 1. Create a managed instance group with n1-standard-1 type machines. 2. Build a Compute Engine image from the production branch that contains all of the dependencies and automatically starts the Python app. 3. Rebuild the Compute Engine image, and update the instance template to deploy new production releases.

**C.** Perform the following: 1. Create a Google Kubernetes Engine (GKE) cluster with n1-standard-1 type machines. 2. Build a Docker image from the production branch with all of the dependencies, and tag it with the version number. 3. Create a Kubernetes Deployment with the imagePullPolicy set to 'IfNotPresent' in the staging namespace, and then promote it to the production namespace after testing.

**D.** Perform the following: 1. Create a GKE cluster with n1-standard-4 type machines. 2. Build a Docker image from the master branch with all of the dependencies, and tag it with 'latest'. 3. Create a Kubernetes Deployment in the default namespace with the imagePullPolicy set to 'Always'. Restart the pods to automatically deploy new production releases.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google Kubernetes Engine (GKE) allows precise resource specification via container limits (0.1 CPU, 128 MB), maximizing machine utilization by packing multiple pods onto nodes, unlike rigid VM instance types.
Using semantic versioning for Docker images ensures reliable deployments and reproducibility, whereas using 'latest' tags or startup scripts is less stable.
Staging in a separate namespace before promotion provides a safe testing environment, aligning with best practices for reliable release management.

## Pregunta 68

Contexto: [topics:92](#topics-92)
Your company wants to start using Google Cloud resources but wants to retain their on-premises Active Directory domain controller for identity management.
What should you do?

**A.** Use the Admin Directory API to authenticate against the Active Directory domain controller.

**B.** Use Google Cloud Directory Sync to synchronize Active Directory usernames with cloud identities and configure SAML SSO.

**C.** Use Cloud Identity-Aware Proxy configured to use the on-premises Active Directory domain controller as an identity provider.

**D.** Use Compute Engine to create an Active Directory (AD) domain controller that is a replica of the on-premises AD domain controller using Google Cloud Directory Sync.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Directory Sync (GCDS) is the recommended tool for synchronizing on-premises Active Directory identities with Google Workspace or Cloud Identity accounts.
By combining GCDS with SAML Single Sign-On (SSO), the organization retains its AD as the source of truth while allowing users to authenticate seamlessly against Google Cloud resources without duplicating directory infrastructure.

## Pregunta 69

Contexto: [topics:92](#topics-92)
You are running a cluster on Kubernetes Engine (GKE) to serve a web application. Users are reporting that a specific part of the application is not responding anymore. You notice that all pods of your deployment keep restarting after 2 seconds. The application writes logs to standard output. You want to inspect the logs to find the cause of the issue. Which approach can you take?

**A.** Review the Stackdriver logs for each Compute Engine instance that is serving as a node in the cluster.

**B.** Review the Stackdriver logs for the specific GKE container that is serving the unresponsive part of the application.

**C.** Connect to the cluster using gcloud credentials and connect to a container in one of the pods to read the logs.

**D.** Review the Serial Port logs for each Compute Engine instance that is serving as a node in the cluster.

**Respuesta de la fuente:** B

**Explicación:** GKE automatically collects container standard output and error logs via the per-node logging agent, making them available in Cloud Logging (formerly Stackdriver) without requiring node-level SSH access.
Since the pods are restarting rapidly (every 2 seconds), attempting to exec into a running container (Option C) is impractical and often impossible due to the short lifecycle.
Cloud Logging aggregates these logs centrally, allowing you to inspect the specific container's output to identify the crash cause efficiently.

## Pregunta 70

Contexto: [topics:92](#topics-92)
You are using a single Cloud SQL instance to serve your application from a specific zone. You want to introduce high availability. What should you do?

**A.** Create a read replica instance in a different region

**B.** Create a failover replica instance in a different region

**C.** Create a read replica instance in the same region, but in a different zone

**D.** Create a failover replica instance in the same region, but in a different zone

**Respuesta de la fuente:** D

**Explicación:** High Availability in Cloud SQL requires data redundancy across zones within a single region to handle zone-level failures. Read replicas are designed for read scaling and do not provide automatic failover capabilities for high availability. Therefore, you must configure a failover replica in the same region but a different zone to ensure the instance can automatically switch over if the primary zone becomes unavailable.

## Pregunta 71

Contexto: [topics:92](#topics-92)
Your company is running a stateless application on a Compute Engine instance. The application is used heavily during regular business hours and lightly outside of business hours. Users are reporting that the application is slow during peak hours. You need to optimize the application's performance. What should you do?

**A.** Create a snapshot of the existing disk. Create an instance template from the snapshot. Create an autoscaled managed instance group from the instance template.

**B.** Create a snapshot of the existing disk. Create a custom image from the snapshot. Create an autoscaled managed instance group from the custom image.

**C.** Create a custom image from the existing disk. Create an instance template from the custom image. Create an autoscaled managed instance group from the instance template.

**D.** Create an instance template from the existing disk. Create a custom image from the instance template. Create an autoscaled managed instance group from the custom image.

**Respuesta de la fuente:** C

**Explicación:** To autoscale a stateless application on Google Cloud, you must create an autoscaled managed instance group (MIG), which requires an instance template as its source. An instance template defines the properties for new VMs, including the boot disk image, so it cannot be created directly from a snapshot or a raw disk; it must reference a custom image. Therefore, the correct workflow is to first create a custom image from the existing instance's disk, then define an instance template using that image, and finally configure the autoscaled MIG from the template.

## Pregunta 72

Contexto: [topics:92](#topics-92)
Your web application has several VM instances running within a VPC. You want to restrict communications between instances to only the paths and ports you authorize, but you don't want to rely on static IP addresses or subnets because the app can autoscale. How should you restrict communications?

**A.** Use separate VPCs to restrict traffic

**B.** Use firewall rules based on network tags attached to the compute instances

**C.** Use Cloud DNS and only allow connections from authorized hostnames

**D.** Use service accounts and configure the web application to authorize particular service accounts to have access

**Respuesta de la fuente:** B

**Explicación:** Firewall rules are the only mechanism listed that can restrict traffic based on specific ports and protocols within a VPC.
Using network tags allows you to target instances dynamically by their function or role rather than static IP addresses, which is essential for autoscaling environments where IPs change frequently.

## Pregunta 73

Contexto: [topics:92](#topics-92)
You are using Cloud SQL as the database backend for a large CRM deployment. You want to scale as usage increases and ensure that you don't run out of storage, maintain 75% CPU usage cores, and keep replication lag below 60 seconds. What are the correct steps to meet your requirements?

**A.** 1. Enable automatic storage increase for the instance. 2. Create a Stackdriver alert when CPU usage exceeds 75%, and change the instance type to reduce CPU usage. 3. Create a Stackdriver alert for replication lag, and shard the database to reduce replication time.

**B.** 1. Enable automatic storage increase for the instance. 2. Change the instance type to a 32-core machine type to keep CPU usage below 75%. 3. Create a Stackdriver alert for replication lag, and deploy memcache to reduce load on the master.

**C.** 1. Create a Stackdriver alert when storage exceeds 75%, and increase the available storage on the instance to create more space. 2. Deploy memcached to reduce CPU load. 3. Change the instance type to a 32-core machine type to reduce replication lag.

**D.** 1. Create a Stackdriver alert when storage exceeds 75%, and increase the available storage on the instance to create more space. 2. Deploy memcached to reduce CPU load. 3. Create a Stackdriver alert for replication lag, and change the instance type to a 32-core machine type to reduce replication lag.

**Respuesta de la fuente:** A

**Explicación:** The requirement is to maintain CPU usage *at* 75%, not below it by arbitrary means; enabling auto-storage growth ensures you don't run out of space.
Option A correctly addresses storage via automatic increase, monitors CPU with alerts to trigger instance type changes if usage exceeds the target, and addresses replication lag through sharding, which is a standard scaling strategy for write-heavy workloads to reduce master load and lag.
Other options incorrectly focus on storage thresholds (75% storage vs 75% CPU) or suggest fixed machine types without monitoring logic.

## Pregunta 74

Contexto: [topics:92](#topics-92)
You are tasked with building an online analytical processing (OLAP) marketing analytics and reporting tool. This requires a relational database that can operate on hundreds of terabytes of data. What is the Google-recommended tool for such applications?

**A.** Cloud Spanner, because it is globally distributed

**B.** Cloud SQL, because it is a fully managed relational database

**C.** Cloud Firestore, because it offers real-time synchronization across devices

**D.** BigQuery, because it is designed for large-scale processing of tabular data

**Respuesta de la fuente:** D

**Explicación:** BigQuery is Google's serverless data warehouse designed specifically for large-scale OLAP analytics and reporting on petabytes of tabular data. While Cloud Spanner is a relational database, it is optimized for online transaction processing (OLTP) rather than the heavy analytical queries described in the scenario.

## Pregunta 75

Contexto: [topics:92](#topics-92)
You have deployed an application to Google Kubernetes Engine (GKE), and are using the Cloud SQL proxy container to make the Cloud SQL database available to the services running on Kubernetes. You are notified that the application is reporting database connection issues. Your company policies require a post- mortem. What should you do?

**A.** Use gcloud sql instances restart.

**B.** Validate that the Service Account used by the Cloud SQL proxy container still has the Cloud Build Editor role.

**C.** In the GCP Console, navigate to Stackdriver Logging. Consult logs for (GKE) and Cloud SQL.

**D.** In the GCP Console, navigate to Cloud SQL. Restore the latest backup. Use kubectl to restart all pods.

**Respuesta de la fuente:** C

**Explicación:** The question specifically requires conducting a post-mortem to investigate connection issues, which necessitates analyzing historical data to determine the root cause. Consulting Stackdriver Logging (now Cloud Logging) for both GKE and Cloud SQL provides the necessary diagnostic details regarding connectivity failures.
Other options like restarting instances or restoring backups are remediation actions rather than investigative steps, and checking for Cloud Build Editor roles is irrelevant since the proxy requires Cloud SQL Client permissions, not build capabilities.

## Pregunta 76

Contexto: [topics:92](#topics-92)
Your company pushes batches of sensitive transaction data from its application server VMs to Cloud Pub/Sub for processing and storage. What is the Google- recommended way for your application to authenticate to the required Google Cloud services?

**A.** Ensure that VM service accounts are granted the appropriate Cloud Pub/Sub IAM roles.

**B.** Ensure that VM service accounts do not have access to Cloud Pub/Sub, and use VM access scopes to grant the appropriate Cloud Pub/Sub IAM roles.

**C.** Generate an OAuth2 access token for accessing Cloud Pub/Sub, encrypt it, and store it in Cloud Storage for access from each VM.

**D.** Create a gateway to Cloud Pub/Sub using a Cloud Function, and grant the Cloud Function service account the appropriate Cloud Pub/Sub IAM roles.

**Respuesta de la fuente:** A

**Explicación:** Google recommends using Compute Engine service accounts for applications running on VMs to authenticate with Cloud services, as they provide automatic credential management without manual key handling. By granting the appropriate Cloud Pub/Sub IAM roles directly to these service accounts, you follow the principle of least privilege while ensuring secure, seamless API access.

## Pregunta 77

Contexto: [topics:92](#topics-92)
You want to establish a Compute Engine application in a single VPC across two regions. The application must communicate over VPN to an on-premises network.
How should you deploy the VPN?

**A.** Use VPC Network Peering between the VPC and the on-premises network.

**B.** Expose the VPC to the on-premises network using IAM and VPC Sharing.

**C.** Create a global Cloud VPN Gateway with VPN tunnels from each region to the on-premises peer gateway.

**D.** Deploy Cloud VPN Gateway in each region. Ensure that each region has at least one VPN tunnel to the on-premises peer gateway.

**Respuesta de la fuente:** D

**Explicación:** The correct answer is D because Cloud VPN gateways are regional resources, not global ones, meaning a single gateway cannot span multiple regions directly as implied in option C. To ensure high availability and proper routing for an application deployed across two regions to an on-premises network, you must deploy Cloud VPN gateways in each region with corresponding tunnels.

## Pregunta 78

Contexto: [topics:92](#topics-92)
Your applications will be writing their logs to BigQuery for analysis. Each application should have its own table. Any logs older than 45 days should be removed.
You want to optimize storage and follow Google-recommended practices. What should you do?

**A.** Configure the expiration time for your tables at 45 days

**B.** Make the tables time-partitioned, and configure the partition expiration at 45 days

**C.** Rely on BigQuery's default behavior to prune application logs older than 45 days

**D.** Create a script that uses the BigQuery command line tool (bq) to remove records older than 45 days

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it uses partition expiration to delete only the specific data partitions older than 45 days while preserving the table structure and newer data.
In contrast, Option A sets a table expiration, which would delete the entire table (and all its data) after 45 days, causing loss of recent logs.
BigQuery does not automatically prune old records by default (Option C), and using a script (Option D) is less efficient and not a recommended best practice compared to native partition management.

## Pregunta 79

Contexto: [topics:92](#topics-92)
You want your Google Kubernetes Engine cluster to automatically add or remove nodes based on CPU load.
What should you do?

**A.** Configure a HorizontalPodAutoscaler with a target CPU usage. Enable the Cluster Autoscaler from the GCP Console.

**B.** Configure a HorizontalPodAutoscaler with a target CPU usage. Enable autoscaling on the managed instance group for the cluster using the gcloud command.

**C.** Create a deployment and set the maxUnavailable and maxSurge properties. Enable the Cluster Autoscaler using the gcloud command.

**D.** Create a deployment and set the maxUnavailable and maxSurge properties. Enable autoscaling on the cluster managed instance group from the GCP Console.

**Respuesta de la fuente:** A

**Explicación:** The Cluster Autoscaler scales the node pool by monitoring pending pods that cannot be scheduled due to resource constraints. A HorizontalPodAutoscaler (HPA) triggers this process by increasing the number of pod replicas in response to high CPU load, creating scheduling pressure. When nodes are insufficient for these new pods, the Cluster Autoscaler adds nodes; conversely, it removes underutilized nodes when the HPA scales down replicas. Options B and D incorrectly suggest using Compute Engine autoscaling, which must not be used for GKE node groups.

## Pregunta 80

Contexto: [topics:92](#topics-92)
You need to develop procedures to verify resilience of disaster recovery for remote recovery using GCP. Your production environment is hosted on-premises. You need to establish a secure, redundant connection between your on-premises network and the GCP network.
What should you do?

**A.** Verify that Dedicated Interconnect can replicate files to GCP. Verify that direct peering can establish a secure connection between your networks if Dedicated Interconnect fails.

**B.** Verify that Dedicated Interconnect can replicate files to GCP. Verify that Cloud VPN can establish a secure connection between your networks if Dedicated Interconnect fails.

**C.** Verify that the Transfer Appliance can replicate files to GCP. Verify that direct peering can establish a secure connection between your networks if the Transfer Appliance fails.

**D.** Verify that the Transfer Appliance can replicate files to GCP. Verify that Cloud VPN can establish a secure connection between your networks if the Transfer Appliance fails.

**Respuesta de la fuente:** B

**Explicación:** Dedicated Interconnect provides a high-performance, private connection suitable for disaster recovery replication, while the Transfer Appliance is only for one-time bulk data migration and cannot serve as an active network link. Cloud VPN serves as the appropriate redundant failover because it establishes a secure IPSec tunnel over the public internet, whereas Direct Peering does not provide end-to-end encryption and is designed for Google services access rather than private VPC extension.

## Pregunta 81

Contexto: [topics:92](#topics-92)
Your company operates nationally and plans to use GCP for multiple batch workloads, including some that are not time-critical. You also need to use GCP services that are HIPAA-certified and manage service costs.
How should you design to meet Google best practices?

**A.** Provision preemptible VMs to reduce cost. Discontinue use of all GCP services and APIs that are not HIPAA-compliant.

**B.** Provision preemptible VMs to reduce cost. Disable and then discontinue use of all GCP services and APIs that are not HIPAA-compliant.

**C.** Provision standard VMs in the same region to reduce cost. Discontinue use of all GCP services and APIs that are not HIPAA-compliant.

**D.** Provision standard VMs to the same region to reduce cost. Disable and then discontinue use of all GCP services and APIs that are not HIPAA-compliant.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 82

Contexto: [topics:92](#topics-92)
Your customer wants to do resilience testing of their authentication layer. This consists of a regional managed instance group serving a public REST API that reads from and writes to a Cloud SQL instance.
What should you do?

**A.** Engage with a security company to run web scrapers that look your for users' authentication data om malicious websites and notify you if any is found.

**B.** Deploy intrusion detection software to your virtual machines to detect and log unauthorized access.

**C.** Schedule a disaster simulation exercise during which you can shut off all VMs in a zone to see how your application behaves.

**D.** Configure a read replica for your Cloud SQL instance in a different zone than the master, and then manually trigger a failover while monitoring KPIs for our REST API.

**Respuesta de la fuente:** C

**Explicación:** Resilience testing validates that an application continues to function during component failures. Option C describes chaos engineering, specifically simulating a zone-level outage to verify the Regional MIG's fault tolerance and automatic self-healing capabilities.

Option D is incorrect because standard read replicas do not support automatic failover; they must be manually promoted, which does not test the system's ability to withstand unexpected failures autonomously.

## Pregunta 83

Contexto: [topics:92](#topics-92)
Your BigQuery project has several users. For audit purposes, you need to see how many queries each user ran in the last month. What should you do?

**A.** Connect Google Data Studio to BigQuery. Create a dimension for the users and a metric for the amount of queries per user.

**B.** In the BigQuery interface, execute a query on the JOBS table to get the required information.

**C.** Use 'bq show' to list all jobs. Per job, use 'bq ls' to list job information and get the required information.

**D.** Use Cloud Audit Logging to view Cloud Audit Logs, and create a filter on the query operation to get the required information.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 84

Contexto: [topics:92](#topics-92)
You want to automate the creation of a managed instance group. The VMs have many OS package dependencies. You want to minimize the startup time for new
VMs in the instance group.
What should you do?

**A.** Use Terraform to create the managed instance group and a startup script to install the OS package dependencies.

**B.** Create a custom VM image with all OS package dependencies. Use Deployment Manager to create the managed instance group with the VM image.

**C.** Use Puppet to create the managed instance group and install the OS package dependencies.

**D.** Use Deployment Manager to create the managed instance group and Ansible to install the OS package dependencies.

**Respuesta de la fuente:** B

**Explicación:** To minimize startup time, you should use a custom VM image with pre-installed OS package dependencies.
This approach eliminates the need to download and install packages during boot, which significantly reduces initialization latency compared to using startup scripts or configuration management tools like Puppet, Ansible, or Terraform post-boot.

## Pregunta 85

Contexto: [topics:92](#topics-92)
Your company captures all web traffic data in Google Analytics 360 and stores it in BigQuery. Each country has its own dataset. Each dataset has multiple tables.
You want analysts from each country to be able to see and query only the data for their respective countries.
How should you configure the access rights?

**A.** Create a group per country. Add analysts to their respective country-groups. Create a single group 'all_analysts', and add all country-groups as members. Grant the 'all_analysts' group the IAM role of BigQuery jobUser. Share the appropriate dataset with view access with each respective analyst country-group.

**B.** Create a group per country. Add analysts to their respective country-groups. Create a single group 'all_analysts', and add all country-groups as members. Grant the 'all_analysts' group the IAM role of BigQuery jobUser. Share the appropriate tables with view access with each respective analyst country-group.

**C.** Create a group per country. Add analysts to their respective country-groups. Create a single group 'all_analysts', and add all country-groups as members. Grant the 'all_analysts' group the IAM role of BigQuery dataViewer. Share the appropriate dataset with view access with each respective analyst country- group.

**D.** Create a group per country. Add analysts to their respective country-groups. Create a single group 'all_analysts', and add all country-groups as members. Grant the 'all_analysts' group the IAM role of BigQuery dataViewer. Share the appropriate table with view access with each respective analyst country-group.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because the BigQuery JobUser role (applied at the project level) grants the necessary permissions to run queries without allowing users to list or see datasets they don't have explicit access to. By sharing specific datasets with View Access to respective country groups, analysts can only query and view data within their authorized scopes, adhering to the principle of least privilege.

In contrast, granting the DataViewer role (as in Option C) typically allows users to list tables and view metadata for all accessible resources, which violates the requirement that analysts should not see data from other countries.

## Pregunta 86

Contexto: [topics:92](#topics-92)
You have been engaged by your client to lead the migration of their application infrastructure to GCP. One of their current problems is that the on-premises high performance SAN is requiring frequent and expensive upgrades to keep up with the variety of workloads that are identified as follows: 20 TB of log archives retained for legal reasons; 500 GB of VM boot/data volumes and templates; 500 GB of image thumbnails; 200 GB of customer session state data that allows customers to restart sessions even if off-line for several days.
Which of the following best reflects your recommendations for a cost-effective storage allocation?

**A.** Local SSD for customer session state data. Lifecycle-managed Cloud Storage for log archives, thumbnails, and VM boot/data volumes.

**B.** Memcache backed by Cloud Datastore for the customer session state data. Lifecycle-managed Cloud Storage for log archives, thumbnails, and VM boot/data volumes.

**C.** Memcache backed by Cloud SQL for customer session state data. Assorted local SSD-backed instances for VM boot/data volumes. Cloud Storage for log archives and thumbnails.

**D.** Memcache backed by Persistent Disk SSD storage for customer session state data. Assorted local SSD-backed instances for VM boot/data volumes. Cloud Storage for log archives and thumbnails.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 87

Contexto: [topics:92](#topics-92)
Your web application uses Google Kubernetes Engine to manage several workloads. One workload requires a consistent set of hostnames even after pod scaling and relaunches.
Which feature of Kubernetes should you use to accomplish this?

**A.** StatefulSets

**B.** Role-based access control

**C.** Container environment variables

**D.** Persistent Volumes

**Respuesta de la fuente:** A

**Explicación:** StatefulSets are the Kubernetes workload controller designed for stateful applications that require stable, unique network identifiers.
Unlike Deployments or ReplicaSets, StatefulSets ensure that each pod maintains a consistent hostname (e.g., web-0, web-1) even after scaling, rescheduling, or relaunching.
This stability is critical for distributed systems and databases where service discovery relies on predictable naming conventions.

## Pregunta 88

Contexto: [topics:92](#topics-92)
You are using Cloud CDN to deliver static HTTP(S) website content hosted on a Compute Engine instance group. You want to improve the cache hit ratio.
What should you do?

**A.** Customize the cache keys to omit the protocol from the key.

**B.** Shorten the expiration time of the cached objects.

**C.** Make sure the HTTP(S) header "Cache-Region" points to the closest region of your users.

**D.** Replicate the static content in a Cloud Storage bucket. Point CloudCDN toward a load balancer on that bucket.

**Respuesta de la fuente:** A

**Explicación:** By default, Cloud CDN includes the protocol (HTTP vs HTTPS) in the cache key, treating requests with different protocols as distinct objects. Customizing the cache key to omit the protocol consolidates these entries, allowing HTTP and HTTPS requests for the same content to share a single cached object, thereby increasing the hit ratio.

## Pregunta 89

Contexto: [topics:92](#topics-92)
Your architecture calls for the centralized collection of all admin activity and VM system logs within your project.
How should you collect these logs from both VMs and services?

**A.** All admin and VM system logs are automatically collected by Stackdriver.

**B.** Stackdriver automatically collects admin activity logs for most services. The Stackdriver Logging agent must be installed on each instance to collect system logs.

**C.** Launch a custom syslogd compute instance and configure your GCP project and VMs to forward all logs to it.

**D.** Install the Stackdriver Logging agent on a single compute instance and let it collect all audit and access logs for your environment.

**Respuesta de la fuente:** B

**Explicación:** In Google Cloud Platform (now Stackdriver/Cloud Logging), audit and admin activity logs are collected automatically for most services without additional configuration. However, system logs from Compute Engine VMs require the installation of the logging agent to be forwarded and centralized.
Therefore, option B correctly describes this hybrid approach, whereas A is incorrect because it claims VM system logs are automatic.

## Pregunta 90

Contexto: [topics:92](#topics-92)
You have an App Engine application that needs to be updated. You want to test the update with production traffic before replacing the current application version.
What should you do?

**A.** Deploy the update using the Instance Group Updater to create a partial rollout, which allows for canary testing.

**B.** Deploy the update as a new version in the App Engine application, and split traffic between the new and current versions.

**C.** Deploy the update in a new VPC, and use Google's global HTTP load balancing to split traffic between the update and current applications.

**D.** Deploy the update as a new App Engine application, and use Google's global HTTP load balancing to split traffic between the new and current applications.

**Respuesta de la fuente:** B

**Explicación:** App Engine natively supports multi-version deployments, allowing you to deploy updates as new versions within the same service. You can then use App Engine's built-in traffic splitting feature to route a specific percentage of production traffic to the new version for testing (canary or A/B testing) without requiring external load balancers.

## Pregunta 91

Contexto: [topics:92](#topics-92)
All Compute Engine instances in your VPC should be able to connect to an Active Directory server on specific ports. Any other traffic emerging from your instances is not allowed. You want to enforce this using VPC firewall rules.
How should you configure the firewall rules?

**A.** Create an egress rule with priority 1000 to deny all traffic for all instances. Create another egress rule with priority 100 to allow the Active Directory traffic for all instances.

**B.** Create an egress rule with priority 100 to deny all traffic for all instances. Create another egress rule with priority 1000 to allow the Active Directory traffic for all instances.

**C.** Create an egress rule with priority 1000 to allow the Active Directory traffic. Rely on the implied deny egress rule with priority 100 to block all traffic for all instances.

**D.** Create an egress rule with priority 100 to allow the Active Directory traffic. Rely on the implied deny egress rule with priority 1000 to block all traffic for all instances.

**Respuesta de la fuente:** A

**Explicación:** By default, GCP VPCs have an implied egress rule that allows all outbound traffic. To enforce a restrictive policy, you must first create an explicit deny-all egress rule with a lower priority (e.g., 1000) to override this default allow behavior.
Then, create a more specific allow rule for Active Directory traffic with a higher priority (lower number, e.g., 100) to permit only the required connections.
Options C and D are incorrect because there is no implied deny-all egress rule in GCP.

## Pregunta 92

Contexto: [topics:92](#topics-92)
Your customer runs a web service used by e-commerce sites to offer product recommendations to users. The company has begun experimenting with a machine learning model on Google Cloud Platform to improve the quality of results.
What should the customer do to improve their model's results over time?

**A.** Export Cloud Machine Learning Engine performance metrics from Stackdriver to BigQuery, to be used to analyze the efficiency of the model.

**B.** Build a roadmap to move the machine learning model training from Cloud GPUs to Cloud TPUs, which offer better results.

**C.** Monitor Compute Engine announcements for availability of newer CPU architectures, and deploy the model to them as soon as they are available for additional performance.

**D.** Save a history of recommendations and results of the recommendations in BigQuery, to be used as training data.

**Respuesta de la fuente:** D

**Explicación:** To improve a machine learning model's results over time, the model must be retrained with new data that reflects actual user interactions and outcomes. Option D describes capturing recommendation history and user feedback to build a feedback loop for future training, which directly enhances prediction accuracy. Options A, B, and C focus on infrastructure performance metrics or hardware acceleration, which affect speed but not the predictive quality of the model.

## Pregunta 93

Contexto: [topics:92](#topics-92)
A development team at your company has created a dockerized HTTPS web application. You need to deploy the application on Google Kubernetes Engine (GKE) and make sure that the application scales automatically.
How should you deploy to GKE?

**A.** Use the Horizontal Pod Autoscaler and enable cluster autoscaling. Use an Ingress resource to load-balance the HTTPS traffic.

**B.** Use the Horizontal Pod Autoscaler and enable cluster autoscaling on the Kubernetes cluster. Use a Service resource of type LoadBalancer to load-balance the HTTPS traffic.

**C.** Enable autoscaling on the Compute Engine instance group. Use an Ingress resource to load-balance the HTTPS traffic.

**D.** Enable autoscaling on the Compute Engine instance group. Use a Service resource of type LoadBalancer to load-balance the HTTPS traffic.

**Respuesta de la fuente:** A

**Explicación:** Answer A is correct because the Horizontal Pod Autoscaler and cluster autoscaling handle automatic scaling requirements.
Since the application is HTTPS (Layer 7), an Ingress resource is required to configure HTTP(S) load balancing, whereas a standard Service of type LoadBalancer provisioned on GKE creates a Network Load Balancer (Layer 4) which does not natively terminate TLS for HTTP/HTTPS routing without additional configuration.

## Pregunta 94

Contexto: [topics:92](#topics-92)
You need to design a solution for global load balancing based on the URL path being requested. You need to ensure operations reliability and end-to-end in- transit encryption based on Google best practices.
What should you do?

**A.** Create a cross-region load balancer with URL Maps.

**B.** Create an HTTPS load balancer with URL Maps.

**C.** Create appropriate instance groups and instances. Configure SSL proxy load balancing.

**D.** Create a global forwarding rule. Configure SSL proxy load balancing.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud HTTP(S) Load Balancing is inherently global and supports URL maps for routing traffic based on host and path rules. SSL Proxy load balancing does not support URL-based routing, making it unsuitable for this requirement despite its encryption capabilities.

## Pregunta 95

Contexto: [topics:92](#topics-92)
You have an application that makes HTTP requests to Cloud Storage. Occasionally the requests fail with HTTP status codes of 5xx and 429.
How should you handle these types of errors?

**A.** Use gRPC instead of HTTP for better performance.

**B.** Implement retry logic using a truncated exponential backoff strategy.

**C.** Make sure the Cloud Storage bucket is multi-regional for geo-redundancy.

**D.** Monitor https://status.cloud.google.com/feed.atom and only make requests if Cloud Storage is not reporting an incident.

**Respuesta de la fuente:** B

**Explicación:** HTTP 5xx errors indicate server-side failures, while 429 errors signify rate limiting; both are typically transient conditions that resolve over time.
Implementing truncated exponential backoff is the recommended best practice because it automatically retries failed requests with increasing delays, preventing service overload and improving request success rates.
Other options like switching protocols (A), changing bucket topology (C), or manual status monitoring (D) do not address the dynamic handling of transient errors at the application level.

## Pregunta 96

Contexto: [topics:92](#topics-92)
You need to develop procedures to test a disaster plan for a mission-critical application. You want to use Google-recommended practices and native capabilities within GCP.
What should you do?

**A.** Use Deployment Manager to automate service provisioning. Use Activity Logs to monitor and debug your tests.

**B.** Use Deployment Manager to automate service provisioning. Use Stackdriver to monitor and debug your tests.

**C.** Use gcloud scripts to automate service provisioning. Use Activity Logs to monitor and debug your tests.

**D.** Use gcloud scripts to automate service provisioning. Use Stackdriver to monitor and debug your tests.

**Respuesta de la fuente:** B

**Explicación:** Google recommends using Deployment Manager for Infrastructure as Code (IaC) to automate service provisioning in disaster recovery plans, ensuring reproducibility and consistency over manual scripts. Additionally, Cloud Logging (formerly Stackdriver Logs), referred to here as 'Activity Logs' or part of the broader Stackdriver suite which was the recommended monitoring/debugging suite at the time of this question's origin, is the native tool for observing system health. However, specific Google documentation for DR testing highlights using Deployment Manager for automation and relying on native monitoring tools; among the choices, Option B aligns with the historical context where 'Stackdriver' was the branded name for the comprehensive monitoring/debugging suite recommended for such tasks, while 'Activity Logs' is a subset. Note: In current terminology, Stackdriver Monitoring/Logging is simply Cloud Operations, but within the context of this specific exam question's era and phrasing, B is the intended answer.

## Pregunta 97

Contexto: [topics:92](#topics-92)
Your company creates rendering software which users can download from the company website. Your company has customers all over the world. You want to minimize latency for all your customers. You want to follow Google-recommended practices.
How should you store the files?

**A.** Save the files in a Multi-Regional Cloud Storage bucket.

**B.** Save the files in a Regional Cloud Storage bucket, one bucket per zone of the region.

**C.** Save the files in multiple Regional Cloud Storage buckets, one bucket per zone per region.

**D.** Save the files in multiple Multi-Regional Cloud Storage buckets, one bucket per multi-region.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 98

Contexto: [topics:92](#topics-92)
Your company acquired a healthcare startup and must retain its customers' medical information for up to 4 more years, depending on when it was created. Your corporate policy is to securely retain this data, and then delete it as soon as regulations allow.
Which approach should you take?

**A.** Store the data in Google Drive and manually delete records as they expire.

**B.** Anonymize the data using the Cloud Data Loss Prevention API and store it indefinitely.

**C.** Store the data in Cloud Storage and use lifecycle management to delete files when they expire.

**D.** Store the data in Cloud Storage and run a nightly batch script that deletes all expired data.

**Respuesta de la fuente:** C

**Explicación:** Cloud Storage lifecycle management provides an automated, serverless mechanism to delete objects based on specific conditions like age or custom time, ensuring data is purged immediately upon expiration without manual intervention. This aligns with the requirement for secure retention followed by timely deletion, whereas manual processes (A) are error-prone and indefinite storage (B) violates the deletion mandate.

## Pregunta 99

Contexto: [topics:92](#topics-92)
You are deploying a PHP App Engine Standard service with Cloud SQL as the backend. You want to minimize the number of queries to the database.
What should you do?

**A.** Set the memcache service level to dedicated. Create a key from the hash of the query, and return database values from memcache before issuing a query to Cloud SQL.

**B.** Set the memcache service level to dedicated. Create a cron task that runs every minute to populate the cache with keys containing query results.

**C.** Set the memcache service level to shared. Create a cron task that runs every minute to save all expected queries to a key called "cached_queries".

**D.** Set the memcache service level to shared. Create a key called "cached_queries", and return database values from the key before using a query to Cloud SQL.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it implements a standard read-through caching pattern where the cache is checked before querying Cloud SQL, effectively reducing redundant database calls for repeated requests. Using a dedicated Memcache instance ensures higher performance and isolation compared to shared memory, which is crucial for minimizing latency in frequent data access scenarios.
Options C and D are incorrect because storing all query results under a single key violates Memcache best practices and size limits, while Option B uses an inefficient polling strategy (cron jobs) that generates unnecessary overhead rather than reacting to actual cache misses.

## Pregunta 100

Contexto: [topics:92](#topics-92)
You need to ensure reliability for your application and operations by supporting reliable task scheduling for compute on GCP. Leveraging Google best practices, what should you do?

**A.** Using the Cron service provided by App Engine, publish messages directly to a message-processing utility service running on Compute Engine instances.

**B.** Using the Cron service provided by App Engine, publish messages to a Cloud Pub/Sub topic. Subscribe to that topic using a message-processing utility service running on Compute Engine instances.

**C.** Using the Cron service provided by Google Kubernetes Engine (GKE), publish messages directly to a message-processing utility service running on Compute Engine instances.

**D.** Using the Cron service provided by GKE, publish messages to a Cloud Pub/Sub topic. Subscribe to that topic using a message-processing utility service running on Compute Engine instances.

**Respuesta de la fuente:** B

**Explicación:** Option B is the correct answer because it follows GCP best practices for reliable task scheduling by decoupling the scheduler from the compute instances using Cloud Pub/Sub.
Direct HTTP calls (Options A and C) lack built-in durability, whereas Pub/Sub provides at-least-once delivery guarantees and buffering to handle instance downtime or scaling events.
Although modern exams recommend Cloud Scheduler, within this question's context, App Engine Cron is the designated scheduler, making B the only pattern that ensures reliability via a durable message queue.

## Pregunta 101

Contexto: [topics:92](#topics-92)
Your company is building a new architecture to support its data-centric business focus. You are responsible for setting up the network. Your company's mobile and web-facing applications will be deployed on-premises, and all data analysis will be conducted in GCP. The plan is to process and load 7 years of archived .csv files totaling 900 TB of data and then continue loading 10 TB of data daily. You currently have an existing 100-MB internet connection.
What actions will meet your company's needs?

**A.** Compress and upload both archived files and files uploaded daily using the gsutil —m option.

**B.** Lease a Transfer Appliance, upload archived files to it, and send it to Google to transfer archived data to Cloud Storage. Establish a connection with Google using a Dedicated Interconnect or Direct Peering connection and use it to upload files daily.

**C.** Lease a Transfer Appliance, upload archived files to it, and send it to Google to transfer archived data to Cloud Storage. Establish one Cloud VPN Tunnel to VPC networks over the public internet, and compress and upload files daily using the gsutil —m option.

**D.** Lease a Transfer Appliance, upload archived files to it, and send it to Google to transfer archived data to Cloud Storage. Establish a Cloud VPN Tunnel to VPC networks over the public internet, and compress and upload files daily.

**Respuesta de la fuente:** B

**Explicación:** Uploading 900 TB over a 100 Mbps connection is impractical due to extreme latency; Google Transfer Appliance is required for the initial bulk data migration.
For daily transfers of 10 TB, cloud interconnect options (Dedicated Interconnect or Direct Peering) provide the necessary high-bandwidth, private connectivity that exceeds the limits of the existing internet link or standard VPN.

## Pregunta 102

Contexto: [topics:92](#topics-92)
You are developing a globally scaled frontend for a legacy streaming backend data API. This API expects events in strict chronological order with no repeat data for proper processing.
Which products should you deploy to ensure guaranteed-once FIFO (first-in, first-out) delivery of data?

**A.** Cloud Pub/Sub alone

**B.** Cloud Pub/Sub to Cloud Dataflow

**C.** Cloud Pub/Sub to Stackdriver

**D.** Cloud Pub/Sub to Cloud SQL

**Respuesta de la fuente:** B

**Explicación:** Cloud Pub/Sub natively provides at-least-once delivery semantics. To achieve guaranteed-exactly-once (no repeats) and strict ordering for a globally scaled stream, Cloud Dataflow is required to perform deduplication and windowing based on timestamps. Other options like Cloud SQL or Stackdriver lack the native streaming processing capabilities needed for this real-time data lifecycle pattern.

## Pregunta 103

Contexto: [topics:92](#topics-92)
Your company is planning to perform a lift and shift migration of their Linux RHEL 6.5+ virtual machines. The virtual machines are running in an on-premises
VMware environment. You want to migrate them to Compute Engine following Google-recommended practices. What should you do?

**A.** 1. Define a migration plan based on the list of the applications and their dependencies. 2. Migrate all virtual machines into Compute Engine individually with Migrate for Compute Engine.

**B.** 1. Perform an assessment of virtual machines running in the current VMware environment. 2. Create images of all disks. Import disks on Compute Engine. 3. Create standard virtual machines where the boot disks are the ones you have imported.

**C.** 1. Perform an assessment of virtual machines running in the current VMware environment. 2. Define a migration plan, prepare a Migrate for Compute Engine migration RunBook, and execute the migration.

**D.** 1. Perform an assessment of virtual machines running in the current VMware environment. 2. Install a third-party agent on all selected virtual machines. 3. Migrate all virtual machines into Compute Engine.

**Respuesta de la fuente:** C

**Explicación:** Google-recommended practices for lift-and-shift migrations from VMware utilize Migrate for Compute Engine to automate the process while managing dependencies.

The correct workflow involves assessing the source environment, defining a migration plan that groups VMs into waves based on application dependencies, and creating RunBooks in the Migrate for Compute Engine Manager to orchestrate the replication and cutover.

## Pregunta 104

Contexto: [topics:92](#topics-92)
You need to deploy an application to Google Cloud. The application receives traffic via TCP and reads and writes data to the filesystem. The application does not support horizontal scaling. The application process requires full control over the data on the file system because concurrent access causes corruption. The business is willing to accept a downtime when an incident occurs, but the application must be available 24/7 to support their business operations. You need to design the architecture of this application on Google Cloud. What should you do?

**A.** Use a managed instance group with instances in multiple zones, use Cloud Filestore, and use an HTTP load balancer in front of the instances.

**B.** Use a managed instance group with instances in multiple zones, use Cloud Filestore, and use a network load balancer in front of the instances.

**C.** Use an unmanaged instance group with an active and standby instance in different zones, use a regional persistent disk, and use an HTTP load balancer in front of the instances.

**D.** Use an unmanaged instance group with an active and standby instance in different zones, use a regional persistent disk, and use a network load balancer in front of the instances.

**Respuesta de la fuente:** D

**Explicación:** A Network Load Balancer is required because the application receives TCP traffic (Layer 4), whereas an HTTP(S) load balancer handles only Layer 7 protocols. An unmanaged instance group with active/standby instances is necessary because the application does not support horizontal scaling and requires exclusive filesystem access to prevent data corruption, which rules out shared storage like Cloud Filestore in a scaled-out managed group.

## Pregunta 105

Contexto: [topics:92](#topics-92)
Your company has an application running on multiple Compute Engine instances. You need to ensure that the application can communicate with an on-premises service that requires high throughput via internal IPs, while minimizing latency. What should you do?

**A.** Use OpenVPN to configure a VPN tunnel between the on-premises environment and Google Cloud.

**B.** Configure a direct peering connection between the on-premises environment and Google Cloud.

**C.** Use Cloud VPN to configure a VPN tunnel between the on-premises environment and Google Cloud.

**D.** Configure a Cloud Dedicated Interconnect connection between the on-premises environment and Google Cloud.

**Respuesta de la fuente:** D

**Explicación:** Cloud Dedicated Interconnect provides a direct physical link between on-premises networks and Google Cloud, ensuring high throughput and low latency by bypassing the public internet.
This dedicated connection supports internal IP communication without the encryption overhead or variable jitter associated with Cloud VPN solutions.

## Pregunta 106

Contexto: [topics:92](#topics-92)
You are managing an application deployed on Cloud Run for Anthos, and you need to define a strategy for deploying new versions of the application. You want to evaluate the new code with a subset of production traffic to decide whether to proceed with the rollout. What should you do?

**A.** Deploy a new revision to Cloud Run with the new version. Configure traffic percentage between revisions.

**B.** Deploy a new service to Cloud Run with the new version. Add a Cloud Load Balancing instance in front of both services.

**C.** In the Google Cloud Console page for Cloud Run, set up continuous deployment using Cloud Build for the development branch. As part of the Cloud Build trigger, configure the substitution variable TRAFFIC_PERCENTAGE with the percentage of traffic you want directed to a new version.

**D.** In the Google Cloud Console, configure Traffic Director with a new Service that points to the new version of the application on Cloud Run. Configure Traffic Director to send a small percentage of traffic to the new version of the application.

**Respuesta de la fuente:** A

**Explicación:** Cloud Run for Anthos natively supports traffic splitting between different revisions of the same service, allowing for canary deployments or A/B testing without external load balancers.
Deploying a new revision and configuring the traffic percentage directly within the service settings is the standard, supported mechanism for gradually rolling out changes while evaluating them with production traffic.

## Pregunta 107

Contexto: [topics:92](#topics-92)
You are monitoring Google Kubernetes Engine (GKE) clusters in a Cloud Monitoring workspace. As a Site Reliability Engineer (SRE), you need to triage incidents quickly. What should you do?

**A.** Navigate the predefined dashboards in the Cloud Monitoring workspace, and then add metrics and create alert policies.

**B.** Navigate the predefined dashboards in the Cloud Monitoring workspace, create custom metrics, and install alerting software on a Compute Engine instance.

**C.** Write a shell script that gathers metrics from GKE nodes, publish these metrics to a Pub/Sub topic, export the data to BigQuery, and make a Data Studio dashboard.

**D.** Create a custom dashboard in the Cloud Monitoring workspace for each incident, and then add metrics and create alert policies.

**Respuesta de la fuente:** A

**Explicación:** Cloud Monitoring provides predefined dashboards that offer immediate visibility into GKE cluster health without additional configuration.
Using these built-in views allows an SRE to quickly identify anomalies and triage incidents, whereas creating custom dashboards per incident (D) or building complex data pipelines (C) introduces unnecessary latency and overhead.
Option A leverages the native capabilities of Cloud Monitoring for efficient operational response.

## Pregunta 108

Contexto: [topics:92](#topics-92)
You are implementing a single Cloud SQL MySQL second-generation database that contains business-critical transaction data. You want to ensure that the minimum amount of data is lost in case of catastrophic failure. Which two features should you implement? (Choose two.)

**A.** Sharding

**B.** Read replicas

**C.** Binary logging

**D.** Automated backups

**E.** Semisynchronous replication

**Respuesta de la fuente:** C, D

**Explicación:** To minimize data loss (RPO) in Cloud SQL MySQL, you must enable Point-in-Time Recovery (PITR), which allows restoring the database to any specific second within the retention period. PITR relies on two underlying mechanisms: Automated Backups (which provide a base snapshot) and Binary Logging (which records all transaction changes since that snapshot). Without both features, you cannot recover recent transactions lost between backup windows or during a catastrophic failure.

## Pregunta 109

Contexto: [topics:92](#topics-92)
You are working at a sports association whose members range in age from 8 to 30. The association collects a large amount of health data, such as sustained injuries. You are storing this data in BigQuery. Current legislation requires you to delete such information upon request of the subject. You want to design a solution that can accommodate such a request. What should you do?

**A.** Use a unique identifier for each individual. Upon a deletion request, delete all rows from BigQuery with this identifier.

**B.** When ingesting new data in BigQuery, run the data through the Data Loss Prevention (DLP) API to identify any personal information. As part of the DLP scan, save the result to Data Catalog. Upon a deletion request, query Data Catalog to find the column with personal information.

**C.** Create a BigQuery view over the table that contains all data. Upon a deletion request, exclude the rows that affect the subject's data from this view. Use this view instead of the source table for all analysis tasks.

**D.** Use a unique identifier for each individual. Upon a deletion request, overwrite the column with the unique identifier with a salted SHA256 of its value.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it directly fulfills the legislative requirement to delete data upon request by physically removing all rows associated with a unique identifier.
DLP (Option B) only identifies or classifies sensitive data but does not perform the actual deletion required by law.
Options C and D are incorrect because excluding rows via a view or hashing identifiers only masks the data rather than permanently erasing it.

## Pregunta 110

Contexto: [topics:92](#topics-92)
Your company has announced that they will be outsourcing operations functions. You want to allow developers to easily stage new versions of a cloud-based application in the production environment and allow the outsourced operations team to autonomously promote staged versions to production. You want to minimize the operational overhead of the solution. Which Google Cloud product should you migrate to?

**A.** App Engine

**B.** GKE On-Prem

**C.** Compute Engine

**D.** Google Kubernetes Engine

**Respuesta de la fuente:** A

**Explicación:** App Engine is a fully managed Platform-as-a-Service (PaaS) that significantly minimizes operational overhead by handling infrastructure management automatically.
It natively supports the workflow described: developers can deploy new versions to staging, and operations teams can promote specific version IDs to production without managing underlying servers or complex Kubernetes configurations.

## Pregunta 111

Contexto: [topics:92](#topics-92)
Your company is running its application workloads on Compute Engine. The applications have been deployed in production, acceptance, and development environments. The production environment is business-critical and is used 24/7, while the acceptance and development environments are only critical during office hours. Your CFO has asked you to optimize these environments to achieve cost savings during idle times. What should you do?

**A.** Create a shell script that uses the gcloud command to change the machine type of the development and acceptance instances to a smaller machine type outside of office hours. Schedule the shell script on one of the production instances to automate the task.

**B.** Use Cloud Scheduler to trigger a Cloud Function that will stop the development and acceptance environments after office hours and start them just before office hours.

**C.** Deploy the development and acceptance applications on a managed instance group and enable autoscaling.

**D.** Use regular Compute Engine instances for the production environment, and use preemptible VMs for the acceptance and development environments.

**Respuesta de la fuente:** B

**Explicación:** Option B is the most cost-effective solution because stopping Compute Engine instances eliminates all charges for vCPU and memory during idle hours, whereas preemptible VMs (D) are only suitable for fault-tolerant tasks and autoscaling (C) does not stop instances entirely.
Scheduling stops and starts via Cloud Scheduler and Cloud Functions follows Google Cloud best practices for optimizing costs in non-critical dev/test environments without requiring custom scripting on production servers (A).

## Pregunta 112

Contexto: [topics:92](#topics-92)
You are moving an application that uses MySQL from on-premises to Google Cloud. The application will run on Compute Engine and will use Cloud SQL. You want to cut over to the Compute Engine deployment of the application with minimal downtime and no data loss to your customers. You want to migrate the application with minimal modification. You also need to determine the cutover strategy. What should you do?

**A.** 1. Set up Cloud VPN to provide private network connectivity between the Compute Engine application and the on-premises MySQL server. 2. Stop the on-premises application. 3. Create a mysqldump of the on-premises MySQL server. 4. Upload the dump to a Cloud Storage bucket. 5. Import the dump into Cloud SQL. 6. Modify the source code of the application to write queries to both databases and read from its local database. 7. Start the Compute Engine application. 8. Stop the on-premises application.

**B.** 1. Set up Cloud SQL proxy and MySQL proxy. 2. Create a mysqldump of the on-premises MySQL server. 3. Upload the dump to a Cloud Storage bucket. 4. Import the dump into Cloud SQL. 5. Stop the on-premises application. 6. Start the Compute Engine application.

**C.** 1. Set up Cloud VPN to provide private network connectivity between the Compute Engine application and the on-premises MySQL server. 2. Stop the on-premises application. 3. Start the Compute Engine application, configured to read and write to the on-premises MySQL server. 4. Create the replication configuration in Cloud SQL. 5. Configure the source database server to accept connections from the Cloud SQL replica. 6. Finalize the Cloud SQL replica configuration. 7. When replication has been completed, stop the Compute Engine application. 8. Promote the Cloud SQL replica to a standalone instance. 9. Restart the Compute Engine application, configured to read and write to the Cloud SQL standalone instance.

**D.** 1. Stop the on-premises application. 2. Create a mysqldump of the on-premises MySQL server. 3. Upload the dump to a Cloud Storage bucket. 4. Import the dump into Cloud SQL. 5. Start the application on Compute Engine.

**Respuesta de la fuente:** C

**Explicación:** Option C describes the External Replica Promotion strategy, which allows for continuous data replication to Cloud SQL while the application remains active, ensuring minimal downtime and no data loss.
In contrast, options using mysqldump (A, B, D) require stopping the application during the export/import process, resulting in significant downtime as any changes made after the snapshot are lost.
By setting up a replica, synchronizing data, and promoting it only at the final cutover step, you achieve a near-zero downtime migration with minimal application code changes.

## Pregunta 113

Contexto: [topics:92](#topics-92)
Your organization has decided to restrict the use of external IP addresses on instances to only approved instances. You want to enforce this requirement across all of your Virtual Private Clouds (VPCs). What should you do?

**A.** Remove the default route on all VPCs. Move all approved instances into a new subnet that has a default route to an internet gateway.

**B.** Create a new VPC in custom mode. Create a new subnet for the approved instances, and set a default route to the internet gateway on this new subnet.

**C.** Implement a Cloud NAT solution to remove the need for external IP addresses entirely.

**D.** Set an Organization Policy with a constraint on constraints/compute.vmExternalIpAccess. List the approved instances in the allowedValues list.

**Respuesta de la fuente:** D

**Explicación:** Organization Policy constraints provide the centralized mechanism required to enforce rules across all VPCs and projects within an organization. Specifically, the `constraints/compute.vmExternalIpAccess` constraint allows you to define a whitelist (`allowedValues`) of specific VM instances permitted to use external IP addresses, thereby restricting access for all others.

## Pregunta 114

Contexto: [topics:92](#topics-92)
Your company uses the Firewall Insights feature in the Google Network Intelligence Center. You have several firewall rules applied to Compute Engine instances.
You need to evaluate the efficiency of the applied firewall ruleset. When you bring up the Firewall Insights page in the Google Cloud Console, you notice that there are no log rows to display. What should you do to troubleshoot the issue?

**A.** Enable Virtual Private Cloud (VPC) flow logging.

**B.** Enable Firewall Rules Logging for the firewall rules you want to monitor.

**C.** Verify that your user account is assigned the compute.networkAdmin Identity and Access Management (IAM) role.

**D.** Install the Google Cloud SDK, and verify that there are no Firewall logs in the command line output.

**Respuesta de la fuente:** B

**Explicación:** Firewall Insights relies on data generated by Firewall Rules Logging to analyze traffic patterns and rule efficiency.
By default, logging is disabled for firewall rules; therefore, no log rows appear until you explicitly enable logging for the specific rules in question.
VPC flow logs (Option A) provide packet-level data but do not directly supply the metadata required for Firewall Insights without enabling the specific firewall rule logging feature.

## Pregunta 115

Contexto: [topics:92](#topics-92)
Your company has sensitive data in Cloud Storage buckets. Data analysts have Identity Access Management (IAM) permissions to read the buckets. You want to prevent data analysts from retrieving the data in the buckets from outside the office network. What should you do?

**A.** 1. Create a VPC Service Controls perimeter that includes the projects with the buckets. 2. Create an access level with the CIDR of the office network.

**B.** 1. Create a firewall rule for all instances in the Virtual Private Cloud (VPC) network for source range. 2. Use the Classless Inter-domain Routing (CIDR) of the office network.

**C.** 1. Create a Cloud Function to remove IAM permissions from the buckets, and another Cloud Function to add IAM permissions to the buckets. 2. Schedule the Cloud Functions with Cloud Scheduler to add permissions at the start of business and remove permissions at the end of business.

**D.** 1. Create a Cloud VPN to the office network. 2. Configure Private Google Access for on-premises hosts.

**Respuesta de la fuente:** A

**Explicación:** VPC Service Controls are specifically designed to create security perimeters that prevent unauthorized data exfiltration from Google Cloud services like Cloud Storage.
By defining an access level based on the office network's CIDR, you ensure that resources within the perimeter can only be accessed by users or networks meeting that condition.
This effectively blocks data retrieval from outside the designated office network, addressing the requirement to prevent external access.

## Pregunta 116

Contexto: [topics:92](#topics-92)
You have developed a non-critical update to your application that is running in a managed instance group, and have created a new instance template with the update that you want to release. To prevent any possible impact to the application, you don't want to update any running instances. You want any new instances that are created by the managed instance group to contain the new update. What should you do?

**A.** Start a new rolling restart operation.

**B.** Start a new rolling replace operation.

**C.** Start a new rolling update. Select the Proactive update mode.

**D.** Start a new rolling update. Select the Opportunistic update mode.

**Respuesta de la fuente:** D

**Explicación:** Opportunistic update mode is designed to apply configuration changes only when new instances are created or during manual selective updates, ensuring that currently running instances remain untouched.
In contrast, Proactive mode automatically triggers updates on existing instances to meet the desired state, which would violate the requirement to avoid impacting running applications.

## Pregunta 117

Contexto: [topics:92](#topics-92)
Your company is designing its application landscape on Compute Engine. Whenever a zonal outage occurs, the application should be restored in another zone as quickly as possible with the latest application data. You need to design the solution to meet this requirement. What should you do?

**A.** Create a snapshot schedule for the disk containing the application data. Whenever a zonal outage occurs, use the latest snapshot to restore the disk in the same zone.

**B.** Configure the Compute Engine instances with an instance template for the application, and use a regional persistent disk for the application data. Whenever a zonal outage occurs, use the instance template to spin up the application in another zone in the same region. Use the regional persistent disk for the application data.

**C.** Create a snapshot schedule for the disk containing the application data. Whenever a zonal outage occurs, use the latest snapshot to restore the disk in another zone within the same region.

**D.** Configure the Compute Engine instances with an instance template for the application, and use a regional persistent disk for the application data. Whenever a zonal outage occurs, use the instance template to spin up the application in another region. Use the regional persistent disk for the application data.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Regional Persistent Disks provide synchronous replication across two zones in the same region, ensuring data availability if one zone fails. The question specifically requires restoring in another *zone* (not a different region), making regional resources the appropriate choice for zonal resiliency while minimizing latency and complexity.

## Pregunta 118

Contexto: [topics:92](#topics-92)
Your company has just acquired another company, and you have been asked to integrate their existing Google Cloud environment into your company's data center. Upon investigation, you discover that some of the RFC 1918 IP ranges being used in the new company's Virtual Private Cloud (VPC) overlap with your data center IP space. What should you do to enable connectivity and make sure that there are no routing conflicts when connectivity is established?

**A.** Create a Cloud VPN connection from the new VPC to the data center, create a Cloud Router, and apply new IP addresses so there is no overlapping IP space.

**B.** Create a Cloud VPN connection from the new VPC to the data center, and create a Cloud NAT instance to perform NAT on the overlapping IP space.

**C.** Create a Cloud VPN connection from the new VPC to the data center, create a Cloud Router, and apply a custom route advertisement to block the overlapping IP space.

**D.** Create a Cloud VPN connection from the new VPC to the data center, and apply a firewall rule that blocks the overlapping IP space.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 119

Contexto: [topics:92](#topics-92)
You need to migrate Hadoop jobs for your company's Data Science team without modifying the underlying infrastructure. You want to minimize costs and infrastructure management effort. What should you do?

**A.** Create a Dataproc cluster using standard worker instances.

**B.** Create a Dataproc cluster using preemptible worker instances.

**C.** Manually deploy a Hadoop cluster on Compute Engine using standard instances.

**D.** Manually deploy a Hadoop cluster on Compute Engine using preemptible instances.

**Respuesta de la fuente:** B

**Explicación:** Google Dataproc is the managed service that minimizes infrastructure management effort compared to manually deploying Hadoop on Compute Engine.
Using preemptible worker instances significantly reduces costs while maintaining fault tolerance for batch jobs, aligning with the goal to minimize expenses.
Therefore, creating a Dataproc cluster with preemptible workers satisfies both cost and management requirements.

## Pregunta 120

Contexto: [topics:92](#topics-92)
Your company has a project in Google Cloud with three Virtual Private Clouds (VPCs). There is a Compute Engine instance on each VPC. Network subnets do not overlap and must remain separated. The network configuration is shown below.
[Imagen: sin descripción]
Instance #1 is an exception and must communicate directly with both Instance #2 and Instance #3 via internal IPs. How should you accomplish this?
Imagen · question_text · sin descripción
![Imagen original](imagenes/bc432dbb2cb270157dc7.jpg)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Y Google Cloud Platform
VPC#2
Instance #1
Compute Engine
```

**A.** Create a cloud router to advertise subnet #2 and subnet #3 to subnet #1.

**B.** Add two additional NICs to Instance #1 with the following configuration: "¢ NIC1 ○ VPC: VPC #2 ○ SUBNETWORK: subnet #2 "¢ NIC2 ○ VPC: VPC #3 ○ SUBNETWORK: subnet #3 Update firewall rules to enable traffic between instances.

**C.** Create two VPN tunnels via CloudVPN: "¢ 1 between VPC #1 and VPC #2. "¢ 1 between VPC #2 and VPC #3. Update firewall rules to enable traffic between the instances.

**D.** Peer all three VPCs: "¢ Peer VPC #1 with VPC #2. "¢ Peer VPC #2 with VPC #3. Update firewall rules to enable traffic between the instances.

**Respuesta de la fuente:** B

**Explicación:** Option B is the correct solution because multiple network interfaces allow a single Compute Engine instance to connect directly to different VPC networks without establishing transitive connectivity between those VPCs. This satisfies the requirement for Instance #1 to communicate with Instances #2 and #3 while keeping VPC #2 and VPC #3 isolated from each other.
VPC peering (Option D) creates full mesh or direct connections that would allow all three instances to communicate, violating the isolation constraint between VPCs 2 and 3.
Cloud Routers (Option A) do not facilitate internal IP routing between separate VPCs, and Cloud VPN (Option C) introduces unnecessary latency and complexity for intra-project communication.

## Pregunta 121

Contexto: [topics:92](#topics-92)
You need to deploy an application on Google Cloud that must run on a Debian Linux environment. The application requires extensive configuration in order to operate correctly. You want to ensure that you can install Debian distribution updates with minimal manual intervention whenever they become available. What should you do?

**A.** Create a Compute Engine instance template using the most recent Debian image. Create an instance from this template, and install and configure the application as part of the startup script. Repeat this process whenever a new Google-managed Debian image becomes available.

**B.** Create a Debian-based Compute Engine instance, install and configure the application, and use OS patch management to install available updates.

**C.** Create an instance with the latest available Debian image. Connect to the instance via SSH, and install and configure the application on the instance. Repeat this process whenever a new Google-managed Debian image becomes available.

**D.** Create a Docker container with Debian as the base image. Install and configure the application as part of the Docker image creation process. Host the container on Google Kubernetes Engine and restart the container whenever a new update is available.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Google Cloud OS patch management automates the installation of security patches and updates on Compute Engine instances with minimal manual intervention, directly addressing the requirement for automated Debian distribution updates. In contrast, options A and C require recreating instances from new images, which is a manual or semi-manual process that does not leverage automated patching for an existing configured environment. Option D uses Kubernetes containers, which do not handle underlying OS-level distribution updates in the same manner as host VM patch management.

## Pregunta 122

Contexto: [topics:92](#topics-92)
You have an application that runs in Google Kubernetes Engine (GKE). Over the last 2 weeks, customers have reported that a specific part of the application returns errors very frequently. You currently have no logging or monitoring solution enabled on your GKE cluster. You want to diagnose the problem, but you have not been able to replicate the issue. You want to cause minimal disruption to the application. What should you do?

**A.** 1. Update your GKE cluster to use Cloud Operations for GKE. 2. Use the GKE Monitoring dashboard to investigate logs from affected Pods.

**B.** 1. Create a new GKE cluster with Cloud Operations for GKE enabled. 2. Migrate the affected Pods to the new cluster, and redirect traffic for those Pods to the new cluster. 3. Use the GKE Monitoring dashboard to investigate logs from affected Pods.

**C.** 1. Update your GKE cluster to use Cloud Operations for GKE, and deploy Prometheus. 2. Set an alert to trigger whenever the application returns an error.

**D.** 1. Create a new GKE cluster with Cloud Operations for GKE enabled, and deploy Prometheus. 2. Migrate the affected Pods to the new cluster, and redirect traffic for those Pods to the new cluster. 3. Set an alert to trigger whenever the application returns an error.

**Respuesta de la fuente:** A

**Explicación:** The correct answer is A because enabling Cloud Operations for GKE allows you to collect logs and metrics natively without the complexity of a third-party solution like Prometheus, adhering to Google's best practices.
Migrating workloads (as suggested in B and D) introduces unnecessary risk and potential downtime, violating the requirement for minimal disruption.
Since the error is intermittent and unreplicable, setting up an alert system immediately (C) would require waiting for the next occurrence to gather data, whereas simply enabling logging allows for immediate historical analysis of recent errors if they continue or for capturing future instances as they happen.

## Pregunta 123

Contexto: [topics:92](#topics-92)
You need to deploy a stateful workload on Google Cloud. The workload can scale horizontally, but each instance needs to read and write to the same POSIX filesystem. At high load, the stateful workload needs to support up to 100 MB/s of writes. What should you do?

**A.** Use a persistent disk for each instance.

**B.** Use a regional persistent disk for each instance.

**C.** Create a Cloud Filestore instance and mount it in each instance.

**D.** Create a Cloud Storage bucket and mount it in each instance using gcsfuse.

**Respuesta de la fuente:** C

**Explicación:** Cloud Filestore is a fully managed NFS service that provides native POSIX filesystem semantics, including file locking and concurrent read/write access required by the stateful workload.

In contrast, gcsfuse mounts object storage as a filesystem but explicitly lacks POSIX compliance, does not support proper concurrency controls (last write wins), and performs poorly under high I/O loads compared to dedicated network storage.

## Pregunta 124

Contexto: [topics:92](#topics-92)
Your company has an application deployed on Anthos clusters (formerly Anthos GKE) that is running multiple microservices. The cluster has both Anthos Service
Mesh and Anthos Config Management configured. End users inform you that the application is responding very slowly. You want to identify the microservice that is causing the delay. What should you do?

**A.** Use the Service Mesh visualization in the Cloud Console to inspect the telemetry between the microservices.

**B.** Use Anthos Config Management to create a ClusterSelector selecting the relevant cluster. On the Google Cloud Console page for Google Kubernetes Engine, view the Workloads and filter on the cluster. Inspect the configurations of the filtered workloads.

**C.** Use Anthos Config Management to create a namespaceSelector selecting the relevant cluster namespace. On the Google Cloud Console page for Google Kubernetes Engine, visit the workloads and filter on the namespace. Inspect the configurations of the filtered workloads.

**D.** Reinstall istio using the default istio profile in order to collect request latency. Evaluate the telemetry between the microservices in the Cloud Console.

**Respuesta de la fuente:** A

**Explicación:** Anthos Service Mesh provides native observability dashboards in the Cloud Console that visualize traffic patterns, latency, and error rates between microservices.
This allows you to directly inspect telemetry data to identify which specific service is introducing performance delays without needing to modify configurations or restart components.

## Pregunta 125

Contexto: [topics:92](#topics-92)
You are working at a financial institution that stores mortgage loan approval documents on Cloud Storage. Any change to these approval documents must be uploaded as a separate approval file, so you want to ensure that these documents cannot be deleted or overwritten for the next 5 years. What should you do?

**A.** Create a retention policy on the bucket for the duration of 5 years. Create a lock on the retention policy.

**B.** Create the bucket with uniform bucket-level access, and grant a service account the role of Object Writer. Use the service account to upload new files.

**C.** Use a customer-managed key for the encryption of the bucket. Rotate the key after 5 years.

**D.** Create the bucket with fine-grained access control, and grant a service account the role of Object Writer. Use the service account to upload new files.

**Respuesta de la fuente:** A

**Explicación:** A Cloud Storage retention policy prevents objects from being deleted or overwritten until a specified time period has elapsed.
Locking the retention policy makes it immutable, ensuring that even administrators cannot shorten the retention period or remove the policy during the 5-year window.

## Pregunta 126

Contexto: [topics:92](#topics-92)
Your team will start developing a new application using microservices architecture on Kubernetes Engine. As part of the development lifecycle, any code change that has been pushed to the remote develop branch on your GitHub repository should be built and tested automatically. When the build and test are successful, the relevant microservice will be deployed automatically in the development environment. You want to ensure that all code deployed in the development environment follows this process. What should you do?

**A.** Have each developer install a pre-commit hook on their workstation that tests the code and builds the container when committing on the development branch. After a successful commit, have the developer deploy the newly built container image on the development cluster.

**B.** Install a post-commit hook on the remote git repository that tests the code and builds the container when code is pushed to the development branch. After a successful commit, have the developer deploy the newly built container image on the development cluster.

**C.** Create a Cloud Build trigger based on the development branch that tests the code, builds the container, and stores it in Container Registry. Create a deployment pipeline that watches for new images and deploys the new image on the development cluster. Ensure only the deployment tool has access to deploy new versions.

**D.** Create a Cloud Build trigger based on the development branch to build a new container image and store it in Container Registry. Rely on Vulnerability Scanning to ensure the code tests succeed. As the final step of the Cloud Build process, deploy the new container image on the development cluster. Ensure only Cloud Build has access to deploy new versions.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it implements a fully automated CI/CD pipeline using Cloud Build triggers to handle testing and image building upon pushes to the develop branch. It separates concerns by using a deployment pipeline to automatically deploy new images to Kubernetes, ensuring consistency and preventing manual or unauthorized deployments.

Options A and B are incorrect as they rely on developer actions rather than an automated system. Option D is incorrect because Vulnerability Scanning checks for security issues in existing images, not functional code tests.

## Pregunta 127

Contexto: [topics:92](#topics-92)
Your operations team has asked you to help diagnose a performance issue in a production application that runs on Compute Engine. The application is dropping requests that reach it when under heavy load. The process list for affected instances shows a single application process that is consuming all available CPU, and autoscaling has reached the upper limit of instances. There is no abnormal load on any other related systems, including the database. You want to allow production traffic to be served again as quickly as possible. Which action should you recommend?

**A.** Change the autoscaling metric to agent.googleapis.com/memory/percent_used.

**B.** Restart the affected instances on a staggered schedule.

**C.** SSH to each instance and restart the application process.

**D.** Increase the maximum number of instances in the autoscaling group.

**Respuesta de la fuente:** D

**Explicación:** The application is dropping requests because autoscaling has hit its configured maximum number of instances, preventing new resources from handling the load.
Increasing the maximum instance count allows the autoscaler to provision additional VMs immediately, distributing traffic and restoring service availability.
Changing metrics (A) is irrelevant since CPU is already saturated, while restarting processes or instances (B, C) causes downtime or service interruption during critical production outages.

## Pregunta 128

Contexto: [topics:92](#topics-92)
You are implementing the infrastructure for a web service on Google Cloud. The web service needs to receive and store the data from 500,000 requests per second. The data will be queried later in real time, based on exact matches of a known set of attributes. There will be periods where the web service will not receive any requests. The business wants to keep costs low. Which web service platform and database should you use for the application?

**A.** Cloud Run and BigQuery

**B.** Cloud Run and Cloud Bigtable

**C.** A Compute Engine autoscaling managed instance group and BigQuery

**D.** A Compute Engine autoscaling managed instance group and Cloud Bigtable

**Respuesta de la fuente:** B

**Explicación:** Cloud Bigtable is the correct database choice because it is designed for high-throughput, low-latency writes and real-time point lookups (exact attribute matches), whereas BigQuery has streaming insertion limits (100,000 rows/sec per table) that would bottleneck 500,000 requests.
Cloud Run is the preferred compute platform over Compute Engine because it scales to zero during periods of inactivity, satisfying the requirement to keep costs low while still supporting high concurrency via horizontal scaling.

## Pregunta 129

Contexto: [topics:92](#topics-92)
You are developing an application using different microservices that should remain internal to the cluster. You want to be able to configure each microservice with a specific number of replicas. You also want to be able to address a specific microservice from any other microservice in a uniform way, regardless of the number of replicas the microservice scales to. You need to implement this solution on Google Kubernetes Engine. What should you do?

**A.** Deploy each microservice as a Deployment. Expose the Deployment in the cluster using a Service, and use the Service DNS name to address it from other microservices within the cluster.

**B.** Deploy each microservice as a Deployment. Expose the Deployment in the cluster using an Ingress, and use the Ingress IP address to address the Deployment from other microservices within the cluster.

**C.** Deploy each microservice as a Pod. Expose the Pod in the cluster using a Service, and use the Service DNS name to address the microservice from other microservices within the cluster.

**D.** Deploy each microservice as a Pod. Expose the Pod in the cluster using an Ingress, and use the Ingress IP address name to address the Pod from other microservices within the cluster.

**Respuesta de la fuente:** A

**Explicación:** Deployments manage replica counts for microservices, satisfying the requirement to configure specific numbers of replicas, whereas Pods do not inherently handle scaling or self-healing.
A Service provides a stable internal endpoint and DNS name that remains consistent regardless of how many pod replicas are running, ensuring uniform addressability within the cluster.
Ingress is designed for external HTTP routing and is unnecessary for internal service-to-service communication, making Option A the correct choice over B.

## Pregunta 130

Contexto: [topics:92](#topics-92)
Your company has a networking team and a development team. The development team runs applications on Compute Engine instances that contain sensitive data. The development team requires administrative permissions for Compute Engine. Your company requires all network resources to be managed by the networking team. The development team does not want the networking team to have access to the sensitive data on the instances. What should you do?

**A.** 1. Create a project with a standalone VPC and assign the Network Admin role to the networking team. 2. Create a second project with a standalone VPC and assign the Compute Admin role to the development team. 3. Use Cloud VPN to join the two VPCs.

**B.** 1. Create a project with a standalone Virtual Private Cloud (VPC), assign the Network Admin role to the networking team, and assign the Compute Admin role to the development team.

**C.** 1. Create a project with a Shared VPC and assign the Network Admin role to the networking team. 2. Create a second project without a VPC, configure it as a Shared VPC service project, and assign the Compute Admin role to the development team.

**D.** 1. Create a project with a standalone VPC and assign the Network Admin role to the networking team. 2. Create a second project with a standalone VPC and assign the Compute Admin role to the development team. 3. Use VPC Peering to join the two VPCs.

**Respuesta de la fuente:** C

**Explicación:** Shared VPC is the correct solution because it enforces separation of duties by centralizing network resource management in a host project while allowing service projects to host compute resources.
This architecture prevents the networking team from accessing sensitive data on Compute Engine instances, as they lack permissions in the development team's service project.
Additionally, using separate projects avoids the security risk inherent in Option B, where the Compute Admin role includes network administration privileges that would violate the requirement for isolated network management.

## Pregunta 131

Contexto: [topics:92](#topics-92)
Your company wants you to build a highly reliable web application with a few public APIs as the backend. You don't expect a lot of user traffic, but traffic could spike occasionally. You want to leverage Cloud Load Balancing, and the solution must be cost-effective for users. What should you do?

**A.** Store static content such as HTML and images in Cloud CDN. Host the APIs on App Engine and store the user data in Cloud SQL.

**B.** Store static content such as HTML and images in a Cloud Storage bucket. Host the APIs on a zonal Google Kubernetes Engine cluster with worker nodes in multiple zones, and save the user data in Cloud Spanner.

**C.** Store static content such as HTML and images in Cloud CDN. Use Cloud Run to host the APIs and save the user data in Cloud SQL.

**D.** Store static content such as HTML and images in a Cloud Storage bucket. Use Cloud Functions to host the APIs and save the user data in Firestore.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 132

Contexto: [topics:92](#topics-92)
Your company sends all Google Cloud logs to Cloud Logging. Your security team wants to monitor the logs. You want to ensure that the security team can react quickly if an anomaly such as an unwanted firewall change or server breach is detected. You want to follow Google-recommended practices. What should you do?

**A.** Schedule a cron job with Cloud Scheduler. The scheduled job queries the logs every minute for the relevant events.

**B.** Export logs to BigQuery, and trigger a query in BigQuery to process the log data for the relevant events.

**C.** Export logs to a Pub/Sub topic, and trigger Cloud Function with the relevant log events.

**D.** Export logs to a Cloud Storage bucket, and trigger Cloud Run with the relevant log events.

**Respuesta de la fuente:** C

**Explicación:** Option C is the correct answer because it leverages Cloud Logging sinks to export filtered log entries to a Pub/Sub topic, enabling an event-driven, real-time architecture. This allows a Cloud Function to trigger immediately upon detecting specific anomalies, fulfilling the requirement for quick reaction times as recommended by Google best practices.

## Pregunta 133

Contexto: [topics:92](#topics-92)
You have deployed several instances on Compute Engine. As a security requirement, instances cannot have a public IP address. There is no VPN connection between Google Cloud and your office, and you need to connect via SSH into a specific machine without violating the security requirements. What should you do?

**A.** Configure Cloud NAT on the subnet where the instance is hosted. Create an SSH connection to the Cloud NAT IP address to reach the instance.

**B.** Add all instances to an unmanaged instance group. Configure TCP Proxy Load Balancing with the instance group as a backend. Connect to the instance using the TCP Proxy IP.

**C.** Configure Identity-Aware Proxy (IAP) for the instance and ensure that you have the role of IAP-secured Tunnel User. Use the gcloud command line tool to ssh into the instance.

**D.** Create a bastion host in the network to SSH into the bastion host from your office location. From the bastion host, SSH into the desired instance.

**Respuesta de la fuente:** C

**Explicación:** Identity-Aware Proxy (IAP) TCP forwarding allows administrators to connect to Compute Engine instances via SSH without requiring a public IP address or a VPN, satisfying the strict security constraints.
Using `gcloud compute ssh` with IAP establishes an encrypted tunnel through the IAP service, granting access based on IAM roles (specifically `compute.securityAdmin` or `iap.tunnelResourceAccessor`) rather than network-level firewall rules or external IP assignments.

## Pregunta 134

Contexto: [topics:92](#topics-92)
Your company is using Google Cloud. You have two folders under the Organization: Finance and Shopping. The members of the development team are in a
Google Group. The development team group has been assigned the Project Owner role on the Organization. You want to prevent the development team from creating resources in projects in the Finance folder. What should you do?

**A.** Assign the development team group the Project Viewer role on the Finance folder, and assign the development team group the Project Owner role on the Shopping folder.

**B.** Assign the development team group only the Project Viewer role on the Finance folder.

**C.** Assign the development team group the Project Owner role on the Shopping folder, and remove the development team group Project Owner role from the Organization.

**D.** Assign the development team group only the Project Owner role on the Shopping folder.

**Respuesta de la fuente:** C

**Explicación:** IAM permissions in Google Cloud are hierarchical and inherit from parent resources. Since the development group holds the Project Owner role at the Organization level, they implicitly have these high-privilege permissions on all descendant folders, including Finance. Assigning a more restrictive role like Viewer to the Finance folder does not override the inherited Owner permissions from the Organization level (Option A and B). Therefore, you must remove the broad Organization-level binding and explicitly grant access only to the intended scope, which is the Shopping folder (Option C).

## Pregunta 135

Contexto: [topics:92](#topics-92)
You are developing your microservices application on Google Kubernetes Engine. During testing, you want to validate the behavior of your application in case a specific microservice should suddenly crash. What should you do?

**A.** Add a taint to one of the nodes of the Kubernetes cluster. For the specific microservice, configure a pod anti-affinity label that has the name of the tainted node as a value.

**B.** Use Istio's fault injection on the particular microservice whose faulty behavior you want to simulate.

**C.** Destroy one of the nodes of the Kubernetes cluster to observe the behavior.

**D.** Configure Istio's traffic management features to steer the traffic away from a crashing microservice.

**Respuesta de la fuente:** B

**Explicación:** Istio's fault injection capabilities allow you to simulate specific failure scenarios, such as a microservice crash or high latency, without actually destroying resources. This enables safe validation of application resilience and error handling during testing. In contrast, destroying nodes (C) is destructive and affects multiple pods, while taints (A) and traffic steering (D) do not simulate the service failure itself.

## Pregunta 136

Contexto: [topics:92](#topics-92)
Your company is developing a new application that will allow globally distributed users to upload pictures and share them with other selected users. The application will support millions of concurrent users. You want to allow developers to focus on just building code without having to create and maintain the underlying infrastructure. Which service should you use to deploy the application?

**A.** App Engine

**B.** Cloud Endpoints

**C.** Compute Engine

**D.** Google Kubernetes Engine

**Respuesta de la fuente:** A

**Explicación:** The key requirement is for developers to focus solely on code without maintaining underlying infrastructure. App Engine is a fully managed Platform-as-a-Service (PaaS) that abstracts away server and operating system management, allowing automatic scaling for millions of users. In contrast, Compute Engine and GKE require significant infrastructure provisioning and maintenance, while Cloud Endpoints is an API management service, not a deployment runtime.

## Pregunta 137

Contexto: [topics:92](#topics-92)
Your company provides a recommendation engine for retail customers. You are providing retail customers with an API where they can submit a user ID and the
API returns a list of recommendations for that user. You are responsible for the API lifecycle and want to ensure stability for your customers in case the API makes backward-incompatible changes. You want to follow Google-recommended practices. What should you do?

**A.** Create a distribution list of all customers to inform them of an upcoming backward-incompatible change at least one month before replacing the old API with the new API.

**B.** Create an automated process to generate API documentation, and update the public API documentation as part of the CI/CD process when deploying an update to the API.

**C.** Use a versioning strategy for the APIs that increases the version number on every backward-incompatible change.

**D.** Use a versioning strategy for the APIs that adds the suffix "DEPRECATED" to the current API version number on every backward-incompatible change. Use the current version number for the new API.

**Respuesta de la fuente:** C

**Explicación:** Google API Design Best Practices recommend using versioning to manage breaking changes and ensure stability for clients.
When a backward-incompatible change is introduced, the major version number must be incremented (e.g., v1 to v2) so that existing client code continues to function without modification.
This allows developers to migrate to the new version at their own pace while maintaining access to the old stable version.

## Pregunta 138

Contexto: [topics:92](#topics-92)
Your company has developed a monolithic, 3-tier application to allow external users to upload and share files. The solution cannot be easily enhanced and lacks reliability. The development team would like to re-architect the application to adopt microservices and a fully managed service approach, but they need to convince their leadership that the effort is worthwhile. Which advantage(s) should they highlight to leadership?

**A.** The new approach will be significantly less costly, make it easier to manage the underlying infrastructure, and automatically manage the CI/CD pipelines.

**B.** The monolithic solution can be converted to a container with Docker. The generated container can then be deployed into a Kubernetes cluster.

**C.** The new approach will make it easier to decouple infrastructure from application, develop and release new features, manage the underlying infrastructure, manage CI/CD pipelines and perform A/B testing, and scale the solution if necessary.

**D.** The process can be automated with Migrate for Compute Engine.

**Respuesta de la fuente:** C

**Explicación:** Option C correctly identifies the key architectural benefits of microservices and fully managed services that address the stated problems of poor maintainability and reliability.
These benefits include decoupling infrastructure from application code, enabling independent feature development and releases, simplifying CI/CD management, facilitating A/B testing, and allowing granular scaling.
Option A is incorrect because moving to microservices does not guarantee lower costs (often initial costs rise) nor does it automatically manage CI/CD pipelines without configuration.

## Pregunta 139

Contexto: [topics:92](#topics-92)
Your team is developing a web application that will be deployed on Google Kubernetes Engine (GKE). Your CTO expects a successful launch and you need to ensure your application can handle the expected load of tens of thousands of users. You want to test the current deployment to ensure the latency of your application stays below a certain threshold. What should you do?

**A.** Use a load testing tool to simulate the expected number of concurrent users and total requests to your application, and inspect the results.

**B.** Enable autoscaling on the GKE cluster and enable horizontal pod autoscaling on your application deployments. Send curl requests to your application, and validate if the auto scaling works.

**C.** Replicate the application over multiple GKE clusters in every Google Cloud region. Configure a global HTTP(S) load balancer to expose the different clusters over a single global IP address.

**D.** Use Cloud Debugger in the development environment to understand the latency between the different microservices.

**Respuesta de la fuente:** A

**Explicación:** The objective is to verify that application latency remains below a specific threshold under a load of tens of thousands of users.
Load testing tools are specifically designed to simulate high concurrency and generate realistic traffic patterns to measure performance metrics like latency, throughput, and error rates.
Manual checks like `curl` or debugging tools do not provide the statistical significance or volume required to validate system behavior at scale.

## Pregunta 140

Contexto: [topics:92](#topics-92)
Your company has a Kubernetes application that pulls messages from Pub/Sub and stores them in Filestore. Because the application is simple, it was deployed as a single pod. The infrastructure team has analyzed Pub/Sub metrics and discovered that the application cannot process the messages in real time. Most of them wait for minutes before being processed. You need to scale the elaboration process that is I/O-intensive. What should you do?

**A.** Use kubectl autoscale deployment APP_NAME --max 6 --min 2 --cpu-percent 50 to configure Kubernetes autoscaling deployment.

**B.** Configure a Kubernetes autoscaling deployment based on the subscription/push_request_latencies metric.

**C.** Use the --enable-autoscaling flag when you create the Kubernetes cluster.

**D.** Configure a Kubernetes autoscaling deployment based on the subscription/num_undelivered_messages metric.

**Respuesta de la fuente:** D

**Explicación:** The core issue is that the application cannot process messages fast enough, leading to a backlog. The `subscription/num_undelivered_messages` metric directly measures this backlog size, allowing Kubernetes to scale out pods specifically when the queue depth exceeds a threshold.
This approach uses Horizontal Pod Autoscaler (HPA) with external metrics, which is the standard method for scaling based on Pub/Sub subscription status in Google Kubernetes Engine (GKE).

## Pregunta 141

Contexto: [topics:92](#topics-92)
Your company is developing a web-based application. You need to make sure that production deployments are linked to source code commits and are fully auditable. What should you do?

**A.** Make sure a developer is tagging the code commit with the date and time of commit.

**B.** Make sure a developer is adding a comment to the commit that links to the deployment.

**C.** Make the container tag match the source code commit hash.

**D.** Make sure the developer is tagging the commits with latest.

**Respuesta de la fuente:** C

**Explicación:** Using the immutable Git commit hash as the container image tag creates a permanent, verifiable link between the deployed artifact and the exact source code revision. This automated approach ensures full auditability by allowing engineers to trace any running production instance back to a specific commit without relying on error-prone manual tagging or metadata.

## Pregunta 142

Contexto: [topics:92](#topics-92)
An application development team has come to you for advice. They are planning to write and deploy an HTTP(S) API using Go 1.12. The API will have a very unpredictable workload and must remain reliable during peaks in traffic. They want to minimize operational overhead for this application. Which approach should you recommend?

**A.** Develop the application with containers, and deploy to Google Kubernetes Engine.

**B.** Develop the application for App Engine standard environment.

**C.** Use a Managed Instance Group when deploying to Compute Engine.

**D.** Develop the application for App Engine flexible environment, using a custom runtime.

**Respuesta de la fuente:** B

**Explicación:** App Engine Standard Environment is the optimal choice because it natively supports Go 1.12 and provides automatic, instant scaling to handle unpredictable traffic spikes.
It minimizes operational overhead by managing infrastructure automatically, including scaling to zero instances when idle to reduce costs.

## Pregunta 143

Contexto: [topics:92](#topics-92)
Your company is designing its data lake on Google Cloud and wants to develop different ingestion pipelines to collect unstructured data from different sources.
After the data is stored in Google Cloud, it will be processed in several data pipelines to build a recommendation engine for end users on the website. The structure of the data retrieved from the source systems can change at any time. The data must be stored exactly as it was retrieved for reprocessing purposes in case the data structure is incompatible with the current processing pipelines. You need to design an architecture to support the use case after you retrieve the data. What should you do?

**A.** Send the data through the processing pipeline, and then store the processed data in a BigQuery table for reprocessing.

**B.** Store the data in a BigQuery table. Design the processing pipelines to retrieve the data from the table.

**C.** Send the data through the processing pipeline, and then store the processed data in a Cloud Storage bucket for reprocessing.

**D.** Store the data in a Cloud Storage bucket. Design the processing pipelines to retrieve the data from the bucket.

**Respuesta de la fuente:** D

**Explicación:** The requirement to store data exactly as retrieved for reprocessing mandates an Extract-Load-Transform (ELT) pattern where raw data is persisted before any schema enforcement or transformation.
Cloud Storage is the appropriate service for storing unstructured, schema-less raw data in a data lake architecture, whereas BigQuery requires a defined schema that would conflict with the changing source structures.

## Pregunta 144

Contexto: [topics:92](#topics-92)
You are responsible for the Google Cloud environment in your company. Multiple departments need access to their own projects, and the members within each department will have the same project responsibilities. You want to structure your Google Cloud environment for minimal maintenance and maximum overview of
IAM permissions as each department's projects start and end. You want to follow Google-recommended practices. What should you do?

**A.** Grant all department members the required IAM permissions for their respective projects.

**B.** Create a Google Group per department and add all department members to their respective groups. Create a folder per department and grant the respective group the required IAM permissions at the folder level. Add the projects under the respective folders.

**C.** Create a folder per department and grant the respective members of the department the required IAM permissions at the folder level. Structure all projects for each department under the respective folders.

**D.** Create a Google Group per department and add all department members to their respective groups. Grant each group the required IAM permissions for their respective projects.

**Respuesta de la fuente:** B

**Explicación:** Option B follows Google-recommended practices by leveraging organizational hierarchy (folders) for bulk resource management and Google Groups for identity abstraction.
Granting IAM permissions to a Group at the Folder level allows all member projects within that folder to inherit those permissions automatically, significantly reducing maintenance overhead compared to managing individual user or project-level bindings.

## Pregunta 145

Contexto: [topics:92](#topics-92)
Your company has an application running as a Deployment in a Google Kubernetes Engine (GKE) cluster. You have separate clusters for development, staging, and production. You have discovered that the team is able to deploy a Docker image to the production cluster without first testing the deployment in development and then staging. You want to allow the team to have autonomy but want to prevent this from happening. You want a Google Cloud solution that can be implemented quickly with minimal effort. What should you do?

**A.** Configure a Kubernetes lifecycle hook to prevent the container from starting if it is not approved for usage in the given environment.

**B.** Implement a corporate policy to prevent teams from deploying Docker images to an environment unless the Docker image was tested in an earlier environment.

**C.** Configure binary authorization policies for the development, staging, and production clusters. Create attestations as part of the continuous integration pipeline.

**D.** Create a Kubernetes admissions controller to prevent the container from starting if it is not approved for usage in the given environment.

**Respuesta de la fuente:** C

**Explicación:** Binary Authorization is the native GKE feature designed to enforce policies on container images before they are deployed. By requiring attestations generated during the CI pipeline for development and staging, it technically prevents untested images from being admitted into production.
This approach provides automated enforcement with minimal effort, unlike corporate policies (which rely on human compliance) or custom admission controllers/lifecycle hooks (which require more complex implementation).

## Pregunta 146

Contexto: [topics:92](#topics-92)
Your company wants to migrate their 10-TB on-premises database export into Cloud Storage. You want to minimize the time it takes to complete this activity, the overall cost, and database load. The bandwidth between the on-premises environment and Google Cloud is 1 Gbps. You want to follow Google-recommended practices. What should you do?

**A.** Develop a Dataflow job to read data directly from the database and write it into Cloud Storage.

**B.** Use the Data Transfer appliance to perform an offline migration.

**C.** Use a commercial partner ETL solution to extract the data from the on-premises database and upload it into Cloud Storage.

**D.** Compress the data and upload it with gsutil -m to enable multi-threaded copy.

**Respuesta de la fuente:** B

**Explicación:** The question specifies minimizing time, cost, and database load for a 10 TB transfer with only 1 Gbps bandwidth. An online transfer via gsutil (Option D) would take approximately 30 hours, keeping the network saturated and potentially impacting other workloads, whereas offline transfers are recommended when online speeds exceed acceptable timelines or data sizes are large. Although Google documentation often cites >40 TB for Transfer Appliance recommendations to offset shipping time, in the context of minimizing database load and avoiding long-duration network saturation on a limited 1 Gbps link, the offline Data Transfer Appliance (Option B) is the prescribed solution for large, bulk migrations where online bandwidth is a bottleneck. Options A and C involve ETL processes that impose significant load on the source database, violating the constraint to minimize database load.

## Pregunta 147

Contexto: [topics:92](#topics-92)
Your company has an enterprise application running on Compute Engine that requires high availability and high performance. The application has been deployed on two instances in two zones in the same region in active-passive mode. The application writes data to a persistent disk. In the case of a single zone outage, that data should be immediately made available to the other instance in the other zone. You want to maximize performance while minimizing downtime and data loss.
What should you do?

**A.** 1. Attach a persistent SSD disk to the first instance. 2. Create a snapshot every hour. 3. In case of a zone outage, recreate a persistent SSD disk in the second instance where data is coming from the created snapshot.

**B.** 1. Create a Cloud Storage bucket. 2. Mount the bucket into the first instance with gcs-fuse. 3. In case of a zone outage, mount the Cloud Storage bucket to the second instance with gcs-fuse.

**C.** 1. Attach a regional SSD persistent disk to the first instance. 2. In case of a zone outage, force-attach the disk to the other instance.

**D.** 1. Attach a local SSD to the first instance disk. 2. Execute an rsync command every hour where the target is a persistent SSD disk attached to the second instance. 3. In case of a zone outage, use the second instance.

**Respuesta de la fuente:** C

**Explicación:** Regional persistent SSDs provide synchronous replication across two zones within a region, ensuring data availability in the event of a single zone failure.
Unlike zonal disks or snapshot-based recovery, force-attaching a regional disk to an instance in the surviving zone allows for immediate access to data with minimal downtime and no data loss.
Other options like Cloud Storage (gcs-fuse) offer lower performance, while snapshots and rsync introduce significant latency and potential data loss during the replication window.

## Pregunta 148

Contexto: [topics:92](#topics-92)
You are designing a Data Warehouse on Google Cloud and want to store sensitive data in BigQuery. Your company requires you to generate the encryption keys outside of Google Cloud. You need to implement a solution. What should you do?

**A.** Generate a new key in Cloud Key Management Service (Cloud KMS). Store all data in Cloud Storage using the customer-managed key option and select the created key. Set up a Dataflow pipeline to decrypt the data and to store it in a new BigQuery dataset.

**B.** Generate a new key in Cloud KMS. Create a dataset in BigQuery using the customer-managed key option and select the created key.

**C.** Import a key in Cloud KMS. Store all data in Cloud Storage using the customer-managed key option and select the created key. Set up a Dataflow pipeline to decrypt the data and to store it in a new BigQuery dataset.

**D.** Import a key in Cloud KMS. Create a dataset in BigQuery using the customer-supplied key option and select the created key.

**Respuesta de la fuente:** D

**Explicación:** The requirement to generate keys outside of Google Cloud necessitates importing the key into Cloud KMS rather than generating a new one there, eliminating options A and B.
BigQuery encryption uses Customer-Managed Encryption Keys (CMEK) stored in Cloud KMS; once an external key is imported into KMS, it functions as a CMEK for BigQuery datasets.
Option D correctly identifies the need to import the key and use it with BigQuery, whereas option C incorrectly suggests storing data in Cloud Storage and using Dataflow for decryption, which is unnecessary complexity for native BigQuery encryption.

## Pregunta 149

Contexto: [topics:92](#topics-92)
Your organization has stored sensitive data in a Cloud Storage bucket. For regulatory reasons, your company must be able to rotate the encryption key used to encrypt the data in the bucket. The data will be processed in Dataproc. You want to follow Google-recommended practices for security. What should you do?

**A.** Create a key with Cloud Key Management Service (KMS). Encrypt the data using the encrypt method of Cloud KMS.

**B.** Create a key with Cloud Key Management Service (KMS). Set the encryption key on the bucket to the Cloud KMS key.

**C.** Generate a GPG key pair. Encrypt the data using the GPG key. Upload the encrypted data to the bucket.

**D.** Generate an AES-256 encryption key. Encrypt the data in the bucket using the customer-supplied encryption keys feature.

**Respuesta de la fuente:** B

**Explicación:** Using Cloud Key Management Service (KMS) with Customer-Managed Keys (CMKs) allows you to set a default encryption key for the entire bucket.
This configuration enables automated, seamless key rotation and re-encryption of data without manual intervention per object.
It adheres to Google-recommended best practices by centralizing key management while meeting regulatory requirements for control over encryption keys.

## Pregunta 150

Contexto: [topics:92](#topics-92)
Your team needs to create a Google Kubernetes Engine (GKE) cluster to host a newly built application that requires access to third-party services on the internet.
Your company does not allow any Compute Engine instance to have a public IP address on Google Cloud. You need to create a deployment strategy that adheres to these guidelines. What should you do?

**A.** Configure the GKE cluster as a private cluster, and configure Cloud NAT Gateway for the cluster subnet.

**B.** Configure the GKE cluster as a private cluster. Configure Private Google Access on the Virtual Private Cloud (VPC).

**C.** Configure the GKE cluster as a route-based cluster. Configure Private Google Access on the Virtual Private Cloud (VPC).

**D.** Create a Compute Engine instance, and install a NAT Proxy on the instance. Configure all workloads on GKE to pass through this proxy to access third-party services on the Internet.

**Respuesta de la fuente:** A

**Explicación:** A private GKE cluster ensures nodes have no public IP addresses, satisfying the security requirement.
Cloud NAT Gateway allows these private instances to initiate outbound connections to third-party internet services while hiding their internal IPs.
Private Google Access (Option B) only permits access to Google APIs and Services, not general internet traffic.

## Pregunta 151

Contexto: [topics:92](#topics-92)
Your company has a support ticketing solution that uses App Engine Standard. The project that contains the App Engine application already has a Virtual Private
Cloud (VPC) network fully connected to the company's on-premises environment through a Cloud VPN tunnel. You want to enable the App Engine application to communicate with a database that is running in the company's on-premises environment. What should you do?

**A.** Configure private Google access for on-premises hosts only.

**B.** Configure private Google access.

**C.** Configure private services access.

**D.** Configure serverless VPC access.

**Respuesta de la fuente:** D

**Explicación:** App Engine Standard runs in a managed environment isolated from the VPC network. To allow App Engine applications to communicate with resources on a VPC network, you must configure Serverless VPC Access. This creates a connector that routes traffic from App Engine through the existing VPC and Cloud VPN tunnel to the on-premises database.

## Pregunta 152

Contexto: [topics:92](#topics-92)
Your company is planning to upload several important files to Cloud Storage. After the upload is completed, they want to verify that the uploaded content is identical to what they have on-premises. You want to minimize the cost and effort of performing this check. What should you do?

**A.** 1. Use Linux shasum to compute a digest of files you want to upload. 2. Use gsutil -m to upload all the files to Cloud Storage. 3. Use gsutil cp to download the uploaded files. 4. Use Linux shasum to compute a digest of the downloaded files. 5. Compare the hashes.

**B.** 1. Use gsutil -m to upload the files to Cloud Storage. 2. Develop a custom Java application that computes CRC32C hashes. 3. Use gsutil ls -L gs://[YOUR_BUCKET_NAME] to collect CRC32C hashes of the uploaded files. 4. Compare the hashes.

**C.** 1. Use gsutil -m to upload all the files to Cloud Storage. 2. Use gsutil cp to download the uploaded files. 3. Use Linux diff to compare the content of the files.

**D.** 1. Use gsutil -m to upload the files to Cloud Storage. 2. Use gsutil hash -c FILE_NAME to generate CRC32C hashes of all on-premises files. 3. Use gsutil ls -L gs://[YOUR_BUCKET_NAME] to collect CRC32C hashes of the uploaded files. 4. Compare the hashes.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it minimizes cost and effort by avoiding the need to download files for comparison. Instead, it leverages `gsutil hash` to generate local CRC32C checksums and `gsutil ls -L` to retrieve server-side checksums, allowing a simple string comparison. Options A and C incur unnecessary egress costs and latency by downloading files, while Option B introduces complexity by requiring custom development.

## Pregunta 153

Contexto: [topics:92](#topics-92)
You have deployed an application on Anthos clusters (formerly Anthos GKE). According to the SRE practices at your company, you need to be alerted if request latency is above a certain threshold for a specified amount of time. What should you do?

**A.** Install Anthos Service Mesh on your cluster. Use the Google Cloud Console to define a Service Level Objective (SLO), and create an alerting policy based on this SLO.

**B.** Enable the Cloud Trace API on your project, and use Cloud Monitoring Alerts to send an alert based on the Cloud Trace metrics.

**C.** Use Cloud Profiler to follow up the request latency. Create a custom metric in Cloud Monitoring based on the results of Cloud Profiler, and create an Alerting policy in case this metric exceeds the threshold.

**D.** Configure Anthos Config Management on your cluster, and create a yaml file that defines the SLO and alerting policy you want to deploy in your cluster.

**Respuesta de la fuente:** A

**Explicación:** Anthos Service Mesh integrates with Cloud Monitoring to define Service Level Objectives (SLOs) based on latency metrics. You can directly configure alerting policies in the Google Cloud Console that trigger when an SLO's error budget is consumed or specific latency thresholds are breached, which aligns with SRE best practices. Options B and C involve tools (Cloud Trace, Cloud Profiler) designed for diagnostic debugging rather than continuous monitoring and threshold-based alerting.

## Pregunta 154

Contexto: [topics:92](#topics-92)
Your company has a stateless web API that performs scientific calculations. The web API runs on a single Google Kubernetes Engine (GKE) cluster. The cluster is currently deployed in us-central1. Your company has expanded to offer your API to customers in Asia. You want to reduce the latency for users in Asia.
What should you do?

**A.** Create a second GKE cluster in asia-southeast1, and expose both APIs using a Service of type LoadBalancer. Add the public IPs to the Cloud DNS zone.

**B.** Use a global HTTP(s) load balancer with Cloud CDN enabled.

**C.** Create a second GKE cluster in asia-southeast1, and use kubemci to create a global HTTP(s) load balancer.

**D.** Increase the memory and CPU allocated to the application in the cluster.

**Respuesta de la fuente:** C

**Explicación:** To reduce latency for global users accessing a stateless API, you must deploy the application in a region closer to them (Asia).
A standard Service LoadBalancer only creates an L4 TCP/UDP load balancer, which lacks the intelligent HTTP-based routing required to direct traffic based on user geography.
While kubemci is deprecated and Multi-Cluster Ingress is the modern equivalent, Option C correctly identifies the architectural pattern of using a centralized controller to manage global HTTP(S) load balancing across multiple GKE clusters.

## Pregunta 155

Contexto: [topics:92](#topics-92)
You are migrating third-party applications from optimized on-premises virtual machines to Google Cloud. You are unsure about the optimum CPU and memory options. The applications have a consistent usage pattern across multiple weeks. You want to optimize resource usage for the lowest cost. What should you do?

**A.** Create an instance template with the smallest available machine type, and use an image of the third-party application taken from a current on-premises virtual machine. Create a managed instance group that uses average CPU utilization to autoscale the number of instances in the group. Modify the average CPU utilization threshold to optimize the number of instances running.

**B.** Create an App Engine flexible environment, and deploy the third-party application using a Dockerfile and a custom runtime. Set CPU and memory options similar to your application's current on-premises virtual machine in the app.yaml file.

**C.** Create multiple Compute Engine instances with varying CPU and memory options. Install the Cloud Monitoring agent, and deploy the third-party application on each of them. Run a load test with high traffic levels on the application, and use the results to determine the optimal settings.

**D.** Create a Compute Engine instance with CPU and memory options similar to your application's current on-premises virtual machine. Install the Cloud Monitoring agent, and deploy the third-party application. Run a load test with normal traffic levels on the application, and follow the Rightsizing Recommendations in the Cloud Console.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it leverages Google Cloud's built-in Rightsizing Recommendations feature, which specifically analyzes usage patterns over time to suggest optimal CPU and memory configurations for cost efficiency.
The question states the application has a 'consistent usage pattern across multiple weeks,' which aligns with the data requirements for rightsizing algorithms to generate accurate recommendations.
Option A is incorrect because it relies on autoscaling based only on average CPU, ignoring memory constraints and the need for proper initial sizing.