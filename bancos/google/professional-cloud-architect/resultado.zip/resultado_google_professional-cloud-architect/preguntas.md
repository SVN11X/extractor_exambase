# professional cloud architect

360 / 360 preguntas. Cobertura completa: True.

Respuestas de la fuente; revisión técnica pendiente. Las imágenes permanecen en sus campos de origen.

360 respuestas conservadas; 0 pendientes.

<a id="topics-92"></a>
## Contexto topics:92
name:
Topic 1

<a id="topics-93"></a>
## Contexto topics:93
name:
Topic 2

case_study_text:
Company Overview -
JencoMart is a global retailer with over 10,000 stores in 16 countries. The stores carry a range of goods, such as groceries, tires, and jewelry. One of the company's core values is excellent customer service. In addition, they recently introduced an environmental policy to reduce their carbon output by 50% over the next 5 years.

Company Background -
JencoMart started as a general store in 1931, and has grown into one of the world's leading brands, known for great value and customer service. Over time, the company transitioned from only physical stores to a stores and online hybrid model, with 25% of sales online. Currently, JencoMart has little presence in Asia, but considers that market key for future growth.

Solution Concept -
JencoMart wants to migrate several critical applications to the cloud but has not completed a technical review to determine their suitability for the cloud and the engineering required for migration. They currently host all of these applications on infrastructure that is at its end of life and is no longer supported.

Existing Technical Environment -
JencoMart hosts all of its applications in 4 data centers: 3 in North American and 1 in Europe; most applications are dual-homed.
JencoMart understands the dependencies and resource usage metrics of their on-premises architecture.
Application: Customer loyalty portal
LAMP (Linux, Apache, MySQL and PHP) application served from the two JencoMart-owned U.S. data centers.

Database -
Oracle Database stores user profiles
- 20 TB
- Complex table structure
- Well maintained, clean data
- Strong backup strategy
PostgreSQL database stores user credentials
- Single-homed in US West
- No redundancy
- Backed up every 12 hours
- 100% uptime service level agreement (SLA)
- Authenticates all users

Compute -
30 machines in US West Coast, each machine has:
- Twin, dual core CPUs
- 32 GB of RAM
- Twin 250 GB HDD (RAID 1)
20 machines in US East Coast, each machine has:
- Single, dual-core CPU
- 24 GB of RAM
- Twin 250 GB HDD (RAID 1)

Storage -
Access to shared 100 TB SAN in each location
Tape backup every week

Business Requirements -
Optimize for capacity during peak periods and value during off-peak periods
Guarantee service availability and support
Reduce on-premises footprint and associated financial and environmental impact
Move to outsourcing model to avoid large upfront costs associated with infrastructure purchase
Expand services into Asia

Technical Requirements -
Assess key application for cloud suitability
Modify applications for the cloud
Move applications to a new infrastructure
Leverage managed services wherever feasible
Sunset 20% of capacity in existing data centers
Decrease latency in Asia

CEO Statement -
JencoMart will continue to develop personal relationships with our customers as more people access the web. The future of our retail business is in the global market and the connection between online and in-store experiences. As a large, global company, we also have a responsibility to the environment through `green` initiatives and policies.

CTO Statement -
The challenges of operating data centers prevent focus on key technologies critical to our long-term success. Migrating our data services to a public cloud infrastructure will allow us to focus on big data and machine learning to improve our service to customers.

CFO Statement -
Since its founding, JencoMart has invested heavily in our data services infrastructure. However, because of changing market trends, we need to outsource our infrastructure to ensure our long-term success. This model will allow us to respond to increasing customer demand during peak periods and reduce costs.

<a id="topics-94"></a>
## Contexto topics:94
name:
Topic 3

case_study_text:
Company overview -
Helicopter Racing League (HRL) is a global sports league for competitive helicopter racing. Each year HRL holds the world championship and several regional league competitions where teams compete to earn a spot in the world championship. HRL offers a paid service to stream the races all over the world with live telemetry and predictions throughout each race.

Solution concept -
HRL wants to migrate their existing service to a new platform to expand their use of managed AI and ML services to facilitate race predictions. Additionally, as new fans engage with the sport, particularly in emerging regions, they want to move the serving of their content, both real-time and recorded, closer to their users.

Existing technical environment -
HRL is a public cloud-first company; the core of their mission-critical applications runs on their current public cloud provider. Video recording and editing is performed at the race tracks, and the content is encoded and transcoded, where needed, in the cloud. Enterprise-grade connectivity and local compute is provided by truck-mounted mobile data centers. Their race prediction services are hosted exclusively on their existing public cloud provider. Their existing technical environment is as follows:
Existing content is stored in an object storage service on their existing public cloud provider.
Video encoding and transcoding is performed on VMs created for each job.
Race predictions are performed using TensorFlow running on VMs in the current public cloud provider.

Business requirements -
HRL's owners want to expand their predictive capabilities and reduce latency for their viewers in emerging markets. Their requirements are:
Support ability to expose the predictive models to partners.
Increase predictive capabilities during and before races:
○ Race results
○ Mechanical failures
○ Crowd sentiment
Increase telemetry and create additional insights.
Measure fan engagement with new predictions.
Enhance global availability and quality of the broadcasts.
Increase the number of concurrent viewers.
Minimize operational complexity.
Ensure compliance with regulations.
Create a merchandising revenue stream.

Technical requirements -
Maintain or increase prediction throughput and accuracy.
Reduce viewer latency.
Increase transcoding performance.
Create real-time analytics of viewer consumption patterns and engagement.
Create a data mart to enable processing of large volumes of race data.

Executive statement -
Our CEO, S. Hawke, wants to bring high-adrenaline racing to fans all around the world. We listen to our fans, and they want enhanced video streams that include predictions of events within the race (e.g., overtaking). Our current platform allows us to predict race outcomes but lacks the facility to support real-time predictions during races and the capacity to process season-long results.

<a id="topics-95"></a>
## Contexto topics:95
name:
Topic 4

case_study_text:
Company overview -
EHR Healthcare is a leading provider of electronic health record software to the medical industry. EHR Healthcare provides their software as a service to multi- national medical offices, hospitals, and insurance providers.

Solution concept -
Due to rapid changes in the healthcare and insurance industry, EHR Healthcare's business has been growing exponentially year over year. They need to be able to scale their environment, adapt their disaster recovery plan, and roll out new continuous deployment capabilities to update their software at a fast pace. Google
Cloud has been chosen to replace their current colocation facilities.

Existing technical environment -
EHR's software is currently hosted in multiple colocation facilities. The lease on one of the data centers is about to expire.
Customer-facing applications are web-based, and many have recently been containerized to run on a group of Kubernetes clusters. Data is stored in a mixture of relational and NoSQL databases (MySQL, MS SQL Server, Redis, and MongoDB).
EHR is hosting several legacy file- and API-based integrations with insurance providers on-premises. These systems are scheduled to be replaced over the next several years. There is no plan to upgrade or move these systems at the current time.
Users are managed via Microsoft Active Directory. Monitoring is currently being done via various open source tools. Alerts are sent via email and are often ignored.

Business requirements -
* On-board new insurance providers as quickly as possible.
* Provide a minimum 99.9% availability for all customer-facing systems.
* Provide centralized visibility and proactive action on system performance and usage.
* Increase ability to provide insights into healthcare trends.
* Reduce latency to all customers.
* Maintain regulatory compliance.
* Decrease infrastructure administration costs.
* Make predictions and generate reports on industry trends based on provider data.

Technical requirements -
* Maintain legacy interfaces to insurance providers with connectivity to both on-premises systems and cloud providers.
* Provide a consistent way to manage customer-facing applications that are container-based.
* Provide a secure and high-performance connection between on-premises systems and Google Cloud.
* Provide consistent logging, log retention, monitoring, and alerting capabilities.
* Maintain and manage multiple container-based environments.
* Dynamically scale and provision new environments.
* Create interfaces to ingest and process data from new providers.

Executive statement -
Our on-premises strategy has worked for years but has required a major investment of time and money in training our team on distinctly different systems, managing similar but separate environments, and responding to outages. Many of these outages have been a result of misconfigured systems, inadequate capacity to manage spikes in traffic, and inconsistent monitoring practices. We want to use Google Cloud to leverage a scalable, resilient platform that can span multiple environments seamlessly and provide a consistent and stable user experience that positions us for future growth.

<a id="topics-96"></a>
## Contexto topics:96
name:
Topic 5

case_study_text:
Company Overview -
Mountkirk Games makes online, session-based, multiplayer games for the most popular mobile platforms. They build all of their games using some server-side integration. Historically, they have used cloud providers to lease physical servers.
Due to the unexpected popularity of some of their games, they have had problems scaling their global audience, application servers MySQL databases, and analytics tools.
Their current model is to write game statistics to files and send them through an ETL tool that loads them into a centralized MySQL database for reporting.

Solution Concept -
Mountkirk Games is building a new game, which they expect to be very popular. They plan to deploy the game's backend on Google Compute Engine so they can capture streaming metrics run intensive analytics, and take advantage of its autoscaling server environment and integrate with a managed NoSQL database.

Business Requirements -
Increase to a global footprint
Improve uptime `" downtime is loss of players
Increase efficiency of the cloud resources we use
Reduce latency to all customers

Technical Requirements -
Requirements for Game Backend Platform
1. Dynamically scale up or down based on game activity
2. Connect to a managed NoSQL database service
3. Run customize Linux distro
Requirements for Game Analytics Platform
1. Dynamically scale up or down based on game activity
2. Process incoming data on the fly directly from the game servers
3. Process data that arrives late because of slow mobile networks
4. Allow SQL queries to access at least 10 TB of historical data
5. Process files that are regularly uploaded by users' mobile devices
6. Use only fully managed services

CEO Statement -
Our last successful game did not scale well with our previous cloud provider, resulting in lower user adoption and affecting the game's reputation. Our investors want more key performance indicators (KPIs) to evaluate the speed and stability of the game, as well as other metrics that provide deeper insight into usage patterns so we can adapt the game to target users.

CTO Statement -
Our current technology stack cannot provide the scale we need, so we want to replace MySQL and move to an environment that provides autoscaling, low latency load balancing, and frees us up from managing physical servers.

CFO Statement -
We are not capturing enough user demographic data, usage metrics, and other KPIs. As a result, we do not engage the right users, we are not confident that our marketing is targeting the right users, and we are not selling enough premium Blast-Ups inside the games, which dramatically impacts our revenue.

<a id="topics-97"></a>
## Contexto topics:97
name:
Topic 6

case_study_text:
Company Overview -
Mountkirk Games makes online, session-based, multiplayer games for mobile platforms. They build all of their games using some server-side integration.
Historically, they have used cloud providers to lease physical servers.
Due to the unexpected popularity of some of their games, they have had problems scaling their global audience, application servers, MySQL databases, and analytics tools.
Their current model is to write game statistics to files and send them through an ETL tool that loads them into a centralized MySQL database for reporting.

Solution Concept -
Mountkirk Games is building a new game, which they expect to be very popular. They plan to deploy the game's backend on Google Compute Engine so they can capture streaming metrics, run intensive analytics, and take advantage of its autoscaling server environment and integrate with a managed NoSQL database.

Business Requirements -
Increase to a global footprint
Improve uptime `" downtime is loss of players
Increase efficiency of the cloud resources we use
Reduce latency to all customers

Technical Requirements -
Requirements for Game Backend Platform
Dynamically scale up or down based on game activity
Connect to a transactional database service to manage user profiles and game state
Store game activity in a timeseries database service for future analysis
As the system scales, ensure that data is not lost due to processing backlogs
Run hardened Linux distro
Requirements for Game Analytics Platform
Dynamically scale up or down based on game activity
Process incoming data on the fly directly from the game servers
Process data that arrives late because of slow mobile networks
Allow queries to access at least 10 TB of historical data
Process files that are regularly uploaded by users' mobile devices

Executive Statement -
Our last successful game did not scale well with our previous cloud provider, resulting in lower user adoption and affecting the game's reputation. Our investors want more key performance indicators (KPIs) to evaluate the speed and stability of the game, as well as other metrics that provide deeper insight into usage patterns so we can adapt the game to target users. Additionally, our current technology stack cannot provide the scale we need, so we want to replace MySQL and move to an environment that provides autoscaling, low latency load balancing, and frees us up from managing physical servers.

<a id="topics-98"></a>
## Contexto topics:98
name:
Topic 7

case_study_text:
Company overview -
Mountkirk Games makes online, session-based, multiplayer games for mobile platforms. They have recently started expanding to other platforms after successfully migrating their on-premises environments to Google Cloud.
Their most recent endeavor is to create a retro-style first-person shooter (FPS) game that allows hundreds of simultaneous players to join a geo-specific digital arena from multiple platforms and locations. A real-time digital banner will display a global leaderboard of all the top players across every active arena.

Solution concept -
Mountkirk Games is building a new multiplayer game that they expect to be very popular. They plan to deploy the game's backend on Google Kubernetes Engine so they can scale rapidly and use Google's global load balancer to route players to the closest regional game arenas. In order to keep the global leader board in sync, they plan to use a multi-region Spanner cluster.

Existing technical environment -
The existing environment was recently migrated to Google Cloud, and five games came across using lift-and-shift virtual machine migrations, with a few minor exceptions. Each new game exists in an isolated Google Cloud project nested below a folder that maintains most of the permissions and network policies. Legacy games with low traffic have been consolidated into a single project. There are also separate environments for development and testing.

Business requirements -
Support multiple gaming platforms.
Support multiple regions.
Support rapid iteration of game features.
Minimize latency.
Optimize for dynamic scaling.
Use managed services and pooled resources.
Minimize costs.

Technical requirements -
Dynamically scale based on game activity.
Publish scoring data on a near real-time global leaderboard.
Store game activity logs in structured files for future analysis.
Use GPU processing to render graphics server-side for multi-platform support.
Support eventual migration of legacy games to this new platform.

Executive statement -
Our last game was the first time we used Google Cloud, and it was a tremendous success. We were able to analyze player behavior and game telemetry in ways that we never could before. This success allowed us to bet on a full migration to the cloud and to start building all-new games using cloud-native design principles.
Our new game is our most ambitious to date and will open up doors for us to support more gaming platforms beyond mobile. Latency is our top priority, although cost management is the next most important challenge. As with our first cloud-based game, we have grown to expect the cloud to enable advanced analytics capabilities so we can rapidly iterate on our deployments of bug fixes and new functionality.

<a id="topics-99"></a>
## Contexto topics:99
name:
Topic 8

case_study_text:
Company Overview -
TerramEarth manufactures heavy equipment for the mining and agricultural industries: about 80% of their business is from mining and 20% from agriculture. They currently have over 500 dealers and service centers in 100 countries. Their mission is to build products that make their customers more productive.

Company background -
TerramEarth was formed in 1946, when several small, family owned companies combined to retool after World War II. The company cares about their employees and customers and considers them to be extended members of their family.
TerramEarth is proud of their ability to innovate on their core products and find new markets as their customers' needs change. For the past 20 years, trends in the industry have been largely toward increasing productivity by using larger vehicles with a human operator.

Solution Concept -
There are 20 million TerramEarth vehicles in operation that collect 120 fields of data per second. Data is stored locally on the vehicle and can be accessed for analysis when a vehicle is serviced. The data is downloaded via a maintenance port. This same port can be used to adjust operational parameters, allowing the vehicles to be upgraded in the field with new computing modules.
Approximately 200,000 vehicles are connected to a cellular network, allowing TerramEarth to collect data directly. At a rate of 120 fields of data per second with 22 hours of operation per day, Terram Earth collects a total of about 9 TB/day from these connected vehicles.

Existing Technical Environment -
[Imagen: sin descripción]
TerramEarth's existing architecture is composed of Linux-based systems that reside in a data center. These systems gzip CSV files from the field and upload via
FTP, transform and aggregate them, and place the data in their data warehouse. Because this process takes time, aggregated reports are based on data that is 3 weeks old.
With this data, TerramEarth has been able to preemptively stock replacement parts and reduce unplanned downtime of their vehicles by 60%. However, because the data is stale, some customers are without their vehicles for up to 4 weeks while they wait for replacement parts.

Business Requirements -
Decrease unplanned vehicle downtime to less than 1 week, without increasing the cost of carrying surplus inventory
Support the dealer network with more data on how their customers use their equipment to better position new products and services
Have the ability to partner with different companies `" especially with seed and fertilizer suppliers in the fast-growing agricultural business `" to create compelling joint offerings for their customers.

CEO Statement -
We have been successful in capitalizing on the trend toward larger vehicles to increase the productivity of our customers. Technological change is occurring rapidly, and TerramEarth has taken advantage of connected devices technology to provide our customers with better services, such as our intelligent farming equipment. With this technology, we have been able to increase farmers' yields by 25%, by using past trends to adjust how our vehicles operate. These advances have led to the rapid growth of our agricultural product line, which we expect will generate 50% of our revenues by 2020.

CTO Statement -
Our competitive advantage has always been in the manufacturing process, with our ability to build better vehicles for lower cost than our competitors. However, new products with different approaches are constantly being developed, and I'm concerned that we lack the skills to undergo the next wave of transformations in our industry. Unfortunately, our CEO doesn't take technology obsolescence seriously and he considers the many new companies in our industry to be niche players. My goals are to build our skills while addressing immediate market needs through incremental innovations.
Imagen · case_study_text · sin descripción
![Imagen original](imagenes/f14c7f261e72c48a2df3.png)
OCR: no_text_detected_unverified · Revisión visual pendiente.

<a id="topics-100"></a>
## Contexto topics:100
name:
Topic 9

case_study_text:
Company Overview -
TerramEarth manufactures heavy equipment for the mining and agricultural industries. About 80% of their business is from mining and 20% from agriculture. They currently have over 500 dealers and service centers in 100 countries. Their mission is to build products that make their customers more productive.

Solution Concept -
There are 20 million TerramEarth vehicles in operation that collect 120 fields of data per second. Data is stored locally on the vehicle and can be accessed for analysis when a vehicle is serviced. The data is downloaded via a maintenance port. This same port can be used to adjust operational parameters, allowing the vehicles to be upgraded in the field with new computing modules.
Approximately 200,000 vehicles are connected to a cellular network, allowing TerramEarth to collect data directly. At a rate of 120 fields of data per second, with
22 hours of operation per day, TerramEarth collects a total of about 9 TB/day from these connected vehicles.

Existing Technical Environment -
TerramEarth's existing architecture is composed of Linux and Windows-based systems that reside in a single U.S, west coast based data center. These systems gzip CSV files from the field and upload via FTP, and place the data in their data warehouse. Because this process takes time, aggregated reports are based on data that is 3 weeks old.
With this data, TerramEarth has been able to preemptively stock replacement parts and reduce unplanned downtime of their vehicles by 60%. However, because the data is stale, some customers are without their vehicles for up to 4 weeks while they wait for replacement parts.

Business Requirements -
Decrease unplanned vehicle downtime to less than 1 week
Support the dealer network with more data on how their customers use their equipment to better position new products and services
Have the ability to partner with different companies `" especially with seed and fertilizer suppliers in the fast-growing agricultural business `" to create compelling joint offerings for their customers

Technical Requirements -
Expand beyond a single datacenter to decrease latency to the American midwest and east coast
Create a backup strategy
Increase security of data transfer from equipment to the datacenter
Improve data in the data warehouse
Use customer and equipment data to anticipate customer needs

Application 1: Data ingest -
A custom Python application reads uploaded datafiles from a single server, writes to the data warehouse.
Compute:
Windows Server 2008 R2
- 16 CPUs
- 128 GB of RAM
- 10 TB local HDD storage

Application 2: Reporting -
An off the shelf application that business analysts use to run a daily report to see what equipment needs repair. Only 2 analysts of a team of 10 (5 west coast, 5 east coast) can connect to the reporting application at a time.
Compute:
Off the shelf application. License tied to number of physical CPUs
- Windows Server 2008 R2
- 16 CPUs
- 32 GB of RAM
- 500 GB HDD
Data warehouse:
A single PostgreSQL server
- RedHat Linux
- 64 CPUs
- 128 GB of RAM
- 4x 6TB HDD in RAID 0

Executive Statement -
Our competitive advantage has always been in our manufacturing process, with our ability to build better vehicles for lower cost than our competitors. However, new products with different approaches are constantly being developed, and I'm concerned that we lack the skills to undergo the next wave of transformations in our industry. My goals are to build our skills while addressing immediate market needs through incremental innovations.

<a id="topics-101"></a>
## Contexto topics:101
name:
Topic 10

case_study_text:
Company overview -
TerramEarth manufactures heavy equipment for the mining and agricultural industries. They currently have over 500 dealers and service centers in 100 countries.
Their mission is to build products that make their customers more productive.

Solution concept -
There are 2 million TerramEarth vehicles in operation currently, and we see 20% yearly growth. Vehicles collect telemetry data from many sensors during operation. A small subset of critical data is transmitted from the vehicles in real time to facilitate fleet management. The rest of the sensor data is collected, compressed, and uploaded daily when the vehicles return to home base. Each vehicle usually generates 200 to 500 megabytes of data per day.

Existing technical environment -
TerramEarth's vehicle data aggregation and analysis infrastructure resides in Google Cloud and serves clients from all around the world. A growing amount of sensor data is captured from their two main manufacturing plants and sent to private data centers that contain their legacy inventory and logistics management systems. The private data centers have multiple network interconnects configured to Google Cloud. The web frontend for dealers and customers is running in
Google Cloud and allows access to stock management and analytics.

Business requirements -
* Predict and detect vehicle malfunction and rapidly ship parts to dealerships for just-in-time repair where possible.
* Decrease cloud operational costs and adapt to seasonality.
* Increase speed and reliability of development workflow.
* Allow remote developers to be productive without compromising code or data security.
* Create a flexible and scalable platform for developers to create custom API services for dealers and partners.

Technical requirements -
* Create a new abstraction layer for HTTP API access to their legacy systems to enable a gradual move into the cloud without disrupting operations.
* Modernize all CI/CD pipelines to allow developers to deploy container-based workloads in highly scalable environments.
* Allow developers to run experiments without compromising security and governance requirements.
* Create a self-service portal for internal and partner developers to create new projects, request resources for data analytics jobs, and centrally manage access to the API endpoints.
* Use cloud-native solutions for keys and secrets management and optimize for identity-based access.
* Improve and standardize tools necessary for application and network monitoring and troubleshooting.

Executive statement -
Our competitive advantage has always been our focus on the customer, with our ability to provide excellent customer service and minimize vehicle downtimes.
After moving multiple systems into Google Cloud, we are seeking new ways to provide best-in-class online fleet management services to our customers and improve operations of our dealerships. Our 5-year strategic plan is to create a partner ecosystem of new products by enabling access to our data, increasing autonomous operation capabilities of our vehicles, and creating a path to move the remaining legacy systems to the cloud.

<a id="topics-102"></a>
## Contexto topics:102
name:
Topic 11

case_study_text:
Company Overview -
Dress4Win is a web-based company that helps their users organize and manage their personal wardrobe using a website and mobile application. The company also cultivates an active social network that connects their users with designers and retailers. They monetize their services through advertising, e-commerce, referrals, and a premium app model.

Company Background -
Dress4Win's application has grown from a few servers in the founder's garage to several hundred servers and appliances in a collocated data center. However, the capacity of their infrastructure is now insufficient for the application's rapid growth. Because of this growth and the company's desire to innovate faster,
Dress4Win is committing to a full migration to a public cloud.

Solution Concept -
For the first phase of their migration to the cloud, Dress4Win is considering moving their development and test environments. They are also considering building a disaster recovery site, because their current infrastructure is at a single location. They are not sure which components of their architecture they can migrate as is and which components they need to change before migrating them.

Existing Technical Environment -
The Dress4Win application is served out of a single data center location.
Databases:
- MySQL - user data, inventory, static data
- Redis - metadata, social graph, caching
Application servers:
- Tomcat - Java micro-services
- Nginx - static content
- Apache Beam - Batch processing
Storage appliances:
- iSCSI for VM hosts
- Fiber channel SAN - MySQL databases
- NAS - image storage, logs, backups
Apache Hadoop/Spark servers:
- Data analysis
- Real-time trending calculations
MQ servers:
- Messaging
- Social notifications
- Events
Miscellaneous servers:
- Jenkins, monitoring, bastion hosts, security scanners

Business Requirements -
Build a reliable and reproducible environment with scaled parity of production.
[Imagen: sin descripción]
Improve security by defining and adhering to a set of security and Identity and Access Management (IAM) best practices for cloud.
Improve business agility and speed of innovation through rapid provisioning of new resources.
Analyze and optimize architecture for performance in the cloud.
Migrate fully to the cloud if all other requirements are met.

Technical Requirements -
Evaluate and choose an automation framework for provisioning resources in cloud.
Support failover of the production environment to cloud during an emergency.
Identify production services that can migrate to cloud to save capacity.
Use managed services whenever possible.
Encrypt data on the wire and at rest.
Support multiple VPN connections between the production data center and cloud environment.

CEO Statement -
Our investors are concerned about our ability to scale and contain costs with our current infrastructure. They are also concerned that a new competitor could use a public cloud platform to offset their up-front investment and freeing them to focus on developing better features.

CTO Statement -
We have invested heavily in the current infrastructure, but much of the equipment is approaching the end of its useful life. We are consistently waiting weeks for new gear to be racked before we can start new projects. Our traffic patterns are highest in the mornings and weekend evenings; during other times, 80% of our capacity is sitting idle.

CFO Statement -
Our capital expenditure is now exceeding our quarterly projections. Migrating to the cloud will likely cause an initial increase in spending, but we expect to fully transition before our next hardware refresh cycle. Our total cost of ownership (TCO) analysis over the next 5 years puts a cloud strategy between 30 to 50% lower than our current model.
Imagen · case_study_text · sin descripción
![Imagen original](imagenes/3076ff4279f1e5061d75.png)
OCR: no_text_detected_unverified · Revisión visual pendiente.

<a id="topics-103"></a>
## Contexto topics:103
name:
Topic 12

case_study_text:
Company Overview -
Dress4Win is a web-based company that helps their users organize and manage their personal wardrobe using a web app and mobile application. The company also cultivates an active social network that connects their users with designers and retailers. They monetize their services through advertising, e-commerce, referrals, and a freemium app model. The application has grown from a few servers in the founder's garage to several hundred servers and appliances in a colocated data center. However, the capacity of their infrastructure is now insufficient for the application's rapid growth. Because of this growth and the company's desire to innovate faster, Dress4Win is committing to a full migration to a public cloud.

Solution Concept -
For the first phase of their migration to the cloud, Dress4Win is moving their development and test environments. They are also building a disaster recovery site, because their current infrastructure is at a single location. They are not sure which components of their architecture they can migrate as is and which components they need to change before migrating them.

Existing Technical Environment -
The Dress4Win application is served out of a single data center location. All servers run Ubuntu LTS v16.04.
Databases:
MySQL. 1 server for user data, inventory, static data:
- MySQL 5.8
- 8 core CPUs
- 128 GB of RAM
- 2x 5 TB HDD (RAID 1)
Redis 3 server cluster for metadata, social graph, caching. Each server is:
- Redis 3.2
- 4 core CPUs
- 32GB of RAM
Compute:
40 Web Application servers providing micro-services based APIs and static content.
`"
- Tomcat

Java -
- Nginx
- 4 core CPUs
- 32 GB of RAM
20 Apache Hadoop/Spark servers:
- Data analysis
- Real-time trending calculations
- 8 core CPUs
- 128 GB of RAM
- 4x 5 TB HDD (RAID 1)
3 RabbitMQ servers for messaging, social notifications, and events:
- 8 core CPUs
- 32GB of RAM
Miscellaneous servers:
- Jenkins, monitoring, bastion hosts, security scanners
- 8 core CPUs
- 32GB of RAM
Storage appliances:
iSCSI for VM hosts
Fiber channel SAN `" MySQL databases
- 1 PB total storage; 400 TB available
NAS `" image storage, logs, backups
- 100 TB total storage; 35 TB available

Business Requirements -
Build a reliable and reproducible environment with scaled parity of production.
Improve security by defining and adhering to a set of security and Identity and Access Management (IAM) best practices for cloud.
Improve business agility and speed of innovation through rapid provisioning of new resources.
Analyze and optimize architecture for performance in the cloud.

Technical Requirements -
Easily create non-production environments in the cloud.
Implement an automation framework for provisioning resources in cloud.
Implement a continuous deployment process for deploying applications to the on-premises datacenter or cloud.
Support failover of the production environment to cloud during an emergency.
Encrypt data on the wire and at rest.
Support multiple private connections between the production data center and cloud environment.

Executive Statement -
Our investors are concerned about our ability to scale and contain costs with our current infrastructure. They are also concerned that a competitor could use a public cloud platform to offset their up-front investment and free them to focus on developing better features. Our traffic patterns are highest in the mornings and weekend evenings; during other times, 80% of our capacity is sitting idle.
Our capital expenditure is now exceeding our quarterly projections. Migrating to the cloud will likely cause an initial increase in spending, but we expect to fully transition before our next hardware refresh cycle. Our total cost of ownership (TCO) analysis over the next 5 years for a public cloud strategy achieves a cost reduction between 30% and 50% over our current model.


## Pregunta 1

Contexto: [topics:92](#topics-92)
Your company has decided to make a major revision of their API in order to create better experiences for their developers. They need to keep the old version of the API available and deployable, while allowing new customers and testers to try out the new API. They want to keep the same SSL and DNS records in place to serve both APIs.
What should they do?

**A.** Configure a new load balancer for the new version of the API

**B.** Reconfigure old clients to use a new endpoint for the new API

**C.** Have the old API forward traffic to the new API based on the path

**D.** Use separate backend pools for each API path behind the load balancer

**Respuesta de la fuente:** D

**Explicación:** Using separate backend pools for each API path allows the load balancer to route traffic based on URL paths while maintaining a single IP address, SSL certificate, and DNS record. This satisfies the requirement to keep existing configuration intact while supporting parallel deployment of both API versions.

## Pregunta 2

Contexto: [topics:92](#topics-92)
Your company plans to migrate a multi-petabyte data set to the cloud. The data set must be available 24hrs a day. Your business analysts have experience only with using a SQL interface.
How should you store the data to optimize it for ease of analysis?

**A.** Load data into Google BigQuery

**B.** Insert data into Google Cloud SQL

**C.** Put flat files into Google Cloud Storage

**D.** Stream data into Google Cloud Datastore

**Respuesta de la fuente:** A

**Explicación:** BigQuery is the correct choice because it is a serverless data warehouse specifically designed for analyzing massive datasets (petabyte-scale) using standard SQL, aligning with the analysts' skills.
In contrast, Cloud SQL is an OLTP database that does not scale effectively to petabytes and is unsuitable for heavy analytical workloads, while Cloud Storage lacks native SQL query capabilities without additional tools.

## Pregunta 3

Contexto: [topics:92](#topics-92)
The operations manager asks you for a list of recommended practices that she should consider when migrating a J2EE application to the cloud.
Which three practices should you recommend? (Choose three.)

**A.** Port the application code to run on Google App Engine

**B.** Integrate Cloud Dataflow into the application to capture real-time metrics

**C.** Instrument the application with a monitoring tool like Stackdriver Debugger

**D.** Select an automation framework to reliably provision the cloud infrastructure

**E.** Deploy a continuous integration tool with automated testing in a staging environment

**F.** Migrate from MySQL to a managed NoSQL database like Google Cloud Datastore or Bigtable

**Respuesta de la fuente:** C, D, E

**Explicación:** The correct practices focus on universal cloud migration strategies rather than specific vendor lock-in steps.
Instrumenting with monitoring tools (C) ensures visibility and reliability in the new environment, while automation frameworks (D) enable consistent, reliable infrastructure provisioning essential for cloud scalability.
Implementing CI/CD with automated testing (E) guarantees code quality and stability during the transition process.

## Pregunta 4

Contexto: [topics:92](#topics-92)
A news feed web service has the following code running on Google App Engine. During peak load, users report that they can see news articles they already viewed.
What is the most likely cause of this problem?
[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/4ce30aba71fc77480182.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
import news
from flask import Flask, redirect, request
from flask.ext.api import status
from google.appengine.api import users
app = Flask(_name_)
sessions = {}
Gapp. route ("/”)
def homepage ():
user = users.get_current_user()
if not user:
return “Invalid login”,
status.HTTP_401_UNAUTHORIZED
if user not in session
sessions[user] = {“viewed”: []}
news_articles = news.get_new_news (user, sessions [user]
(viewed”])
sessions [user] [“viewed”] +- [n["id”] for n
in news_articles]
return news. render (news_articles)
if _name, main”:
app. run ()
```

**A.** The session variable is local to just a single instance

**B.** The session variable is being overwritten in Cloud Datastore

**C.** The URL of the API needs to be modified to prevent caching

**D.** The HTTP Expires header needs to be set to -1 stop caching

**Respuesta de la fuente:** A

**Explicación:** Google App Engine automatically scales by spinning up new instances to handle peak traffic, routing requests from the same user to different instances. Since the `sessions` variable is stored in local memory (in-memory dictionary), it is not shared across these instances. Consequently, when a request lands on a different instance that lacks the user's session history, previously viewed articles are shown again.

## Pregunta 5

Contexto: [topics:92](#topics-92)
An application development team believes their current logging tool will not meet their needs for their new cloud-based product. They want a better tool to capture errors and help them analyze their historical log data. You want to help them find a solution that meets their needs.
What should you do?

**A.** Direct them to download and install the Google StackDriver logging agent

**B.** Send them a list of online resources about logging best practices

**C.** Help them define their requirements and assess viable logging tools

**D.** Help them upgrade their current tool to take advantage of any new features

**Respuesta de la fuente:** C

**Explicación:** As a cloud architect, the primary responsibility is to understand specific business and technical requirements before recommending a solution.
The question states the team believes their current tool is insufficient but does not define precise metrics (e.g., retention periods, volume, integration needs), making it premature to select a specific tool like Stackdriver or suggest an upgrade.
Option C correctly prioritizes defining these requirements to ensure the selected logging solution effectively addresses error capture and historical analysis needs.

## Pregunta 6

Contexto: [topics:92](#topics-92)
You need to reduce the number of unplanned rollbacks of erroneous production deployments in your company's web hosting platform. Improvement to the QA/
Test processes accomplished an 80% reduction.
Which additional two approaches can you take to further reduce the rollbacks? (Choose two.)

**A.** Introduce a green-blue deployment model

**B.** Replace the QA environment with canary releases

**C.** Fragment the monolithic platform into microservices

**D.** Reduce the platform's dependency on relational database systems

**E.** Replace the platform's relational database systems with a NoSQL database

**Respuesta de la fuente:** A, C

**Explicación:** Blue-green deployment (A) allows for instant rollback by switching traffic between two identical environments, directly mitigating the impact of erroneous releases.
Fragmenting a monolithic platform into microservices (C) reduces the blast radius of failures and simplifies isolated testing, further decreasing the likelihood of system-wide rollbacks.

## Pregunta 7

Contexto: [topics:92](#topics-92)
To reduce costs, the Director of Engineering has required all developers to move their development infrastructure resources from on-premises virtual machines
(VMs) to Google Cloud Platform. These resources go through multiple start/stop events during the day and require state to persist. You have been asked to design the process of running a development environment in Google Cloud while providing cost visibility to the finance department.
Which two steps should you take? (Choose two.)

**A.** Use the - -no-auto-delete flag on all persistent disks and stop the VM

**B.** Use the - -auto-delete flag on all persistent disks and terminate the VM

**C.** Apply VM CPU utilization label and include it in the BigQuery billing export

**D.** Use Google BigQuery billing export and labels to associate cost to groups

**E.** Store all state into local SSD, snapshot the persistent disks, and terminate the VM

**F.** Store all state in Google Cloud Storage, snapshot the persistent disks, and terminate the VM

**Respuesta de la fuente:** A, D

**Explicación:** Option A is correct because using the `--no-auto-delete` flag ensures that persistent disks are retained when VMs are stopped or deleted, satisfying the requirement for state persistence.
Option D is correct because exporting billing data to BigQuery and applying labels allows the finance department to aggregate and analyze costs by specific groups or teams, providing the required cost visibility.

## Pregunta 8

Contexto: [topics:92](#topics-92)
Your company wants to track whether someone is present in a meeting room reserved for a scheduled meeting. There are 1000 meeting rooms across 5 offices on 3 continents. Each room is equipped with a motion sensor that reports its status every second. The data from the motion detector includes only a sensor ID and several different discrete items of information. Analysts will use this data, together with information about account owners and office locations.
Which database type should you use?

**A.** Flat file

**B.** NoSQL

**C.** Relational

**D.** Blobstore

**Respuesta de la fuente:** B

**Explicación:** The scenario involves high-volume IoT data (1 million records per second) with a semi-structured schema ('several different discrete items'). NoSQL databases, such as Bigtable or Cloud Datastore, are designed for this type of unstructured or semi-structured time-series data, offering the necessary horizontal scalability and write performance.
Relational databases struggle with this volume and schema flexibility, while flat files lack query capability and blobstores are unsuitable for structured sensor metadata.

## Pregunta 9

Contexto: [topics:92](#topics-92)
You set up an autoscaling instance group to serve web traffic for an upcoming launch. After configuring the instance group as a backend service to an HTTP(S) load balancer, you notice that virtual machine (VM) instances are being terminated and re-launched every minute. The instances do not have a public IP address.
You have verified the appropriate web response is coming from each instance using the curl command. You want to ensure the backend is configured correctly.
What should you do?

**A.** Ensure that a firewall rules exists to allow source traffic on HTTP/HTTPS to reach the load balancer.

**B.** Assign a public IP to each instance and configure a firewall rule to allow the load balancer to reach the instance public IP.

**C.** Ensure that a firewall rule exists to allow load balancer health checks to reach the instances in the instance group.

**D.** Create a tag on each instance with the name of the load balancer. Configure a firewall rule with the name of the load balancer as the source and the instance tag as the destination.

**Respuesta de la fuente:** C

**Explicación:** The cyclical termination and relaunching of VMs indicate that the health checks are failing, causing the autoscaler to replace instances it considers unhealthy.
Since you confirmed the web application is responding correctly via curl, the issue lies in network access for the load balancer's health check probes rather than the application itself.
Firewall rules must explicitly allow inbound traffic from Google Cloud's health check IP ranges (130.211.0.0/22 and 35.191.0.0/16) to ensure the load balancer can reach the backend instances.

## Pregunta 10

Contexto: [topics:92](#topics-92)
You write a Python script to connect to Google BigQuery from a Google Compute Engine virtual machine. The script is printing errors that it cannot connect to
BigQuery.
What should you do to fix the script?

**A.** Install the latest BigQuery API client library for Python

**B.** Run your script on a new virtual machine with the BigQuery access scope enabled

**C.** Create a new service account with BigQuery access and execute your script with that user

**D.** Install the bq component for gcloud with the command gcloud components install bq.

**Respuesta de la fuente:** C

**Explicación:** Creating a dedicated service account with the appropriate BigQuery IAM roles aligns with Google Cloud best practices for application authentication, ensuring least-privilege access.
While default Compute Engine metadata-based scopes (Option B) are a legacy mechanism and often restricted or deprecated, using a specific service account provides explicit, manageable, and secure permissions for the script.

## Pregunta 11

Contexto: [topics:92](#topics-92)
Your customer is moving an existing corporate application to Google Cloud Platform from an on-premises data center. The business owners require minimal user disruption. There are strict security team requirements for storing passwords.
What authentication strategy should they use?

**A.** Use G Suite Password Sync to replicate passwords into Google

**B.** Federate authentication via SAML 2.0 to the existing Identity Provider

**C.** Provision users in Google using the Google Cloud Directory Sync tool

**D.** Ask users to set their Google password to match their corporate password

**Respuesta de la fuente:** B

**Explicación:** Federating authentication via SAML 2.0 (Option B) ensures that password storage and validation remain with the on-premises Identity Provider, satisfying strict security requirements against storing passwords in Google Cloud. This approach also minimizes user disruption by allowing Single Sign-On (SSO), so users continue using their existing corporate credentials without needing to manage separate passwords or undergo a migration of credential data.

## Pregunta 12

Contexto: [topics:92](#topics-92)
Your company has successfully migrated to the cloud and wants to analyze their data stream to optimize operations. They do not have any existing code for this analysis, so they are exploring all their options. These options include a mix of batch and stream processing, as they are running some hourly jobs and live- processing some data as it comes in.
Which technology should they use for this?

**A.** Google Cloud Dataproc

**B.** Google Cloud Dataflow

**C.** Google Container Engine with Bigtable

**D.** Google Compute Engine with Google BigQuery

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Dataflow is the optimal choice because it provides a unified service for both batch and stream processing within a single API.
This directly addresses the requirement to handle hourly jobs and live data ingestion without maintaining existing code or managing complex infrastructure like Dataproc clusters.

## Pregunta 13

Contexto: [topics:92](#topics-92)
Your customer is receiving reports that their recently updated Google App Engine application is taking approximately 30 seconds to load for some of their users.
This behavior was not reported before the update.
What strategy should you take?

**A.** Work with your ISP to diagnose the problem

**B.** Open a support ticket to ask for network capture and flow data to diagnose the problem, then roll back your application

**C.** Roll back to an earlier known good release initially, then use Stackdriver Trace and Logging to diagnose the problem in a development/test/staging environment

**D.** Roll back to an earlier known good release, then push the release again at a quieter period to investigate. Then use Stackdriver Trace and Logging to diagnose the problem

**Respuesta de la fuente:** C

**Explicación:** Since the latency issue began immediately after a deployment, the highest priority is to restore service stability by rolling back to the last known good version.
Investigating in a development or staging environment using Stackdriver Trace and Logging allows you to diagnose root causes safely without impacting production users or risking further downtime.

## Pregunta 14

Contexto: [topics:92](#topics-92)
A production database virtual machine on Google Compute Engine has an ext4-formatted persistent disk for data files. The database is about to run out of storage space.
How can you remediate the problem with the least amount of downtime?

**A.** In the Cloud Platform Console, increase the size of the persistent disk and use the resize2fs command in Linux.

**B.** Shut down the virtual machine, use the Cloud Platform Console to increase the persistent disk size, then restart the virtual machine

**C.** In the Cloud Platform Console, increase the size of the persistent disk and verify the new space is ready to use with the fdisk command in Linux

**D.** In the Cloud Platform Console, create a new persistent disk attached to the virtual machine, format and mount it, and configure the database service to move the files to the new disk

**E.** In the Cloud Platform Console, create a snapshot of the persistent disk restore the snapshot to a new larger disk, unmount the old disk, mount the new disk and restart the database service

**Respuesta de la fuente:** A

**Explicación:** Google Compute Engine supports resizing persistent disks online while the virtual machine is running, eliminating the need for downtime associated with shutting down or restarting the instance.
Once the disk size is increased via the console, the ext4 file system must be expanded using the `resize2fs` command, which can be executed on a mounted filesystem to make the new space immediately available.
Other options involve unnecessary reboots (B, E) or incorrect tools like `fdisk`, which manages partition tables rather than resizing existing ext4 volumes (C).

## Pregunta 15

Contexto: [topics:92](#topics-92)
Your application needs to process credit card transactions. You want the smallest scope of Payment Card Industry (PCI) compliance without compromising the ability to analyze transactional data and trends relating to which payment methods are used.
How should you design your architecture?

**A.** Create a tokenizer service and store only tokenized data

**B.** Create separate projects that only process credit card data

**C.** Create separate subnetworks and isolate the components that process credit card data

**D.** Streamline the audit discovery phase by labeling all of the virtual machines (VMs) that process PCI data

**E.** Enable Logging export to Google BigQuery and use ACLs and views to scope the data shared with the auditor

**Respuesta de la fuente:** A

**Explicación:** Tokenization replaces sensitive Primary Account Numbers (PANs) with non-sensitive equivalents called tokens, which are outside the scope of PCI DSS.
By storing only tokenized data for analysis, you significantly reduce the number of systems handling sensitive cardholder data, thereby minimizing compliance scope while preserving the ability to analyze transaction trends.

## Pregunta 16

Contexto: [topics:92](#topics-92)
You have been asked to select the storage system for the click-data of your company's large portfolio of websites. This data is streamed in from a custom website analytics package at a typical rate of 6,000 clicks per minute. With bursts of up to 8,500 clicks per second. It must have been stored for future analysis by your data science and user experience teams.
Which storage infrastructure should you choose?

**A.** Google Cloud SQL

**B.** Google Cloud Bigtable

**C.** Google Cloud Storage

**D.** Google Cloud Datastore

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Bigtable is the optimal choice because it is a managed NoSQL database designed specifically for high-throughput, low-latency workloads involving large-scale time-series and event data like clickstreams.

It can easily handle the specified write volume of up to 8,500 clicks per second with bursts, whereas Cloud SQL would struggle with such high write concurrency, Cloud Storage lacks structured query capabilities for analysis, and Datastore is less suitable for this specific high-velocity ingestion pattern.

## Pregunta 17

Contexto: [topics:92](#topics-92)
You are creating a solution to remove backup files older than 90 days from your backup Cloud Storage bucket. You want to optimize ongoing Cloud Storage spend.
What should you do?

**A.** Write a lifecycle management rule in XML and push it to the bucket with gsutil

**B.** Write a lifecycle management rule in JSON and push it to the bucket with gsutil

**C.** Schedule a cron script using gsutil ls —lr gs://backups/** to find and remove items older than 90 days

**D.** Schedule a cron script using gsutil ls —l gs://backups/** to find and remove items older than 90 days and schedule it with cron

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Cloud Storage lifecycle management configurations must be defined in JSON format when using the `gsutil` command-line tool. Implementing a native lifecycle rule automatically handles object deletion based on age, which is more cost-effective and reliable than managing custom cron scripts (Options C and D). Option A is incorrect because `gsutil` does not accept XML for this specific operation.

## Pregunta 18

Contexto: [topics:92](#topics-92)
Your company is forecasting a sharp increase in the number and size of Apache Spark and Hadoop jobs being run on your local datacenter. You want to utilize the cloud to help you scale this upcoming demand with the least amount of operations work and code change.
Which product should you use?

**A.** Google Cloud Dataflow

**B.** Google Cloud Dataproc

**C.** Google Compute Engine

**D.** Google Kubernetes Engine

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Dataproc is the managed service specifically designed to run Apache Spark and Hadoop jobs.
It allows you to leverage existing code with minimal operational overhead by handling cluster management and scaling automatically.

## Pregunta 19

Contexto: [topics:92](#topics-92)
The database administration team has asked you to help them improve the performance of their new database server running on Google Compute Engine. The database is for importing and normalizing their performance statistics and is built with MySQL running on Debian Linux. They have an n1-standard-8 virtual machine with 80 GB of SSD persistent disk.
What should they change to get better performance from this system?

**A.** Increase the virtual machine's memory to 64 GB

**B.** Create a new virtual machine running PostgreSQL

**C.** Dynamically resize the SSD persistent disk to 500 GB

**D.** Migrate their performance metrics warehouse to BigQuery

**E.** Modify all of their batch jobs to use bulk inserts into the database

**Respuesta de la fuente:** C

**Explicación:** On Google Compute Engine, the IOPS and throughput of an SSD persistent disk are directly determined by its size (up to a maximum cap defined by the instance type). By increasing the disk size from 80 GB to 500 GB, the available IOPS increases significantly (from ~2,400 to ~15,000), which directly improves database performance for import and normalization tasks without requiring a VM shutdown or migration. Increasing memory alone (Option A) does not increase disk IOPS, and migrating to BigQuery (Option D) is an architectural change rather than a direct performance tuning of the existing MySQL server.

## Pregunta 20

Contexto: [topics:92](#topics-92)
You want to optimize the performance of an accurate, real-time, weather-charting application. The data comes from 50,000 sensors sending 10 readings a second, in the format of a timestamp and sensor reading.
Where should you store the data?

**A.** Google BigQuery

**B.** Google Cloud SQL

**C.** Google Cloud Bigtable

**D.** Google Cloud Storage

**Respuesta de la fuente:** C

**Explicación:** Google Cloud Bigtable is the correct choice because it is a NoSQL database designed for high-throughput, low-latency ingestion of massive datasets, making it ideal for real-time IoT time-series data.
Unlike relational databases (Cloud SQL) which struggle with such high write volumes, or analytics warehouses (BigQuery) and storage systems (GCS) which are optimized for batch processing rather than real-time random access, Bigtable efficiently handles the 500,000 writes per second required by the sensor network.

## Pregunta 21

Contexto: [topics:92](#topics-92)
Your company's user-feedback portal comprises a standard LAMP stack replicated across two zones. It is deployed in the us-central1 region and uses autoscaled managed instance groups on all layers, except the database. Currently, only a small group of select customers have access to the portal. The portal meets a
99,99% availability SLA under these conditions. However next quarter, your company will be making the portal available to all users, including unauthenticated users. You need to develop a resiliency testing strategy to ensure the system maintains the SLA once they introduce additional user load.
What should you do?

**A.** Capture existing users input, and replay captured user load until autoscale is triggered on all layers. At the same time, terminate all resources in one of the zones

**B.** Create synthetic random user input, replay synthetic load until autoscale logic is triggered on at least one layer, and introduce "chaos" to the system by terminating random resources on both zones

**C.** Expose the new system to a larger group of users, and increase group size each day until autoscale logic is triggered on all layers. At the same time, terminate random resources on both zones

**D.** Capture existing users input, and replay captured user load until resource utilization crosses 80%. Also, derive estimated number of users based on existing user's usage of the app, and deploy enough resources to handle 200% of expected load

**Respuesta de la fuente:** B

**Explicación:** Resilience testing focuses on validating system behavior during failure conditions, which requires introducing chaos (resource termination) rather than just measuring load. Option B is correct because it simulates realistic failures across both zones using synthetic load that accounts for the new unauthenticated traffic profile, ensuring the SLA holds under unexpected stress. Option A is insufficient as it only tests single-zone loss and relies on outdated user patterns, while D describes capacity planning rather than resilience testing.

## Pregunta 22

Contexto: [topics:92](#topics-92)
One of the developers on your team deployed their application in Google Container Engine with the Dockerfile below. They report that their application deployments are taking too long.
[Imagen: sin descripción]
You want to optimize this Dockerfile for faster deployment times without adversely affecting the app's functionality.
Which two actions should you take? (Choose two.)
Imagen · question_text · sin descripción
![Imagen original](imagenes/0722ecab9a02ee9e5738.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
FROM ubuntu:16.
copy . /sre
RUN apt-get update && apt-get install -y python python-pip
RUN pip install -r requirements.txt
```

**A.** Remove Python after running pip

**B.** Remove dependencies from requirements.txt

**C.** Use a slimmed-down base image like Alpine Linux

**D.** Use larger machine types for your Google Container Engine node pools

**E.** Copy the source after he package dependencies (Python and pip) are installed

**Respuesta de la fuente:** C, E

**Explicación:** Using a slimmed-down base image like Alpine Linux (C) significantly reduces the overall container size, leading to faster download and deployment times.
Copying source code after installing dependencies (E) leverages Docker's layer caching mechanism; since application code changes more frequently than requirements, this ensures dependency installation layers are reused during rebuilds.

## Pregunta 23

Contexto: [topics:92](#topics-92)
Your solution is producing performance bugs in production that you did not see in staging and test environments. You want to adjust your test and deployment procedures to avoid this problem in the future.
What should you do?

**A.** Deploy fewer changes to production

**B.** Deploy smaller changes to production

**C.** Increase the load on your test and staging environments

**D.** Deploy changes to a small subset of users before rolling out to production

**Respuesta de la fuente:** C

**Explicación:** Performance bugs that appear in production but not in staging are typically caused by differences in traffic volume or concurrency levels.
Increasing the load on test and staging environments ensures these non-functional requirements are validated before a full production rollout,
thereby catching performance issues during the testing phase as requested.

## Pregunta 24

Contexto: [topics:92](#topics-92)
A small number of API requests to your microservices-based application take a very long time. You know that each request to the API can traverse many services.
You want to know which service takes the longest in those cases.
What should you do?

**A.** Set timeouts on your application so that you can fail requests faster

**B.** Send custom metrics for each of your requests to Stackdriver Monitoring

**C.** Use Stackdriver Monitoring to look for insights that show when your API latencies are high

**D.** Instrument your application with Stackdriver Trace in order to break down the request latencies at each microservice

**Respuesta de la fuente:** D

**Explicación:** Stackdriver Trace (now Cloud Trace) is a distributed tracing system designed to visualize request paths across microservices.
It breaks down latency at each service hop, allowing you to identify the specific bottleneck causing slow API responses.
Monitoring and timeouts manage symptoms or aggregate data but do not provide the granular service-level breakdown needed here.

## Pregunta 25

Contexto: [topics:92](#topics-92)
During a high traffic portion of the day, one of your relational databases crashes, but the replica is never promoted to a master. You want to avoid this in the future.
What should you do?

**A.** Use a different database

**B.** Choose larger instances for your database

**C.** Create snapshots of your database more regularly

**D.** Implement routinely scheduled failovers of your databases

**Respuesta de la fuente:** D

**Explicación:** The core issue is that the replica failed to promote during a critical failure, indicating a potential flaw in the automated failover configuration or health checks.
Routine scheduled failovers allow administrators to proactively test the promotion process and validate that the replica correctly assumes the master role before a real crisis occurs.
While scaling up (Option B) might prevent resource-based crashes, it does not address the specific operational failure of the promotion mechanism itself.

## Pregunta 26

Contexto: [topics:92](#topics-92)
Your organization requires that metrics from all applications be retained for 5 years for future analysis in possible legal proceedings.
Which approach should you use?

**A.** Grant the security team access to the logs in each Project

**B.** Configure Stackdriver Monitoring for all Projects, and export to BigQuery

**C.** Configure Stackdriver Monitoring for all Projects with the default retention policies

**D.** Configure Stackdriver Monitoring for all Projects, and export to Google Cloud Storage

**Respuesta de la fuente:** D

**Explicación:** Options A and C are incorrect because Stackdriver Logging/Monitoring default retention is only 30 days, which fails the 5-year requirement.
Option D is the best choice because exporting to Google Cloud Storage (specifically using Archive or Coldline classes) provides a cost-effective solution for long-term data retention required for legal proceedings.
While BigQuery (Option B) supports analysis, it is generally more expensive for passive archival storage of large volumes of historical data compared to Cloud Storage.

## Pregunta 27

Contexto: [topics:92](#topics-92)
Your company has decided to build a backup replica of their on-premises user authentication PostgreSQL database on Google Cloud Platform. The database is 4
TB, and large updates are frequent. Replication requires private address space communication.
Which networking approach should you use?

**A.** Google Cloud Dedicated Interconnect

**B.** Google Cloud VPN connected to the data center network

**C.** A NAT and TLS translation gateway installed on-premises

**D.** A Google Compute Engine instance with a VPN server installed connected to the data center network

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Dedicated Interconnect is the correct choice because it provides a direct, private physical connection between on-premises infrastructure and GCP.
This ensures high bandwidth and low latency required for replicating a large (4 TB) database with frequent updates, while keeping traffic off the public internet to satisfy the private address space requirement.
VPN solutions traverse the public internet, which poses security risks and potential bandwidth limitations for such heavy data loads.

## Pregunta 28

Contexto: [topics:92](#topics-92)
Auditors visit your teams every 12 months and ask to review all the Google Cloud Identity and Access Management (Cloud IAM) policy changes in the previous 12 months. You want to streamline and expedite the analysis and audit process.
What should you do?

**A.** Create custom Google Stackdriver alerts and send them to the auditor

**B.** Enable Logging export to Google BigQuery and use ACLs and views to scope the data shared with the auditor

**C.** Use cloud functions to transfer log entries to Google Cloud SQL and use ACLs and views to limit an auditor's view

**D.** Enable Google Cloud Storage (GCS) log export to audit logs into a GCS bucket and delegate access to the bucket

**Respuesta de la fuente:** B

**Explicación:** To streamline and expedite the audit process, you need a tool that allows for rapid querying and analysis of large datasets, which Cloud Storage buckets do not provide efficiently. BigQuery enables auditors to run SQL queries against exported logs directly, significantly reducing the time required to review IAM policy changes compared to downloading or parsing raw files from GCS.
Reference: Google Cloud documentation on audit logging scenarios recommends BigQuery for interactive analysis and streamlining audits.

## Pregunta 29

Contexto: [topics:92](#topics-92)
You are designing a large distributed application with 30 microservices. Each of your distributed microservices needs to connect to a database back-end. You want to store the credentials securely.
Where should you store the credentials?

**A.** In the source code

**B.** In an environment variable

**C.** In a secret management system

**D.** In a config file that has restricted access through ACLs

**Respuesta de la fuente:** C

**Explicación:** A secret management system is the industry standard for securing credentials in distributed architectures because it provides centralized storage, encryption at rest, and fine-grained access controls.
Unlike source code or config files, it prevents accidental exposure through version control and simplifies credential rotation without redeploying services.
Environment variables are less secure as they can be exposed via process listings, making a dedicated secret manager the most robust choice for protecting sensitive data.

## Pregunta 30

Contexto: [topics:92](#topics-92)
A lead engineer wrote a custom tool that deploys virtual machines in the legacy data center. He wants to migrate the custom tool to the new cloud environment.
You want to advocate for the adoption of Google Cloud Deployment Manager.
What are two business risks of migrating to Cloud Deployment Manager? (Choose two.)

**A.** Cloud Deployment Manager uses Python

**B.** Cloud Deployment Manager APIs could be deprecated in the future

**C.** Cloud Deployment Manager is unfamiliar to the company's engineers

**D.** Cloud Deployment Manager requires a Google APIs service account to run

**E.** Cloud Deployment Manager can be used to permanently delete cloud resources

**F.** Cloud Deployment Manager only supports automation of Google Cloud resources

**Respuesta de la fuente:** C, F

**Explicación:** Choice C represents a business risk because migrating to an unfamiliar tool introduces a learning curve, leading to potential deployment errors and productivity loss during the transition period. Choice F is a business risk related to vendor lock-in and strategic flexibility; since Deployment Manager only supports Google Cloud resources, it cannot automate hybrid or multi-cloud infrastructure, potentially forcing the company to maintain legacy tools or adopt additional solutions for non-GCP assets.

## Pregunta 31

Contexto: [topics:92](#topics-92)
A development manager is building a new application. He asks you to review his requirements and identify what cloud technologies he can use to meet them. The application must:
1. Be based on open-source technology for cloud portability
2. Dynamically scale compute capacity based on demand
3. Support continuous software delivery
4. Run multiple segregated copies of the same application stack
5. Deploy application bundles using dynamic templates
6. Route network traffic to specific services based on URL
Which combination of technologies will meet all of his requirements?

**A.** Google Kubernetes Engine, Jenkins, and Helm

**B.** Google Kubernetes Engine and Cloud Load Balancing

**C.** Google Kubernetes Engine and Cloud Deployment Manager

**D.** Google Kubernetes Engine, Jenkins, and Cloud Load Balancing

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Helm satisfies the specific requirement to 'deploy application bundles using dynamic templates' via its chart templating engine.
Jenkins addresses the need for 'continuous software delivery' through CI/CD pipelines.
Google Kubernetes Engine (GKE) handles open-source portability, dynamic scaling, segregated copies via namespaces, and URL-based routing via Ingress resources.

## Pregunta 32

Contexto: [topics:92](#topics-92)
You have created several pre-emptible Linux virtual machine instances using Google Compute Engine. You want to properly shut down your application before the virtual machines are preempted.
What should you do?

**A.** Create a shutdown script named k99.shutdown in the /etc/rc.6.d/ directory

**B.** Create a shutdown script registered as a xinetd service in Linux and configure a Stackdriver endpoint check to call the service

**C.** Create a shutdown script and use it as the value for a new metadata entry with the key shutdown-script in the Cloud Platform Console when you create the new virtual machine instance

**D.** Create a shutdown script, registered as a xinetd service in Linux, and use the gcloud compute instances add-metadata command to specify the service URL as the value for a new metadata entry with the key shutdown-script-url

**Respuesta de la fuente:** C

**Explicación:** Google Compute Engine executes shutdown scripts specified via instance metadata keys like `shutdown-script` or `shutdown-script-url` when an instance is preempted.
Option C correctly uses the `shutdown-script` key to provide script contents directly, which works for both new and existing instances (via `gcloud compute instances add-metadata`).
Option D is incorrect because `shutdown-script-url` requires a Cloud Storage URL, not an internal xinetd service URL.

## Pregunta 33

Contexto: [topics:92](#topics-92)
Your organization has a 3-tier web application deployed in the same network on Google Cloud Platform. Each tier (web, API, and database) scales independently of the others. Network traffic should flow through the web to the API tier and then on to the database tier. Traffic should not flow between the web and the database tier.
How should you configure the network?

**A.** Add each tier to a different subnetwork

**B.** Set up software based firewalls on individual VMs

**C.** Add tags to each tier and set up routes to allow the desired traffic flow

**D.** Add tags to each tier and set up firewall rules to allow the desired traffic flow

**Respuesta de la fuente:** D

**Explicación:** Network segmentation in GCP is primarily enforced using VPC firewall rules rather than just subnetwork boundaries. By assigning network tags to each tier and configuring specific ingress/egress firewall rules, you can explicitly allow traffic from Web to API and API to Database while denying direct communication between Web and Database. Routing only determines the path of packets and does not provide the access control necessary to block unwanted traffic flows.

## Pregunta 34

Contexto: [topics:92](#topics-92)
Your development team has installed a new Linux kernel module on the batch servers in Google Compute Engine (GCE) virtual machines (VMs) to speed up the nightly batch process. Two days after the installation, 50% of the batch servers failed the nightly batch run. You want to collect details on the failure to pass back to the development team.
Which three actions should you take? (Choose three.)

**A.** Use Stackdriver Logging to search for the module log entries

**B.** Read the debug GCE Activity log using the API or Cloud Console

**C.** Use gcloud or Cloud Console to connect to the serial console and observe the logs

**D.** Identify whether a live migration event of the failed server occurred, using in the activity log

**E.** Adjust the Google Stackdriver timeline to match the failure time, and observe the batch server metrics

**F.** Export a debug VM into an image, and run the image on a local server where kernel log messages will be displayed on the native screen

**Respuesta de la fuente:** A, C, E

**Explicación:** No conservada en esta captura.

## Pregunta 35

Contexto: [topics:92](#topics-92)
Your company wants to try out the cloud with low risk. They want to archive approximately 100 TB of their log data to the cloud and test the analytics features available to them there, while also retaining that data as a long-term disaster recovery backup.
Which two steps should you take? (Choose two.)

**A.** Load logs into Google BigQuery

**B.** Load logs into Google Cloud SQL

**C.** Import logs into Google Stackdriver

**D.** Insert logs into Google Cloud Bigtable

**E.** Upload log files into Google Cloud Storage

**Respuesta de la fuente:** A, E

**Explicación:** Google Cloud Storage is the appropriate solution for archiving 100 TB of log data as a long-term disaster recovery backup due to its durability, scalability, and cost-effective storage classes like Coldline or Archive. Google BigQuery should be used to load the logs for analytics because it is a serverless, highly scalable data warehouse designed specifically for analyzing large datasets efficiently.

## Pregunta 36

Contexto: [topics:92](#topics-92)
You created a pipeline that can deploy your source code changes to your infrastructure in instance groups for self-healing. One of the changes negatively affects your key performance indicator. You are not sure how to fix it, and investigation could take up to a week.
What should you do?

**A.** Log in to a server, and iterate on the fox locally

**B.** Revert the source code change, and rerun the deployment pipeline

**C.** Log into the servers with the bad code change, and swap in the previous code

**D.** Change the instance group template to the previous one, and delete all instances

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it adheres to the principle of treating infrastructure as code by reverting the change at its source (the repository).
This ensures that any subsequent pipeline executions or deployments will not reintroduce the broken code, maintaining consistency between the source of truth and the deployed infrastructure.
Manual interventions like Options A and C violate automation best practices, while Option D creates state inconsistency between the instance group configuration and the version control system.

## Pregunta 37

Contexto: [topics:92](#topics-92)
Your organization wants to control IAM policies for different departments independently, but centrally.
Which approach should you take?

**A.** Multiple Organizations with multiple Folders

**B.** Multiple Organizations, one for each department

**C.** A single Organization with Folders for each department

**D.** A single Organization with multiple projects, each with a central owner

**Respuesta de la fuente:** C

**Explicación:** A single Organization with Folders (Choice C) is the correct approach because folders allow you to group resources and apply IAM policies at an intermediate level between the organization root and individual projects. This structure enables centralized governance through organization policies while granting departments independent administrative control over their specific folder and its contained projects.

Using multiple organizations (Choices A and B) creates silos that complicate centralized management, and modeling departments as single projects (Choice D) limits each department to only one project, which is typically insufficient for real-world needs.

## Pregunta 38

Contexto: [topics:92](#topics-92)
You deploy your custom Java application to Google App Engine. It fails to deploy and gives you the following stack trace.
What should you do?
[Imagen: sin descripción]
Imagen · question_text · sin descripción
![Imagen original](imagenes/bd10155238fd39676838.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
java.lang.SecurityException: SHAl digest error for
com/Altostrat/Cloakedservlet.class
at com.google.appengine. runtime. Request process
-d36f818a24b8cfld (Request. java)
at
sun.security.util.ManifestEntryVerifier.verify
(Mani festEntryVeri fier. java:210)
at java.util. jar.JarvVerifier.processEntry
(Jarverifier.java:218)
at java.util. jar.JarvVerifier.update
(Jarverifier.java:205)
at
java.util. jar.JarvVerifiersverifierstream. read
(Jarverifier.java:428)
at sun.misc.Resource.getBytes
(Resource. java:124)
at java.net .URL.ClassLoader.defineClass
(URLClassLoader. java:273)
at sun.reflect .GeneratedMethodAccessorS. invoke
(Unknown Source)
at
sun. reflect .DelegatingMethodAccessorImp1. invoke
(DelegatingMethodAccessorImpl. java: 43)
at java.lang.reflect Method. invoke
(Method. java: 616)
at java.lang.ClassLoader.loadClass
(ClassLoader. java:266)
```

**A.** Upload missing JAR files and redeploy your application.

**B.** Digitally sign all of your JAR files and redeploy your application

**C.** Recompile the CLoakedServlet class using and MD5 hash instead of SHA1

**Respuesta de la fuente:** B

**Explicación:** The error trace indicates a `java.security.SignatureException` with an invalid SHA1 digest, which signifies that the JAR file's digital signature does not match its contents. This usually occurs when a JAR is modified after being signed or if the signature metadata is corrupt. To resolve this integrity mismatch, you must digitally sign all JAR files again to ensure the signatures are valid and consistent with the deployed code.

## Pregunta 39

Contexto: [topics:92](#topics-92)
You are designing a mobile chat application. You want to ensure people cannot spoof chat messages, by providing a message were sent by a specific user.
What should you do?

**A.** Tag messages client side with the originating user identifier and the destination user.

**B.** Encrypt the message client side using block-based encryption with a shared key.

**C.** Use public key infrastructure (PKI) to encrypt the message client side using the originating user's private key.

**D.** Use a trusted certificate authority to enable SSL connectivity between the client application and the server.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because using the originating user's private key to encrypt (sign) a message provides non-repudiation and integrity. Only the holder of the private key could have performed this operation, ensuring the recipient can verify the specific user's identity via the corresponding public key.

Option A is insecure as client-side tags are easily modified. Option B fails because shared keys do not provide unique originator identification (non-repudiation). Option D secures the transport channel but does not inherently bind the message content to a specific sender within the application layer.

## Pregunta 40

Contexto: [topics:92](#topics-92)
As part of implementing their disaster recovery plan, your company is trying to replicate their production MySQL database from their private data center to their
GCP project using a Google Cloud VPN connection. They are experiencing latency issues and a small amount of packet loss that is disrupting the replication.
What should they do?

**A.** Configure their replication to use UDP.

**B.** Configure a Google Cloud Dedicated Interconnect.

**C.** Restore their database daily using Google Cloud SQL.

**D.** Add additional VPN connections and load balance them.

**E.** Send the replicated transaction to Google Cloud Pub/Sub.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Dedicated Interconnect provides a private, Layer 2 connection with higher throughput, lower latency, and greater consistency than an IPsec VPN over the public internet.
This dedicated physical link eliminates the packet loss and latency issues caused by the unpredictable nature of the public network.

## Pregunta 41

Contexto: [topics:92](#topics-92)
Your customer support tool logs all email and chat conversations to Cloud Bigtable for retention and analysis. What is the recommended approach for sanitizing this data of personally identifiable information or payment card information before initial storage?

**A.** Hash all data using SHA256

**B.** Encrypt all data using elliptic curve cryptography

**C.** De-identify the data with the Cloud Data Loss Prevention API

**D.** Use regular expressions to find and redact phone numbers, email addresses, and credit card numbers

**Respuesta de la fuente:** C

**Explicación:** The Cloud Data Loss Prevention (DLP) API is the recommended Google Cloud service for automatically discovering, classifying, and de-identifying sensitive data like PII and payment card information.
Unlike manual regex approaches, it uses advanced inspection templates to accurately detect and redact sensitive content with high precision.
Hashing or encrypting data does not sanitize it by removing identifiers, whereas DLP specifically performs the required de-identification before storage.

## Pregunta 42

Contexto: [topics:92](#topics-92)
You are using Cloud Shell and need to install a custom utility for use in a few weeks. Where can you store the file so it is in the default execution path and persists across sessions?

**A.** ~/bin

**B.** Cloud Storage

**C.** /google/scripts

**D.** /usr/local/bin

**Respuesta de la fuente:** A

**Explicación:** Cloud Shell provides a persistent 5GB disk mounted at the $HOME directory, which survives session restarts.
Placing files in ~/bin ensures they are stored on this persistent volume and are automatically included in the user's PATH environment variable for easy execution.

## Pregunta 43

Contexto: [topics:92](#topics-92)
You want to create a private connection between your instances on Compute Engine and your on-premises data center. You require a connection of at least 20
Gbps. You want to follow Google-recommended practices. How should you set up the connection?

**A.** Create a VPC and connect it to your on-premises data center using Dedicated Interconnect.

**B.** Create a VPC and connect it to your on-premises data center using a single Cloud VPN.

**C.** Create a Cloud Content Delivery Network (Cloud CDN) and connect it to your on-premises data center using Dedicated Interconnect.

**D.** Create a Cloud Content Delivery Network (Cloud CDN) and connect it to your on-premises datacenter using a single Cloud VPN.

**Respuesta de la fuente:** A

**Explicación:** Dedicated Interconnect provides a private, high-bandwidth physical connection supporting speeds up to 100 Gbps, which satisfies the requirement of at least 20 Gbps.
Cloud VPN is unsuitable for this bandwidth level, as it typically caps at lower throughput (often cited around 3-30 Gbps depending on configuration) and traverses the public internet.
Cloud CDN is a content distribution service, not a method for establishing site-to-site network connectivity between on-premises data centers and Compute Engine instances.

## Pregunta 44

Contexto: [topics:92](#topics-92)
You are analyzing and defining business processes to support your startup's trial usage of GCP, and you don't yet know what consumer demand for your product will be. Your manager requires you to minimize GCP service costs and adhere to Google best practices. What should you do?

**A.** Utilize free tier and sustained use discounts. Provision a staff position for service cost management.

**B.** Utilize free tier and sustained use discounts. Provide training to the team about service cost management.

**C.** Utilize free tier and committed use discounts. Provision a staff position for service cost management.

**D.** Utilize free tier and committed use discounts. Provide training to the team about service cost management.

**Respuesta de la fuente:** B

**Explicación:** Sustained Use Discounts are automatic and ideal for unpredictable workloads during a trial phase, whereas Committed Use Discounts require long-term commitments unsuited to unknown demand.
Providing training empowers the existing team to manage costs effectively without the financial burden of provisioning a dedicated staff position for a startup.

## Pregunta 45

Contexto: [topics:92](#topics-92)
You are building a continuous deployment pipeline for a project stored in a Git source repository and want to ensure that code changes can be verified before deploying to production. What should you do?

**A.** Use Spinnaker to deploy builds to production using the red/black deployment strategy so that changes can easily be rolled back.

**B.** Use Spinnaker to deploy builds to production and run tests on production deployments.

**C.** Use Jenkins to build the staging branches and the master branch. Build and deploy changes to production for 10% of users before doing a complete rollout.

**D.** Use Jenkins to monitor tags in the repository. Deploy staging tags to a staging environment for testing. After testing, tag the repository for production and deploy that to the production environment.

**Respuesta de la fuente:** D

**Explicación:** The requirement is to verify changes *before* deploying to production. Option D describes a process where code is deployed to a staging environment for testing prior to the final production deployment, which directly satisfies this constraint.
Other options either deploy directly to production (A, B, C) or perform verification on live production traffic, failing the 'before' condition.

## Pregunta 46

Contexto: [topics:92](#topics-92)
You have an outage in your Compute Engine managed instance group: all instances keep restarting after 5 seconds. You have a health check configured, but autoscaling is disabled. Your colleague, who is a Linux expert, offered to look into the issue. You need to make sure that he can access the VMs. What should you do?

**A.** Grant your colleague the IAM role of project Viewer

**B.** Perform a rolling restart on the instance group

**C.** Disable the health check for the instance group. Add his SSH key to the project-wide SSH Keys

**D.** Disable autoscaling for the instance group. Add his SSH key to the project-wide SSH Keys

**Respuesta de la fuente:** C

**Explicación:** The instances are restarting because the health check is failing, which causes the managed instance group to terminate and recreate them, preventing any persistent SSH connection. Disabling the health check stops this automatic recreation cycle, allowing the VMs to remain running long enough for troubleshooting. Adding the colleague's SSH key to project-wide metadata grants the necessary OS-level access to log in to the instances.

## Pregunta 47

Contexto: [topics:92](#topics-92)
Your company is migrating its on-premises data center into the cloud. As part of the migration, you want to integrate Google Kubernetes Engine (GKE) for workload orchestration. Parts of your architecture must also be PCI DSS-compliant. Which of the following is most accurate?

**A.** App Engine is the only compute platform on GCP that is certified for PCI DSS hosting.

**B.** GKE cannot be used under PCI DSS because it is considered shared hosting.

**C.** GKE and GCP provide the tools you need to build a PCI DSS-compliant environment.

**D.** All Google Cloud services are usable because Google Cloud Platform is certified PCI-compliant.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because GCP operates under a shared responsibility model where Google secures the underlying infrastructure (including GKE), but the customer must configure security controls to meet PCI DSS requirements.
Options A and B are incorrect because GKE is not restricted from PCI DSS use, nor is App Engine the only certified platform.
Option D is inaccurate because GCP certification does not automatically render all services usable in a compliant environment without proper customer-side configuration.

## Pregunta 48

Contexto: [topics:92](#topics-92)
Your company has multiple on-premises systems that serve as sources for reporting. The data has not been maintained well and has become degraded over time.
You want to use Google-recommended practices to detect anomalies in your company data. What should you do?

**A.** Upload your files into Cloud Storage. Use Cloud Datalab to explore and clean your data.

**B.** Upload your files into Cloud Storage. Use Cloud Dataprep to explore and clean your data.

**C.** Connect Cloud Datalab to your on-premises systems. Use Cloud Datalab to explore and clean your data.

**D.** Connect Cloud Dataprep to your on-premises systems. Use Cloud Dataprep to explore and clean your data.

**Respuesta de la fuente:** B

**Explicación:** Cloud Dataprep is the Google-recommended tool for visually exploring, cleaning, and detecting anomalies in data due to its built-in profiling features.
Cloud Dataprep does not support direct connections to on-premises systems; it requires data to be ingested via supported sources like Cloud Storage first.
Therefore, uploading files to Cloud Storage before using Dataprep is the correct workflow, whereas options involving direct on-prem connectivity or Datalab (which lacks OOTB anomaly detection) are incorrect.

## Pregunta 49

Contexto: [topics:92](#topics-92)
Google Cloud Platform resources are managed hierarchically using organization, folders, and projects. When Cloud Identity and Access Management (IAM) policies exist at these different levels, what is the effective policy at a particular node of the hierarchy?

**A.** The effective policy is determined only by the policy set at the node

**B.** The effective policy is the policy set at the node and restricted by the policies of its ancestors

**C.** The effective policy is the union of the policy set at the node and policies inherited from its ancestors

**D.** The effective policy is the intersection of the policy set at the node and policies inherited from its ancestors

**Respuesta de la fuente:** C

**Explicación:** In Google Cloud IAM, resources inherit allow policies from their parent nodes in the hierarchy (Organization, Folder, Project).
The effective policy at a specific node is calculated as the union of the policies set directly on that node and all policies inherited from its ancestors.
This means permissions granted at higher levels are combined with local permissions, ensuring access is additive rather than restrictive.

## Pregunta 50

Contexto: [topics:92](#topics-92)
You are migrating your on-premises solution to Google Cloud in several phases. You will use Cloud VPN to maintain a connection between your on-premises systems and Google Cloud until the migration is completed. You want to make sure all your on-premise systems remain reachable during this period. How should you organize your networking in Google Cloud?

**A.** Use the same IP range on Google Cloud as you use on-premises

**B.** Use the same IP range on Google Cloud as you use on-premises for your primary IP range and use a secondary range that does not overlap with the range you use on-premises

**C.** Use an IP range on Google Cloud that does not overlap with the range you use on-premises

**D.** Use an IP range on Google Cloud that does not overlap with the range you use on-premises for your primary IP range and use a secondary range with the same IP range as you use on-premises

**Respuesta de la fuente:** C

**Explicación:** To establish a Cloud VPN connection between on-premises networks and Google Cloud, the IP address ranges must not overlap.
If primary or secondary subnets in the VPC share IP addresses with on-premises systems, routing ambiguity prevents proper connectivity.
Therefore, you must use an IP range on Google Cloud that is distinct from your on-premises network.

## Pregunta 51

Contexto: [topics:92](#topics-92)
You have found an error in your App Engine application caused by missing Cloud Datastore indexes. You have created a YAML file with the required indexes and want to deploy these new indexes to Cloud Datastore. What should you do?

**A.** Point gcloud datastore create-indexes to your configuration file

**B.** Upload the configuration file to App Engine's default Cloud Storage bucket, and have App Engine detect the new indexes

**C.** In the GCP Console, use Datastore Admin to delete the current indexes and upload the new configuration file

**D.** Create an HTTP request to the built-in python module to send the index configuration file to your application

**Respuesta de la fuente:** A

**Explicación:** To deploy new Cloud Datastore indexes defined in a YAML file, you must use the Google Cloud SDK command line tool.
The correct procedure is to run `gcloud datastore create-indexes` and point it to your local index configuration file (typically `index.yaml`).
This command explicitly instructs the service to build the specified composite indexes.

## Pregunta 52

Contexto: [topics:92](#topics-92)
You have an application that will run on Compute Engine. You need to design an architecture that takes into account a disaster recovery plan that requires your application to fail over to another region in case of a regional outage. What should you do?

**A.** Deploy the application on two Compute Engine instances in the same project but in a different region. Use the first instance to serve traffic, and use the HTTP load balancing service to fail over to the standby instance in case of a disaster.

**B.** Deploy the application on a Compute Engine instance. Use the instance to serve traffic, and use the HTTP load balancing service to fail over to an instance on your premises in case of a disaster.

**C.** Deploy the application on two Compute Engine instance groups, each in the same project but in a different region. Use the first instance group to serve traffic, and use the HTTP load balancing service to fail over to the standby instance group in case of a disaster.

**D.** Deploy the application on two Compute Engine instance groups, each in a separate project and a different region. Use the first instance group to serve traffic, and use the HTTP load balancing service to fail over to the standby instance group in case of a disaster.

**Respuesta de la fuente:** C

**Explicación:** HTTP Load Balancing in Google Cloud requires backend services to be configured with Instance Groups; you cannot attach individual Compute Engine instances directly to an external HTTP load balancer.
Therefore, options A and B are technically invalid because they attempt to use standalone instances as backends.
Option C is the correct architectural choice because it utilizes Managed Instance Groups (MIGs) in different regions within the same project, ensuring proper health checking, traffic routing, and consistent management for disaster recovery failover.

## Pregunta 53

Contexto: [topics:92](#topics-92)
You are deploying an application on App Engine that needs to integrate with an on-premises database. For security purposes, your on-premises database must not be accessible through the public internet. What should you do?

**A.** Deploy your application on App Engine standard environment and use App Engine firewall rules to limit access to the open on-premises database.

**B.** Deploy your application on App Engine standard environment and use Cloud VPN to limit access to the on-premises database.

**C.** Deploy your application on App Engine flexible environment and use App Engine firewall rules to limit access to the on-premises database.

**D.** Deploy your application on App Engine flexible environment and use Cloud VPN to limit access to the on-premises database.

**Respuesta de la fuente:** D

**Explicación:** App Engine Flexible environment instances run within the Compute Engine network, allowing direct connectivity to VPC resources such as Cloud VPN tunnels. This enables secure access to on-premises databases without exposing them to the public internet, which App Engine Standard (in the context of this legacy question) could not do directly.

## Pregunta 54

Contexto: [topics:92](#topics-92)
You are working in a highly secured environment where public Internet access from the Compute Engine VMs is not allowed. You do not yet have a VPN connection to access an on-premises file server. You need to install specific software on a Compute Engine instance. How should you install the software?

**A.** Upload the required installation files to Cloud Storage. Configure the VM on a subnet with a Private Google Access subnet. Assign only an internal IP address to the VM. Download the installation files to the VM using gsutil.

**B.** Upload the required installation files to Cloud Storage and use firewall rules to block all traffic except the IP address range for Cloud Storage. Download the files to the VM using gsutil.

**C.** Upload the required installation files to Cloud Source Repositories. Configure the VM on a subnet with a Private Google Access subnet. Assign only an internal IP address to the VM. Download the installation files to the VM using gcloud.

**D.** Upload the required installation files to Cloud Source Repositories and use firewall rules to block all traffic except the IP address range for Cloud Source Repositories. Download the files to the VM using gsutil.

**Respuesta de la fuente:** A

**Explicación:** The environment prohibits public Internet access, making Private Google Access the required mechanism for the VM to reach Cloud Storage via internal IP only.
Cloud Storage is designed for general file hosting and supports gsutil for transfers, whereas Cloud Source Repositories is a source control system unsuitable for binary installation files.

## Pregunta 55

Contexto: [topics:92](#topics-92)
Your company is moving 75 TB of data into Google Cloud. You want to use Cloud Storage and follow Google-recommended practices. What should you do?

**A.** Move your data onto a Transfer Appliance. Use a Transfer Appliance Rehydrator to decrypt the data into Cloud Storage.

**B.** Move your data onto a Transfer Appliance. Use Cloud Dataprep to decrypt the data into Cloud Storage.

**C.** Install gsutil on each server that contains data. Use resumable transfers to upload the data into Cloud Storage.

**D.** Install gsutil on each server containing data. Use streaming transfers to upload the data into Cloud Storage.

**Respuesta de la fuente:** A

**Explicación:** Google recommends the Transfer Appliance for offline transfers when the data volume is large (typically >10-20 TB) or when network transfer would take longer than a week, which applies to this 75 TB scenario.
The appliance hardware includes a built-in rehydrator process to decrypt and upload the data directly to Cloud Storage upon arrival at the Google datacenter.
Options using gsutil (C and D) are less efficient for this volume due to potential network latency and cost, while Cloud Dataprep (B) is an ETL tool, not a migration decryption utility.

## Pregunta 56

Contexto: [topics:92](#topics-92)
You have an application deployed on Google Kubernetes Engine using a Deployment named echo-deployment. The deployment is exposed using a Service called echo-service. You need to perform an update to the application with minimal downtime to the application. What should you do?

**A.** Use kubectl set image deployment/echo-deployment <new-image>

**B.** Use the rolling update functionality of the Instance Group behind the Kubernetes cluster

**C.** Update the deployment yaml file with the new container image. Use kubectl delete deployment/echo-deployment and kubectl create —f <yaml-file>

**D.** Update the service yaml file which the new container image. Use kubectl delete service/echo-service and kubectl create —f <yaml-file>

**Respuesta de la fuente:** A

**Explicación:** The `kubectl set image` command directly updates the container image in the Deployment specification, which automatically triggers a rolling update strategy.
This default strategy ensures that existing Pods remain available while new ones are created, resulting in minimal downtime as required by the scenario.

## Pregunta 57

Contexto: [topics:92](#topics-92)
Your company is using BigQuery as its enterprise data warehouse. Data is distributed over several Google Cloud projects. All queries on BigQuery need to be billed on a single project. You want to make sure that no query costs are incurred on the projects that contain the data. Users should be able to query the datasets, but not edit them.
How should you configure users' access roles?

**A.** Add all users to a group. Grant the group the role of BigQuery user on the billing project and BigQuery dataViewer on the projects that contain the data.

**B.** Add all users to a group. Grant the group the roles of BigQuery dataViewer on the billing project and BigQuery user on the projects that contain the data.

**C.** Add all users to a group. Grant the group the roles of BigQuery jobUser on the billing project and BigQuery dataViewer on the projects that contain the data.

**D.** Add all users to a group. Grant the group the roles of BigQuery dataViewer on the billing project and BigQuery jobUser on the projects that contain the data.

**Respuesta de la fuente:** C

**Explicación:** Assigning BigQuery jobUser to the billing project allows users to run queries billed to that project without granting unnecessary permissions to create or modify datasets.

Assigning BigQuery dataViewer to the data projects provides read-only access to the tables, ensuring users cannot edit the data.

This combination satisfies the requirements for centralized billing and least-privilege access.

## Pregunta 58

Contexto: [topics:92](#topics-92)
You have developed an application using Cloud ML Engine that recognizes famous paintings from uploaded images. You want to test the application and allow specific people to upload images for the next 24 hours. Not all users have a Google Account. How should you have users upload images?

**A.** Have users upload the images to Cloud Storage. Protect the bucket with a password that expires after 24 hours.

**B.** Have users upload the images to Cloud Storage using a signed URL that expires after 24 hours.

**C.** Create an App Engine web application where users can upload images. Configure App Engine to disable the application after 24 hours. Authenticate users via Cloud Identity.

**D.** Create an App Engine web application where users can upload images for the next 24 hours. Authenticate users via Cloud Identity.

**Respuesta de la fuente:** B

**Explicación:** Signed URLs provide temporary, authenticated access to Cloud Storage objects without requiring users to have Google Accounts or manage credentials. This fits the requirement for non-Google Account users and allows precise control via a 24-hour expiration timestamp.
Cloud Storage buckets do not support password protection with time-based expiration (Option A), making signed URLs the correct mechanism for secure, time-limited access.

## Pregunta 59

Contexto: [topics:92](#topics-92)
Your web application must comply with the requirements of the European Union's General Data Protection Regulation (GDPR). You are responsible for the technical architecture of your web application. What should you do?

**A.** Ensure that your web application only uses native features and services of Google Cloud Platform, because Google already has various certifications and provides "pass-on" compliance when you use native features.

**B.** Enable the relevant GDPR compliance setting within the GCPConsole for each of the services in use within your application.

**C.** Ensure that Cloud Security Scanner is part of your test planning strategy in order to pick up any compliance gaps.

**D.** Define a design for the security of data in your web application that meets GDPR requirements.

**Respuesta de la fuente:** D

**Explicación:** GDPR compliance is a shared responsibility; while GCP provides infrastructure security certifications, the customer must design their application architecture to meet specific data protection requirements like encryption and access controls.
Option D correctly identifies that defining a compliant data security design is the primary architectural task, whereas the other options are either insufficient alone or technically inaccurate.

## Pregunta 60

Contexto: [topics:92](#topics-92)
You need to set up Microsoft SQL Server on GCP. Management requires that there's no downtime in case of a data center outage in any of the zones within a
GCP region. What should you do?

**A.** Configure a Cloud SQL instance with high availability enabled.

**B.** Configure a Cloud Spanner instance with a regional instance configuration.

**C.** Set up SQL Server on Compute Engine, using Always On Availability Groups using Windows Failover Clustering. Place nodes in different subnets.

**D.** Set up SQL Server Always On Availability Groups using Windows Failover Clustering. Place nodes in different zones.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 61

Contexto: [topics:92](#topics-92)
The development team has provided you with a Kubernetes Deployment file. You have no infrastructure yet and need to deploy the application. What should you do?

**A.** Use gcloud to create a Kubernetes cluster. Use Deployment Manager to create the deployment.

**B.** Use gcloud to create a Kubernetes cluster. Use kubectl to create the deployment.

**C.** Use kubectl to create a Kubernetes cluster. Use Deployment Manager to create the deployment.

**D.** Use kubectl to create a Kubernetes cluster. Use kubectl to create the deployment.

**Respuesta de la fuente:** B

**Explicación:** In Google Cloud, the gcloud CLI is used to provision infrastructure resources like GKE clusters, whereas kubectl is the standard tool for interacting with Kubernetes APIs to create workloads such as Deployments.
Deployment Manager is for provisioning GCP resources and does not handle Kubernetes object creation directly, making option B the correct workflow.

## Pregunta 62

Contexto: [topics:92](#topics-92)
You need to evaluate your team readiness for a new GCP project. You must perform the evaluation and create a skills gap plan which incorporates the business goal of cost optimization. Your team has deployed two GCP projects successfully to date. What should you do?

**A.** Allocate budget for team training. Set a deadline for the new GCP project.

**B.** Allocate budget for team training. Create a roadmap for your team to achieve Google Cloud certification based on job role.

**C.** Allocate budget to hire skilled external consultants. Set a deadline for the new GCP project.

**D.** Allocate budget to hire skilled external consultants. Create a roadmap for your team to achieve Google Cloud certification based on job role.

**Respuesta de la fuente:** B

**Explicación:** The requirement to create a 'skills gap plan' necessitates a structured evaluation of current competencies against best practices.
Creating a roadmap for role-based certification provides this framework and ensures the team learns specific cost optimization techniques, whereas simply setting a deadline does not address skill deficiencies.

## Pregunta 63

Contexto: [topics:92](#topics-92)
You are designing an application for use only during business hours. For the minimum viable product release, you'd like to use a managed product that automatically `scales to zero` so you don't incur costs when there is no activity.
Which primary compute resource should you choose?

**A.** Cloud Functions

**B.** Compute Engine

**C.** Google Kubernetes Engine

**D.** AppEngine flexible environment

**Respuesta de la fuente:** A

**Explicación:** Cloud Functions is a fully managed serverless compute service that supports scaling to zero instances when there are no requests, eliminating costs during inactivity.
Compute Engine requires manual management or instance scheduling and does not scale to zero automatically by default.
Google Kubernetes Engine incurs control plane costs even if node pools scale down, as at least one node is typically required for system pods.
App Engine Flexible Environment maintains a minimum of one instance running at all times to reduce latency, preventing it from scaling to zero.

## Pregunta 64

Contexto: [topics:92](#topics-92)
You are creating an App Engine application that uses Cloud Datastore as its persistence layer. You need to retrieve several root entities for which you have the identifiers. You want to minimize the overhead in operations performed by Cloud Datastore. What should you do?

**A.** Create the Key object for each Entity and run a batch get operation

**B.** Create the Key object for each Entity and run multiple get operations, one operation for each entity

**C.** Use the identifiers to create a query filter and run a batch query operation

**D.** Use the identifiers to create a query filter and run multiple query operations, one operation for each entity

**Respuesta de la fuente:** A

**Explicación:** To minimize overhead when entity keys or identifiers are already known, you should use a batch get operation rather than queries.

Batching multiple lookups into a single API call significantly reduces network latency and server-side processing costs compared to individual get operations.

Using query filters (Options C and D) is inefficient here because the specific entities are already identified by key, making direct retrieval faster and cheaper than scanning indexes.

## Pregunta 65

Contexto: [topics:92](#topics-92)
You need to upload files from your on-premises environment to Cloud Storage. You want the files to be encrypted on Cloud Storage using customer-supplied encryption keys. What should you do?

**A.** Supply the encryption key in a .boto configuration file. Use gsutil to upload the files.

**B.** Supply the encryption key using gcloud config. Use gsutil to upload the files to that bucket.

**C.** Use gsutil to upload the files, and use the flag --encryption-key to supply the encryption key.

**D.** Use gsutil to create a bucket, and use the flag --encryption-key to supply the encryption key. Use gsutil to upload the files to that bucket.

**Respuesta de la fuente:** A

**Explicación:** To use Customer-Supplied Encryption Keys (CSEK) with gsutil, you must configure the encryption key in the .boto configuration file.
The --encryption-key flag is specific to the gcloud storage command and is not supported by gsutil, making Option C incorrect despite similar syntax.

## Pregunta 66

Contexto: [topics:92](#topics-92)
Your customer wants to capture multiple GBs of aggregate real-time key performance indicators (KPIs) from their game servers running on Google Cloud Platform and monitor the KPIs with low latency. How should they capture the KPIs?

**A.** Store time-series data from the game servers in Google Bigtable, and view it using Google Data Studio.

**B.** Output custom metrics to Stackdriver from the game servers, and create a Dashboard in Stackdriver Monitoring Console to view them.

**C.** Schedule BigQuery load jobs to ingest analytics files uploaded to Cloud Storage every ten minutes, and visualize the results in Google Data Studio.

**D.** Insert the KPIs into Cloud Datastore entities, and run ad hoc analysis and visualizations of them in Cloud Datalab.

**Respuesta de la fuente:** B

**Explicación:** The requirement for low-latency monitoring of real-time KPIs is best met by Stackdriver Monitoring (now Cloud Monitoring), which is purpose-built for collecting custom metrics and providing immediate visualization via dashboards.
Other options like BigQuery or Data Studio are designed for batch analytics or historical reporting, introducing latency that violates the real-time constraint.

## Pregunta 67

Contexto: [topics:92](#topics-92)
You have a Python web application with many dependencies that requires 0.1 CPU cores and 128 MB of memory to operate in production. You want to monitor and maximize machine utilization. You also want to reliably deploy new versions of the application. Which set of steps should you take?

**A.** Perform the following: 1. Create a managed instance group with f1-micro type machines. 2. Use a startup script to clone the repository, check out the production branch, install the dependencies, and start the Python app. 3. Restart the instances to automatically deploy new production releases.

**B.** Perform the following: 1. Create a managed instance group with n1-standard-1 type machines. 2. Build a Compute Engine image from the production branch that contains all of the dependencies and automatically starts the Python app. 3. Rebuild the Compute Engine image, and update the instance template to deploy new production releases.

**C.** Perform the following: 1. Create a Google Kubernetes Engine (GKE) cluster with n1-standard-1 type machines. 2. Build a Docker image from the production branch with all of the dependencies, and tag it with the version number. 3. Create a Kubernetes Deployment with the imagePullPolicy set to 'IfNotPresent' in the staging namespace, and then promote it to the production namespace after testing.

**D.** Perform the following: 1. Create a GKE cluster with n1-standard-4 type machines. 2. Build a Docker image from the master branch with all of the dependencies, and tag it with 'latest'. 3. Create a Kubernetes Deployment in the default namespace with the imagePullPolicy set to 'Always'. Restart the pods to automatically deploy new production releases.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google Kubernetes Engine (GKE) allows precise resource specification via container limits (0.1 CPU, 128 MB), maximizing machine utilization by packing multiple pods onto nodes, unlike rigid VM instance types.
Using semantic versioning for Docker images ensures reliable deployments and reproducibility, whereas using 'latest' tags or startup scripts is less stable.
Staging in a separate namespace before promotion provides a safe testing environment, aligning with best practices for reliable release management.

## Pregunta 68

Contexto: [topics:92](#topics-92)
Your company wants to start using Google Cloud resources but wants to retain their on-premises Active Directory domain controller for identity management.
What should you do?

**A.** Use the Admin Directory API to authenticate against the Active Directory domain controller.

**B.** Use Google Cloud Directory Sync to synchronize Active Directory usernames with cloud identities and configure SAML SSO.

**C.** Use Cloud Identity-Aware Proxy configured to use the on-premises Active Directory domain controller as an identity provider.

**D.** Use Compute Engine to create an Active Directory (AD) domain controller that is a replica of the on-premises AD domain controller using Google Cloud Directory Sync.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Directory Sync (GCDS) is the recommended tool for synchronizing on-premises Active Directory identities with Google Workspace or Cloud Identity accounts.
By combining GCDS with SAML Single Sign-On (SSO), the organization retains its AD as the source of truth while allowing users to authenticate seamlessly against Google Cloud resources without duplicating directory infrastructure.

## Pregunta 69

Contexto: [topics:92](#topics-92)
You are running a cluster on Kubernetes Engine (GKE) to serve a web application. Users are reporting that a specific part of the application is not responding anymore. You notice that all pods of your deployment keep restarting after 2 seconds. The application writes logs to standard output. You want to inspect the logs to find the cause of the issue. Which approach can you take?

**A.** Review the Stackdriver logs for each Compute Engine instance that is serving as a node in the cluster.

**B.** Review the Stackdriver logs for the specific GKE container that is serving the unresponsive part of the application.

**C.** Connect to the cluster using gcloud credentials and connect to a container in one of the pods to read the logs.

**D.** Review the Serial Port logs for each Compute Engine instance that is serving as a node in the cluster.

**Respuesta de la fuente:** B

**Explicación:** GKE automatically collects container standard output and error logs via the per-node logging agent, making them available in Cloud Logging (formerly Stackdriver) without requiring node-level SSH access.
Since the pods are restarting rapidly (every 2 seconds), attempting to exec into a running container (Option C) is impractical and often impossible due to the short lifecycle.
Cloud Logging aggregates these logs centrally, allowing you to inspect the specific container's output to identify the crash cause efficiently.

## Pregunta 70

Contexto: [topics:92](#topics-92)
You are using a single Cloud SQL instance to serve your application from a specific zone. You want to introduce high availability. What should you do?

**A.** Create a read replica instance in a different region

**B.** Create a failover replica instance in a different region

**C.** Create a read replica instance in the same region, but in a different zone

**D.** Create a failover replica instance in the same region, but in a different zone

**Respuesta de la fuente:** D

**Explicación:** High Availability in Cloud SQL requires data redundancy across zones within a single region to handle zone-level failures. Read replicas are designed for read scaling and do not provide automatic failover capabilities for high availability. Therefore, you must configure a failover replica in the same region but a different zone to ensure the instance can automatically switch over if the primary zone becomes unavailable.

## Pregunta 71

Contexto: [topics:92](#topics-92)
Your company is running a stateless application on a Compute Engine instance. The application is used heavily during regular business hours and lightly outside of business hours. Users are reporting that the application is slow during peak hours. You need to optimize the application's performance. What should you do?

**A.** Create a snapshot of the existing disk. Create an instance template from the snapshot. Create an autoscaled managed instance group from the instance template.

**B.** Create a snapshot of the existing disk. Create a custom image from the snapshot. Create an autoscaled managed instance group from the custom image.

**C.** Create a custom image from the existing disk. Create an instance template from the custom image. Create an autoscaled managed instance group from the instance template.

**D.** Create an instance template from the existing disk. Create a custom image from the instance template. Create an autoscaled managed instance group from the custom image.

**Respuesta de la fuente:** C

**Explicación:** To autoscale a stateless application on Google Cloud, you must create an autoscaled managed instance group (MIG), which requires an instance template as its source. An instance template defines the properties for new VMs, including the boot disk image, so it cannot be created directly from a snapshot or a raw disk; it must reference a custom image. Therefore, the correct workflow is to first create a custom image from the existing instance's disk, then define an instance template using that image, and finally configure the autoscaled MIG from the template.

## Pregunta 72

Contexto: [topics:92](#topics-92)
Your web application has several VM instances running within a VPC. You want to restrict communications between instances to only the paths and ports you authorize, but you don't want to rely on static IP addresses or subnets because the app can autoscale. How should you restrict communications?

**A.** Use separate VPCs to restrict traffic

**B.** Use firewall rules based on network tags attached to the compute instances

**C.** Use Cloud DNS and only allow connections from authorized hostnames

**D.** Use service accounts and configure the web application to authorize particular service accounts to have access

**Respuesta de la fuente:** B

**Explicación:** Firewall rules are the only mechanism listed that can restrict traffic based on specific ports and protocols within a VPC.
Using network tags allows you to target instances dynamically by their function or role rather than static IP addresses, which is essential for autoscaling environments where IPs change frequently.

## Pregunta 73

Contexto: [topics:92](#topics-92)
You are using Cloud SQL as the database backend for a large CRM deployment. You want to scale as usage increases and ensure that you don't run out of storage, maintain 75% CPU usage cores, and keep replication lag below 60 seconds. What are the correct steps to meet your requirements?

**A.** 1. Enable automatic storage increase for the instance. 2. Create a Stackdriver alert when CPU usage exceeds 75%, and change the instance type to reduce CPU usage. 3. Create a Stackdriver alert for replication lag, and shard the database to reduce replication time.

**B.** 1. Enable automatic storage increase for the instance. 2. Change the instance type to a 32-core machine type to keep CPU usage below 75%. 3. Create a Stackdriver alert for replication lag, and deploy memcache to reduce load on the master.

**C.** 1. Create a Stackdriver alert when storage exceeds 75%, and increase the available storage on the instance to create more space. 2. Deploy memcached to reduce CPU load. 3. Change the instance type to a 32-core machine type to reduce replication lag.

**D.** 1. Create a Stackdriver alert when storage exceeds 75%, and increase the available storage on the instance to create more space. 2. Deploy memcached to reduce CPU load. 3. Create a Stackdriver alert for replication lag, and change the instance type to a 32-core machine type to reduce replication lag.

**Respuesta de la fuente:** A

**Explicación:** The requirement is to maintain CPU usage *at* 75%, not below it by arbitrary means; enabling auto-storage growth ensures you don't run out of space.
Option A correctly addresses storage via automatic increase, monitors CPU with alerts to trigger instance type changes if usage exceeds the target, and addresses replication lag through sharding, which is a standard scaling strategy for write-heavy workloads to reduce master load and lag.
Other options incorrectly focus on storage thresholds (75% storage vs 75% CPU) or suggest fixed machine types without monitoring logic.

## Pregunta 74

Contexto: [topics:92](#topics-92)
You are tasked with building an online analytical processing (OLAP) marketing analytics and reporting tool. This requires a relational database that can operate on hundreds of terabytes of data. What is the Google-recommended tool for such applications?

**A.** Cloud Spanner, because it is globally distributed

**B.** Cloud SQL, because it is a fully managed relational database

**C.** Cloud Firestore, because it offers real-time synchronization across devices

**D.** BigQuery, because it is designed for large-scale processing of tabular data

**Respuesta de la fuente:** D

**Explicación:** BigQuery is Google's serverless data warehouse designed specifically for large-scale OLAP analytics and reporting on petabytes of tabular data. While Cloud Spanner is a relational database, it is optimized for online transaction processing (OLTP) rather than the heavy analytical queries described in the scenario.

## Pregunta 75

Contexto: [topics:92](#topics-92)
You have deployed an application to Google Kubernetes Engine (GKE), and are using the Cloud SQL proxy container to make the Cloud SQL database available to the services running on Kubernetes. You are notified that the application is reporting database connection issues. Your company policies require a post- mortem. What should you do?

**A.** Use gcloud sql instances restart.

**B.** Validate that the Service Account used by the Cloud SQL proxy container still has the Cloud Build Editor role.

**C.** In the GCP Console, navigate to Stackdriver Logging. Consult logs for (GKE) and Cloud SQL.

**D.** In the GCP Console, navigate to Cloud SQL. Restore the latest backup. Use kubectl to restart all pods.

**Respuesta de la fuente:** C

**Explicación:** The question specifically requires conducting a post-mortem to investigate connection issues, which necessitates analyzing historical data to determine the root cause. Consulting Stackdriver Logging (now Cloud Logging) for both GKE and Cloud SQL provides the necessary diagnostic details regarding connectivity failures.
Other options like restarting instances or restoring backups are remediation actions rather than investigative steps, and checking for Cloud Build Editor roles is irrelevant since the proxy requires Cloud SQL Client permissions, not build capabilities.

## Pregunta 76

Contexto: [topics:92](#topics-92)
Your company pushes batches of sensitive transaction data from its application server VMs to Cloud Pub/Sub for processing and storage. What is the Google- recommended way for your application to authenticate to the required Google Cloud services?

**A.** Ensure that VM service accounts are granted the appropriate Cloud Pub/Sub IAM roles.

**B.** Ensure that VM service accounts do not have access to Cloud Pub/Sub, and use VM access scopes to grant the appropriate Cloud Pub/Sub IAM roles.

**C.** Generate an OAuth2 access token for accessing Cloud Pub/Sub, encrypt it, and store it in Cloud Storage for access from each VM.

**D.** Create a gateway to Cloud Pub/Sub using a Cloud Function, and grant the Cloud Function service account the appropriate Cloud Pub/Sub IAM roles.

**Respuesta de la fuente:** A

**Explicación:** Google recommends using Compute Engine service accounts for applications running on VMs to authenticate with Cloud services, as they provide automatic credential management without manual key handling. By granting the appropriate Cloud Pub/Sub IAM roles directly to these service accounts, you follow the principle of least privilege while ensuring secure, seamless API access.

## Pregunta 77

Contexto: [topics:92](#topics-92)
You want to establish a Compute Engine application in a single VPC across two regions. The application must communicate over VPN to an on-premises network.
How should you deploy the VPN?

**A.** Use VPC Network Peering between the VPC and the on-premises network.

**B.** Expose the VPC to the on-premises network using IAM and VPC Sharing.

**C.** Create a global Cloud VPN Gateway with VPN tunnels from each region to the on-premises peer gateway.

**D.** Deploy Cloud VPN Gateway in each region. Ensure that each region has at least one VPN tunnel to the on-premises peer gateway.

**Respuesta de la fuente:** D

**Explicación:** The correct answer is D because Cloud VPN gateways are regional resources, not global ones, meaning a single gateway cannot span multiple regions directly as implied in option C. To ensure high availability and proper routing for an application deployed across two regions to an on-premises network, you must deploy Cloud VPN gateways in each region with corresponding tunnels.

## Pregunta 78

Contexto: [topics:92](#topics-92)
Your applications will be writing their logs to BigQuery for analysis. Each application should have its own table. Any logs older than 45 days should be removed.
You want to optimize storage and follow Google-recommended practices. What should you do?

**A.** Configure the expiration time for your tables at 45 days

**B.** Make the tables time-partitioned, and configure the partition expiration at 45 days

**C.** Rely on BigQuery's default behavior to prune application logs older than 45 days

**D.** Create a script that uses the BigQuery command line tool (bq) to remove records older than 45 days

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it uses partition expiration to delete only the specific data partitions older than 45 days while preserving the table structure and newer data.
In contrast, Option A sets a table expiration, which would delete the entire table (and all its data) after 45 days, causing loss of recent logs.
BigQuery does not automatically prune old records by default (Option C), and using a script (Option D) is less efficient and not a recommended best practice compared to native partition management.

## Pregunta 79

Contexto: [topics:92](#topics-92)
You want your Google Kubernetes Engine cluster to automatically add or remove nodes based on CPU load.
What should you do?

**A.** Configure a HorizontalPodAutoscaler with a target CPU usage. Enable the Cluster Autoscaler from the GCP Console.

**B.** Configure a HorizontalPodAutoscaler with a target CPU usage. Enable autoscaling on the managed instance group for the cluster using the gcloud command.

**C.** Create a deployment and set the maxUnavailable and maxSurge properties. Enable the Cluster Autoscaler using the gcloud command.

**D.** Create a deployment and set the maxUnavailable and maxSurge properties. Enable autoscaling on the cluster managed instance group from the GCP Console.

**Respuesta de la fuente:** A

**Explicación:** The Cluster Autoscaler scales the node pool by monitoring pending pods that cannot be scheduled due to resource constraints. A HorizontalPodAutoscaler (HPA) triggers this process by increasing the number of pod replicas in response to high CPU load, creating scheduling pressure. When nodes are insufficient for these new pods, the Cluster Autoscaler adds nodes; conversely, it removes underutilized nodes when the HPA scales down replicas. Options B and D incorrectly suggest using Compute Engine autoscaling, which must not be used for GKE node groups.

## Pregunta 80

Contexto: [topics:92](#topics-92)
You need to develop procedures to verify resilience of disaster recovery for remote recovery using GCP. Your production environment is hosted on-premises. You need to establish a secure, redundant connection between your on-premises network and the GCP network.
What should you do?

**A.** Verify that Dedicated Interconnect can replicate files to GCP. Verify that direct peering can establish a secure connection between your networks if Dedicated Interconnect fails.

**B.** Verify that Dedicated Interconnect can replicate files to GCP. Verify that Cloud VPN can establish a secure connection between your networks if Dedicated Interconnect fails.

**C.** Verify that the Transfer Appliance can replicate files to GCP. Verify that direct peering can establish a secure connection between your networks if the Transfer Appliance fails.

**D.** Verify that the Transfer Appliance can replicate files to GCP. Verify that Cloud VPN can establish a secure connection between your networks if the Transfer Appliance fails.

**Respuesta de la fuente:** B

**Explicación:** Dedicated Interconnect provides a high-performance, private connection suitable for disaster recovery replication, while the Transfer Appliance is only for one-time bulk data migration and cannot serve as an active network link. Cloud VPN serves as the appropriate redundant failover because it establishes a secure IPSec tunnel over the public internet, whereas Direct Peering does not provide end-to-end encryption and is designed for Google services access rather than private VPC extension.

## Pregunta 81

Contexto: [topics:92](#topics-92)
Your company operates nationally and plans to use GCP for multiple batch workloads, including some that are not time-critical. You also need to use GCP services that are HIPAA-certified and manage service costs.
How should you design to meet Google best practices?

**A.** Provision preemptible VMs to reduce cost. Discontinue use of all GCP services and APIs that are not HIPAA-compliant.

**B.** Provision preemptible VMs to reduce cost. Disable and then discontinue use of all GCP services and APIs that are not HIPAA-compliant.

**C.** Provision standard VMs in the same region to reduce cost. Discontinue use of all GCP services and APIs that are not HIPAA-compliant.

**D.** Provision standard VMs to the same region to reduce cost. Disable and then discontinue use of all GCP services and APIs that are not HIPAA-compliant.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 82

Contexto: [topics:92](#topics-92)
Your customer wants to do resilience testing of their authentication layer. This consists of a regional managed instance group serving a public REST API that reads from and writes to a Cloud SQL instance.
What should you do?

**A.** Engage with a security company to run web scrapers that look your for users' authentication data om malicious websites and notify you if any is found.

**B.** Deploy intrusion detection software to your virtual machines to detect and log unauthorized access.

**C.** Schedule a disaster simulation exercise during which you can shut off all VMs in a zone to see how your application behaves.

**D.** Configure a read replica for your Cloud SQL instance in a different zone than the master, and then manually trigger a failover while monitoring KPIs for our REST API.

**Respuesta de la fuente:** C

**Explicación:** Resilience testing validates that an application continues to function during component failures. Option C describes chaos engineering, specifically simulating a zone-level outage to verify the Regional MIG's fault tolerance and automatic self-healing capabilities.

Option D is incorrect because standard read replicas do not support automatic failover; they must be manually promoted, which does not test the system's ability to withstand unexpected failures autonomously.

## Pregunta 83

Contexto: [topics:92](#topics-92)
Your BigQuery project has several users. For audit purposes, you need to see how many queries each user ran in the last month. What should you do?

**A.** Connect Google Data Studio to BigQuery. Create a dimension for the users and a metric for the amount of queries per user.

**B.** In the BigQuery interface, execute a query on the JOBS table to get the required information.

**C.** Use 'bq show' to list all jobs. Per job, use 'bq ls' to list job information and get the required information.

**D.** Use Cloud Audit Logging to view Cloud Audit Logs, and create a filter on the query operation to get the required information.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 84

Contexto: [topics:92](#topics-92)
You want to automate the creation of a managed instance group. The VMs have many OS package dependencies. You want to minimize the startup time for new
VMs in the instance group.
What should you do?

**A.** Use Terraform to create the managed instance group and a startup script to install the OS package dependencies.

**B.** Create a custom VM image with all OS package dependencies. Use Deployment Manager to create the managed instance group with the VM image.

**C.** Use Puppet to create the managed instance group and install the OS package dependencies.

**D.** Use Deployment Manager to create the managed instance group and Ansible to install the OS package dependencies.

**Respuesta de la fuente:** B

**Explicación:** To minimize startup time, you should use a custom VM image with pre-installed OS package dependencies.
This approach eliminates the need to download and install packages during boot, which significantly reduces initialization latency compared to using startup scripts or configuration management tools like Puppet, Ansible, or Terraform post-boot.

## Pregunta 85

Contexto: [topics:92](#topics-92)
Your company captures all web traffic data in Google Analytics 360 and stores it in BigQuery. Each country has its own dataset. Each dataset has multiple tables.
You want analysts from each country to be able to see and query only the data for their respective countries.
How should you configure the access rights?

**A.** Create a group per country. Add analysts to their respective country-groups. Create a single group 'all_analysts', and add all country-groups as members. Grant the 'all_analysts' group the IAM role of BigQuery jobUser. Share the appropriate dataset with view access with each respective analyst country-group.

**B.** Create a group per country. Add analysts to their respective country-groups. Create a single group 'all_analysts', and add all country-groups as members. Grant the 'all_analysts' group the IAM role of BigQuery jobUser. Share the appropriate tables with view access with each respective analyst country-group.

**C.** Create a group per country. Add analysts to their respective country-groups. Create a single group 'all_analysts', and add all country-groups as members. Grant the 'all_analysts' group the IAM role of BigQuery dataViewer. Share the appropriate dataset with view access with each respective analyst country- group.

**D.** Create a group per country. Add analysts to their respective country-groups. Create a single group 'all_analysts', and add all country-groups as members. Grant the 'all_analysts' group the IAM role of BigQuery dataViewer. Share the appropriate table with view access with each respective analyst country-group.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because the BigQuery JobUser role (applied at the project level) grants the necessary permissions to run queries without allowing users to list or see datasets they don't have explicit access to. By sharing specific datasets with View Access to respective country groups, analysts can only query and view data within their authorized scopes, adhering to the principle of least privilege.

In contrast, granting the DataViewer role (as in Option C) typically allows users to list tables and view metadata for all accessible resources, which violates the requirement that analysts should not see data from other countries.

## Pregunta 86

Contexto: [topics:92](#topics-92)
You have been engaged by your client to lead the migration of their application infrastructure to GCP. One of their current problems is that the on-premises high performance SAN is requiring frequent and expensive upgrades to keep up with the variety of workloads that are identified as follows: 20 TB of log archives retained for legal reasons; 500 GB of VM boot/data volumes and templates; 500 GB of image thumbnails; 200 GB of customer session state data that allows customers to restart sessions even if off-line for several days.
Which of the following best reflects your recommendations for a cost-effective storage allocation?

**A.** Local SSD for customer session state data. Lifecycle-managed Cloud Storage for log archives, thumbnails, and VM boot/data volumes.

**B.** Memcache backed by Cloud Datastore for the customer session state data. Lifecycle-managed Cloud Storage for log archives, thumbnails, and VM boot/data volumes.

**C.** Memcache backed by Cloud SQL for customer session state data. Assorted local SSD-backed instances for VM boot/data volumes. Cloud Storage for log archives and thumbnails.

**D.** Memcache backed by Persistent Disk SSD storage for customer session state data. Assorted local SSD-backed instances for VM boot/data volumes. Cloud Storage for log archives and thumbnails.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 87

Contexto: [topics:92](#topics-92)
Your web application uses Google Kubernetes Engine to manage several workloads. One workload requires a consistent set of hostnames even after pod scaling and relaunches.
Which feature of Kubernetes should you use to accomplish this?

**A.** StatefulSets

**B.** Role-based access control

**C.** Container environment variables

**D.** Persistent Volumes

**Respuesta de la fuente:** A

**Explicación:** StatefulSets are the Kubernetes workload controller designed for stateful applications that require stable, unique network identifiers.
Unlike Deployments or ReplicaSets, StatefulSets ensure that each pod maintains a consistent hostname (e.g., web-0, web-1) even after scaling, rescheduling, or relaunching.
This stability is critical for distributed systems and databases where service discovery relies on predictable naming conventions.

## Pregunta 88

Contexto: [topics:92](#topics-92)
You are using Cloud CDN to deliver static HTTP(S) website content hosted on a Compute Engine instance group. You want to improve the cache hit ratio.
What should you do?

**A.** Customize the cache keys to omit the protocol from the key.

**B.** Shorten the expiration time of the cached objects.

**C.** Make sure the HTTP(S) header "Cache-Region" points to the closest region of your users.

**D.** Replicate the static content in a Cloud Storage bucket. Point CloudCDN toward a load balancer on that bucket.

**Respuesta de la fuente:** A

**Explicación:** By default, Cloud CDN includes the protocol (HTTP vs HTTPS) in the cache key, treating requests with different protocols as distinct objects. Customizing the cache key to omit the protocol consolidates these entries, allowing HTTP and HTTPS requests for the same content to share a single cached object, thereby increasing the hit ratio.

## Pregunta 89

Contexto: [topics:92](#topics-92)
Your architecture calls for the centralized collection of all admin activity and VM system logs within your project.
How should you collect these logs from both VMs and services?

**A.** All admin and VM system logs are automatically collected by Stackdriver.

**B.** Stackdriver automatically collects admin activity logs for most services. The Stackdriver Logging agent must be installed on each instance to collect system logs.

**C.** Launch a custom syslogd compute instance and configure your GCP project and VMs to forward all logs to it.

**D.** Install the Stackdriver Logging agent on a single compute instance and let it collect all audit and access logs for your environment.

**Respuesta de la fuente:** B

**Explicación:** In Google Cloud Platform (now Stackdriver/Cloud Logging), audit and admin activity logs are collected automatically for most services without additional configuration. However, system logs from Compute Engine VMs require the installation of the logging agent to be forwarded and centralized.
Therefore, option B correctly describes this hybrid approach, whereas A is incorrect because it claims VM system logs are automatic.

## Pregunta 90

Contexto: [topics:92](#topics-92)
You have an App Engine application that needs to be updated. You want to test the update with production traffic before replacing the current application version.
What should you do?

**A.** Deploy the update using the Instance Group Updater to create a partial rollout, which allows for canary testing.

**B.** Deploy the update as a new version in the App Engine application, and split traffic between the new and current versions.

**C.** Deploy the update in a new VPC, and use Google's global HTTP load balancing to split traffic between the update and current applications.

**D.** Deploy the update as a new App Engine application, and use Google's global HTTP load balancing to split traffic between the new and current applications.

**Respuesta de la fuente:** B

**Explicación:** App Engine natively supports multi-version deployments, allowing you to deploy updates as new versions within the same service. You can then use App Engine's built-in traffic splitting feature to route a specific percentage of production traffic to the new version for testing (canary or A/B testing) without requiring external load balancers.

## Pregunta 91

Contexto: [topics:92](#topics-92)
All Compute Engine instances in your VPC should be able to connect to an Active Directory server on specific ports. Any other traffic emerging from your instances is not allowed. You want to enforce this using VPC firewall rules.
How should you configure the firewall rules?

**A.** Create an egress rule with priority 1000 to deny all traffic for all instances. Create another egress rule with priority 100 to allow the Active Directory traffic for all instances.

**B.** Create an egress rule with priority 100 to deny all traffic for all instances. Create another egress rule with priority 1000 to allow the Active Directory traffic for all instances.

**C.** Create an egress rule with priority 1000 to allow the Active Directory traffic. Rely on the implied deny egress rule with priority 100 to block all traffic for all instances.

**D.** Create an egress rule with priority 100 to allow the Active Directory traffic. Rely on the implied deny egress rule with priority 1000 to block all traffic for all instances.

**Respuesta de la fuente:** A

**Explicación:** By default, GCP VPCs have an implied egress rule that allows all outbound traffic. To enforce a restrictive policy, you must first create an explicit deny-all egress rule with a lower priority (e.g., 1000) to override this default allow behavior.
Then, create a more specific allow rule for Active Directory traffic with a higher priority (lower number, e.g., 100) to permit only the required connections.
Options C and D are incorrect because there is no implied deny-all egress rule in GCP.

## Pregunta 92

Contexto: [topics:92](#topics-92)
Your customer runs a web service used by e-commerce sites to offer product recommendations to users. The company has begun experimenting with a machine learning model on Google Cloud Platform to improve the quality of results.
What should the customer do to improve their model's results over time?

**A.** Export Cloud Machine Learning Engine performance metrics from Stackdriver to BigQuery, to be used to analyze the efficiency of the model.

**B.** Build a roadmap to move the machine learning model training from Cloud GPUs to Cloud TPUs, which offer better results.

**C.** Monitor Compute Engine announcements for availability of newer CPU architectures, and deploy the model to them as soon as they are available for additional performance.

**D.** Save a history of recommendations and results of the recommendations in BigQuery, to be used as training data.

**Respuesta de la fuente:** D

**Explicación:** To improve a machine learning model's results over time, the model must be retrained with new data that reflects actual user interactions and outcomes. Option D describes capturing recommendation history and user feedback to build a feedback loop for future training, which directly enhances prediction accuracy. Options A, B, and C focus on infrastructure performance metrics or hardware acceleration, which affect speed but not the predictive quality of the model.

## Pregunta 93

Contexto: [topics:92](#topics-92)
A development team at your company has created a dockerized HTTPS web application. You need to deploy the application on Google Kubernetes Engine (GKE) and make sure that the application scales automatically.
How should you deploy to GKE?

**A.** Use the Horizontal Pod Autoscaler and enable cluster autoscaling. Use an Ingress resource to load-balance the HTTPS traffic.

**B.** Use the Horizontal Pod Autoscaler and enable cluster autoscaling on the Kubernetes cluster. Use a Service resource of type LoadBalancer to load-balance the HTTPS traffic.

**C.** Enable autoscaling on the Compute Engine instance group. Use an Ingress resource to load-balance the HTTPS traffic.

**D.** Enable autoscaling on the Compute Engine instance group. Use a Service resource of type LoadBalancer to load-balance the HTTPS traffic.

**Respuesta de la fuente:** A

**Explicación:** Answer A is correct because the Horizontal Pod Autoscaler and cluster autoscaling handle automatic scaling requirements.
Since the application is HTTPS (Layer 7), an Ingress resource is required to configure HTTP(S) load balancing, whereas a standard Service of type LoadBalancer provisioned on GKE creates a Network Load Balancer (Layer 4) which does not natively terminate TLS for HTTP/HTTPS routing without additional configuration.

## Pregunta 94

Contexto: [topics:92](#topics-92)
You need to design a solution for global load balancing based on the URL path being requested. You need to ensure operations reliability and end-to-end in- transit encryption based on Google best practices.
What should you do?

**A.** Create a cross-region load balancer with URL Maps.

**B.** Create an HTTPS load balancer with URL Maps.

**C.** Create appropriate instance groups and instances. Configure SSL proxy load balancing.

**D.** Create a global forwarding rule. Configure SSL proxy load balancing.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud HTTP(S) Load Balancing is inherently global and supports URL maps for routing traffic based on host and path rules. SSL Proxy load balancing does not support URL-based routing, making it unsuitable for this requirement despite its encryption capabilities.

## Pregunta 95

Contexto: [topics:92](#topics-92)
You have an application that makes HTTP requests to Cloud Storage. Occasionally the requests fail with HTTP status codes of 5xx and 429.
How should you handle these types of errors?

**A.** Use gRPC instead of HTTP for better performance.

**B.** Implement retry logic using a truncated exponential backoff strategy.

**C.** Make sure the Cloud Storage bucket is multi-regional for geo-redundancy.

**D.** Monitor https://status.cloud.google.com/feed.atom and only make requests if Cloud Storage is not reporting an incident.

**Respuesta de la fuente:** B

**Explicación:** HTTP 5xx errors indicate server-side failures, while 429 errors signify rate limiting; both are typically transient conditions that resolve over time.
Implementing truncated exponential backoff is the recommended best practice because it automatically retries failed requests with increasing delays, preventing service overload and improving request success rates.
Other options like switching protocols (A), changing bucket topology (C), or manual status monitoring (D) do not address the dynamic handling of transient errors at the application level.

## Pregunta 96

Contexto: [topics:92](#topics-92)
You need to develop procedures to test a disaster plan for a mission-critical application. You want to use Google-recommended practices and native capabilities within GCP.
What should you do?

**A.** Use Deployment Manager to automate service provisioning. Use Activity Logs to monitor and debug your tests.

**B.** Use Deployment Manager to automate service provisioning. Use Stackdriver to monitor and debug your tests.

**C.** Use gcloud scripts to automate service provisioning. Use Activity Logs to monitor and debug your tests.

**D.** Use gcloud scripts to automate service provisioning. Use Stackdriver to monitor and debug your tests.

**Respuesta de la fuente:** B

**Explicación:** Google recommends using Deployment Manager for Infrastructure as Code (IaC) to automate service provisioning in disaster recovery plans, ensuring reproducibility and consistency over manual scripts. Additionally, Cloud Logging (formerly Stackdriver Logs), referred to here as 'Activity Logs' or part of the broader Stackdriver suite which was the recommended monitoring/debugging suite at the time of this question's origin, is the native tool for observing system health. However, specific Google documentation for DR testing highlights using Deployment Manager for automation and relying on native monitoring tools; among the choices, Option B aligns with the historical context where 'Stackdriver' was the branded name for the comprehensive monitoring/debugging suite recommended for such tasks, while 'Activity Logs' is a subset. Note: In current terminology, Stackdriver Monitoring/Logging is simply Cloud Operations, but within the context of this specific exam question's era and phrasing, B is the intended answer.

## Pregunta 97

Contexto: [topics:92](#topics-92)
Your company creates rendering software which users can download from the company website. Your company has customers all over the world. You want to minimize latency for all your customers. You want to follow Google-recommended practices.
How should you store the files?

**A.** Save the files in a Multi-Regional Cloud Storage bucket.

**B.** Save the files in a Regional Cloud Storage bucket, one bucket per zone of the region.

**C.** Save the files in multiple Regional Cloud Storage buckets, one bucket per zone per region.

**D.** Save the files in multiple Multi-Regional Cloud Storage buckets, one bucket per multi-region.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 98

Contexto: [topics:92](#topics-92)
Your company acquired a healthcare startup and must retain its customers' medical information for up to 4 more years, depending on when it was created. Your corporate policy is to securely retain this data, and then delete it as soon as regulations allow.
Which approach should you take?

**A.** Store the data in Google Drive and manually delete records as they expire.

**B.** Anonymize the data using the Cloud Data Loss Prevention API and store it indefinitely.

**C.** Store the data in Cloud Storage and use lifecycle management to delete files when they expire.

**D.** Store the data in Cloud Storage and run a nightly batch script that deletes all expired data.

**Respuesta de la fuente:** C

**Explicación:** Cloud Storage lifecycle management provides an automated, serverless mechanism to delete objects based on specific conditions like age or custom time, ensuring data is purged immediately upon expiration without manual intervention. This aligns with the requirement for secure retention followed by timely deletion, whereas manual processes (A) are error-prone and indefinite storage (B) violates the deletion mandate.

## Pregunta 99

Contexto: [topics:92](#topics-92)
You are deploying a PHP App Engine Standard service with Cloud SQL as the backend. You want to minimize the number of queries to the database.
What should you do?

**A.** Set the memcache service level to dedicated. Create a key from the hash of the query, and return database values from memcache before issuing a query to Cloud SQL.

**B.** Set the memcache service level to dedicated. Create a cron task that runs every minute to populate the cache with keys containing query results.

**C.** Set the memcache service level to shared. Create a cron task that runs every minute to save all expected queries to a key called "cached_queries".

**D.** Set the memcache service level to shared. Create a key called "cached_queries", and return database values from the key before using a query to Cloud SQL.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it implements a standard read-through caching pattern where the cache is checked before querying Cloud SQL, effectively reducing redundant database calls for repeated requests. Using a dedicated Memcache instance ensures higher performance and isolation compared to shared memory, which is crucial for minimizing latency in frequent data access scenarios.
Options C and D are incorrect because storing all query results under a single key violates Memcache best practices and size limits, while Option B uses an inefficient polling strategy (cron jobs) that generates unnecessary overhead rather than reacting to actual cache misses.

## Pregunta 100

Contexto: [topics:92](#topics-92)
You need to ensure reliability for your application and operations by supporting reliable task scheduling for compute on GCP. Leveraging Google best practices, what should you do?

**A.** Using the Cron service provided by App Engine, publish messages directly to a message-processing utility service running on Compute Engine instances.

**B.** Using the Cron service provided by App Engine, publish messages to a Cloud Pub/Sub topic. Subscribe to that topic using a message-processing utility service running on Compute Engine instances.

**C.** Using the Cron service provided by Google Kubernetes Engine (GKE), publish messages directly to a message-processing utility service running on Compute Engine instances.

**D.** Using the Cron service provided by GKE, publish messages to a Cloud Pub/Sub topic. Subscribe to that topic using a message-processing utility service running on Compute Engine instances.

**Respuesta de la fuente:** B

**Explicación:** Option B is the correct answer because it follows GCP best practices for reliable task scheduling by decoupling the scheduler from the compute instances using Cloud Pub/Sub.
Direct HTTP calls (Options A and C) lack built-in durability, whereas Pub/Sub provides at-least-once delivery guarantees and buffering to handle instance downtime or scaling events.
Although modern exams recommend Cloud Scheduler, within this question's context, App Engine Cron is the designated scheduler, making B the only pattern that ensures reliability via a durable message queue.

## Pregunta 101

Contexto: [topics:92](#topics-92)
Your company is building a new architecture to support its data-centric business focus. You are responsible for setting up the network. Your company's mobile and web-facing applications will be deployed on-premises, and all data analysis will be conducted in GCP. The plan is to process and load 7 years of archived .csv files totaling 900 TB of data and then continue loading 10 TB of data daily. You currently have an existing 100-MB internet connection.
What actions will meet your company's needs?

**A.** Compress and upload both archived files and files uploaded daily using the gsutil —m option.

**B.** Lease a Transfer Appliance, upload archived files to it, and send it to Google to transfer archived data to Cloud Storage. Establish a connection with Google using a Dedicated Interconnect or Direct Peering connection and use it to upload files daily.

**C.** Lease a Transfer Appliance, upload archived files to it, and send it to Google to transfer archived data to Cloud Storage. Establish one Cloud VPN Tunnel to VPC networks over the public internet, and compress and upload files daily using the gsutil —m option.

**D.** Lease a Transfer Appliance, upload archived files to it, and send it to Google to transfer archived data to Cloud Storage. Establish a Cloud VPN Tunnel to VPC networks over the public internet, and compress and upload files daily.

**Respuesta de la fuente:** B

**Explicación:** Uploading 900 TB over a 100 Mbps connection is impractical due to extreme latency; Google Transfer Appliance is required for the initial bulk data migration.
For daily transfers of 10 TB, cloud interconnect options (Dedicated Interconnect or Direct Peering) provide the necessary high-bandwidth, private connectivity that exceeds the limits of the existing internet link or standard VPN.

## Pregunta 102

Contexto: [topics:92](#topics-92)
You are developing a globally scaled frontend for a legacy streaming backend data API. This API expects events in strict chronological order with no repeat data for proper processing.
Which products should you deploy to ensure guaranteed-once FIFO (first-in, first-out) delivery of data?

**A.** Cloud Pub/Sub alone

**B.** Cloud Pub/Sub to Cloud Dataflow

**C.** Cloud Pub/Sub to Stackdriver

**D.** Cloud Pub/Sub to Cloud SQL

**Respuesta de la fuente:** B

**Explicación:** Cloud Pub/Sub natively provides at-least-once delivery semantics. To achieve guaranteed-exactly-once (no repeats) and strict ordering for a globally scaled stream, Cloud Dataflow is required to perform deduplication and windowing based on timestamps. Other options like Cloud SQL or Stackdriver lack the native streaming processing capabilities needed for this real-time data lifecycle pattern.

## Pregunta 103

Contexto: [topics:92](#topics-92)
Your company is planning to perform a lift and shift migration of their Linux RHEL 6.5+ virtual machines. The virtual machines are running in an on-premises
VMware environment. You want to migrate them to Compute Engine following Google-recommended practices. What should you do?

**A.** 1. Define a migration plan based on the list of the applications and their dependencies. 2. Migrate all virtual machines into Compute Engine individually with Migrate for Compute Engine.

**B.** 1. Perform an assessment of virtual machines running in the current VMware environment. 2. Create images of all disks. Import disks on Compute Engine. 3. Create standard virtual machines where the boot disks are the ones you have imported.

**C.** 1. Perform an assessment of virtual machines running in the current VMware environment. 2. Define a migration plan, prepare a Migrate for Compute Engine migration RunBook, and execute the migration.

**D.** 1. Perform an assessment of virtual machines running in the current VMware environment. 2. Install a third-party agent on all selected virtual machines. 3. Migrate all virtual machines into Compute Engine.

**Respuesta de la fuente:** C

**Explicación:** Google-recommended practices for lift-and-shift migrations from VMware utilize Migrate for Compute Engine to automate the process while managing dependencies.

The correct workflow involves assessing the source environment, defining a migration plan that groups VMs into waves based on application dependencies, and creating RunBooks in the Migrate for Compute Engine Manager to orchestrate the replication and cutover.

## Pregunta 104

Contexto: [topics:92](#topics-92)
You need to deploy an application to Google Cloud. The application receives traffic via TCP and reads and writes data to the filesystem. The application does not support horizontal scaling. The application process requires full control over the data on the file system because concurrent access causes corruption. The business is willing to accept a downtime when an incident occurs, but the application must be available 24/7 to support their business operations. You need to design the architecture of this application on Google Cloud. What should you do?

**A.** Use a managed instance group with instances in multiple zones, use Cloud Filestore, and use an HTTP load balancer in front of the instances.

**B.** Use a managed instance group with instances in multiple zones, use Cloud Filestore, and use a network load balancer in front of the instances.

**C.** Use an unmanaged instance group with an active and standby instance in different zones, use a regional persistent disk, and use an HTTP load balancer in front of the instances.

**D.** Use an unmanaged instance group with an active and standby instance in different zones, use a regional persistent disk, and use a network load balancer in front of the instances.

**Respuesta de la fuente:** D

**Explicación:** A Network Load Balancer is required because the application receives TCP traffic (Layer 4), whereas an HTTP(S) load balancer handles only Layer 7 protocols. An unmanaged instance group with active/standby instances is necessary because the application does not support horizontal scaling and requires exclusive filesystem access to prevent data corruption, which rules out shared storage like Cloud Filestore in a scaled-out managed group.

## Pregunta 105

Contexto: [topics:92](#topics-92)
Your company has an application running on multiple Compute Engine instances. You need to ensure that the application can communicate with an on-premises service that requires high throughput via internal IPs, while minimizing latency. What should you do?

**A.** Use OpenVPN to configure a VPN tunnel between the on-premises environment and Google Cloud.

**B.** Configure a direct peering connection between the on-premises environment and Google Cloud.

**C.** Use Cloud VPN to configure a VPN tunnel between the on-premises environment and Google Cloud.

**D.** Configure a Cloud Dedicated Interconnect connection between the on-premises environment and Google Cloud.

**Respuesta de la fuente:** D

**Explicación:** Cloud Dedicated Interconnect provides a direct physical link between on-premises networks and Google Cloud, ensuring high throughput and low latency by bypassing the public internet.
This dedicated connection supports internal IP communication without the encryption overhead or variable jitter associated with Cloud VPN solutions.

## Pregunta 106

Contexto: [topics:92](#topics-92)
You are managing an application deployed on Cloud Run for Anthos, and you need to define a strategy for deploying new versions of the application. You want to evaluate the new code with a subset of production traffic to decide whether to proceed with the rollout. What should you do?

**A.** Deploy a new revision to Cloud Run with the new version. Configure traffic percentage between revisions.

**B.** Deploy a new service to Cloud Run with the new version. Add a Cloud Load Balancing instance in front of both services.

**C.** In the Google Cloud Console page for Cloud Run, set up continuous deployment using Cloud Build for the development branch. As part of the Cloud Build trigger, configure the substitution variable TRAFFIC_PERCENTAGE with the percentage of traffic you want directed to a new version.

**D.** In the Google Cloud Console, configure Traffic Director with a new Service that points to the new version of the application on Cloud Run. Configure Traffic Director to send a small percentage of traffic to the new version of the application.

**Respuesta de la fuente:** A

**Explicación:** Cloud Run for Anthos natively supports traffic splitting between different revisions of the same service, allowing for canary deployments or A/B testing without external load balancers.
Deploying a new revision and configuring the traffic percentage directly within the service settings is the standard, supported mechanism for gradually rolling out changes while evaluating them with production traffic.

## Pregunta 107

Contexto: [topics:92](#topics-92)
You are monitoring Google Kubernetes Engine (GKE) clusters in a Cloud Monitoring workspace. As a Site Reliability Engineer (SRE), you need to triage incidents quickly. What should you do?

**A.** Navigate the predefined dashboards in the Cloud Monitoring workspace, and then add metrics and create alert policies.

**B.** Navigate the predefined dashboards in the Cloud Monitoring workspace, create custom metrics, and install alerting software on a Compute Engine instance.

**C.** Write a shell script that gathers metrics from GKE nodes, publish these metrics to a Pub/Sub topic, export the data to BigQuery, and make a Data Studio dashboard.

**D.** Create a custom dashboard in the Cloud Monitoring workspace for each incident, and then add metrics and create alert policies.

**Respuesta de la fuente:** A

**Explicación:** Cloud Monitoring provides predefined dashboards that offer immediate visibility into GKE cluster health without additional configuration.
Using these built-in views allows an SRE to quickly identify anomalies and triage incidents, whereas creating custom dashboards per incident (D) or building complex data pipelines (C) introduces unnecessary latency and overhead.
Option A leverages the native capabilities of Cloud Monitoring for efficient operational response.

## Pregunta 108

Contexto: [topics:92](#topics-92)
You are implementing a single Cloud SQL MySQL second-generation database that contains business-critical transaction data. You want to ensure that the minimum amount of data is lost in case of catastrophic failure. Which two features should you implement? (Choose two.)

**A.** Sharding

**B.** Read replicas

**C.** Binary logging

**D.** Automated backups

**E.** Semisynchronous replication

**Respuesta de la fuente:** C, D

**Explicación:** To minimize data loss (RPO) in Cloud SQL MySQL, you must enable Point-in-Time Recovery (PITR), which allows restoring the database to any specific second within the retention period. PITR relies on two underlying mechanisms: Automated Backups (which provide a base snapshot) and Binary Logging (which records all transaction changes since that snapshot). Without both features, you cannot recover recent transactions lost between backup windows or during a catastrophic failure.

## Pregunta 109

Contexto: [topics:92](#topics-92)
You are working at a sports association whose members range in age from 8 to 30. The association collects a large amount of health data, such as sustained injuries. You are storing this data in BigQuery. Current legislation requires you to delete such information upon request of the subject. You want to design a solution that can accommodate such a request. What should you do?

**A.** Use a unique identifier for each individual. Upon a deletion request, delete all rows from BigQuery with this identifier.

**B.** When ingesting new data in BigQuery, run the data through the Data Loss Prevention (DLP) API to identify any personal information. As part of the DLP scan, save the result to Data Catalog. Upon a deletion request, query Data Catalog to find the column with personal information.

**C.** Create a BigQuery view over the table that contains all data. Upon a deletion request, exclude the rows that affect the subject's data from this view. Use this view instead of the source table for all analysis tasks.

**D.** Use a unique identifier for each individual. Upon a deletion request, overwrite the column with the unique identifier with a salted SHA256 of its value.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it directly fulfills the legislative requirement to delete data upon request by physically removing all rows associated with a unique identifier.
DLP (Option B) only identifies or classifies sensitive data but does not perform the actual deletion required by law.
Options C and D are incorrect because excluding rows via a view or hashing identifiers only masks the data rather than permanently erasing it.

## Pregunta 110

Contexto: [topics:92](#topics-92)
Your company has announced that they will be outsourcing operations functions. You want to allow developers to easily stage new versions of a cloud-based application in the production environment and allow the outsourced operations team to autonomously promote staged versions to production. You want to minimize the operational overhead of the solution. Which Google Cloud product should you migrate to?

**A.** App Engine

**B.** GKE On-Prem

**C.** Compute Engine

**D.** Google Kubernetes Engine

**Respuesta de la fuente:** A

**Explicación:** App Engine is a fully managed Platform-as-a-Service (PaaS) that significantly minimizes operational overhead by handling infrastructure management automatically.
It natively supports the workflow described: developers can deploy new versions to staging, and operations teams can promote specific version IDs to production without managing underlying servers or complex Kubernetes configurations.

## Pregunta 111

Contexto: [topics:92](#topics-92)
Your company is running its application workloads on Compute Engine. The applications have been deployed in production, acceptance, and development environments. The production environment is business-critical and is used 24/7, while the acceptance and development environments are only critical during office hours. Your CFO has asked you to optimize these environments to achieve cost savings during idle times. What should you do?

**A.** Create a shell script that uses the gcloud command to change the machine type of the development and acceptance instances to a smaller machine type outside of office hours. Schedule the shell script on one of the production instances to automate the task.

**B.** Use Cloud Scheduler to trigger a Cloud Function that will stop the development and acceptance environments after office hours and start them just before office hours.

**C.** Deploy the development and acceptance applications on a managed instance group and enable autoscaling.

**D.** Use regular Compute Engine instances for the production environment, and use preemptible VMs for the acceptance and development environments.

**Respuesta de la fuente:** B

**Explicación:** Option B is the most cost-effective solution because stopping Compute Engine instances eliminates all charges for vCPU and memory during idle hours, whereas preemptible VMs (D) are only suitable for fault-tolerant tasks and autoscaling (C) does not stop instances entirely.
Scheduling stops and starts via Cloud Scheduler and Cloud Functions follows Google Cloud best practices for optimizing costs in non-critical dev/test environments without requiring custom scripting on production servers (A).

## Pregunta 112

Contexto: [topics:92](#topics-92)
You are moving an application that uses MySQL from on-premises to Google Cloud. The application will run on Compute Engine and will use Cloud SQL. You want to cut over to the Compute Engine deployment of the application with minimal downtime and no data loss to your customers. You want to migrate the application with minimal modification. You also need to determine the cutover strategy. What should you do?

**A.** 1. Set up Cloud VPN to provide private network connectivity between the Compute Engine application and the on-premises MySQL server. 2. Stop the on-premises application. 3. Create a mysqldump of the on-premises MySQL server. 4. Upload the dump to a Cloud Storage bucket. 5. Import the dump into Cloud SQL. 6. Modify the source code of the application to write queries to both databases and read from its local database. 7. Start the Compute Engine application. 8. Stop the on-premises application.

**B.** 1. Set up Cloud SQL proxy and MySQL proxy. 2. Create a mysqldump of the on-premises MySQL server. 3. Upload the dump to a Cloud Storage bucket. 4. Import the dump into Cloud SQL. 5. Stop the on-premises application. 6. Start the Compute Engine application.

**C.** 1. Set up Cloud VPN to provide private network connectivity between the Compute Engine application and the on-premises MySQL server. 2. Stop the on-premises application. 3. Start the Compute Engine application, configured to read and write to the on-premises MySQL server. 4. Create the replication configuration in Cloud SQL. 5. Configure the source database server to accept connections from the Cloud SQL replica. 6. Finalize the Cloud SQL replica configuration. 7. When replication has been completed, stop the Compute Engine application. 8. Promote the Cloud SQL replica to a standalone instance. 9. Restart the Compute Engine application, configured to read and write to the Cloud SQL standalone instance.

**D.** 1. Stop the on-premises application. 2. Create a mysqldump of the on-premises MySQL server. 3. Upload the dump to a Cloud Storage bucket. 4. Import the dump into Cloud SQL. 5. Start the application on Compute Engine.

**Respuesta de la fuente:** C

**Explicación:** Option C describes the External Replica Promotion strategy, which allows for continuous data replication to Cloud SQL while the application remains active, ensuring minimal downtime and no data loss.
In contrast, options using mysqldump (A, B, D) require stopping the application during the export/import process, resulting in significant downtime as any changes made after the snapshot are lost.
By setting up a replica, synchronizing data, and promoting it only at the final cutover step, you achieve a near-zero downtime migration with minimal application code changes.

## Pregunta 113

Contexto: [topics:92](#topics-92)
Your organization has decided to restrict the use of external IP addresses on instances to only approved instances. You want to enforce this requirement across all of your Virtual Private Clouds (VPCs). What should you do?

**A.** Remove the default route on all VPCs. Move all approved instances into a new subnet that has a default route to an internet gateway.

**B.** Create a new VPC in custom mode. Create a new subnet for the approved instances, and set a default route to the internet gateway on this new subnet.

**C.** Implement a Cloud NAT solution to remove the need for external IP addresses entirely.

**D.** Set an Organization Policy with a constraint on constraints/compute.vmExternalIpAccess. List the approved instances in the allowedValues list.

**Respuesta de la fuente:** D

**Explicación:** Organization Policy constraints provide the centralized mechanism required to enforce rules across all VPCs and projects within an organization. Specifically, the `constraints/compute.vmExternalIpAccess` constraint allows you to define a whitelist (`allowedValues`) of specific VM instances permitted to use external IP addresses, thereby restricting access for all others.

## Pregunta 114

Contexto: [topics:92](#topics-92)
Your company uses the Firewall Insights feature in the Google Network Intelligence Center. You have several firewall rules applied to Compute Engine instances.
You need to evaluate the efficiency of the applied firewall ruleset. When you bring up the Firewall Insights page in the Google Cloud Console, you notice that there are no log rows to display. What should you do to troubleshoot the issue?

**A.** Enable Virtual Private Cloud (VPC) flow logging.

**B.** Enable Firewall Rules Logging for the firewall rules you want to monitor.

**C.** Verify that your user account is assigned the compute.networkAdmin Identity and Access Management (IAM) role.

**D.** Install the Google Cloud SDK, and verify that there are no Firewall logs in the command line output.

**Respuesta de la fuente:** B

**Explicación:** Firewall Insights relies on data generated by Firewall Rules Logging to analyze traffic patterns and rule efficiency.
By default, logging is disabled for firewall rules; therefore, no log rows appear until you explicitly enable logging for the specific rules in question.
VPC flow logs (Option A) provide packet-level data but do not directly supply the metadata required for Firewall Insights without enabling the specific firewall rule logging feature.

## Pregunta 115

Contexto: [topics:92](#topics-92)
Your company has sensitive data in Cloud Storage buckets. Data analysts have Identity Access Management (IAM) permissions to read the buckets. You want to prevent data analysts from retrieving the data in the buckets from outside the office network. What should you do?

**A.** 1. Create a VPC Service Controls perimeter that includes the projects with the buckets. 2. Create an access level with the CIDR of the office network.

**B.** 1. Create a firewall rule for all instances in the Virtual Private Cloud (VPC) network for source range. 2. Use the Classless Inter-domain Routing (CIDR) of the office network.

**C.** 1. Create a Cloud Function to remove IAM permissions from the buckets, and another Cloud Function to add IAM permissions to the buckets. 2. Schedule the Cloud Functions with Cloud Scheduler to add permissions at the start of business and remove permissions at the end of business.

**D.** 1. Create a Cloud VPN to the office network. 2. Configure Private Google Access for on-premises hosts.

**Respuesta de la fuente:** A

**Explicación:** VPC Service Controls are specifically designed to create security perimeters that prevent unauthorized data exfiltration from Google Cloud services like Cloud Storage.
By defining an access level based on the office network's CIDR, you ensure that resources within the perimeter can only be accessed by users or networks meeting that condition.
This effectively blocks data retrieval from outside the designated office network, addressing the requirement to prevent external access.

## Pregunta 116

Contexto: [topics:92](#topics-92)
You have developed a non-critical update to your application that is running in a managed instance group, and have created a new instance template with the update that you want to release. To prevent any possible impact to the application, you don't want to update any running instances. You want any new instances that are created by the managed instance group to contain the new update. What should you do?

**A.** Start a new rolling restart operation.

**B.** Start a new rolling replace operation.

**C.** Start a new rolling update. Select the Proactive update mode.

**D.** Start a new rolling update. Select the Opportunistic update mode.

**Respuesta de la fuente:** D

**Explicación:** Opportunistic update mode is designed to apply configuration changes only when new instances are created or during manual selective updates, ensuring that currently running instances remain untouched.
In contrast, Proactive mode automatically triggers updates on existing instances to meet the desired state, which would violate the requirement to avoid impacting running applications.

## Pregunta 117

Contexto: [topics:92](#topics-92)
Your company is designing its application landscape on Compute Engine. Whenever a zonal outage occurs, the application should be restored in another zone as quickly as possible with the latest application data. You need to design the solution to meet this requirement. What should you do?

**A.** Create a snapshot schedule for the disk containing the application data. Whenever a zonal outage occurs, use the latest snapshot to restore the disk in the same zone.

**B.** Configure the Compute Engine instances with an instance template for the application, and use a regional persistent disk for the application data. Whenever a zonal outage occurs, use the instance template to spin up the application in another zone in the same region. Use the regional persistent disk for the application data.

**C.** Create a snapshot schedule for the disk containing the application data. Whenever a zonal outage occurs, use the latest snapshot to restore the disk in another zone within the same region.

**D.** Configure the Compute Engine instances with an instance template for the application, and use a regional persistent disk for the application data. Whenever a zonal outage occurs, use the instance template to spin up the application in another region. Use the regional persistent disk for the application data.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Regional Persistent Disks provide synchronous replication across two zones in the same region, ensuring data availability if one zone fails. The question specifically requires restoring in another *zone* (not a different region), making regional resources the appropriate choice for zonal resiliency while minimizing latency and complexity.

## Pregunta 118

Contexto: [topics:92](#topics-92)
Your company has just acquired another company, and you have been asked to integrate their existing Google Cloud environment into your company's data center. Upon investigation, you discover that some of the RFC 1918 IP ranges being used in the new company's Virtual Private Cloud (VPC) overlap with your data center IP space. What should you do to enable connectivity and make sure that there are no routing conflicts when connectivity is established?

**A.** Create a Cloud VPN connection from the new VPC to the data center, create a Cloud Router, and apply new IP addresses so there is no overlapping IP space.

**B.** Create a Cloud VPN connection from the new VPC to the data center, and create a Cloud NAT instance to perform NAT on the overlapping IP space.

**C.** Create a Cloud VPN connection from the new VPC to the data center, create a Cloud Router, and apply a custom route advertisement to block the overlapping IP space.

**D.** Create a Cloud VPN connection from the new VPC to the data center, and apply a firewall rule that blocks the overlapping IP space.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 119

Contexto: [topics:92](#topics-92)
You need to migrate Hadoop jobs for your company's Data Science team without modifying the underlying infrastructure. You want to minimize costs and infrastructure management effort. What should you do?

**A.** Create a Dataproc cluster using standard worker instances.

**B.** Create a Dataproc cluster using preemptible worker instances.

**C.** Manually deploy a Hadoop cluster on Compute Engine using standard instances.

**D.** Manually deploy a Hadoop cluster on Compute Engine using preemptible instances.

**Respuesta de la fuente:** B

**Explicación:** Google Dataproc is the managed service that minimizes infrastructure management effort compared to manually deploying Hadoop on Compute Engine.
Using preemptible worker instances significantly reduces costs while maintaining fault tolerance for batch jobs, aligning with the goal to minimize expenses.
Therefore, creating a Dataproc cluster with preemptible workers satisfies both cost and management requirements.

## Pregunta 120

Contexto: [topics:92](#topics-92)
Your company has a project in Google Cloud with three Virtual Private Clouds (VPCs). There is a Compute Engine instance on each VPC. Network subnets do not overlap and must remain separated. The network configuration is shown below.
[Imagen: sin descripción]
Instance #1 is an exception and must communicate directly with both Instance #2 and Instance #3 via internal IPs. How should you accomplish this?
Imagen · question_text · sin descripción
![Imagen original](imagenes/bc432dbb2cb270157dc7.jpg)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Y Google Cloud Platform
VPC#2
Instance #1
Compute Engine
```

**A.** Create a cloud router to advertise subnet #2 and subnet #3 to subnet #1.

**B.** Add two additional NICs to Instance #1 with the following configuration: "¢ NIC1 ○ VPC: VPC #2 ○ SUBNETWORK: subnet #2 "¢ NIC2 ○ VPC: VPC #3 ○ SUBNETWORK: subnet #3 Update firewall rules to enable traffic between instances.

**C.** Create two VPN tunnels via CloudVPN: "¢ 1 between VPC #1 and VPC #2. "¢ 1 between VPC #2 and VPC #3. Update firewall rules to enable traffic between the instances.

**D.** Peer all three VPCs: "¢ Peer VPC #1 with VPC #2. "¢ Peer VPC #2 with VPC #3. Update firewall rules to enable traffic between the instances.

**Respuesta de la fuente:** B

**Explicación:** Option B is the correct solution because multiple network interfaces allow a single Compute Engine instance to connect directly to different VPC networks without establishing transitive connectivity between those VPCs. This satisfies the requirement for Instance #1 to communicate with Instances #2 and #3 while keeping VPC #2 and VPC #3 isolated from each other.
VPC peering (Option D) creates full mesh or direct connections that would allow all three instances to communicate, violating the isolation constraint between VPCs 2 and 3.
Cloud Routers (Option A) do not facilitate internal IP routing between separate VPCs, and Cloud VPN (Option C) introduces unnecessary latency and complexity for intra-project communication.

## Pregunta 121

Contexto: [topics:92](#topics-92)
You need to deploy an application on Google Cloud that must run on a Debian Linux environment. The application requires extensive configuration in order to operate correctly. You want to ensure that you can install Debian distribution updates with minimal manual intervention whenever they become available. What should you do?

**A.** Create a Compute Engine instance template using the most recent Debian image. Create an instance from this template, and install and configure the application as part of the startup script. Repeat this process whenever a new Google-managed Debian image becomes available.

**B.** Create a Debian-based Compute Engine instance, install and configure the application, and use OS patch management to install available updates.

**C.** Create an instance with the latest available Debian image. Connect to the instance via SSH, and install and configure the application on the instance. Repeat this process whenever a new Google-managed Debian image becomes available.

**D.** Create a Docker container with Debian as the base image. Install and configure the application as part of the Docker image creation process. Host the container on Google Kubernetes Engine and restart the container whenever a new update is available.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Google Cloud OS patch management automates the installation of security patches and updates on Compute Engine instances with minimal manual intervention, directly addressing the requirement for automated Debian distribution updates. In contrast, options A and C require recreating instances from new images, which is a manual or semi-manual process that does not leverage automated patching for an existing configured environment. Option D uses Kubernetes containers, which do not handle underlying OS-level distribution updates in the same manner as host VM patch management.

## Pregunta 122

Contexto: [topics:92](#topics-92)
You have an application that runs in Google Kubernetes Engine (GKE). Over the last 2 weeks, customers have reported that a specific part of the application returns errors very frequently. You currently have no logging or monitoring solution enabled on your GKE cluster. You want to diagnose the problem, but you have not been able to replicate the issue. You want to cause minimal disruption to the application. What should you do?

**A.** 1. Update your GKE cluster to use Cloud Operations for GKE. 2. Use the GKE Monitoring dashboard to investigate logs from affected Pods.

**B.** 1. Create a new GKE cluster with Cloud Operations for GKE enabled. 2. Migrate the affected Pods to the new cluster, and redirect traffic for those Pods to the new cluster. 3. Use the GKE Monitoring dashboard to investigate logs from affected Pods.

**C.** 1. Update your GKE cluster to use Cloud Operations for GKE, and deploy Prometheus. 2. Set an alert to trigger whenever the application returns an error.

**D.** 1. Create a new GKE cluster with Cloud Operations for GKE enabled, and deploy Prometheus. 2. Migrate the affected Pods to the new cluster, and redirect traffic for those Pods to the new cluster. 3. Set an alert to trigger whenever the application returns an error.

**Respuesta de la fuente:** A

**Explicación:** The correct answer is A because enabling Cloud Operations for GKE allows you to collect logs and metrics natively without the complexity of a third-party solution like Prometheus, adhering to Google's best practices.
Migrating workloads (as suggested in B and D) introduces unnecessary risk and potential downtime, violating the requirement for minimal disruption.
Since the error is intermittent and unreplicable, setting up an alert system immediately (C) would require waiting for the next occurrence to gather data, whereas simply enabling logging allows for immediate historical analysis of recent errors if they continue or for capturing future instances as they happen.

## Pregunta 123

Contexto: [topics:92](#topics-92)
You need to deploy a stateful workload on Google Cloud. The workload can scale horizontally, but each instance needs to read and write to the same POSIX filesystem. At high load, the stateful workload needs to support up to 100 MB/s of writes. What should you do?

**A.** Use a persistent disk for each instance.

**B.** Use a regional persistent disk for each instance.

**C.** Create a Cloud Filestore instance and mount it in each instance.

**D.** Create a Cloud Storage bucket and mount it in each instance using gcsfuse.

**Respuesta de la fuente:** C

**Explicación:** Cloud Filestore is a fully managed NFS service that provides native POSIX filesystem semantics, including file locking and concurrent read/write access required by the stateful workload.

In contrast, gcsfuse mounts object storage as a filesystem but explicitly lacks POSIX compliance, does not support proper concurrency controls (last write wins), and performs poorly under high I/O loads compared to dedicated network storage.

## Pregunta 124

Contexto: [topics:92](#topics-92)
Your company has an application deployed on Anthos clusters (formerly Anthos GKE) that is running multiple microservices. The cluster has both Anthos Service
Mesh and Anthos Config Management configured. End users inform you that the application is responding very slowly. You want to identify the microservice that is causing the delay. What should you do?

**A.** Use the Service Mesh visualization in the Cloud Console to inspect the telemetry between the microservices.

**B.** Use Anthos Config Management to create a ClusterSelector selecting the relevant cluster. On the Google Cloud Console page for Google Kubernetes Engine, view the Workloads and filter on the cluster. Inspect the configurations of the filtered workloads.

**C.** Use Anthos Config Management to create a namespaceSelector selecting the relevant cluster namespace. On the Google Cloud Console page for Google Kubernetes Engine, visit the workloads and filter on the namespace. Inspect the configurations of the filtered workloads.

**D.** Reinstall istio using the default istio profile in order to collect request latency. Evaluate the telemetry between the microservices in the Cloud Console.

**Respuesta de la fuente:** A

**Explicación:** Anthos Service Mesh provides native observability dashboards in the Cloud Console that visualize traffic patterns, latency, and error rates between microservices.
This allows you to directly inspect telemetry data to identify which specific service is introducing performance delays without needing to modify configurations or restart components.

## Pregunta 125

Contexto: [topics:92](#topics-92)
You are working at a financial institution that stores mortgage loan approval documents on Cloud Storage. Any change to these approval documents must be uploaded as a separate approval file, so you want to ensure that these documents cannot be deleted or overwritten for the next 5 years. What should you do?

**A.** Create a retention policy on the bucket for the duration of 5 years. Create a lock on the retention policy.

**B.** Create the bucket with uniform bucket-level access, and grant a service account the role of Object Writer. Use the service account to upload new files.

**C.** Use a customer-managed key for the encryption of the bucket. Rotate the key after 5 years.

**D.** Create the bucket with fine-grained access control, and grant a service account the role of Object Writer. Use the service account to upload new files.

**Respuesta de la fuente:** A

**Explicación:** A Cloud Storage retention policy prevents objects from being deleted or overwritten until a specified time period has elapsed.
Locking the retention policy makes it immutable, ensuring that even administrators cannot shorten the retention period or remove the policy during the 5-year window.

## Pregunta 126

Contexto: [topics:92](#topics-92)
Your team will start developing a new application using microservices architecture on Kubernetes Engine. As part of the development lifecycle, any code change that has been pushed to the remote develop branch on your GitHub repository should be built and tested automatically. When the build and test are successful, the relevant microservice will be deployed automatically in the development environment. You want to ensure that all code deployed in the development environment follows this process. What should you do?

**A.** Have each developer install a pre-commit hook on their workstation that tests the code and builds the container when committing on the development branch. After a successful commit, have the developer deploy the newly built container image on the development cluster.

**B.** Install a post-commit hook on the remote git repository that tests the code and builds the container when code is pushed to the development branch. After a successful commit, have the developer deploy the newly built container image on the development cluster.

**C.** Create a Cloud Build trigger based on the development branch that tests the code, builds the container, and stores it in Container Registry. Create a deployment pipeline that watches for new images and deploys the new image on the development cluster. Ensure only the deployment tool has access to deploy new versions.

**D.** Create a Cloud Build trigger based on the development branch to build a new container image and store it in Container Registry. Rely on Vulnerability Scanning to ensure the code tests succeed. As the final step of the Cloud Build process, deploy the new container image on the development cluster. Ensure only Cloud Build has access to deploy new versions.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it implements a fully automated CI/CD pipeline using Cloud Build triggers to handle testing and image building upon pushes to the develop branch. It separates concerns by using a deployment pipeline to automatically deploy new images to Kubernetes, ensuring consistency and preventing manual or unauthorized deployments.

Options A and B are incorrect as they rely on developer actions rather than an automated system. Option D is incorrect because Vulnerability Scanning checks for security issues in existing images, not functional code tests.

## Pregunta 127

Contexto: [topics:92](#topics-92)
Your operations team has asked you to help diagnose a performance issue in a production application that runs on Compute Engine. The application is dropping requests that reach it when under heavy load. The process list for affected instances shows a single application process that is consuming all available CPU, and autoscaling has reached the upper limit of instances. There is no abnormal load on any other related systems, including the database. You want to allow production traffic to be served again as quickly as possible. Which action should you recommend?

**A.** Change the autoscaling metric to agent.googleapis.com/memory/percent_used.

**B.** Restart the affected instances on a staggered schedule.

**C.** SSH to each instance and restart the application process.

**D.** Increase the maximum number of instances in the autoscaling group.

**Respuesta de la fuente:** D

**Explicación:** The application is dropping requests because autoscaling has hit its configured maximum number of instances, preventing new resources from handling the load.
Increasing the maximum instance count allows the autoscaler to provision additional VMs immediately, distributing traffic and restoring service availability.
Changing metrics (A) is irrelevant since CPU is already saturated, while restarting processes or instances (B, C) causes downtime or service interruption during critical production outages.

## Pregunta 128

Contexto: [topics:92](#topics-92)
You are implementing the infrastructure for a web service on Google Cloud. The web service needs to receive and store the data from 500,000 requests per second. The data will be queried later in real time, based on exact matches of a known set of attributes. There will be periods where the web service will not receive any requests. The business wants to keep costs low. Which web service platform and database should you use for the application?

**A.** Cloud Run and BigQuery

**B.** Cloud Run and Cloud Bigtable

**C.** A Compute Engine autoscaling managed instance group and BigQuery

**D.** A Compute Engine autoscaling managed instance group and Cloud Bigtable

**Respuesta de la fuente:** B

**Explicación:** Cloud Bigtable is the correct database choice because it is designed for high-throughput, low-latency writes and real-time point lookups (exact attribute matches), whereas BigQuery has streaming insertion limits (100,000 rows/sec per table) that would bottleneck 500,000 requests.
Cloud Run is the preferred compute platform over Compute Engine because it scales to zero during periods of inactivity, satisfying the requirement to keep costs low while still supporting high concurrency via horizontal scaling.

## Pregunta 129

Contexto: [topics:92](#topics-92)
You are developing an application using different microservices that should remain internal to the cluster. You want to be able to configure each microservice with a specific number of replicas. You also want to be able to address a specific microservice from any other microservice in a uniform way, regardless of the number of replicas the microservice scales to. You need to implement this solution on Google Kubernetes Engine. What should you do?

**A.** Deploy each microservice as a Deployment. Expose the Deployment in the cluster using a Service, and use the Service DNS name to address it from other microservices within the cluster.

**B.** Deploy each microservice as a Deployment. Expose the Deployment in the cluster using an Ingress, and use the Ingress IP address to address the Deployment from other microservices within the cluster.

**C.** Deploy each microservice as a Pod. Expose the Pod in the cluster using a Service, and use the Service DNS name to address the microservice from other microservices within the cluster.

**D.** Deploy each microservice as a Pod. Expose the Pod in the cluster using an Ingress, and use the Ingress IP address name to address the Pod from other microservices within the cluster.

**Respuesta de la fuente:** A

**Explicación:** Deployments manage replica counts for microservices, satisfying the requirement to configure specific numbers of replicas, whereas Pods do not inherently handle scaling or self-healing.
A Service provides a stable internal endpoint and DNS name that remains consistent regardless of how many pod replicas are running, ensuring uniform addressability within the cluster.
Ingress is designed for external HTTP routing and is unnecessary for internal service-to-service communication, making Option A the correct choice over B.

## Pregunta 130

Contexto: [topics:92](#topics-92)
Your company has a networking team and a development team. The development team runs applications on Compute Engine instances that contain sensitive data. The development team requires administrative permissions for Compute Engine. Your company requires all network resources to be managed by the networking team. The development team does not want the networking team to have access to the sensitive data on the instances. What should you do?

**A.** 1. Create a project with a standalone VPC and assign the Network Admin role to the networking team. 2. Create a second project with a standalone VPC and assign the Compute Admin role to the development team. 3. Use Cloud VPN to join the two VPCs.

**B.** 1. Create a project with a standalone Virtual Private Cloud (VPC), assign the Network Admin role to the networking team, and assign the Compute Admin role to the development team.

**C.** 1. Create a project with a Shared VPC and assign the Network Admin role to the networking team. 2. Create a second project without a VPC, configure it as a Shared VPC service project, and assign the Compute Admin role to the development team.

**D.** 1. Create a project with a standalone VPC and assign the Network Admin role to the networking team. 2. Create a second project with a standalone VPC and assign the Compute Admin role to the development team. 3. Use VPC Peering to join the two VPCs.

**Respuesta de la fuente:** C

**Explicación:** Shared VPC is the correct solution because it enforces separation of duties by centralizing network resource management in a host project while allowing service projects to host compute resources.
This architecture prevents the networking team from accessing sensitive data on Compute Engine instances, as they lack permissions in the development team's service project.
Additionally, using separate projects avoids the security risk inherent in Option B, where the Compute Admin role includes network administration privileges that would violate the requirement for isolated network management.

## Pregunta 131

Contexto: [topics:92](#topics-92)
Your company wants you to build a highly reliable web application with a few public APIs as the backend. You don't expect a lot of user traffic, but traffic could spike occasionally. You want to leverage Cloud Load Balancing, and the solution must be cost-effective for users. What should you do?

**A.** Store static content such as HTML and images in Cloud CDN. Host the APIs on App Engine and store the user data in Cloud SQL.

**B.** Store static content such as HTML and images in a Cloud Storage bucket. Host the APIs on a zonal Google Kubernetes Engine cluster with worker nodes in multiple zones, and save the user data in Cloud Spanner.

**C.** Store static content such as HTML and images in Cloud CDN. Use Cloud Run to host the APIs and save the user data in Cloud SQL.

**D.** Store static content such as HTML and images in a Cloud Storage bucket. Use Cloud Functions to host the APIs and save the user data in Firestore.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 132

Contexto: [topics:92](#topics-92)
Your company sends all Google Cloud logs to Cloud Logging. Your security team wants to monitor the logs. You want to ensure that the security team can react quickly if an anomaly such as an unwanted firewall change or server breach is detected. You want to follow Google-recommended practices. What should you do?

**A.** Schedule a cron job with Cloud Scheduler. The scheduled job queries the logs every minute for the relevant events.

**B.** Export logs to BigQuery, and trigger a query in BigQuery to process the log data for the relevant events.

**C.** Export logs to a Pub/Sub topic, and trigger Cloud Function with the relevant log events.

**D.** Export logs to a Cloud Storage bucket, and trigger Cloud Run with the relevant log events.

**Respuesta de la fuente:** C

**Explicación:** Option C is the correct answer because it leverages Cloud Logging sinks to export filtered log entries to a Pub/Sub topic, enabling an event-driven, real-time architecture. This allows a Cloud Function to trigger immediately upon detecting specific anomalies, fulfilling the requirement for quick reaction times as recommended by Google best practices.

## Pregunta 133

Contexto: [topics:92](#topics-92)
You have deployed several instances on Compute Engine. As a security requirement, instances cannot have a public IP address. There is no VPN connection between Google Cloud and your office, and you need to connect via SSH into a specific machine without violating the security requirements. What should you do?

**A.** Configure Cloud NAT on the subnet where the instance is hosted. Create an SSH connection to the Cloud NAT IP address to reach the instance.

**B.** Add all instances to an unmanaged instance group. Configure TCP Proxy Load Balancing with the instance group as a backend. Connect to the instance using the TCP Proxy IP.

**C.** Configure Identity-Aware Proxy (IAP) for the instance and ensure that you have the role of IAP-secured Tunnel User. Use the gcloud command line tool to ssh into the instance.

**D.** Create a bastion host in the network to SSH into the bastion host from your office location. From the bastion host, SSH into the desired instance.

**Respuesta de la fuente:** C

**Explicación:** Identity-Aware Proxy (IAP) TCP forwarding allows administrators to connect to Compute Engine instances via SSH without requiring a public IP address or a VPN, satisfying the strict security constraints.
Using `gcloud compute ssh` with IAP establishes an encrypted tunnel through the IAP service, granting access based on IAM roles (specifically `compute.securityAdmin` or `iap.tunnelResourceAccessor`) rather than network-level firewall rules or external IP assignments.

## Pregunta 134

Contexto: [topics:92](#topics-92)
Your company is using Google Cloud. You have two folders under the Organization: Finance and Shopping. The members of the development team are in a
Google Group. The development team group has been assigned the Project Owner role on the Organization. You want to prevent the development team from creating resources in projects in the Finance folder. What should you do?

**A.** Assign the development team group the Project Viewer role on the Finance folder, and assign the development team group the Project Owner role on the Shopping folder.

**B.** Assign the development team group only the Project Viewer role on the Finance folder.

**C.** Assign the development team group the Project Owner role on the Shopping folder, and remove the development team group Project Owner role from the Organization.

**D.** Assign the development team group only the Project Owner role on the Shopping folder.

**Respuesta de la fuente:** C

**Explicación:** IAM permissions in Google Cloud are hierarchical and inherit from parent resources. Since the development group holds the Project Owner role at the Organization level, they implicitly have these high-privilege permissions on all descendant folders, including Finance. Assigning a more restrictive role like Viewer to the Finance folder does not override the inherited Owner permissions from the Organization level (Option A and B). Therefore, you must remove the broad Organization-level binding and explicitly grant access only to the intended scope, which is the Shopping folder (Option C).

## Pregunta 135

Contexto: [topics:92](#topics-92)
You are developing your microservices application on Google Kubernetes Engine. During testing, you want to validate the behavior of your application in case a specific microservice should suddenly crash. What should you do?

**A.** Add a taint to one of the nodes of the Kubernetes cluster. For the specific microservice, configure a pod anti-affinity label that has the name of the tainted node as a value.

**B.** Use Istio's fault injection on the particular microservice whose faulty behavior you want to simulate.

**C.** Destroy one of the nodes of the Kubernetes cluster to observe the behavior.

**D.** Configure Istio's traffic management features to steer the traffic away from a crashing microservice.

**Respuesta de la fuente:** B

**Explicación:** Istio's fault injection capabilities allow you to simulate specific failure scenarios, such as a microservice crash or high latency, without actually destroying resources. This enables safe validation of application resilience and error handling during testing. In contrast, destroying nodes (C) is destructive and affects multiple pods, while taints (A) and traffic steering (D) do not simulate the service failure itself.

## Pregunta 136

Contexto: [topics:92](#topics-92)
Your company is developing a new application that will allow globally distributed users to upload pictures and share them with other selected users. The application will support millions of concurrent users. You want to allow developers to focus on just building code without having to create and maintain the underlying infrastructure. Which service should you use to deploy the application?

**A.** App Engine

**B.** Cloud Endpoints

**C.** Compute Engine

**D.** Google Kubernetes Engine

**Respuesta de la fuente:** A

**Explicación:** The key requirement is for developers to focus solely on code without maintaining underlying infrastructure. App Engine is a fully managed Platform-as-a-Service (PaaS) that abstracts away server and operating system management, allowing automatic scaling for millions of users. In contrast, Compute Engine and GKE require significant infrastructure provisioning and maintenance, while Cloud Endpoints is an API management service, not a deployment runtime.

## Pregunta 137

Contexto: [topics:92](#topics-92)
Your company provides a recommendation engine for retail customers. You are providing retail customers with an API where they can submit a user ID and the
API returns a list of recommendations for that user. You are responsible for the API lifecycle and want to ensure stability for your customers in case the API makes backward-incompatible changes. You want to follow Google-recommended practices. What should you do?

**A.** Create a distribution list of all customers to inform them of an upcoming backward-incompatible change at least one month before replacing the old API with the new API.

**B.** Create an automated process to generate API documentation, and update the public API documentation as part of the CI/CD process when deploying an update to the API.

**C.** Use a versioning strategy for the APIs that increases the version number on every backward-incompatible change.

**D.** Use a versioning strategy for the APIs that adds the suffix "DEPRECATED" to the current API version number on every backward-incompatible change. Use the current version number for the new API.

**Respuesta de la fuente:** C

**Explicación:** Google API Design Best Practices recommend using versioning to manage breaking changes and ensure stability for clients.
When a backward-incompatible change is introduced, the major version number must be incremented (e.g., v1 to v2) so that existing client code continues to function without modification.
This allows developers to migrate to the new version at their own pace while maintaining access to the old stable version.

## Pregunta 138

Contexto: [topics:92](#topics-92)
Your company has developed a monolithic, 3-tier application to allow external users to upload and share files. The solution cannot be easily enhanced and lacks reliability. The development team would like to re-architect the application to adopt microservices and a fully managed service approach, but they need to convince their leadership that the effort is worthwhile. Which advantage(s) should they highlight to leadership?

**A.** The new approach will be significantly less costly, make it easier to manage the underlying infrastructure, and automatically manage the CI/CD pipelines.

**B.** The monolithic solution can be converted to a container with Docker. The generated container can then be deployed into a Kubernetes cluster.

**C.** The new approach will make it easier to decouple infrastructure from application, develop and release new features, manage the underlying infrastructure, manage CI/CD pipelines and perform A/B testing, and scale the solution if necessary.

**D.** The process can be automated with Migrate for Compute Engine.

**Respuesta de la fuente:** C

**Explicación:** Option C correctly identifies the key architectural benefits of microservices and fully managed services that address the stated problems of poor maintainability and reliability.
These benefits include decoupling infrastructure from application code, enabling independent feature development and releases, simplifying CI/CD management, facilitating A/B testing, and allowing granular scaling.
Option A is incorrect because moving to microservices does not guarantee lower costs (often initial costs rise) nor does it automatically manage CI/CD pipelines without configuration.

## Pregunta 139

Contexto: [topics:92](#topics-92)
Your team is developing a web application that will be deployed on Google Kubernetes Engine (GKE). Your CTO expects a successful launch and you need to ensure your application can handle the expected load of tens of thousands of users. You want to test the current deployment to ensure the latency of your application stays below a certain threshold. What should you do?

**A.** Use a load testing tool to simulate the expected number of concurrent users and total requests to your application, and inspect the results.

**B.** Enable autoscaling on the GKE cluster and enable horizontal pod autoscaling on your application deployments. Send curl requests to your application, and validate if the auto scaling works.

**C.** Replicate the application over multiple GKE clusters in every Google Cloud region. Configure a global HTTP(S) load balancer to expose the different clusters over a single global IP address.

**D.** Use Cloud Debugger in the development environment to understand the latency between the different microservices.

**Respuesta de la fuente:** A

**Explicación:** The objective is to verify that application latency remains below a specific threshold under a load of tens of thousands of users.
Load testing tools are specifically designed to simulate high concurrency and generate realistic traffic patterns to measure performance metrics like latency, throughput, and error rates.
Manual checks like `curl` or debugging tools do not provide the statistical significance or volume required to validate system behavior at scale.

## Pregunta 140

Contexto: [topics:92](#topics-92)
Your company has a Kubernetes application that pulls messages from Pub/Sub and stores them in Filestore. Because the application is simple, it was deployed as a single pod. The infrastructure team has analyzed Pub/Sub metrics and discovered that the application cannot process the messages in real time. Most of them wait for minutes before being processed. You need to scale the elaboration process that is I/O-intensive. What should you do?

**A.** Use kubectl autoscale deployment APP_NAME --max 6 --min 2 --cpu-percent 50 to configure Kubernetes autoscaling deployment.

**B.** Configure a Kubernetes autoscaling deployment based on the subscription/push_request_latencies metric.

**C.** Use the --enable-autoscaling flag when you create the Kubernetes cluster.

**D.** Configure a Kubernetes autoscaling deployment based on the subscription/num_undelivered_messages metric.

**Respuesta de la fuente:** D

**Explicación:** The core issue is that the application cannot process messages fast enough, leading to a backlog. The `subscription/num_undelivered_messages` metric directly measures this backlog size, allowing Kubernetes to scale out pods specifically when the queue depth exceeds a threshold.
This approach uses Horizontal Pod Autoscaler (HPA) with external metrics, which is the standard method for scaling based on Pub/Sub subscription status in Google Kubernetes Engine (GKE).

## Pregunta 141

Contexto: [topics:92](#topics-92)
Your company is developing a web-based application. You need to make sure that production deployments are linked to source code commits and are fully auditable. What should you do?

**A.** Make sure a developer is tagging the code commit with the date and time of commit.

**B.** Make sure a developer is adding a comment to the commit that links to the deployment.

**C.** Make the container tag match the source code commit hash.

**D.** Make sure the developer is tagging the commits with latest.

**Respuesta de la fuente:** C

**Explicación:** Using the immutable Git commit hash as the container image tag creates a permanent, verifiable link between the deployed artifact and the exact source code revision. This automated approach ensures full auditability by allowing engineers to trace any running production instance back to a specific commit without relying on error-prone manual tagging or metadata.

## Pregunta 142

Contexto: [topics:92](#topics-92)
An application development team has come to you for advice. They are planning to write and deploy an HTTP(S) API using Go 1.12. The API will have a very unpredictable workload and must remain reliable during peaks in traffic. They want to minimize operational overhead for this application. Which approach should you recommend?

**A.** Develop the application with containers, and deploy to Google Kubernetes Engine.

**B.** Develop the application for App Engine standard environment.

**C.** Use a Managed Instance Group when deploying to Compute Engine.

**D.** Develop the application for App Engine flexible environment, using a custom runtime.

**Respuesta de la fuente:** B

**Explicación:** App Engine Standard Environment is the optimal choice because it natively supports Go 1.12 and provides automatic, instant scaling to handle unpredictable traffic spikes.
It minimizes operational overhead by managing infrastructure automatically, including scaling to zero instances when idle to reduce costs.

## Pregunta 143

Contexto: [topics:92](#topics-92)
Your company is designing its data lake on Google Cloud and wants to develop different ingestion pipelines to collect unstructured data from different sources.
After the data is stored in Google Cloud, it will be processed in several data pipelines to build a recommendation engine for end users on the website. The structure of the data retrieved from the source systems can change at any time. The data must be stored exactly as it was retrieved for reprocessing purposes in case the data structure is incompatible with the current processing pipelines. You need to design an architecture to support the use case after you retrieve the data. What should you do?

**A.** Send the data through the processing pipeline, and then store the processed data in a BigQuery table for reprocessing.

**B.** Store the data in a BigQuery table. Design the processing pipelines to retrieve the data from the table.

**C.** Send the data through the processing pipeline, and then store the processed data in a Cloud Storage bucket for reprocessing.

**D.** Store the data in a Cloud Storage bucket. Design the processing pipelines to retrieve the data from the bucket.

**Respuesta de la fuente:** D

**Explicación:** The requirement to store data exactly as retrieved for reprocessing mandates an Extract-Load-Transform (ELT) pattern where raw data is persisted before any schema enforcement or transformation.
Cloud Storage is the appropriate service for storing unstructured, schema-less raw data in a data lake architecture, whereas BigQuery requires a defined schema that would conflict with the changing source structures.

## Pregunta 144

Contexto: [topics:92](#topics-92)
You are responsible for the Google Cloud environment in your company. Multiple departments need access to their own projects, and the members within each department will have the same project responsibilities. You want to structure your Google Cloud environment for minimal maintenance and maximum overview of
IAM permissions as each department's projects start and end. You want to follow Google-recommended practices. What should you do?

**A.** Grant all department members the required IAM permissions for their respective projects.

**B.** Create a Google Group per department and add all department members to their respective groups. Create a folder per department and grant the respective group the required IAM permissions at the folder level. Add the projects under the respective folders.

**C.** Create a folder per department and grant the respective members of the department the required IAM permissions at the folder level. Structure all projects for each department under the respective folders.

**D.** Create a Google Group per department and add all department members to their respective groups. Grant each group the required IAM permissions for their respective projects.

**Respuesta de la fuente:** B

**Explicación:** Option B follows Google-recommended practices by leveraging organizational hierarchy (folders) for bulk resource management and Google Groups for identity abstraction.
Granting IAM permissions to a Group at the Folder level allows all member projects within that folder to inherit those permissions automatically, significantly reducing maintenance overhead compared to managing individual user or project-level bindings.

## Pregunta 145

Contexto: [topics:92](#topics-92)
Your company has an application running as a Deployment in a Google Kubernetes Engine (GKE) cluster. You have separate clusters for development, staging, and production. You have discovered that the team is able to deploy a Docker image to the production cluster without first testing the deployment in development and then staging. You want to allow the team to have autonomy but want to prevent this from happening. You want a Google Cloud solution that can be implemented quickly with minimal effort. What should you do?

**A.** Configure a Kubernetes lifecycle hook to prevent the container from starting if it is not approved for usage in the given environment.

**B.** Implement a corporate policy to prevent teams from deploying Docker images to an environment unless the Docker image was tested in an earlier environment.

**C.** Configure binary authorization policies for the development, staging, and production clusters. Create attestations as part of the continuous integration pipeline.

**D.** Create a Kubernetes admissions controller to prevent the container from starting if it is not approved for usage in the given environment.

**Respuesta de la fuente:** C

**Explicación:** Binary Authorization is the native GKE feature designed to enforce policies on container images before they are deployed. By requiring attestations generated during the CI pipeline for development and staging, it technically prevents untested images from being admitted into production.
This approach provides automated enforcement with minimal effort, unlike corporate policies (which rely on human compliance) or custom admission controllers/lifecycle hooks (which require more complex implementation).

## Pregunta 146

Contexto: [topics:92](#topics-92)
Your company wants to migrate their 10-TB on-premises database export into Cloud Storage. You want to minimize the time it takes to complete this activity, the overall cost, and database load. The bandwidth between the on-premises environment and Google Cloud is 1 Gbps. You want to follow Google-recommended practices. What should you do?

**A.** Develop a Dataflow job to read data directly from the database and write it into Cloud Storage.

**B.** Use the Data Transfer appliance to perform an offline migration.

**C.** Use a commercial partner ETL solution to extract the data from the on-premises database and upload it into Cloud Storage.

**D.** Compress the data and upload it with gsutil -m to enable multi-threaded copy.

**Respuesta de la fuente:** B

**Explicación:** The question specifies minimizing time, cost, and database load for a 10 TB transfer with only 1 Gbps bandwidth. An online transfer via gsutil (Option D) would take approximately 30 hours, keeping the network saturated and potentially impacting other workloads, whereas offline transfers are recommended when online speeds exceed acceptable timelines or data sizes are large. Although Google documentation often cites >40 TB for Transfer Appliance recommendations to offset shipping time, in the context of minimizing database load and avoiding long-duration network saturation on a limited 1 Gbps link, the offline Data Transfer Appliance (Option B) is the prescribed solution for large, bulk migrations where online bandwidth is a bottleneck. Options A and C involve ETL processes that impose significant load on the source database, violating the constraint to minimize database load.

## Pregunta 147

Contexto: [topics:92](#topics-92)
Your company has an enterprise application running on Compute Engine that requires high availability and high performance. The application has been deployed on two instances in two zones in the same region in active-passive mode. The application writes data to a persistent disk. In the case of a single zone outage, that data should be immediately made available to the other instance in the other zone. You want to maximize performance while minimizing downtime and data loss.
What should you do?

**A.** 1. Attach a persistent SSD disk to the first instance. 2. Create a snapshot every hour. 3. In case of a zone outage, recreate a persistent SSD disk in the second instance where data is coming from the created snapshot.

**B.** 1. Create a Cloud Storage bucket. 2. Mount the bucket into the first instance with gcs-fuse. 3. In case of a zone outage, mount the Cloud Storage bucket to the second instance with gcs-fuse.

**C.** 1. Attach a regional SSD persistent disk to the first instance. 2. In case of a zone outage, force-attach the disk to the other instance.

**D.** 1. Attach a local SSD to the first instance disk. 2. Execute an rsync command every hour where the target is a persistent SSD disk attached to the second instance. 3. In case of a zone outage, use the second instance.

**Respuesta de la fuente:** C

**Explicación:** Regional persistent SSDs provide synchronous replication across two zones within a region, ensuring data availability in the event of a single zone failure.
Unlike zonal disks or snapshot-based recovery, force-attaching a regional disk to an instance in the surviving zone allows for immediate access to data with minimal downtime and no data loss.
Other options like Cloud Storage (gcs-fuse) offer lower performance, while snapshots and rsync introduce significant latency and potential data loss during the replication window.

## Pregunta 148

Contexto: [topics:92](#topics-92)
You are designing a Data Warehouse on Google Cloud and want to store sensitive data in BigQuery. Your company requires you to generate the encryption keys outside of Google Cloud. You need to implement a solution. What should you do?

**A.** Generate a new key in Cloud Key Management Service (Cloud KMS). Store all data in Cloud Storage using the customer-managed key option and select the created key. Set up a Dataflow pipeline to decrypt the data and to store it in a new BigQuery dataset.

**B.** Generate a new key in Cloud KMS. Create a dataset in BigQuery using the customer-managed key option and select the created key.

**C.** Import a key in Cloud KMS. Store all data in Cloud Storage using the customer-managed key option and select the created key. Set up a Dataflow pipeline to decrypt the data and to store it in a new BigQuery dataset.

**D.** Import a key in Cloud KMS. Create a dataset in BigQuery using the customer-supplied key option and select the created key.

**Respuesta de la fuente:** D

**Explicación:** The requirement to generate keys outside of Google Cloud necessitates importing the key into Cloud KMS rather than generating a new one there, eliminating options A and B.
BigQuery encryption uses Customer-Managed Encryption Keys (CMEK) stored in Cloud KMS; once an external key is imported into KMS, it functions as a CMEK for BigQuery datasets.
Option D correctly identifies the need to import the key and use it with BigQuery, whereas option C incorrectly suggests storing data in Cloud Storage and using Dataflow for decryption, which is unnecessary complexity for native BigQuery encryption.

## Pregunta 149

Contexto: [topics:92](#topics-92)
Your organization has stored sensitive data in a Cloud Storage bucket. For regulatory reasons, your company must be able to rotate the encryption key used to encrypt the data in the bucket. The data will be processed in Dataproc. You want to follow Google-recommended practices for security. What should you do?

**A.** Create a key with Cloud Key Management Service (KMS). Encrypt the data using the encrypt method of Cloud KMS.

**B.** Create a key with Cloud Key Management Service (KMS). Set the encryption key on the bucket to the Cloud KMS key.

**C.** Generate a GPG key pair. Encrypt the data using the GPG key. Upload the encrypted data to the bucket.

**D.** Generate an AES-256 encryption key. Encrypt the data in the bucket using the customer-supplied encryption keys feature.

**Respuesta de la fuente:** B

**Explicación:** Using Cloud Key Management Service (KMS) with Customer-Managed Keys (CMKs) allows you to set a default encryption key for the entire bucket.
This configuration enables automated, seamless key rotation and re-encryption of data without manual intervention per object.
It adheres to Google-recommended best practices by centralizing key management while meeting regulatory requirements for control over encryption keys.

## Pregunta 150

Contexto: [topics:92](#topics-92)
Your team needs to create a Google Kubernetes Engine (GKE) cluster to host a newly built application that requires access to third-party services on the internet.
Your company does not allow any Compute Engine instance to have a public IP address on Google Cloud. You need to create a deployment strategy that adheres to these guidelines. What should you do?

**A.** Configure the GKE cluster as a private cluster, and configure Cloud NAT Gateway for the cluster subnet.

**B.** Configure the GKE cluster as a private cluster. Configure Private Google Access on the Virtual Private Cloud (VPC).

**C.** Configure the GKE cluster as a route-based cluster. Configure Private Google Access on the Virtual Private Cloud (VPC).

**D.** Create a Compute Engine instance, and install a NAT Proxy on the instance. Configure all workloads on GKE to pass through this proxy to access third-party services on the Internet.

**Respuesta de la fuente:** A

**Explicación:** A private GKE cluster ensures nodes have no public IP addresses, satisfying the security requirement.
Cloud NAT Gateway allows these private instances to initiate outbound connections to third-party internet services while hiding their internal IPs.
Private Google Access (Option B) only permits access to Google APIs and Services, not general internet traffic.

## Pregunta 151

Contexto: [topics:92](#topics-92)
Your company has a support ticketing solution that uses App Engine Standard. The project that contains the App Engine application already has a Virtual Private
Cloud (VPC) network fully connected to the company's on-premises environment through a Cloud VPN tunnel. You want to enable the App Engine application to communicate with a database that is running in the company's on-premises environment. What should you do?

**A.** Configure private Google access for on-premises hosts only.

**B.** Configure private Google access.

**C.** Configure private services access.

**D.** Configure serverless VPC access.

**Respuesta de la fuente:** D

**Explicación:** App Engine Standard runs in a managed environment isolated from the VPC network. To allow App Engine applications to communicate with resources on a VPC network, you must configure Serverless VPC Access. This creates a connector that routes traffic from App Engine through the existing VPC and Cloud VPN tunnel to the on-premises database.

## Pregunta 152

Contexto: [topics:92](#topics-92)
Your company is planning to upload several important files to Cloud Storage. After the upload is completed, they want to verify that the uploaded content is identical to what they have on-premises. You want to minimize the cost and effort of performing this check. What should you do?

**A.** 1. Use Linux shasum to compute a digest of files you want to upload. 2. Use gsutil -m to upload all the files to Cloud Storage. 3. Use gsutil cp to download the uploaded files. 4. Use Linux shasum to compute a digest of the downloaded files. 5. Compare the hashes.

**B.** 1. Use gsutil -m to upload the files to Cloud Storage. 2. Develop a custom Java application that computes CRC32C hashes. 3. Use gsutil ls -L gs://[YOUR_BUCKET_NAME] to collect CRC32C hashes of the uploaded files. 4. Compare the hashes.

**C.** 1. Use gsutil -m to upload all the files to Cloud Storage. 2. Use gsutil cp to download the uploaded files. 3. Use Linux diff to compare the content of the files.

**D.** 1. Use gsutil -m to upload the files to Cloud Storage. 2. Use gsutil hash -c FILE_NAME to generate CRC32C hashes of all on-premises files. 3. Use gsutil ls -L gs://[YOUR_BUCKET_NAME] to collect CRC32C hashes of the uploaded files. 4. Compare the hashes.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it minimizes cost and effort by avoiding the need to download files for comparison. Instead, it leverages `gsutil hash` to generate local CRC32C checksums and `gsutil ls -L` to retrieve server-side checksums, allowing a simple string comparison. Options A and C incur unnecessary egress costs and latency by downloading files, while Option B introduces complexity by requiring custom development.

## Pregunta 153

Contexto: [topics:92](#topics-92)
You have deployed an application on Anthos clusters (formerly Anthos GKE). According to the SRE practices at your company, you need to be alerted if request latency is above a certain threshold for a specified amount of time. What should you do?

**A.** Install Anthos Service Mesh on your cluster. Use the Google Cloud Console to define a Service Level Objective (SLO), and create an alerting policy based on this SLO.

**B.** Enable the Cloud Trace API on your project, and use Cloud Monitoring Alerts to send an alert based on the Cloud Trace metrics.

**C.** Use Cloud Profiler to follow up the request latency. Create a custom metric in Cloud Monitoring based on the results of Cloud Profiler, and create an Alerting policy in case this metric exceeds the threshold.

**D.** Configure Anthos Config Management on your cluster, and create a yaml file that defines the SLO and alerting policy you want to deploy in your cluster.

**Respuesta de la fuente:** A

**Explicación:** Anthos Service Mesh integrates with Cloud Monitoring to define Service Level Objectives (SLOs) based on latency metrics. You can directly configure alerting policies in the Google Cloud Console that trigger when an SLO's error budget is consumed or specific latency thresholds are breached, which aligns with SRE best practices. Options B and C involve tools (Cloud Trace, Cloud Profiler) designed for diagnostic debugging rather than continuous monitoring and threshold-based alerting.

## Pregunta 154

Contexto: [topics:92](#topics-92)
Your company has a stateless web API that performs scientific calculations. The web API runs on a single Google Kubernetes Engine (GKE) cluster. The cluster is currently deployed in us-central1. Your company has expanded to offer your API to customers in Asia. You want to reduce the latency for users in Asia.
What should you do?

**A.** Create a second GKE cluster in asia-southeast1, and expose both APIs using a Service of type LoadBalancer. Add the public IPs to the Cloud DNS zone.

**B.** Use a global HTTP(s) load balancer with Cloud CDN enabled.

**C.** Create a second GKE cluster in asia-southeast1, and use kubemci to create a global HTTP(s) load balancer.

**D.** Increase the memory and CPU allocated to the application in the cluster.

**Respuesta de la fuente:** C

**Explicación:** To reduce latency for global users accessing a stateless API, you must deploy the application in a region closer to them (Asia).
A standard Service LoadBalancer only creates an L4 TCP/UDP load balancer, which lacks the intelligent HTTP-based routing required to direct traffic based on user geography.
While kubemci is deprecated and Multi-Cluster Ingress is the modern equivalent, Option C correctly identifies the architectural pattern of using a centralized controller to manage global HTTP(S) load balancing across multiple GKE clusters.

## Pregunta 155

Contexto: [topics:92](#topics-92)
You are migrating third-party applications from optimized on-premises virtual machines to Google Cloud. You are unsure about the optimum CPU and memory options. The applications have a consistent usage pattern across multiple weeks. You want to optimize resource usage for the lowest cost. What should you do?

**A.** Create an instance template with the smallest available machine type, and use an image of the third-party application taken from a current on-premises virtual machine. Create a managed instance group that uses average CPU utilization to autoscale the number of instances in the group. Modify the average CPU utilization threshold to optimize the number of instances running.

**B.** Create an App Engine flexible environment, and deploy the third-party application using a Dockerfile and a custom runtime. Set CPU and memory options similar to your application's current on-premises virtual machine in the app.yaml file.

**C.** Create multiple Compute Engine instances with varying CPU and memory options. Install the Cloud Monitoring agent, and deploy the third-party application on each of them. Run a load test with high traffic levels on the application, and use the results to determine the optimal settings.

**D.** Create a Compute Engine instance with CPU and memory options similar to your application's current on-premises virtual machine. Install the Cloud Monitoring agent, and deploy the third-party application. Run a load test with normal traffic levels on the application, and follow the Rightsizing Recommendations in the Cloud Console.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it leverages Google Cloud's built-in Rightsizing Recommendations feature, which specifically analyzes usage patterns over time to suggest optimal CPU and memory configurations for cost efficiency.
The question states the application has a 'consistent usage pattern across multiple weeks,' which aligns with the data requirements for rightsizing algorithms to generate accurate recommendations.
Option A is incorrect because it relies on autoscaling based only on average CPU, ignoring memory constraints and the need for proper initial sizing.

## Pregunta 156

Contexto: [topics:92](#topics-92)
Your company has a Google Cloud project that uses BigQuery for data warehousing. They have a VPN tunnel between the on-premises environment and Google
Cloud that is configured with Cloud VPN. The security team wants to avoid data exfiltration by malicious insiders, compromised code, and accidental oversharing.
What should they do?

**A.** Configure Private Google Access for on-premises only.

**B.** Perform the following tasks: 1. Create a service account. 2. Give the BigQuery JobUser role and Storage Reader role to the service account. 3. Remove all other IAM access from the project.

**C.** Configure VPC Service Controls and configure Private Google Access.

**D.** Configure Private Google Access.

**Respuesta de la fuente:** C

**Explicación:** VPC Service Controls are specifically designed to prevent data exfiltration by restricting resource access within a defined perimeter, protecting against malicious insiders and compromised credentials. Private Google Access allows on-premises resources to communicate with Google APIs without using public IP addresses, supporting the hybrid setup while maintaining security boundaries.

## Pregunta 157

Contexto: [topics:92](#topics-92)
You are working at an institution that processes medical data. You are migrating several workloads onto Google Cloud. Company policies require all workloads to run on physically separated hardware, and workloads from different clients must also be separated. You created a sole-tenant node group and added a node for each client. You need to deploy the workloads on these dedicated hosts. What should you do?

**A.** Add the node group name as a network tag when creating Compute Engine instances in order to host each workload on the correct node group.

**B.** Add the node name as a network tag when creating Compute Engine instances in order to host each workload on the correct node.

**C.** Use node affinity labels based on the node group name when creating Compute Engine instances in order to host each workload on the correct node group.

**D.** Use node affinity labels based on the node name when creating Compute Engine instances in order to host each workload on the correct node.

**Respuesta de la fuente:** D

**Explicación:** The requirement specifies that workloads from different clients must be separated on dedicated nodes within a sole-tenant node group. To ensure each client's workload runs on its specific physical node, you must use node affinity rules targeting the individual node name (Key: compute.googleapis.com/node-name). Using node group affinity would place VMs on any available node in the group, failing to guarantee isolation between clients on distinct hardware.

## Pregunta 158

Contexto: [topics:92](#topics-92)
Your company's test suite is a custom C++ application that runs tests throughout each day on Linux virtual machines. The full test suite takes several hours to complete, running on a limited number of on-premises servers reserved for testing. Your company wants to move the testing infrastructure to the cloud, to reduce the amount of time it takes to fully test a change to the system, while changing the tests as little as possible.
Which cloud infrastructure should you recommend?

**A.** Google Compute Engine unmanaged instance groups and Network Load Balancer

**B.** Google Compute Engine managed instance groups with auto-scaling

**C.** Google Cloud Dataproc to run Apache Hadoop jobs to process each test

**D.** Google App Engine with Google StackDriver for logging

**Respuesta de la fuente:** B

**Explicación:** Google Compute Engine Managed Instance Groups (MIGs) with auto-scaling allow you to dynamically provision more VM instances based on demand, reducing the total time to run the test suite by parallelizing execution. This approach requires minimal changes to the existing C++ application code, satisfying the constraint to change tests as little as possible.

In contrast, App Engine (Option D) would require significant refactoring for a custom Linux-based C++ app, and Dataproc (Option C) is designed for big data processing rather than generic VM-based testing. Unmanaged instance groups (Option A) lack the auto-scaling capability needed to automatically handle variable load and reduce execution time.

## Pregunta 159

Contexto: [topics:92](#topics-92)
A lead software engineer tells you that his new application design uses websockets and HTTP sessions that are not distributed across the web servers. You want to help him ensure his application will run properly on Google Cloud Platform.
What should you do?

**A.** Help the engineer to convert his websocket code to use HTTP streaming

**B.** Review the encryption requirements for websocket connections with the security team

**C.** Meet with the cloud operations team and the engineer to discuss load balancer options

**D.** Help the engineer redesign the application to use a distributed user session service that does not rely on websockets and HTTP sessions.

**Respuesta de la fuente:** C

**Explicación:** The core challenge is that non-distributed HTTP sessions require session affinity (sticky sessions) to function correctly across multiple web servers.
Google Cloud Platform's HTTP(S) Load Balancer natively supports WebSocket connections and can be configured to maintain client affinity, ensuring requests from a specific user are routed to the same backend instance.
Meeting with the cloud operations team allows you to configure these load balancing settings without forcing unnecessary application redesigns (Options A and D) or addressing unrelated security concerns (Option B).

## Pregunta 160

Contexto: [topics:92](#topics-92)
The application reliability team at your company this added a debug feature to their backend service to send all server events to Google Cloud Storage for eventual analysis. The event records are at least 50 KB and at most 15 MB and are expected to peak at 3,000 events per second. You want to minimize data loss.
Which process should you implement?

**A.** "¢ Append metadata to file body "¢ Compress individual files "¢ Name files with serverName — Timestamp "¢ Create a new bucket if bucket is older than 1 hour and save individual files to the new bucket. Otherwise, save files to existing bucket.

**B.** "¢ Batch every 10,000 events with a single manifest file for metadata "¢ Compress event files and manifest file into a single archive file "¢ Name files using serverName — EventSequence "¢ Create a new bucket if bucket is older than 1 day and save the single archive file to the new bucket. Otherwise, save the single archive file to existing bucket.

**C.** "¢ Compress individual files "¢ Name files with serverName — EventSequence "¢ Save files to one bucket "¢ Set custom metadata headers for each object after saving

**D.** "¢ Append metadata to file body "¢ Compress individual files "¢ Name files with a random prefix pattern "¢ Save files to one bucket

**Respuesta de la fuente:** D

**Explicación:** To minimize data loss at high throughput rates (3,000 writes/sec), you must prevent Google Cloud Storage hotspots by using randomized prefixes in object names. Randomized prefixes ensure that write requests are distributed evenly across multiple servers rather than being bottlenecked on a single machine. Creating new buckets frequently or using predictable naming conventions can lead to throttling or increased latency.

## Pregunta 161

Contexto: [topics:92](#topics-92)
A recent audit revealed that a new network was created in your GCP project. In this network, a GCE instance has an SSH port open to the world. You want to discover this network's origin.
What should you do?

**A.** Search for Create VM entry in the Stackdriver alerting console

**B.** Navigate to the Activity page in the Home section. Set category to Data Access and search for Create VM entry

**C.** In the Logging section of the console, specify GCE Network as the logging section. Search for the Create Insert entry

**D.** Connect to the GCE instance using project SSH keys. Identify previous logins in system logs, and match these with the project owners list

**Respuesta de la fuente:** C

**Explicación:** Creating a network and its associated firewall rules constitutes an administrative action, which is recorded in Admin activity audit logs rather than Data Access or system event logs.
By navigating to the Logging section and filtering for GCE Network resources with 'Create' or 'Insert' methods, you can identify the exact timestamp and principal (user/service account) responsible for the resource creation.

## Pregunta 162

Contexto: [topics:92](#topics-92)
You want to make a copy of a production Linux virtual machine in the US-Central region. You want to manage and replace the copy easily if there are changes on the production virtual machine. You will deploy the copy as a new instance in a different project in the US-East region.
What steps must you take?

**A.** Use the Linux dd and netcat commands to copy and stream the root disk contents to a new virtual machine instance in the US-East region.

**B.** Create a snapshot of the root disk and select the snapshot as the root disk when you create a new virtual machine instance in the US-East region.

**C.** Create an image file from the root disk with Linux dd command, create a new virtual machine instance in the US-East region

**D.** Create a snapshot of the root disk, create an image file in Google Cloud Storage from the snapshot, and create a new virtual machine instance in the US-East region using the image file the root disk.

**Respuesta de la fuente:** D

**Explicación:** The scenario requires deploying a VM in a different project, which necessitates sharing the boot disk configuration across project boundaries.
While snapshots are global resources, directly attaching a snapshot from another project as a root disk is not supported without first converting it into a custom image that can be shared or accessed by the target project.
Option D correctly outlines the process: creating a snapshot, exporting it to an image file (custom image) in Cloud Storage, and using that image to boot the new instance, ensuring proper isolation and ease of management.

## Pregunta 163

Contexto: [topics:92](#topics-92)
Your company runs several databases on a single MySQL instance. They need to take backups of a specific database at regular intervals. The backup activity needs to complete as quickly as possible and cannot be allowed to impact disk performance.
How should you configure the storage?

**A.** Configure a cron job to use the gcloud tool to take regular backups using persistent disk snapshots.

**B.** Mount a Local SSD volume as the backup location. After the backup is complete, use gsutil to move the backup to Google Cloud Storage.

**C.** Use gcsfise to mount a Google Cloud Storage bucket as a volume directly on the instance and write backups to the mounted location using mysqldump.

**D.** Mount additional persistent disk volumes onto each virtual machine (VM) instance in a RAID10 array and use LVM to create snapshots to send to Cloud Storage

**Respuesta de la fuente:** B

**Explicación:** Option B is the correct configuration because Local SSDs provide high-throughput, low-latency block storage that minimizes I/O contention on the production database disk.
By staging backups locally first, the backup process completes quickly without impacting disk performance, as required by the scenario.
Subsequently moving the data to Cloud Storage via gsutil decouples the network transfer from the critical database backup window.

## Pregunta 164

Contexto: [topics:92](#topics-92)
You are helping the QA team to roll out a new load-testing tool to test the scalability of your primary cloud services that run on Google Compute Engine with Cloud
Bigtable.
Which three requirements should they include? (Choose three.)

**A.** Ensure that the load tests validate the performance of Cloud Bigtable

**B.** Create a separate Google Cloud project to use for the load-testing environment

**C.** Schedule the load-testing tool to regularly run against the production environment

**D.** Ensure all third-party systems your services use is capable of handling high load

**E.** Instrument the production services to record every transaction for replay by the load-testing tool

**F.** Instrument the load-testing tool and the target services with detailed logging and metrics collection

**Respuesta de la fuente:** A, B, F

**Explicación:** Creating a separate project (B) is essential to isolate test resources and prevent load testing from consuming production service quotas or causing accidental disruptions.
Instrumenting services with detailed logging and metrics (F) provides the necessary data to analyze performance bottlenecks and validate scalability results.
Validating Cloud Bigtable performance (A) is critical because, although managed, it requires explicit capacity planning and node provisioning to handle specific workload patterns.

## Pregunta 165

Contexto: [topics:92](#topics-92)
Your customer is moving their corporate applications to Google Cloud Platform. The security team wants detailed visibility of all projects in the organization. You provision the Google Cloud Resource Manager and set up yourself as the org admin.
What Google Cloud Identity and Access Management (Cloud IAM) roles should you give to the security team?

**A.** Org viewer, project owner

**B.** Org viewer, project viewer

**C.** Org admin, project browser

**D.** Project owner, network admin

**Respuesta de la fuente:** B

**Explicación:** The principle of least privilege requires granting only the permissions necessary to perform a task. The security team needs visibility but not modification rights, making Viewer roles appropriate.
Option B is correct because Organization Viewer allows viewing organization metadata, and Project Viewer permits inspecting resources within projects without enabling changes.
Other options include Admin or Owner roles, which grant excessive write access contrary to the read-only requirement.

## Pregunta 166

Contexto: [topics:92](#topics-92)
Your company places a high value on being responsive and meeting customer needs quickly. Their primary business objectives are release speed and agility. You want to reduce the chance of security errors being accidentally introduced.
Which two actions can you take? (Choose two.)

**A.** Ensure every code check-in is peer reviewed by a security SME

**B.** Use source code security analyzers as part of the CI/CD pipeline

**C.** Ensure you have stubs to unit test all interfaces between components

**D.** Enable code signing and a trusted binary repository integrated with your CI/CD pipeline

**E.** Run a vulnerability security scanner as part of your continuous-integration /continuous-delivery (CI/CD) pipeline

**Respuesta de la fuente:** B, E

**Explicación:** To balance release speed with security in a CI/CD pipeline, automated tools are preferred over manual reviews. Source code security analyzers (SAST) detect vulnerabilities early in development without slowing down deployment cycles. Vulnerability scanners identify issues in dependencies and container images, ensuring known flaws are caught before production. Together, these automated checks reduce the risk of accidental security errors while maintaining agility.

## Pregunta 167

Contexto: [topics:92](#topics-92)
You want to enable your running Google Kubernetes Engine cluster to scale as demand for your application changes.
What should you do?

**A.** Add additional nodes to your Kubernetes Engine cluster using the following command: gcloud container clusters resize CLUSTER_Name — -size 10

**B.** Add a tag to the instances in the cluster with the following command: gcloud compute instances add-tags INSTANCE - -tags enable- autoscaling max-nodes-10

**C.** Update the existing Kubernetes Engine cluster with the following command: gcloud alpha container clusters update mycluster - -enable- autoscaling - -min-nodes=1 - -max-nodes=10

**D.** Create a new Kubernetes Engine cluster with the following command: gcloud alpha container clusters create mycluster - -enable- autoscaling - -min-nodes=1 - -max-nodes=10 and redeploy your application

**Respuesta de la fuente:** C

**Explicación:** The question specifies enabling autoscaling on a *running* cluster, which requires updating the existing configuration rather than creating a new one or manually resizing nodes. Option C uses the `gcloud container clusters update` command with the `--enable-autoscaling` flag to dynamically adjust the cluster based on demand within defined min/max node limits.

## Pregunta 168

Contexto: [topics:92](#topics-92)
Your marketing department wants to send out a promotional email campaign. The development team wants to minimize direct operation management. They project a wide range of possible customer responses, from 100 to 500,000 click-through per day. The link leads to a simple website that explains the promotion and collects user information and preferences.
Which infrastructure should you recommend? (Choose two.)

**A.** Use Google App Engine to serve the website and Google Cloud Datastore to store user data.

**B.** Use a Google Container Engine cluster to serve the website and store data to persistent disk.

**C.** Use a managed instance group to serve the website and Google Cloud Bigtable to store user data.

**D.** Use a single Compute Engine virtual machine (VM) to host a web server, backend by Google Cloud SQL.

**Respuesta de la fuente:** A, C

**Explicación:** The requirement to minimize direct operation management and handle unpredictable traffic spikes eliminates single-VM options like D.
Google App Engine (A) provides fully managed, automatic scaling for both compute and Datastore, fitting the low-management goal.
Managed Instance Groups (C) offer automatic horizontal scaling for web servers, while Bigtable is a highly scalable NoSQL database capable of handling high-throughput data storage.

## Pregunta 169

Contexto: [topics:92](#topics-92)
Your company just finished a rapid lift and shift to Google Compute Engine for your compute needs. You have another 9 months to design and deploy a more cloud-native solution. Specifically, you want a system that is no-ops and auto-scaling.
Which two compute products should you choose? (Choose two.)

**A.** Compute Engine with containers

**B.** Google Kubernetes Engine with containers

**C.** Google App Engine Standard Environment

**D.** Compute Engine with custom instance types

**E.** Compute Engine with managed instance groups

**Respuesta de la fuente:** B, C

**Explicación:** The question explicitly requires "no-ops" and "auto-scaling." Google App Engine (C) is a serverless Platform-as-a-Service that offers true zero-operations infrastructure management with automatic scaling. Google Kubernetes Engine (B), particularly in Autopilot mode, abstracts node management away from the user, providing a near-serverless experience for containerized workloads compared to Compute Engine options which require significant OS and instance maintenance.

## Pregunta 170

Contexto: [topics:92](#topics-92)
One of your primary business objectives is being able to trust the data stored in your application. You want to log all changes to the application data.
How can you design your logging system to verify authenticity of your logs?

**A.** Write the log concurrently in the cloud and on premises

**B.** Use a SQL database and limit who can modify the log table

**C.** Digitally sign each timestamp and log entry and store the signature

**D.** Create a JSON dump of each log entry and store it in Google Cloud Storage

**Respuesta de la fuente:** C

**Explicación:** Digital signatures use cryptographic hashing and asymmetric encryption to prove the integrity and origin of data. By signing each log entry with a private key, any subsequent tampering changes the hash, causing verification with the public key to fail. Other options like storage location or access controls do not provide cryptographic proof that the data has not been altered.

## Pregunta 171

Contexto: [topics:92](#topics-92)
Your company has a Google Workspace account and Google Cloud Organization. Some developers in the company have created Google Cloud projects outside of the Google Cloud Organization.
You want to create an Organization structure that allows developers to create projects, but prevents them from modifying production projects. You want to manage policies for all projects centrally and be able to set more restrictive policies for production projects.
You want to minimize disruption to users and developers when business needs change in the future. You want to follow Google-recommended practices. Now should you design the Organization structure?

**A.** 1. Create a second Google Workspace account and Organization. 2. Grant all developers the Project Creator IAM role on the new Organization. 3. Move the developer projects into the new Organization. 4. Set the policies for all projects on both Organizations. 5. Additionally, set the production policies on the original Organization.

**B.** 1. Create a folder under the Organization resource named "Production." 2. Grant all developers the Project Creator IAM role on the new Organization. 3. Move the developer projects into the new Organization. 4. Set the policies for all projects on the Organization. 5. Additionally, set the production policies on the "Production" folder.

**C.** 1. Create folders under the Organization resource named "Development" and "Production." 2. Grant all developers the Project Creator IAM role on the "Development" folder. 3. Move the developer projects into the "Development" folder. 4. Set the policies for all projects on the Organization. 5. Additionally, set the production policies on the "Production" folder.

**D.** 1. Designate the Organization for production projects only. 2. Ensure that developers do not have the Project Creator IAM role on the Organization. 3. Create development projects outside of the Organization using the developer Google Workspace accounts. 4. Set the policies for all projects on the Organization. 5. Additionally, set the production policies on the individual production projects.

**Respuesta de la fuente:** C

**Explicación:** Option C correctly uses organizational folders to segregate environments, allowing central policy enforcement at the Organization level while applying stricter constraints specifically to Production projects.
Granting Project Creator rights only on the Development folder ensures developers can create new resources without access to modify or create within Production.
This design adheres to Google best practices by maintaining a single Organization structure, simplifying management and facilitating future project movement between environments with minimal disruption.

## Pregunta 172

Contexto: [topics:92](#topics-92)
Your company has an application running on Compute Engine that allows users to play their favorite music. There are a fixed number of instances. Files are stored in Cloud Storage, and data is streamed directly to users. Users are reporting that they sometimes need to attempt to play popular songs multiple times before they are successful. You need to improve the performance of the application. What should you do?

**A.** 1. Mount the Cloud Storage bucket using gcsfuse on all backend Compute Engine instances. 2. Serve music files directly from the backend Compute Engine instance.

**B.** 1. Create a Cloud Filestore NFS volume and attach it to the backend Compute Engine instances. 2. Download popular songs in Cloud Filestore. 3. Serve music files directly from the backend Compute Engine instance.

**C.** 1. Copy popular songs into CloudSQL as a blob. 2. Update application code to retrieve data from CloudSQL when Cloud Storage is overloaded.

**D.** 1. Create a managed instance group with Compute Engine instances. 2. Create a global load balancer and configure it with two backends: ○ Managed instance group ○ Cloud Storage bucket 3. Enable Cloud CDN on the bucket backend.

**Respuesta de la fuente:** D

**Explicación:** The correct answer is D.
Enabling Cloud CDN on a Cloud Storage backend caches static content (music files) at edge locations closer to users, significantly reducing latency and load on the origin bucket. This directly addresses the performance issue of failed retries for popular songs by serving cached copies efficiently, whereas other options involve inefficient architectures like gcsfuse or storing large blobs in Cloud SQL.

## Pregunta 173

Contexto: [topics:92](#topics-92)
The operations team in your company wants to save Cloud VPN log events for one year. You need to configure the cloud infrastructure to save the logs. What should you do?

**A.** Set up a filter in Cloud Logging and a Cloud Storage bucket as an export target for the logs you want to save.

**B.** Enable the Compute Engine API, and then enable logging on the firewall rules that match the traffic you want to save.

**C.** Set up a Cloud Logging Dashboard titled Cloud VPN Logs, and then add a chart that queries for the VPN metrics over a one-year time period.

**D.** Set up a filter in Cloud Logging and a topic in Pub/Sub to publish the logs.

**Respuesta de la fuente:** A

**Explicación:** Cloud Logging retains data for a limited time (typically 30 days to 2 years depending on the plan), but exporting to Cloud Storage is the standard method for long-term archival beyond native retention limits. By creating a log filter for Cloud VPN events and configuring a Cloud Storage bucket as the export destination, you ensure logs are persisted durably for the required one-year period.

## Pregunta 174

Contexto: [topics:92](#topics-92)
You are working with a data warehousing team that performs data analysis. The team needs to process data from external partners, but the data contains personally identifiable information (PII). You need to process and store the data without storing any of the PIIE data. What should you do?

**A.** Create a Dataflow pipeline to retrieve the data from the external sources. As part of the pipeline, use the Cloud Data Loss Prevention (Cloud DLP) API to remove any PII data. Store the result in BigQuery.

**B.** Create a Dataflow pipeline to retrieve the data from the external sources. As part of the pipeline, store all non-PII data in BigQuery and store all PII data in a Cloud Storage bucket that has a retention policy set.

**C.** Ask the external partners to upload all data on Cloud Storage. Configure Bucket Lock for the bucket. Create a Dataflow pipeline to read the data from the bucket. As part of the pipeline, use the Cloud Data Loss Prevention (Cloud DLP) API to remove any PII data. Store the result in BigQuery.

**D.** Ask the external partners to import all data in your BigQuery dataset. Create a dataflow pipeline to copy the data into a new table. As part of the Dataflow bucket, skip all data in columns that have PII data

**Respuesta de la fuente:** A

**Explicación:** Option A is the correct choice because it processes data from external sources without persisting PII to any storage location like Cloud Storage. The requirement explicitly states not to store any PII, making Option C incorrect due to the intermediate storage in a GCS bucket. Options B and D are invalid because they either retain PII or fail to programmatically de-identify sensitive fields within the pipeline.

## Pregunta 175

Contexto: [topics:92](#topics-92)
You want to allow your operations team to store logs from all the production projects in your Organization, without including logs from other projects. All of the production projects are contained in a folder. You want to ensure that all logs for existing and new production projects are captured automatically. What should you do?

**A.** Create an aggregated export on the Production folder. Set the log sink to be a Cloud Storage bucket in an operations project.

**B.** Create an aggregated export on the Organization resource. Set the log sink to be a Cloud Storage bucket in an operations project.

**C.** Create log exports in the production projects. Set the log sinks to be a Cloud Storage bucket in an operations project.

**D.** Create log exports in the production projects. Set the log sinks to be BigQuery datasets in the production projects, and grant IAM access to the operations team to run queries on the datasets.

**Respuesta de la fuente:** A

**Explicación:** Aggregated sinks allow you to export logs from multiple resources under a specific parent resource without configuring individual exports for each child.
By creating the sink on the Production folder, all existing and future production projects within that folder automatically have their logs exported, satisfying the requirement for automatic capture.
This approach avoids including logs from other projects not in the folder, which would happen if the sink were placed at the Organization level.

## Pregunta 176

Contexto: [topics:92](#topics-92)
Your company has an application that is running on multiple instances of Compute Engine. It generates 1 TB per day of logs. For compliance reasons, the logs need to be kept for at least two years. The logs need to be available for active query for 30 days. After that, they just need to be retained for audit purposes. You want to implement a storage solution that is compliant, minimizes costs, and follows Google-recommended practices. What should you do?

**A.** 1. Install a Cloud Logging agent on all instances. 2. Create a sink to export logs into a regional Cloud Storage bucket. 3. Create an Object Lifecycle rule to move files into a Coldline Cloud Storage bucket after one month. 4. Configure a retention policy at the bucket level using bucket lock.

**B.** 1. Write a daily cron job, running on all instances, that uploads logs into a Cloud Storage bucket. 2. Create a sink to export logs into a regional Cloud Storage bucket. 3. Create an Object Lifecycle rule to move files into a Coldline Cloud Storage bucket after one month.

**C.** 1. Install a Cloud Logging agent on all instances. 2. Create a sink to export logs into a partitioned BigQuery table. 3. Set a time_partitioning_expiration of 30 days.

**D.** 1. Create a daily cron job, running on all instances, that uploads logs into a partitioned BigQuery table. 2. Set a time_partitioning_expiration of 30 days.

**Respuesta de la fuente:** A

**Explicación:** Option A is the correct answer because it uses Google-recommended practices: installing the Cloud Logging agent for centralized log collection and using a sink to export logs to Cloud Storage.

It satisfies the compliance requirement by using Bucket Lock to enforce a two-year retention policy that cannot be deleted or altered prematurely.

Cost optimization is achieved through Object Lifecycle rules that transition data to Coldline storage after 30 days, balancing query accessibility (via BigQuery external tables on GCS) with lower long-term storage costs.

## Pregunta 177

Contexto: [topics:92](#topics-92)
Your company has just recently activated Cloud Identity to manage users. The Google Cloud Organization has been configured as well. The security team needs to secure projects that will be part of the Organization. They want to prohibit IAM users outside the domain from gaining permissions from now on. What should they do?

**A.** Configure an organization policy to restrict identities by domain.

**B.** Configure an organization policy to block creation of service accounts.

**C.** Configure Cloud Scheduler to trigger a Cloud Function every hour that removes all users that don't belong to the Cloud Identity domain from all projects.

**D.** Create a technical user (e.g., crawler@yourdomain.com), and give it the project owner role at root organization level. Write a bash script that: "¢ Lists all the IAM rules of all projects within the organization. "¢ Deletes all users that do not belong to the company domain. Create a Compute Engine instance in a project within the Organization and configure gcloud to be executed with technical user credentials. Configure a cron job that executes the bash script every hour.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Organization Policies provide a built-in constraint to restrict IAM members to specific domains, which directly enforces the requirement to prohibit external users from gaining permissions.
Options C and D involve complex, custom automation scripts that are unnecessary when native policy controls exist, while Option B only affects service account creation rather than user identity restrictions.

## Pregunta 178

Contexto: [topics:92](#topics-92)
Your company has an application running on Google Cloud that is collecting data from thousands of physical devices that are globally distributed. Data is published to Pub/Sub and streamed in real time into an SSD Cloud Bigtable cluster via a Dataflow pipeline. The operations team informs you that your Cloud
Bigtable cluster has a hotspot, and queries are taking longer than expected. You need to resolve the problem and prevent it from happening in the future. What should you do?

**A.** Advise your clients to use HBase APIs instead of NodeJS APIs.

**B.** Delete records older than 30 days.

**C.** Review your RowKey strategy and ensure that keys are evenly spread across the alphabet.

**D.** Double the number of nodes you currently have.

**Respuesta de la fuente:** C

**Explicación:** Cloud Bigtable distributes data across nodes based on the lexicographic order of row keys. A hotspot occurs when rows with similar keys are clustered together, causing disproportionate load on a specific tablet server and degrading query performance.
Reviewing and optimizing the RowKey strategy to ensure keys are evenly distributed (e.g., by reversing keys or using salts) spreads the load across the cluster, resolving the current bottleneck and preventing future hotspots.

## Pregunta 179

Contexto: [topics:92](#topics-92)
Your company has a Google Cloud project that uses BigQuery for data warehousing. There are some tables that contain personally identifiable information (PII).
Only the compliance team may access the PII. The other information in the tables must be available to the data science team. You want to minimize cost and the time it takes to assign appropriate access to the tables. What should you do?

**A.** 1. From the dataset where you have the source data, create views of tables that you want to share, excluding PII. 2. Assign an appropriate project-level IAM role to the members of the data science team. 3. Assign access controls to the dataset that contains the view.

**B.** 1. From the dataset where you have the source data, create materialized views of tables that you want to share, excluding PII. 2. Assign an appropriate project-level IAM role to the members of the data science team. 3. Assign access controls to the dataset that contains the view.

**C.** 1. Create a dataset for the data science team. 2. Create views of tables that you want to share, excluding PII. 3. Assign an appropriate project-level IAM role to the members of the data science team. 4. Assign access controls to the dataset that contains the view. 5. Authorize the view to access the source dataset.

**D.** 1. Create a dataset for the data science team. 2. Create materialized views of tables that you want to share, excluding PII. 3. Assign an appropriate project-level IAM role to the members of the data science team. 4. Assign access controls to the dataset that contains the view. 5. Authorize the view to access the source dataset.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it follows the BigQuery best practice of creating authorized views in a separate dataset from the source data. This separation ensures that granting the Data Science team access to the view does not inadvertently grant them read access to the underlying table containing PII. Materialized views (Options B and D) are unnecessary here as they incur storage costs for precomputed results, violating the cost minimization requirement.

## Pregunta 180

Contexto: [topics:92](#topics-92)
Your operations team currently stores 10 TB of data in an object storage service from a third-party provider. They want to move this data to a Cloud Storage bucket as quickly as possible, following Google-recommended practices. They want to minimize the cost of this data migration. Which approach should they use?

**A.** Use the gsutil mv command to move the data.

**B.** Use the Storage Transfer Service to move the data.

**C.** Download the data to a Transfer Appliance, and ship it to Google.

**D.** Download the data to the on-premises data center, and upload it to the Cloud Storage bucket.

**Respuesta de la fuente:** B

**Explicación:** Google recommends the Storage Transfer Service for migrating large datasets (like 10 TB) from third-party object storage providers to Cloud Storage.
This service automates the transfer over the internet or via a network backbone, ensuring speed and minimizing costs compared to manual downloads/uploads or physical appliances, which are reserved for petabyte-scale data with insufficient bandwidth.

## Pregunta 181

Contexto: [topics:92](#topics-92)
You have a Compute Engine managed instance group that adds and removes Compute Engine instances from the group in response to the load on your application. The instances have a shutdown script that removes REDIS database entries associated with the instance. You see that many database entries have not been removed, and you suspect that the shutdown script is the problem. You need to ensure that the commands in the shutdown script are run reliably every time an instance is shut down. You create a Cloud Function to remove the database entries. What should you do next?

**A.** Modify the shutdown script to wait for 30 seconds before triggering the Cloud Function.

**B.** Do not use the Cloud Function. Modify the shutdown script to restart if it has not completed in 30 seconds.

**C.** Set up a Cloud Monitoring sink that triggers the Cloud Function after an instance removal log message arrives in Cloud Logging.

**D.** Modify the shutdown script to wait for 30 seconds and then publish a message to a Pub/Sub queue.

**Respuesta de la fuente:** C

**Explicación:** Shutdown scripts are unreliable because GCP does not guarantee that an instance will remain active long enough for the script to complete after a shutdown signal is sent. By using a Cloud Monitoring sink to forward specific instance removal logs to Cloud Pub/Sub (which then triggers the Cloud Function), you decouple the cleanup task from the volatile instance lifecycle. This ensures the cleanup logic executes reliably in response to the confirmed deletion event, rather than depending on uncertain timing within the dying VM.

## Pregunta 182

Contexto: [topics:92](#topics-92)
You are managing several projects on Google Cloud and need to interact on a daily basis with BigQuery, Bigtable, and Kubernetes Engine using the gcloud CL tool. You are travelling a lot and work on different workstations during the week. You want to avoid having to manage the gcloud CLI manually. What should you do?

**A.** Use Google Cloud Shell in the Google Cloud Console to interact with Google Cloud.

**B.** Create a Compute Engine instance and install gcloud on the instance. Connect to this instance via SSH to always use the same gcloud installation when interacting with Google Cloud.

**C.** Install gcloud on all of your workstations. Run the command gcloud components auto-update on each workstation

**D.** Use a package manager to install gcloud on your workstations instead of installing it manually.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Shell provides a persistent development environment with the gcloud CLI pre-installed and configured, accessible from any browser.
This eliminates the need to manually install or manage the CLI across multiple local workstations, directly addressing the requirement to avoid manual management while traveling.

## Pregunta 183

Contexto: [topics:92](#topics-92)
Your company recently acquired a company that has infrastructure in Google Cloud. Each company has its own Google Cloud organization. Each company is using a Shared Virtual Private Cloud (VPC) to provide network connectivity for its applications. Some of the subnets used by both companies overlap. In order for both businesses to integrate, the applications need to have private network connectivity. These applications are not on overlapping subnets. You want to provide connectivity with minimal re-engineering. What should you do?

**A.** Set up VPC peering and peer each Shared VPC together.

**B.** Migrate the projects from the acquired company into your company's Google Cloud organization. Re-launch the instances in your companies Shared VPC.

**C.** Set up a Cloud VPN gateway in each Shared VPC and peer Cloud VPNs.

**D.** Configure SSH port forwarding on each application to provide connectivity between applications in the different Shared VPCs.

**Respuesta de la fuente:** C

**Explicación:** VPC Network Peering requires that the IP ranges of all subnets in the peered VPCs do not overlap at the time of establishment. Since the scenario explicitly states that some subnets used by both companies overlap, VPC peering (Option A) will fail and cannot be established. Cloud VPN (Option C) is the correct solution because it connects networks via IPsec tunnels without requiring non-overlapping CIDR blocks for the entire VPC, allowing connectivity between the specific application subnets that do not overlap while avoiding the significant re-engineering required by migration (Option B).

## Pregunta 184

Contexto: [topics:92](#topics-92)
You are managing several internal applications that are deployed on Compute Engine. Business users inform you that an application has become very slow over the past few days. You want to find the underlying cause in order to solve the problem. What should you do first?

**A.** Inspect the logs and metrics from the instances in Cloud Logging and Cloud Monitoring.

**B.** Change the Compute Engine Instances behind the application to a machine type with more CPU and memory.

**C.** Restore a backup of the application database from a time before the application became slow.

**D.** Deploy the applications on a managed instance group with autoscaling enabled. Add a load balancer in front of the managed instance group, and have the users connect to the IP of the load balancer.

**Respuesta de la fuente:** A

**Explicación:** The question explicitly asks for the step to *find* the underlying cause of the slowness before attempting a fix. Inspecting logs and metrics via Cloud Logging and Cloud Monitoring provides the necessary data to diagnose resource constraints, network issues, or application errors. Options B, C, and D represent potential remediation actions that should only be taken after the root cause has been identified through analysis.

## Pregunta 185

Contexto: [topics:92](#topics-92)
Your company has an application running as a Deployment in a Google Kubernetes Engine (GKE) cluster. When releasing new versions of the application via a rolling deployment, the team has been causing outages. The root cause of the outages is misconfigurations with parameters that are only used in production. You want to put preventive measures for this in the platform to prevent outages. What should you do?

**A.** Configure liveness and readiness probes in the Pod specification.

**B.** Configure health checks on the managed instance group.

**C.** Create a Scheduled Task to check whether the application is available.

**D.** Configure an uptime alert in Cloud Monitoring.

**Respuesta de la fuente:** A

**Explicación:** Readiness probes are the key preventive measure here because they signal to the Kubernetes Service controller when a Pod is ready to accept traffic. During a rolling update, if a new Pod fails the readiness probe due to production parameter misconfigurations, it will be excluded from the load balancer endpoints, preventing users from receiving errors while the old Pods continue serving traffic.

Option B is incorrect because GKE manages underlying infrastructure via controller logic rather than exposing Managed Instance Groups (MIGs) for direct health check configuration. Options C and D are reactive measures that detect outages after they occur or rely on external checks, whereas probes provide real-time, platform-level prevention.

## Pregunta 186

Contexto: [topics:92](#topics-92)
Your company uses Google Kubernetes Engine (GKE) as a platform for all workloads. Your company has a single large GKE cluster that contains batch, stateful, and stateless workloads. The GKE cluster is configured with a single node pool with 200 nodes. Your company needs to reduce the cost of this cluster but does not want to compromise availability. What should you do?

**A.** Create a second GKE cluster for the batch workloads only. Allocate the 200 original nodes across both clusters.

**B.** Configure CPU and memory limits on the namespaces in the cluster. Configure all Pods to have a CPU and memory limits.

**C.** Configure a HorizontalPodAutoscaler for all stateless workloads and for all compatible stateful workloads. Configure the cluster to use node auto scaling.

**D.** Change the node pool to use preemptible VMs.

**Respuesta de la fuente:** C

**Explicación:** Horizontal Pod Autoscaler (HPA) dynamically adjusts the number of pod replicas based on real-time demand, preventing over-provisioning of compute resources. Combining this with Node Auto Scaling allows the cluster to automatically remove unused nodes when demand drops, directly reducing infrastructure costs while maintaining high availability without manual intervention.

## Pregunta 187

Contexto: [topics:92](#topics-92)
Your company has a Google Cloud project that uses BigQuery for data warehousing on a pay-per-use basis. You want to monitor queries in real time to discover the most costly queries and which users spend the most. What should you do?

**A.** 1. In the BigQuery dataset that contains all the tables to be queried, add a label for each user that can launch a query. 2. Open the Billing page of the project. 3. Select Reports. 4. Select BigQuery as the product and filter by the user you want to check.

**B.** 1. Create a Cloud Logging sink to export BigQuery data access logs to BigQuery. 2. Perform a BigQuery query on the generated table to extract the information you need.

**C.** 1. Create a Cloud Logging sink to export BigQuery data access logs to Cloud Storage. 2. Develop a Dataflow pipeline to compute the cost of queries split by users.

**D.** 1. Activate billing export into BigQuery. 2. Perform a BigQuery query on the billing table to extract the information you need.

**Respuesta de la fuente:** B

**Explicación:** The correct answer is B because Cloud Logging captures BigQuery audit logs in near real-time, including the `resourcePricing` field which details query costs and user identities.
Exporting these logs to a BigQuery table allows you to run SQL queries immediately to identify expensive queries and high-spending users as they occur.
Billing exports (Option D) typically have significant latency (often 24 hours) and do not satisfy the 'real time' monitoring requirement, while Options A and C involve excessive complexity or incorrect billing interfaces.

## Pregunta 188

Contexto: [topics:92](#topics-92)
Your company and one of its partners each have a Google Cloud project in separate organizations. Your company's project (prj-a) runs in Virtual Private Cloud
(vpc-a). The partner's project (prj-b) runs in vpc-b. There are two instances running on vpc-a and one instance running on vpc-b. Subnets defined in both VPCs are not overlapping. You need to ensure that all instances communicate with each other via internal IPs, minimizing latency and maximizing throughput. What should you do?

**A.** Set up a network peering between vpc-a and vpc-b.

**B.** Set up a VPN between vpc-a and vpc-b using Cloud VPN.

**C.** Configure IAP TCP forwarding on the instance in vpc-b, and then launch the following gcloud command from one of the instances in vpc-a gcloud: gcloud compute start-iap-tunnel INSTANCE_NAME_IN_VPC_8 22 \ --local-host-port=localhost:22

**D.** 1. Create an additional instance in vpc-a. 2. Create an additional instance in vpc-b. 3. Install OpenVPN in newly created instances. 4. Configure a VPN tunnel between vpc-a and vpc-b with the help of OpenVPN.

**Respuesta de la fuente:** A

**Explicación:** VPC network peering is the correct solution because it enables low-latency, high-throughput private connectivity between VPCs in separate projects or organizations without traversing the public internet. Since the subnets do not overlap, a key requirement for VPC peering is met, allowing direct internal IP communication. Options like Cloud VPN or IAP introduce higher latency, encryption overhead, or do not support full bidirectional instance-to-instance internal traffic as effectively.

## Pregunta 189

Contexto: [topics:92](#topics-92)
You want to store critical business information in Cloud Storage buckets. The information is regularly changed, but previous versions need to be referenced on a regular basis. You want to ensure that there is a record of all changes to any information in these buckets. You want to ensure that accidental edits or deletions can be easily rolled back. Which feature should you enable?

**A.** Bucket Lock

**B.** Object Versioning

**C.** Object change notification

**D.** Object Lifecycle Management

**Respuesta de la fuente:** B

**Explicación:** Object Versioning maintains multiple versions of an object in a bucket, ensuring that all changes are recorded and previous states can be retrieved.
This feature directly enables easy rollback from accidental edits or deletions by allowing restoration of prior versions.

## Pregunta 190

Contexto: [topics:92](#topics-92)
You have a Compute Engine application that you want to autoscale when total memory usage exceeds 80%. You have installed the Cloud Monitoring agent and configured the autoscaling policy as follows:
✑ Metric identifier: agent.googleapis.com/memory/percent_used
✑ Filter: metric.label.state = 'used'
✑ Target utilization level: 80
✑ Target type: GAUGE
You observe that the application does not scale under high load. You want to resolve this. What should you do?

**A.** Change the Target type to DELTA_PER_MINUTE.

**B.** Change the Metric identifier to agent.googleapis.com/memory/bytes_used.

**C.** Change the filter to metric.label.state = 'used' AND metric.label.state = 'buffered' AND metric.label.state = 'cached' AND metric.label.state = 'slab'.

**D.** Change the filter to metric.label.state = 'free' and the Target utilization to 20.

**Respuesta de la fuente:** C

**Explicación:** The autoscaling policy fails because it only monitors the 'used' memory state, ignoring significant memory components like buffers, cache, and slab.
To accurately reflect total system memory pressure for autoscaling, the filter must aggregate these states. According to GCP documentation for memory-based autoscaling, you should combine 'used', 'buffered', 'cached', and 'slab' metrics to determine when total utilization exceeds the threshold.

## Pregunta 191

Contexto: [topics:92](#topics-92)
You are deploying an application to Google Cloud. The application is part of a system. The application in Google Cloud must communicate over a private network with applications in a non-Google Cloud environment. The expected average throughput is 200 kbps. The business requires:
✑ as close to 100% system availability as possible
✑ cost optimization
You need to design the connectivity between the locations to meet the business requirements. What should you provision?

**A.** An HA Cloud VPN gateway connected with two tunnels to an on-premises VPN gateway

**B.** Two Classic Cloud VPN gateways connected to two on-premises VPN gateways Configure each Classic Cloud VPN gateway to have two tunnels, each connected to different on-premises VPN gateways

**C.** Two HA Cloud VPN gateways connected to two on-premises VPN gateways Configure each HA Cloud VPN gateway to have two tunnels, each connected to different on-premises VPN gateways

**D.** A single Cloud VPN gateway connected to an on-premises VPN gateway

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because an HA Cloud VPN gateway with two tunnels provides the required high availability (up to 99.99%) by utilizing redundant control and data planes.
It meets the cost optimization requirement better than Option C, which provisions redundant gateways on both sides, resulting in unnecessary overhead and expense for a low-throughput scenario like 200 kbps.
Options B and D lack the necessary redundancy or use deprecated technologies that do not guarantee the required availability levels.

## Pregunta 192

Contexto: [topics:92](#topics-92)
Your company has an application running on App Engine that allows users to upload music files and share them with other people. You want to allow users to upload files directly into Cloud Storage from their browser session. The payload should not be passed through the backend. What should you do?

**A.** 1. Set a CORS configuration in the target Cloud Storage bucket where the base URL of the App Engine application is an allowed origin.
2. Use the Cloud Storage Signed URL feature to generate a POST URL.

**B.** 1. Set a CORS configuration in the target Cloud Storage bucket where the base URL of the App Engine application is an allowed origin.
2. Assign the Cloud Storage WRITER role to users who upload files.

**C.** 1. Use the Cloud Storage Signed URL feature to generate a POST URL.
2. Use App Engine default credentials to sign requests against Cloud Storage.

**D.** 1. Assign the Cloud Storage WRITER role to users who upload files.
2. Use App Engine default credentials to sign requests against Cloud Storage.

**Respuesta de la fuente:** A

**Explicación:** To allow direct browser uploads without passing the payload through the backend, you must use Signed URLs to provide temporary, secure write access without granting broad IAM roles. Additionally, since the request originates from a web domain different from Cloud Storage, CORS configuration is required on the bucket to allow the App Engine origin to perform the upload.

## Pregunta 193

Contexto: [topics:92](#topics-92)
You are configuring the cloud network architecture for a newly created project in Google Cloud that will host applications in Compute Engine. Compute Engine virtual machine instances will be created in two different subnets (sub-a and sub-b) within a single region:
•	Instances in sub-a will have public IP addresses.
•	Instances in sub-b will have only private IP addresses.

To download updated packages, instances must connect to a public repository outside the boundaries of Google Cloud. You need to allow sub-b to access the external repository. What should you do?

**A.** Enable Private Google Access on sub-b.

**B.** Configure Cloud NAT and select sub-b in the NAT mapping section.

**C.** Configure a bastion host instance in sub-a to connect to instances in sub-b.

**D.** Enable Identity-Aware Proxy for TCP forwarding for instances in sub-b.

**Respuesta de la fuente:** B

**Explicación:** Cloud NAT is the dedicated Google Cloud service designed to allow VMs in a private subnet to initiate outbound connections to the internet without requiring public IP addresses. By configuring Cloud NAT and specifying sub-b in the NAT mapping, instances can reach external repositories for updates while remaining unreachable from outside traffic.

- Private Google Access (A) only permits access to Google APIs and services, not general public internet resources.
- A bastion host (C) is used for inbound administrative access, not for outbound internet connectivity by multiple VMs.
- Identity-Aware Proxy (D) provides secure remote access to apps and instances, not general outbound NAT functionality.

## Pregunta 194

Contexto: [topics:92](#topics-92)
Your company is planning to migrate their Windows Server 2022 from their on-premises data center to Google Cloud. You need to bring the licenses that are currently in use in on-premises virtual machines into the target cloud environment. What should you do?

**A.** 1. Create an image of the on-premises virtual machines and upload into Cloud Storage.
2. Import the image as a virtual disk on Compute Engine.

**B.** 1. Create standard instances on Compute Engine.
2. Select as the OS the same Microsoft Windows version that is currently in use in the on-premises environment.

**C.** 1. Create an image of the on-premises virtual machine.
2. Import the image as a virtual disk on Compute Engine.
3. Create a standard instance on Compute Engine, selecting as the OS the same Microsoft Windows version that is currently in use in the on-premises environment.
4. Attach a data disk that includes data that matches the created image.

**D.** 1. Create an image of the on-premises virtual machines.
2. Import the image as a virtual disk on Compute Engine using --os=windows-2022-dc-v<timestamp>.
3. Create a sole-tenancy instance on Compute Engine that uses the imported disk as a boot disk.

**Respuesta de la fuente:** D

**Explicación:** To migrate Windows Server licenses from on-premises to Google Cloud under a Bring Your Own License (BYOL) model, you must use sole-tenant nodes. This requirement ensures dedicated hardware visibility for license compliance and is explicitly mandated by Google documentation when creating VM instances with custom BYOL images.

## Pregunta 195

Contexto: [topics:92](#topics-92)
You are deploying an application to Google Cloud. The application is part of a system. The application in Google Cloud must communicate over a private network with applications in a non-Google Cloud environment. The expected average throughput is 200 kbps. The business requires:

•	99.99% system availability
•	cost optimization

You need to design the connectivity between the locations to meet the business requirements. What should you provision?

**A.** An HA Cloud VPN gateway connected with two tunnels to an on-premises VPN gateway.

**B.** A Classic Cloud VPN gateway connected with two tunnels to an on-premises VPN gateway.

**C.** Two HA Cloud VPN gateways connected to two on-premises VPN gateways. Configure each HA Cloud VPN gateway to have two tunnels, each connected to different on-premises VPN gateways.

**D.** A Classic Cloud VPN gateway connected with one tunnel to an on-premises VPN gateway.

**Respuesta de la fuente:** A

**Explicación:** To achieve the required 99.99% availability, you must use an HA Cloud VPN gateway configured with two active-active tunnels to a single on-premises gateway (or dual gateways if specified), as Classic VPN lacks this high-availability feature.
Option C is incorrect because provisioning multiple HA gateways and multiple on-premises gateways incurs unnecessary costs, violating the cost optimization requirement when a single HA gateway with two tunnels suffices for redundancy.

## Pregunta 196

Contexto: [topics:92](#topics-92)
Your company wants to migrate their 10-TB on-premises database export into Cloud Storage. You want to minimize the time it takes to complete this activity and the overall cost. The bandwidth between the on-premises environment and Google Cloud is 1 Gbps. You want to follow Google-recommended practices. What should you do?

**A.** Develop a Dataflow job to read data directly from the database and write it into Cloud Storage.

**B.** Use the Data Transfer appliance to perform an offline migration.

**C.** Use a commercial partner ETL solution to extract the data from the on-premises database and upload it into Cloud Storage.

**D.** Upload the data with gcloud storage cp.

**Respuesta de la fuente:** D

**Explicación:** The correct approach depends on the time required for online transfer versus offline shipping. At 1 Gbps, transferring 10 TB takes approximately 29 hours (30-40% overhead for real-world conditions), which is well under the 1-week threshold where Google recommends using a Transfer Appliance.
Therefore, an online transfer is faster and more cost-effective than waiting for hardware shipping. While `gsutil` is the specific tool often cited, in this context option D represents the standard CLI-based online upload method, avoiding the latency of physical transport.

## Pregunta 197

Contexto: [topics:92](#topics-92)
You are working at a financial institution that stores mortgage loan approval documents on Cloud Storage. Any change to these approval documents must be uploaded as a separate approval file. You need to ensure that these documents cannot be deleted or overwritten for the next 5 years. What should you do?

**A.** Create a retention policy on the bucket for the duration of 5 years. Create a lock on the retention policy.

**B.** Create a retention policy organizational constraint constraints/storage.retentionPolicySeconds at the organization level. Set the duration to 5 years.

**C.** Use a customer-managed key for the encryption of the bucket. Rotate the key after 5 years.

**D.** Create a retention policy organizational constraint constraints/storage.retentionPolicySeconds at the project level. Set the duration to 5 years.

**Respuesta de la fuente:** A

**Explicación:** To prevent documents from being deleted or overwritten for a specific period on Cloud Storage, you must configure a bucket-level retention policy.
Locking this retention policy is critical because it prevents any subsequent changes to the duration or deletion of the policy itself, ensuring the data remains immutable for the required 5 years.

## Pregunta 198

Contexto: [topics:92](#topics-92)
Your company has decided to make a major revision of their API in order to create better experiences for their developers. They need to keep the old version of the API available and deployable, while allowing new customers and testers to try out the new API. They want to keep the same SSL and DNS records in place to serve both APIs.

What should they do?

**A.** Configure a new load balancer for the new version of the API

**B.** Reconfigure old clients to use a new endpoint for the new API

**C.** Have the old API forward traffic to the new API based on the path

**D.** Use separate backend pools for each API path behind the load balancer

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it allows the load balancer to route traffic to different backend pools based on the API path (e.g., /v1 vs /v2). This architecture supports simultaneous deployment of both versions under the same DNS and SSL records while keeping them logically separated for independent scaling and management.

## Pregunta 199

Contexto: [topics:92](#topics-92)
You have a Compute Engine application that you want to autoscale when total memory usage exceeds 80%. You have installed the Cloud Monitoring agent and configured the autoscaling policy as follows:

[Imagen: sin descripción]

You observe that the application does not scale under high load. You want to resolve this. What should you do?
Imagen · question_text · sin descripción
![Imagen original](imagenes/995cc5046e7d4e31104e.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Metric identifier: agent .googleapis.com/memory/percent_used
metric.label.state = ‘used’ AND
Filter: metric.label.state = ‘buffered’ AND
metric.label.state = ‘cached' AND
metric.label.state = 'slab'
Target utilization level: | 80
Target type: GAUGE
```

**A.** Change the Target type to DELTA_PER_MINUTE.

**B.** Change the Metric identifier to agent.googleapis.com/memory/bytes_used.

**C.** Change the filter to metric.label.state = ‘used’.

**D.** Change the filter to metric.label.state = ‘free’ and the Target utilization to 20.

**Respuesta de la fuente:** C

**Explicación:** The current filter uses AND logic to match states 'used', 'buffered', 'cached', and 'slab' simultaneously, which is impossible since each metric time series has only one state label value. This results in no data points matching the filter, preventing autoscaling from triggering. Changing the filter to metric.label.state = 'used' correctly targets the specific memory usage component needed to evaluate the 80% threshold.

## Pregunta 200

Contexto: [topics:92](#topics-92)
Your company has a Google Cloud project that uses BigOuery for data warehousing. The VPN tunnel between the on-premises environment and Google Cloud is configured with Cloud VPN. Your security team wants to avoid data exfiltration by malicious insiders, compromised code, and accidental oversharing. What should you do?

**A.** Configure Private Service Connect.

**B.** Configure VPC Service Controls and configure Private Google Access for on-promises hosts.

**C.** Create a service account, grant the BigQuery JobUser role and Storage Object Viewer role to the service account, and remove all other Identity and Access Management (IAM) access from the project.

**D.** Configure Private Google Access.

**Respuesta de la fuente:** B

**Explicación:** VPC Service Controls create a security perimeter that prevents data exfiltration from BigQuery even if credentials are compromised or insiders attempt to access data from outside the perimeter.
Configuring Private Google Access ensures that on-premises hosts can reach these protected services through private connectivity rather than the public internet, completing the secure path required for the VPN environment.

## Pregunta 201

Contexto: [topics:92](#topics-92)
You are managing a few hundred Ubuntu and Red Hat Enterprise Linux virtual machines running on Google Compute Engine (GCE). You need to patch the operating systems for those VMs periodically in a secure and scalable way. What should you do?

**A.** Create a Cloud Scheduler job to run a Bash script that securely connects to each VM and applies the patches.

**B.** Configure Config Sync, and install the Ops Agent on each VM. Schedule a patch job to apply patches on each VM.

**C.** Schedule a Cloud Build job, and use Cloud Deploy to run a patch job that applies patches on each VM.

**D.** Set up VM Manager, and install the OS Config agent on each VM. Schedule a patch job to apply patches on each VM.

**Respuesta de la fuente:** D

**Explicación:** Google Cloud VM Manager is the centralized service designed for managing fleets of VMs, specifically utilizing the OS Config agent to automate operating system patching.
Config Sync is intended for Kubernetes configuration management, while Ops Agent is primarily for monitoring and logging rather than patch execution.
Cloud Build and Cloud Deploy are CI/CD tools not suited for direct, scheduled guest OS patching at scale.

## Pregunta 202

Contexto: [topics:92](#topics-92)
Your company uses Salesforce for customer relationship management (CRM). ServiceNow for IT service management, and a Cloud SQL database to store customer transaction data You need to seamlessly connect, map. and transform data between these systems to ensure data consistency and enable real-time reporting. You want to follow Google-recommended practices. What should you do?

**A.** Leverage Workflows to connect the services and transform the data.

**B.** Leverage Application Integration to connect the services and transform the data.

**C.** Leverage Pub/Sub and BigQuery to connect the services and transform the data.

**D.** Leverage Pub/Sub and Datastream to connect the services and transform the data.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Application Integration is the recommended iPaaS solution for enterprise application integration scenarios involving SaaS tools like Salesforce and ServiceNow.
It provides pre-built connectors, data mapping, transformation capabilities, and supports real-time synchronization with databases like Cloud SQL.
Other options like Workflows or Pub/Sub require significantly more custom development effort to achieve similar connectivity and transformation results.

## Pregunta 203

Contexto: [topics:92](#topics-92)
You are designing the architecture for a global social media site on Google Cloud. The site serves dynamic API content, static assets such as CSS. JS. images, and user-uploaded videos for streaming. You need to minimize latency for all content types for users worldwide. What should you do? (Choose two.)

**A.** Use an external Application Load Balancer to serve your application APIs.

**B.** Use Cloud CDN to serve static assets of your application.

**C.** Use Media CDN to serve static assets of your application

**D.** Use Memorystore to serve your web application.

**E.** Use a multi-region Cloud Storage bucket to serve your entire web application.

**Respuesta de la fuente:** A, B

**Explicación:** To minimize latency for dynamic API content globally, an external Application Load Balancer routes user requests to the nearest backend instance via Google's global anycast network. For static assets like CSS, JS, and images, Cloud CDN caches content at edge locations worldwide, significantly reducing delivery latency.

## Pregunta 204

Contexto: [topics:92](#topics-92)
You are creating a migration plan to move your organization’s infrastructure from on-premises to Google Cloud. You want to understand and manage costs effectively after the migration is complete. Which strategies should you include in the migration plan? (Choose two.)

**A.** Enable Backup and DR Service.

**B.** Configure labels and tags for the resources provisioned in Google Cloud.

**C.** Create a Cloud Scheduler job to export billing data to Cloud SQL.

**D.** Create service alerts using Cloud Monitoring.

**E.** Adopt infrastructure as code (IaC) for the cloud resources.

**Respuesta de la fuente:** B, E

**Explicación:** Labels (B) are essential for cost allocation and visibility, allowing you to track spending by project, team, or application in billing reports.
Infrastructure as Code (E) enables proactive cost management by enforcing standardized, optimized configurations and preventing resource sprawl or orphaned instances.
Other options like Backup/DR (A) focus on resilience, Cloud Monitoring (D) on operational health, and Cloud Scheduler for Cloud SQL (C) is technically incorrect since billing data exports to BigQuery.

## Pregunta 205

Contexto: [topics:92](#topics-92)
A Cloud Run service running your serverless application is unable to connect to an AlloyDB database created with default configurations. You need to troubleshoot and resolve the issue as quickly as possible. What should you do?

**A.** Verify that the Cloud Run service and AlloyDB instance are in the same region.

**B.** Enable Direct VPC egress for the Cloud Run service, and send traffic directly to a VPC.

**C.** Disable the default public IP address of the AlloyDB instance, and use the private IP address in the connection string.

**D.** Create a Cloud SQL instance, and migrate the AlloyDB database to PostgreSQL on Cloud SQL.

**Respuesta de la fuente:** B

**Explicación:** AlloyDB instances are deployed within a VPC and use private IP addresses by default, making them inaccessible from Cloud Run's serverless environment without specific networking configuration. Enabling Direct VPC egress allows the Cloud Run service to send traffic directly into the VPC network to reach the database efficiently.

## Pregunta 206

Contexto: [topics:92](#topics-92)
Your company is building containerized applications as part of their CI/CD pipeline. To improve the security and maintainability of the build process, you need to:
•	Identify potential vulnerabilities within your container images.
•	Generate verifiable metadata about the builds for auditing and compliance.
•	Create a comprehensive inventory of your application’s dependencies

What should you do?

**A.** Use Cloud Build to build container images, and then trigger Artifact Analysis on images pushed to Artifact Registry.

**B.** Use Cloud Build to build container images, trigger Binary Authorization, and use Cloud Asset Inventory for tracking and analysis.

**C.** Use Cloud Build to build container images, push the images to Artifact Registry, and use Security Command Center for tracking and analysis.

**D.** Use Cloud Build to build container images, trigger Binary Authorization, and use Security Command Center for tracking and analysis.

**Respuesta de la fuente:** A

**Explicación:** Artifact Analysis is the specific Google Cloud service designed to scan container images for vulnerabilities and generate Software Bill of Materials (SBOM) for dependency inventory.
It automatically generates verifiable metadata and attestations upon image push, satisfying all three requirements: vulnerability identification, compliance metadata, and dependency tracking.
While Security Command Center aggregates findings, Artifact Analysis is the primary engine for these specific build-time checks.

## Pregunta 207

Contexto: [topics:92](#topics-92)
Your team is running applications on a Google Kubernetes Engine (GKE) cluster with a private endpoint. You've set up a Cloud Deploy pipeline, but deployments to the GKE cluster are failing. You need to resolve the issue. What should you do?

**A.** Use VPC Service Controls with Cloud Build Update the Cloud pipeline to use Cloud Build as its execution environment.

**B.** Create a Cloud Build private pool in the default VPC. Use Cloud Build to deploy the applications to the GKE cluster.

**C.** Create a Cloud Build private pool that is peered with the same VPC network as your GKE cluster. Update the Cloud Deploy pipeline to use this private pool as its execution environment.

**D.** Create a custom target in Cloud Deploy Update the deploy pipeline to use the custom target for the application deployment.

**Respuesta de la fuente:** C

**Explicación:** Default Cloud Build workers run in Google's managed network and cannot access a GKE cluster with a private endpoint due to lack of VPC connectivity.
Creating a Cloud Build Private Pool allows you to deploy worker nodes within your own VPC, specifically peered or in the same network as the GKE cluster.
By configuring the Cloud Deploy pipeline to use this private pool, the deployment steps execute from an environment that has direct internal network access to the private cluster API server.

## Pregunta 208

Contexto: [topics:92](#topics-92)
You are planning to migrate your on-premises compute and SAP workloads to Google Cloud. You want to follow Google-recommended practices to quickly create a cost estimate for running these workloads in Google Cloud. What should you do?

**A.** Leverage Cloud Asset Inventory to gather data and generate a cost estimate.

**B.** Use the Google Cloud pricing calculator, and input the estimated resource to generate a cost estimate.

**C.** Engage with a Google Cloud partner to perform a comprehensive assessment and provide a customized cost estimate.

**D.** Gather data about your current environment, and leverage Google Cloud Migration Center to generate a cost estimate.

**Respuesta de la fuente:** D

**Explicación:** Google Cloud Migration Center is the recommended tool for planning migrations as it automates infrastructure discovery and provides specialized cost estimation capabilities.
It specifically supports complex workloads like SAP by leveraging gathered environment data to generate accurate cost estimates, whereas the standard pricing calculator lacks this automated assessment context.

## Pregunta 209

Contexto: [topics:92](#topics-92)
Your organization has a significant amount of log data stored in Cloud Logging. The data engineering team is accustomed to using SQL for analysis and wants the ability to create insightful dashboards for visualizing log trends and patterns. You want to follow the recommendations of the Google Cloud Well-Architected Framework to provide a solution for the data engineering team. What should you do?

**A.** Create a log sink, and export the data to BigQuery using Pub/Sub. Run queries and visualize the data with Cloud Monitoring dashboards.

**B.** Enable log analytics and run queries in Cloud Monitoring. Visualize the data using Vertex AI workbench.

**C.** Enable log analytics and run queries in the linked log dataset in BigQuery. Visualize the data with Looker Studio dashboards.

**D.** Create a log sink, and export the data to a storage bucket. Create an external table in BigQuery for the data in the bucket. Run queries and visualize the data with Cloud Monitoring dashboards.

**Respuesta de la fuente:** C

**Explicación:** Enabling Log Analytics on a Cloud Logging bucket creates a linked dataset in BigQuery, allowing the data engineering team to use standard SQL for analysis without exporting or duplicating raw log data.
Looker Studio provides native, robust visualization capabilities connected directly to BigQuery, satisfying the requirement for insightful dashboards.
This approach aligns with the Well-Architected Framework by leveraging managed, integrated services to reduce operational overhead and latency.

## Pregunta 210

Contexto: [topics:92](#topics-92)
You are designing the storage architecture for a financial analytics platform. The platform ingests and stores terabytes of transactional data daily, which is used for both real-time fraud detection and long-term historical analysis. Transaction data from the last 30 days must be accessible with very low latency for the fraud detection engine. Data older than 30 days is accessed infrequently for quarterly reports, where retrieval times of a few seconds are acceptable. All data must be retained for five years to meet compliance regulations. You need to design a solution as cost-effective as possible. What should you do?

**A.** Store all transaction data in a Cloud Storage bucket using the Standard storage class for the entire five-year retention period.

**B.** Ingest all data into BigQuery using time-partitioned tables, and rely on BigQuery’s automatic long-term storage pricing for data older than 90 days.

**C.** Configure a Cloud Storage bucket with an Object Lifecycle Management policy to transition data from the Standard class to the Archive class after 30 days.

**D.** Configure a Cloud Storage bucket with an Object Lifecycle Management policy to transition data from the Standard class to the Coldline class after 30 days.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Coldline storage aligns with the quarterly access pattern while offering lower retrieval fees and a shorter minimum retention period (90 days) than Archive class.
Archive class has higher retrieval costs ($0.05/GB vs $0.02/GB) and a 365-day minimum storage duration, making it less cost-effective for data accessed every quarter.

## Pregunta 211

Contexto: [topics:92](#topics-92)
You are architecting a new application feature for a healthcare provider based in Qatar. The feature needs to summarize sensitive patient notes that are submitted by clinicians. A critical requirement is that the content of these patient notes must never be processed outside of Qatar's borders. You want to use a powerful, pre-trained generative model for the summarization task while strictly adhering to the data residency constraint. What should you do?

**A.** Write application code that sends the patient notes explicitly to the Gemini API endpoint in Qatar for summarization. Protect the API by VPC-Service Controls.

**B.** Use Vertex AI Model Garden to select a Gemma model. Deploy this model to a Vertex AI Endpoint within a Google Cloud region located in Qatar.

**C.** Use the Cloud Natural Language API to analyze the text and configure it to generate a summary of the patient notes.

**D.** Gather a large, anonymized dataset of medical notes. Use Vertex AI Training to train a custom summarization model from scratch, deploying it in a Qatar region.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because deploying an open-source model like Gemma to a Vertex AI Endpoint allows you to specify the exact region (e.g., me-central1 in Qatar), ensuring data processing stays within local borders. This satisfies both the requirement for a pre-trained generative model and the strict data residency constraint, whereas using standard API endpoints (A) or training from scratch (D) fails one of these criteria.

## Pregunta 212

Contexto: [topics:92](#topics-92)
You are migrating a critical on-premises inventory management application to Google Cloud. The application is a monolith with a traditional relational database, and the immediate business goal is a rapid data center exit. The monolith is exposing an API to other business critical applications.

The long-term vision is to modernize the application into globally distributed, cloud-native services to support the company’s expansion. You need to design the initial cloud architecture to ensure that future modernization causes the least possible disruption to other applications that depend on inventory data. The future modernization might require the API to change structure. What should you do?

**A.** Use Service Directory to register the monolith's endpoint, allowing dependent applications to look up its address and connect directly.

**B.** Implement a managed API facade with Apigee to handle all requests from dependent applications on behalf of the monolith’s backend.

**C.** Use an internal load balancer to provide a stable IP for dependent applications to connect directly to the monolith's native API.

**D.** Provide dependent applications with direct database access by creating secured SQL VIEWs on Cloud SQL for them to query.

**Respuesta de la fuente:** B

**Explicación:** Implementing an API facade with Apigee decouples dependent applications from the backend implementation, ensuring that future changes to the monolith or its transition to microservices do not break client integrations.
Apigee provides transformation and routing capabilities that maintain a stable external contract while allowing internal restructuring for modernization.

## Pregunta 213

Contexto: [topics:92](#topics-92)
Your organization uses separate Google Cloud projects for shared services, development, testing, and production.
•	The shared services project hosts your private CI/CD runners and a central Artifact Registry
•	The development, testing, and production projects host the GKE clusters where applications are deployed.

You need to design an architecture that allows the CI/CD runners to connect to the GKE clusters and the clusters to pull images from Artifact Registry, all using private IP addresses. However, direct network traffic between the development, testing, and production environments must be strictly prohibited. What should you do?

**A.** Create a separate VPC in each of the four projects. Connect each environment's VPC to the shared services VPC through VPC Network Peering.

**B.** Expose the resources in the shared services project using an external load balancer. Implement a firewall rule to limit access.

**C.** Create a separate VPC in each project. Use VPC Network Peering to create a full mesh, connecting every VPC directly to every other VPC.

**D.** Configure the shared services project as a Shared VPC host. Create a single VPC in this host project and attach the environment projects as service projects.

**Respuesta de la fuente:** A

**Explicación:** Option A implements a hub-and-spoke topology using VPC Network Peering between the shared services project (hub) and each environment project (spoke). This allows CI/CD runners to reach GKE clusters and Artifact Registry via private IPs while preventing direct network traffic between isolated development, testing, and production environments. Options C and D would allow or facilitate cross-environment connectivity, violating the strict isolation requirement, while Option B uses public IPs.

## Pregunta 214

Contexto: [topics:92](#topics-92)
You are designing the network architecture for a public-facing, containerized web application deployed on Cloud Run. All incoming traffic must be inspected by a Cloud Armor web application firewall (WAF) before reaching the application You plan to use an Application Load Balancer, which will have the Cloud Armor policy attached. You must ensure that all public requests pass through the load balancer and any attempt to access the Cloud Run service directly through its default *.run.app URL is blocked. What should you do?

**A.** Enable Identity-Aware Proxy (IAP) directly on the Cloud Run service to intercept and validate all incoming requests

**B.** Create a DNS entry to route traffic to Cloud Armor. Configure Cloud Armor to deny traffic from unknown IP addresses

**C.** Set the Cloud Run ingress to Allow internal traffic and Cloud Load Balancing, and use a serverless NEG backend on the load balancer

**D.** Configure a VPC firewall rule with a high priority to deny all traffic that does not originate from the load balancer

**Respuesta de la fuente:** C

**Explicación:** To block direct public access via the default *.run.app URL while allowing traffic from an Application Load Balancer, you must set the Cloud Run ingress setting to "Allow internal traffic and Cloud Load Balancing." This configuration restricts access so that only requests originating from a Google-managed load balancer or within the VPC are permitted. Furthermore, an external Application Load Balancer cannot connect directly to a Cloud Run service; it requires a Serverless Network Endpoint Group (NEG) as the backend target.

## Pregunta 215

Contexto: [topics:92](#topics-92)
To improve governance and security, your organization has structured the Google Cloud environment using folders for different business units. Each business unit folder has subfolders for development, staging, and production environments, which must comply with internal security controls:
•	Production workloads must be protected from direct internet ingress by default unless explicitly tagged.
•	The application must be accessible to customers over HTTPS.

You need to design a scalable and enforceable model that blocks internet ingress traffic to the production folders while selectively allowing direct HTTPS traffic to the necessary virtual machines. You must also ensure that individual project teams cannot overwrite these controls once they are implemented for all current and future production projects. What should you do?

**A.** At each production folder, apply a hierarchical firewall policy to deny all ingress except for HTTPS to tagged VMs.

**B.** Mandate the application teams to deploy a Terraform module to create VPC firewall rules in each project that deny ingress and allow HTTPS.

**C.** At the organization root, apply a hierarchical firewall policy to deny all ingress except for HTTPS to tagged VMs.

**D.** At each production folder, use an organization policy to block all external IPs and require teams to use external HTTPS load balancers.

**Respuesta de la fuente:** A

**Explicación:** Hierarchical firewall policies are the correct tool because they apply at the folder level and automatically inherit to all current and future projects within that folder, ensuring scalability.
By attaching these policies to the Production folders, you block direct internet ingress by default while selectively allowing HTTPS to tagged VMs using Secure Tags.
Crucially, hierarchical policies are evaluated before VPC-level firewall rules, preventing individual project teams from overriding the security controls with local rules.

## Pregunta 216

Contexto: [topics:92](#topics-92)
You are designing a new insurance claims processing application that will be deployed on Google Kubernetes Engine (GKE) Your company’s compliance team requires a complete and non-repudiable audit trail for all administrative actions from day one. Your application must capture who deploys a new container image, who modifies the GKE cluster's configuration, and who interacts with running pods or Kubernetes secrets using kubectl. What should you do?

**A.** Enable Binary Authorization on the GKE cluster, and create a policy that requires all deployed container images to be signed by a trusted attestor.

**B.** Deploy a DaemonSet to every node in the GKE cluster that runs a logging agent to collect and forward all container logs to Cloud Logging.

**C.** Enable GKE Audit Logging to send Kubernetes API server logs to Cloud Logging, and ensure Cloud Audit Logs are enabled for the project.

**D.** Activate the Security Command Center Premium tier to analyze GKE logs and detect threats, vulnerabilities, and misconfigurations in real time.

**Respuesta de la fuente:** C

**Explicación:** GKE Audit Logging records all requests made to the Kubernetes API server, providing a complete audit trail of administrative actions like deployments and configuration changes. Combined with Cloud Audit Logs for tamper-evident storage, this satisfies the non-repudiation requirement by capturing exactly who performed specific actions using kubectl.

## Pregunta 217

Contexto: [topics:92](#topics-92)
Your product team is building a critical, customer-facing application on Google Cloud. The development team wants to use Spanner for their database to take advantage of its horizontal scalability and low operational overhead However, the FinOps team is concerned about the direct monthly cost of Spanner and proposed using a self-managed PostgreSQL database on Compute Engine VMs instead. You need to resolve this conflict and ensure the project moves forward with an architecturally sound database choice that balances technical requirements with financial constraints. What should you do?

**A.** Provide the development team with a reference architecture for deploying a highly available PostgreSQL cluster on a regional managed instance group (MIG).

**B.** Suggest using Cloud SQL for PostgreSQL as a compromise to get a managed service at a lower cost than Spanner.

**C.** Develop a total cost of ownership (TCO) analysis that includes operational overhead, and present it in a workshop to facilitate a decision.

**D.** Cite the reliability and performance optimization pillars of the Google Cloud Well-Architected Framework to formally justify the use of Spanner.

**Respuesta de la fuente:** C

**Explicación:** The conflict involves both technical requirements and financial constraints, requiring a data-driven comparison rather than just architectural justification. A Total Cost of Ownership (TCO) analysis explicitly quantifies the hidden operational costs of managing PostgreSQL versus Spanner's lower maintenance overhead.
This evidence-based approach facilitates a consensus between the development and FinOps teams by balancing direct costs against long-term resource expenditure.

## Pregunta 218

Contexto: [topics:92](#topics-92)
You are deploying a critical application with a stateless, containerized frontend on Cloud Run and a Cloud SQL for PostgreSQL backend. The application experiences unpredictable traffic spikes, and the business requires the ability to immediately roll back a failed deployment to the last known good state. You need to apply a deployment strategy that aligns with Site Reliability Engineering (SRE) principles for both the application code and the database schema updates, while meeting the business's requirements. What should you do?

**A.** Package the database schema migration script within the container to be executed on every container startup before the application process begins.

**B.** Configure the CI/CD pipeline to use the :latest container tag for deployments, with database schema changes applied manually as needed.

**C.** Separate CI/CD pipelines for database schema migrations from application deployments. When deploying a new Cloud Run revision, use gradual traffic split.

**D.** Use a single CI/CD pipeline that first applies database schema changes and then deploys the new Cloud Run revision.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it separates stateful database changes from stateless application deployments, which is critical for safe rollbacks. Using gradual traffic splitting on Cloud Run allows immediate reversion of application revisions if issues arise, while keeping schema migrations independent prevents the need to revert data structures when rolling back code.

## Pregunta 219

Contexto: [topics:92](#topics-92)
Company Overview -

Altostrat is a prominent player in the media industry, with an extensive collection of audio and video content that comprises podcasts, interviews, news broadcasts, and documentaries. Their success in delivering premium content to a diverse audience requires a content management system that can keep pace with the dynamic media landscape.

Solution Concept -

Altostrat seeks to modernize its content management and user engagement strategies using Google Cloud's generative AI. They want a platform that empowers customers with personalized recommendations, natural language interactions and seamless self-service support. Simultaneously, they want to drive revenue growth through dynamic pricing targeted marketing, and personalized product suggestions.

The seamless integration of AI-powered tools into the existing Google Cloud environment will enable Altostrat to efficiently manage their vast media library, enhance user experiences, and unlock new revenue streams. Google Cloud's generative AI will solidify their leadership in the media industry.

Existing Technical Environment -

Altostrat’s content management and delivery platform leverages GKE for scalability and high availability, essential for handling their vast media library. Their extensive media library spanning various documents, audio and video formats is stored in Cloud Storage. To gain valuable insights into user behavior, content consumption patterns, and audience demographics, Altostrat leverages BigQuery as their primary data warehouse. Additionally, they use Cloud Run functions for serverless execution of event-driven tasks such as video transcoding metadata extraction, and personalized content recommendations.

While Altostrat has made significant strides in cloud adoption, they also maintain some legacy on-premises systems for specific workflows like content ingestion and archival. These systems are slated for modernization and migration to Google Cloud in the near future. User management and authentication are currently handled through a combination of Google Identity and third-party identity providers. For monitoring and observability, Altostrat relies on a mix of native Google Cloud tools like Cloud Monitoring and open-source solutions like Prometheus, with alerts primarily delivered via email notifications.

Business Requirements -

•	Accelerate and enhance the reliability of operational workflows across all environments. [Google Cloud + On-premises]
•	Simplify infrastructure management for rapid application deployment.
•	Optimize cloud storage costs while maintaining high availability and scalability for media content.
•	Enable natural language interaction with the platform with 24/7 user support.
•	Automatically generate concise summaries of media content.
•	Extract rich metadata from media assets using NLP and computer vision.
•	Detect and filter inappropriate content.
•	Analyze media content to identify trends and extract insights.
•	Inform content strategy and decision making with data.

Technical Requirements -

•	Modernize CI/CD for containerized deployments with a centralized management platform.
•	Secure, high-performance hybrid cloud connectivity for data ingestion.
•	Provide scalable, performant kubernetes environments both on-premises and in the cloud.
•	Optimize cloud storage costs for growing media volumes.
•	Design AI-powered detection of harmful content.
•	Ensure that AI systems are auditable and their decisions can be explained.
•	Leverage LLMs and conversational AI for personalized experiences and content virality.
•	Develop advanced chatbots with natural language understanding to provide personalized assistance.
•	Automated summarization for diverse media.

Executive Statement -

At Altostrat, we are embracing the next frontier of artificial intelligence to revolutionize our content strategy. By harnessing the power of generative AI, we will create an unparalleled user experience by empowering our audience with intelligent toots for content discovery, personalized recommendations, and seamless interaction. Reliability and cost management are our top priorities. This strategic initiative will deepen engagement, foster customer loyalty, and unlock new revenue streams through targeted marketing and tailored content offerings. We see a future where Al-driven innovation is central to our business, leading to greater success for our company and delivering exceptional value to our customers.

For this question, refer to the Altostrat Media case study. Altostrat stores a large library of media content, including sensitive interviews and documentaries, in Cloud Storage. They are concerned about the confidentiality of this content and want to protect it from unauthorized access. You need to implement a Google-recommended solution that is easy to integrate and provides Altostrat with control and auditability of the encryption keys. What should you do?

**A.** Configure Cloud Storage to use server-side encryption with Google-managed encryption keys. Create a bucket policy to restrict access to only authorized Google groups and required service accounts.

**B.** Use Cloud Storage default encryption at rest. Implement fine-grained access control using IAM roles and groups to restrict access to sensitive buckets

**C.** Implement client-side encryption before uploading it to Cloud Storage. Store the encryption keys in a HashiCorp Vault instance deployed on Google Kubernetes Engine (GKE). Implement fine-grained access control to sensitive Cloud Storage buckets using IAM roles.

**D.** Use customer-managed encryption keys (CMEK) for all Cloud Storage buckets storing sensitive media content. Implement fine-grained access control using IAM roles and groups to restrict access to sensitive buckets.

**Respuesta de la fuente:** D

**Explicación:** Customer-Managed Encryption Keys (CMEK) provide the required control and auditability by allowing Altostrat to manage encryption keys via Cloud KMS, ensuring they can rotate or revoke access independent of Google's management. This native solution is easier to integrate than client-side encryption with third-party vaults (Option C) while offering more security oversight than Google-managed keys (Options A and B). Combining CMEK with fine-grained IAM roles ensures both data confidentiality and restricted access.

## Pregunta 220

Contexto: [topics:92](#topics-92)
Company Overview -

Altostrat is a prominent player in the media industry, with an extensive collection of audio and video content that comprises podcasts, interviews, news broadcasts, and documentaries. Their success in delivering premium content to a diverse audience requires a content management system that can keep pace with the dynamic media landscape.

Solution Concept -

Altostrat seeks to modernize its content management and user engagement strategies using Google Cloud's generative AI. They want a platform that empowers customers with personalized recommendations, natural language interactions and seamless self-service support. Simultaneously, they want to drive revenue growth through dynamic pricing targeted marketing, and personalized product suggestions.

The seamless integration of AI-powered tools into the existing Google Cloud environment will enable Altostrat to efficiently manage their vast media library, enhance user experiences, and unlock new revenue streams. Google Cloud's generative AI will solidify their leadership in the media industry.

Existing Technical Environment -

Altostrat’s content management and delivery platform leverages GKE for scalability and high availability, essential for handling their vast media library. Their extensive media library spanning various documents, audio and video formats is stored in Cloud Storage. To gain valuable insights into user behavior, content consumption patterns, and audience demographics, Altostrat leverages BigQuery as their primary data warehouse. Additionally, they use Cloud Run functions for serverless execution of event-driven tasks such as video transcoding metadata extraction, and personalized content recommendations.

While Altostrat has made significant strides in cloud adoption, they also maintain some legacy on-premises systems for specific workflows like content ingestion and archival. These systems are slated for modernization and migration to Google Cloud in the near future. User management and authentication are currently handled through a combination of Google Identity and third-party identity providers. For monitoring and observability, Altostrat relies on a mix of native Google Cloud tools like Cloud Monitoring and open-source solutions like Prometheus, with alerts primarily delivered via email notifications.

Business Requirements -

•	Accelerate and enhance the reliability of operational workflows across all environments. [Google Cloud + On-premises]
•	Simplify infrastructure management for rapid application deployment.
•	Optimize cloud storage costs while maintaining high availability and scalability for media content.
•	Enable natural language interaction with the platform with 24/7 user support.
•	Automatically generate concise summaries of media content.
•	Extract rich metadata from media assets using NLP and computer vision.
•	Detect and filter inappropriate content.
•	Analyze media content to identify trends and extract insights.
•	Inform content strategy and decision making with data.

Technical Requirements -

•	Modernize CI/CD for containerized deployments with a centralized management platform.
•	Secure, high-performance hybrid cloud connectivity for data ingestion.
•	Provide scalable, performant kubernetes environments both on-premises and in the cloud.
•	Optimize cloud storage costs for growing media volumes.
•	Design AI-powered detection of harmful content.
•	Ensure that AI systems are auditable and their decisions can be explained.
•	Leverage LLMs and conversational AI for personalized experiences and content virality.
•	Develop advanced chatbots with natural language understanding to provide personalized assistance.
•	Automated summarization for diverse media.

Executive Statement -

At Altostrat, we are embracing the next frontier of artificial intelligence to revolutionize our content strategy. By harnessing the power of generative AI, we will create an unparalleled user experience by empowering our audience with intelligent toots for content discovery, personalized recommendations, and seamless interaction. Reliability and cost management are our top priorities. This strategic initiative will deepen engagement, foster customer loyalty, and unlock new revenue streams through targeted marketing and tailored content offerings. We see a future where Al-driven innovation is central to our business, leading to greater success for our company and delivering exceptional value to our customers.

For this question, refer to the Altostrat Media case study. Altostrat is experiencing fluctuating computational demands for its batch processing jobs. These jobs are not time-critical and can tolerate occasional interruptions. You want to optimize cloud costs and address batch processing needs. What should you do?

**A.** Configure reserved VM instances

**B.** Deploy spot VM instances.

**C.** Set up standard VM instances.

**D.** Use Cloud Run functions.

**Respuesta de la fuente:** B

**Explicación:** Spot VM instances are designed for fault-tolerant, flexible workloads like batch processing that can handle interruptions.
They offer significant cost savings compared to standard or reserved instances, directly addressing the goal of optimizing cloud costs for non-time-critical jobs.

## Pregunta 221

Contexto: [topics:92](#topics-92)
Company Overview -

Altostrat is a prominent player in the media industry, with an extensive collection of audio and video content that comprises podcasts, interviews, news broadcasts, and documentaries. Their success in delivering premium content to a diverse audience requires a content management system that can keep pace with the dynamic media landscape.

Solution Concept -

Altostrat seeks to modernize its content management and user engagement strategies using Google Cloud's generative AI. They want a platform that empowers customers with personalized recommendations, natural language interactions and seamless self-service support. Simultaneously, they want to drive revenue growth through dynamic pricing targeted marketing, and personalized product suggestions.

The seamless integration of AI-powered tools into the existing Google Cloud environment will enable Altostrat to efficiently manage their vast media library, enhance user experiences, and unlock new revenue streams. Google Cloud's generative AI will solidify their leadership in the media industry.

Existing Technical Environment -

Altostrat’s content management and delivery platform leverages GKE for scalability and high availability, essential for handling their vast media library. Their extensive media library spanning various documents, audio and video formats is stored in Cloud Storage. To gain valuable insights into user behavior, content consumption patterns, and audience demographics, Altostrat leverages BigQuery as their primary data warehouse. Additionally, they use Cloud Run functions for serverless execution of event-driven tasks such as video transcoding metadata extraction, and personalized content recommendations.

While Altostrat has made significant strides in cloud adoption, they also maintain some legacy on-premises systems for specific workflows like content ingestion and archival. These systems are slated for modernization and migration to Google Cloud in the near future. User management and authentication are currently handled through a combination of Google Identity and third-party identity providers. For monitoring and observability, Altostrat relies on a mix of native Google Cloud tools like Cloud Monitoring and open-source solutions like Prometheus, with alerts primarily delivered via email notifications.

Business Requirements -

•	Accelerate and enhance the reliability of operational workflows across all environments. [Google Cloud + On-premises]
•	Simplify infrastructure management for rapid application deployment.
•	Optimize cloud storage costs while maintaining high availability and scalability for media content.
•	Enable natural language interaction with the platform with 24/7 user support.
•	Automatically generate concise summaries of media content.
•	Extract rich metadata from media assets using NLP and computer vision.
•	Detect and filter inappropriate content.
•	Analyze media content to identify trends and extract insights.
•	Inform content strategy and decision making with data.

Technical Requirements -

•	Modernize CI/CD for containerized deployments with a centralized management platform.
•	Secure, high-performance hybrid cloud connectivity for data ingestion.
•	Provide scalable, performant kubernetes environments both on-premises and in the cloud.
•	Optimize cloud storage costs for growing media volumes.
•	Design AI-powered detection of harmful content.
•	Ensure that AI systems are auditable and their decisions can be explained.
•	Leverage LLMs and conversational AI for personalized experiences and content virality.
•	Develop advanced chatbots with natural language understanding to provide personalized assistance.
•	Automated summarization for diverse media.

Executive Statement -

At Altostrat, we are embracing the next frontier of artificial intelligence to revolutionize our content strategy. By harnessing the power of generative AI, we will create an unparalleled user experience by empowering our audience with intelligent toots for content discovery, personalized recommendations, and seamless interaction. Reliability and cost management are our top priorities. This strategic initiative will deepen engagement, foster customer loyalty, and unlock new revenue streams through targeted marketing and tailored content offerings. We see a future where Al-driven innovation is central to our business, leading to greater success for our company and delivering exceptional value to our customers.

For this question, refer to the Altostrat Media case study. Altostrat's development team is using a microservices architecture for their application. You need to select the most suitable testing approach to ensure that individual microservices function correctly in isolation. What should you do?

**A.** Run unit testing.

**B.** Use load testing.

**C.** Perform end-to-end testing.

**D.** Execute integration testing

**Respuesta de la fuente:** A

**Explicación:** Unit testing is the correct approach because it validates individual components or functions in isolation without involving external dependencies or other microservices.
Integration testing (D) and end-to-end testing (C) involve interactions between multiple services, which contradicts the requirement for isolation.

## Pregunta 222

Contexto: [topics:92](#topics-92)
Company Overview -

Altostrat is a prominent player in the media industry, with an extensive collection of audio and video content that comprises podcasts, interviews, news broadcasts, and documentaries. Their success in delivering premium content to a diverse audience requires a content management system that can keep pace with the dynamic media landscape.

Solution Concept -

Altostrat seeks to modernize its content management and user engagement strategies using Google Cloud's generative AI. They want a platform that empowers customers with personalized recommendations, natural language interactions and seamless self-service support. Simultaneously, they want to drive revenue growth through dynamic pricing targeted marketing, and personalized product suggestions.

The seamless integration of AI-powered tools into the existing Google Cloud environment will enable Altostrat to efficiently manage their vast media library, enhance user experiences, and unlock new revenue streams. Google Cloud's generative AI will solidify their leadership in the media industry.

Existing Technical Environment -

Altostrat’s content management and delivery platform leverages GKE for scalability and high availability, essential for handling their vast media library. Their extensive media library spanning various documents, audio and video formats is stored in Cloud Storage. To gain valuable insights into user behavior, content consumption patterns, and audience demographics, Altostrat leverages BigQuery as their primary data warehouse. Additionally, they use Cloud Run functions for serverless execution of event-driven tasks such as video transcoding metadata extraction, and personalized content recommendations.

While Altostrat has made significant strides in cloud adoption, they also maintain some legacy on-premises systems for specific workflows like content ingestion and archival. These systems are slated for modernization and migration to Google Cloud in the near future. User management and authentication are currently handled through a combination of Google Identity and third-party identity providers. For monitoring and observability, Altostrat relies on a mix of native Google Cloud tools like Cloud Monitoring and open-source solutions like Prometheus, with alerts primarily delivered via email notifications.

Business Requirements -

•	Accelerate and enhance the reliability of operational workflows across all environments. [Google Cloud + On-premises]
•	Simplify infrastructure management for rapid application deployment.
•	Optimize cloud storage costs while maintaining high availability and scalability for media content.
•	Enable natural language interaction with the platform with 24/7 user support.
•	Automatically generate concise summaries of media content.
•	Extract rich metadata from media assets using NLP and computer vision.
•	Detect and filter inappropriate content.
•	Analyze media content to identify trends and extract insights.
•	Inform content strategy and decision making with data.

Technical Requirements -

•	Modernize CI/CD for containerized deployments with a centralized management platform.
•	Secure, high-performance hybrid cloud connectivity for data ingestion.
•	Provide scalable, performant kubernetes environments both on-premises and in the cloud.
•	Optimize cloud storage costs for growing media volumes.
•	Design AI-powered detection of harmful content.
•	Ensure that AI systems are auditable and their decisions can be explained.
•	Leverage LLMs and conversational AI for personalized experiences and content virality.
•	Develop advanced chatbots with natural language understanding to provide personalized assistance.
•	Automated summarization for diverse media.

Executive Statement -

At Altostrat, we are embracing the next frontier of artificial intelligence to revolutionize our content strategy. By harnessing the power of generative AI, we will create an unparalleled user experience by empowering our audience with intelligent toots for content discovery, personalized recommendations, and seamless interaction. Reliability and cost management are our top priorities. This strategic initiative will deepen engagement, foster customer loyalty, and unlock new revenue streams through targeted marketing and tailored content offerings. We see a future where Al-driven innovation is central to our business, leading to greater success for our company and delivering exceptional value to our customers.

For this question, refer to the Altostrat Media case study. Altostrat needs to analyze the performance of its media processing pipeline running on Java-based Cloud Run function. You need to select the most effective tool for the task. What should you do?

**A.** Query logs in Cloud Logging.

**B.** Analyze the data via Cloud Profiler.

**C.** Instrument the code to use Cloud Trace.

**D.** Inspect data from Snapshot Debugger.

**Respuesta de la fuente:** B

**Explicación:** Cloud Profiler is the correct tool for analyzing application performance issues such as CPU, memory, and I/O usage in production environments like Cloud Run.
Unlike Cloud Logging (which records events) or Cloud Trace (which measures latency), Cloud Profiler provides low-overhead insights into resource consumption patterns to identify bottlenecks.

## Pregunta 223

Contexto: [topics:92](#topics-92)
Company Overview -

Altostrat is a prominent player in the media industry, with an extensive collection of audio and video content that comprises podcasts, interviews, news broadcasts, and documentaries. Their success in delivering premium content to a diverse audience requires a content management system that can keep pace with the dynamic media landscape.

Solution Concept -

Altostrat seeks to modernize its content management and user engagement strategies using Google Cloud's generative AI. They want a platform that empowers customers with personalized recommendations, natural language interactions and seamless self-service support. Simultaneously, they want to drive revenue growth through dynamic pricing targeted marketing, and personalized product suggestions.

The seamless integration of AI-powered tools into the existing Google Cloud environment will enable Altostrat to efficiently manage their vast media library, enhance user experiences, and unlock new revenue streams. Google Cloud's generative AI will solidify their leadership in the media industry.

Existing Technical Environment -

Altostrat’s content management and delivery platform leverages GKE for scalability and high availability, essential for handling their vast media library. Their extensive media library spanning various documents, audio and video formats is stored in Cloud Storage. To gain valuable insights into user behavior, content consumption patterns, and audience demographics, Altostrat leverages BigQuery as their primary data warehouse. Additionally, they use Cloud Run functions for serverless execution of event-driven tasks such as video transcoding metadata extraction, and personalized content recommendations.

While Altostrat has made significant strides in cloud adoption, they also maintain some legacy on-premises systems for specific workflows like content ingestion and archival. These systems are slated for modernization and migration to Google Cloud in the near future. User management and authentication are currently handled through a combination of Google Identity and third-party identity providers. For monitoring and observability, Altostrat relies on a mix of native Google Cloud tools like Cloud Monitoring and open-source solutions like Prometheus, with alerts primarily delivered via email notifications.

Business Requirements -

•	Accelerate and enhance the reliability of operational workflows across all environments. [Google Cloud + On-premises]
•	Simplify infrastructure management for rapid application deployment.
•	Optimize cloud storage costs while maintaining high availability and scalability for media content.
•	Enable natural language interaction with the platform with 24/7 user support.
•	Automatically generate concise summaries of media content.
•	Extract rich metadata from media assets using NLP and computer vision.
•	Detect and filter inappropriate content.
•	Analyze media content to identify trends and extract insights.
•	Inform content strategy and decision making with data.

Technical Requirements -

•	Modernize CI/CD for containerized deployments with a centralized management platform.
•	Secure, high-performance hybrid cloud connectivity for data ingestion.
•	Provide scalable, performant kubernetes environments both on-premises and in the cloud.
•	Optimize cloud storage costs for growing media volumes.
•	Design AI-powered detection of harmful content.
•	Ensure that AI systems are auditable and their decisions can be explained.
•	Leverage LLMs and conversational AI for personalized experiences and content virality.
•	Develop advanced chatbots with natural language understanding to provide personalized assistance.
•	Automated summarization for diverse media.

Executive Statement -

At Altostrat, we are embracing the next frontier of artificial intelligence to revolutionize our content strategy. By harnessing the power of generative AI, we will create an unparalleled user experience by empowering our audience with intelligent toots for content discovery, personalized recommendations, and seamless interaction. Reliability and cost management are our top priorities. This strategic initiative will deepen engagement, foster customer loyalty, and unlock new revenue streams through targeted marketing and tailored content offerings. We see a future where Al-driven innovation is central to our business, leading to greater success for our company and delivering exceptional value to our customers.

For this question, refer to the Altostrat Media case study. Altostrat is concerned about sophisticated, multi-vector Distributed Denial of Service (DDoS) attacks targeting various layers of their infrastructure. DDoS attacks could potentially disrupt video streaming and cause financial losses. You need to mitigate this risk. What should you do?

**A.** Set up VPC Service Controls to restrict access to sensitive resources and prevent data exfiltration.

**B.** Configure Cloud Next Generation Firewall (NGFW) with custom rules to filter malicious traffic at the network level.

**C.** Deploy Google Cloud Armor with pre-configured and custom rules for L3/L4 and L7 protection

**D.** Activate Security Command Center to monitor security posture and detect potential threats.

**Respuesta de la fuente:** C

**Explicación:** Google Cloud Armor is the dedicated DDoS mitigation service for Google Cloud, providing protection against Layer 3/4 and Layer 7 attacks through configurable Security Policy rules.
While VPC Service Controls prevent data exfiltration and Security Command Center monitors threats, neither actively mitigates volumetric DDoS traffic to ensure availability.
Cloud Armor integrates with Cloud Load Balancing to filter malicious requests before they reach backend resources, directly addressing the risk of disrupted video streaming.

## Pregunta 224

Contexto: [topics:92](#topics-92)
Company Overview -

Altostrat is a prominent player in the media industry, with an extensive collection of audio and video content that comprises podcasts, interviews, news broadcasts, and documentaries. Their success in delivering premium content to a diverse audience requires a content management system that can keep pace with the dynamic media landscape.

Solution Concept -

Altostrat seeks to modernize its content management and user engagement strategies using Google Cloud's generative AI. They want a platform that empowers customers with personalized recommendations, natural language interactions and seamless self-service support. Simultaneously, they want to drive revenue growth through dynamic pricing targeted marketing, and personalized product suggestions.

The seamless integration of AI-powered tools into the existing Google Cloud environment will enable Altostrat to efficiently manage their vast media library, enhance user experiences, and unlock new revenue streams. Google Cloud's generative AI will solidify their leadership in the media industry.

Existing Technical Environment -

Altostrat’s content management and delivery platform leverages GKE for scalability and high availability, essential for handling their vast media library. Their extensive media library spanning various documents, audio and video formats is stored in Cloud Storage. To gain valuable insights into user behavior, content consumption patterns, and audience demographics, Altostrat leverages BigQuery as their primary data warehouse. Additionally, they use Cloud Run functions for serverless execution of event-driven tasks such as video transcoding metadata extraction, and personalized content recommendations.

While Altostrat has made significant strides in cloud adoption, they also maintain some legacy on-premises systems for specific workflows like content ingestion and archival. These systems are slated for modernization and migration to Google Cloud in the near future. User management and authentication are currently handled through a combination of Google Identity and third-party identity providers. For monitoring and observability, Altostrat relies on a mix of native Google Cloud tools like Cloud Monitoring and open-source solutions like Prometheus, with alerts primarily delivered via email notifications.

Business Requirements -

•	Accelerate and enhance the reliability of operational workflows across all environments. [Google Cloud + On-premises]
•	Simplify infrastructure management for rapid application deployment.
•	Optimize cloud storage costs while maintaining high availability and scalability for media content.
•	Enable natural language interaction with the platform with 24/7 user support.
•	Automatically generate concise summaries of media content.
•	Extract rich metadata from media assets using NLP and computer vision.
•	Detect and filter inappropriate content.
•	Analyze media content to identify trends and extract insights.
•	Inform content strategy and decision making with data.

Technical Requirements -

•	Modernize CI/CD for containerized deployments with a centralized management platform.
•	Secure, high-performance hybrid cloud connectivity for data ingestion.
•	Provide scalable, performant kubernetes environments both on-premises and in the cloud.
•	Optimize cloud storage costs for growing media volumes.
•	Design AI-powered detection of harmful content.
•	Ensure that AI systems are auditable and their decisions can be explained.
•	Leverage LLMs and conversational AI for personalized experiences and content virality.
•	Develop advanced chatbots with natural language understanding to provide personalized assistance.
•	Automated summarization for diverse media.

Executive Statement -

At Altostrat, we are embracing the next frontier of artificial intelligence to revolutionize our content strategy. By harnessing the power of generative AI, we will create an unparalleled user experience by empowering our audience with intelligent toots for content discovery, personalized recommendations, and seamless interaction. Reliability and cost management are our top priorities. This strategic initiative will deepen engagement, foster customer loyalty, and unlock new revenue streams through targeted marketing and tailored content offerings. We see a future where Al-driven innovation is central to our business, leading to greater success for our company and delivering exceptional value to our customers.

For this question, refer to the Altostrat Media case study. Altostrat is using Apigee for API management and wants to ensure their APIs are protected from overuse and abuse. You need to implement an Apigee feature to control the total number of API calls for cost management. What should you do?

**A.** Set up API key validation.

**B.** Integrate OAuth 2.0 authorization.

**C.** Configure Quota policies.

**D.** Activate XML threat protection.

**Respuesta de la fuente:** C

**Explicación:** Apigee Quota policies are specifically designed to limit the number of API requests over a defined time period, directly addressing the need for cost management by preventing overuse.
Other options like API Key validation and OAuth 2.0 handle authentication and authorization, while XML threat protection secures against malicious payloads, neither of which controls call volume.

## Pregunta 225

Contexto: [topics:92](#topics-92)
Company Overview -

KnightMotives is a car manufacturer specializing in autonomous, self-driving vehicles, including Battery Electric Vehicles (BEVs), hybrids and traditional internal combustion engine (ICE) vehicles. While KnightMotives has made strides with the in-vehicle experience in their BEV fleet, the hybrid and ICE vehicles have yet to implement these new systems and are viewed poorly by critics and drivers. The lack of modern in-vehicle technology in hybrid and ICE vehicles has resulted in declining sales and customer satisfaction.

KnightMotives wants to modernize the consumer experience across all vehicles within five years Artificial Intelligence offers a unique opportunity to revolutionize the in-vehicle experience, as well as the shopping buying and service/maintenance experience. Investment in this new technology will require a shift in financial priorities on a global scale.

KnightMotives also wants to improve their online ordering system, which is unreliable. Systems for customers to build their vehicle online for acquisition through a dealer are not delivering the data or reliability that dealers need, causing. A strain in the relationship between KnightMotives and dealers. Service technicians and sales staff need better tooling to enhance dealer successes, including built-to-order vehicles.

Solution Concept -

KnightMotives wants to shift from manufacturing cars to creating a complete and compelling “automotive experience.” Then strategy prioritizes delivering a consistent experience across all models, developing AI-powered features, generating new revenue from data monetization, adopting a digital focus to differentiate their brand from competitors, and developing better tools for mechanics and salespeople.

Existing Technical Environment -

KnightMotives's IT is largely on-premises with some applications on major cloud platforms. Their supply chain runs on an outdated mainframe, and Enterprise Resource Planning (ERP) is also outdated, making new promotions and dealer discounts difficult to implement. Dealers have no budget for new equipment. There is fragmentation across vehicles with multiple code bases, and significant technical debt from supporting backwards compatibility. Network connectivity to manufacturing plants and vehicle connectivity in rural areas are challenges.

Business Requirements -

Key business requirements include fostering a personalized relationship with the driver and delivering a cohesive experience across all models. Creating a better build-to-order model will reduce time on the lot and provide transparency for both dealers and customers. Additionally, KnightMotives seeks to monetize corporate data to finance new technology investments, as their current AI infrastructure is obsolete and corporate data remains siloed. Security is a paramount concern due to past data breaches Adherence to European Union (EU) data protection regulations, especially for emerging autonomous platforms, is critical.

KnightMotives plans to make significant investments in fully autonomous driving capabilities, with initial implementation targeting regions with favorable regulatory environments. Prioritizing employee upskilling, attracting top-tier talent, and fostering better communication between business and technical teams are also critical objectives.

Technical Requirements -

•	Modernizing the in-vehicle experience includes developing a consistent user experience (UX) that seamlessly integrates AI-powered features across all models, updating in-vehicle hardware and software in legacy models to support new UX features and AI capabilities, and ensuring reliable network connectivity, especially in rural areas, to support real-time AI features and data transmission.
•	Network upgrades are necessary to support increased data traffic and improve connectivity between plants and headquarters.
•	IT infrastructure modernization requires adopting a hybrid cloud strategy to leverage the benefits of both on-premises and cloud infrastructure, and gradually modernizing or replacing legacy systems to improve efficiency and agility.
•	Autonomous vehicle development and testing requires investing in cutting-edge AI and machine learning technologies, building a robust simulation environment, and ensuring compliance with evolving regulations related to autonomous vehicles.
•	Data monetization and insights requires implementing a robust data management platform, strict data security and privacy measures, and a scalable AI/ML infrastructure.
•	Increased focus on security and risk management involves implementing a comprehensive security framework to protect against cyber threats and data breaches, developing an incident response plan, and providing security awareness training to employees.
•	Providing a delightful experience for dealers and customers requires improving the online build-to-order system; developing modern dealer tools to streamline dealer operations, including sales, service, and inventory management; and implementing a comprehensive Customer Relationship Management (CRM) system to track customer interactions personalize experiences, and improve customer satisfaction.

Executive Statement -

KnightMotives is committed to enhancing safety and saving lives by leveraging an extensive body of data — encompassing driving, road conditions, behavioral studies, and crash safety statistics — to create compelling digital experiences for drivers. Our AI consistently outperforms national safety statistics, ensuring the unique and coveted KnightMotives experience is aligned across all our vehicle models.

Michael Knight, KnightMotives CEO

For this question, refer to the KnightMotives Automotive case study. KnightMotives has developed a new car configurator application to enhance both the dealer and customer experience. The new application will be deployed on Google Kubernetes Engine (GKE) KnightMotives wants you to replicate the deployment of the application across multiple locations to ensure this critical application is always available over the internet, even during regional outages. What should you do?

**A.** Create multiple GKE clusters in different regions. Deploy part of the microservices of the app in different clusters. Configure a multi-cluster Cloud Service Mesh.

**B.** Create multiple GKE clusters in different regions. Deploy the app on every cluster. Configure a multi-cluster Cloud Service Mesh.

**C.** Create a fleet of GKE clusters in different regions Deploy part of the microservices of the app in different clusters Configure a multi-cluster Gateway.

**D.** Create a fleet of GKE clusters in different regions. Deploy the app on every cluster. Configure a multi-cluster Gateway.

**Respuesta de la fuente:** D

**Explicación:** To ensure high availability during regional outages, the application must be fully deployed on every GKE cluster in each region so that any single region can independently serve traffic. A multi-cluster Gateway is the correct configuration for distributing internet traffic across these geographically dispersed clusters based on locality and health, rather than using an internal service mesh.

## Pregunta 226

Contexto: [topics:92](#topics-92)
Company Overview -

KnightMotives is a car manufacturer specializing in autonomous, self-driving vehicles, including Battery Electric Vehicles (BEVs), hybrids and traditional internal combustion engine (ICE) vehicles. While KnightMotives has made strides with the in-vehicle experience in their BEV fleet, the hybrid and ICE vehicles have yet to implement these new systems and are viewed poorly by critics and drivers. The lack of modern in-vehicle technology in hybrid and ICE vehicles has resulted in declining sales and customer satisfaction.

KnightMotives wants to modernize the consumer experience across all vehicles within five years Artificial Intelligence offers a unique opportunity to revolutionize the in-vehicle experience, as well as the shopping buying and service/maintenance experience. Investment in this new technology will require a shift in financial priorities on a global scale.

KnightMotives also wants to improve their online ordering system, which is unreliable. Systems for customers to build their vehicle online for acquisition through a dealer are not delivering the data or reliability that dealers need, causing. A strain in the relationship between KnightMotives and dealers. Service technicians and sales staff need better tooling to enhance dealer successes, including built-to-order vehicles.

Solution Concept -

KnightMotives wants to shift from manufacturing cars to creating a complete and compelling “automotive experience.” Then strategy prioritizes delivering a consistent experience across all models, developing AI-powered features, generating new revenue from data monetization, adopting a digital focus to differentiate their brand from competitors, and developing better tools for mechanics and salespeople.

Existing Technical Environment -

KnightMotives's IT is largely on-premises with some applications on major cloud platforms. Their supply chain runs on an outdated mainframe, and Enterprise Resource Planning (ERP) is also outdated, making new promotions and dealer discounts difficult to implement. Dealers have no budget for new equipment. There is fragmentation across vehicles with multiple code bases, and significant technical debt from supporting backwards compatibility. Network connectivity to manufacturing plants and vehicle connectivity in rural areas are challenges.

Business Requirements -

Key business requirements include fostering a personalized relationship with the driver and delivering a cohesive experience across all models. Creating a better build-to-order model will reduce time on the lot and provide transparency for both dealers and customers. Additionally, KnightMotives seeks to monetize corporate data to finance new technology investments, as their current AI infrastructure is obsolete and corporate data remains siloed. Security is a paramount concern due to past data breaches Adherence to European Union (EU) data protection regulations, especially for emerging autonomous platforms, is critical.

KnightMotives plans to make significant investments in fully autonomous driving capabilities, with initial implementation targeting regions with favorable regulatory environments. Prioritizing employee upskilling, attracting top-tier talent, and fostering better communication between business and technical teams are also critical objectives.

Technical Requirements -

•	Modernizing the in-vehicle experience includes developing a consistent user experience (UX) that seamlessly integrates AI-powered features across all models, updating in-vehicle hardware and software in legacy models to support new UX features and AI capabilities, and ensuring reliable network connectivity, especially in rural areas, to support real-time AI features and data transmission.
•	Network upgrades are necessary to support increased data traffic and improve connectivity between plants and headquarters.
•	IT infrastructure modernization requires adopting a hybrid cloud strategy to leverage the benefits of both on-premises and cloud infrastructure, and gradually modernizing or replacing legacy systems to improve efficiency and agility.
•	Autonomous vehicle development and testing requires investing in cutting-edge AI and machine learning technologies, building a robust simulation environment, and ensuring compliance with evolving regulations related to autonomous vehicles.
•	Data monetization and insights requires implementing a robust data management platform, strict data security and privacy measures, and a scalable AI/ML infrastructure.
•	Increased focus on security and risk management involves implementing a comprehensive security framework to protect against cyber threats and data breaches, developing an incident response plan, and providing security awareness training to employees.
•	Providing a delightful experience for dealers and customers requires improving the online build-to-order system; developing modern dealer tools to streamline dealer operations, including sales, service, and inventory management; and implementing a comprehensive Customer Relationship Management (CRM) system to track customer interactions personalize experiences, and improve customer satisfaction.

Executive Statement -

KnightMotives is committed to enhancing safety and saving lives by leveraging an extensive body of data — encompassing driving, road conditions, behavioral studies, and crash safety statistics — to create compelling digital experiences for drivers. Our AI consistently outperforms national safety statistics, ensuring the unique and coveted KnightMotives experience is aligned across all our vehicle models.

Michael Knight, KnightMotives CEO

For this question, refer to the KnightMotives Automotive case study. As part of its development of fully autonomous driving vehicles. KnightMotives wants to analyze all vehicle sensor data during test drives. The analysis will enable KnightMotives to improve its software based on insights from this data.
•	Different event types, such as parking, overtaking and navigating, need to be analyzed. Each test vehicle and event type has an ID.
•	Different categories of sensors, such as cameras, radars, and ultrasonic beams, also need to be analyzed. During each autonomously-initiated event, data from multiple sensors will be captured and sent to Google Cloud where the data will be stored in Bigtable.

During data analysis, you want to be able to retrieve all sensor data of occurrences of the same event type for a specific vehicle within a specific interval of time. You need to design a Bigtable schema that is optimized for read performance. What should you do?

**A.** Use the sensor category, event ID, and timestamp (in that order) as the row key. Create a column family for each individual sensor and a column qualifier for each vehicle.

**B.** Use the timestamp, vehicle ID, and event ID (in that order) as the row key. Create a column family per sensor category, and use a column qualifier for each individual sensor within its respective category.

**C.** Use the vehicle ID, event ID, and timestamp (in that order) as the row key. Create a column family per sensor category, and use a column qualifier for each individual sensor within its respective category.

**D.** Use the vehicle ID and event ID (in that order) as the row key. Create a column family per sensor category, and use a column qualifier for each individual sensor within its respective category. Utilize the timestamped versions of a cell to distinguish between different moments in time of similar events.

**Respuesta de la fuente:** C

**Explicación:** Bigtable optimizes reads by storing rows with similar prefixes contiguously on disk. To efficiently retrieve data for a specific vehicle and event type within a time interval, the row key must start with vehicle ID, followed by event ID, and then timestamp. This structure allows for an efficient range scan bounded by the timestamps for that specific vehicle-event combination.

## Pregunta 227

Contexto: [topics:92](#topics-92)
Company Overview -

KnightMotives is a car manufacturer specializing in autonomous, self-driving vehicles, including Battery Electric Vehicles (BEVs), hybrids and traditional internal combustion engine (ICE) vehicles. While KnightMotives has made strides with the in-vehicle experience in their BEV fleet, the hybrid and ICE vehicles have yet to implement these new systems and are viewed poorly by critics and drivers. The lack of modern in-vehicle technology in hybrid and ICE vehicles has resulted in declining sales and customer satisfaction.

KnightMotives wants to modernize the consumer experience across all vehicles within five years Artificial Intelligence offers a unique opportunity to revolutionize the in-vehicle experience, as well as the shopping buying and service/maintenance experience. Investment in this new technology will require a shift in financial priorities on a global scale.

KnightMotives also wants to improve their online ordering system, which is unreliable. Systems for customers to build their vehicle online for acquisition through a dealer are not delivering the data or reliability that dealers need, causing. A strain in the relationship between KnightMotives and dealers. Service technicians and sales staff need better tooling to enhance dealer successes, including built-to-order vehicles.

Solution Concept -

KnightMotives wants to shift from manufacturing cars to creating a complete and compelling “automotive experience.” Then strategy prioritizes delivering a consistent experience across all models, developing AI-powered features, generating new revenue from data monetization, adopting a digital focus to differentiate their brand from competitors, and developing better tools for mechanics and salespeople.

Existing Technical Environment -

KnightMotives's IT is largely on-premises with some applications on major cloud platforms. Their supply chain runs on an outdated mainframe, and Enterprise Resource Planning (ERP) is also outdated, making new promotions and dealer discounts difficult to implement. Dealers have no budget for new equipment. There is fragmentation across vehicles with multiple code bases, and significant technical debt from supporting backwards compatibility. Network connectivity to manufacturing plants and vehicle connectivity in rural areas are challenges.

Business Requirements -

Key business requirements include fostering a personalized relationship with the driver and delivering a cohesive experience across all models. Creating a better build-to-order model will reduce time on the lot and provide transparency for both dealers and customers. Additionally, KnightMotives seeks to monetize corporate data to finance new technology investments, as their current AI infrastructure is obsolete and corporate data remains siloed. Security is a paramount concern due to past data breaches Adherence to European Union (EU) data protection regulations, especially for emerging autonomous platforms, is critical.

KnightMotives plans to make significant investments in fully autonomous driving capabilities, with initial implementation targeting regions with favorable regulatory environments. Prioritizing employee upskilling, attracting top-tier talent, and fostering better communication between business and technical teams are also critical objectives.

Technical Requirements -

•	Modernizing the in-vehicle experience includes developing a consistent user experience (UX) that seamlessly integrates AI-powered features across all models, updating in-vehicle hardware and software in legacy models to support new UX features and AI capabilities, and ensuring reliable network connectivity, especially in rural areas, to support real-time AI features and data transmission.
•	Network upgrades are necessary to support increased data traffic and improve connectivity between plants and headquarters.
•	IT infrastructure modernization requires adopting a hybrid cloud strategy to leverage the benefits of both on-premises and cloud infrastructure, and gradually modernizing or replacing legacy systems to improve efficiency and agility.
•	Autonomous vehicle development and testing requires investing in cutting-edge AI and machine learning technologies, building a robust simulation environment, and ensuring compliance with evolving regulations related to autonomous vehicles.
•	Data monetization and insights requires implementing a robust data management platform, strict data security and privacy measures, and a scalable AI/ML infrastructure.
•	Increased focus on security and risk management involves implementing a comprehensive security framework to protect against cyber threats and data breaches, developing an incident response plan, and providing security awareness training to employees.
•	Providing a delightful experience for dealers and customers requires improving the online build-to-order system; developing modern dealer tools to streamline dealer operations, including sales, service, and inventory management; and implementing a comprehensive Customer Relationship Management (CRM) system to track customer interactions personalize experiences, and improve customer satisfaction.

Executive Statement -

KnightMotives is committed to enhancing safety and saving lives by leveraging an extensive body of data — encompassing driving, road conditions, behavioral studies, and crash safety statistics — to create compelling digital experiences for drivers. Our AI consistently outperforms national safety statistics, ensuring the unique and coveted KnightMotives experience is aligned across all our vehicle models.

Michael Knight, KnightMotives CEO

For this question, refer to the KnightMotives Automotive case study, KnightMotives has deployed their new Dealer Tools on Google Kubernetes Engine (GKE). You are supporting KnightMotives in the performance of the GKE workloads. Some of the Pods are Statefull. To ensure these Pods do not consume an unlimited amount of CPU, you have configured resource limits on the Deployments. You have identified that these Pods were allocated too much CPU and are actually consuming drastically less some of the time. You want to optimize resource usage and allow maximum flexibility in case of higher load. What should you do?

**A.** Configure resource requests per Deployment. Set resource requests slightly above the typical CPU usage observed during monitoring.

**B.** Configure resource requests per Deployment. Ensure the requests are equal to the current limits.

**C.** Enable vertical Pod autoscaling on each Deployment. Ensure the autoscaling mode is set to Auto.

**D.** Enable horizontal Pod autoscaling on each Deployment. Ensure the minimum number of Pods is lower than the currently configured amount in the Deployment.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because setting resource requests slightly above typical usage allows the Kubernetes scheduler to efficiently pack Pods onto nodes, optimizing overall cluster utilization.
By keeping the existing CPU limits higher than these new requests, you create a burstable QoS class that provides maximum flexibility for handling sudden load spikes without evicting or restarting Stateful Pods, which avoids the downtime associated with Vertical Pod Autoscaler adjustments.

## Pregunta 228

Contexto: [topics:92](#topics-92)
Company Overview -

KnightMotives is a car manufacturer specializing in autonomous, self-driving vehicles, including Battery Electric Vehicles (BEVs), hybrids and traditional internal combustion engine (ICE) vehicles. While KnightMotives has made strides with the in-vehicle experience in their BEV fleet, the hybrid and ICE vehicles have yet to implement these new systems and are viewed poorly by critics and drivers. The lack of modern in-vehicle technology in hybrid and ICE vehicles has resulted in declining sales and customer satisfaction.

KnightMotives wants to modernize the consumer experience across all vehicles within five years Artificial Intelligence offers a unique opportunity to revolutionize the in-vehicle experience, as well as the shopping buying and service/maintenance experience. Investment in this new technology will require a shift in financial priorities on a global scale.

KnightMotives also wants to improve their online ordering system, which is unreliable. Systems for customers to build their vehicle online for acquisition through a dealer are not delivering the data or reliability that dealers need, causing. A strain in the relationship between KnightMotives and dealers. Service technicians and sales staff need better tooling to enhance dealer successes, including built-to-order vehicles.

Solution Concept -

KnightMotives wants to shift from manufacturing cars to creating a complete and compelling “automotive experience.” Then strategy prioritizes delivering a consistent experience across all models, developing AI-powered features, generating new revenue from data monetization, adopting a digital focus to differentiate their brand from competitors, and developing better tools for mechanics and salespeople.

Existing Technical Environment -

KnightMotives's IT is largely on-premises with some applications on major cloud platforms. Their supply chain runs on an outdated mainframe, and Enterprise Resource Planning (ERP) is also outdated, making new promotions and dealer discounts difficult to implement. Dealers have no budget for new equipment. There is fragmentation across vehicles with multiple code bases, and significant technical debt from supporting backwards compatibility. Network connectivity to manufacturing plants and vehicle connectivity in rural areas are challenges.

Business Requirements -

Key business requirements include fostering a personalized relationship with the driver and delivering a cohesive experience across all models. Creating a better build-to-order model will reduce time on the lot and provide transparency for both dealers and customers. Additionally, KnightMotives seeks to monetize corporate data to finance new technology investments, as their current AI infrastructure is obsolete and corporate data remains siloed. Security is a paramount concern due to past data breaches Adherence to European Union (EU) data protection regulations, especially for emerging autonomous platforms, is critical.

KnightMotives plans to make significant investments in fully autonomous driving capabilities, with initial implementation targeting regions with favorable regulatory environments. Prioritizing employee upskilling, attracting top-tier talent, and fostering better communication between business and technical teams are also critical objectives.

Technical Requirements -

•	Modernizing the in-vehicle experience includes developing a consistent user experience (UX) that seamlessly integrates AI-powered features across all models, updating in-vehicle hardware and software in legacy models to support new UX features and AI capabilities, and ensuring reliable network connectivity, especially in rural areas, to support real-time AI features and data transmission.
•	Network upgrades are necessary to support increased data traffic and improve connectivity between plants and headquarters.
•	IT infrastructure modernization requires adopting a hybrid cloud strategy to leverage the benefits of both on-premises and cloud infrastructure, and gradually modernizing or replacing legacy systems to improve efficiency and agility.
•	Autonomous vehicle development and testing requires investing in cutting-edge AI and machine learning technologies, building a robust simulation environment, and ensuring compliance with evolving regulations related to autonomous vehicles.
•	Data monetization and insights requires implementing a robust data management platform, strict data security and privacy measures, and a scalable AI/ML infrastructure.
•	Increased focus on security and risk management involves implementing a comprehensive security framework to protect against cyber threats and data breaches, developing an incident response plan, and providing security awareness training to employees.
•	Providing a delightful experience for dealers and customers requires improving the online build-to-order system; developing modern dealer tools to streamline dealer operations, including sales, service, and inventory management; and implementing a comprehensive Customer Relationship Management (CRM) system to track customer interactions personalize experiences, and improve customer satisfaction.

Executive Statement -

KnightMotives is committed to enhancing safety and saving lives by leveraging an extensive body of data — encompassing driving, road conditions, behavioral studies, and crash safety statistics — to create compelling digital experiences for drivers. Our AI consistently outperforms national safety statistics, ensuring the unique and coveted KnightMotives experience is aligned across all our vehicle models.

Michael Knight, KnightMotives CEO

For this question, refer to the KnightMotives Automotive case study. KnightMotives has established a dedicated Google Cloud Interconnect with 99.99% availability between its headquarters and two different metropolitan areas corresponding to the us-central1 and us-east1 Google Cloud regions. To minimize cost and latency between these workloads, you want to ensure all workloads in Google Cloud are deployed in these two regions as the VLAN attachment for the Cloud Interconnect. What should you do?

**A.** Schedule an export of all assets via Asset Inventory into BigQuery. Schedule a daily Cloud Run function to query the export and send out an alert if resources are created in regions outside of the allowed list.

**B.** Ensure all deployments are done through Infrastructure as Code using standardized Terraform modules. Configure the region variable of all resources with a default value corresponding to one of the allowed regions.

**C.** Limit the Google Cloud VPC used by the Cloud Interconnect to only have subnets in the allowed regions.

**D.** Configure the Resource Location Restriction constraint organization policy at the organization level, and ensure only the allowed regions are listed.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Organization Policies provide a centralized, declarative way to enforce resource location restrictions across the entire organization. By configuring the `constraints/gcp.resourceLocations` policy to include only us-central1 and us-east1, you prevent any resources from being created in other regions, ensuring cost and latency targets are met.

Option C is incorrect because limiting VPC subnets does not prevent the creation of non-VPC resources (like Cloud Storage buckets or Compute Engine instances) in disallowed regions. Options A and B are ineffective as they rely on reactive alerts or developer discipline rather than hard enforcement mechanisms.

## Pregunta 229

Contexto: [topics:92](#topics-92)
Company Overview -

KnightMotives is a car manufacturer specializing in autonomous, self-driving vehicles, including Battery Electric Vehicles (BEVs), hybrids and traditional internal combustion engine (ICE) vehicles. While KnightMotives has made strides with the in-vehicle experience in their BEV fleet, the hybrid and ICE vehicles have yet to implement these new systems and are viewed poorly by critics and drivers. The lack of modern in-vehicle technology in hybrid and ICE vehicles has resulted in declining sales and customer satisfaction.

KnightMotives wants to modernize the consumer experience across all vehicles within five years Artificial Intelligence offers a unique opportunity to revolutionize the in-vehicle experience, as well as the shopping buying and service/maintenance experience. Investment in this new technology will require a shift in financial priorities on a global scale.

KnightMotives also wants to improve their online ordering system, which is unreliable. Systems for customers to build their vehicle online for acquisition through a dealer are not delivering the data or reliability that dealers need, causing. A strain in the relationship between KnightMotives and dealers. Service technicians and sales staff need better tooling to enhance dealer successes, including built-to-order vehicles.

Solution Concept -

KnightMotives wants to shift from manufacturing cars to creating a complete and compelling “automotive experience.” Then strategy prioritizes delivering a consistent experience across all models, developing AI-powered features, generating new revenue from data monetization, adopting a digital focus to differentiate their brand from competitors, and developing better tools for mechanics and salespeople.

Existing Technical Environment -

KnightMotives's IT is largely on-premises with some applications on major cloud platforms. Their supply chain runs on an outdated mainframe, and Enterprise Resource Planning (ERP) is also outdated, making new promotions and dealer discounts difficult to implement. Dealers have no budget for new equipment. There is fragmentation across vehicles with multiple code bases, and significant technical debt from supporting backwards compatibility. Network connectivity to manufacturing plants and vehicle connectivity in rural areas are challenges.

Business Requirements -

Key business requirements include fostering a personalized relationship with the driver and delivering a cohesive experience across all models. Creating a better build-to-order model will reduce time on the lot and provide transparency for both dealers and customers. Additionally, KnightMotives seeks to monetize corporate data to finance new technology investments, as their current AI infrastructure is obsolete and corporate data remains siloed. Security is a paramount concern due to past data breaches Adherence to European Union (EU) data protection regulations, especially for emerging autonomous platforms, is critical.

KnightMotives plans to make significant investments in fully autonomous driving capabilities, with initial implementation targeting regions with favorable regulatory environments. Prioritizing employee upskilling, attracting top-tier talent, and fostering better communication between business and technical teams are also critical objectives.

Technical Requirements -

•	Modernizing the in-vehicle experience includes developing a consistent user experience (UX) that seamlessly integrates AI-powered features across all models, updating in-vehicle hardware and software in legacy models to support new UX features and AI capabilities, and ensuring reliable network connectivity, especially in rural areas, to support real-time AI features and data transmission.
•	Network upgrades are necessary to support increased data traffic and improve connectivity between plants and headquarters.
•	IT infrastructure modernization requires adopting a hybrid cloud strategy to leverage the benefits of both on-premises and cloud infrastructure, and gradually modernizing or replacing legacy systems to improve efficiency and agility.
•	Autonomous vehicle development and testing requires investing in cutting-edge AI and machine learning technologies, building a robust simulation environment, and ensuring compliance with evolving regulations related to autonomous vehicles.
•	Data monetization and insights requires implementing a robust data management platform, strict data security and privacy measures, and a scalable AI/ML infrastructure.
•	Increased focus on security and risk management involves implementing a comprehensive security framework to protect against cyber threats and data breaches, developing an incident response plan, and providing security awareness training to employees.
•	Providing a delightful experience for dealers and customers requires improving the online build-to-order system; developing modern dealer tools to streamline dealer operations, including sales, service, and inventory management; and implementing a comprehensive Customer Relationship Management (CRM) system to track customer interactions personalize experiences, and improve customer satisfaction.

Executive Statement -

KnightMotives is committed to enhancing safety and saving lives by leveraging an extensive body of data — encompassing driving, road conditions, behavioral studies, and crash safety statistics — to create compelling digital experiences for drivers. Our AI consistently outperforms national safety statistics, ensuring the unique and coveted KnightMotives experience is aligned across all our vehicle models.

Michael Knight, KnightMotives CEO

For this question, refer to the KnightMotives Automotive case study. KnightMotives is managing supplier data and pricing in a central MySQL database at headquarters (HQ). Only personnel at HQ are allowed to change the data. Each local plant stores a copy of the data in their own MySQL database, often using a different database schema or version. Every night a batch job exports any product or price updates in XML format from the central database at HQ and stores the updated data on a central FTP server. Each local plant must download this XML file and update their local system with the new information. The local data kept by some plants has become inconsistent with the source data due to XML parsing issues. HQ wants to easily verify that all changes are applied correctly at each plant.

**A.** Create a Pub/Sub topic per supplier, and have HQ publish all changes related to the respective supplier in JSON format on that topic. Allow all plants to create Pub/Sub Pull subscription to receive messages for their suppliers and update their databases.

**B.** Create a Pub/Sub topic per supplier, and have HQ publish all changes related to the respective supplier in JSON format on that topic. Allow all plants to create Pub/Sub Push subscription to receive messages for their suppliers and update their databases.

**C.** Migrate the self-hosted MySQL database at HQ to Cloud SQL. Standardize the database schema across all plants, and configure the local databases as external read replicas in Cloud SQL.

**D.** Migrate the self-hosted MySQL database at HQ to Cloud SQL. Configure Database Migration Service between Cloud SQL and the on-premises databases. When creating the migration job. choose continuous migration instead of one-time migration.

**Respuesta de la fuente:** C

**Explicación:** The core problem involves data inconsistency due to schema differences and XML parsing errors. Migrating to Cloud SQL and configuring local databases as external read replicas ensures that all plants use a standardized schema and automatically receive consistent, real-time updates from the central source without manual file processing.

## Pregunta 230

Contexto: [topics:92](#topics-92)
Company Overview -

KnightMotives is a car manufacturer specializing in autonomous, self-driving vehicles, including Battery Electric Vehicles (BEVs), hybrids and traditional internal combustion engine (ICE) vehicles. While KnightMotives has made strides with the in-vehicle experience in their BEV fleet, the hybrid and ICE vehicles have yet to implement these new systems and are viewed poorly by critics and drivers. The lack of modern in-vehicle technology in hybrid and ICE vehicles has resulted in declining sales and customer satisfaction.

KnightMotives wants to modernize the consumer experience across all vehicles within five years Artificial Intelligence offers a unique opportunity to revolutionize the in-vehicle experience, as well as the shopping buying and service/maintenance experience. Investment in this new technology will require a shift in financial priorities on a global scale.

KnightMotives also wants to improve their online ordering system, which is unreliable. Systems for customers to build their vehicle online for acquisition through a dealer are not delivering the data or reliability that dealers need, causing. A strain in the relationship between KnightMotives and dealers. Service technicians and sales staff need better tooling to enhance dealer successes, including built-to-order vehicles.

Solution Concept -

KnightMotives wants to shift from manufacturing cars to creating a complete and compelling “automotive experience.” Then strategy prioritizes delivering a consistent experience across all models, developing AI-powered features, generating new revenue from data monetization, adopting a digital focus to differentiate their brand from competitors, and developing better tools for mechanics and salespeople.

Existing Technical Environment -

KnightMotives's IT is largely on-premises with some applications on major cloud platforms. Their supply chain runs on an outdated mainframe, and Enterprise Resource Planning (ERP) is also outdated, making new promotions and dealer discounts difficult to implement. Dealers have no budget for new equipment. There is fragmentation across vehicles with multiple code bases, and significant technical debt from supporting backwards compatibility. Network connectivity to manufacturing plants and vehicle connectivity in rural areas are challenges.

Business Requirements -

Key business requirements include fostering a personalized relationship with the driver and delivering a cohesive experience across all models. Creating a better build-to-order model will reduce time on the lot and provide transparency for both dealers and customers. Additionally, KnightMotives seeks to monetize corporate data to finance new technology investments, as their current AI infrastructure is obsolete and corporate data remains siloed. Security is a paramount concern due to past data breaches Adherence to European Union (EU) data protection regulations, especially for emerging autonomous platforms, is critical.

KnightMotives plans to make significant investments in fully autonomous driving capabilities, with initial implementation targeting regions with favorable regulatory environments. Prioritizing employee upskilling, attracting top-tier talent, and fostering better communication between business and technical teams are also critical objectives.

Technical Requirements -

•	Modernizing the in-vehicle experience includes developing a consistent user experience (UX) that seamlessly integrates AI-powered features across all models, updating in-vehicle hardware and software in legacy models to support new UX features and AI capabilities, and ensuring reliable network connectivity, especially in rural areas, to support real-time AI features and data transmission.
•	Network upgrades are necessary to support increased data traffic and improve connectivity between plants and headquarters.
•	IT infrastructure modernization requires adopting a hybrid cloud strategy to leverage the benefits of both on-premises and cloud infrastructure, and gradually modernizing or replacing legacy systems to improve efficiency and agility.
•	Autonomous vehicle development and testing requires investing in cutting-edge AI and machine learning technologies, building a robust simulation environment, and ensuring compliance with evolving regulations related to autonomous vehicles.
•	Data monetization and insights requires implementing a robust data management platform, strict data security and privacy measures, and a scalable AI/ML infrastructure.
•	Increased focus on security and risk management involves implementing a comprehensive security framework to protect against cyber threats and data breaches, developing an incident response plan, and providing security awareness training to employees.
•	Providing a delightful experience for dealers and customers requires improving the online build-to-order system; developing modern dealer tools to streamline dealer operations, including sales, service, and inventory management; and implementing a comprehensive Customer Relationship Management (CRM) system to track customer interactions personalize experiences, and improve customer satisfaction.

Executive Statement -

KnightMotives is committed to enhancing safety and saving lives by leveraging an extensive body of data — encompassing driving, road conditions, behavioral studies, and crash safety statistics — to create compelling digital experiences for drivers. Our AI consistently outperforms national safety statistics, ensuring the unique and coveted KnightMotives experience is aligned across all our vehicle models.

Michael Knight, KnightMotives CEO

For this question, refer to the KnightMotives Automotive case study. KnightMotives wants to personalize the dealer experience for its customers and has decided to train its own AI models for personalized recommendations. The company will start collecting personally identifiable information (PII) from its customers to use as part of the models’ training data. KnightMotives wants to ensure maximum security and compliance worldwide. You need to ensure the data is encrypted both at rest and during AI model training without impacting the models’ accuracy. What should you do?

**A.** Store the training data in BigQuery using column-level encryption. Train the model using Confidential GKE Nodes.

**B.** Store the training data in BigQuery using column-level encryption Train the model on VertexAI notebooks using customer-managed encryption keys.

**C.** Process all data with Sensitive Data Protection’s de-identification service. Replace any PII with a random string before storing it. Train the model using Confidential GKE Nodes.

**D.** Process all data with Sensitive Data Protection's de-identification service. Replace any PII with a random string before storing it. Train the model on VertexAI notebooks using customer-managed encryption keys.

**Respuesta de la fuente:** A

**Explicación:** The requirement to encrypt data during AI model training necessitates confidential computing capabilities provided by Confidential GKE Nodes, which keep data encrypted in memory (in use). BigQuery column-level encryption ensures PII is protected at rest while allowing the necessary analytics for model preparation. Options using CMEK only address encryption at rest, not in use, and de-identification compromises the personalization accuracy required by the business case.

## Pregunta 231

Contexto: [topics:92](#topics-92)
Company Overview -

KnightMotives is a car manufacturer specializing in autonomous, self-driving vehicles, including Battery Electric Vehicles (BEVs), hybrids and traditional internal combustion engine (ICE) vehicles. While KnightMotives has made strides with the in-vehicle experience in their BEV fleet, the hybrid and ICE vehicles have yet to implement these new systems and are viewed poorly by critics and drivers. The lack of modern in-vehicle technology in hybrid and ICE vehicles has resulted in declining sales and customer satisfaction.

KnightMotives wants to modernize the consumer experience across all vehicles within five years Artificial Intelligence offers a unique opportunity to revolutionize the in-vehicle experience, as well as the shopping buying and service/maintenance experience. Investment in this new technology will require a shift in financial priorities on a global scale.

KnightMotives also wants to improve their online ordering system, which is unreliable. Systems for customers to build their vehicle online for acquisition through a dealer are not delivering the data or reliability that dealers need, causing. A strain in the relationship between KnightMotives and dealers. Service technicians and sales staff need better tooling to enhance dealer successes, including built-to-order vehicles.

Solution Concept -

KnightMotives wants to shift from manufacturing cars to creating a complete and compelling “automotive experience.” Then strategy prioritizes delivering a consistent experience across all models, developing AI-powered features, generating new revenue from data monetization, adopting a digital focus to differentiate their brand from competitors, and developing better tools for mechanics and salespeople.

Existing Technical Environment -

KnightMotives's IT is largely on-premises with some applications on major cloud platforms. Their supply chain runs on an outdated mainframe, and Enterprise Resource Planning (ERP) is also outdated, making new promotions and dealer discounts difficult to implement. Dealers have no budget for new equipment. There is fragmentation across vehicles with multiple code bases, and significant technical debt from supporting backwards compatibility. Network connectivity to manufacturing plants and vehicle connectivity in rural areas are challenges.

Business Requirements -

Key business requirements include fostering a personalized relationship with the driver and delivering a cohesive experience across all models. Creating a better build-to-order model will reduce time on the lot and provide transparency for both dealers and customers. Additionally, KnightMotives seeks to monetize corporate data to finance new technology investments, as their current AI infrastructure is obsolete and corporate data remains siloed. Security is a paramount concern due to past data breaches Adherence to European Union (EU) data protection regulations, especially for emerging autonomous platforms, is critical.

KnightMotives plans to make significant investments in fully autonomous driving capabilities, with initial implementation targeting regions with favorable regulatory environments. Prioritizing employee upskilling, attracting top-tier talent, and fostering better communication between business and technical teams are also critical objectives.

Technical Requirements -

•	Modernizing the in-vehicle experience includes developing a consistent user experience (UX) that seamlessly integrates AI-powered features across all models, updating in-vehicle hardware and software in legacy models to support new UX features and AI capabilities, and ensuring reliable network connectivity, especially in rural areas, to support real-time AI features and data transmission.
•	Network upgrades are necessary to support increased data traffic and improve connectivity between plants and headquarters.
•	IT infrastructure modernization requires adopting a hybrid cloud strategy to leverage the benefits of both on-premises and cloud infrastructure, and gradually modernizing or replacing legacy systems to improve efficiency and agility.
•	Autonomous vehicle development and testing requires investing in cutting-edge AI and machine learning technologies, building a robust simulation environment, and ensuring compliance with evolving regulations related to autonomous vehicles.
•	Data monetization and insights requires implementing a robust data management platform, strict data security and privacy measures, and a scalable AI/ML infrastructure.
•	Increased focus on security and risk management involves implementing a comprehensive security framework to protect against cyber threats and data breaches, developing an incident response plan, and providing security awareness training to employees.
•	Providing a delightful experience for dealers and customers requires improving the online build-to-order system; developing modern dealer tools to streamline dealer operations, including sales, service, and inventory management; and implementing a comprehensive Customer Relationship Management (CRM) system to track customer interactions personalize experiences, and improve customer satisfaction.

Executive Statement -

KnightMotives is committed to enhancing safety and saving lives by leveraging an extensive body of data — encompassing driving, road conditions, behavioral studies, and crash safety statistics — to create compelling digital experiences for drivers. Our AI consistently outperforms national safety statistics, ensuring the unique and coveted KnightMotives experience is aligned across all our vehicle models.

Michael Knight, KnightMotives CEO

For this question, refer to the KnightMotives Automotive case study. You are responsible for designing the network infrastructure architecture for KnightMotives's new environment on Google Cloud. You need to design the new VPC topology. You want to ensure a guaranteed bandwidth and low latency between the plants and Google Cloud resources. What should you do?

**A.** Create a Standard Tier VPC. and ensure a subnet is available in the region closest to a plant. Establish a Cloud Interconnect between each subnet and the local plant.

**B.** Create a Standard Tier VPC. and ensure a subnet is available in the region closest to a plant Establish Direct Peering between Google's Edge Network and the local plant.

**C.** Create a Premium Ter VPand ensure a subnet is available in the region closest to a plant. Establish a Cloud Interconnect between each subnet and the local plant.

**D.** Create a Premium Ter VPC. and ensure a subnet is available in the region closest to a plant. Establish Direct Peering between Google's Edge Network and the local plant.

**Respuesta de la fuente:** C

**Explicación:** To guarantee bandwidth and ensure low latency between on-premises locations and Google Cloud, you must use Dedicated Interconnect or Partner Interconnect, which require a Premium Tier VPC to leverage Google's global backbone network for optimal routing. Standard Tier VPCs use the public internet for cross-region traffic, failing to meet the strict performance and reliability requirements specified in the scenario.

## Pregunta 232

Contexto: [topics:92](#topics-92)
Company Overview -

KnightMotives is a car manufacturer specializing in autonomous, self-driving vehicles, including Battery Electric Vehicles (BEVs), hybrids and traditional internal combustion engine (ICE) vehicles. While KnightMotives has made strides with the in-vehicle experience in their BEV fleet, the hybrid and ICE vehicles have yet to implement these new systems and are viewed poorly by critics and drivers. The lack of modern in-vehicle technology in hybrid and ICE vehicles has resulted in declining sales and customer satisfaction.

KnightMotives wants to modernize the consumer experience across all vehicles within five years Artificial Intelligence offers a unique opportunity to revolutionize the in-vehicle experience, as well as the shopping buying and service/maintenance experience. Investment in this new technology will require a shift in financial priorities on a global scale.

KnightMotives also wants to improve their online ordering system, which is unreliable. Systems for customers to build their vehicle online for acquisition through a dealer are not delivering the data or reliability that dealers need, causing. A strain in the relationship between KnightMotives and dealers. Service technicians and sales staff need better tooling to enhance dealer successes, including built-to-order vehicles.

Solution Concept -

KnightMotives wants to shift from manufacturing cars to creating a complete and compelling “automotive experience.” Then strategy prioritizes delivering a consistent experience across all models, developing AI-powered features, generating new revenue from data monetization, adopting a digital focus to differentiate their brand from competitors, and developing better tools for mechanics and salespeople.

Existing Technical Environment -

KnightMotives's IT is largely on-premises with some applications on major cloud platforms. Their supply chain runs on an outdated mainframe, and Enterprise Resource Planning (ERP) is also outdated, making new promotions and dealer discounts difficult to implement. Dealers have no budget for new equipment. There is fragmentation across vehicles with multiple code bases, and significant technical debt from supporting backwards compatibility. Network connectivity to manufacturing plants and vehicle connectivity in rural areas are challenges.

Business Requirements -

Key business requirements include fostering a personalized relationship with the driver and delivering a cohesive experience across all models. Creating a better build-to-order model will reduce time on the lot and provide transparency for both dealers and customers. Additionally, KnightMotives seeks to monetize corporate data to finance new technology investments, as their current AI infrastructure is obsolete and corporate data remains siloed. Security is a paramount concern due to past data breaches Adherence to European Union (EU) data protection regulations, especially for emerging autonomous platforms, is critical.

KnightMotives plans to make significant investments in fully autonomous driving capabilities, with initial implementation targeting regions with favorable regulatory environments. Prioritizing employee upskilling, attracting top-tier talent, and fostering better communication between business and technical teams are also critical objectives.

Technical Requirements -

•	Modernizing the in-vehicle experience includes developing a consistent user experience (UX) that seamlessly integrates AI-powered features across all models, updating in-vehicle hardware and software in legacy models to support new UX features and AI capabilities, and ensuring reliable network connectivity, especially in rural areas, to support real-time AI features and data transmission.
•	Network upgrades are necessary to support increased data traffic and improve connectivity between plants and headquarters.
•	IT infrastructure modernization requires adopting a hybrid cloud strategy to leverage the benefits of both on-premises and cloud infrastructure, and gradually modernizing or replacing legacy systems to improve efficiency and agility.
•	Autonomous vehicle development and testing requires investing in cutting-edge AI and machine learning technologies, building a robust simulation environment, and ensuring compliance with evolving regulations related to autonomous vehicles.
•	Data monetization and insights requires implementing a robust data management platform, strict data security and privacy measures, and a scalable AI/ML infrastructure.
•	Increased focus on security and risk management involves implementing a comprehensive security framework to protect against cyber threats and data breaches, developing an incident response plan, and providing security awareness training to employees.
•	Providing a delightful experience for dealers and customers requires improving the online build-to-order system; developing modern dealer tools to streamline dealer operations, including sales, service, and inventory management; and implementing a comprehensive Customer Relationship Management (CRM) system to track customer interactions personalize experiences, and improve customer satisfaction.

Executive Statement -

KnightMotives is committed to enhancing safety and saving lives by leveraging an extensive body of data — encompassing driving, road conditions, behavioral studies, and crash safety statistics — to create compelling digital experiences for drivers. Our AI consistently outperforms national safety statistics, ensuring the unique and coveted KnightMotives experience is aligned across all our vehicle models.

Michael Knight, KnightMotives CEO

For this question, refer to the KnightMotives Automotive case study. As part of its cloud strategy. KnightMotives wants to move its virtual machines (VMs) into Google Cloud. These VMs contain applications, database instances, and file servers. In the future, KnightMotives intends to modernize their landscape by adopting cloud native technologies on Google Cloud. During modernization, minimal latency and operational overhead between the old and new landscape will be crucial. You need to design the cloud architecture for the VM environment on Google Cloud while ensuring a future modernization track will meet the technical requirements. What should you do?

**A.** Create a Shared Virtual Private Cloud (VPC). and migrate the VMs to Compute Engine in a new project. During modernization, deploy each modernized workload in a dedicated Google Cloud project with its own VPC. Connect the two VPCs via an on-premises VPN.

**B.** Create a Shared Virtual Private Cloud (VPC). Migrate the VMs to Compute Engine in a new project. During modernization, deploy each modernized workload in a dedicated Google Cloud project using the Shared VPC.

**C.** Create a single private cloud on Google Cloud VMware Engine. Migrate the VMs using VMware HCX. During modernization, deploy the modernized workloads in a single Google Cloud project using a single VPC.

**D.** Create a single private cloud on Google Cloud VMware Engine. Migrate the VMs using VMware HCX. During modernization, deploy each modernized workload in a dedicated Google Cloud project with its own VPC.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it leverages Shared VPC to keep legacy VMs and modernized workloads on the same network plane without routing traffic through an external VPN, ensuring minimal latency.

Deploying modernized workloads in dedicated projects attached to the shared network allows for independent IAM management and scaling while maintaining direct internal connectivity, thereby reducing operational overhead during the migration phase.

## Pregunta 233

Contexto: [topics:92](#topics-92)
Company Overview -

KnightMotives is a car manufacturer specializing in autonomous, self-driving vehicles, including Battery Electric Vehicles (BEVs), hybrids and traditional internal combustion engine (ICE) vehicles. While KnightMotives has made strides with the in-vehicle experience in their BEV fleet, the hybrid and ICE vehicles have yet to implement these new systems and are viewed poorly by critics and drivers. The lack of modern in-vehicle technology in hybrid and ICE vehicles has resulted in declining sales and customer satisfaction.

KnightMotives wants to modernize the consumer experience across all vehicles within five years Artificial Intelligence offers a unique opportunity to revolutionize the in-vehicle experience, as well as the shopping buying and service/maintenance experience. Investment in this new technology will require a shift in financial priorities on a global scale.

KnightMotives also wants to improve their online ordering system, which is unreliable. Systems for customers to build their vehicle online for acquisition through a dealer are not delivering the data or reliability that dealers need, causing. A strain in the relationship between KnightMotives and dealers. Service technicians and sales staff need better tooling to enhance dealer successes, including built-to-order vehicles.

Solution Concept -

KnightMotives wants to shift from manufacturing cars to creating a complete and compelling “automotive experience.” Then strategy prioritizes delivering a consistent experience across all models, developing AI-powered features, generating new revenue from data monetization, adopting a digital focus to differentiate their brand from competitors, and developing better tools for mechanics and salespeople.

Existing Technical Environment -

KnightMotives's IT is largely on-premises with some applications on major cloud platforms. Their supply chain runs on an outdated mainframe, and Enterprise Resource Planning (ERP) is also outdated, making new promotions and dealer discounts difficult to implement. Dealers have no budget for new equipment. There is fragmentation across vehicles with multiple code bases, and significant technical debt from supporting backwards compatibility. Network connectivity to manufacturing plants and vehicle connectivity in rural areas are challenges.

Business Requirements -

Key business requirements include fostering a personalized relationship with the driver and delivering a cohesive experience across all models. Creating a better build-to-order model will reduce time on the lot and provide transparency for both dealers and customers. Additionally, KnightMotives seeks to monetize corporate data to finance new technology investments, as their current AI infrastructure is obsolete and corporate data remains siloed. Security is a paramount concern due to past data breaches Adherence to European Union (EU) data protection regulations, especially for emerging autonomous platforms, is critical.

KnightMotives plans to make significant investments in fully autonomous driving capabilities, with initial implementation targeting regions with favorable regulatory environments. Prioritizing employee upskilling, attracting top-tier talent, and fostering better communication between business and technical teams are also critical objectives.

Technical Requirements -

•	Modernizing the in-vehicle experience includes developing a consistent user experience (UX) that seamlessly integrates AI-powered features across all models, updating in-vehicle hardware and software in legacy models to support new UX features and AI capabilities, and ensuring reliable network connectivity, especially in rural areas, to support real-time AI features and data transmission.
•	Network upgrades are necessary to support increased data traffic and improve connectivity between plants and headquarters.
•	IT infrastructure modernization requires adopting a hybrid cloud strategy to leverage the benefits of both on-premises and cloud infrastructure, and gradually modernizing or replacing legacy systems to improve efficiency and agility.
•	Autonomous vehicle development and testing requires investing in cutting-edge AI and machine learning technologies, building a robust simulation environment, and ensuring compliance with evolving regulations related to autonomous vehicles.
•	Data monetization and insights requires implementing a robust data management platform, strict data security and privacy measures, and a scalable AI/ML infrastructure.
•	Increased focus on security and risk management involves implementing a comprehensive security framework to protect against cyber threats and data breaches, developing an incident response plan, and providing security awareness training to employees.
•	Providing a delightful experience for dealers and customers requires improving the online build-to-order system; developing modern dealer tools to streamline dealer operations, including sales, service, and inventory management; and implementing a comprehensive Customer Relationship Management (CRM) system to track customer interactions personalize experiences, and improve customer satisfaction.

Executive Statement -

KnightMotives is committed to enhancing safety and saving lives by leveraging an extensive body of data — encompassing driving, road conditions, behavioral studies, and crash safety statistics — to create compelling digital experiences for drivers. Our AI consistently outperforms national safety statistics, ensuring the unique and coveted KnightMotives experience is aligned across all our vehicle models.

Michael Knight, KnightMotives CEO

For this question, refer to the KnightMotives Automotive case study. KnightMotives management wants to upskill their engineering teams. They want each team to experiment with one specific technology at a time in a sandbox environment in Google Cloud. KnightMotives management also wants to prevent any experimental projects from going into production and creating shadow IT. They want you to design a solution that supports these training objectives and follows Google-recommended practices. What should you do?

**A.** Create a request form where engineers can request a sandbox environment for a specific technology. Automate the creation of a project with only the relevant APIs enabled and lower the default API quota. Grant IAM roles related to this scope to the requesting team. Ensure the project is automatically deleted after a predefined amount of time.

**B.** Create a request form where engineers can request a sandbox environment and automate the creation of a project in which the requesting engineer obtains full permissions. Within the details of the request form, highlight the expectation of keeping costs under control and the scope limited to the requested services.

**C.** Create a separate billing account for all sandbox projects. Grant all engineers the role of Billing Account User on this billing account. Create a folder called Sandboxes in the Organization's Resource Manager. Grant all users the Project Creator role on this folder.

**D.** Create a secondary Google Cloud organization which is to be used for R&D, separate from the production organization. Create a folder for each team under this organization. Create a project for each team member in the relevant folder. Grant each team member full access to their dedicated project. Grant each team manager the permission of Security Admin on the respective folder. Have them enable the relevant APIs in each team member's project.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 234

Contexto: [topics:92](#topics-92)
Company Overview -

KnightMotives is a car manufacturer specializing in autonomous, self-driving vehicles, including Battery Electric Vehicles (BEVs), hybrids and traditional internal combustion engine (ICE) vehicles. While KnightMotives has made strides with the in-vehicle experience in their BEV fleet, the hybrid and ICE vehicles have yet to implement these new systems and are viewed poorly by critics and drivers. The lack of modern in-vehicle technology in hybrid and ICE vehicles has resulted in declining sales and customer satisfaction.

KnightMotives wants to modernize the consumer experience across all vehicles within five years Artificial Intelligence offers a unique opportunity to revolutionize the in-vehicle experience, as well as the shopping buying and service/maintenance experience. Investment in this new technology will require a shift in financial priorities on a global scale.

KnightMotives also wants to improve their online ordering system, which is unreliable. Systems for customers to build their vehicle online for acquisition through a dealer are not delivering the data or reliability that dealers need, causing. A strain in the relationship between KnightMotives and dealers. Service technicians and sales staff need better tooling to enhance dealer successes, including built-to-order vehicles.

Solution Concept -

KnightMotives wants to shift from manufacturing cars to creating a complete and compelling “automotive experience.” Then strategy prioritizes delivering a consistent experience across all models, developing AI-powered features, generating new revenue from data monetization, adopting a digital focus to differentiate their brand from competitors, and developing better tools for mechanics and salespeople.

Existing Technical Environment -

KnightMotives's IT is largely on-premises with some applications on major cloud platforms. Their supply chain runs on an outdated mainframe, and Enterprise Resource Planning (ERP) is also outdated, making new promotions and dealer discounts difficult to implement. Dealers have no budget for new equipment. There is fragmentation across vehicles with multiple code bases, and significant technical debt from supporting backwards compatibility. Network connectivity to manufacturing plants and vehicle connectivity in rural areas are challenges.

Business Requirements -

Key business requirements include fostering a personalized relationship with the driver and delivering a cohesive experience across all models. Creating a better build-to-order model will reduce time on the lot and provide transparency for both dealers and customers. Additionally, KnightMotives seeks to monetize corporate data to finance new technology investments, as their current AI infrastructure is obsolete and corporate data remains siloed. Security is a paramount concern due to past data breaches Adherence to European Union (EU) data protection regulations, especially for emerging autonomous platforms, is critical.

KnightMotives plans to make significant investments in fully autonomous driving capabilities, with initial implementation targeting regions with favorable regulatory environments. Prioritizing employee upskilling, attracting top-tier talent, and fostering better communication between business and technical teams are also critical objectives.

Technical Requirements -

•	Modernizing the in-vehicle experience includes developing a consistent user experience (UX) that seamlessly integrates AI-powered features across all models, updating in-vehicle hardware and software in legacy models to support new UX features and AI capabilities, and ensuring reliable network connectivity, especially in rural areas, to support real-time AI features and data transmission.
•	Network upgrades are necessary to support increased data traffic and improve connectivity between plants and headquarters.
•	IT infrastructure modernization requires adopting a hybrid cloud strategy to leverage the benefits of both on-premises and cloud infrastructure, and gradually modernizing or replacing legacy systems to improve efficiency and agility.
•	Autonomous vehicle development and testing requires investing in cutting-edge AI and machine learning technologies, building a robust simulation environment, and ensuring compliance with evolving regulations related to autonomous vehicles.
•	Data monetization and insights requires implementing a robust data management platform, strict data security and privacy measures, and a scalable AI/ML infrastructure.
•	Increased focus on security and risk management involves implementing a comprehensive security framework to protect against cyber threats and data breaches, developing an incident response plan, and providing security awareness training to employees.
•	Providing a delightful experience for dealers and customers requires improving the online build-to-order system; developing modern dealer tools to streamline dealer operations, including sales, service, and inventory management; and implementing a comprehensive Customer Relationship Management (CRM) system to track customer interactions personalize experiences, and improve customer satisfaction.

Executive Statement -

KnightMotives is committed to enhancing safety and saving lives by leveraging an extensive body of data — encompassing driving, road conditions, behavioral studies, and crash safety statistics — to create compelling digital experiences for drivers. Our AI consistently outperforms national safety statistics, ensuring the unique and coveted KnightMotives experience is aligned across all our vehicle models.

Michael Knight, KnightMotives CEO

For this question, refer to the KnightMotives Automotive case study. KnightMotives has developed and deployed a model on Vertex AI that can provide personalized recommendations in the new car configuration application. Customers will receive optional equipment recommendations that best suit their persona. Previous usage data from the car configuration application has been used for model training features. You know from past experience that customer behavior can change over time. For example, in times of economic certainty and rising stock markets, customers tend to purchase more expensive options. You want to detect when customer behavior gradually changes over time so you can adjust the model. What should you do?

**A.** Configure Model Monitoring, and select training-serving skew detection.

**B.** Configure Model Monitoring, and select prediction drift detection.

**C.** Configure Dataplex auto data quality on the prediction request data features using row-level rules.

**D.** Configure Dataplex auto data quality on the prediction request data features using aggregate rules.

**Respuesta de la fuente:** B

**Explicación:** The scenario describes a gradual change in customer behavior over time, which constitutes data drift (specifically prediction or feature drift) rather than training-serving skew. Prediction drift detection in Vertex AI Model Monitoring is designed to identify when the distribution of input features or predictions diverges from the baseline, allowing you to detect these behavioral shifts and retrain the model accordingly.

## Pregunta 235

Contexto: [topics:92](#topics-92)
Your team plans to use Vertex AI to develop and deploy machine learning models for various use cases for fraud detection, product recommendations, and customer churn prediction. You want to enhance the security posture of the Vertex AI and Workbench environment by restricting data exfiltration. What should you do?

**A.** Enable Private Google Access for the VPC network to allow Vertex AI services to access public Google services without traversing the public internet.

**B.** Enable VPC Flow Logs to monitor network traffic to and from Vertex AI services and to identify suspicious activity.

**C.** Create a service perimeter and include ml.googleapis.com and document.googleapis.com as protected services.

**D.** Create a service perimeter and include aiplatform.googleapis.com and notebooks.googleapis.com as protected services.

**Respuesta de la fuente:** D

**Explicación:** To restrict data exfiltration within a VPC Service Controls perimeter, you must include the specific Google Cloud services handling your sensitive data.
Vertex AI models are managed via aiplatform.googleapis.com, and Vertex AI Workbench uses notebooks.googleapis.com.
Including these service names in the service perimeter ensures that data cannot be accessed or exported outside the defined security boundary.

## Pregunta 236

Contexto: [topics:92](#topics-92)
You have an application that uses Vertex AI Feature Store to manage and serve product features for real-time recommendations. You want to monitor the performance and health of the application. You need to understand the overall duration of a request. What should you do?

**A.** Observe the Request size in your featurestore.

**B.** Monitor the Queries per second for your featurestore.

**C.** Measure the Latency of your requests.

**D.** Track the Online serving throughput of your requests.

**Respuesta de la fuente:** C

**Explicación:** The question specifically asks for the overall duration of a request, which is the definition of latency.
Latency measures the time elapsed between sending a request and receiving the response, directly indicating performance health from a user perspective.
Other metrics like throughput (queries per second) or request size measure volume and data payload, not time duration.

## Pregunta 237

Contexto: [topics:92](#topics-92)
A large healthcare provider's primary electronic health record (EHR) application runs on Compute Engine instances with a Cloud SQL for PostgreSQL database, all located in the us-west1 region. A new regulatory mandate requires you to implement and document a business continuity plan (BCP). This plan must ensure that the EHR application can be fully recovered and operational in a different geographical region with a recovery time objective (RTO) of two hours and a recovery point objective (RPO) of 15 minutes. You need to design a disaster recovery strategy that meets these strict BCP requirements. What should you do?

**A.** Deploy active managed instance groups (MIGs) in both us-west1 and us-east1, fronted by a global external HTTP(S) Load Balancer. For the database, use a cross-region read replica in us-east1, and rely on load balancer health checks to automatically fail over all traffic during an outage.

**B.** Use Terraform to define the application’s compute infrastructure. During a disaster, configure the Cloud SQL database in us-west1 to use a cross-region read replica in us-east1, build the environment in us-east1, and promote the replica.

**C.** Take daily snapshots of the Compute Engine disks and Cloud SQL database. Copy these snapshots to a Cloud Storage bucket in us-east1. During a disaster, manually restore the virtual machines (VMs) and database from the latest snapshots

**D.** Deploy a regional MIG in us-west1 for high availability, and rely on the Google Cloud SLA to ensure the region remains online.

**Respuesta de la fuente:** A

**Explicación:** Option A is the correct choice because it implements an active-passive or active-active architecture with automated failover capabilities, which is necessary to meet a strict RTO of two hours. The cross-region read replica for Cloud SQL supports an RPO of 15 minutes through near-real-time replication, whereas snapshot-based approaches (Option C) would likely exceed the RPO due to daily backup intervals and manual restoration delays. Options B and D fail to provide automated cross-region redundancy required for rapid recovery without significant manual intervention.

## Pregunta 238

Contexto: [topics:92](#topics-92)
A financial services company is decommissioning one of its on-premises data centers. As part of this initiative, the company needs to perform a one-time migration of 500 TB of historical transaction archives to a Cloud Storage bucket for long-term retention. The data center’s internet egress is 1 Gbps, which is shared with critical business operations. You must complete the secure data transfer within a 60-day window to meet the decommissioning deadline. What should you do?

**A.** Provision a Partner Interconnect connection with a 10 Gbps capacity to accelerate the data transfer, and then use Storage Transfer Service.

**B.** Write a script that uses the gcloud storage cp --parallel command to upload the data in chunks over the public internet during off-peak hours.

**C.** Use Storage Transfer Service to create an agent-based transfer job that moves the data from the on-premises file servers directly to the Cloud Storage bucket.

**D.** Order a Transfer Appliance, copy the data to the appliance using your high-speed local network, and ship it back to Google to upload the data into your Cloud Storage bucket.

**Respuesta de la fuente:** D

**Explicación:** For large-scale data transfers (typically >10 TB) where internet bandwidth is limited or shared with critical operations, a Transfer Appliance is the recommended solution.
It bypasses network constraints by using local high-speed connections for data loading and physical shipping to the cloud provider,
ensuring the transfer completes within the deadline without impacting business operations.

## Pregunta 239

Contexto: [topics:92](#topics-92)
Your company wants to optimize Google Cloud costs for their development and staging environments. These environments are workstations used by developers Monday through Friday, 9:00 AM to 6:00 PM local time. Currently, the environments run on a fleet of nl-standard-4 Compute Engine instances that operate 24/7, leading to a high monthly cost for resources that are idle more than 70% of the time. You need to implement a solution that significantly reduces the monthly cost of these non-production environments without impacting the development team's productivity during work hours. What should you do?

**A.** Schedule the virtual machines to start and stop to match your team’s work schedule.

**B.** Purchase three-year committed use discounts (CUDs) for the existing nl-standard-4 instances.

**C.** Upgrade all instances to the N2 machine series.

**D.** Re-architect the environments to run on a regional managed instance group (MIG) with autoscaling enabled.

**Respuesta de la fuente:** A

**Explicación:** Scheduling VMs to start and stop aligns resource usage strictly with business hours, eliminating costs for the ~70% of time the resources are idle.
This approach directly addresses the root cause of waste without requiring architectural changes or long-term financial commitments like CUDs.

## Pregunta 240

Contexto: [topics:92](#topics-92)
A retail company s most critical application is its online payment processing system. The business has a requirement that the system must be able to survive a complete zonal outage while minimizing cost. You need a design solution that can handle a zonal failure. What should you do?

**A.** Deploy the application in an active-active configuration using managed instance groups (MIGs) in two different regions, fronted by a global external HTTP(S) Load Balancer and backed by a multi-regional database like Spanner.

**B.** Deploy the application on a regional MIG to provide high availability across multiple zones in the primary region.

**C.** Configure the regional MIG to use only Spot VMs to aggressively minimize operational costs while maintaining high availability.

**D.** Deploy the application on Compute Engine instances across multiple regions, and rely on daily snapshots for recovery to achieve the lowest possible cost.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because a regional Managed Instance Group automatically distributes instances across multiple availability zones within a single region, ensuring survival during a zonal outage.

This approach minimizes cost by avoiding the complex infrastructure and cross-region data egress fees associated with multi-region active-active setups (Option A) while maintaining high availability through managed auto-scaling and self-healing.

## Pregunta 241

Contexto: [topics:92](#topics-92)
Your company is a global financial services provider that processes and analyzes a high volume of credit card transactions in real time for fraud detection. Your analytics team must run complex batch queries on the same transaction data for daily reporting. You need to design a data processing solution that can handle both real-time and batch processing of the transaction data while minimizing operational overhead and infrastructure management. What should you do?

**A.** Use Dataprep to ingest the transactions.

**B.** Use Dataflow to process the streaming data.

**C.** Use a Dataproc cluster for both the streaming and batch workloads.

**D.** Use BigQuery for the batch analytics reports.

**E.** Use Firestore to store and analyze the transaction data.

**Respuesta de la fuente:** B, D

**Explicación:** Dataflow is the optimal choice for real-time fraud detection because it provides a fully managed, serverless streaming processing capability that minimizes infrastructure overhead.
BigQuery is the correct selection for batch analytics as it offers a scalable, serverless data warehouse designed to handle complex SQL queries on large datasets without requiring manual management of compute resources.

## Pregunta 242

Contexto: [topics:92](#topics-92)
Your company uses a custom-built application running on a Compute Engine virtual machine (VM). This application processes real-time sales data and writes it to a zonal Persistent Disk. A recent internal audit requires that you implement a backup and recovery plan to protect against zonal failures. Your company has a strict policy that all backup data must be retained for at least 90 days and stored in a separate project with limited access. You need to implement a fully automated backup solution that meets these requirements with minimal operational overhead. What should you do?

**A.** Write a script to create daily backups of the Persistent Disk. Copy the backups to a different zone and apply a label to each snapshot to indicate the deletion date.

**B.** Use gcloud commands to create snapshots of the Persistent Disk. Store the snapshots in a regional Cloud Storage bucket and configure a lifecycle rule to delete objects older than 90 days.

**C.** Create a snapshot schedule to automatically create Persistent Disk snapshots and use a script to move and store them in a multi-regional Cloud Storage bucket.

**D.** Use the Backup and Disaster Recovery (DR) service to create a backup plan. Configure the backup plan to take daily snapshots and store them in a backup vault with a 90-day retention policy.

**Respuesta de la fuente:** D

**Explicación:** Google Cloud Backup and DR (Option D) is the managed service designed to automate backup plans with minimal operational overhead, directly satisfying the requirement for automation.

It supports storing backups in a separate project via Backup Vaults to meet the isolation and access control requirements specified by the audit.

The service natively enforces retention policies, such as the 90-day limit, without requiring custom scripts or manual lifecycle management.

## Pregunta 243

Contexto: [topics:92](#topics-92)
Your ecommerce web application includes many products with pictures and videos. You need to improve the application's page load speed and reduce the latency for customer requests. What should you do? (Choose two.)

**A.** Deploy your application to Cloud Run and enable concurrency.

**B.** Use Memorystore tor Redis.

**C.** Implement CDN with the application's external HTTPS load balancer.

**D.** Change the database from Bigtable to Spanner.

**E.** Deploy your application to a GKE Autopilot cluster instead of a regular GKE cluster.

**Respuesta de la fuente:** B, C

**Explicación:** Option B is correct because Memorystore for Redis provides in-memory caching, significantly reducing latency for frequently accessed dynamic data like product details and session information. Option C is correct because a CDN caches static assets such as images and videos at edge locations closer to the user, directly improving page load speeds and reducing bandwidth usage.

## Pregunta 244

Contexto: [topics:92](#topics-92)
You need to build and deploy a containerized web application to Google Cloud. The application is very write-heavy and requires a relational database as its data store. The application needs to be highly available in multiple cloud regions. You want to minimize operational overhead while following Google-recommended practices. What should you do?

**A.** Deploy the application to GKE clusters in multiple regions and expose the application endpoint with a regional load balancer. Use Cloud SQL as the database.

**B.** Deploy the application to Cloud Run in multiple regions behind a global HTTPS load balancer. Use Spanner as the database.

**C.** Deploy the application to a GKE standard cluster behind a global HTTPS load balancer. Use Firestore as the database with multi-region locations enabled.

**D.** Deploy the application to a GKE standard cluster with a global ingress to expose the application endpoint. Use Bigtable as the database.

**Respuesta de la fuente:** B

**Explicación:** Cloud Run provides a serverless container platform that minimizes operational overhead compared to managing GKE clusters.
A global HTTPS load balancer ensures high availability and low-latency access across multiple regions.
Google Cloud Spanner is the only fully managed relational database service offering strong consistency, horizontal scalability, and true multi-region high availability required for a write-heavy application.

## Pregunta 245

Contexto: [topics:92](#topics-92)
Your machine learning (ML) engineers use self-hosted Jupyter notebooks for tasks such as data preparation, model training, and fine-tuning. The operations team then deploys these models in various environments. You want to provide maximum flexibility for ML engineers, promote collaboration with a common toolset, and leverage Google Cloud's scalability, while following Google-recommended practices. What should you do?

**A.** Use AutoML for machine learning and Cloud Deploy for model deployment.

**B.** Use Colab Enterprise for machine learning and DevOps for model deployment.

**C.** Use Vertex AI for machine learning and machine learning operations (MLOps) for model deployment.

**D.** Use TensorFlow for machine learning and Cloud Deploy for model deployment.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 246

Contexto: [topics:92](#topics-92)
Your employer is a financial services company that recently acquired a popular fintech startup. The startup's core application is a monolithic Python application running on a managed instance group of Compute Engine virtual machines with a single, large PostgreSQL database. Your development team struggles with slow deployment cycles, and the monolithic design of the startup's core application makes it difficult to integrate new. ML-powered fraud detection models. You need a long-term strategy that improves developer agility and positions the company to leverage Google Cloud's advanced data and AI capabilities for future innovations. What should you do?

**A.** Deploy the ML fraud detection model to a Vertex AI endpoint. Create a REST API for the model and modify the monolithic Python application to call this endpoint for real-time fraud analysis.

**B.** Containerize the application, deploy it to Google Kubernetes Engine (GKE), and migrate the PostgreSQL database to Cloud SQL for PostgreSQL.

**C.** Propose a phased, event-driven migration to a microservices architecture. Use Pub/Sub for asynchronous communication and deploy the fraud models on Vertex AI endpoints.

**D.** Migrate the PostgreSQL database to Cloud SQL for PostgreSQL. Replicate the data into BigQuery using Datastream, and then train and deploy the fraud detection models directly within BigQuery using BigQuery ML.

**Respuesta de la fuente:** C

**Explicación:** Option C is the correct long-term strategy because breaking the monolith into microservices directly resolves slow deployment cycles and improves developer agility. Using Pub/Sub for event-driven communication decouples services, facilitating easier integration of new capabilities like ML models without impacting core performance. Deploying fraud detection on Vertex AI endpoints leverages Google Cloud's managed ML infrastructure for scalability and advanced AI innovation.

## Pregunta 247

Contexto: [topics:92](#topics-92)
You are deploying a new three-tier application to Compute Engine instances within a single Virtual Private Cloud (VPC). The architecture is segmented into three subnets: a web tier subnet, an application tier subnet, and a database tier subnet.
•	The web tier must only receive traffic from an external load balancer.
•	The application tier must only receive traffic from the web tier.
•	The database tier must only receive traffic from the application tier.

You need to enforce strict traffic flow control and want to follow Google-recommended practices. What should you do?

**A.** Configure Cloud NAT for each subnet, and create Google Cloud Armor policies to filter traffic between the tiers based on their IP address ranges.

**B.** Create a single VPC firewall rule with a high priority that allows ingress traffic on all ports between the IP address ranges of the three subnets.

**C.** Use a combination of network tags and service accounts. Apply a unique network tag and a dedicated service account to the instances in each tier. Then create specific firewall rules that allow ingress traffic based on the source service account or tag of the upstream tier.

**D.** Set up VPC Network Peering between the web tier and application tier subnets, and another peering connection between the application tier and database tier subnets.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 248

Contexto: [topics:92](#topics-92)
You are launching a data fabric service on Google Cloud in ten weeks and need to transfer 2 petabytes of historical data from your on-premises data center to Google Cloud. You want to securely transfer the data with low latency. What should you do?

**A.** Create a 1 Gbps VPN connection between your data center and Google Cloud. Use Storage Transfer Service to transfer the data.

**B.** Request Transfer Appliances from Google Cloud. Transfer the data using the appliances.

**C.** Create a 1 Gbps connection using direct interconnect. Use the Storage Transfer Service for on-premises data to transfer the data.

**D.** Export the data to portable disks and send the disks to Google Cloud for data import.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 249

Contexto: [topics:92](#topics-92)
You are designing the storage configuration for a critical Cloud Storage bucket. This bucket will store trade confirmation documents for a financial services company. These documents are immutable and serve as a legal record. Your design must meet two primary data protection requirements:
•	The system must allow for the rapid recovery of any document that is accidentally deleted or maliciously overwritten.
•	Once a document is written, it must be impossible for anyone, including administrators, to delete or modify it for seven years.

What should you do?

**A.** Grant only the roles/storage.objectCreator IAM role to the application's service account. Remove all other admin permissions from the bucket.

**B.** Use Storage Transfer Service to create a daily replication job that synchronizes the bucket to a separate archive bucket in another region.

**C.** Configure an Object Lifecycle Management rule on the bucket to ensure all objects are retained for at least seven years before they can be deleted.

**D.** Enable Object Versioning on the bucket. Additionally, configure the bucket with a Bucket Lock and a retention policy of seven years.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 250

Contexto: [topics:92](#topics-92)
Your company has hired an external auditing firm to perform a compliance audit. Your company’s governance policy requires that external auditors be managed in a single Google Group that is granted temporary, read-only access to a Cloud Storage bucket named audit-evidence-bucket. Access must be traceable to the individual auditor's identity and be active only for the duration of the audit engagement, which runs the entire month of October. You need a secure access control strategy that avoids administrative overhead and complies with your company's governance policy. What should you do?

**A.** Apply an IAM policy binding that grants the roles/storage.objectViewer role to the Google Group. Configure this binding with a time-based IAM Condition that automatically grants access from October 1 to November 1.

**B.** Create a service account, and grant it the roles/storage.objectViewer role on the bucket. Generate and share Signed URLs for each object in the bucket with an expiration date of November 1.

**C.** Use Cloud Scheduler to run a Cloud Run functions script that adds the IAM binding of roles/storage.objectViewer to the Google Group on October 1 and another that removes the IAM binding on November 1.

**D.** Use Workforce Identity Federation to map the auditors’ group to the Google Group. Bind the roles/storage.objectViewer role to this Google Group. Configure a 1-month session duration on the provider.

**Respuesta de la fuente:** A

**Explicación:** IAM Conditions provide a declarative way to enforce time-based access without manual intervention or custom code, satisfying the requirement for low administrative overhead.
By binding the role to the Google Group with a condition valid only for October, access automatically expires on November 1 while maintaining individual user traceability in audit logs.

## Pregunta 251

Contexto: [topics:92](#topics-92)
You are using a GitHub repository for your application’s source code. You want to set up an efficient and secure continuous deployment process to automatically build and deploy the application to Cloud Run whenever a pull request is merged. What should you do?

**A.** Create a GitHub webhook trigger in Cloud Build. Once a pull request is merged, trigger Cloud Build to build a container image and save it in Artifact Registry. Use Config Sync to deploy the application to Cloud Run.

**B.** Create a workflow using GitHub Actions to build and deploy the application to Cloud Run once a pull request is merged. The workflow will use a service account key checked in with your source code for deployment permission.

**C.** Create a GitHub Enterprise trigger in Cloud Build. Once a pull request is merged, trigger Cloud Build to build and deploy the application to Cloud Run. Save the deployment credential to Secret Manager.

**D.** Connect your repository using the Cloud Build GitHub app. Create a trigger in Cloud Build. Once a pull request is merged, trigger Cloud Build to build and deploy the application to Cloud Run.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because the Cloud Build GitHub app is the native, Google-recommended method for integrating GitHub with Cloud Build, ensuring a secure and managed connection without manual webhook configuration or secret management.

Using this integration allows Cloud Build triggers to automatically build container images and deploy them to Cloud Run upon pull request merge, adhering to best practices for continuous deployment security and efficiency.

## Pregunta 252

Contexto: [topics:92](#topics-92)
You are deploying a highly confidential data processing workload on Google Cloud. Your company’s compliance framework mandates that cryptographic keys used for encrypting data at rest must be generated and stored exclusively within a validated Hardware Security Module (HSM). You want to use a fully integrated Google Cloud managed service to handle the lifecycle and usage of these keys. What should you do?

**A.** Use Customer-Supplied Encryption Keys (CSEK) by providing your on-premises generated key with each API request.

**B.** Import your on-premises HSM key material into a Cloud KMS key with the SOFTWARE protection level.

**C.** Create a new key in Cloud Key Management Service (Cloud KMS) with the HSM protection level.

**D.** Configure Cloud External Key Manager (Cloud EKM) to connect to your on-premises HSM.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Cloud KMS supports keys with an HSM protection level, which ensures key material is generated and stored exclusively within FIPS 140-2 Level 3 validated hardware.
This satisfies the compliance mandate for HSM-based encryption while leveraging a fully managed Google Cloud service for lifecycle management, unlike on-premises or customer-supplied options.

## Pregunta 253

Contexto: [topics:92](#topics-92)
Your ecommerce platform uses a regional Cloud SQL for PostgreSQL database to store critical order information. The business requests a recovery time objective (RTO) of less than 10 minutes and a recovery point objective (RPO) of 2 minutes to ensure business continuity in the event of a full regional outage. You need to design a disaster recovery strategy for the Cloud SQL database that meets the business's strict RTO and RPO requirements. Your design must avoid operational complexity. What should you do?

**A.** Schedule hourly automated backups of the Cloud SQL instance to a multi-regional Cloud Storage bucket. In a disaster, restore the latest backup to a new instance in a different region.

**B.** Use Database Migration Service to continuously replicate the database to another instance in a different region. In a disaster, redirect application traffic to the replica.

**C.** Configure the Cloud SQL instance with a cross-region read replica. In a disaster, promote the read replica to a standalone, primary instance.

**D.** Configure the primary instance for high availability (HA). In the event of a regional outage, trigger a failover to the standby instance.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 254

Contexto: [topics:92](#topics-92)
You are designing a central, automated infrastructure deployment process for your organization using Terraform and Cloud Build. The security team prohibits the use of long-lived, static service account keys in any CI/CD pipeline. Additionally, while developers can propose infrastructure changes for peer review, they must not have permissions to directly apply changes in the production project. You need to design a secure and automated workflow for applying Terraform changes that meets the security team's requirements and ensures proper governance. What should you do?

**A.** Configure the Cloud Build pipeline to use service account impersonation. Set up a trigger that automatically runs terraform apply when a pull request is merged.

**B.** Use service account impersonation in Cloud Build. Configure the pipeline to run terraform plan on pull requests, and require manual approval before running terraform apply.

**C.** Configure the pipeline to only run terraform plan. After a pull request is approved, have an authorized developer run terraform apply from a secured workstation.

**D.** Create a privileged service account and store its JSON key in Secret Manager. Configure the Cloud Build pipeline to fetch this key during execution to authenticate Terraform.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it uses service account impersonation to generate short-lived tokens, eliminating the need for prohibited static keys. It enforces governance by requiring manual approval before applying changes to production, ensuring human oversight while maintaining automation.

## Pregunta 255

Contexto: [topics:92](#topics-92)
You need to build a continuous delivery pipeline for a containerized application in Google Cloud. You want to run all your tests in the pipeline to improve your application’s quality. What should you do?

**A.** 1. After the developers push the code to a central repository, trigger Cloud Build to run unit tests. If all unit tests are successful, build the application container and push it to a central registry.
2. Trigger Cloud Build to deploy the container to a testing environment and run integration tests and acceptance tests.
3. If all tests are successful, deploy the application to the production environment and run the smoke tests.

**B.** 1. After the developers push the code to a central repository, trigger Cloud Build to build the application container. Then run unit tests.
2. If unit tests are successful, deploy the container to a testing environment and run integration tests.
3. If the integration tests are successful, deploy the container to a production environment and run acceptance tests.

**C.** 1. Automatically run unit tests in a local environment once the code is changed. If all tests are successful, build a container.
2. Trigger Cloud Build to deploy the container to a testing environment, and run integration tests and acceptance tests.
3. If all tests are successful, tag the code as production ready. Trigger Cloud Build to build and deploy the container to the production environment.

**D.** 1. Run unit tests in the developer's local environment before committing and pushing the code to a central repository.
2. After the code is pushed, trigger Cloud Build to build the application container and deploy the container to a testing environment, and run integration tests.
3. If the integration tests are successful, deploy the container to your production environment and run acceptance tests.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 256

Contexto: [topics:92](#topics-92)
Your organization is a cloud-native shop which uses Google Kubernetes Engine (GKE) extensively to run its containerized workloads. You want to embrace infrastructure as code (IaC) principles to streamline and automate the provisioning, configuration, and management of Google Cloud resources and minimize operational cost. What should you do?

**A.** Install Config Sync, and use YAML manifests in your GitHub repository to automate the provisioning and management of Google Cloud resources.

**B.** Install Config Connector, and use Python to define the desired state of your Google Cloud resources. Apply the Python scripts to provision and manage the resources.

**C.** Set up Config Controller, and use YAML manifests to define the desired state of your Google Cloud resources. Apply these YAML configurations to provision and manage the resources.

**D.** Develop a custom Kubernetes operator within your GKE cluster to automate the execution of your IaC scripts for provisioning and managing Google Cloud resources.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 257

Contexto: [topics:92](#topics-92)
A global media company is launching a new web application. The application backend is hosted on Compute Engine in us-central1 and serves both static assets (images, CSS, and JavaScript) and dynamic, user-specific content from a Cloud SQL database in the same region. Early user feedback from Europe and Asia indicates significant page load delays due to slow loading static content. You need to design a solution that minimizes latency for all global users accessing the static content. What should you do? (Choose two.)

**A.** Use a regional external Network Load Balancer in us-central1 to better distribute the incoming global traffic.

**B.** Enable Cloud CDN for the backend service that serves the static assets, and configure it as part of a global external HTTP(S) Load Balancer.

**C.** Vertically scale the Compute Engine instances in us-central1 by increasing their machine size.

**D.** Deploy the application frontend service to Compute Engine managed instance groups in regions in Europe and Asia. Use a global external HTTP(S) Load Balancer to route user traffic to the nearest region.

**E.** Create Cloud SQL read replicas in regions in Europe and Asia, and direct all database read traffic from those continents to their local replica.

**Respuesta de la fuente:** B, D

**Explicación:** No conservada en esta captura.

## Pregunta 258

Contexto: [topics:92](#topics-92)
You are developing a deep learning model that requires high-performance access to large volumes of media data currently stored in Cloud Storage. Model training will be executed on multiple VM instances with GPUs attached, but your application must interact with the data as if it were on the local file system. You need to minimize complexity and cost. What should you do?

**A.** Copy the data from Cloud Storage to Filestore, and then mount the Filestore volume as a local file system on your VM instances.

**B.** Create a shared persistent disk, attach the disk to your VM instances, and load data from the Cloud Storage bucket.

**C.** Use the gcsfuse command line tool to mount the Cloud Storage bucket as a local file system, and perform read/write operations in your bucket using standard file system semantics.

**D.** Use the gsutil command line tool to download the data to your VM instances.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 259

Contexto: [topics:92](#topics-92)
Your company is expanding its AI-powered operations nationwide and has chosen accelerator-based compute for the AI workloads. The batch image processing workloads are not time-sensitive and can tolerate interruptions. You need to rapidly deploy cost-effective accelerator nodes for these batch tasks, ensuring rapid deployment and data persistence when necessary. What should you do?

**A.** Deploy standard VMs with configured accelerators and attached persistent disks.

**B.** Deploy spot VMs with attached persistent disks and implement checkpoint mechanisms.

**C.** Deploy spot VMs with local SSD to reduce time for bursty workloads

**D.** Deploy Cloud Run functions with ephemeral local SSD.

**Respuesta de la fuente:** B

**Explicación:** Spot VMs provide significant cost savings for non-time-sensitive, interruption-tolerant batch workloads like AI image processing.
To ensure data persistence despite potential preemption, Persistent Disks must be used to store state and checkpoints, allowing the workload to resume from where it left off.

## Pregunta 260

Contexto: [topics:92](#topics-92)
A large, multinational corporation is migrating to Google Cloud. The company has several distinct business units: Finance, Marketing, and Research and Development (R&D). The central security team has mandated governance requirements for each business unit:
•	Finance: Must be restricted to deploying resources only in specific, compliant regions (us-central1 and europe-west2). Access to their projects must be tightly controlled by a dedicated finance-admins group.
•	Marketing: Needs separate environments for production and development, with different teams managing each environment.
•	R&D: Requires maximum flexibility to experiment with new services but must be completely isolated to prevent any impact on production systems.
•	Global Auditing: A central compliance team requires read-only access to view all resources across the entire company for auditing purposes.

You need to design a resource hierarchy that enforces these security policies at scale according to the Google Cloud Well-Architected Framework while providing the correct level of autonomy for each business unit. What should you do?

**A.** Create a folder for each department under the root Organization node. Apply the resource location Organization Policy on the Finance folder. Within the Marketing folder, create separate projects for mktg-prod and mktg-dev. Grant the compliance team the roles/viewer role at the Organization level.

**B.** Place all projects directly under the Organization node. Use network tags and service accounts to enforce security boundaries between the different department workloads. Apply the resource location Organization Policy on the Finance project.

**C.** Create separate Google Cloud Organizations for each department (Finance, Marketing, and R&D). Grant the compliance team the roles/viewer role for each organization.

**D.** Create a single project for each department. Apply the resource location policy directly to the Finance project. Grant the compliance team the roles/browser role on each project individually.

**Respuesta de la fuente:** A

**Explicación:** Folders are the correct resource hierarchy level to group projects by department and apply organizational policies, such as restricting Finance to specific regions.
Granting the roles/viewer role at the Organization level provides the compliance team with read-only access across all descendant resources efficiently.
This structure supports Marketing's need for separate environment projects within a folder and R&D's isolation while maintaining centralized governance.

## Pregunta 261

Contexto: [topics:92](#topics-92)
Your organization is going to migrate applications to Kubernetes and use managed cloud services to deploy applications. Your team is new to Kubernetes and wants to quickly onboard engineers. You want to reduce operational overhead, so the engineering team can focus on developing consumer requirements instead of maintaining the infrastructure. What should you do?

**A.** Package your application into a Docker image, and deploy it to Kubernetes on Compute Engine.

**B.** Leverage Cloud Build to create a container image, and deploy it automatically to Kubernetes on Compute Engine.

**C.** Assess application and dependencies for containerization Develop a migration strategy for deployment to GKE in Standard mode.

**D.** Assess application and dependencies for containerization. Develop a migration strategy for deployment to GKE in Autopilot mode.

**Respuesta de la fuente:** D

**Explicación:** The key requirement is reducing operational overhead for a team new to Kubernetes. GKE Autopilot mode abstracts away cluster infrastructure management, including node provisioning, scaling, and patching, allowing engineers to focus solely on application deployment. This directly addresses the goal of minimizing maintenance tasks compared to Standard mode or manual deployments on Compute Engine.

## Pregunta 262

Contexto: [topics:92](#topics-92)
Your company runs a critical, revenue-generating ecommerce application that is served by a regional managed instance group (MIG) behind an external HTTP(S) Load Balancer. The operations team is currently overwhelmed with low-priority notifications and is starting to ignore alerts. Your team's service level objective (SLO) is to maintain 99.9% availability, which is measured by the ratio of successful requests (2xx status codes) to total requests. You want to minimize noise from non-critical events and ensure that the team is only notified of issues that are actionable and threaten the SLO. What should you do?

**A.** Focus on cause-based alerts, creating alerting policies with thresholds for the Compute Engine instances, including CPU utilization, memory usage, disk I/O, and network traffic.

**B.** Create log-based alerts for only the WARN and ERROR log entries generated by the application to ensure that no potential issue is missed.

**C.** Implement an error budget policy based on the availability of the SLO. Create a "page” alert that triggers only when the rate of burn of the error budget predicts a full exhaustion within the next 24 hours.

**D.** Configure alerts based on predictive metrics. Use the instance count of the MIG as the primary metric to trigger an alert.

**Respuesta de la fuente:** C

**Explicación:** Implementing burn-rate alerting on the error budget directly ties alerts to the SLO, ensuring notifications are only generated when availability is genuinely at risk. This approach minimizes noise by ignoring transient issues that fall within the allowed error budget and focusing solely on events threatening the 99.9% availability goal.

## Pregunta 263

Contexto: [topics:92](#topics-92)
You manage a highly distributed, hybrid- and multi-cloud IT environment, and your developers rely heavily on Prometheus for their workflows. You need a cloud-based, highly scalable, low-maintenance enterprise solution that supports Prometheus Query Language (PromQL) queries, quick metric viewing, and efficient issue diagnosis. What should you do?

**A.** Deploy a Prometheus operator in your existing Kubernetes and Serverless setup across multi-cloud environments.

**B.** Set up Cloud Monitoring as a single pane of glass across multi-cloud environments.

**C.** Enable Google Cloud Managed Service for Prometheus to monitor and alert on your workloads at scale.

**D.** Build a SaaS-based, Prometheus-compatible solution to display metrics for each cloud in a customizable way.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google Cloud Managed Service for Prometheus is a fully managed, scalable solution that natively supports PromQL and integrates seamlessly with GKE and multi-cloud environments via OpenTelemetry or remote write.

It eliminates the maintenance burden of self-hosted Prometheus (Option A) while providing the specific Prometheus compatibility required by developers, unlike generic monitoring tools (Option B) or custom builds (Option D).

## Pregunta 264

Contexto: [topics:92](#topics-92)
Your organization uses Google Kubernetes Engine (GKE) and Amazon Elastic Kubernetes Service (EKS) to manage a complex Kubernetes environment across multiple cloud providers. You need to deploy a solution that streamlines configuration management, enforces security policies, and ensures consistent application deployment across all of the environments. You want to follow Google-recommended practices. What should you do?

**A.** Leverage Argo CD for GitOps-based continuous delivery and Open Policy Agent (OPA) for policy enforcement, and develop a controller for multi-cluster configuration management.

**B.** Deploy Crossplane for managing cloud resources as Kubernetes objects, FluxCD for GitOps-based configuration synchronization, and Kyverno for policy enforcement.

**C.** Deploy Kustomize for configuration customization, Config Sync with multiple Git repositories, and a script to enforce security policies.

**D.** Utilize Config Sync as part of GKE to synchronize configurations from a centralized repository, and utilize Policy Controller to enforce policies using OPA Gatekeeper.

**Respuesta de la fuente:** D

**Explicación:** The question explicitly asks to follow Google-recommended practices for a multi-cloud Kubernetes environment. Config Sync (part of Anthos/GKE Enterprise) synchronizes configurations from Git to registered clusters across both GCP and AWS, ensuring consistency.
Policy Controller enforces security policies using OPA Gatekeeper, which is the standard Google-recommended tool for declarative policy enforcement in this ecosystem.

## Pregunta 265

Contexto: [topics:92](#topics-92)
Your company is rapidly deploying containerized microservices on Google Kubernetes Engine (GKE) using a robust CI/CD pipeline. Security is a top priority, and you need to implement a comprehensive and efficient strategy to prevent container image vulnerabilities from reaching your GKE production environment. What should you do? (Choose two.)

**A.** Review the security reports generated by Artifact Analysis for each container image before deployment to GKE.

**B.** Incorporate vulnerability scanning before building container images, and use Google-maintained base images for your container deployments.

**C.** Enable Artifact Analysis for the container images, and stop deployment if critical vulnerabilities are found.

**D.** Use a custom security policy within your container image that restricts access to specific network ports and resources.

**E.** Enable Shielded GKE Nodes on the production cluster to automatically block the execution of container images with known vulnerabilities.

**Respuesta de la fuente:** B, C

**Explicación:** Artifact Analysis (now Binary Authorization integrated with Container Scanning) automatically scans images for vulnerabilities and can enforce admission control policies to block deployment of images containing critical CVEs, fulfilling the requirement to prevent vulnerable images from reaching production. Additionally, using Google-maintained base images is a foundational security best practice that reduces the attack surface by starting with pre-hardened, regularly patched layers, complementing the automated scanning strategy.

Option A is inefficient because manual review does not scale for rapid CI/CD pipelines. Option D addresses runtime configuration rather than image vulnerability prevention. Option E (Shielded GKE Nodes) protects the underlying node infrastructure from bootkits and unauthorized access, but it does not scan or block container images based on their CVE content.

## Pregunta 266

Contexto: [topics:92](#topics-92)
Your organization is implementing a new cloud-native application on Google Cloud and needs to ensure compliance with the ISO/IEC 27001 framework. You want to leverage Google Cloud’s security reports and documentation to support your ISO/IEC 27001 audit process. What should you do?

**A.** Engage an independent auditor to conduct an ISO/IEC 27001 audit of your organization's Google Cloud implementation.

**B.** Download the ISO/IEC 27001 report for Google Cloud through internet search.

**C.** Review the Compliance Reports Manager for information about ISO/IEC 27001 compliance and related documentation on obtaining reports through your Google Cloud account.

**D.** Utilize the Cloud Audit Logs service for accessing and requesting the ISO/IEC 27001 reports.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because the Compliance Reports Manager in the Google Cloud Console serves as the centralized repository for all compliance documentation, including ISO/IEC 27001 reports.
It provides direct, self-service access to third-party audit reports and attestation letters required for customer audits.
Options A, B, and D are incorrect because engaging an auditor is not a documentation retrieval method, internet searches do not guarantee official current reports, and Cloud Audit Logs track resource activity rather than host compliance certificates.

## Pregunta 267

Contexto: [topics:92](#topics-92)
You are monitoring Google Kubernetes Engine (GKE) clusters in a Cloud Monitoring workspace. As a Site Reliability Engineer (SRE), you need to triage incidents quickly. What should you do?

**A.** 1. Navigate the predefined dashboards in the Cloud Monitoring workspace.
2. Add metrics and create alert policies.

**B.** 1. Write a shell script that gathers metrics from GKE nodes, and publish these metrics to a Pub/Sub topic.
2. Export the data to BigQuery. and make a Data Studio dashboard.

**C.** 1. Create a custom dashboard in the Cloud Monitoring workspace for each incident.
2. Add metrics and create alert policies.

**D.** 1. Navigate the predefined dashboards in the Cloud Monitoring workspace.
2. Create custom metrics and install alerting software on a Compute Engine instance.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Monitoring provides predefined dashboards for GKE that offer immediate visibility into golden signals, enabling rapid triage without the overhead of building custom views during an incident.
Alert policies created within the same workspace ensure automated detection and seamless integration with these dashboards for efficient incident management.

## Pregunta 268

Contexto: [topics:92](#topics-92)
Company overview -

EHR Healthcare is a leading provider of electronic health record software to the medical industry. EHR Healthcare provides their software as a service to multi-national medical offices, hospitals, and insurance providers.

Solution concept -

Due to rapid changes in the healthcare and insurance industry, EHR Healthcare's business has been growing exponentially year over year. They need to be able to scale their environment, adapt their disaster recovery plan, and roll out new continuous deployment capabilities to update their software at a fast pace. Google Cloud has been chosen to replace their current colocation facilities.

Existing technical environment -

EHR's software is currently hosted in multiple colocation facilities. The lease on one of the data centers is about to expire.

Customer-facing applications are web-based, and many have recently been containerized to run on a group of Kubernetes clusters. Data is stored in a mixture of relational and NoSQL databases (MySQL, MS SQL Server, Redis, and MongoDB).

EHR is hosting several legacy file- and API-based integrations with insurance providers on-premises. These systems are scheduled to be replaced over the next several years. There is no plan to upgrade or move these systems at the current time.

Users are managed via Microsoft Active Directory. Monitoring is currently being done via various open source tools. Alerts are sent via email and are often ignored.

Business requirements -

•	On-board new insurance providers as quickly as possible.
•	Provide a minimum 99.9% availability for all customer-facing systems.
•	Provide centralized visibility and proactive action on system performance and usage.
•	Increase ability to provide insights into healthcare trends.
•	Reduce latency to all customers.
•	Maintain regulatory compliance.
•	Decrease infrastructure administration costs.
•	Make predictions and generate reports on industry trends based on provider data.

Technical requirements -

•	Maintain legacy interfaces to insurance providers with connectivity to both on-premises systems and cloud providers.
•	Provide a consistent way to manage customer-facing applications that are container-based.
•	Provide a secure and high-performance connection between on-premises systems and Google Cloud.
•	Provide consistent logging, log retention, monitoring, and alerting capabilities.
•	Maintain and manage multiple container-based environments.
•	Dynamically scale and provision new environments.
•	Create interfaces to ingest and process data from new providers.

Executive statement -

Our on-premises strategy has worked for years but has required a major investment of time and money in training our team on distinctly different systems, managing similar but separate environments, and responding to outages. Many of these outages have been a result of misconfigured systems, inadequate capacity to manage spikes in traffic, and inconsistent monitoring practices. We want to use Google Cloud to leverage a scalable, resilient platform that can span multiple environments seamlessly and provide a consistent and stable user experience that positions us for future growth.

For this question, refer to the EHR Healthcare case study. Due to the growing partnerships with new insurance providers, EHR Healthcare needs a solution to streamline the creation of secure Google Cloud environments for each provider. You need to automate the provisioning and management of these secure environments, ensure that each provider's environment is consistently configured and managed, and provide a consistent user experience across all providers. What should you do?

**A.** Develop custom Cloud Run functions to automate the provisioning of new Google Cloud environments. Incorporate security measures and pre-defined configurations within the functions to ensure consistency and protection.

**B.** Provision and configure each new environment and resources through the Google Cloud console.

**C.** Leverage Google Kubernetes Engine (GKE) for workload deployments. Use cluster autoscaling and node auto-provisioning features to scale the cluster based on resource usage.

**D.** Utilize Infrastructure as Code (IaC) tools, such as Terraform, to define and manage infrastructure configurations.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 269

Contexto: [topics:92](#topics-92)
Company overview -

EHR Healthcare is a leading provider of electronic health record software to the medical industry. EHR Healthcare provides their software as a service to multi-national medical offices, hospitals, and insurance providers.

Solution concept -

Due to rapid changes in the healthcare and insurance industry, EHR Healthcare's business has been growing exponentially year over year. They need to be able to scale their environment, adapt their disaster recovery plan, and roll out new continuous deployment capabilities to update their software at a fast pace. Google Cloud has been chosen to replace their current colocation facilities.

Existing technical environment -

EHR's software is currently hosted in multiple colocation facilities. The lease on one of the data centers is about to expire.

Customer-facing applications are web-based, and many have recently been containerized to run on a group of Kubernetes clusters. Data is stored in a mixture of relational and NoSQL databases (MySQL, MS SQL Server, Redis, and MongoDB).

EHR is hosting several legacy file- and API-based integrations with insurance providers on-premises. These systems are scheduled to be replaced over the next several years. There is no plan to upgrade or move these systems at the current time.

Users are managed via Microsoft Active Directory. Monitoring is currently being done via various open source tools. Alerts are sent via email and are often ignored.

Business requirements -

•	On-board new insurance providers as quickly as possible.
•	Provide a minimum 99.9% availability for all customer-facing systems.
•	Provide centralized visibility and proactive action on system performance and usage.
•	Increase ability to provide insights into healthcare trends.
•	Reduce latency to all customers.
•	Maintain regulatory compliance.
•	Decrease infrastructure administration costs.
•	Make predictions and generate reports on industry trends based on provider data.

Technical requirements -

•	Maintain legacy interfaces to insurance providers with connectivity to both on-premises systems and cloud providers.
•	Provide a consistent way to manage customer-facing applications that are container-based.
•	Provide a secure and high-performance connection between on-premises systems and Google Cloud.
•	Provide consistent logging, log retention, monitoring, and alerting capabilities.
•	Maintain and manage multiple container-based environments.
•	Dynamically scale and provision new environments.
•	Create interfaces to ingest and process data from new providers.

Executive statement -

Our on-premises strategy has worked for years but has required a major investment of time and money in training our team on distinctly different systems, managing similar but separate environments, and responding to outages. Many of these outages have been a result of misconfigured systems, inadequate capacity to manage spikes in traffic, and inconsistent monitoring practices. We want to use Google Cloud to leverage a scalable, resilient platform that can span multiple environments seamlessly and provide a consistent and stable user experience that positions us for future growth.

For this question, refer to the EHR Healthcare case study. EHR Healthcare recently experienced unauthorized access of their Kubernetes-based applications due to compromised credentials, resulting in a security breach. You need to secure access between their on-premises systems and the Google Kubernetes Engine (GKE) environment, while maintaining regulatory compliance and integrating with EHR's existing identity provider. What should you do?

**A.** Deploy an OpenID Connect (OIDC) identity provider in GKE, and integrate it with Active Directory for centralized authentication and fine-grained authorization controls.

**B.** Establish a secure VPN tunnel between the on-premises network and the GKE VPC, and implement strict firewall rules to restrict access based on source IP addresses and ports.

**C.** Configure Workload Identity Federation with Active Directory to enable authentication and authorization for applications across both Kubernetes environments.

**D.** Create a service account with minimal permissions for each application running in GKE, and distribute the credentials securely to the on-premises systems.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 270

Contexto: [topics:92](#topics-92)
Company overview -

EHR Healthcare is a leading provider of electronic health record software to the medical industry. EHR Healthcare provides their software as a service to multi-national medical offices, hospitals, and insurance providers.

Solution concept -

Due to rapid changes in the healthcare and insurance industry, EHR Healthcare's business has been growing exponentially year over year. They need to be able to scale their environment, adapt their disaster recovery plan, and roll out new continuous deployment capabilities to update their software at a fast pace. Google Cloud has been chosen to replace their current colocation facilities.

Existing technical environment -

EHR's software is currently hosted in multiple colocation facilities. The lease on one of the data centers is about to expire.

Customer-facing applications are web-based, and many have recently been containerized to run on a group of Kubernetes clusters. Data is stored in a mixture of relational and NoSQL databases (MySQL, MS SQL Server, Redis, and MongoDB).

EHR is hosting several legacy file- and API-based integrations with insurance providers on-premises. These systems are scheduled to be replaced over the next several years. There is no plan to upgrade or move these systems at the current time.

Users are managed via Microsoft Active Directory. Monitoring is currently being done via various open source tools. Alerts are sent via email and are often ignored.

Business requirements -

•	On-board new insurance providers as quickly as possible.
•	Provide a minimum 99.9% availability for all customer-facing systems.
•	Provide centralized visibility and proactive action on system performance and usage.
•	Increase ability to provide insights into healthcare trends.
•	Reduce latency to all customers.
•	Maintain regulatory compliance.
•	Decrease infrastructure administration costs.
•	Make predictions and generate reports on industry trends based on provider data.

Technical requirements -

•	Maintain legacy interfaces to insurance providers with connectivity to both on-premises systems and cloud providers.
•	Provide a consistent way to manage customer-facing applications that are container-based.
•	Provide a secure and high-performance connection between on-premises systems and Google Cloud.
•	Provide consistent logging, log retention, monitoring, and alerting capabilities.
•	Maintain and manage multiple container-based environments.
•	Dynamically scale and provision new environments.
•	Create interfaces to ingest and process data from new providers.

Executive statement -

Our on-premises strategy has worked for years but has required a major investment of time and money in training our team on distinctly different systems, managing similar but separate environments, and responding to outages. Many of these outages have been a result of misconfigured systems, inadequate capacity to manage spikes in traffic, and inconsistent monitoring practices. We want to use Google Cloud to leverage a scalable, resilient platform that can span multiple environments seamlessly and provide a consistent and stable user experience that positions us for future growth.

For this question, refer to the EHR Healthcare case study. Due to the growing infrastructure administration costs, you want to migrate the legacy relational database systems to Google Cloud. You need to maintain the strict uptime requirements with limited in-house expertise. What should you do?

**A.** Use the Database Migration Service (DMS) to migrate the MySQL databases to Cloud SQL.

**B.** Backup and restore the databases to Cloud SQL instances with minimal changes.

**C.** Leverage AlloyDB to migrate the on-premises databases.

**D.** Set up database replication to Cloud SQL instances using native database tools, and incrementally switch applications to use the replicas.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 271

Contexto: [topics:92](#topics-92)
You are setting up a new regional environment for your business needs. You plan to migrate more than 2 TB of data from the us-central1 region to the asia-southeast1 region. The transfer should occur as quickly as possible. If the transfer is interrupted, the operation must resume where it left off and copy only new or modified objects. What should you do?

**A.** Use the gcloud storage cp command to copy the objects. Be careful to manage potential naming conflicts to ensure data integrity.

**B.** Utilize Storage Transfer Service (STS) to migrate objects to the destination bucket in the target region. Once the transfer is complete, delete the original source bucket objects.

**C.** Use the gcloud storage rsync --recursive command to replicate the source bucket to a new target bucket in the us-west1 region.

**D.** Leverage Cloud Composer to orchestrate a data pipeline that copies objects from the source bucket to the destination bucket.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 272

Contexto: [topics:92](#topics-92)
You are migrating a large, on-premises application to Google Cloud. The application consists of several interconnected virtual machines. You want to create a detailed migration plan to ensure a smooth migration with minimal effort. You need to understand the existing environment, identify dependencies, and estimate the total cost of ownership (TCO) in the cloud. What should you do?

**A.** Write a custom script to query the vSphere API for virtual machine information and then import it into BigQuery for analysis.

**B.** Use the Google Cloud Migration Center to perform an automated discovery and assessment of the on-premises environment.

**C.** Use Config Connector to declare the desired state of your Google Cloud resources in Kubernetes-style manifests.

**D.** Use the Google Cloud pricing calculator to input the specifications of your on-premises servers and receive a TCO estimate.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 273

Contexto: [topics:92](#topics-92)
You created a Cloud Monitoring dashboard for your dev environment to view real-time application metrics. The Ops team wants a similar dashboard to monitor the production environment. You want to minimize time and effort as you assist the Ops team with their dashboard request. What should you do?

**A.** Export your dashboard to a JSON file and share it with the Ops team.

**B.** Grant viewer permission to the Ops team in your project so they can recreate the charts in their dashboard from the console.

**C.** Create a shared document and list every step you performed to create the dashboard. The Ops team can use the document to build their own dashboard.

**D.** Share your dashboard and send the shared dashboard URL to the Ops team.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 274

Contexto: [topics:92](#topics-92)
You are migrating a critical, on-premises, three-tier ecommerce application to Google Cloud. The application has tightly coupled dependencies between its web, application, and database tiers. The business has strict performance and availability requirements and is concerned about the risks associated with an "all-at-once" migration. You want to follow Google-recommended practices to create a migration plan that systematically addresses application dependencies and validates post-migration performance before the final production cutover. What should you do?

**A.** Prioritize the establishment of a high-bandwidth, low-latency Cloud Interconnect connection, and then plan to migrate the database servers first.

**B.** Plan a "lift and shift" migration for all application tiers to be executed simultaneously over a single weekend to minimize downtime.

**C.** Redesign the application to be cloud-native using microservices before migration to eliminate dependencies and simplify workload testing.

**D.** Use dependency mapping to group application components into waves, create a phased migration plan, and incorporate performance testing for each wave.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 275

Contexto: [topics:92](#topics-92)
You are designing the architecture for a stateless, public-facing, containerized web application. The marketing department uses this web application to run unpredictable flash sales that cause sudden, massive spikes in user traffic. The application is a critical revenue driver and must always be available and responsive to users. Your design must automatically handle high traffic fluctuations and allow for new application versions to be deployed with zero downtime and a safe, fast rollback capability. What should you do?

**A.** Deploy the application to a Google Kubernetes Engine (GKE) cluster. Use the Recreate deployment strategy to roll out new application versions.

**B.** Deploy the application to a single, large Compute Engine instance and use a startup script to pull and run the latest container image on boot.

**C.** Deploy the application as a Cloud Run service. Configure request-based auto-scaling and use gradual rollouts by splitting traffic between revisions.

**D.** Deploy the application to a regional Managed Instance Group (MIG). Configure a CPU-based autoscaling policy and use the MIG's rolling update feature for deployments.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 276

Contexto: [topics:92](#topics-92)
You are designing the observability strategy for a new microservices application running on Google Kubernetes Engine (GKE). The application consists of multiple services (e.g., frontend, orders, payments). During load testing, you observe an error in the frontend service's logs, but you cannot find the corresponding logs in the downstream services to investigate the root cause because the logs are not correlated. You need to implement a solution that allows you to follow a single user request across all microservices involved in the transaction. The solution must not require developers to manually add correlation logic to their application code. What should you do?

**A.** Implement Cloud Trace by ensuring the traceparent header is propagated between microservice calls to link logs to a single trace.

**B.** Configure all containers to write logs to STDOUT/STDERR, and then filter logs by pod name and timestamp in the Logs Explorer.

**C.** Require developers to generate a unique correlation-id at the frontend, and manually add it as a field to every log message in all services.

**D.** Create custom metrics in Cloud Monitoring for error counts in each service and correlate incident spikes using a shared dashboard.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 277

Contexto: [topics:92](#topics-92)
Your company is running AI/ML workloads on graphics processing units (GPUs) within Google Kubernetes Engine (GKE). These workloads are deployed across production and development projects, with the production environment being business critical and operating 24/7. You need to ensure that the GPU capacity is always available during scaling events, without being limited by overall GPU availability. You also need the ability to shift unused GPU capacity from production to development projects as needed. You want to follow Google-recommended practices. What should you do?

**A.** Create a reservation in the production project, and then transfer the reservation to the development project when needed.

**B.** Create a shared reservation in the production project, and then add the development project as a consumer project to move capacity when needed.

**C.** Create an owner project with shared reservations, and then configure the production project and development project as consumer projects to consume capacity.

**D.** Create a reservation in the production project, and then create a separate reservation in the development project to secure capacity.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 278

Contexto: [topics:92](#topics-92)
You are responsible for the architecture of a critical ecommerce application. The application's web frontends run on Compute Engine instances deployed across multiple zones within a single region. The architecture must be highly available and self-healing. If a zone becomes unavailable, the system must automatically recreate the lost capacity in the available zones. To maximize efficiency, you need to ensure that all provisioned compute resources actively serve traffic during normal operations, and user traffic is automatically and seamlessly directed away from any failed instance or zone. What should you do?

**A.** Configure a regional external Application Load Balancer with a primary regional managed instance group (MIG) as its backend service, and configure a second regional MIG as a failover backend.

**B.** Create a single regional unmanaged instance group spanning all three zones. Place a regional external Application Load Balancer in front of the group, and configure its backend service with a health check.

**C.** Create a single regional managed instance group (MIG) configured to span all three zones. Place a regional external Application Load Balancer in front of the MIG, and configure its backend service with a health check.

**D.** Create three separate zonal managed instance groups (MIGs), and use Cloud DNS with weighted routing to distribute traffic across the public IP address of an instance in each MIG.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 279

Contexto: [topics:92](#topics-92)
You are designing the access control strategy for a new system that will store highly sensitive financial reports in a series of Cloud Storage buckets. Each bucket holds a specific type of sensitive data. Your company uses Google Workspace, and all employee roles are managed through Google Groups. The design must allow members of these groups to access only the reports they are authorized to see. The company's governance policy has two additional, critical requirements:

•	All access must be directly tied to an employee's corporate identity for clear audit trails.
•	The access model must be simple to operate and scalable.

What should you do?

**A.** Grant the IAM role roles/storage.objectAdmin to all authorized Google Groups to simplify permission management.

**B.** Enable uniform bucket-level access on the buckets, and grant predefined Storage IAM roles to the Google Groups.

**C.** Generate and distribute time-limited signed URLs to grant users temporary, per-object access.

**D.** Maintain fine-grained access control, and use default object ACLs to grant the required permissions to the Google Groups.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 280

Contexto: [topics:92](#topics-92)
A large enterprise is building a file processing pipeline on Google Cloud. The pipeline ingests the raw files, which are then accessed by a fleet of hundreds of Compute Engine virtual machines (VMs) in a single region for parallel processing. These VMs need concurrent, low-latency read and write access to a shared file system. You need to implement a storage solution that delivers the highest possible throughput to minimize the overall processing time. What should you do?

**A.** Use a multi-region Cloud Storage bucket to store the files.

**B.** Create a Filestore Enterprise instance in the same region as the VMs. Mount the Filestore file share on each Compute Engine VM.

**C.** Create a Filestore Zonal instance in each zone where the VMs are running. Mount the Filestore file share on each Compute Engine VM.

**D.** Create a Regional Persistent Disk and attach it to all VMs in multi-writer mode.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 281

Contexto: [topics:92](#topics-92)
You are leading a large-scale Google Cloud implementation project. Your development teams need to deploy applications, but they lack deep expertise in cloud-native patterns. This leads to inconsistent and insecure deployments, such as GKE clusters without proper logging and overly permissive IAM roles. You need to implement a system that empowers these teams to deploy complete, pre-approved architectural patterns in a self-service manner. The system must ensure security and consistency by default while maintaining high developer velocity and avoiding manual approval bottlenecks. What should you do?

**A.** Create a central Cloud Monitoring dashboard and a set of custom alerts that fire whenever a non-compliant resource is detected.

**B.** Use Service Catalog to define, govern, and offer a portfolio of approved products. Include Terraform scripts into Service Catalog items.

**C.** Enforce a mandatory CI/CD pipeline using Cloud Build that requires every Terraform deployment to be reviewed and approved before the Terraform apply step can run.

**D.** Use a combination of organization policies to restrict resource configurations and IAM recommender to periodically suggest improvements.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 282

Contexto: [topics:93](#topics-93)
The JencoMart security team requires that all Google Cloud Platform infrastructure is deployed using a least privilege model with separation of duties for administration between production and development resources.
What Google domain and project structure should you recommend?

**A.** Create two G Suite accounts to manage users: one for development/test/staging and one for production. Each account should contain one project for every application

**B.** Create two G Suite accounts to manage users: one with a single project for all development applications and one with a single project for all production applications

**C.** Create a single G Suite account to manage users with each stage of each application in its own project

**D.** Create a single G Suite account to manage users with one project for the development/test/staging environment and one project for the production environment

**Respuesta de la fuente:** C

**Explicación:** Google Cloud best practices recommend a single domain for user management to simplify administration and support Single Sign-On (SSO).
To enforce least privilege and separation of duties, each application stage (e.g., dev, staging, prod) should reside in its own project. This granular isolation allows administrators to grant specific permissions to developers for non-production projects while restricting access to production resources.

## Pregunta 283

Contexto: [topics:93](#topics-93)
A few days after JencoMart migrates the user credentials database to Google Cloud Platform and shuts down the old server, the new database server stops responding to SSH connections. It is still serving database requests to the application servers correctly.
What three steps should you take to diagnose the problem? (Choose three.)

**A.** Delete the virtual machine (VM) and disks and create a new one

**B.** Delete the instance, attach the disk to a new VM, and investigate

**C.** Take a snapshot of the disk and connect to a new machine to investigate

**D.** Check inbound firewall rules for the network the machine is connected to

**E.** Connect the machine to another network with very simple firewall rules and investigate

**F.** Print the Serial Console output for the instance for troubleshooting, activate the interactive console, and investigate

**Respuesta de la fuente:** C, D, F

**Explicación:** The primary constraint is maintaining the 100% uptime SLA for the production database server.
Steps D and F are non-intrusive diagnostic actions: checking firewall rules verifies network connectivity without service impact, and serial console access allows OS-level troubleshooting without requiring SSH.
Step C involves taking a snapshot and connecting it to a new machine; since the source VM remains running, this allows safe investigation of disk or configuration issues without risking downtime on the production instance.

## Pregunta 284

Contexto: [topics:93](#topics-93)
JencoMart has decided to migrate user profile storage to Google Cloud Datastore and the application servers to Google Compute Engine (GCE). During the migration, the existing infrastructure will need access to Datastore to upload the data.
What service account key-management strategy should you recommend?

**A.** Provision service account keys for the on-premises infrastructure and for the GCE virtual machines (VMs)

**B.** Authenticate the on-premises infrastructure with a user account and provision service account keys for the VMs

**C.** Provision service account keys for the on-premises infrastructure and use Google Cloud Platform (GCP) managed keys for the VMs

**D.** Deploy a custom authentication service on GCE/Google Kubernetes Engine (GKE) for the on-premises infrastructure and use GCP managed keys for the VMs

**Respuesta de la fuente:** C

**Explicación:** For on-premises infrastructure accessing GCP resources, you must provision downloadable user-managed service account keys because the external environment cannot use automatic credential rotation. For Google Compute Engine (GCE) virtual machines, you should rely on GCP-managed service account keys (attached via IAM metadata) to avoid manual key management and security risks.

## Pregunta 285

Contexto: [topics:93](#topics-93)
JencoMart has built a version of their application on Google Cloud Platform that serves traffic to Asia. You want to measure success against their business and technical goals.
Which metrics should you track?

**A.** Error rates for requests from Asia

**B.** Latency difference between US and Asia

**C.** Total visits, error rates, and latency from Asia

**D.** Total visits and average latency for users from Asia

**E.** The number of character sets present in the database

**Respuesta de la fuente:** C

**Explicación:** To measure success against both business and technical goals, you must track metrics that address availability, growth, and performance.
'Total visits' validates the goal to expand services into Asia and optimize for peak capacity.
'Error rates' directly correlate with the requirement to guarantee service availability and support.
'Latency from Asia' addresses the specific technical requirement to decrease latency in that region.

## Pregunta 286

Contexto: [topics:93](#topics-93)
[Imagen: sin descripción]
The migration of JencoMart's application to Google Cloud Platform (GCP) is progressing too slowly. The infrastructure is shown in the diagram. You want to maximize throughput.
What are three potential bottlenecks? (Choose three.)
Imagen · question_text · sin descripción
![Imagen original](imagenes/2bbb9f3cdba718df00bb.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
On-premises infrastructure
Rack
Google
Cloud
Storage
Managed group
Rack
Edge router H Cloud VPN
1
VM
Rack
wu
Managed group
VM
“U
```

**A.** A single VPN tunnel, which limits throughput

**B.** A tier of Google Cloud Storage that is not suited for this task

**C.** A copy command that is not suited to operate over long distances

**D.** Fewer virtual machines (VMs) in GCP than on-premises machines

**E.** A separate storage layer outside the VMs, which is not suited for this task

**F.** Complicated internet connectivity between the on-premises infrastructure and GCP

**Respuesta de la fuente:** A, C, F

**Explicación:** A single VPN tunnel creates a throughput bottleneck for migrating large datasets (100+ TB) due to bandwidth and encryption overhead. Standard copy commands lack the parallelism and resumable capabilities needed for efficient long-distance transfers, making them unsuitable compared to tools like Transfer Service or gsutil -m. Complex internet connectivity introduces latency and potential instability, further hindering migration speed and reliability.

## Pregunta 287

Contexto: [topics:93](#topics-93)
JencoMart wants to move their User Profiles database to Google Cloud Platform.
Which Google Database should they use?

**A.** Cloud Spanner

**B.** Google BigQuery

**C.** Google Cloud SQL

**D.** Google Cloud Datastore

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 288

Contexto: [topics:94](#topics-94)
For this question, refer to the Helicopter Racing League (HRL) case study. Your team is in charge of creating a payment card data vault for card numbers used to bill tens of thousands of viewers, merchandise consumers, and season ticket holders. You need to implement a custom card tokenization service that meets the following requirements:
* It must provide low latency at minimal cost.
* It must be able to identify duplicate credit cards and must not store plaintext card numbers.
* It should support annual key rotation.
Which storage approach should you adopt for your tokenization service?

**A.** Store the card data in Secret Manager after running a query to identify duplicates.

**B.** Encrypt the card data with a deterministic algorithm stored in Firestore using Datastore mode.

**C.** Encrypt the card data with a deterministic algorithm and shard it across multiple Memorystore instances.

**D.** Use column-level encryption to store the data in Cloud SQL.

**Respuesta de la fuente:** B

**Explicación:** Deterministic encryption is required to generate consistent tokens from the same input, enabling duplicate card detection without storing plaintext numbers.
Firestore in Datastore mode provides the low-latency, high-throughput, and cost-effective storage needed for a large-scale token vault.
Reference: Google Cloud Architecture Center - Tokenizing sensitive cardholder data for PCI DSS.

## Pregunta 289

Contexto: [topics:94](#topics-94)
For this question, refer to the Helicopter Racing League (HRL) case study. Recently HRL started a new regional racing league in Cape Town, South Africa. In an effort to give customers in Cape Town a better user experience, HRL has partnered with the Content Delivery Network provider, Fastly. HRL needs to allow traffic coming from all of the Fastly IP address ranges into their Virtual Private Cloud network (VPC network). You are a member of the HRL security team and you need to configure the update that will allow only the Fastly IP address ranges through the External HTTP(S) load balancer. Which command should you use?

**A.** [Imagen: sin descripción]
Imagen · choices[0].text · sin descripción
![Imagen original](imagenes/fa523230a2bc1b0112d3.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
gcloud compute security-policies rules update 1000 \
security-policy from-fastly \
src-ip-ranges * \
action “allow”
```

**B.** [Imagen: sin descripción]
Imagen · choices[1].text · sin descripción
![Imagen original](imagenes/4a72ba107960324293af.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
gcloud compute firewall rules update sourceiplist-fastly \
priority 1000 \
allow tep:443
```

**C.** [Imagen: sin descripción]
Imagen · choices[2].text · sin descripción
![Imagen original](imagenes/eb63fd09fa58c0c84300.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
gcloud compute firewall rules update hlr-policy \
priority 1000 \
target-tags-sourceiplist-fastly \
allow tep:443
```

**D.** [Imagen: sin descripción]
Imagen · choices[3].text · sin descripción
![Imagen original](imagenes/09c6c9e4271226dbe8f5.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
gcloud compute security-policies rules update 1000 \
--security-policy hlr-policy \
--expression “evaluatePreconfiguredExpr (‘sourceiplist-fastly’)” \
--action “allow”
```

**Respuesta de la fuente:** A

**Explicación:** Reference:
https://cloud.google.com/load-balancing/docs/https

## Pregunta 290

Contexto: [topics:94](#topics-94)
For this question, refer to the Helicopter Racing League (HRL) case study. The HRL development team releases a new version of their predictive capability application every Tuesday evening at 3 a.m. UTC to a repository. The security team at HRL has developed an in-house penetration test Cloud Function called
Airwolf. The security team wants to run Airwolf against the predictive capability application as soon as it is released every Tuesday. You need to set up Airwolf to run at the recurring weekly cadence. What should you do?

**A.** Set up Cloud Tasks and a Cloud Storage bucket that triggers a Cloud Function.

**B.** Set up a Cloud Logging sink and a Cloud Storage bucket that triggers a Cloud Function.

**C.** Configure the deployment job to notify a Pub/Sub queue that triggers a Cloud Function.

**D.** Set up Identity and Access Management (IAM) and Confidential Computing to trigger a Cloud Function.

**Respuesta de la fuente:** C

**Explicación:** The requirement is to run the penetration test 'as soon as' the application is released, implying an event-driven trigger rather than a fixed time schedule. Cloud Storage buckets cannot directly trigger Cloud Functions via native events in this context; instead, deployment pipelines typically publish notifications to Pub/Sub when artifacts are uploaded. Configuring the deployment job to notify a Pub/Sub topic allows the Cloud Function to be invoked immediately upon release detection, ensuring timely execution without manual scheduling or race conditions associated with fixed-time triggers.

## Pregunta 291

Contexto: [topics:94](#topics-94)
For this question, refer to the Helicopter Racing League (HRL) case study. HRL wants better prediction accuracy from their ML prediction models. They want you to use Google's AI Platform so HRL can understand and interpret the predictions. What should you do?

**A.** Use Explainable AI.

**B.** Use Vision AI.

**C.** Use Google Cloud's operations suite.

**D.** Use Jupyter Notebooks.

**Respuesta de la fuente:** A

**Explicación:** The requirement is to understand and interpret ML predictions on Google AI Platform. Explainable AI (specifically AI Explanations) provides feature attribution data that shows how each input feature contributed to the model's output, directly addressing the need for interpretability.

Other options like Vision AI, Operations Suite, or Jupyter Notebooks do not provide this specific capability for interpreting prediction results.

## Pregunta 292

Contexto: [topics:94](#topics-94)
For this question, refer to the Helicopter Racing League (HRL) case study. HRL is looking for a cost-effective approach for storing their race data such as telemetry. They want to keep all historical records, train models using only the previous season's data, and plan for data growth in terms of volume and information collected. You need to propose a data solution. Considering HRL business requirements and the goals expressed by CEO S. Hawke, what should you do?

**A.** Use Firestore for its scalable and flexible document-based database. Use collections to aggregate race data by season and event.

**B.** Use Cloud Spanner for its scalability and ability to version schemas with zero downtime. Split race data using season as a primary key.

**C.** Use BigQuery for its scalability and ability to add columns to a schema. Partition race data based on season.

**D.** Use Cloud SQL for its ability to automatically manage storage increases and compatibility with MySQL. Use separate database instances for each season.

**Respuesta de la fuente:** C

**Explicación:** BigQuery is the optimal choice because it is a serverless data warehouse designed for analyzing large datasets and supports machine learning via BigQuery ML, aligning with HRL's goal of training models on historical telemetry. Partitioning by season allows for cost-effective querying of specific timeframes while handling massive data growth without operational overhead.

## Pregunta 293

Contexto: [topics:94](#topics-94)
For this question, refer to the Helicopter Racing League (HRL) case study. A recent finance audit of cloud infrastructure noted an exceptionally high number of
Compute Engine instances are allocated to do video encoding and transcoding. You suspect that these Virtual Machines are zombie machines that were not deleted after their workloads completed. You need to quickly get a list of which VM instances are idle. What should you do?

**A.** Log into each Compute Engine instance and collect disk, CPU, memory, and network usage statistics for analysis.

**B.** Use the gcloud compute instances list to list the virtual machine instances that have the idle: true label set.

**C.** Use the gcloud recommender command to list the idle virtual machine instances.

**D.** From the Google Console, identify which Compute Engine instances in the managed instance groups are no longer responding to health check probes.

**Respuesta de la fuente:** C

**Explicación:** Google Cloud Recommender provides automated suggestions to reduce costs and improve reliability, including identifying idle Compute Engine instances.
The specific recommender `google.compute.instance.IdleResourceRecommender` analyzes usage patterns (CPU, memory, network) to detect VMs that have not been utilized for a set period.
Using the `gcloud recommender` command is the most efficient and automated way to generate this list without manual inspection or custom scripting.

## Pregunta 294

Contexto: [topics:95](#topics-95)
For this question, refer to the EHR Healthcare case study. You are responsible for ensuring that EHR's use of Google Cloud will pass an upcoming privacy compliance audit. What should you do? (Choose two.)

**A.** Verify EHR's product usage against the list of compliant products on the Google Cloud compliance page.

**B.** Advise EHR to execute a Business Associate Agreement (BAA) with Google Cloud.

**C.** Use Firebase Authentication for EHR's user facing applications.

**D.** Implement Prometheus to detect and prevent security breaches on EHR's web-based applications.

**E.** Use GKE private clusters for all Kubernetes workloads.

**Respuesta de la fuente:** A, B

**Explicación:** To ensure compliance for healthcare data (likely HIPAA/GDPR), EHR must first confirm that the specific Google Cloud services in use are certified by checking the compliance offerings list (A). Additionally, because EHR processes Protected Health Information, a Business Associate Agreement (BAA) is legally required to define roles and responsibilities for data protection (B).

## Pregunta 295

Contexto: [topics:95](#topics-95)
For this question, refer to the EHR Healthcare case study. You need to define the technical architecture for securely deploying workloads to Google Cloud. You also need to ensure that only verified containers are deployed using Google Cloud services. What should you do? (Choose two.)

**A.** Enable Binary Authorization on GKE, and sign containers as part of a CI/CD pipeline.

**B.** Configure Jenkins to utilize Kritis to cryptographically sign a container as part of a CI/CD pipeline.

**C.** Configure Container Registry to only allow trusted service accounts to create and deploy containers from the registry.

**D.** Configure Container Registry to use vulnerability scanning to confirm that there are no vulnerabilities before deploying the workload.

**Respuesta de la fuente:** A, D

**Explicación:** Binary Authorization is the primary Google Cloud service for enforcing admission control on GKE to ensure only signed (verified) containers are deployed, directly satisfying the requirement. Vulnerability scanning in Container Registry provides critical security insights by identifying known CVEs, which can be integrated with Binary Authorization policies to reject untrusted images, thereby supporting secure deployment.

## Pregunta 296

Contexto: [topics:95](#topics-95)
You need to upgrade the EHR connection to comply with their requirements. The new connection design must support business-critical needs and meet the same network and security policy requirements. What should you do?

**A.** Add a new Dedicated Interconnect connection.

**B.** Upgrade the bandwidth on the Dedicated Interconnect connection to 100 G.

**C.** Add three new Cloud VPN connections.

**D.** Add a new Carrier Peering connection.

**Respuesta de la fuente:** A

**Explicación:** The case study requires a secure, high-performance connection between on-premises systems and Google Cloud to support business-critical needs and maintain regulatory compliance. Dedicated Interconnect provides a direct, private connection with higher availability (up to 99.5% SLA for dual connections) and lower latency compared to Cloud VPN or Carrier Peering. While Carrier Peering is easier to set up, it lacks the SLA guarantees and security controls required for sensitive healthcare data transmission.

## Pregunta 297

Contexto: [topics:95](#topics-95)
For this question, refer to the EHR Healthcare case study. You need to define the technical architecture for hybrid connectivity between EHR's on-premises systems and Google Cloud. You want to follow Google's recommended practices for production-level applications. Considering the EHR Healthcare business and technical requirements, what should you do?

**A.** Configure two Partner Interconnect connections in one metro (City), and make sure the Interconnect connections are placed in different metro zones.

**B.** Configure two VPN connections from on-premises to Google Cloud, and make sure the VPN devices on-premises are in separate racks.

**C.** Configure Direct Peering between EHR Healthcare and Google Cloud, and make sure you are peering at least two Google locations.

**D.** Configure two Dedicated Interconnect connections in one metro (City) and two connections in another metro, and make sure the Interconnect connections are placed in different metro zones.

**Respuesta de la fuente:** D

**Explicación:** Google's recommended practices for production-level applications require a highly resilient hybrid connectivity topology that ensures high availability and performance. Option D provides two Dedicated Interconnect connections in one metro and two in another, each placed in different zones, which achieves the 99.99% SLA recommended for critical production workloads. This exceeds the minimum 99.9% business requirement, aligning with Google's best practices to minimize downtime risks associated with single-metro or lower-SLA configurations.

## Pregunta 298

Contexto: [topics:95](#topics-95)
For this question, refer to the EHR Healthcare case study. You are a developer on the EHR customer portal team. Your team recently migrated the customer portal application to Google Cloud. The load has increased on the application servers, and now the application is logging many timeout errors. You recently incorporated Pub/Sub into the application architecture, and the application is not logging any Pub/Sub publishing errors. You want to improve publishing latency.
What should you do?

**A.** Increase the Pub/Sub Total Timeout retry value.

**B.** Move from a Pub/Sub subscriber pull model to a push model.

**C.** Turn off Pub/Sub message batching.

**D.** Create a backup Pub/Sub message queue.

**Respuesta de la fuente:** C

**Explicación:** Pub/Sub publishers batch messages in memory before sending them to reduce API call overhead. While this improves throughput and reduces costs, it introduces latency because individual messages wait for the batch threshold or timeout to be met. To minimize publishing latency, turning off batching ensures that each message is sent individually and immediately upon publication.

## Pregunta 299

Contexto: [topics:95](#topics-95)
For this question, refer to the EHR Healthcare case study. In the past, configuration errors put public IP addresses on backend servers that should not have been accessible from the Internet. You need to ensure that no one can put external IP addresses on backend Compute Engine instances and that external IP addresses can only be configured on frontend Compute Engine instances. What should you do?

**A.** Create an Organizational Policy with a constraint to allow external IP addresses only on the frontend Compute Engine instances.

**B.** Revoke the compute.networkAdmin role from all users in the project with front end instances.

**C.** Create an Identity and Access Management (IAM) policy that maps the IT staff to the compute.networkAdmin role for the organization.

**D.** Create a custom Identity and Access Management (IAM) role named GCE_FRONTEND with the compute.addresses.create permission.

**Respuesta de la fuente:** A

**Explicación:** The requirement to restrict external IP addresses based on instance type is best handled by Google Cloud Organization Policy constraints.
Specifically, the `constraints/compute.restrictExternalIPOutbound` or related VM-scoped constraints allow administrators to enforce rules that prevent backend instances from acquiring external IPs while permitting frontend instances to have them.
IAM roles (B, C, D) manage user permissions but cannot technically prevent a privileged user from misconfiguring an instance if the underlying resource policy allows it.

## Pregunta 300

Contexto: [topics:95](#topics-95)
For this question, refer to the EHR Healthcare case study. You are responsible for designing the Google Cloud network architecture for Google Kubernetes
Engine. You want to follow Google best practices. Considering the EHR Healthcare business and technical requirements, what should you do to reduce the attack surface?

**A.** Use a private cluster with a private endpoint with master authorized networks configured.

**B.** Use a public cluster with firewall rules and Virtual Private Cloud (VPC) routes.

**C.** Use a private cluster with a public endpoint with master authorized networks configured.

**D.** Use a public cluster with master authorized networks enabled and firewall rules.

**Respuesta de la fuente:** A

**Explicación:** To reduce the attack surface for GKE in a healthcare context, you should use a private cluster with a private endpoint.
This configuration removes public IP addresses from nodes and blocks internet access to the control plane API server entirely.
Master authorized networks are then configured on the private endpoint to restrict API access to specific internal CIDR ranges, adhering to Google's most secure best practices.

## Pregunta 301

Contexto: [topics:96](#topics-96)
Mountkirk Games wants you to design their new testing strategy. How should the test coverage differ from their existing backends on the other platforms?

**A.** Tests should scale well beyond the prior approaches

**B.** Unit tests are no longer required, only end-to-end tests

**C.** Tests should be applied after the release is in the production environment

**D.** Tests should include directly testing the Google Cloud Platform (GCP) infrastructure

**Respuesta de la fuente:** A

**Explicación:** Mountkirk Games' primary historical failure was an inability to scale under unexpected popularity, making scalability the critical differentiator for the new testing strategy.
Therefore, test coverage must be designed to validate that the system performs reliably at loads significantly exceeding previous capacities.
Testing GCP infrastructure directly (D) is incorrect as customers rely on provider SLAs rather than testing the underlying platform's internal mechanics.

## Pregunta 302

Contexto: [topics:96](#topics-96)
Mountkirk Games has deployed their new backend on Google Cloud Platform (GCP). You want to create a through testing process for new versions of the backend before they are released to the public. You want the testing environment to scale in an economical way. How should you design the process?

**A.** Create a scalable environment in GCP for simulating production load

**B.** Use the existing infrastructure to test the GCP-based backend at scale

**C.** Build stress tests into each component of your application using resources internal to GCP to simulate load

**D.** Create a set of static environments in GCP to test different levels of load — for example, high, medium, and low

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it leverages GCP's native autoscaling capabilities to simulate production load economically, aligning with the requirement for a testing environment that scales as needed. Option D is incorrect because static environments do not scale dynamically, violating the core requirement. Option B is invalid as the existing infrastructure suffered from scaling issues, and Option C focuses on component-level stress testing rather than end-to-end system load simulation.

## Pregunta 303

Contexto: [topics:96](#topics-96)
Mountkirk Games wants to set up a continuous delivery pipeline. Their architecture includes many small services that they want to be able to update and roll back quickly. Mountkirk Games has the following requirements:
✑ Services are deployed redundantly across multiple regions in the US and Europe
✑ Only frontend services are exposed on the public internet
✑ They can provide a single frontend IP for their fleet of services
✑ Deployment artifacts are immutable
Which set of products should they use?

**A.** Google Cloud Storage, Google Cloud Dataflow, Google Compute Engine

**B.** Google Cloud Storage, Google App Engine, Google Network Load Balancer

**C.** Google Kubernetes Registry, Google Container Engine, Google HTTP(S) Load Balancer

**D.** Google Cloud Functions, Google Cloud Pub/Sub, Google Cloud Deployment Manager

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google Kubernetes Engine (GKE) enables rapid updates and rollbacks of small services using immutable container images stored in the registry.
The HTTP(S) Load Balancer provides a single global frontend IP address and allows routing to specific backend services while keeping internal services private, meeting the multi-region exposure requirements.

## Pregunta 304

Contexto: [topics:96](#topics-96)
Mountkirk Games' gaming servers are not automatically scaling properly. Last month, they rolled out a new feature, which suddenly became very popular. A record number of users are trying to use the service, but many of them are getting 503 errors and very slow response times. What should they investigate first?

**A.** Verify that the database is online

**B.** Verify that the project quota hasn't been exceeded

**C.** Verify that the new feature code did not introduce any performance bugs

**D.** Verify that the load-testing team is not running their tool against production

**Respuesta de la fuente:** B

**Explicación:** The problem statement explicitly identifies that the gaming servers are "not automatically scaling properly" due to a sudden surge in traffic. In Google Cloud, autoscaling relies on creating new VM instances within the limits defined by service quotas (such as CPU or instance counts). If the existing quota is exceeded, the platform cannot provision additional resources to handle the load, leading to capacity exhaustion and resulting 503 Service Unavailable errors.

## Pregunta 305

Contexto: [topics:96](#topics-96)
Mountkirk Games needs to create a repeatable and configurable mechanism for deploying isolated application environments. Developers and testers can access each other's environments and resources, but they cannot access staging or production resources. The staging environment needs access to some services from production.
What should you do to isolate development environments from staging and production?

**A.** Create a project for development and test and another for staging and production

**B.** Create a network for development and test and another for staging and production

**C.** Create one subnetwork for development and another for staging and production

**D.** Create one project for development, a second for staging and a third for production

**Respuesta de la fuente:** D

**Explicación:** Google Cloud best practices recommend creating a separate project for each environment (dev, staging, production) to ensure distinct IAM policies, billing separation, and isolation.
While the staging environment needs access to production services, this is best achieved using Shared VPC or VPC Service Controls rather than merging them into one project, which would compromise the required isolation between dev/test and higher environments.
Option D correctly isolates all three stages by placing each in its own project, allowing precise control over cross-environment access.

## Pregunta 306

Contexto: [topics:96](#topics-96)
Mountkirk Games wants to set up a real-time analytics platform for their new game. The new platform must meet their technical requirements.
Which combination of Google technologies will meet all of their requirements?

**A.** Kubernetes Engine, Cloud Pub/Sub, and Cloud SQL

**B.** Cloud Dataflow, Cloud Storage, Cloud Pub/Sub, and BigQuery

**C.** Cloud SQL, Cloud Storage, Cloud Pub/Sub, and Cloud Dataflow

**D.** Cloud Dataproc, Cloud Pub/Sub, Cloud SQL, and Cloud Dataflow

**E.** Cloud Pub/Sub, Compute Engine, Cloud Storage, and Cloud Dataproc

**Respuesta de la fuente:** B

**Explicación:** Option B satisfies all technical requirements for the analytics platform: Cloud Pub/Sub handles high-throughput streaming ingestion; Cloud Dataflow processes data on-the-fly and accommodates late-arriving events with exactly-once semantics; Cloud Storage manages user-uploaded files; and BigQuery provides SQL access to petabyte-scale historical data. Crucially, this combination uses only fully managed services, fulfilling requirement #6, whereas other options include Compute Engine or Cloud Dataproc which are not fully managed.

## Pregunta 307

Contexto: [topics:97](#topics-97)
For this question, refer to the Mountkirk Games case study. Mountkirk Games wants to migrate from their current analytics and statistics reporting model to one that meets their technical requirements on Google Cloud Platform.
Which two steps should be part of their migration plan? (Choose two.)

**A.** Evaluate the impact of migrating their current batch ETL code to Cloud Dataflow.

**B.** Write a schema migration plan to denormalize data for better performance in BigQuery.

**C.** Draw an architecture diagram that shows how to move from a single MySQL database to a MySQL cluster.

**D.** Load 10 TB of analytics data from a previous game into a Cloud SQL instance, and run test queries against the full dataset to confirm that they complete successfully.

**E.** Integrate Cloud Armor to defend against possible SQL injection attacks in analytics files uploaded to Cloud Storage.

**Respuesta de la fuente:** A, B

**Explicación:** Mountkirk Games needs to migrate from a batch ETL model handling high-volume analytics data. Cloud Dataflow (Option A) is the appropriate managed service to process this streaming and batch data, replacing their current tooling.
BigQuery (Option B) is the correct target for storing large-scale historical analytics (10 TB+) because it supports denormalized schemas for optimized query performance, whereas Cloud SQL is not designed for such heavy analytical workloads.

## Pregunta 308

Contexto: [topics:97](#topics-97)
For this question, refer to the Mountkirk Games case study. You need to analyze and define the technical architecture for the compute workloads for your company, Mountkirk Games. Considering the Mountkirk Games business and technical requirements, what should you do?

**A.** Create network load balancers. Use preemptible Compute Engine instances.

**B.** Create network load balancers. Use non-preemptible Compute Engine instances.

**C.** Create a global load balancer with managed instance groups and autoscaling policies. Use preemptible Compute Engine instances.

**D.** Create a global load balancer with managed instance groups and autoscaling policies. Use non-preemptible Compute Engine instances.

**Respuesta de la fuente:** D

**Explicación:** A global load balancer with managed instance groups and autoscaling is required to meet the business requirements for a global footprint, low latency, and dynamic scaling based on game activity.
Non-preemptible instances must be used because preemptible VMs can be terminated by Google at any time, which violates the critical requirement to improve uptime and prevent downtime that results in loss of players.

## Pregunta 309

Contexto: [topics:97](#topics-97)
For this question, refer to the Mountkirk Games case study. Mountkirk Games wants to design their solution for the future in order to take advantage of cloud and technology improvements as they become available. Which two steps should they take? (Choose two.)

**A.** Store as much analytics and game activity data as financially feasible today so it can be used to train machine learning models to predict user behavior in the future.

**B.** Begin packaging their game backend artifacts in container images and running them on Google Kubernetes Engine to improve the ability to scale up or down based on game activity.

**C.** Set up a CI/CD pipeline using Jenkins and Spinnaker to automate canary deployments and improve development velocity.

**D.** Adopt a schema versioning tool to reduce downtime when adding new game features that require storing additional player data in the database.

**E.** Implement a weekly rolling maintenance process for the Linux virtual machines so they can apply critical kernel patches and package updates and reduce the risk of 0-day vulnerabilities.

**Respuesta de la fuente:** A, B

**Explicación:** Option B is correct because containerizing applications on Google Kubernetes Engine (GKE) abstracts infrastructure management, allowing the company to leverage future cloud advancements and autoscaling capabilities without being tied to specific virtual machine images.
Option A is correct because accumulating historical data creates a foundation for machine learning and advanced analytics; as AI technology improves, having a rich dataset ensures the business can immediately capitalize on new predictive modeling capabilities to optimize user experience.

## Pregunta 310

Contexto: [topics:97](#topics-97)
For this question, refer to the Mountkirk Games case study. Mountkirk Games wants you to design a way to test the analytics platform's resilience to changes in mobile network latency. What should you do?

**A.** Deploy failure injection software to the game analytics platform that can inject additional latency to mobile client analytics traffic.

**B.** Build a test client that can be run from a mobile phone emulator on a Compute Engine virtual machine, and run multiple copies in Google Cloud Platform regions all over the world to generate realistic traffic.

**C.** Add the ability to introduce a random amount of delay before beginning to process analytics files uploaded from mobile devices.

**D.** Create an opt-in beta of the game that runs on players' mobile devices and collects response times from analytics endpoints running in Google Cloud Platform regions all over the world.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it directly addresses the requirement to test resilience against mobile network latency by simulating that specific failure mode at the source. Failure injection tools allow engineers to introduce controlled latency into the traffic path before it reaches the analytics platform, ensuring the system handles delayed or out-of-order data as specified in the technical requirements. Option C only delays processing after ingestion, failing to simulate the actual network conditions and potential partial delivery issues associated with mobile connectivity.

## Pregunta 311

Contexto: [topics:97](#topics-97)
For this question, refer to the Mountkirk Games case study. You need to analyze and define the technical architecture for the database workloads for your company, Mountkirk Games. Considering the business and technical requirements, what should you do?

**A.** Use Cloud SQL for time series data, and use Cloud Bigtable for historical data queries.

**B.** Use Cloud SQL to replace MySQL, and use Cloud Spanner for historical data queries.

**C.** Use Cloud Bigtable to replace MySQL, and use BigQuery for historical data queries.

**D.** Use Cloud Bigtable for time series data, use Cloud Spanner for transactional data, and use BigQuery for historical data queries.

**Respuesta de la fuente:** D

**Explicación:** The technical requirements explicitly call for a transactional database for user profiles (Cloud Spanner) and a timeseries database for game activity (Cloud Bigtable). Additionally, BigQuery is the appropriate service for analyzing large volumes of historical data as specified in the analytics requirements.

## Pregunta 312

Contexto: [topics:97](#topics-97)
For this question, refer to the Mountkirk Games case study. Which managed storage option meets Mountkirk's technical requirement for storing game activity in a time series database service?

**A.** Cloud Bigtable

**B.** Cloud Spanner

**C.** BigQuery

**D.** Cloud Datastore

**Respuesta de la fuente:** A

**Explicación:** Cloud Bigtable is the correct choice because it is specifically designed for high-throughput, low-latency time-series data, such as IoT metrics and game activity logs.
BigQuery is an OLAP data warehouse suitable for historical analysis but lacks the low-latency real-time write capabilities required for storing live game activity.
Spanner and Datastore are primarily transactional NoSQL databases not optimized for the specific high-volume, append-only nature of time-series telemetry.

## Pregunta 313

Contexto: [topics:97](#topics-97)
For this question, refer to the Mountkirk Games case study. You are in charge of the new Game Backend Platform architecture. The game communicates with the backend over a REST API.
You want to follow Google-recommended practices. How should you design the backend?

**A.** Create an instance template for the backend. For every region, deploy it on a multi-zone managed instance group. Use an L4 load balancer.

**B.** Create an instance template for the backend. For every region, deploy it on a single-zone managed instance group. Use an L4 load balancer.

**C.** Create an instance template for the backend. For every region, deploy it on a multi-zone managed instance group. Use an L7 load balancer.

**D.** Create an instance template for the backend. For every region, deploy it on a single-zone managed instance group. Use an L7 load balancer.

**Respuesta de la fuente:** C

**Explicación:** The game backend communicates via a REST API, which operates over HTTP/HTTPS at Layer 7 (Application Layer), requiring an L7 load balancer for proper content-based routing and SSL termination.
To satisfy the business requirement for high uptime and global scalability, instances must be deployed across multiple zones within each region to ensure high availability during zone-level failures.

## Pregunta 314

Contexto: [topics:98](#topics-98)
You need to optimize batch file transfers into Cloud Storage for Mountkirk Games' new Google Cloud solution. The batch files contain game statistics that need to be staged in Cloud Storage and be processed by an extract transform load (ETL) tool. What should you do?

**A.** Use gsutil to batch move files in sequence.

**B.** Use gsutil to batch copy the files in parallel.

**C.** Use gsutil to extract the files as the first part of ETL.

**D.** Use gsutil to load the files as the last part of ETL.

**Respuesta de la fuente:** B

**Explicación:** To optimize batch file transfers into Cloud Storage, you should use gsutil with the -m flag to perform parallel multi-threaded or multi-processing copies. This approach significantly improves transfer speed and throughput compared to sequential processing, aligning with the goal of optimization.

## Pregunta 315

Contexto: [topics:98](#topics-98)
You are implementing Firestore for Mountkirk Games. Mountkirk Games wants to give a new game programmatic access to a legacy game's Firestore database.
Access should be as restricted as possible. What should you do?

**A.** Create a service account (SA) in the legacy game's Google Cloud project, add a second SA in the new game's IAM page, and then give the Organization Admin role to both SAs.

**B.** Create a service account (SA) in the legacy game's Google Cloud project, give the SA the Organization Admin role, and then give it the Firebase Admin role in both projects.

**C.** Create a service account (SA) in the legacy game's Google Cloud project, add this SA in the new game's IAM page, and then give it the Firebase Admin role in both projects.

**D.** Create a service account (SA) in the legacy game's Google Cloud project, give it the Firebase Admin role, and then migrate the new game to the legacy game's project.

**Respuesta de la fuente:** C

**Explicación:** Option C correctly implements the principle of least privilege by using a service account with specific Firebase Admin roles rather than Organization Admin (which is overly permissive).
It grants the necessary cross-project access from the legacy project to the new game without merging projects, adhering to the existing isolation strategy.

## Pregunta 316

Contexto: [topics:98](#topics-98)
Mountkirk Games wants to limit the physical location of resources to their operating Google Cloud regions. What should you do?

**A.** Configure an organizational policy which constrains where resources can be deployed.

**B.** Configure IAM conditions to limit what resources can be configured.

**C.** Configure the quotas for resources in the regions not being used to 0.

**D.** Configure a custom alert in Cloud Monitoring so you can disable resources as they are created in other regions.

**Respuesta de la fuente:** A

**Explicación:** Organizational Policy Constraints in Google Cloud provide a mechanism to enforce limits on resource deployment based on specific criteria, including physical location.
The `constraints/gcp.resourceLocations` constraint allows administrators to define an allowlist of regions and zones where new resources can be created, preventing deployment in unauthorized locations.
This is a proactive governance measure, unlike monitoring alerts (reactive) or quotas (which limit quantity, not geography), making it the correct solution for enforcing regional compliance.

## Pregunta 317

Contexto: [topics:98](#topics-98)
You need to implement a network ingress for a new game that meets the defined business and technical requirements. Mountkirk Games wants each regional game instance to be located in multiple Google Cloud regions. What should you do?

**A.** Configure a global load balancer connected to a managed instance group running Compute Engine instances.

**B.** Configure kubemci with a global load balancer and Google Kubernetes Engine.

**C.** Configure a global load balancer with Google Kubernetes Engine.

**D.** Configure Ingress for Anthos with a global load balancer and Google Kubernetes Engine.

**Respuesta de la fuente:** D

**Explicación:** The case study requires routing traffic to GKE clusters across multiple Google Cloud regions to minimize latency for global players.
Multi-Cluster Ingress (formerly known as Ingress for Anthos) is the specific service designed to configure a single Global HTTP(S) Load Balancer that distributes traffic across multiple regional GKE clusters.
Option D correctly identifies this multi-region ingress solution, whereas Option A uses Compute Engine MIGs which do not align with the stated GKE deployment strategy, and Option C does inherently specify the multi-cluster capability required for global routing.

## Pregunta 318

Contexto: [topics:98](#topics-98)
Your development teams release new versions of games running on Google Kubernetes Engine (GKE) daily. You want to create service level indicators (SLIs) to evaluate the quality of the new versions from the user's perspective. What should you do?

**A.** Create CPU Utilization and Request Latency as service level indicators.

**B.** Create GKE CPU Utilization and Memory Utilization as service level indicators.

**C.** Create Request Latency and Error Rate as service level indicators.

**D.** Create Server Uptime and Error Rate as service level indicators.

**Respuesta de la fuente:** C

**Explicación:** Service Level Indicators (SLIs) must measure the service quality from the end-user's perspective, focusing on attributes like freshness, accuracy, availability, and latency. Request Latency and Error Rate are standard user-facing metrics that directly reflect the experience of game players. Infrastructure metrics like CPU utilization or server uptime do not correlate directly with user satisfaction.

## Pregunta 319

Contexto: [topics:98](#topics-98)
Mountkirk Games wants you to secure the connectivity from the new gaming application platform to Google Cloud. You want to streamline the process and follow
Google-recommended practices. What should you do?

**A.** Configure Workload Identity and service accounts to be used by the application platform.

**B.** Use Kubernetes Secrets, which are obfuscated by default. Configure these Secrets to be used by the application platform.

**C.** Configure Kubernetes Secrets to store the secret, enable Application-Layer Secrets Encryption, and use Cloud Key Management Service (Cloud KMS) to manage the encryption keys. Configure these Secrets to be used by the application platform.

**D.** Configure HashiCorp Vault on Compute Engine, and use customer managed encryption keys and Cloud Key Management Service (Cloud KMS) to manage the encryption keys. Configure these Secrets to be used by the application platform.

**Respuesta de la fuente:** A

**Explicación:** Workload Identity is the Google-recommended best practice for securing GKE workloads because it allows pods to access Google Cloud resources via IAM policies without managing service account keys. This approach streamlines management and enhances security by eliminating the need to store or rotate credentials manually, aligning with the requirement to follow Google-recommended practices.

## Pregunta 320

Contexto: [topics:98](#topics-98)
Your development team has created a mobile game app. You want to test the new mobile app on Android and iOS devices with a variety of configurations. You need to ensure that testing is efficient and cost-effective. What should you do?

**A.** Upload your mobile app to the Firebase Test Lab, and test the mobile app on Android and iOS devices.

**B.** Create Android and iOS VMs on Google Cloud, install the mobile app on the VMs, and test the mobile app.

**C.** Create Android and iOS containers on Google Kubernetes Engine (GKE), install the mobile app on the containers, and test the mobile app.

**D.** Upload your mobile app with different configurations to Firebase Hosting and test each configuration.

**Respuesta de la fuente:** A

**Explicación:** Firebase Test Lab is a managed service specifically designed to test mobile apps on a wide variety of physical Android and iOS devices with different configurations.

This solution meets the requirements for efficiency and cost-effectiveness by eliminating the need to maintain your own device farm or manage complex VM/container infrastructure (as suggested in options B and C).

Option D is incorrect because Firebase Hosting is used for serving static web content, not for executing mobile app tests.

## Pregunta 321

Contexto: [topics:99](#topics-99)
TerramEarth's CTO wants to use the raw data from connected vehicles to help identify approximately when a vehicle in the field will have a catastrophic failure.
You want to allow analysts to centrally query the vehicle data.
Which architecture should you recommend?

**A.** [Imagen: sin descripción]
Imagen · choices[0].text · sin descripción
![Imagen original](imagenes/40c0031f04b98be6bde4.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
IoT <) tT ©) tot
S S/ SM
FTP FTP FTP
Google Cloud Load Balancing
Google Container Engine? |?
Cloud Pub/Sub
Cloud Dataflow
BigQuery
I
Analysts
```

**B.** [Imagen: sin descripción]
Imagen · choices[1].text · sin descripción
![Imagen original](imagenes/4c639d1e875e967e7fd2.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
<> Wor <> Wot <> bet
FTP FTP FTP
Flexible Environment
App Engine
|
Cloud Pub/Sub
Cloud Dataflow
BigQuery
T
Analysts
```

**C.** [Imagen: sin descripción]
Imagen · choices[2].text · sin descripción
![Imagen original](imagenes/06e2567e638e82876d73.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
<> tor <) kT <) WoT
FTP FTP FTP
Google Cloud Load Balancing
[FTP
Google Container Engine
Cloud Pub/Sub
Cloud Dataflow
—__[
Cloud SQL
Analysts
```

**D.** [Imagen: sin descripción]
Imagen · choices[3].text · sin descripción
![Imagen original](imagenes/93642b7cfdbee92b697b.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
<) IoT <> lot <?
FTP FIP FTP
Flexible Environment
App Engine
Cloud Pub/Sub
Cloud Dataflow
Cloud SQL
Analysts
```

**Respuesta de la fuente:** A

**Explicación:** Option A is the correct architecture because it utilizes BigQuery for analytics, which scales effectively to handle the massive daily data volume (9 TB/day) required for predicting catastrophic failures, whereas Cloud SQL does not. Additionally, GKE combined with global Cloud Load Balancing supports a multi-region deployment suitable for a global business, unlike App Engine which is regionally constrained.

## Pregunta 322

Contexto: [topics:99](#topics-99)
The TerramEarth development team wants to create an API to meet the company's business requirements. You want the development team to focus their development effort on business value versus creating a custom framework.
Which method should they use?

**A.** Use Google App Engine with Google Cloud Endpoints. Focus on an API for dealers and partners

**B.** Use Google App Engine with a JAX-RS Jersey Java-based framework. Focus on an API for the public

**C.** Use Google App Engine with the Swagger (Open API Specification) framework. Focus on an API for the public

**D.** Use Google Container Engine with a Django Python container. Focus on an API for the public

**E.** Use Google Container Engine with a Tomcat container with the Swagger (Open API Specification) framework. Focus on an API for dealers and partners

**Respuesta de la fuente:** A

**Explicación:** The requirement is to avoid building a custom framework and focus on business value, which points to using a managed service like Google Cloud Endpoints.
Option A correctly combines Google App Engine with Cloud Endpoints, providing automated infrastructure management for APIs without the operational overhead of managing servers or containers.
Focusing on dealers and partners aligns with the specific business need to support the dealer network and enable partnerships, as opposed to a generic public API.

## Pregunta 323

Contexto: [topics:99](#topics-99)
Your development team has created a structured API to retrieve vehicle data. They want to allow third parties to develop tools for dealerships that use this vehicle event data. You want to support delegated authorization against this data.
What should you do?

**A.** Build or leverage an OAuth-compatible access control system

**B.** Build SAML 2.0 SSO compatibility into your authentication system

**C.** Restrict data access based on the source IP address of the partner systems

**D.** Create secondary credentials for each dealer that can be given to the trusted third party

**Respuesta de la fuente:** A

**Explicación:** The requirement specifies 'delegated authorization,' which allows a third-party application to access specific resources on behalf of a user without handling their credentials. OAuth 2.0 is the industry-standard protocol designed specifically for this purpose, managing access tokens and scopes securely.

SAML (Option B) is primarily an identity federation protocol used for single sign-on (authentication), not for granular API resource delegation. Restricting by IP (Option C) lacks user-level consent and granularity, while sharing credentials (Option D) violates security best practices.

## Pregunta 324

Contexto: [topics:99](#topics-99)
TerramEarth plans to connect all 20 million vehicles in the field to the cloud. This increases the volume to 20 million 600 byte records a second for 40 TB an hour.
How should you design the data ingestion?

**A.** Vehicles write data directly to GCS

**B.** Vehicles write data directly to Google Cloud Pub/Sub

**C.** Vehicles stream data directly to Google BigQuery

**D.** Vehicles continue to write data using the existing system (FTP)

**Respuesta de la fuente:** B

**Explicación:** The correct answer is B because Google Cloud Pub/Sub is designed to handle high-throughput, low-latency streaming data from millions of devices, acting as a scalable buffer for the massive volume (40 TB/hour).
Direct streaming into BigQuery (Option C) is incorrect because the ingestion rate would exceed BigQuery's streaming limits, leading to errors or data loss.
Writing directly to GCS (Option A) lacks the real-time processing and decoupling capabilities needed for this scale of IoT telemetry.

## Pregunta 325

Contexto: [topics:99](#topics-99)
You analyzed TerramEarth's business requirement to reduce downtime, and found that they can achieve a majority of time saving by reducing customer's wait time for parts. You decided to focus on reduction of the 3 weeks aggregate reporting time.
Which modifications to the company's processes should you recommend?

**A.** Migrate from CSV to binary format, migrate from FTP to SFTP transport, and develop machine learning analysis of metrics

**B.** Migrate from FTP to streaming transport, migrate from CSV to binary format, and develop machine learning analysis of metrics

**C.** Increase fleet cellular connectivity to 80%, migrate from FTP to streaming transport, and develop machine learning analysis of metrics

**D.** Migrate from FTP to SFTP transport, develop machine learning analysis of metrics, and increase dealer local inventory by a fixed factor

**Respuesta de la fuente:** C

**Explicación:** The primary bottleneck is the 3-week latency caused by batch FTP transfers from only 1% of connected vehicles. Increasing cellular connectivity to 80% expands the data sample significantly, while migrating to streaming transport eliminates the batch delay for real-time analysis. Machine learning then leverages this fresh, comprehensive data stream to predict part failures accurately, enabling just-in-time inventory stocking that reduces downtime without increasing surplus costs.

## Pregunta 326

Contexto: [topics:99](#topics-99)
Which of TerramEarth's legacy enterprise processes will experience significant change as a result of increased Google Cloud Platform adoption?

**A.** Opex/capex allocation, LAN changes, capacity planning

**B.** Capacity planning, TCO calculations, opex/capex allocation

**C.** Capacity planning, utilization measurement, data center expansion

**D.** Data Center expansion, TCO calculations, utilization measurement

**Respuesta de la fuente:** B

**Explicación:** Adopting Google Cloud Platform shifts financial models from Capital Expenditures (CapEx) to Operating Expenditures (OpEx), fundamentally changing Opex/capex allocation and Total Cost of Ownership (TCO) calculations. Capacity planning transforms from provisioning physical hardware for peak loads to managing elastic, on-demand resources, which is a significant process change compared to legacy methods. Options involving data center expansion or LAN changes are incorrect because the cloud provider manages infrastructure capacity and network topology.

## Pregunta 327

Contexto: [topics:99](#topics-99)
To speed up data retrieval, more vehicles will be upgraded to cellular connections and be able to transmit data to the ETL process. The current FTP process is error-prone and restarts the data transfer from the start of the file when connections fail, which happens often. You want to improve the reliability of the solution and minimize data transfer time on the cellular connections.
What should you do?

**A.** Use one Google Container Engine cluster of FTP servers. Save the data to a Multi-Regional bucket. Run the ETL process using data in the bucket

**B.** Use multiple Google Container Engine clusters running FTP servers located in different regions. Save the data to Multi-Regional buckets in US, EU, and Asia. Run the ETL process using the data in the bucket

**C.** Directly transfer the files to different Google Cloud Multi-Regional Storage bucket locations in US, EU, and Asia using Google APIs over HTTP(S). Run the ETL process using the data in the bucket

**D.** Directly transfer the files to a different Google Cloud Regional Storage bucket location in US, EU, and Asia using Google APIs over HTTP(S). Run the ETL process to retrieve the data from each Regional bucket

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 328

Contexto: [topics:99](#topics-99)
TerramEarth's 20 million vehicles are scattered around the world. Based on the vehicle's location, its telemetry data is stored in a Google Cloud Storage (GCS) regional bucket (US, Europe, or Asia). The CTO has asked you to run a report on the raw telemetry data to determine why vehicles are breaking down after 100 K miles. You want to run this job on all the data.
What is the most cost-effective way to run this job?

**A.** Move all the data into 1 zone, then launch a Cloud Dataproc cluster to run the job

**B.** Move all the data into 1 region, then launch a Google Cloud Dataproc cluster to run the job

**C.** Launch a cluster in each region to preprocess and compress the raw data, then move the data into a multi-region bucket and use a Dataproc cluster to finish the job

**D.** Launch a cluster in each region to preprocess and compress the raw data, then move the data into a region bucket and use a Cloud Dataproc cluster to finish the job

**Respuesta de la fuente:** D

**Explicación:** Option D is the most cost-effective because it minimizes cross-regional data egress charges by preprocessing and compressing data locally before transfer.
Moving uncompressed raw telemetry data across continents would incur prohibitive costs, whereas transferring smaller, compressed datasets significantly reduces network expenses.
Additionally, using a regional bucket instead of multi-region storage avoids higher storage fees while maintaining sufficient performance for the final Dataproc analysis job.

## Pregunta 329

Contexto: [topics:99](#topics-99)
TerramEarth has equipped all connected trucks with servers and sensors to collect telemetry data. Next year they want to use the data to train machine learning models. They want to store this data in the cloud while reducing costs.
What should they do?

**A.** Have the vehicle's computer compress the data in hourly snapshots, and store it in a Google Cloud Storage (GCS) Nearline bucket

**B.** Push the telemetry data in real-time to a streaming dataflow job that compresses the data, and store it in Google BigQuery

**C.** Push the telemetry data in real-time to a streaming dataflow job that compresses the data, and store it in Cloud Bigtable

**D.** Have the vehicle's computer compress the data in hourly snapshots, and store it in a GCS Coldline bucket

**Respuesta de la fuente:** D

**Explicación:** The requirement to use the data 'next year' implies a long storage duration with no immediate access needs. Google Cloud Storage Coldline is the most cost-effective option for infrequent access, as it offers the lowest storage rates among the choices provided.
Storing compressed snapshots in Coldline minimizes both the volume of stored data and the monthly storage costs compared to Nearline, BigQuery, or Bigtable.

## Pregunta 330

Contexto: [topics:99](#topics-99)
Your agricultural division is experimenting with fully autonomous vehicles. You want your architecture to promote strong security during vehicle operation.
Which two architectures should you consider? (Choose two.)

**A.** Treat every micro service call between modules on the vehicle as untrusted.

**B.** Require IPv6 for connectivity to ensure a secure address space.

**C.** Use a trusted platform module (TPM) and verify firmware and binaries on boot.

**D.** Use a functional programming language to isolate code execution cycles.

**E.** Use multiple connectivity subsystems for redundancy.

**F.** Enclose the vehicle's drive electronics in a Faraday cage to isolate chips.

**Respuesta de la fuente:** A, C

**Explicación:** Option A is correct because adopting a zero-trust architecture ensures that every microservice interaction is authenticated and encrypted, preventing lateral movement if one module is compromised.
Option C is correct because using a Trusted Platform Module (TPM) establishes a root of trust by cryptographically verifying firmware and binaries during boot, ensuring the vehicle's software integrity before operation begins.

## Pregunta 331

Contexto: [topics:99](#topics-99)
Operational parameters such as oil pressure are adjustable on each of TerramEarth's vehicles to increase their efficiency, depending on their environmental conditions. Your primary goal is to increase the operating efficiency of all 20 million cellular and unconnected vehicles in the field.
How can you accomplish this goal?

**A.** Have you engineers inspect the data for patterns, and then create an algorithm with rules that make operational adjustments automatically

**B.** Capture all operating data, train machine learning models that identify ideal operations, and run locally to make operational adjustments automatically

**C.** Implement a Google Cloud Dataflow streaming job with a sliding window, and use Google Cloud Messaging (GCM) to make operational adjustments automatically

**D.** Capture all operating data, train machine learning models that identify ideal operations, and host in Google Cloud Machine Learning (ML) Platform to make operational adjustments automatically

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because the case study specifies that only 200,000 of the 20 million vehicles are connected to a cellular network.
To increase efficiency for all vehicles, including the vast majority that are unconnected, operational adjustments must be executed locally on the vehicle's onboard computing modules rather than relying on cloud-hosted inference which requires real-time connectivity.

## Pregunta 332

Contexto: [topics:100](#topics-100)
For this question, refer to the TerramEarth case study. To be compliant with European GDPR regulation, TerramEarth is required to delete data generated from its
European customers after a period of 36 months when it contains personal data. In the new architecture, this data will be stored in both Cloud Storage and
BigQuery. What should you do?

**A.** Create a BigQuery table for the European data, and set the table retention period to 36 months. For Cloud Storage, use gsutil to enable lifecycle management using a DELETE action with an Age condition of 36 months.

**B.** Create a BigQuery table for the European data, and set the table retention period to 36 months. For Cloud Storage, use gsutil to create a SetStorageClass to NONE action when with an Age condition of 36 months.

**C.** Create a BigQuery time-partitioned table for the European data, and set the partition expiration period to 36 months. For Cloud Storage, use gsutil to enable lifecycle management using a DELETE action with an Age condition of 36 months.

**D.** Create a BigQuery time-partitioned table for the European data, and set the partition expiration period to 36 months. For Cloud Storage, use gsutil to create a SetStorageClass to NONE action with an Age condition of 36 months.

**Respuesta de la fuente:** C

**Explicación:** For BigQuery, time-partitioned tables with a partition expiration period allow the automatic deletion of specific old data partitions without dropping the entire table, ensuring only data older than 36 months is removed.
For Cloud Storage, lifecycle management rules with a DELETE action based on object age are required to automatically remove files after they exceed the retention period; 'SetStorageClass' cannot be set to NONE and does not delete objects.

## Pregunta 333

Contexto: [topics:100](#topics-100)
For this question, refer to the TerramEarth case study. TerramEarth has decided to store data files in Cloud Storage. You need to configure Cloud Storage lifecycle rule to store 1 year of data and minimize file storage cost.
Which two actions should you take?

**A.** Create a Cloud Storage lifecycle rule with Age: "30", Storage Class: "Standard", and Action: "Set to Coldline", and create a second GCS life-cycle rule with Age: "365", Storage Class: "Coldline", and Action: "Delete".

**B.** Create a Cloud Storage lifecycle rule with Age: "30", Storage Class: "Coldline", and Action: "Set to Nearline", and create a second GCS life-cycle rule with Age: "91", Storage Class: "Coldline", and Action: "Set to Nearline".

**C.** Create a Cloud Storage lifecycle rule with Age: "90", Storage Class: "Standard", and Action: "Set to Nearline", and create a second GCS life-cycle rule with Age: "91", Storage Class: "Nearline", and Action: "Set to Coldline".

**D.** Create a Cloud Storage lifecycle rule with Age: "30", Storage Class: "Standard", and Action: "Set to Coldline", and create a second GCS life-cycle rule with Age: "365", Storage Class: "Nearline", and Action: "Delete".

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it implements a lifecycle policy that retains data for one year and minimizes cost by transitioning objects to Coldline storage after 30 days. The second rule correctly targets the Coldline storage class to delete objects at age 365, satisfying the retention requirement.
Option D is incorrect because its deletion rule targets the Nearline storage class, but the data was moved to Coldline at day 30, so the condition would never match.

## Pregunta 334

Contexto: [topics:100](#topics-100)
For this question, refer to the TerramEarth case study. You need to implement a reliable, scalable GCP solution for the data warehouse for your company,
TerramEarth.
Considering the TerramEarth business and technical requirements, what should you do?

**A.** Replace the existing data warehouse with BigQuery. Use table partitioning.

**B.** Replace the existing data warehouse with a Compute Engine instance with 96 CPUs.

**C.** Replace the existing data warehouse with BigQuery. Use federated data sources.

**D.** Replace the existing data warehouse with a Compute Engine instance with 96 CPUs. Add an additional Compute Engine preemptible instance with 32 CPUs.

**Respuesta de la fuente:** A

**Explicación:** BigQuery is a fully managed, serverless data warehouse that scales automatically to handle TerramEarth's massive data ingest (9 TB/day) and complex analytical queries, eliminating the need for manual infrastructure management.
Table partitioning is critical for performance and cost optimization, allowing queries to scan only relevant subsets of time-series vehicle data rather than entire tables.
Federated sources (Option C) introduce significant latency and egress costs by querying external storage, which contradicts the requirement for low-latency analytics. Compute Engine instances (Options B and D) lack the managed scalability and query optimization inherent to BigQuery.

## Pregunta 335

Contexto: [topics:100](#topics-100)
For this question, refer to the TerramEarth case study. A new architecture that writes all incoming data to BigQuery has been introduced. You notice that the data is dirty, and want to ensure data quality on an automated daily basis while managing cost.
What should you do?

**A.** Set up a streaming Cloud Dataflow job, receiving data by the ingestion process. Clean the data in a Cloud Dataflow pipeline.

**B.** Create a Cloud Function that reads data from BigQuery and cleans it. Trigger the Cloud Function from a Compute Engine instance.

**C.** Create a SQL statement on the data in BigQuery, and save it as a view. Run the view daily, and save the result to a new table.

**D.** Use Cloud Dataprep and configure the BigQuery tables as the source. Schedule a daily job to clean the data.

**Respuesta de la fuente:** D

**Explicación:** Cloud Dataprep is the specialized tool for data cleansing and transformation within the Google Cloud ecosystem.
It allows you to visually prepare dirty data from BigQuery sources and schedule automated daily jobs.
This approach balances ease of use, cost-effectiveness, and reliability compared to building custom Dataflow pipelines or functions.

## Pregunta 336

Contexto: [topics:100](#topics-100)
For this question, refer to the TerramEarth case study. Considering the technical requirements, how should you reduce the unplanned vehicle downtime in GCP?

**A.** Use BigQuery as the data warehouse. Connect all vehicles to the network and stream data into BigQuery using Cloud Pub/Sub and Cloud Dataflow. Use Google Data Studio for analysis and reporting.

**B.** Use BigQuery as the data warehouse. Connect all vehicles to the network and upload gzip files to a Multi-Regional Cloud Storage bucket using gcloud. Use Google Data Studio for analysis and reporting.

**C.** Use Cloud Dataproc Hive as the data warehouse. Upload gzip files to a Multi-Regional Cloud Storage bucket. Upload this data into BigQuery using gcloud. Use Google Data Studio for analysis and reporting.

**D.** Use Cloud Dataproc Hive as the data warehouse. Directly stream data into partitioned Hive tables. Use Pig scripts to analyze data.

**Respuesta de la fuente:** A

**Explicación:** To reduce unplanned downtime from weeks to less than a week, TerramEarth must replace its batch-oriented FTP/CSV process with real-time data ingestion. Option A is correct because it uses Cloud Pub/Sub and Cloud Dataflow to stream telemetry directly from connected vehicles into BigQuery, enabling immediate analysis for predictive maintenance.
Other options are incorrect because they rely on manual file uploads (B, C) or less optimal batch processing frameworks like Dataproc/Hive/Pig (C, D), which do not provide the low-latency insights required by the technical requirements.

## Pregunta 337

Contexto: [topics:100](#topics-100)
For this question, refer to the TerramEarth case study. You are asked to design a new architecture for the ingestion of the data of the 200,000 vehicles that are connected to a cellular network. You want to follow Google-recommended practices.
Considering the technical requirements, which components should you use for the ingestion of the data?

**A.** Google Kubernetes Engine with an SSL Ingress

**B.** Cloud IoT Core with public/private key pairs

**C.** Compute Engine with project-wide SSH keys

**D.** Compute Engine with specific SSH keys

**Respuesta de la fuente:** B

**Explicación:** Cloud IoT Core is the specialized Google Cloud service designed for securely connecting massive numbers of IoT devices to Google Cloud.
It natively supports authentication via public/private key pairs (using JWTs), which satisfies the technical requirement to increase the security of data transfers from the vehicles.

## Pregunta 338

Contexto: [topics:101](#topics-101)
For this question, refer to the TerramEarth case study. You start to build a new application that uses a few Cloud Functions for the backend. One use case requires a Cloud Function func_display to invoke another Cloud Function func_query. You want func_query only to accept invocations from func_display. You also want to follow Google's recommended best practices. What should you do?

**A.** Create a token and pass it in as an environment variable to func_display. When invoking func_query, include the token in the request. Pass the same token to func_query and reject the invocation if the tokens are different.

**B.** Make func_query 'Require authentication.' Create a unique service account and associate it to func_display. Grant the service account invoker role for func_query. Create an id token in func_display and include the token to the request when invoking func_query.

**C.** Make func_query 'Require authentication' and only accept internal traffic. Create those two functions in the same VPC. Create an ingress firewall rule for func_query to only allow traffic from func_display.

**D.** Create those two functions in the same project and VPC. Make func_query only accept internal traffic. Create an ingress firewall for func_query to only allow traffic from func_display. Also, make sure both functions use the same service account.

**Respuesta de la fuente:** B

**Explicación:** To restrict invocation of func_query exclusively to func_display using Google Cloud best practices, you must enable authentication on the receiving function and leverage Identity and Access Management (IAM). Specifically, assign a dedicated service account to func_display and grant it the 'Cloud Functions Invoker' role on func_query. Finally, configure func_display to obtain and send an ID token in the Authorization header when invoking func_query, ensuring secure, authenticated communication.

## Pregunta 339

Contexto: [topics:101](#topics-101)
For this question, refer to the TerramEarth case study. You have broken down a legacy monolithic application into a few containerized RESTful microservices.
You want to run those microservices on Cloud Run. You also want to make sure the services are highly available with low latency to your customers. What should you do?

**A.** Deploy Cloud Run services to multiple availability zones. Create Cloud Endpoints that point to the services. Create a global HTTP(S) Load Balancing instance and attach the Cloud Endpoints to its backend.

**B.** Deploy Cloud Run services to multiple regions. Create serverless network endpoint groups pointing to the services. Add the serverless NEGs to a backend service that is used by a global HTTP(S) Load Balancing instance.

**C.** Deploy Cloud Run services to multiple regions. In Cloud DNS, create a latency-based DNS name that points to the services.

**D.** Deploy Cloud Run services to multiple availability zones. Create a TCP/IP global load balancer. Add the Cloud Run Endpoints to its backend service.

**Respuesta de la fuente:** B

**Explicación:** Cloud Run is a regional service, so deploying to multiple regions is necessary for global high availability and low latency. To route traffic across these regions, you must use Global HTTP(S) Load Balancing with Serverless Network Endpoint Groups (NEGs), which are specifically designed to integrate serverless backends like Cloud Run into the load balancer's backend service.

## Pregunta 340

Contexto: [topics:101](#topics-101)
For this question, refer to the TerramEarth case study. You are migrating a Linux-based application from your private data center to Google Cloud. The
TerramEarth security team sent you several recent Linux vulnerabilities published by Common Vulnerabilities and Exposures (CVE). You need assistance in understanding how these vulnerabilities could impact your migration. What should you do? (Choose two.)

**A.** Open a support case regarding the CVE and chat with the support engineer.

**B.** Read the CVEs from the Google Cloud Status Dashboard to understand the impact.

**C.** Read the CVEs from the Google Cloud Platform Security Bulletins to understand the impact.

**D.** Post a question regarding the CVE in Stack Overflow to get an explanation.

**E.** Post a question regarding the CVE in a Google Cloud discussion group to get an explanation.

**Respuesta de la fuente:** A, C

**Explicación:** You should open a support case (A) to receive expert guidance tailored to your specific environment and migration path. Additionally, consulting Google Cloud Platform Security Bulletins (C) provides official documentation on how identified CVEs impact Google-managed infrastructure and services.

## Pregunta 341

Contexto: [topics:101](#topics-101)
For this question, refer to the TerramEarth case study. TerramEarth has a legacy web application that you cannot migrate to cloud. However, you still want to build a cloud-native way to monitor the application. If the application goes down, you want the URL to point to a "Site is unavailable" page as soon as possible. You also want your Ops team to receive a notification for the issue. You need to build a reliable solution for minimum cost. What should you do?

**A.** Create a scheduled job in Cloud Run to invoke a container every minute. The container will check the application URL. If the application is down, switch the URL to the "Site is unavailable" page, and notify the Ops team.

**B.** Create a cron job on a Compute Engine VM that runs every minute. The cron job invokes a Python program to check the application URL. If the application is down, switch the URL to the "Site is unavailable" page, and notify the Ops team.

**C.** Create a Cloud Monitoring uptime check to validate the application URL. If it fails, put a message in a Pub/Sub queue that triggers a Cloud Function to switch the URL to the "Site is unavailable" page, and notify the Ops team.

**D.** Use Cloud Error Reporting to check the application URL. If the application is down, switch the URL to the "Site is unavailable" page, and notify the Ops team.

**Respuesta de la fuente:** C

**Explicación:** Cloud Monitoring uptime checks are the native solution for validating external HTTP endpoints, including legacy on-premises applications accessible via the internet.
Using Pub/Sub to trigger a Cloud Function upon failure ensures an event-driven, serverless architecture that meets the 'cloud-native' requirement while maintaining minimal operational cost.
This approach avoids the overhead of managing VMs or scheduled containers required by options A and B, and unlike Error Reporting (D), it actively monitors availability rather than just aggregating application logs.

## Pregunta 342

Contexto: [topics:101](#topics-101)
For this question, refer to the TerramEarth case study. You are building a microservice-based application for TerramEarth. The application is based on Docker containers. You want to follow Google-recommended practices to build the application continuously and store the build artifacts. What should you do?

**A.** Configure a trigger in Cloud Build for new source changes. Invoke Cloud Build to build container images for each microservice, and tag them using the code commit hash. Push the images to the Container Registry.

**B.** Configure a trigger in Cloud Build for new source changes. The trigger invokes build jobs and build container images for the microservices. Tag the images with a version number, and push them to Cloud Storage.

**C.** Create a Scheduler job to check the repo every minute. For any new change, invoke Cloud Build to build container images for the microservices. Tag the images using the current timestamp, and push them to the Container Registry.

**D.** Configure a trigger in Cloud Build for new source changes. Invoke Cloud Build to build one container image, and tag the image with the label 'latest.' Push the image to the Container Registry.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it follows Google-recommended practices by using Cloud Build triggers for automation and tagging images with the Git commit hash to ensure reproducible builds and traceability.
It also correctly pushes container images to Container Registry, which is the designated service for storing container artifacts.
Option B is incorrect because Cloud Storage is not used for hosting pullable container images; Option C is inefficient compared to event-driven triggers; and Option D lacks unique tagging strategies necessary for managing multiple microservice versions.

## Pregunta 343

Contexto: [topics:101](#topics-101)
For this question, refer to the TerramEarth case study. TerramEarth has about 1 petabyte (PB) of vehicle testing data in a private data center. You want to move the data to Cloud Storage for your machine learning team. Currently, a 1-Gbps interconnect link is available for you. The machine learning team wants to start using the data in a month. What should you do?

**A.** Request Transfer Appliances from Google Cloud, export the data to appliances, and return the appliances to Google Cloud.

**B.** Configure the Storage Transfer service from Google Cloud to send the data from your data center to Cloud Storage.

**C.** Make sure there are no other users consuming the 1Gbps link, and use multi-thread transfer to upload the data to Cloud Storage.

**D.** Export files to an encrypted USB device, send the device to Google Cloud, and request an import of the data to Cloud Storage.

**Respuesta de la fuente:** A

**Explicación:** Migrating 1 PB of data over a 1 Gbps link would take approximately 93 days, which exceeds the one-month deadline. Google Cloud Transfer Appliance is designed for large-scale offline transfers (hundreds of TBs to PBs) and can complete the migration within the required timeframe by shipping physical storage devices.

## Pregunta 344

Contexto: [topics:102](#topics-102)
The Dress4Win security team has disabled external SSH access into production virtual machines (VMs) on Google Cloud Platform (GCP).
The operations team needs to remotely manage the VMs, build and push Docker containers, and manage Google Cloud Storage objects.
What can they do?

**A.** Grant the operations engineer access to use Google Cloud Shell.

**B.** Configure a VPN connection to GCP to allow SSH access to the cloud VMs.

**C.** Develop a new access request process that grants temporary SSH access to cloud VMs when an operations engineer needs to perform a task.

**D.** Have the development team build an API service that allows the operations team to execute specific remote procedure calls to accomplish their tasks.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Shell provides a pre-configured web-based development environment with the Google Cloud SDK installed, allowing operations teams to manage VMs, build Docker containers via `docker` commands, and handle Cloud Storage objects using `gsutil` without requiring direct SSH access.
This approach adheres to IAM best practices by eliminating the need for insecure network-level access like open SSH ports or VPN tunnels while maintaining full administrative capabilities through the command line.

## Pregunta 345

Contexto: [topics:102](#topics-102)
At Dress4Win, an operations engineer wants to create a tow-cost solution to remotely archive copies of database backup files.
The database files are compressed tar files stored in their current data center.
How should he proceed?

**A.** Create a cron script using gsutil to copy the files to a Coldline Storage bucket.

**B.** Create a cron script using gsutil to copy the files to a Regional Storage bucket.

**C.** Create a Cloud Storage Transfer Service Job to copy the files to a Coldline Storage bucket.

**D.** Create a Cloud Storage Transfer Service job to copy the files to a Regional Storage bucket.

**Respuesta de la fuente:** C

**Explicación:** The case study indicates Dress4Win has significant data volumes (600+ TB used), exceeding the <1 TB threshold where gsutil is recommended. Google Cloud documentation specifies using Cloud Storage Transfer Service for on-premises transfers larger than 1 TB due to reliability and performance.
Coldline Storage is chosen over Regional Storage because it is designed for infrequent access, making it the lower-cost option for remote archival backups.

## Pregunta 346

Contexto: [topics:102](#topics-102)
Dress4Win has asked you to recommend machine types they should deploy their application servers to.
How should you proceed?

**A.** Perform a mapping of the on-premises physical hardware cores and RAM to the nearest machine types in the cloud.

**B.** Recommend that Dress4Win deploy application servers to machine types that offer the highest RAM to CPU ratio available.

**C.** Recommend that Dress4Win deploy into production with the smallest instances available, monitor them over time, and scale the machine type up until the desired performance is reached.

**D.** Identify the number of virtual cores and RAM associated with the application server virtual machines align them to a custom machine type in the cloud, monitor performance, and scale the machine types up until the desired performance is reached.

**Respuesta de la fuente:** D

**Explicación:** The correct approach is to map the existing on-premises virtual machine specifications (vCPUs and RAM) to a comparable custom or predefined machine type in the cloud to establish a performance baseline.
Starting with an equivalent configuration ensures the application functions correctly during the initial migration phase, particularly for disaster recovery or production parity requirements mentioned in the case study.
Once deployed, you should monitor performance metrics and then scale up or down as needed to optimize costs and performance, rather than guessing with the smallest possible instance which may cause failures.

## Pregunta 347

Contexto: [topics:102](#topics-102)
As part of Dress4Win's plans to migrate to the cloud, they want to be able to set up a managed logging and monitoring system so they can handle spikes in their traffic load.
They want to ensure that:
* The infrastructure can be notified when it needs to scale up and down to handle the ebb and flow of usage throughout the day
* Their administrators are notified automatically when their application reports errors.
* They can filter their aggregated logs down in order to debug one piece of the application across many hosts
Which Google StackDriver features should they use?

**A.** Logging, Alerts, Insights, Debug

**B.** Monitoring, Trace, Debug, Logging

**C.** Monitoring, Logging, Alerts, Error Reporting

**D.** Monitoring, Logging, Debug, Error Report

**Respuesta de la fuente:** C

**Explicación:** The correct answer is C because it directly maps to the three specific requirements: Monitoring handles autoscaling notifications, Logging allows filtering aggregated logs for debugging across hosts, and Error Reporting provides automatic notifications for application errors.
Option D is incorrect because Cloud Debugger (Debug) is an interactive tool for live code inspection, not a mechanism for automated error notification or log aggregation filtering.

## Pregunta 348

Contexto: [topics:102](#topics-102)
Dress4Win would like to become familiar with deploying applications to the cloud by successfully deploying some applications quickly, as is. They have asked for your recommendation.
What should you advise?

**A.** Identify self-contained applications with external dependencies as a first move to the cloud.

**B.** Identify enterprise applications with internal dependencies and recommend these as a first move to the cloud.

**C.** Suggest moving their in-house databases to the cloud and continue serving requests to on-premise applications.

**D.** Recommend moving their message queuing servers to the cloud and continue handling requests to on-premise applications.

**Respuesta de la fuente:** A

**Explicación:** To gain familiarity with cloud deployment quickly and with minimal risk, Dress4Win should start with self-contained applications that have external dependencies but no internal ties to on-premise systems.

Moving these isolated workloads allows the team to validate cloud processes without disrupting critical enterprise architecture or dealing with complex cross-network latency issues inherent in partially migrated environments.

## Pregunta 349

Contexto: [topics:102](#topics-102)
Dress4Win has asked you for advice on how to migrate their on-premises MySQL deployment to the cloud.
They want to minimize downtime and performance impact to their on-premises solution during the migration.
Which approach should you recommend?

**A.** Create a dump of the on-premises MySQL master server, and then shut it down, upload it to the cloud environment, and load into a new MySQL cluster.

**B.** Setup a MySQL replica server/slave in the cloud environment, and configure it for asynchronous replication from the MySQL master server on-premises until cutover.

**C.** Create a new MySQL cluster in the cloud, configure applications to begin writing to both on premises and cloud MySQL masters, and destroy the original cluster at cutover.

**D.** Create a dump of the MySQL replica server into the cloud environment, load it into: Google Cloud Datastore, and configure applications to read/write to Cloud Datastore at cutover.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because setting up asynchronous replication allows the on-premises MySQL master to continue serving traffic with minimal performance overhead while replicating data changes to the cloud replica.
This setup enables a near-zero downtime cutover by simply promoting the cloud replica to primary and redirecting application traffic, avoiding the long outage required for a full dump/load process.

## Pregunta 350

Contexto: [topics:102](#topics-102)
Dress4Win has configured a new uptime check with Google Stackdriver for several of their legacy services. The Stackdriver dashboard is not reporting the services as healthy.
What should they do?

**A.** Install the Stackdriver agent on all of the legacy web servers.

**B.** In the Cloud Platform Console download the list of the uptime servers' IP addresses and create an inbound firewall rule

**C.** Configure their load balancer to pass through the User-Agent HTTP header when the value matches GoogleStackdriverMonitoring-UptimeChecks (https:// cloud.google.com/monitoring)

**D.** Configure their legacy web servers to allow requests that contain user-Agent HTTP header when the value matches GoogleStackdriverMonitoring- UptimeChecks (https://cloud.google.com/monitoring)

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Uptime Checks are performed from specific IP addresses. For legacy services hosted on-premises (legacy web servers), the external firewall blocking these checks must be configured to allow inbound traffic from those specific IPs.
Downloading the list of uptime check source IPs and creating an inbound allow rule on the on-premise perimeter firewall is the required step to permit the health check probes to reach the services.

## Pregunta 351

Contexto: [topics:102](#topics-102)
As part of their new application experience, Dress4Wm allows customers to upload images of themselves.
The customer has exclusive control over who may view these images.
Customers should be able to upload images with minimal latency and also be shown their images quickly on the main application page when they log in.
Which configuration should Dress4Win use?

**A.** Store image files in a Google Cloud Storage bucket. Use Google Cloud Datastore to maintain metadata that maps each customer's ID and their image files.

**B.** Store image files in a Google Cloud Storage bucket. Add custom metadata to the uploaded images in Cloud Storage that contains the customer's unique ID.

**C.** Use a distributed file system to store customers' images. As storage needs increase, add more persistent disks and/or nodes. Assign each customer a unique ID, which sets each file's owner attribute, ensuring privacy of images.

**D.** Use a distributed file system to store customers' images. As storage needs increase, add more persistent disks and/or nodes. Use a Google Cloud SQL database to maintain metadata that maps each customer's ID to their image files.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Storage (GCS) is the optimal service for storing unstructured data like images due to its high availability, scalability, and low latency for read/write operations.
Using Google Cloud Datastore to manage metadata and access control allows for efficient querying and enforces the requirement that customers have exclusive control over who views their images, which custom object metadata in GCS cannot effectively support.

## Pregunta 352

Contexto: [topics:102](#topics-102)
Dress4Win has end-to-end tests covering 100% of their endpoints.
They want to ensure that the move to the cloud does not introduce any new bugs.
Which additional testing methods should the developers employ to prevent an outage?

**A.** They should enable Google Stackdriver Debugger on the application code to show errors in the code.

**B.** They should add additional unit tests and production scale load tests on their cloud staging environment.

**C.** They should run the end-to-end tests in the cloud staging environment to determine if the code is working as intended.

**D.** They should add canary tests so developers can measure how much of an impact the new release causes to latency.

**Respuesta de la fuente:** B

**Explicación:** The question explicitly asks for *additional* testing methods. Since Dress4Win already has 100% end-to-end test coverage (Option C repeats existing tests), they must adopt new strategies to prevent outages in a cloud environment.

Adding unit tests ensures code correctness at the component level, which is critical if applications are refactored for managed services. Implementing production-scale load testing is essential to validate auto-scaling configurations and performance under expected traffic patterns, directly preventing capacity-related outages during migration.

## Pregunta 353

Contexto: [topics:102](#topics-102)
You want to ensure Dress4Win's sales and tax records remain available for infrequent viewing by auditors for at least 10 years.
Cost optimization is your top priority.
Which cloud services should you choose?

**A.** Google Cloud Storage Coldline to store the data, and gsutil to access the data.

**B.** Google Cloud Storage Nearline to store the data, and gsutil to access the data.

**C.** Google Bigtabte with US or EU as location to store the data, and gcloud to access the data.

**D.** BigQuery to store the data, and a web server cluster in a managed instance group to access the data. Google Cloud SQL mirrored across two distinct regions to store the data, and a Redis cluster in a managed instance group to access the data.

**Respuesta de la fuente:** A

**Explicación:** The requirement for storing data for at least 10 years with infrequent access and a primary focus on cost optimization points to a long-term archival storage class.
Among the choices, Google Cloud Storage Coldline is designed for infrequently accessed data retained for months or years, offering lower storage costs than Nearline while meeting the availability needs of auditors.
Bigtable and BigQuery are database and analytics services, respectively, making them inappropriate and cost-ineffective for simple static file retention.

## Pregunta 354

Contexto: [topics:102](#topics-102)
The current Dress4Win system architecture has high latency to some customers because it is located in one data center.
As of a future evaluation and optimizing for performance in the cloud, Dresss4Win wants to distribute its system architecture to multiple locations when Google cloud platform.
Which approach should they use?

**A.** Use regional managed instance groups and a global load balancer to increase performance because the regional managed instance group can grow instances in each region separately based on traffic.

**B.** Use a global load balancer with a set of virtual machines that forward the requests to a closer group of virtual machines managed by your operations team.

**C.** Use regional managed instance groups and a global load balancer to increase reliability by providing automatic failover between zones in different regions.

**D.** Use a global load balancer with a set of virtual machines that forward the requests to a closer group of virtual machines as part of a separate managed instance groups.

**Respuesta de la fuente:** A

**Explicación:** The primary goal is to reduce latency by distributing the architecture across multiple locations on Google Cloud Platform. A Global Load Balancer (GLB) directs user traffic to the backend nearest to them, thereby minimizing round-trip time. Regional Managed Instance Groups (MIGs) allow for independent scaling of instances within each specific region based on local traffic demand.

Combining GLB with regional MIGs ensures that requests are served from the closest available resources while maintaining high availability and performance optimization.

## Pregunta 355

Contexto: [topics:103](#topics-103)
For this question, refer to the Dress4Win case study. Dress4Win is expected to grow to 10 times its size in 1 year with a corresponding growth in data and traffic that mirrors the existing patterns of usage. The CIO has set the target of migrating production infrastructure to the cloud within the next 6 months. How will you configure the solution to scale for this growth without making major application changes and still maximize the ROI?

**A.** Migrate the web application layer to App Engine, and MySQL to Cloud Datastore, and NAS to Cloud Storage. Deploy RabbitMQ, and deploy Hadoop servers using Deployment Manager.

**B.** Migrate RabbitMQ to Cloud Pub/Sub, Hadoop to BigQuery, and NAS to Compute Engine with Persistent Disk storage. Deploy Tomcat, and deploy Nginx using Deployment Manager.

**C.** Implement managed instance groups for Tomcat and Nginx. Migrate MySQL to Cloud SQL, RabbitMQ to Cloud Pub/Sub, Hadoop to Cloud Dataproc, and NAS to Compute Engine with Persistent Disk storage.

**D.** Implement managed instance groups for the Tomcat and Nginx. Migrate MySQL to Cloud SQL, RabbitMQ to Cloud Pub/Sub, Hadoop to Cloud Dataproc, and NAS to Cloud Storage.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it maps each existing on-premises technology to the most appropriate managed GCP service to ensure scalability and high ROI. Specifically, Managed Instance Groups handle dynamic scaling for web servers, Cloud SQL manages MySQL, Cloud Pub/Sub replaces RabbitMQ, Cloud Dataproc runs Hadoop workloads, and Cloud Storage (GCS) provides a cost-effective, scalable object store for the NAS data (images, logs, backups), avoiding the higher costs of Persistent Disks.

## Pregunta 356

Contexto: [topics:103](#topics-103)
For this question, refer to the Dress4Win case study. Considering the given business requirements, how would you automate the deployment of web and transactional data layers?

**A.** Deploy Nginx and Tomcat using Cloud Deployment Manager to Compute Engine. Deploy a Cloud SQL server to replace MySQL. Deploy Jenkins using Cloud Deployment Manager.

**B.** Deploy Nginx and Tomcat using Cloud Launcher. Deploy a MySQL server using Cloud Launcher. Deploy Jenkins to Compute Engine using Cloud Deployment Manager scripts.

**C.** Migrate Nginx and Tomcat to App Engine. Deploy a Cloud Datastore server to replace the MySQL server in a high-availability configuration. Deploy Jenkins to Compute Engine using Cloud Launcher.

**D.** Migrate Nginx and Tomcat to App Engine. Deploy a MySQL server using Cloud Launcher. Deploy Jenkins to Compute Engine using Cloud Launcher.

**Respuesta de la fuente:** A

**Explicación:** Options C and D are incorrect because Cloud Datastore is a NoSQL database, which is not a direct replacement for the existing MySQL relational database without significant refactoring. Option A is the correct choice as it uses Cloud Deployment Manager to provision Compute Engine instances for the web servers (Nginx/Tomcat) and Jenkins, ensuring an automated, reproducible infrastructure framework as required. It also correctly migrates the MySQL workload to Cloud SQL, which provides managed relational database services compatible with the existing application.

## Pregunta 357

Contexto: [topics:103](#topics-103)
For this question, refer to the Dress4Win case study. Which of the compute services should be migrated as-is and would still be an optimized architecture for performance in the cloud?

**A.** Web applications deployed using App Engine standard environment

**B.** RabbitMQ deployed using an unmanaged instance group

**C.** Hadoop/Spark deployed using Cloud Dataproc Regional in High Availability mode

**D.** Jenkins, monitoring, bastion hosts, security scanners services deployed on custom machine types

**Respuesta de la fuente:** C

**Explicación:** The case study requires migrating compute services 'as-is' that remain optimized for performance. Cloud Dataproc is a managed Hadoop and Spark service that allows the existing data analysis workloads to run in the cloud without requiring application code changes, satisfying the 'as-is' migration criteria while leveraging cloud-native high availability and scalability. Other options like App Engine require refactoring (not as-is), and generic VMs (Option D) do not offer the specific performance optimization of a managed big data service.

## Pregunta 358

Contexto: [topics:103](#topics-103)
For this question, refer to the Dress4Win case study. To be legally compliant during an audit, Dress4Win must be able to give insights in all administrative actions that modify the configuration or metadata of resources on Google Cloud.
What should you do?

**A.** Use Stackdriver Trace to create a Trace list analysis.

**B.** Use Stackdriver Monitoring to create a dashboard on the project's activity.

**C.** Enable Cloud Identity-Aware Proxy in all projects, and add the group of Administrators as a member.

**D.** Use the Activity page in the GCP Console and Stackdriver Logging to provide the required insight.

**Respuesta de la fuente:** D

**Explicación:** Cloud Audit Logs automatically record administrative actions (admin activities) and data access across Google Cloud services to ensure compliance and accountability.
These logs are accessed via the Activity page in the GCP Console and Stackdriver Logging, providing the necessary insight into configuration and metadata changes.
Other options like Trace, Monitoring, or IAP serve different purposes such as performance debugging, metrics visualization, or secure access control, not audit logging.

## Pregunta 359

Contexto: [topics:103](#topics-103)
For this question, refer to the Dress4Win case study. You are responsible for the security of data stored in Cloud Storage for your company, Dress4Win. You have already created a set of Google Groups and assigned the appropriate users to those groups. You should use Google best practices and implement the simplest design to meet the requirements.
Considering Dress4Win's business and technical requirements, what should you do?

**A.** Assign custom IAM roles to the Google Groups you created in order to enforce security requirements. Encrypt data with a customer-supplied encryption key when storing files in Cloud Storage.

**B.** Assign custom IAM roles to the Google Groups you created in order to enforce security requirements. Enable default storage encryption before storing files in Cloud Storage.

**C.** Assign predefined IAM roles to the Google Groups you created in order to enforce security requirements. Utilize Google's default encryption at rest when storing files in Cloud Storage.

**D.** Assign predefined IAM roles to the Google Groups you created in order to enforce security requirements. Ensure that the default Cloud KMS key is set before storing files in Cloud Storage.

**Respuesta de la fuente:** C

**Explicación:** The question explicitly asks for the "simplest design" that meets requirements using best practices.
Google Cloud Storage automatically encrypts all data at rest by default, satisfying the encryption requirement without additional configuration or key management overhead (unlike CSEK/CMEK).
While custom roles are often recommended for least privilege in production, predefined IAM roles are sufficient to assign permissions to groups and represent a simpler initial design compared to creating and maintaining custom roles.

## Pregunta 360

Contexto: [topics:103](#topics-103)
For this question, refer to the Dress4Win case study. You want to ensure that your on-premises architecture meets business requirements before you migrate your solution.
What change in the on-premises architecture should you make?

**A.** Replace RabbitMQ with Google Pub/Sub.

**B.** Downgrade MySQL to v5.7, which is supported by Cloud SQL for MySQL.

**C.** Resize compute resources to match predefined Compute Engine machine types.

**D.** Containerize the micro-services and host them in Google Kubernetes Engine.

**Respuesta de la fuente:** D

**Explicación:** The Dress4Win case study (as updated by Google) specifies MySQL version 5.7, which is natively supported by Cloud SQL, rendering option B invalid as a required change.
Option D is correct because containerizing micro-services allows for consistent deployment across on-premises and cloud environments using Anthos/GKE, meeting the requirement to analyze and optimize architecture before migration.
Replacing RabbitMQ with Pub/Sub (A) or resizing compute resources (C) does not address the need for reproducible environments or architectural optimization for migration.