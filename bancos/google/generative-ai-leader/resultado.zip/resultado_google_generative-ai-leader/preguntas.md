# generative ai leader

75 / 75 preguntas. Cobertura completa: True.

Respuestas de la fuente; revisión técnica pendiente. Las imágenes permanecen en sus campos de origen.

75 respuestas conservadas; 0 pendientes.

<a id="topics-88"></a>
## Contexto topics:88
name:
Topic 1

<a id="topics-89"></a>
## Contexto topics:89
name:
Topic 2

<a id="topics-90"></a>
## Contexto topics:90
name:
Topic 3

<a id="topics-91"></a>
## Contexto topics:91
name:
Topic 4


## Pregunta 1

Contexto: [topics:88](#topics-88)
What is the definition of generative AI?

**A.** A type of predictive model that estimates a relationship by fitting a line to the observed data.

**B.** A type of artificial intelligence that can create new content and ideas, including text, images, music, and code.

**C.** A type of machine learning algorithm inspired by the human brain that is made up of interconnected nodes.

**D.** A type of artificial intelligence that enables a system to autonomously learn and improve using neural networks and deep learning.

**Respuesta de la fuente:** B

**Explicación:** Generative AI is defined by its ability to create new content, such as text, images, or code, rather than simply analyzing existing data. Option A describes regression analysis, C defines neural networks generally, and D describes deep learning broadly, none of which capture the specific generative capability.

## Pregunta 2

Contexto: [topics:88](#topics-88)
A company wants to use an AI agent to automate some tasks. They want everyone to understand the different functions of an AI agent. What is the function of an AI agent in the context of gen AI?

**A.** To provide the computational resources needed to train and run gen AI models.

**B.** To store and manage large datasets used for training and running gen AI models.

**C.** To provide a user-friendly interface for interacting with gen AI models.

**D.** To analyze situations, use multiple tools, and make informed decisions without requiring constant human input.

**Respuesta de la fuente:** D

**Explicación:** An AI agent in the context of generative AI is defined by its ability to act autonomously. Unlike passive models that simply generate text, an agent analyzes a situation, selects and uses tools (such as APIs or search engines), and makes decisions to achieve goals with minimal human intervention.

## Pregunta 3

Contexto: [topics:88](#topics-88)
What is the definition of an AI agent?

**A.** An application that learns how to achieve a goal based on inputs and tools available to it.

**B.** A human expert who oversees and manages the operation of a gen AI application.

**C.** A type of user interface that allows users to interact with a gen AI application.

**D.** A static component of a gen AI application that provides information to the user.

**Respuesta de la fuente:** A

**Explicación:** An AI agent is defined as an autonomous system that perceives its environment, makes decisions, and takes actions to achieve specific goals. Option A correctly describes this functionality by highlighting the agent's ability to learn from inputs and utilize available tools. The other options describe human roles, user interfaces, or static components, which do not fit the technical definition of an autonomous AI entity.

## Pregunta 4

Contexto: [topics:88](#topics-88)
A company is developing an AI character for a video game. The AI character needs to learn how to navigate a complex environment and make decisions to achieve certain objectives within the game. When the AI takes actions that lead to positive outcomes like finding a reward or overcoming an obstacle, it receives a positive score. When it takes actions that lead to negative outcomes, like hitting a wall or losing progress, it receives a negative score. Through this process of trial and error, the AI gradually improves the character’s ability to play the game effectively. What machine learning should the company use?

**A.** Unsupervised learning

**B.** Reinforcement learning

**C.** Supervised learning

**D.** Deep learning

**Respuesta de la fuente:** B

**Explicación:** Reinforcement learning is defined by an agent interacting with an environment through trial and error to maximize cumulative rewards.
The scenario explicitly describes receiving positive or negative scores based on actions, which aligns directly with the reward-penalty mechanism of reinforcement learning rather than labeled data supervision or unsupervised pattern clustering.

## Pregunta 5

Contexto: [topics:88](#topics-88)
A research team has collected a large dataset of sensor readings from various industrial machines. This dataset includes measurements like temperature, pressure vibration levels and electrical current recorded at regular intervals. The team has not yet assigned any labels or categories to these readings and wants to identify potential anomalies, malfunctions or natural groupings of machine behavior based on the sensor data alone. What type of machine learning should they use?

**A.** Deep learning

**B.** Reinforcement learning

**C.** Supervised learning

**D.** Unsupervised learning

**Respuesta de la fuente:** D

**Explicación:** Unsupervised learning is the correct choice because the dataset lacks labels or categories, which excludes supervised learning. The goal of identifying natural groupings and anomalies from unlabeled data aligns directly with unsupervised techniques like clustering and anomaly detection.

## Pregunta 6

Contexto: [topics:88](#topics-88)
A highly regulated financial institution wants to use Gemini as the core decision engine for a loan approval system that will deterministically approve or reject loan applications based on a strict set of predefined criteria. Why is this an inappropriate use case for Gemini?

**A.** Gemini deployment for this scenario would be too expensive and complex.

**B.** Gemini’s designed for flexible content generation and inference, not rigid rule-based decisions.

**C.** Gemini is not equipped to handle structured numerical data for financial assessments.

**D.** Gemini cannot integrate with required financial databases.

**Respuesta de la fuente:** B

**Explicación:** Gemini is a generative AI model designed for probabilistic reasoning and content generation rather than deterministic execution. In highly regulated financial contexts requiring strict, consistent rule-based decisions, the non-deterministic nature of generative models poses a significant compliance risk. Traditional rule-based systems are far more appropriate for ensuring the exact reproducibility and auditability required for loan approvals.

## Pregunta 7

Contexto: [topics:88](#topics-88)
What is an example of unsupervised machine learning?

**A.** Predicting subscription renewal based on past renewal status data.

**B.** Training a system to recognize product images using labeled categories.

**C.** Analyzing customer purchase patterns to identify natural groupings.

**D.** Forecasting sales figures using historical sales and marketing spend.

**Respuesta de la fuente:** C

**Explicación:** Unsupervised machine learning algorithms identify patterns and structures within unlabeled data without predefined categories.
Option C describes clustering, a core unsupervised technique used to discover natural groupings in customer purchase data.
The other options involve supervised learning tasks such as classification or regression, which rely on labeled historical data to predict specific outcomes.

## Pregunta 8

Contexto: [topics:88](#topics-88)
A user asks a generative AI model about the scientific accuracy of a popular science fiction movie. The model confidently states that humans can indeed travel faster than light, referencing specific but entirely fictional theories and providing made-up explanations of how this is achieved according to the movie's "established science." The model presents this information as factual, without indicating that it originates from a fictional work. What type of model limitation is this?

**A.** Bias

**B.** Hallucination

**C.** Knowledge cutoff

**D.** Data dependency

**Respuesta de la fuente:** B

**Explicación:** This scenario describes a hallucination, where the generative AI model generates plausible-sounding but factually incorrect information. The model invents scientific theories and presents fictional movie concepts as real-world facts, which is the defining characteristic of this limitation.

## Pregunta 9

Contexto: [topics:88](#topics-88)
What does a diffusion model do?

**A.** Generates high-quality content by refining noise into structured data.

**B.** Facilitates the storage and management of structured data.

**C.** Analyzes data and predicts future trends and patterns.

**D.** Optimizes business processes and resource allocation.

**Respuesta de la fuente:** A

**Explicación:** Diffusion models are generative AI algorithms that create data by learning to reverse a gradual noising process. They start with random noise and iteratively refine it into structured, high-quality outputs such as images or text.
Options B, C, and D describe database management, predictive analytics, and business optimization, which are unrelated to the core function of diffusion models.

## Pregunta 10

Contexto: [topics:88](#topics-88)
An organization is collecting data to train a generative AI model for customer service. They want to ensure security throughout the ML lifecycle. What is a critical consideration at this stage?

**A.** Applying the latest software patches to the AI model on a regular basis.

**B.** Monitoring the AI model’s performance for unexpected outputs and potential errors.

**C.** Establishing ethical guidelines for AI model responses to ensure fairness and avoid harm.

**D.** Implementing access controls and protecting sensitive information within the training data.

**Respuesta de la fuente:** D

**Explicación:** The question specifically addresses the data collection phase of the ML lifecycle, where the primary security risk involves the ingestion of sensitive or personally identifiable information (PII). Implementing access controls and protecting this data ensures confidentiality and compliance before any model training occurs. Other options address later stages such as deployment monitoring (B), ethical alignment (C), or post-deployment maintenance (A), which are not the focus of the data collection stage.

## Pregunta 11

Contexto: [topics:88](#topics-88)
A company trains a generative AI model designed to classify customer feedback as positive, negative, or neutral. However, the training dataset disproportionately includes feedback from a specific demographic and uses outdated language norms that don’t reflect current customer communication styles. When the model is deployed, it shows a strong bias in its sentiment analysis for new customer feedback, misclassifying reviews from underrepresented demographics and struggling to understand current slang or phrasing. What type of model limitation is this?

**A.** Edge case

**B.** Data dependency

**C.** Hallucination

**D.** Overfitting

**Respuesta de la fuente:** B

**Explicación:** The model's performance is directly constrained by the quality and relevance of its training inputs, which is the definition of data dependency.
Since the dataset was skewed and outdated, the model inherited these limitations, leading to biased predictions and an inability to understand current language norms.

## Pregunta 12

Contexto: [topics:88](#topics-88)
A company wants to build a model to classify customer reviews as positive, negative, or neutral. They have collected a dataset of thousands of customer reviews, and each review has been manually tagged with the corresponding sentiment: positive, negative, or neutral. What machine learning should the company use?

**A.** Reinforcement learning

**B.** Deep learning

**C.** Unsupervised learning

**D.** Supervised learning

**Respuesta de la fuente:** D

**Explicación:** Supervised learning is the correct approach because the dataset includes labeled examples (reviews tagged with sentiment). The model learns to map input features to these known output labels to make accurate predictions on new data. Unsupervised learning would be used for unlabeled data, while reinforcement learning involves reward-based agent training, neither of which fits this classification task.

## Pregunta 13

Contexto: [topics:88](#topics-88)
An order fulfillment team has an agent that automatically processes orders, updates inventory, sends shipping notifications, and handles returns. What type of agent is this?

**A.** A conversational agent

**B.** A customer service agent

**C.** An employee productivity agent

**D.** A workflow agent

**Respuesta de la fuente:** D

**Explicación:** The described agent automates a multi-step business process involving order processing, inventory updates, and notifications.
This aligns with the definition of a workflow agent, which orchestrates sequential tasks and integrates across systems to complete operational workflows.

## Pregunta 14

Contexto: [topics:88](#topics-88)
A company is developing a generative AI application to analyze customer feedback collected through online surveys. Stakeholders are concerned about potential privacy risks associated with this data, as the feedback contains personally identifiable information. They need to mitigate these risks before using the data to train the AI model. What action should the company prioritize?

**A.** Focusing on collecting only quantitative feedback data in future surveys.

**B.** Implementing strong access controls to limit which teams can view the raw survey data.

**C.** Ensuring that the AI model is trained on a large and diverse dataset.

**D.** Applying data anonymization techniques to remove or obscure sensitive data

**Respuesta de la fuente:** D

**Explicación:** Data anonymization is the most effective control for mitigating privacy risks associated with Personally Identifiable Information (PII) in AI training data, as it directly removes or obscures sensitive identifiers at the source. Unlike access controls, which only limit who can view the data, anonymization prevents the model from learning or retaining PII, thereby reducing regulatory and re-identification risks.

## Pregunta 15

Contexto: [topics:88](#topics-88)
A company collects customer feedback through open-ended survey questions where customers can write detailed responses in their own words, such as “The product was easy to use, and the customer support was excellent, but the delivery took longer than expected.” What type of data is this?

**A.** Quantitative data

**B.** Structured data

**C.** Labeled data

**D.** Unstructured data

**Respuesta de la fuente:** D

**Explicación:** Open-ended survey responses consist of free-form text that does not adhere to a predefined data model or schema.
This lack of inherent organization classifies it as unstructured data, distinct from structured formats like databases or quantitative metrics.

## Pregunta 16

What are core hardware components of the infrastructure layer in the generative AI landscape?

**A.** User interfaces

**B.** TPUs and GPUs

**C.** Tools and services for building AI models

**D.** Pre-trained models

**Respuesta de la fuente:** B

**Explicación:** The infrastructure layer consists of the physical hardware required to execute computational workloads. GPUs and TPUs are specialized accelerators designed for the massive parallel processing and matrix operations fundamental to training and inference in generative AI models.

User interfaces, development tools, and pre-trained models belong to higher layers such as application, platform, or model services, not the underlying infrastructure.

## Pregunta 17

A company has a machine learning project that involves diverse data types like streaming data and structured databases. How does Google Cloud support data gathering for this project?

**A.** Google Cloud’s strengths are in the data analysis tools such as BigQuery.

**B.** The Gemini app is the primary Google Cloud tool for directly collecting data.

**C.** Google Cloud relies on Vertex AI to connect to external data.

**D.** Google Cloud provides tools such as Pub/Sub, Cloud Storage, and Cloud SQL.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it lists the specific Google Cloud services designed for the data ingestion requirements mentioned in the scenario.
Cloud Pub/Sub is the standard service for handling streaming data, while Cloud SQL supports structured relational databases and Cloud Storage provides scalable object storage for diverse data types.
Options A, B, and C are incorrect as they focus on analysis, generative AI applications, or model deployment rather than the fundamental data gathering infrastructure.

## Pregunta 18

The office of the CISO wants to use generative AI (gen AI) to help automate tasks like summarizing case information, researching threats, and taking actions like creating detection rules. What agent should they use?

**A.** Data agent

**B.** Security agent

**C.** Customer service agent

**D.** Code agent

**Respuesta de la fuente:** B

**Explicación:** The Security agent is specifically designed for cybersecurity tasks within the CISO's domain.
It directly supports summarizing incident cases, researching threats, and automating actions like creating detection rules.
Other agents focus on data preparation, customer support, or code generation, which do not align with these security-specific objectives.

## Pregunta 19

A financial services company receives a high volume of loan applications daily submitted as scanned documents and PDFs with varying layouts. The manual process of extracting key information is time-consuming and prone to errors. This causes delays in loan processing and impacts customer satisfaction. The company wants to automate the extraction of this critical data to improve efficiency and accuracy. Which Google Cloud tool should they use?

**A.** Document AI API

**B.** Natural Language API

**C.** Vision AI

**D.** Dataflow

**Respuesta de la fuente:** A

**Explicación:** Document AI is specifically designed to extract structured data from unstructured or semi-structured documents like PDFs and scanned forms using OCR and layout analysis.
It directly addresses the need to automate data extraction from varying layouts, whereas Vision API focuses on image recognition and Natural Language API analyzes text content without document structure awareness.

## Pregunta 20

A security team needs a centralized platform to gain a comprehensive overview of their organization’s security health across their entire Google Cloud environment, including potential threats to their generative AI deployments. Which Google Cloud security offering is specifically for this purpose?

**A.** Identity and Access Management

**B.** Workload monitoring tools

**C.** Security Command Center

**D.** Secure-Py-design infrastructure

**Respuesta de la fuente:** C

**Explicación:** Security Command Center (SCC) is Google Cloud's native solution designed to provide a centralized, comprehensive view of security posture, threats, and risks across the entire environment.
It aggregates data from various sources to detect vulnerabilities and misconfigurations, making it the correct tool for gaining oversight of both general cloud resources and specific workloads like generative AI deployments.

## Pregunta 21

An organization with a team of live customer service agents wants to improve agent efficiency and customer satisfaction during support interactions. They are looking for a tool that can provide real-time guidance to agents, suggest helpful information, and streamline the support process without fully automating customer conversations. Which component of Google’s Customer Engagement Suite should they use?

**A.** Google Cloud Contact Center as a Service

**B.** Conversational Insights

**C.** Agent Assist

**D.** Conversational Agents

**Respuesta de la fuente:** C

**Explicación:** Agent Assist is specifically designed to support live human agents by providing real-time suggestions and relevant information during customer interactions.

Unlike Conversational Agents, which automate conversations entirely, Agent Assist augments human efficiency without replacing the agent.

Therefore, it directly addresses the requirement for real-time guidance without full automation.

## Pregunta 22

A software developer needs a highly efficient, open-source large language model that can be fine-tuned on a local machine for rapid prototyping of a chatbot application. They require a model that offers strong performance in natural language understanding and generation, while being lightweight enough to run on limited hardware. Which Google-developed family of models should they use?

**A.** Gemma

**B.** Imagen

**C.** Gemini

**D.** Veo

**Respuesta de la fuente:** A

**Explicación:** Gemma is Google's family of open-weight, lightweight large language models specifically designed for efficient local deployment and fine-tuning on limited hardware.
In contrast, Imagen and Veo are generative models for images and video respectively, while Gemini is a powerful multimodal model primarily accessed via API rather than as a lightweight open-source option for local fine-tuning.

## Pregunta 23

A pharmaceutical company’s research and development department spends significant time manually reviewing new scientific papers to identify potential drug targets. They need a solution that can answer questions about these documents and provide summarized insights to researchers without requiring extensive coding expertise. What should the organization do?

**A.** Use Vertex AI Agent Builder to create a custom AI agent.

**B.** Use Vertex AI Search to index the papers and enable keyword-based searches.

**C.** Use Gemini for Google Workspace to facilitate collaborative document review.

**D.** Use Vertex AI AutoML to train a model that classifies papers into predefined research areas.

**Respuesta de la fuente:** A

**Explicación:** Vertex AI Agent Builder is the correct choice because it enables the creation of conversational agents that can answer natural language questions and provide synthesized insights from private data sources.
This low-code platform allows researchers to interact with scientific papers without extensive programming expertise, directly addressing the requirement for accessible, summarized information retrieval.

## Pregunta 24

A company wants to create an AI-powered educational solution that provides personalized learning experiences for students. This platform will assess a student’s knowledge, recommend relevant learning materials and generate personalized exercises. The application would provide the structure for lessons and track progress. What type of AI solution should they use?

**A.** A learning management system (LMS)

**B.** A customized learning agent

**C.** An AI-powered recommendation system for learning resources

**D.** A large language model fine-tuned on educational content

**Respuesta de la fuente:** B

**Explicación:** A customized learning agent is the correct choice because it represents an autonomous AI system capable of orchestrating multiple complex tasks, such as assessing knowledge, generating content, and tracking progress. Unlike a simple recommendation engine (C) or LLM component (D), an agent integrates these capabilities to adapt dynamically to individual student needs. An LMS (A) is merely a structural platform for delivery, not the intelligent engine driving personalization.

## Pregunta 25

A company’s development team is eager to start building generative AI solutions with Google Cloud, but has limited experience in AI development. They need to launch their gen AI solution quickly. What Google Cloud benefit would help the company achieve their goal?

**A.** Google Cloud’s pre-trained models and low- and no-code AI tools and services.

**B.** Google Cloud’s focus on continuous improvement provides access to the latest AI tools, features, and best practices.

**C.** Google Cloud’s comprehensive training materials and tutorials to help developers.

**D.** Google Cloud’s collaborative AI community and support forums connect developers with AI experts.

**Respuesta de la fuente:** A

**Explicación:** The development team has limited AI experience and needs to launch quickly, making pre-trained models and low/no-code tools the most direct solution for rapid deployment. These resources abstract away complex model training and infrastructure management, allowing teams to integrate generative AI capabilities without deep technical expertise. Other options like training materials or community support (C, D) address skill gaps long-term but do not provide the immediate development velocity required.

## Pregunta 26

A large multinational corporation with geographically dispersed teams struggles with knowledge silos and inconsistent access to crucial internal information. What is a key business benefit of using Google Agentspace in this scenario?

**A.** Automation of employee performance reviews using AI.

**B.** Seamless knowledge sharing and collaboration across internal systems.

**C.** Improved IT infrastructure management across offices.

**D.** Enhanced data encryption and compliance for internal communications.

**Respuesta de la fuente:** B

**Explicación:** Google Agentspace is specifically designed to unify access to information across Google Workspace applications like Docs, Drive, and Chat.
This capability directly addresses knowledge silos by enabling seamless knowledge sharing and collaboration for geographically dispersed teams.
Options A, C, and D describe functions unrelated to Agentspace's core purpose of information retrieval and workspace integration.

## Pregunta 27

A marketing team wants to use a foundation model to create social media and advertising campaigns. They want to create written articles and images from text. They lack deep AI expertise and need a versatile solution. Which Google foundation model should they use?

**A.** Gemini

**B.** Gemma

**C.** Veo

**D.** Imagen

**Respuesta de la fuente:** A

**Explicación:** Gemini is Google's flagship multimodal foundation model, natively supporting both text generation and image creation from text prompts. This versatility allows the marketing team to handle both article writing and image generation within a single solution without requiring deep AI expertise to integrate separate models.

## Pregunta 28

A data science team needs a centralized and organized location to store its various model versions, track their metadata, and easily deploy them to the respective applications. What Google Cloud service should they use?

**A.** Cloud Storage

**B.** Verte AI Pipelines

**C.** BigQuery

**D.** Model Registry

**Respuesta de la fuente:** D

**Explicación:** The question describes the core functionalities of a Model Registry: centralized storage, versioning, metadata tracking, and simplified deployment for machine learning models.

While Cloud Storage handles general file storage and Vertex AI Pipelines orchestrates workflows, neither provides native model versioning and metadata management. BigQuery is a data warehouse unsuitable for serving trained ML models. Therefore, Model Registry (often part of Vertex AI) is the correct service.

## Pregunta 29

What is a characteristic of Google Cloud as a generative AI company?

**A.** Google Cloud relies on proprietary, closed-source AI technologies for maximum security benefits.

**B.** Google Cloud has an AI-first focus that enables innovation, with continuous updates and broad integration across its platform.

**C.** Google Cloud ensures that all generative AI models and data are completely secured and isolated from external networks.

**D.** Google Cloud provides fully autonomous AI agents that require zero configuration or management overhead.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud operates with an AI-first strategy, deeply integrating generative AI capabilities across its platform to drive continuous innovation.
Option A is incorrect because Google supports open-source ecosystems alongside proprietary tech; Option C is false as absolute isolation contradicts cloud connectivity needs; and Option D is inaccurate since AI agents still require configuration and oversight.

## Pregunta 30

What will Google Cloud’s Agent Assist help a company achieve?

**A.** The ability to analyze conversational data to identify customer sentiment, common topics of discussion, and insights into agent performance and customer experience.

**B.** The ability to provide real-time assistance and recommended responses to live customer service agents during their interactions.

**C.** The infrastructure to provide an enterprise-grade contact center solution with omnichannel support, routing, and integration with CRM systems.

**D.** The ability to build and deploy deterministic and generative chatbot agents for automated customer support.

**Respuesta de la fuente:** B

**Explicación:** Agent Assist is specifically designed to support human agents during live interactions by providing real-time suggestions, such as relevant knowledge base articles and recommended responses.

Option A describes Conversational Insights (post-call analytics), Option C describes Contact Center AI/CCaaS infrastructure, and Option D describes Conversational Agents (chatbots).

## Pregunta 31

A company wants a generative AI platform that provides the infrastructure, tools, and pre-trained models needed to build, deploy, and manage its generative AI solutions. Which Google Cloud offering should the company use?

**A.** BigQuery

**B.** Google Kubernetes Engine (GKE)

**C.** Google Cloud Storage

**D.** Vertex AI

**Respuesta de la fuente:** D

**Explicación:** Vertex AI is Google Cloud's unified machine learning platform designed specifically for building, deploying, and managing ML models, including generative AI.

It provides access to pre-trained foundation models (via Generative AI Studio) along with the necessary infrastructure for custom training and deployment.

In contrast, BigQuery is a data warehouse, GKE is a container orchestration service, and Cloud Storage is an object storage service; none offer an end-to-end generative AI platform.

## Pregunta 32

A company is exploring Google Agentspace to improve how its employees search for information on their enterprise systems and automate certain tasks. What is the key business advantage of using Agentspace?

**A.** Enhanced real-time communication and collaboration among team members.

**B.** More granular control over support team access and permissions for sensitive data.

**C.** Improved productivity and data interaction using AI assistants and advanced document analysis.

**D.** Greater interoperability with legacy software systems and databases.

**Respuesta de la fuente:** C

**Explicación:** Google Agentspace (now part of Gemini Enterprise) is designed to centralize enterprise information access and automate workflows using AI assistants.
It enhances productivity by enabling advanced document analysis and context-aware interactions, which directly address the question's focus on searching and automation.
Options A, B, and D describe collaboration, security, or legacy integration, which are not the primary business advantages of this specific AI-driven tool.

## Pregunta 33

An organization wants granular control over who can use and see their generative AI models and related resources on Google Cloud. Which Google Cloud security offering is specifically for this purpose?

**A.** Workload monitoring tools.

**B.** Secure-by-design infrastructure.

**C.** Identity and Access Management.

**D.** Security Command Center.

**Respuesta de la fuente:** C

**Explicación:** Google Cloud Identity and Access Management (IAM) is the primary mechanism for granting specific permissions to users and service accounts.
It enables granular control over who can access and manipulate generative AI models by defining precise roles and policies, whereas the other options focus on monitoring, foundational infrastructure, or threat detection.

## Pregunta 34

A large ecommerce company with a substantial product catalog and many support documents has customers struggling to find information on their website. This leads to high support costs and poor user experience. The company wants a Google Cloud solution to improve website search and reduce support costs while improving customer satisfaction. What Google Cloud product should the company use?

**A.** Google Shopping

**B.** Google Search

**C.** Vertex AI Search

**D.** Vertex AI Platform

**Respuesta de la fuente:** C

**Explicación:** Vertex AI Search is the specific Google Cloud service designed to index and retrieve information from private enterprise data sources like product catalogs and support documentation. It uses generative AI to provide natural language, conversational search experiences that improve user satisfaction and deflect support tickets. In contrast, Google Shopping and Google Search are public-facing services, while Vertex AI Platform is a general-purpose ML development environment not specialized for building search applications.

## Pregunta 35

A company wants to adopt generative AI and is concerned about vendor lock-in. They want to maintain flexibility in their technology stack. What Google Cloud strength would ease their concerns?

**A.** Google Cloud’s strict adherence to proprietary technologies ensures the highest level of security and performance.

**B.** Google Cloud’s AI solutions are pre-packaged for easy deployment, eliminating the need for customization and integration efforts.

**C.** Google Cloud’s AI solutions have an open approach that supports customer choice across offerings.

**D.** Google Cloud’s focus on automation aims to replace human jobs with AI systems, potentially leading to significant workforce reductions.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google Cloud's open approach to AI, such as supporting open-source models and standard interfaces, directly mitigates vendor lock-in by ensuring portability and flexibility. In contrast, Option A promotes proprietary tech which increases lock-in risk, while Options B and D describe limitations or irrelevant outcomes that do not address the core concern of maintaining stack flexibility.

## Pregunta 36

A company’s sales team spends a significant amount of time researching potential leads and manually entering data into their customer relationship management (CRM) tool. They want to improve the team’s efficiency and enable them to focus on building relationships and closing deals. What should the organization do?

**A.** Develop a custom AI solution using Google Cloud’s AutoML Natural Language to analyze lead communications and automatically update the CRM.

**B.** Implement Google Cloud’s Contact Center AI to qualify leads and route them to the appropriate sales representatives.

**C.** Implement Google Agentspace "unified enterprise search" including a CRM agent to automate lead research and data entry.

**D.** Integrate the CRM with a popular sales intelligence platform to automatically enrich lead profiles with valuable data.

**Respuesta de la fuente:** C

**Explicación:** Google Cloud Agentspace is the correct solution because it provides unified enterprise search and specialized agents (like a CRM agent) to automate lead research and data entry. This directly addresses the sales team's pain points by eliminating manual tasks through generative AI, allowing them to focus on relationship building.

## Pregunta 37

A logistics company wants to use a generative AI (gen AI) agent to automatically check real-time inventory levels across its warehouses and adjust delivery schedules. The gen AI agent needs access to internal inventory data. They want the most cost-effective solution. What should the organization do?

**A.** Build a custom API instead of using the gen AI agent.

**B.** Use pre-built gen AI chatbots for inventory questions.

**C.** Use Vertex AI Studio to fine-tune a model with sample inventory data.

**D.** Use Google Cloud databases and Vertex AI for the agent to get live data.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because generative AI agents require access to real-time, dynamic data (like current inventory levels) which cannot be embedded in static model weights.
Using Vertex AI allows the agent to invoke tools or APIs that query live Google Cloud databases, ensuring decisions are based on current information rather than outdated training data.
Fine-tuning (Option C) is inappropriate for changing data, and simple chatbots (Option B) lack the autonomous action-taking capabilities needed to adjust schedules.

## Pregunta 38

An organization needs an AI tool to analyze and summarize lengthy customer feedback text transcripts. You need to choose a Google foundation model with a large context window. What foundation model should the organization choose?

**A.** Gemini

**B.** CodeGemma

**C.** Imagen

**D.** Chirp

**Respuesta de la fuente:** A

**Explicación:** Gemini is the correct choice because it is a multimodal foundation model designed with large context windows (up to 1M+ tokens), making it ideal for processing lengthy transcripts.
CodeGemma is optimized specifically for code generation, Imagen is used for image synthesis, and Chirp handles speech-to-text transcription rather than text analysis or summarization.

## Pregunta 39

A large e-commerce company with a vast and frequently updated product catalog finds that customers struggle to find products on their website, and support agents speed too much time finding detailed product information. The company wants to improve search accuracy and efficiency for both customers and support. What Google Cloud solution should they use?

**A.** Vertex AI Conversation

**B.** Vertex AI Natural Language API

**C.** Pre-built RAG with VERTEX AI Search

**D.** Vertex AI Model Garden

**Respuesta de la fuente:** C

**Explicación:** Vertex AI Search (with pre-built RAG) is specifically designed to index large, dynamic enterprise data sources like product catalogs, providing semantic search capabilities that improve accuracy for both customers and support agents. It automatically handles the retrieval and grounding of information from the live database, ensuring answers are current without requiring custom model training.

In contrast, Vertex AI Conversation focuses on agent orchestration rather than pure search indexing; the Natural Language API provides text analysis features but lacks search functionality; and Model Garden is a repository for models, not an application-level search solution.

## Pregunta 40

An organization wants to quickly experiment with different Gemini models and parameters for content creation without a complex setup. What service should the organization use for this initial exploration?

**A.** Vertex AI Studio

**B.** Vertex AI Prediction

**C.** Google AI Studio

**D.** Gemini for Google Workspace

**Respuesta de la fuente:** C

**Explicación:** Google AI Studio is the designated platform for rapid experimentation and prototyping with Gemini models, offering a low-code environment to test parameters and prompts without complex infrastructure setup. While Vertex AI Studio supports enterprise-grade development, Google AI Studio is specifically optimized for quick initial exploration and iteration.

## Pregunta 41

An organization wants to understand trends in customer interactions, identify common issues, gauge customer sentiment, and improve the overall customer experience across both their automated chatbot interactions and live agent support. They need a tool that can analyze their existing conversational data to gain actionable business intelligence. What component of Google’s Customer Engagement Suite best addresses this need?

**A.** Agent Assist

**B.** Google Cloud Contact Center as a Service

**C.** Conversational Agents

**D.** Conversational Insights

**Respuesta de la fuente:** D

**Explicación:** Conversational Insights is the specific component designed to analyze historical data from both chatbots and live agents.
It uses NLP and ML to detect sentiment, extract entities, and identify trends, directly addressing the need for actionable business intelligence on past interactions.

## Pregunta 42

What is a key advantage of using Google’s custom-designed TPUs?

**A.** TPUs increase the storage capacity and data retrieval speeds within Google Cloud data centers.

**B.** TPUs are lightweight processors intended for deployment on edge devices.

**C.** TPUs are specialized AI processors that excel at parallel processing for machine learning workloads.

**D.** TPUs are primarily designed to improve the general processing speed of virtual machines in the cloud.

**Respuesta de la fuente:** C

**Explicación:** Google Tensor Processing Units (TPUs) are custom-designed application-specific integrated circuits (ASICs) optimized specifically for machine learning workloads, particularly neural network inference and training. Their architecture utilizes systolic arrays to perform large-scale matrix multiplications with high throughput and energy efficiency, making them superior for parallel processing in AI tasks compared to general-purpose processors.

## Pregunta 43

A company is trying to decide which platform to use to optimize its generative AI (gen AI) solutions. Why should the company use Vertex AI Platform?

**A.** It provides gen AI coding assistance with enterprise security and privacy protection.

**B.** It provides a mechanism for efficient analysis and exploration of large datasets used in machine learning.

**C.** It provides a unified platform of tools for building, deploying, and managing machine learning.

**D.** It provides scalable and cost-effective object storage for data used in machine learning workflows.

**Respuesta de la fuente:** C

**Explicación:** Vertex AI is designed as a unified machine learning platform that consolidates tools for building, deploying, and managing ML models across the entire lifecycle.
Option C accurately describes this comprehensive capability, whereas Option A refers to GitHub Copilot (Gemini Code Assist), Option B describes BigQuery, and Option D describes Cloud Storage.

## Pregunta 44

A finance team wants to use Gemma to help with daily tasks so that the financial analysts can focus on other work. Which business problem can Gemma most efficiently address?

**A.** The struggle to accurately extract key financial figures and insights from a variety of document formats, such as balance sheets and income statements, for quick reporting.

**B.** The complexity of building and deploying sophisticated internal knowledge bases to answer employees’ finance-related questions with accurate and up-to-date information.

**C.** The difficulty in analyzing large datasets of financial transactions and market data to identify anomalies and predict future financial performance.

**D.** The challenge of efficiently producing high-quality written summaries and initial drafts of financial communications.

**Respuesta de la fuente:** D

**Explicación:** Gemma is a Large Language Model primarily optimized for natural language generation and understanding.
While it can assist with extraction (A), its most distinct advantage in daily workflows is drafting and summarizing text, which directly automates the creation of reports and communications.
Options B and C involve knowledge base architecture or complex numerical prediction tasks that are better served by specialized RAG systems or statistical models, respectively.

## Pregunta 45

A research company needs to analyze several lengthy PDF documents containing financial reports and identify key performance indicators (KPIs) and their trends over the past year. They want a Google Cloud prebuilt generative AI tool that can process these documents and provide summarized insights directly from the source material with citations. What should the analyst do?

**A.** Use NotebookLM to upload and analyze the documents.

**B.** Create a custom Gem in Gemini Advanced with predefined KPIs to look across different financial reports.

**C.** Use Gemini for Google Workspace within Google Docs to copy and paste sections of the reports for summary and analysis.

**D.** Use the Gemini app to ask general financial trend questions.

**Respuesta de la fuente:** A

**Explicación:** NotebookLM is a prebuilt generative AI tool specifically designed to ground responses in user-uploaded source documents, such as PDFs.
It generates insights and summaries directly from these materials while providing inline citations linked to the original text, ensuring accuracy and traceability required for financial analysis.

## Pregunta 46

A learning and development team wants to quickly create a new hire training video with a custom avatar and voiceover that matches their company’s branding and key messaging. They did not receive any money to spend on the production. What should they do?

**A.** Generate the video frames with Imagen.

**B.** Create a video with Google Vids.

**C.** Train a model with Vertex AI and produce a video.

**D.** Prompt the Gemini app to create a video.

**Respuesta de la fuente:** B

**Explicación:** Google Vids is the specific application designed for creating short-form videos with custom avatars and voiceovers aligned to brand messaging. It leverages underlying AI models (like Veo) through an accessible interface suitable for non-technical teams, whereas Vertex AI requires development resources and Gemini/Imagen are not dedicated video editing tools.

## Pregunta 47

What does Model Garden enable a company to do?

**A.** Train new models from scratch using large datasets.

**B.** Evaluate the performance of different models using various metrics.

**C.** Discover, customize, and deploy existing models from Google and its partners.

**D.** Manage different versions of a model including the code, data, and parameters used to train it.

**Respuesta de la fuente:** C

**Explicación:** Model Garden in Google Cloud Vertex AI is designed as a curated library that allows users to discover pre-trained foundational models from Google and its partners.
It enables organizations to customize these existing models through fine-tuning or direct API access and deploy them for production use, rather than requiring training from scratch.

## Pregunta 48

A national bank is overwhelmed by customer inquiries across multiple channels and needs an AI-powered solution to provide seamless, consistent support, empower customer support agents, and improve service quality. What Google Cloud product should the bank use?

**A.** Gemini for Google Workspace

**B.** Google Contact Center as a Service

**C.** Vertex AI Search

**D.** Gemini for Google Cloud

**Respuesta de la fuente:** B

**Explicación:** Google Contact Center AI (CCAI) is the specialized Google Cloud solution designed to unify customer interactions across multiple channels, reduce agent workload through automation and real-time assistance, and improve overall service quality. Unlike general-purpose AI models or search tools, CCAI provides a comprehensive, turnkey contact center infrastructure tailored for high-volume support scenarios.

## Pregunta 49

What is a primary benefit of using a multi-agent system?

**A.** To manage complex tasks that demand coordinated AI functions.

**B.** To serve as a platform for hosting traditional, non-AI applications.

**C.** To simplify the most basic and repetitive rule-based tasks.

**D.** To consolidate all unique AI functions into a single, undifferentiated model.

**Respuesta de la fuente:** A

**Explicación:** Multi-agent systems are designed to decompose complex problems into sub-tasks handled by specialized agents that collaborate to achieve a common goal.
This architectural approach enables the management of intricate workflows requiring coordinated AI functions, which single-model or rule-based solutions cannot efficiently handle.

## Pregunta 50

An organization wants to use generative AI to create a chatbot that can answer customer questions about their account balances. They need to ensure that the chatbot can access previous portions of the conversation with the customer. Which prompting technique should they use?

**A.** Use prompt chaining.

**B.** Use zero-shot prompting.

**C.** Use role prompting.

**D.** Use few-shot prompting.

**Respuesta de la fuente:** A

**Explicación:** Prompt chaining is the correct technique because it enables an application to maintain conversation history by passing previous context and outputs as inputs for subsequent prompts. This ensures the AI has access to prior interactions, allowing it to provide coherent, context-aware responses in a multi-turn dialogue. The other options—zero-shot, role, and few-shot prompting—focus on initial instruction style or examples rather than managing stateful conversation memory.

## Pregunta 51

An organization wants to use generative AI to create a marketing campaign. They need to ensure that the AI model generates text that is appropriate for the target audience. What should the organization do?

**A.** Use few-shot prompting.

**B.** Use role prompting.

**C.** Adjust the temperature parameter.

**D.** Use prompt chaining.

**Respuesta de la fuente:** B

**Explicación:** Role prompting instructs the AI to adopt a specific persona or perspective, directly influencing the tone, style, and vocabulary of the generated content. This ensures the output aligns with the expectations and preferences of the target audience, making it more appropriate than merely adjusting randomness (temperature) or using examples (few-shot).

## Pregunta 52

A company wants to use generative AI to create a chatbot that can answer customer questions about their products and services. They need to ensure that the chatbot only uses information from the company’s official documentation. What should the company do?

**A.** Use role prompting.

**B.** Use prompt chaining.

**C.** Use grounding.

**D.** Adjust temperature parameter.

**Respuesta de la fuente:** C

**Explicación:** Grounding connects the generative AI model to a specific, trusted data source such as official company documentation, ensuring responses are derived solely from that approved information. This technique prevents hallucinations and restricts the model from relying on its general training data.
Options A, B, and D control persona, workflow, or randomness respectively, but do not constrain the factual basis of the generated content.

## Pregunta 53

A social media platform uses a generative AI model to automatically generate summaries of user-submitted posts to provide quick overviews for other users. While the summaries are generally accurate for factual posts, the model occasionally misinterprets sarcasm, satire, or nuanced opinions, leading to summaries that misrepresent the original intent and potentially cause misunderstandings or offense among users. What should the platform do to overcome this limitation of the AI-generated summaries?

**A.** Increase the temperature parameter of the model to encourage more varied and less literal interpretations.

**B.** Implement stricter safety settings to filter out potentially misinterpreted content altogether.

**C.** Incorporate a human-m-the-loop (HITL) review process to refine the summaries.

**D.** Decrease the output length of the summaries to make them more concise.

**Respuesta de la fuente:** C

**Explicación:** Current AI models struggle to interpret nuanced human communication like sarcasm and satire without external context. Implementing a human-in-the-loop (HITL) process allows human reviewers to validate accuracy and correct misinterpretations before publication, ensuring appropriate tone and intent are preserved.

## Pregunta 54

A software development team wants to use generative AI (gen AI) to code faster so they can launch their software prototype quicker. What should the team do?

**A.** Use gen AI to refactor and optimize existing code.

**B.** Use gen AI to automatically generate comprehensive documentation for their code.

**C.** Use gen AI to identify potential bugs and security vulnerabilities in their code.

**D.** Use gen AI to suggest code snippets and complete functions.

**Respuesta de la fuente:** D

**Explicación:** The goal is to accelerate the creation of a prototype, making code generation the most direct method.
Using generative AI to suggest snippets and complete functions (Option D) reduces manual typing and speeds up initial development.
Options A, B, and C focus on optimization, documentation, and quality assurance, which are secondary tasks performed after or alongside initial coding.

## Pregunta 55

A development team is building an internal knowledge base chatbot to answer employee questions about company policies and procedures. This information is stored across various documents in Google Cloud Storage and is updated regularly by different departments. What is the primary benefit of using Google Cloud’s RAG APIs in this scenario?

**A.** They provide a pre-built user interface for the chatbot, simplifying the front-end development process.

**B.** They automatically create summaries of all company policies, which are then presented to employees as quick answers.

**C.** They enable the generative AI model to retrieve the most up-to-date and relevant information from the policy documents in real-time.

**D.** They allow the development team to train a single foundation model on all company documents.

**Respuesta de la fuente:** C

**Explicación:** Retrieval-Augmented Generation (RAG) allows generative AI models to access external data sources dynamically rather than relying solely on static training data.

This ensures the chatbot retrieves the most current and relevant policy information in real-time, which is critical when source documents are updated regularly.

Unlike fine-tuning (Option D), RAG does not require retraining the model for new data updates.

## Pregunta 56

A company’s large learning model (LLM) is producing hallucinations that are a result of the knowledge cutoff. How does retrieval-augmented generation (RAG) overcome this limitation?

**A.** RAG enhances the creative writing capabilities of the LLM to generate more engaging and informative responses.

**B.** RAG uses human oversight to ensure accuracy before presenting information to the customer.

**C.** RAG enables the LLM to retrieve relevant and up-to-date information from knowledge sources.

**D.** RAG fine-tunes the LLM on specific customer query patterns to improve the speed and efficiency of response generation.

**Respuesta de la fuente:** C

**Explicación:** Large Language Models have a static knowledge cutoff because their training data is fixed at a specific point in time. Retrieval-Augmented Generation (RAG) overcomes this by querying external, up-to-date knowledge bases during inference to provide current context. This allows the model to generate accurate responses based on retrieved facts rather than relying solely on its potentially outdated internal memory.

## Pregunta 57

A global news agency is developing a generative AI tool to quickly summarize breaking news articles as they emerge online. The goal is to provide their audience with rapid updates on fast developing stories from various global sources. What Google Cloud solution should they use?

**A.** Grounding with Google Search

**B.** Vertex AI Natural Language API

**C.** BigQuery

**D.** Document AI

**Respuesta de la fuente:** A

**Explicación:** Grounding with Google Search allows generative AI models to retrieve real-time information from the public internet, which is essential for summarizing breaking news. Other options like Vertex AI Natural Language API, BigQuery, and Document AI process static or user-provided data rather than live web content.

## Pregunta 58

A company is developing a conversational AI chatbot. They need to ensure the chatbot can engage in human-like conversations and provide accurate information. What should they do to enhance the chatbot’s ability to understand and respond effectively to user prompts?

**A.** Lower model temperature setting to produce more consistent and predictable responses.

**B.** Use strict keyword matching to ensure that the chatbot only responds to specific commands.

**C.** Limit the chatbot’s training data to prevent it from learning irrelevant information.

**D.** Use prompt engineering techniques like few-shot prompting, to provide the chatbot with examples of successful interactions.

**Respuesta de la fuente:** D

**Explicación:** Few-shot prompting provides the model with concrete examples of desired input-output pairs, allowing it to infer patterns and style without retraining.
This technique directly enhances the chatbot's ability to generate accurate, context-aware, and human-like responses by grounding its behavior in specific demonstration data.

## Pregunta 59

What does Vertex AI Search enable companies to do?

**A.** To ground LLM responses with first-party data, third-party data and Google’s knowledge graph.

**B.** To surface the most popular and frequently accessed content based on global user search patterns and trends.

**C.** To index and retrieve information from the entire public web, providing a comprehensive view of publicly available data.

**D.** To compare products from numerous online retailers, allowing users to find the best deals and product options across the internet.

**Respuesta de la fuente:** A

**Explicación:** Vertex AI Search is an enterprise-grade service designed to index a company's proprietary data sources (first-party) and optionally integrate third-party content or Google's knowledge graph for grounding LLM responses via RAG. The other options describe consumer-facing features of Google Search, Google Trends, or Google Shopping rather than the enterprise search capabilities offered by Vertex AI.

## Pregunta 60

A development team is configuring a generative AI model for a customer-facing application and wants to ensure the generated content is appropriate and harmless. What is the primary function of the safety settings parameter in a generative AI model?

**A.** To filter out potentially harmful or inappropriate content from the model’s output based on the desired level of filtering.

**B.** To limit the maximum text length that the model generates by ensuring concise responses.

**C.** To determine the number of tokens the model can process at once by influencing the complexity and length of inputs and outputs.

**D.** To control the creativity and randomness of the model’s output by adjusting the diversity of word choices.

**Respuesta de la fuente:** A

**Explicación:** Safety settings act as guardrails that filter out harmful or inappropriate content by applying configurable thresholds to specific harm categories. This directly addresses the requirement for appropriate and harmless output, distinguishing it from parameters like max_tokens (B/C) or temperature (D).

## Pregunta 61

A customer service team wants to use generative AI to improve the quality and consistency of their email responses to customer inquiries. They need a solution that can guide the AI to adopt a helpful, empathetic tone while adhering to company policies. Which prompting technique should they use?

**A.** Role prompting that instructs the AI to act as an experienced customer service representative with corporate knowledge.

**B.** Few-shot prompting that provides examples of good and bad customer service emails.

**C.** Prompt chaining that engages the AI in a conversation to gather the necessary information before generating the email response.

**D.** One-shot prompting that provides a single example of a good customer service email.

**Respuesta de la fuente:** A

**Explicación:** Role prompting explicitly defines the AI's persona and behavioral guidelines, making it the most effective technique for enforcing a specific tone like empathy and adherence to company policies.
While few-shot prompting uses examples, role prompting directly instructs the model on how to behave conceptually, ensuring consistency across diverse inquiries without relying solely on pattern matching.

## Pregunta 62

A company is developing a generative AI-powered customer support chatbot. They want to ensure the chatbot can answer a wide range of customer questions accurately, even those related to recently updated product information not present in the model’s original training data. What is a key benefit of implementing retrieval-augmented generation (RAG) in this chatbot?

**A.** RAG will significantly reduce the computational resources required to run the generative AI model.

**B.** RAG will enable the chatbot to fine-tune its underlying language model on the fly based on customer interactions.

**C.** RAG will enable the chatbot to access and utilize external, up-to-date knowledge sources to provide more accurate and relevant answers.

**D.** RAG will primarily help the chatbot generate more creative and engaging conversational responses.

**Respuesta de la fuente:** C

**Explicación:** Retrieval-Augmented Generation (RAG) augments the LLM with real-time access to external knowledge bases, allowing it to retrieve relevant, up-to-date information during inference rather than relying solely on static training data. This directly addresses the requirement for accurate answers regarding recent product updates not present in the original model weights. Other options are incorrect because RAG does not reduce computational load (it adds retrieval steps), does not perform fine-tuning, and focuses on factual accuracy over creative generation.

## Pregunta 63

A team is using a generative AI model to automatically generate short summaries of customer feedback. They need to ensure that these summaries are concise and easy to digest. What model setting should they adjust?

**A.** Temperature

**B.** Output length

**C.** Top-p (nucleus sampling)

**D.** Safety settings

**Respuesta de la fuente:** B

**Explicación:** To ensure summaries are concise and easy to digest, the team must directly control the quantity of generated text. Adjusting the 'Output length' setting (typically via parameters like Max Tokens) imposes a hard limit on response size, preventing verbose outputs. Other settings like Temperature or Top-p influence creativity and probability distribution but do not guarantee brevity.

## Pregunta 64

A company is using a language model to solve complex customer service inquiries. For a particular issue, the prompt includes the following instructions:

“To address this customer’s problem, we should first identify the core issue they are experiencing. Then we need to check if there are any known solutions or workarounds in our knowledge base. If a solution exists, we should clearly explain it to the customer. If not, we might need to escalate the issue to a specialist. Following these steps will help us provide a comprehensive and helpful response. Now, given the customer’s message: ‘My order hasn’t arrived, and the tracking number shows no updates for a week,’ what should be the next step in resolving this?”

What type of prompting is this?

**A.** Few-shot

**B.** Chain-of-thought

**C.** Role-based

**D.** Zero-shot

**Respuesta de la fuente:** B

**Explicación:** The prompt explicitly instructs the model to follow a sequential reasoning process: identifying the core issue, checking for solutions, and deciding on escalation before answering. This structure guides the model through intermediate logical steps rather than just providing examples or defining a role. Such step-by-step guidance is the defining characteristic of Chain-of-thought prompting.

## Pregunta 65

A marketing team wants to use a generative AI model to create product descriptions for their new line of eco-friendly water bottles. They provide a brief prompt stating, “Write a product description for our new water bottle.” The model generates a generic, lackluster description that is factually accurate but lacks engaging language and doesn’t highlight the environmental benefits that are key to their brand. What should the marketing team do to overcome this limitation of the generated product description?

**A.** Lower the temperature setting of the model to produce more consistent results.

**B.** Increase the token count for the model to allow for longer descriptions.

**C.** Add details to the prompt about the audience, tone, and keywords.

**D.** Train the model on a dataset of marketing materials from other eco-friendly brands.

**Respuesta de la fuente:** C

**Explicación:** The core issue is a vague prompt that fails to provide specific context, causing the model to generate generic output. By adding details about the target audience, desired tone, and key environmental benefits (keywords), the marketing team provides the necessary constraints to guide the AI toward producing engaging and brand-aligned content.

## Pregunta 66

A global news company is using a large language model to automatically generate summaries of news articles for their website. The model’s summary of an international summit was accurate until it hallucinated by stating a detail that did not occur. How should the company overcome this hallucination?

**A.** Fine-tune the model on a larger dataset of news articles.

**B.** Use grounding to base the model output on the source articles.

**C.** Implement stricter safety settings to filter out potentially controversial topics.

**D.** Increase the temperature setting of the model to encourage more diverse outputs.

**Respuesta de la fuente:** B

**Explicación:** Hallucinations in large language models occur when the model generates factually incorrect information based on its training data rather than specific source material. Grounding techniques, such as Retrieval-Augmented Generation (RAG), constrain the model to generate responses strictly based on provided context or source documents. By anchoring the summary generation to the actual news article text, the company ensures factual accuracy and prevents the invention of details.

## Pregunta 67

A company is defining their generative AI strategy. They want to follow Google-recommended practices to increase their chances of success. Which strategy should they use?

**A.** Bottom-up strategy

**B.** Rapid implementation strategy

**C.** Top-down strategy

**D.** Multi-directional strategy

**Respuesta de la fuente:** D

**Explicación:** Google's generative AI leadership study guide explicitly recommends combining a top-down approach, where leadership sets vision and governance, with a bottom-up approach, where employees identify practical applications. This combined methodology aligns strategic goals with operational insights, which is best described as a multi-directional strategy.

## Pregunta 68

A retail company with a large online catalog wants to improve customer experience and drive sales by implementing multimodal search capabilities (image voice, and text). What is a primary business benefit of this capability?

**A.** Reduced dependency on keyword optimization for product listings and improved search engine rankings.

**B.** Streamlined inventory management processes and more accurate demand forecasting for popular items.

**C.** Lowered operational costs associated with managing and updating product information across different platforms and channels.

**D.** Improved customer engagement and product discovery leading to increased satisfaction and potential sales.

**Respuesta de la fuente:** D

**Explicación:** Multimodal search enhances the customer experience by allowing intuitive interactions through image, voice, or text, which directly improves product discovery and engagement.
This increased satisfaction and ease of use drive higher conversion rates and sales, aligning with the stated business goal.
Options A, B, and C describe secondary technical effects or internal operational efficiencies that are not the primary customer-facing benefit.

## Pregunta 69

A financial institution uses generative AI (gen AI) to approve and reject loan applications, but gives no reasons for rejection. Customers are starting to file complaints. The company needs to implement a solution to reduce the complaints. What should the company do?

**A.** Fine-tune the gen AI model.

**B.** Collect a larger and more diverse dataset for the gen AI model.

**C.** Implement explainable gen AI policies.

**D.** Develop fairness assessments for the gen AI model.

**Respuesta de la fuente:** C

**Explicación:** The root cause of the complaints is the lack of transparency in loan rejection decisions. Implementing explainable AI (XAI) policies directly addresses this by providing clear, human-understandable reasons for each outcome.
This approach ensures regulatory compliance with fair lending laws that mandate disclosure and helps resolve customer grievances through transparency.

## Pregunta 70

A human resources team is implementing a new generative AI application to assist the department in screening a large volume of job applications. They want to ensure fairness and build trust with potential candidates. What should the team prioritize?

**A.** Integrating the AI application with various job boards to maximize candidate reach.

**B.** Focusing on minimizing the processing time for each application to improve efficiency.

**C.** Ensuring AI operates transparently, especially regarding application evaluation and data usage.

**D.** Ensuring that the AI application can automatically rank all candidates without requiring human review.

**Respuesta de la fuente:** C

**Explicación:** Transparency is a fundamental principle of Responsible AI, particularly in high-stakes domains like hiring, as it allows candidates to understand how decisions are made and enables organizations to audit for bias.
By prioritizing clear communication about evaluation criteria and data usage, the HR team directly addresses the goals of ensuring fairness and building trust with applicants.

## Pregunta 71

According to Google-recommended practices, when should generative AI be used to automate tasks?

**A.** When tasks are highly creative and require original thought.

**B.** When tasks are complex and require strategic decision-making.

**C.** When tasks are repetitive and rule-based.

**D.** When tasks involve sensitive information or require human oversight.

**Respuesta de la fuente:** C

**Explicación:** Google recommends using generative AI to automate tasks that are repetitive and rule-based because these workflows have clear inputs and outputs, allowing for high efficiency and consistency.
Automating such routine processes frees human workers to focus on complex strategic decisions and creative problem-solving, which require nuanced judgment that AI should assist with rather than fully replace.
Tasks involving sensitive information or requiring strict human oversight are explicitly excluded from full automation due to security and ethical concerns.

## Pregunta 72

A company wants to choose a generative AI (gen AI) use case that will be successful and have the most impact. What Key factor should they determine first according to Google Cloud- recommended practices?

**A.** The number of employees who will be trained to use the new gen AI tools.

**B.** The availability of pre-trained models that are offered on various cloud computing platforms.

**C.** The frequency of updates to the underlying foundation models used by different gen AI platforms.

**D.** The specific business problems the company aims to solve and the desired outcomes.

**Respuesta de la fuente:** D

**Explicación:** Google Cloud recommended practices prioritize identifying specific business problems and desired outcomes to ensure strategic alignment and measurable value. Defining these objectives first prevents technology-driven solutions that lack clear purpose or return on investment. Options A, B, and C are secondary technical or operational considerations that should only be evaluated after the core business goal is established.

## Pregunta 73

A sales manager wants to responsibly use generative AI (gen AI) to increase efficiency with their existing tasks. They want to allow the sales team to focus on building customer relationships and closing deals. How should the sales team use gen AI?

**A.** To automate creative content like blog posts and social media updates to attract new leads.

**B.** To draft emails and provide real-time insights about customer needs.

**C.** To analyze customer interactions on social media and automatically generate sales pitches tailored to their public profiles.

**D.** To replace the sales team’s CRM system with a more intuitive and user-friendly interface.

**Respuesta de la fuente:** B

**Explicación:** Option B aligns best with the goal of increasing efficiency while allowing the team to focus on relationship building. By automating routine tasks like drafting emails, reps save time for high-value interactions. Real-time insights assist decision-making without removing human empathy from closing deals, representing a responsible use of AI as an assistant rather than a replacement.

## Pregunta 74

A home loan company is deploying a generative AI system to automate initial loan application reviews. Several applicants have been unexpectedly rejected, leading to customer complaints and potential bias concerns. They need to ensure responsible and fair lending practices. What aspect of the AI system should they prioritize?

**A.** Implementing stricter data security measures to protect applicants’ financial information from unauthorized access.

**B.** Regularly updating the AI model with more financial data to improve its accuracy over time.

**C.** Increasing the speed at which the AI system processes loan applications to handle the high volume.

**D.** Ensuring AI decision-making is explainable to understand decision reasons and establish accountability.

**Respuesta de la fuente:** D

**Explicación:** The core issue involves unexpected rejections and potential bias, which requires transparency to identify unfair patterns. Ensuring explainability allows the company to understand the rationale behind AI decisions, thereby establishing accountability and enabling the detection and mitigation of bias. This directly addresses responsible lending practices more effectively than security, data volume, or processing speed.

## Pregunta 75

A large company is creating their generative AI (gen AI) solution by using Google Cloud’s offerings. They want to ensure that their mid-level managers contribute to a successful gen AI rollout by following Google-recommended practices. What should the mid-level managers do?

**A.** Secure funding and resources for AI initiatives by demonstrating the potential return on investment to the chief financial officer (CFO).

**B.** Create a robust data strategy to ensure teams can access high-quality, relevant data that is appropriate for training and fine-tuning gen AI models.

**C.** Perform continuous testing, measurement and refinement based on user feedback and real-world performance data.

**D.** Drive gen AI adoption by identifying high-impact, feasible solutions that address specific challenges within their workflows.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.