# professional cloud devops engineer

239 / 239 preguntas. Cobertura completa: True.

Respuestas de la fuente; revisión técnica pendiente. Las imágenes permanecen en sus campos de origen.

238 respuestas conservadas; 1 pendientes.

<a id="topics-104"></a>
## Contexto topics:104
name:
Topic 1


## Pregunta 1

Contexto: [topics:104](#topics-104)
You support a Node.js application running on Google Kubernetes Engine (GKE) in production. The application makes several HTTP requests to dependent applications. You want to anticipate which dependent applications might cause performance issues. What should you do?

**A.** Instrument all applications with Stackdriver Profiler.

**B.** Instrument all applications with Stackdriver Trace and review inter-service HTTP requests.

**C.** Use Stackdriver Debugger to review the execution of logic within each application to instrument all applications.

**D.** Modify the Node.js application to log HTTP request and response times to dependent applications. Use Stackdriver Logging to find dependent applications that are performing poorly.

**Respuesta de la fuente:** B

**Explicación:** Stackdriver Trace is designed for distributed tracing, allowing you to visualize request propagation across multiple services and identify latency bottlenecks in inter-service communication.
While Profiler focuses on CPU/heap usage within a single process and Debugger inspects runtime variables, Trace provides the necessary visibility into HTTP request dependencies to anticipate performance issues caused by slow downstream applications.

## Pregunta 2

Contexto: [topics:104](#topics-104)
You created a Stackdriver chart for CPU utilization in a dashboard within your workspace project. You want to share the chart with your Site Reliability Engineering
(SRE) team only. You want to ensure you follow the principle of least privilege. What should you do?

**A.** Share the workspace Project ID with the SRE team. Assign the SRE team the Monitoring Viewer IAM role in the workspace project.

**B.** Share the workspace Project ID with the SRE team. Assign the SRE team the Dashboard Viewer IAM role in the workspace project.

**C.** Click "Share chart by URL" and provide the URL to the SRE team. Assign the SRE team the Monitoring Viewer IAM role in the workspace project.

**D.** Click "Share chart by URL" and provide the URL to the SRE team. Assign the SRE team the Dashboard Viewer IAM role in the workspace project.

**Respuesta de la fuente:** C

**Explicación:** To share a specific chart, you must use the 'Share chart by URL' feature, which generates a direct link to that metric visualization. Assigning the Monitoring Viewer role is necessary because it grants permissions to read metric data and metadata, whereas the Dashboard Configuration Viewer only allows viewing dashboard layouts, not the underlying metrics required to render the chart.

## Pregunta 3

Contexto: [topics:104](#topics-104)
Your organization wants to implement Site Reliability Engineering (SRE) culture and principles. Recently, a service that you support had a limited outage. A manager on another team asks you to provide a formal explanation of what happened so they can action remediations. What should you do?

**A.** Develop a postmortem that includes the root causes, resolution, lessons learned, and a prioritized list of action items. Share it with the manager only.

**B.** Develop a postmortem that includes the root causes, resolution, lessons learned, and a prioritized list of action items. Share it on the engineering organization's document portal.

**C.** Develop a postmortem that includes the root causes, resolution, lessons learned, the list of people responsible, and a list of action items for each person. Share it with the manager only.

**D.** Develop a postmortem that includes the root causes, resolution, lessons learned, the list of people responsible, and a list of action items for each person. Share it on the engineering organization's document portal.

**Respuesta de la fuente:** B

**Explicación:** SRE postmortems must be blameless, meaning they focus on systemic issues rather than assigning individual responsibility, which eliminates options C and D.
Sharing the postmortem widely within the engineering organization (Option B) ensures transparency and allows the entire team to learn from the incident, whereas restricting access to a single manager (Options A and C) contradicts the SRE principle of broad knowledge sharing.

## Pregunta 4

Contexto: [topics:104](#topics-104)
You have a set of applications running on a Google Kubernetes Engine (GKE) cluster, and you are using Stackdriver Kubernetes Engine Monitoring. You are bringing a new containerized application required by your company into production. This application is written by a third party and cannot be modified or reconfigured. The application writes its log information to /var/log/app_messages.log, and you want to send these log entries to Stackdriver Logging. What should you do?

**A.** Use the default Stackdriver Kubernetes Engine Monitoring agent configuration.

**B.** Deploy a Fluentd daemonset to GKE. Then create a customized input and output configuration to tail the log file in the application's pods and write to Stackdriver Logging.

**C.** Install Kubernetes on Google Compute Engine (GCE) and redeploy your applications. Then customize the built-in Stackdriver Logging configuration to tail the log file in the application's pods and write to Stackdriver Logging.

**D.** Write a script to tail the log file within the pod and write entries to standard output. Run the script as a sidecar container with the application's pod. Configure a shared volume between the containers to allow the script to have read access to /var/log in the application container.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 5

Contexto: [topics:104](#topics-104)
You are running an application in a virtual machine (VM) using a custom Debian image. The image has the Stackdriver Logging agent installed. The VM has the cloud-platform scope. The application is logging information via syslog. You want to use Stackdriver Logging in the Google Cloud Platform Console to visualize the logs. You notice that syslog is not showing up in the "All logs" dropdown list of the Logs Viewer. What is the first thing you should do?

**A.** Look for the agent's test log entry in the Logs Viewer.

**B.** Install the most recent version of the Stackdriver agent.

**C.** Verify the VM service account access scope includes the monitoring.write scope.

**D.** SSH to the VM and execute the following commands on your VM: ps ax | grep fluentd.

**Respuesta de la fuente:** D

**Explicación:** The correct answer is D. Troubleshooting best practices dictate verifying that the agent process (Fluentd) is actively running before investigating configuration or permissions issues.
Checking `ps ax | grep fluentd` confirms if the service is up, which is a prerequisite for log ingestion.
Option C is incorrect because it references `monitoring.write`, whereas logging requires `logging.write`; however, the `cloud-platform` scope already grants all necessary access.

## Pregunta 6

Contexto: [topics:104](#topics-104)
You use a multiple step Cloud Build pipeline to build and deploy your application to Google Kubernetes Engine (GKE). You want to integrate with a third-party monitoring platform by performing a HTTP POST of the build information to a webhook. You want to minimize the development effort. What should you do?

**A.** Add logic to each Cloud Build step to HTTP POST the build information to a webhook.

**B.** Add a new step at the end of the pipeline in Cloud Build to HTTP POST the build information to a webhook.

**C.** Use Stackdriver Logging to create a logs-based metric from the Cloud Build logs. Create an Alert with a Webhook notification type.

**D.** Create a Cloud Pub/Sub push subscription to the Cloud Build cloud-builds PubSub topic to HTTP POST the build information to a webhook.

**Respuesta de la fuente:** D

**Explicación:** Cloud Build automatically publishes build events to a Cloud Pub/Sub topic named 'cloud-builds'.
By configuring a Pub/Sub push subscription with an HTTP endpoint, you can forward these events directly to the third-party webhook without writing custom code for each build step.
This serverless integration minimizes development effort compared to adding manual HTTP POST logic to every build stage.

## Pregunta 7

Contexto: [topics:104](#topics-104)
You use Spinnaker to deploy your application and have created a canary deployment stage in the pipeline. Your application has an in-memory cache that loads objects at start time. You want to automate the comparison of the canary version against the production version. How should you configure the canary analysis?

**A.** Compare the canary with a new deployment of the current production version.

**B.** Compare the canary with a new deployment of the previous production version.

**C.** Compare the canary with the existing deployment of the current production version.

**D.** Compare the canary with the average performance of a sliding window of previous production versions.

**Respuesta de la fuente:** A

**Explicación:** Spinnaker best practices dictate comparing the canary against a fresh baseline deployment of the current production version rather than existing production instances.
This ensures both deployments start simultaneously with identical conditions, such as cold in-memory caches and equal heap sizes, isolating the code change as the only variable.

## Pregunta 8

Contexto: [topics:104](#topics-104)
You support a high-traffic web application and want to ensure that the home page loads in a timely manner. As a first step, you decide to implement a Service
Level Indicator (SLI) to represent home page request latency with an acceptable page load time set to 100 ms. What is the Google-recommended way of calculating this SLI?

**A.** Bucketize the request latencies into ranges, and then compute the percentile at 100 ms.

**B.** Bucketize the request latencies into ranges, and then compute the median and 90th percentiles.

**C.** Count the number of home page requests that load in under 100 ms, and then divide by the total number of home page requests.

**D.** Count the number of home page request that load in under 100 ms, and then divide by the total number of all web application requests.

**Respuesta de la fuente:** C

**Explicación:** Google SRE principles define a Service Level Indicator (SLI) as the ratio of good events to valid total events for the specific service in scope. For latency, a 'good event' is a request meeting the performance target (under 100 ms), and the denominator must be the total number of requests to that specific service (the home page). Option C correctly calculates this ratio, whereas A and B compute statistical distributions rather than a compliance ratio, and D incorrectly includes irrelevant requests from other parts of the application.

## Pregunta 9

Contexto: [topics:104](#topics-104)
You deploy a new release of an internal application during a weekend maintenance window when there is minimal user tragic. After the window ends, you learn that one of the new features isn't working as expected in the production environment. After an extended outage, you roll back the new release and deploy a fix.
You want to modify your release process to reduce the mean time to recovery so you can avoid extended outages in the future. What should you do? (Choose two.)

**A.** Before merging new code, require 2 different peers to review the code changes.

**B.** Adopt the blue/green deployment strategy when releasing new code via a CD server.

**C.** Integrate a code linting tool to validate coding standards before any code is accepted into the repository.

**D.** Require developers to run automated integration tests on their local development environments before release.

**E.** Configure a CI server. Add a suite of unit tests to your code and have your CI server run them on commit and verify any changes.

**Respuesta de la fuente:** B, E

**Explicación:** Blue/green deployment (B) drastically reduces Mean Time to Recovery by allowing instant traffic switching back to the stable environment if issues arise, avoiding extended outages.

Integrating a CI server with automated unit tests (E) ensures regressions are caught early in the development pipeline before reaching production, preventing defects that cause downtime.

## Pregunta 10

Contexto: [topics:104](#topics-104)
You have a pool of application servers running on Compute Engine. You need to provide a secure solution that requires the least amount of configuration and allows developers to easily access application logs for troubleshooting. How would you implement the solution on GCP?

**A.** "¢ Deploy the Stackdriver logging agent to the application servers. "¢ Give the developers the IAM Logs Viewer role to access Stackdriver and view logs.

**B.** "¢ Deploy the Stackdriver logging agent to the application servers. "¢ Give the developers the IAM Logs Private Logs Viewer role to access Stackdriver and view logs.

**C.** "¢ Deploy the Stackdriver monitoring agent to the application servers. "¢ Give the developers the IAM Monitoring Viewer role to access Stackdriver and view metrics.

**D.** "¢ Install the gsutil command line tool on your application servers. "¢ Write a script using gsutil to upload your application log to a Cloud Storage bucket, and then schedule it to run via cron every 5 minutes. "¢ Give the developers the IAM Object Viewer access to view the logs in the specified bucket.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because deploying the Stackdriver Logging agent (now part of Cloud Logging) is the standard method for collecting logs from Compute Engine instances, and the `logs.viewer` IAM role grants read-only access to view these logs.

This solution requires minimal configuration compared to writing custom scripts to upload logs to Cloud Storage (Option D).

Options B and C are incorrect: `logs.privateLogsViewer` is restricted to Data Access audit logs which are not standard application logs, and the Monitoring agent collects metrics rather than raw log entries needed for troubleshooting.

## Pregunta 11

Contexto: [topics:104](#topics-104)
You support the backend of a mobile phone game that runs on a Google Kubernetes Engine (GKE) cluster. The application is serving HTTP requests from users.
You need to implement a solution that will reduce the network cost. What should you do?

**A.** Configure the VPC as a Shared VPC Host project.

**B.** Configure your network services on the Standard Tier.

**C.** Configure your Kubernetes cluster as a Private Cluster.

**D.** Configure a Google Cloud HTTP Load Balancer as Ingress.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 12

Contexto: [topics:104](#topics-104)
You encountered a major service outage that affected all users of the service for multiple hours. After several hours of incident management, the service returned to normal, and user access was restored. You need to provide an incident summary to relevant stakeholders following the Site Reliability Engineering recommended practices. What should you do first?

**A.** Call individual stakeholders to explain what happened.

**B.** Develop a post-mortem to be distributed to stakeholders.

**C.** Send the Incident State Document to all the stakeholders.

**D.** Require the engineer responsible to write an apology email to all stakeholders.

**Respuesta de la fuente:** B

**Explicación:** Site Reliability Engineering (SRE) practices emphasize a blameless post-mortem to analyze the root cause and improve system reliability. This document provides a structured summary of the incident for stakeholders, ensuring transparency and learning opportunities. Options A and C are less effective as initial comprehensive summaries, while D contradicts the core SRE principle of blamelessness.

## Pregunta 13

Contexto: [topics:104](#topics-104)
You are performing a semi-annual capacity planning exercise for your flagship service. You expect a service user growth rate of 10% month-over-month over the next six months. Your service is fully containerized and runs on Google Cloud Platform (GCP), using a Google Kubernetes Engine (GKE) Standard regional cluster on three zones with cluster autoscaler enabled. You currently consume about 30% of your total deployed CPU capacity, and you require resilience against the failure of a zone. You want to ensure that your users experience minimal negative impact as a result of this growth or as a result of zone failure, while avoiding unnecessary costs. How should you prepare to handle the predicted growth?

**A.** Verify the maximum node pool size, enable a horizontal pod autoscaler, and then perform a load test to verify your expected resource needs.

**B.** Because you are deployed on GKE and are using a cluster autoscaler, your GKE cluster will scale automatically, regardless of growth rate.

**C.** Because you are at only 30% utilization, you have significant headroom and you won't need to add any additional capacity for this rate of growth.

**D.** Proactively add 60% more node capacity to account for six months of 10% growth rate, and then perform a load test to make sure you have enough capacity.

**Respuesta de la fuente:** A

**Explicación:** The Cluster Autoscaler only adds nodes when pods cannot be scheduled due to resource constraints; it does not scale the number of pods themselves. To handle increased user load, you must configure a Horizontal Pod Autoscaler (HPA) to automatically increase replica counts based on CPU or memory metrics. Verifying the maximum node pool size ensures the Cluster Autoscaler has the capacity to provision the nodes required by the scaled-up pods, and load testing validates that these mechanisms work together effectively under stress.

## Pregunta 14

Contexto: [topics:104](#topics-104)
Your application images are built and pushed to Google Container Registry (GCR). You want to build an automated pipeline that deploys the application when the image is updated while minimizing the development effort. What should you do?

**A.** Use Cloud Build to trigger a Spinnaker pipeline.

**B.** Use Cloud Pub/Sub to trigger a Spinnaker pipeline.

**C.** Use a custom builder in Cloud Build to trigger Jenkins pipeline.

**D.** Use Cloud Pub/Sub to trigger a custom deployment service running in Google Kubernetes Engine (GKE).

**Respuesta de la fuente:** B

**Explicación:** Google Container Registry natively publishes events to Cloud Pub/Sub when new container images are pushed.
Spinnaker is the recommended multi-cloud continuous delivery platform for Google Cloud, and it can be configured to listen for these Pub/Sub messages to automatically trigger deployment pipelines.
This serverless event-driven approach minimizes development effort by eliminating the need to build custom scripts or maintain external CI/CD tools like Jenkins.

## Pregunta 15

Contexto: [topics:104](#topics-104)
Your product is currently deployed in three Google Cloud Platform (GCP) zones with your users divided between the zones. You can fail over from one zone to another, but it causes a 10-minute service disruption for the affected users. You typically experience a database failure once per quarter and can detect it within five minutes. You are cataloging the reliability risks of a new real-time chat feature for your product. You catalog the following information for each risk:
* Mean Time to Detect (MTTD) in minutes
* Mean Time to Repair (MTTR) in minutes
* Mean Time Between Failure (MTBF) in days
* User Impact Percentage
The chat feature requires a new database system that takes twice as long to successfully fail over between zones. You want to account for the risk of the new database failing in one zone. What would be the values for the risk of database failover with the new system?

**A.** MTTD: 5 MTTR: 10 MTBF: 90 Impact: 33%

**B.** MTTD: 5 MTTR: 20 MTBF: 90 Impact: 33%

**C.** MTTD: 5 MTTR: 10 MTBF: 90 Impact: 50%

**D.** MTTD: 5 MTTR: 20 MTBF: 90 Impact: 50%

**Respuesta de la fuente:** B

**Explicación:** The Mean Time to Detect (MTTD) remains 5 minutes as detection capability is unchanged. The Mean Time to Repair (MTTR) doubles to 20 minutes because the new system takes twice as long to fail over (2 * 10 min). The User Impact is 33% because users are divided across three zones, so a single zone failure affects approximately one-third of the user base.

## Pregunta 16

Contexto: [topics:104](#topics-104)
You are managing the production deployment to a set of Google Kubernetes Engine (GKE) clusters. You want to make sure only images which are successfully built by your trusted CI/CD pipeline are deployed to production. What should you do?

**A.** Enable Cloud Security Scanner on the clusters.

**B.** Enable Vulnerability Analysis on the Container Registry.

**C.** Set up the Kubernetes Engine clusters as private clusters.

**D.** Set up the Kubernetes Engine clusters with Binary Authorization.

**Respuesta de la fuente:** D

**Explicación:** Binary Authorization is a deploy-time security service that enforces admission control on GKE clusters. It ensures that only container images with attested signatures from trusted sources (like your CI/CD pipeline) are allowed to be deployed, directly addressing the requirement for image trust verification.

## Pregunta 17

Contexto: [topics:104](#topics-104)
You support an e-commerce application that runs on a large Google Kubernetes Engine (GKE) cluster deployed on-premises and on Google Cloud Platform. The application consists of microservices that run in containers. You want to identify containers that are using the most CPU and memory. What should you do?

**A.** Use Stackdriver Kubernetes Engine Monitoring.

**B.** Use Prometheus to collect and aggregate logs per container, and then analyze the results in Grafana.

**C.** Use the Stackdriver Monitoring API to create custom metrics, and then organize your containers using groups.

**D.** Use Stackdriver Logging to export application logs to BigQuery, aggregate logs per container, and then analyze CPU and memory consumption.

**Respuesta de la fuente:** A

**Explicación:** Cloud Monitoring (formerly Stackdriver) is the native solution for GKE on-prem and provides in-cluster agents to collect standard metrics like CPU and memory utilization.
Unlike Prometheus, which is disabled by default, Cloud Monitoring offers an integrated, out-of-the-box experience for monitoring container resource usage across hybrid environments.

## Pregunta 18

Contexto: [topics:104](#topics-104)
Your company experiences bugs, outages, and slowness in its production systems. Developers use the production environment for new feature development and bug fixes. Configuration and experiments are done in the production environment, causing outages for users. Testers use the production environment for load testing, which often slows the production systems. You need to redesign the environment to reduce the number of bugs and outages in production and to enable testers to toad test new features. What should you do?

**A.** Create an automated testing script in production to detect failures as soon as they occur.

**B.** Create a development environment with smaller server capacity and give access only to developers and testers.

**C.** Secure the production environment to ensure that developers can't change it and set up one controlled update per year.

**D.** Create a development environment for writing code and a test environment for configurations, experiments, and load testing.

**Respuesta de la fuente:** D

**Explicación:** The scenario describes a lack of environment isolation, where development and testing activities directly impact production stability.
Separating environments into distinct Development (for coding) and Testing (for configurations and load testing) spaces prevents non-production workloads from causing outages or slowness in the live system.
This separation ensures that only validated code and configurations reach production, thereby reducing bugs and enabling accurate load testing without risking user experience.

## Pregunta 19

Contexto: [topics:104](#topics-104)
You support an application running on App Engine. The application is used globally and accessed from various device types. You want to know the number of connections. You are using Stackdriver Monitoring for App Engine. What metric should you use?

**A.** flex/connections/current

**B.** tcp_ssl_proxy/new_connections

**C.** tcp_ssl_proxy/open_connections

**D.** flex/instance/connections/current

**Respuesta de la fuente:** A

**Explicación:** The question specifies monitoring an App Engine application globally, which requires metrics specific to the App Engine service rather than Cloud Load Balancing (options B and C). Between the App Engine options, `flex/connections/current` provides the aggregate connection count for the version/application, whereas `flex/instance/connections/current` is scoped to individual instances. Since the goal is to monitor the application as a whole, the version-level metric is the correct choice.

## Pregunta 20

Contexto: [topics:104](#topics-104)
You support an application deployed on Compute Engine. The application connects to a Cloud SQL instance to store and retrieve data. After an update to the application, users report errors showing database timeout messages. The number of concurrent active users remained stable. You need to find the most probable cause of the database timeout. What should you do?

**A.** Check the serial port logs of the Compute Engine instance.

**B.** Use Stackdriver Profiler to visualize the resources utilization throughout the application.

**C.** Determine whether there is an increased number of connections to the Cloud SQL instance.

**D.** Use Cloud Security Scanner to see whether your Cloud SQL is under a Distributed Denial of Service (DDoS) attack.

**Respuesta de la fuente:** B

**Explicación:** The most probable cause is an application-side issue introduced by the recent update, such as inefficient code or resource contention, rather than a database capacity issue since user concurrency remained stable. Stackdriver Profiler (now Cloud Profiler) provides visibility into CPU and memory utilization within the application code, allowing you to identify performance bottlenecks like slow queries or high processing overhead that lead to timeouts. Checking connection counts (Option C) confirms symptoms but does not diagnose the root cause within the application logic.

## Pregunta 21

Contexto: [topics:104](#topics-104)
Your application images are built using Cloud Build and pushed to Google Container Registry (GCR). You want to be able to specify a particular version of your application for deployment based on the release version tagged in source control. What should you do when you push the image?

**A.** Reference the image digest in the source control tag.

**B.** Supply the source control tag as a parameter within the image name.

**C.** Use Cloud Build to include the release version tag in the application image.

**D.** Use GCR digest versioning to match the image to the tag in source control.

**Respuesta de la fuente:** C

**Explicación:** Cloud Build provides built-in substitution variables, such as $TAG_NAME, which capture the source control tag from the commit that triggered the build.
By configuring the build step to use this variable in the Docker image tag during the push to GCR, you ensure the container image is versioned identically to the source code release.
This allows deployment systems to reference a specific application version directly via its matching container image tag.

## Pregunta 22

Contexto: [topics:104](#topics-104)
You are on-call for an infrastructure service that has a large number of dependent systems. You receive an alert indicating that the service is failing to serve most of its requests and all of its dependent systems with hundreds of thousands of users are affected. As part of your Site Reliability Engineering (SRE) incident management protocol, you declare yourself Incident Commander (IC) and pull in two experienced people from your team as Operations Lead (OL) and
Communications Lead (CL). What should you do next?

**A.** Look for ways to mitigate user impact and deploy the mitigations to production.

**B.** Contact the affected service owners and update them on the status of the incident.

**C.** Establish a communication channel where incident responders and leads can communicate with each other.

**D.** Start a postmortem, add incident information, circulate the draft internally, and ask internal stakeholders for input.

**Respuesta de la fuente:** C

**Explicación:** In Site Reliability Engineering (SRE) incident management, the Incident Commander's first priority after assembling the team is to establish a dedicated communication channel (e.g., chat or phone bridge). This ensures coordinated information flow before any mitigation actions are attempted by the Operations Lead. Directly deploying mitigations without this coordination violates role separation principles, as the IC manages the process while the OL executes technical fixes.

## Pregunta 23

Contexto: [topics:104](#topics-104)
You are developing a strategy for monitoring your Google Cloud Platform (GCP) projects in production using Stackdriver Workspaces. One of the requirements is to be able to quickly identify and react to production environment issues without false alerts from development and staging projects. You want to ensure that you adhere to the principle of least privilege when providing relevant team members with access to Stackdriver Workspaces. What should you do?

**A.** Grant relevant team members read access to all GCP production projects. Create Stackdriver workspaces inside each project.

**B.** Grant relevant team members the Project Viewer IAM role on all GCP production projects. Create Stackdriver workspaces inside each project.

**C.** Choose an existing GCP production project to host the monitoring workspace. Attach the production projects to this workspace. Grant relevant team members read access to the Stackdriver Workspace.

**D.** Create a new GCP monitoring project and create a Stackdriver Workspace inside it. Attach the production projects to this workspace. Grant relevant team members read access to the Stackdriver Workspace.

**Respuesta de la fuente:** D

**Explicación:** Creating a dedicated monitoring project isolates the workspace resource from production workloads, adhering to best practices for separation of concerns and security.
Attaching only production projects to this workspace ensures that development and staging data are excluded, preventing false alerts and noise.
Granting team members access solely to the Stackdriver Workspace enforces the principle of least privilege by limiting their permissions to monitoring resources rather than granting broad read access to all production project assets.

## Pregunta 24

Contexto: [topics:104](#topics-104)
You currently store the virtual machine (VM) utilization logs in Stackdriver. You need to provide an easy-to-share interactive VM utilization dashboard that is updated in real time and contains information aggregated on a quarterly basis. You want to use Google Cloud Platform solutions. What should you do?

**A.** 1. Export VM utilization logs from Stackdriver to BigQuery. 2. Create a dashboard in Data Studio. 3. Share the dashboard with your stakeholders.

**B.** 1. Export VM utilization logs from Stackdriver to Cloud Pub/Sub. 2. From Cloud Pub/Sub, send the logs to a Security Information and Event Management (SIEM) system. 3. Build the dashboards in the SIEM system and share with your stakeholders.

**C.** 1. Export VM utilization logs from Stackdriver to BigQuery. 2. From BigQuery, export the logs to a CSV file. 3. Import the CSV file into Google Sheets. 4. Build a dashboard in Google Sheets and share it with your stakeholders.

**D.** 1. Export VM utilization logs from Stackdriver to a Cloud Storage bucket. 2. Enable the Cloud Storage API to pull the logs programmatically. 3. Build a custom data visualization application. 4. Display the pulled logs in a custom dashboard.

**Respuesta de la fuente:** A

**Explicación:** Exporting logs to BigQuery enables efficient SQL-based aggregation of quarterly data from large datasets.
Data Studio (Looker) connects directly to BigQuery to create interactive, real-time dashboards that are easily shared with stakeholders.
This approach avoids the manual overhead and scalability limits of CSV exports or custom application development.

## Pregunta 25

Contexto: [topics:104](#topics-104)
You need to run a business-critical workload on a fixed set of Compute Engine instances for several months. The workload is stable with the exact amount of resources allocated to it. You want to lower the costs for this workload without any performance implications. What should you do?

**A.** Purchase Committed Use Discounts.

**B.** Migrate the instances to a Managed Instance Group.

**C.** Convert the instances to preemptible virtual machines.

**D.** Create an Unmanaged Instance Group for the instances used to run the workload.

**Respuesta de la fuente:** A

**Explicación:** Committed Use Discounts provide significant cost savings for stable, long-term workloads (1 or 3 years) while ensuring the instances remain available and performant.
Preemptible VMs are unsuitable because they can be terminated by Google Cloud at any time without notice, violating the 'business-critical' and 'no performance implications' requirements.

## Pregunta 26

Contexto: [topics:104](#topics-104)
You are part of an organization that follows SRE practices and principles. You are taking over the management of a new service from the Development Team, and you conduct a Production Readiness Review (PRR). After the PRR analysis phase, you determine that the service cannot currently meet its Service Level
Objectives (SLOs). You want to ensure that the service can meet its SLOs in production. What should you do next?

**A.** Adjust the SLO targets to be achievable by the service so you can bring it into production.

**B.** Notify the development team that they will have to provide production support for the service.

**C.** Identify recommended reliability improvements to the service to be completed before handover.

**D.** Bring the service into production with no SLOs and build them when you have collected operational data.

**Respuesta de la fuente:** C

**Explicación:** In SRE practices, a Production Readiness Review (PRR) serves as a gate to ensure reliability standards are met before production deployment. If the service cannot currently meet its Service Level Objectives (SLOs), the appropriate next step is to identify specific reliability improvements required to bridge that gap. Adjusting SLOs or delaying their definition undermines the purpose of PRR, while refusing handover without improvement plans violates the collaborative nature of SRE.

## Pregunta 27

Contexto: [topics:104](#topics-104)
You are running an experiment to see whether your users like a new feature of a web application. Shortly after deploying the feature as a canary release, you receive a spike in the number of 500 errors sent to users, and your monitoring reports show increased latency. You want to quickly minimize the negative impact on users. What should you do first?

**A.** Roll back the experimental canary release.

**B.** Start monitoring latency, traffic, errors, and saturation.

**C.** Record data for the postmortem document of the incident.

**D.** Trace the origin of 500 errors and the root cause of increased latency.

**Respuesta de la fuente:** A

**Explicación:** The primary goal in this scenario is to quickly minimize negative impact on users.
Rolling back the canary release (A) immediately restores the stable state, whereas investigating root causes (D) or recording data (C) takes time during which users continue to experience errors.
Monitoring (B) is already happening and will not fix the immediate issue.

## Pregunta 28

Contexto: [topics:104](#topics-104)
You are responsible for creating and modifying the Terraform templates that define your Infrastructure. Because two new engineers will also be working on the same code, you need to define a process and adopt a tool that will prevent you from overwriting each other's code. You also want to ensure that you capture all updates in the latest version. What should you do?

**A.** "¢ Store your code in a Git-based version control system. "¢ Establish a process that allows developers to merge their own changes at the end of each day. "¢ Package and upload code to a versioned Cloud Storage basket as the latest master version.

**B.** "¢ Store your code in a Git-based version control system. "¢ Establish a process that includes code reviews by peers and unit testing to ensure integrity and functionality before integration of code. "¢ Establish a process where the fully integrated code in the repository becomes the latest master version.

**C.** "¢ Store your code as text files in Google Drive in a defined folder structure that organizes the files. "¢ At the end of each day, confirm that all changes have been captured in the files within the folder structure. "¢ Rename the folder structure with a predefined naming convention that increments the version.

**D.** "¢ Store your code as text files in Google Drive in a defined folder structure that organizes the files. "¢ At the end of each day, confirm that all changes have been captured in the files within the folder structure and create a new .zip archive with a predefined naming convention. "¢ Upload the .zip archive to a versioned Cloud Storage bucket and accept it as the latest version.

**Respuesta de la fuente:** B

**Explicación:** Git-based version control is the industry standard for managing Infrastructure as Code (IaC) because it tracks changes, handles merge conflicts, and maintains history, whereas Google Drive lacks these capabilities.
Peer reviews and unit testing are essential practices to ensure code integrity before merging, preventing broken infrastructure definitions from entering the main branch.
Option B correctly combines Git with a rigorous integration process, while Option A adds unnecessary Cloud Storage uploads and Options C/D rely on non-IaC compatible file storage systems.

## Pregunta 29

Contexto: [topics:104](#topics-104)
You support a high-traffic web application with a microservice architecture. The home page of the application displays multiple widgets containing content such as the current weather, stock prices, and news headlines. The main serving thread makes a call to a dedicated microservice for each widget and then lays out the homepage for the user. The microservices occasionally fail; when that happens, the serving thread serves the homepage with some missing content. Users of the application are unhappy if this degraded mode occurs too frequently, but they would rather have some content served instead of no content at all. You want to set a Service Level Objective (SLO) to ensure that the user experience does not degrade too much. What Service Level Indicator (SLI) should you use to measure this?

**A.** A quality SLI: the ratio of non-degraded responses to total responses.

**B.** An availability SLI: the ratio of healthy microservices to the total number of microservices.

**C.** A freshness SLI: the proportion of widgets that have been updated within the last 10 minutes.

**D.** A latency SLI: the ratio of microservice calls that complete in under 100 ms to the total number of microservice calls.

**Respuesta de la fuente:** A

**Explicación:** The scenario describes a system designed to fail gracefully by serving partial content when dependencies are unavailable. A Quality SLI is specifically defined as the proportion of valid requests served without degradation of service, making it the correct metric for measuring user experience in this context.

## Pregunta 30

Contexto: [topics:104](#topics-104)
You support a multi-region web service running on Google Kubernetes Engine (GKE) behind a Global HTTP/S Cloud Load Balancer (CLB). For legacy reasons, user requests first go through a third-party Content Delivery Network (CDN), which then routes traffic to the CLB. You have already implemented an availability
Service Level Indicator (SLI) at the CLB level. However, you want to increase coverage in case of a potential load balancer misconfiguration, CDN failure, or other global networking catastrophe. Where should you measure this new SLI? (Choose two.)

**A.** Your application servers' logs.

**B.** Instrumentation coded directly in the client.

**C.** Metrics exported from the application servers.

**D.** GKE health checks for your application servers.

**E.** A synthetic client that periodically sends simulated user requests.

**Respuesta de la fuente:** B, E

**Explicación:** To detect failures upstream of the load balancer (such as CDN or global networking issues), you must measure availability from outside the GCP infrastructure. Client instrumentation (B) captures real user experiences end-to-end, while synthetic clients (E) simulate user traffic to verify external connectivity and path health, neither of which are covered by internal server metrics or health checks.

## Pregunta 31

Contexto: [topics:104](#topics-104)
Your team is designing a new application for deployment into Google Kubernetes Engine (GKE). You need to set up monitoring to collect and aggregate various application-level metrics in a centralized location. You want to use Google Cloud Platform services while minimizing the amount of work required to set up monitoring. What should you do?

**A.** Publish various metrics from the application directly to the Stackdriver Monitoring API, and then observe these custom metrics in Stackdriver.

**B.** Install the Cloud Pub/Sub client libraries, push various metrics from the application to various topics, and then observe the aggregated metrics in Stackdriver.

**C.** Install the OpenTelemetry client libraries in the application, configure Stackdriver as the export destination for the metrics, and then observe the application's metrics in Stackdriver.

**D.** Emit all metrics in the form of application-specific log messages, pass these messages from the containers to the Stackdriver logging collector, and then observe metrics in Stackdriver.

**Respuesta de la fuente:** C

**Explicación:** Option C is the correct answer because OpenTelemetry provides a standardized, vendor-neutral instrumentation layer that simplifies the setup and management of metrics compared to writing custom integrations.
By using OpenTelemetry client libraries with Stackdriver (Cloud Monitoring) as the exporter, you minimize implementation effort while leveraging Google Cloud's native aggregation capabilities.
Option A requires manual handling of the monitoring API for each metric type, which is more labor-intensive, whereas Options B and D introduce unnecessary complexity or misalignment between logs and metrics.

## Pregunta 32

Contexto: [topics:104](#topics-104)
You support a production service that runs on a single Compute Engine instance. You regularly need to spend time on recreating the service by deleting the crashing instance and creating a new instance based on the relevant image. You want to reduce the time spent performing manual operations while following Site
Reliability Engineering principles. What should you do?

**A.** File a bug with the development team so they can find the root cause of the crashing instance.

**B.** Create a Managed instance Group with a single instance and use health checks to determine the system status.

**C.** Add a Load Balancer in front of the Compute Engine instance and use health checks to determine the system status.

**D.** Create a Stackdriver Monitoring dashboard with SMS alerts to be able to start recreating the crashed instance promptly after it was crashed.

**Respuesta de la fuente:** B

**Explicación:** The goal is to automate recovery and reduce manual effort, which aligns with Site Reliability Engineering (SRE) principles of automation and self-healing systems. A Managed Instance Group (MIG) combined with health checks automatically detects when the instance becomes unhealthy and replaces it without human intervention. This eliminates the need for manual recreation of the instance, directly addressing the requirement to reduce time spent on manual operations.

## Pregunta 33

Contexto: [topics:104](#topics-104)
Your application artifacts are being built and deployed via a CI/CD pipeline. You want the CI/CD pipeline to securely access application secrets. You also want to more easily rotate secrets in case of a security breach. What should you do?

**A.** Prompt developers for secrets at build time. Instruct developers to not store secrets at rest.

**B.** Store secrets in a separate configuration file on Git. Provide select developers with access to the configuration file.

**C.** Store secrets in Cloud Storage encrypted with a key from Cloud KMS. Provide the CI/CD pipeline with access to Cloud KMS via IAM.

**D.** Encrypt the secrets and store them in the source code repository. Store a decryption key in a separate repository and grant your pipeline access to it.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because using a dedicated secret management solution like Cloud Storage with Cloud KMS encryption provides centralized control and auditability.
It enables seamless secret rotation without modifying code or pipeline configurations, addressing the requirement for easier rotation during breaches.
Options A, B, and D are insecure or impractical, as they involve manual intervention, storing secrets in version control (even if encrypted), or splitting keys across repositories.

## Pregunta 34

Contexto: [topics:104](#topics-104)
Your company follows Site Reliability Engineering practices. You are the person in charge of Communications for a large, ongoing incident affecting your customer-facing applications. There is still no estimated time for a resolution of the outage. You are receiving emails from internal stakeholders who want updates on the outage, as well as emails from customers who want to know what is happening. You want to efficiently provide updates to everyone affected by the outage.
What should you do?

**A.** Focus on responding to internal stakeholders at least every 30 minutes. Commit to "next update" times.

**B.** Provide periodic updates to all stakeholders in a timely manner. Commit to a "next update" time in all communications.

**C.** Delegate the responding to internal stakeholder emails to another member of the Incident Response Team. Focus on providing responses directly to customers.

**D.** Provide all internal stakeholder emails to the Incident Commander, and allow them to manage internal communications. Focus on providing responses directly to customers.

**Respuesta de la fuente:** B

**Explicación:** As the Communications Lead in an SRE incident, your primary responsibility is to ensure all stakeholders (internal and external) receive consistent, timely updates.
You must proactively manage expectations by committing to specific times for future updates, regardless of whether a resolution ETA exists.
Delegating responsibilities or filtering audiences violates the principle that the Communications Lead owns the communication channel for everyone affected.

## Pregunta 35

Contexto: [topics:104](#topics-104)
Your team uses Cloud Build for all CI/CD pipelines. You want to use the kubectl builder for Cloud Build to deploy new images to Google Kubernetes Engine
(GKE). You need to authenticate to GKE while minimizing development effort. What should you do?

**A.** Assign the Container Developer role to the Cloud Build service account.

**B.** Specify the Container Developer role for Cloud Build in the cloudbuild.yaml file.

**C.** Create a new service account with the Container Developer role and use it to run Cloud Build.

**D.** Create a separate step in Cloud Build to retrieve service account credentials and pass these to kubectl.

**Respuesta de la fuente:** A

**Explicación:** The Cloud Build service account is the identity used by Cloud Build to execute pipeline steps.
Assigning the Container Developer role directly to this existing service account (Option A) grants the necessary permissions for kubectl operations without creating additional identities or writing custom credential-retrieval logic.
This approach minimizes development effort compared to creating a new service account (Option C) or adding manual authentication steps (Option D).

## Pregunta 36

Contexto: [topics:104](#topics-104)
You support an application that stores product information in cached memory. For every cache miss, an entry is logged in Stackdriver Logging. You want to visualize how often a cache miss happens over time. What should you do?

**A.** Link Stackdriver Logging as a source in Google Data Studio. Filter the logs on the cache misses.

**B.** Configure Stackdriver Profiler to identify and visualize when the cache misses occur based on the logs.

**C.** Create a logs-based metric in Stackdriver Logging and a dashboard for that metric in Stackdriver Monitoring.

**D.** Configure BigQuery as a sink for Stackdriver Logging. Create a scheduled query to filter the cache miss logs and write them to a separate table.

**Respuesta de la fuente:** C

**Explicación:** To visualize the frequency of cache misses over time, you need a numeric metric derived from log entries. Stackdriver Logging allows you to create custom logs-based metrics (such as counter metrics) that count specific log patterns.
These metrics can then be plotted and visualized directly in Stackdriver Monitoring dashboards. Other options like Data Studio or BigQuery are less direct for real-time operational visualization, and Profiler is designed for CPU/memory usage analysis rather than event counting.

## Pregunta 37

Contexto: [topics:104](#topics-104)
You need to deploy a new service to production. The service needs to automatically scale using a Managed Instance Group (MIG) and should be deployed over multiple regions. The service needs a large number of resources for each instance and you need to plan for capacity. What should you do?

**A.** Use the n1-highcpu-96 machine type in the configuration of the MIG.

**B.** Monitor results of Stackdriver Trace to determine the required amount of resources.

**C.** Validate that the resource requirements are within the available quota limits of each region.

**D.** Deploy the service in one region and use a global load balancer to route traffic to this region.

**Respuesta de la fuente:** C

**Explicación:** The scenario emphasizes the need to 'plan for capacity' when deploying resource-intensive instances across multiple regions. In cloud environments, regional quotas limit the total number of virtual CPUs (vCPUs) and other resources available per region. Therefore, validating that requirements fit within these regional quota limits is the essential prerequisite step to ensure successful deployment.

## Pregunta 38

Contexto: [topics:104](#topics-104)
You are running an application on Compute Engine and collecting logs through Stackdriver. You discover that some personally identifiable information (PII) is leaking into certain log entry fields. All PII entries begin with the text userinfo. You want to capture these log entries in a secure location for later review and prevent them from leaking to Stackdriver Logging. What should you do?

**A.** Create a basic log filter matching userinfo, and then configure a log export in the Stackdriver console with Cloud Storage as a sink.

**B.** Use a Fluentd filter plugin with the Stackdriver Agent to remove log entries containing userinfo, and then copy the entries to a Cloud Storage bucket.

**C.** Create an advanced log filter matching userinfo, configure a log export in the Stackdriver console with Cloud Storage as a sink, and then configure a log exclusion with userinfo as a filter.

**D.** Use a Fluentd filter plugin with the Stackdriver Agent to remove log entries containing userinfo, create an advanced log filter matching userinfo, and then configure a log export in the Stackdriver console with Cloud Storage as a sink.

**Respuesta de la fuente:** B

**Explicación:** The requirement explicitly states to prevent PII from leaking into Stackdriver Logging. Options A, C, and D involve sending logs to Stackdriver first (where they are visible/leaked) before filtering or exporting. Only Option B uses the Fluentd agent at the source to filter out entries containing 'userinfo' before they are ever ingested by the logging service, ensuring they never leak into Stackdriver.

## Pregunta 39

Contexto: [topics:104](#topics-104)
You have a CI/CD pipeline that uses Cloud Build to build new Docker images and push them to Docker Hub. You use Git for code versioning. After making a change in the Cloud Build YAML configuration, you notice that no new artifacts are being built by the pipeline. You need to resolve the issue following Site
Reliability Engineering practices. What should you do?

**A.** Disable the CI pipeline and revert to manually building and pushing the artifacts.

**B.** Change the CI pipeline to push the artifacts is Container Registry instead of Docker Hub.

**C.** Upload the configuration YAML file to Cloud Storage and use Error Reporting to identify and fix the issue.

**D.** Run a Git compare between the previous and current Cloud Build Configuration files to find and fix the bug.

**Respuesta de la fuente:** D

**Explicación:** Site Reliability Engineering (SRE) practices emphasize using version control systems to track changes and diagnose issues. Since the problem appeared after modifying the Cloud Build YAML configuration, comparing the current file with the previous version via Git identifies the specific syntax or logical error introduced. This method allows for precise identification and correction of the bug without relying on manual processes or unrelated storage services.

## Pregunta 40

Contexto: [topics:104](#topics-104)
Your company follows Site Reliability Engineering principles. You are writing a postmortem for an incident, triggered by a software change, that severely affected users. You want to prevent severe incidents from happening in the future. What should you do?

**A.** Identify engineers responsible for the incident and escalate to their senior management.

**B.** Ensure that test cases that catch errors of this type are run successfully before new software releases.

**C.** Follow up with the employees who reviewed the changes and prescribe practices they should follow in the future.

**D.** Design a policy that will require on-call teams to immediately call engineers and management to discuss a plan of action if an incident occurs.

**Respuesta de la fuente:** B

**Explicación:** Site Reliability Engineering (SRE) emphasizes a blameless culture where postmortems focus on systemic process improvements rather than individual accountability. Option B is correct because adding automated test cases addresses the root cause by preventing similar defects from reaching production in the future. Options A and C focus on blaming individuals or reviews, which violates SRE principles and does not guarantee prevention, while Option D improves incident response but does not prevent the initial failure.

## Pregunta 41

Contexto: [topics:104](#topics-104)
You support a high-traffic web application that runs on Google Cloud Platform (GCP). You need to measure application reliability from a user perspective without making any engineering changes to it. What should you do? (Choose two.)

**A.** Review current application metrics and add new ones as needed.

**B.** Modify the code to capture additional information for user interaction.

**C.** Analyze the web proxy logs only and capture response time of each request.

**D.** Create new synthetic clients to simulate a user journey using the application.

**E.** Use current and historic Request Logs to trace customer interaction with the application.

**Respuesta de la fuente:** D, E

**Explicación:** To measure reliability from a user perspective without code changes, you must use existing telemetry and external simulation.
Option E (Request Logs) provides historical data on actual customer interactions and performance without requiring engineering modifications.
Option D (Synthetic Clients) allows for proactive monitoring of the user journey from an external viewpoint, also without changing application code.
Options A, B, and C are incorrect because adding metrics or modifying code requires engineering changes, while web proxy logs represent forward proxies (client-side) which are generally inaccessible to server-side administrators.

## Pregunta 42

Contexto: [topics:104](#topics-104)
You manage an application that is writing logs to Stackdriver Logging. You need to give some team members the ability to export logs. What should you do?

**A.** Grant the team members the IAM role of logging.configWriter on Cloud IAM.

**B.** Configure Access Context Manager to allow only these members to export logs.

**C.** Create and grant a custom IAM role with the permissions logging.sinks.list and logging.sink.get.

**D.** Create an Organizational Policy in Cloud IAM to allow only these members to create log exports.

**Respuesta de la fuente:** A

**Explicación:** The `roles/logging.configWriter` IAM role includes the necessary permissions (specifically `logging.sinks.create`, `logging.sinks.update`, and `logging.sinks.delete`) to create and manage log sinks, which are the mechanism used to export logs in Google Cloud.
Option C is incorrect because it only grants read-only access (`logging.sinks.list` and `logging.sinks.get`), preventing users from actually creating the sinks required for export.

## Pregunta 43

Contexto: [topics:104](#topics-104)
Your application services run in Google Kubernetes Engine (GKE). You want to make sure that only images from your centrally-managed Google Container
Registry (GCR) image registry in the altostrat-images project can be deployed to the cluster while minimizing development time. What should you do?

**A.** Create a custom builder for Cloud Build that will only push images to gcr.io/altostrat-images.

**B.** Use a Binary Authorization policy that includes the whitelist name pattern gcr.io/altostrat-images/.

**C.** Add logic to the deployment pipeline to check that all manifests contain only images from gcr.io/altostrat-images.

**D.** Add a tag to each image in gcr.io/altostrat-images and check that this tag is present when the image is deployed.

**Respuesta de la fuente:** B

**Explicación:** Binary Authorization is the recommended GKE mechanism to enforce which container images are allowed to run in a cluster. By configuring a policy with an allowlist of source repositories (e.g., gcr.io/altostrat-images/), it automatically blocks deployments using untrusted images without requiring manual pipeline logic or custom builders, thus minimizing development overhead.

## Pregunta 44

Contexto: [topics:104](#topics-104)
Your team has recently deployed an NGINX-based application into Google Kubernetes Engine (GKE) and has exposed it to the public via an HTTP Google Cloud
Load Balancer (GCLB) ingress. You want to scale the deployment of the application's frontend using an appropriate Service Level Indicator (SLI). What should you do?

**A.** Configure the horizontal pod autoscaler to use the average response time from the Liveness and Readiness probes.

**B.** Configure the vertical pod autoscaler in GKE and enable the cluster autoscaler to scale the cluster as pods expand.

**C.** Install the Stackdriver custom metrics adapter and configure a horizontal pod autoscaler to use the number of requests provided by the GCLB.

**D.** Expose the NGINX stats endpoint and configure the horizontal pod autoscaler to use the request metrics exposed by the NGINX deployment.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because the Stackdriver custom metrics adapter (now part of Google Cloud Operations) enables Kubernetes Horizontal Pod Autoscaler to scale based on external metrics like GCLB request counts, which is a direct SLI for traffic volume.
Options A and D are less appropriate as health probes are for liveness, not scaling signals, and NGINX stats require additional scraping configuration not natively integrated with standard HPA without the custom metrics adapter for Cloud Load Balancer metrics.
Option B suggests vertical scaling, which adjusts resource limits per pod rather than increasing pod count to handle increased traffic concurrency.

## Pregunta 45

Contexto: [topics:104](#topics-104)
Your company follows Site Reliability Engineering practices. You are the Incident Commander for a new, customer-impacting incident. You need to immediately assign two incident management roles to assist you in an effective incident response. What roles should you assign? (Choose two.)

**A.** Operations Lead

**B.** Engineering Lead

**C.** Communications Lead

**D.** Customer Impact Assessor

**E.** External Customer Communications Lead

**Respuesta de la fuente:** A, C

**Explicación:** According to Site Reliability Engineering (SRE) practices, the three core incident response roles are the Incident Commander (IC), Operations Lead (OL), and Communications Lead (CL).

The IC already exists in this scenario, so the two immediate assignments needed are the OL to resolve the technical issue and the CL to manage stakeholder updates.

Options A and C correspond to these essential SRE-defined roles.

## Pregunta 46

Contexto: [topics:104](#topics-104)
You support an application running on GCP and want to configure SMS notifications to your team for the most critical alerts in Stackdriver Monitoring. You have already identified the alerting policies you want to configure this for. What should you do?

**A.** Download and configure a third-party integration between Stackdriver Monitoring and an SMS gateway. Ensure that your team members add their SMS/phone numbers to the external tool.

**B.** Select the Webhook notifications option for each alerting policy, and configure it to use a third-party integration tool. Ensure that your team members add their SMS/phone numbers to the external tool.

**C.** Ensure that your team members set their SMS/phone numbers in their Stackdriver Profile. Select the SMS notification option for each alerting policy and then select the appropriate SMS/phone numbers from the list.

**D.** Configure a Slack notification for each alerting policy. Set up a Slack-to-SMS integration to send SMS messages when Slack messages are received. Ensure that your team members add their SMS/phone numbers to the external integration.

**Respuesta de la fuente:** C

**Explicación:** Google Cloud Monitoring provides native support for SMS notifications through Notification Channels, eliminating the need for third-party integrations. Users must verify their phone numbers via the profile or channel setup, and those verified numbers can then be selected directly within alerting policies.

## Pregunta 47

Contexto: [topics:104](#topics-104)
You are managing an application that exposes an HTTP endpoint without using a load balancer. The latency of the HTTP responses is important for the user experience. You want to understand what HTTP latencies all of your users are experiencing. You use Stackdriver Monitoring. What should you do?

**A.** "¢ In your application, create a metric with a metricKind set to DELTA and a valueType set to DOUBLE. "¢ In Stackdriver's Metrics Explorer, use a Stacked Bar graph to visualize the metric.

**B.** "¢ In your application, create a metric with a metricKind set to CUMULATIVE and a valueType set to DOUBLE. "¢ In Stackdriver's Metrics Explorer, use a Line graph to visualize the metric.

**C.** "¢ In your application, create a metric with a metricKind set to GAUGE and a valueType set to DISTRIBUTION. "¢ In Stackdriver's Metrics Explorer, use a Heatmap graph to visualize the metric.

**D.** "¢ In your application, create a metric with a metricKind set to METRIC_KIND_UNSPECIFIED and a valueType set to INT64. "¢ In Stackdriver's Metrics Explorer, use a Stacked Area graph to visualize the metric.

**Respuesta de la fuente:** C

**Explicación:** To understand the distribution of HTTP latencies across all users, you must use a metric with a valueType of DISTRIBUTION, which captures histograms of values including min, max, count, and buckets.
A GAUGE metricKind is appropriate here because it records the current state or snapshot of latency statistics at specific points in time.
Visualizing this data with a Heatmap graph effectively displays the frequency of different latency values over time, allowing you to identify performance trends and outliers.

## Pregunta 48

Contexto: [topics:104](#topics-104)
Your team is designing a new application for deployment both inside and outside Google Cloud Platform (GCP). You need to collect detailed metrics such as system resource utilization. You want to use centralized GCP services while minimizing the amount of work required to set up this collection system. What should you do?

**A.** Import the Stackdriver Profiler package, and configure it to relay function timing data to Stackdriver for further analysis.

**B.** Import the Stackdriver Debugger package, and configure the application to emit debug messages with timing information.

**C.** Instrument the code using a timing library, and publish the metrics via a health check endpoint that is scraped by Stackdriver.

**D.** Install an Application Performance Monitoring (APM) tool in both locations, and configure an export to a central data storage location for analysis.

**Respuesta de la fuente:** A

**Explicación:** Stackdriver Profiler (now Cloud Profiler) is designed to collect CPU and memory profiling data with minimal application overhead, making it ideal for minimizing setup work.
It supports deployment in both on-premises/non-GCP environments and GCP, allowing centralized collection of system resource utilization metrics.
Other options like Debugger are for code analysis rather than metric collection, while third-party APM tools require more complex configuration.

## Pregunta 49

Contexto: [topics:104](#topics-104)
You need to reduce the cost of virtual machines (VM) for your organization. After reviewing different options, you decide to leverage preemptible VM instances.
Which application is suitable for preemptible VMs?

**A.** A scalable in-memory caching system.

**B.** The organization's public-facing website.

**C.** A distributed, eventually consistent NoSQL database cluster with sufficient quorum.

**D.** A GPU-accelerated video rendering platform that retrieves and stores videos in a storage bucket.

**Respuesta de la fuente:** D

**Explicación:** Preemptible VMs are suitable for fault-tolerant, stateless, or batch workloads that can handle sudden termination without data loss. Video rendering is a classic example because it processes independent frames and relies on external storage buckets for input/output, allowing tasks to resume or restart if an instance is preempted. In contrast, caching systems (A) and databases (C) require high availability and state consistency, while public websites (B) demand stable uptime.

## Pregunta 50

Contexto: [topics:104](#topics-104)
Your organization recently adopted a container-based workflow for application development. Your team develops numerous applications that are deployed continuously through an automated build pipeline to a Kubernetes cluster in the production environment. The security auditor is concerned that developers or operators could circumvent automated testing and push code changes to production without approval. What should you do to enforce approvals?

**A.** Configure the build system with protected branches that require pull request approval.

**B.** Use an Admission Controller to verify that incoming requests originate from approved sources.

**C.** Leverage Kubernetes Role-Based Access Control (RBAC) to restrict access to only approved users.

**D.** Enable binary authorization inside the Kubernetes cluster and configure the build pipeline as an attestor.

**Respuesta de la fuente:** D

**Explicación:** Binary Authorization enforces security policies by verifying that container images are signed by trusted attestors before they run in Kubernetes.
By configuring the automated build pipeline as an attestor, the system ensures that only artifacts produced through approved CI/CD processes can be deployed, preventing direct pushes from developers or operators.
This mechanism directly addresses the auditor's concern about circumventing automated testing and approval workflows at the container level.

## Pregunta 51

Contexto: [topics:104](#topics-104)
You support a stateless web-based API that is deployed on a single Compute Engine instance in the europe-west2-a zone. The Service Level Indicator (SLI) for service availability is below the specified Service Level Objective (SLO). A postmortem has revealed that requests to the API regularly time out. The time outs are due to the API having a high number of requests and running out memory. You want to improve service availability. What should you do?

**A.** Change the specified SLO to match the measured SLI

**B.** Move the service to higher-specification compute instances with more memory

**C.** Set up additional service instances in other zones and load balance the traffic between all instances

**D.** Set up additional service instances in other zones and use them as a failover in case the primary instance is unavailable

**Respuesta de la fuente:** C

**Explicación:** The API is stateless, meaning it can be horizontally scaled by adding multiple instances behind a load balancer. This distributes the high request volume across several machines, preventing any single instance from exhausting memory and timing out. While increasing instance specs (Option B) offers vertical scaling, horizontal scaling via load balancing provides better availability and resilience against individual node failures.

## Pregunta 52

Contexto: [topics:104](#topics-104)
You are running a real-time gaming application on Compute Engine that has a production and testing environment. Each environment has their own Virtual Private
Cloud (VPC) network. The application frontend and backend servers are located on different subnets in the environment's VPC. You suspect there is a malicious process communicating intermittently in your production frontend servers. You want to ensure that network traffic is captured for analysis. What should you do?

**A.** Enable VPC Flow Logs on the production VPC network frontend and backend subnets only with a sample volume scale of 0.5.

**B.** Enable VPC Flow Logs on the production VPC network frontend and backend subnets only with a sample volume scale of 1.0.

**C.** Enable VPC Flow Logs on the testing and production VPC network frontend and backend subnets with a volume scale of 0.5. Apply changes in testing before production.

**D.** Enable VPC Flow Logs on the testing and production VPC network frontend and backend subnets with a volume scale of 1.0. Apply changes in testing before production.

**Respuesta de la fuente:** B

**Explicación:** The goal is to capture network traffic for analysis of a suspected malicious process, which requires complete visibility into the traffic flow. Enabling VPC Flow Logs with a sample rate of 1.0 ensures that 100% of packets are logged, preventing any intermittent malicious activity from being missed due to sampling. Limiting the scope to the production environment is appropriate because the issue is specific to production, and testing environments do not need this forensic data.

## Pregunta 53

Contexto: [topics:104](#topics-104)
Your team of Infrastructure DevOps Engineers is growing, and you are starting to use Terraform to manage infrastructure. You need a way to implement code versioning and to share code with other team members. What should you do?

**A.** Store the Terraform code in a version-control system. Establish procedures for pushing new versions and merging with the master.

**B.** Store the Terraform code in a network shared folder with child folders for each version release. Ensure that everyone works on different files.

**C.** Store the Terraform code in a Cloud Storage bucket using object versioning. Give access to the bucket to every team member so they can download the files.

**D.** Store the Terraform code in a shared Google Drive folder so it syncs automatically to every team member's computer. Organize files with a naming convention that identifies each new version.

**Respuesta de la fuente:** A

**Explicación:** Terraform recommends storing configuration code in a version-control system (e.g., Git) to enable collaboration, track history, and manage changes via branching and merging.
Options B, C, and D lack essential features like atomic commits, conflict resolution, and audit trails, making them unsuitable for team-based infrastructure management.

## Pregunta 54

Contexto: [topics:104](#topics-104)
You are using Stackdriver to monitor applications hosted on Google Cloud Platform (GCP). You recently deployed a new application, but its logs are not appearing on the Stackdriver dashboard.
You need to troubleshoot the issue. What should you do?

**A.** Confirm that the Stackdriver agent has been installed in the hosting virtual machine.

**B.** Confirm that your account has the proper permissions to use the Stackdriver dashboard.

**C.** Confirm that port 25 has been opened in the firewall to allow messages through to Stackdriver.

**D.** Confirm that the application is using the required client library and the service account key has proper permissions.

**Respuesta de la fuente:** A

**Explicación:** The most critical prerequisite for collecting logs from a GCP VM is the installation of the Stackdriver (now Cloud Logging) agent.
Without this agent running on the virtual machine, the application's logs cannot be exported to the Stackdriver dashboard regardless of other configurations.
While service account permissions are important, verifying the presence and status of the agent is the primary troubleshooting step for missing logs on Compute Engine.

## Pregunta 55

Contexto: [topics:104](#topics-104)
Your organization recently adopted a container-based workflow for application development. Your team develops numerous applications that are deployed continuously through an automated build pipeline to the production environment. A recent security audit alerted your team that the code pushed to production could contain vulnerabilities and that the existing tooling around virtual machine (VM) vulnerabilities no longer applies to the containerized environment. You need to ensure the security and patch level of all code running through the pipeline. What should you do?

**A.** Set up Container Analysis to scan and report Common Vulnerabilities and Exposures.

**B.** Configure the containers in the build pipeline to always update themselves before release.

**C.** Reconfigure the existing operating system vulnerability software to exist inside the container.

**D.** Implement static code analysis tooling against the Docker files used to create the containers.

**Respuesta de la fuente:** A

**Explicación:** Container Analysis is specifically designed to scan container images for Common Vulnerabilities and Exposures (CVEs) within a CI/CD pipeline, addressing the audit's concern about code vulnerabilities.
Unlike traditional VM security tools, it integrates directly with container registries to ensure only secure images are deployed.
Options B, C, and D address different aspects of development or runtime behavior but do not provide the comprehensive vulnerability scanning required for the container image itself.

## Pregunta 56

Contexto: [topics:104](#topics-104)
You use Cloud Build to build your application. You want to reduce the build time while minimizing cost and development effort. What should you do?

**A.** Use Cloud Storage to cache intermediate artifacts.

**B.** Run multiple Jenkins agents to parallelize the build.

**C.** Use multiple smaller build steps to minimize execution time.

**D.** Use larger Cloud Build virtual machines (VMs) by using the machine-type option.

**Respuesta de la fuente:** A

**Explicación:** Caching intermediate artifacts in Cloud Storage is the recommended method to reduce build time by avoiding redundant processing of dependencies.
This approach minimizes cost compared to using larger VMs and requires less development effort than re-architecting build steps or integrating external tools like Jenkins.

## Pregunta 57

Contexto: [topics:104](#topics-104)
You support a web application that is hosted on Compute Engine. The application provides a booking service for thousands of users. Shortly after the release of a new feature, your monitoring dashboard shows that all users are experiencing latency at login. You want to mitigate the impact of the incident on the users of your service. What should you do first?

**A.** Roll back the recent release.

**B.** Review the Stackdriver monitoring.

**C.** Upsize the virtual machines running the login services.

**D.** Deploy a new release to see whether it fixes the problem.

**Respuesta de la fuente:** A

**Explicación:** The question asks for the first step to mitigate the impact of an incident caused by a recent release. Rolling back to the previous stable version is the most effective way to immediately restore service availability and reduce latency for users.
Reviewing monitoring or upsizing VMs are diagnostic or scaling actions that take longer and do not directly resolve the regression introduced by the new feature.

## Pregunta 58

Contexto: [topics:104](#topics-104)
You are deploying an application that needs to access sensitive information. You need to ensure that this information is encrypted and the risk of exposure is minimal if a breach occurs. What should you do?

**A.** Store the encryption keys in Cloud Key Management Service (KMS) and rotate the keys frequently

**B.** Inject the secret at the time of instance creation via an encrypted configuration management system.

**C.** Integrate the application with a Single sign-on (SSO) system and do not expose secrets to the application.

**D.** Leverage a continuous build pipeline that produces multiple versions of the secret for each instance of the application.

**Respuesta de la fuente:** A

**Explicación:** Cloud Key Management Service (KMS) is designed specifically for managing encryption keys securely, ensuring they are never exposed to application code or logs.
Frequent key rotation minimizes the window of exposure and limits the impact of a potential breach by reducing the amount of data encrypted with any single compromised key.

## Pregunta 59

Contexto: [topics:104](#topics-104)
Your company is creating a new cloud-native Google Cloud organization. You expect this Google Cloud organization to first be used by a small number of departments and then expand to be used by a large number of departments. Each department has a large number of applications that range in size. You need to design the VPC network architecture. Your solution must minimize the amount of management required, while remaining flexible enough for development teams to quickly adapt to their evolving needs. What should you do?

**A.** Create a separate VPC for each department, and connect the VPCs with VPC Network Peering.

**B.** Create a separate VPC for each department. Use Private Service Connect to connect the VPCs.

**C.** Create a separate VPC for each application. Use Private Service Connect to connect the VPCs.

**D.** Create a separate VPC for each department, and connect the VPCs with Cloud VPN.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because creating one VPC per department balances security isolation with manageable complexity, avoiding the overhead of managing a VPC for every individual application. VPC Network Peering provides efficient, low-latency connectivity between these departmental VPCs, supporting organizational growth.

Options B and C are incorrect because Private Service Connect is designed for accessing specific backend services (like Cloud SQL or partner APIs), not for general inter-VPC networking. Option D is less optimal as Cloud VPN involves higher complexity and cost compared to native peering for internal connectivity.

## Pregunta 60

Contexto: [topics:104](#topics-104)
You have migrated an e-commerce application to Google Cloud Platform (GCP). You want to prepare the application for the upcoming busy season. What should you do first to prepare for the busy season?

**A.** Load teat the application to profile its performance for scaling.

**B.** Enable AutoScaling on the production clusters, in case there is growth.

**C.** Pre-provision double the compute power used last season, expecting growth.

**D.** Create a runbook on inflating the disaster recovery (DR) environment if there is growth.

**Respuesta de la fuente:** A

**Explicación:** The first step in preparing for peak traffic is to load test the application to profile its performance and identify scaling requirements. This allows you to refine the architecture and validate that auto-scaling mechanisms will function correctly before enabling them in production. Enabling auto-scaling or pre-provisioning resources without prior testing risks hitting quotas, architectural bottlenecks, or inefficiencies during the actual busy season.

## Pregunta 61

Contexto: [topics:104](#topics-104)
You support a web application that runs on App Engine and uses CloudSQL and Cloud Storage for data storage. After a short spike in website traffic, you notice a big increase in latency for all user requests, increase in CPU use, and the number of processes running the application. Initial troubleshooting reveals:
✑ After the initial spike in traffic, load levels returned to normal but users still experience high latency.
✑ Requests for content from the CloudSQL database and images from Cloud Storage show the same high latency.
✑ No changes were made to the website around the time the latency increased.
✑ There is no increase in the number of errors to the users.
You expect another spike in website traffic in the coming days and want to make sure users don't experience latency. What should you do?

**A.** Upgrade the GCS buckets to Multi-Regional.

**B.** Enable high availability on the CloudSQL instances.

**C.** Move the application from App Engine to Compute Engine.

**D.** Modify the App Engine configuration to have additional idle instances.

**Respuesta de la fuente:** D

**Explicación:** The symptoms indicate that App Engine instances were shut down or scaled down after the traffic spike subsided, causing cold start latency when subsequent requests arrived. Since App Engine automatically scales idle instances to zero by default to save costs, maintaining a pool of idle instances ensures they are immediately available to handle new load without initialization delays. This directly addresses the latency issue for both database and storage requests by keeping application servers warm.

## Pregunta 62

Contexto: [topics:104](#topics-104)
Your application runs on Google Cloud Platform (GCP). You need to implement Jenkins for deploying application releases to GCP. You want to streamline the release process, lower operational toil, and keep user data secure. What should you do?

**A.** Implement Jenkins on local workstations.

**B.** Implement Jenkins on Kubernetes on-premises.

**C.** Implement Jenkins on Google Cloud Functions.

**D.** Implement Jenkins on Compute Engine virtual machines.

**Respuesta de la fuente:** D

**Explicación:** Implementing Jenkins on Compute Engine (Option D) allows for scalable and secure CI/CD pipelines using the official Google Compute Engine plugin. This approach supports provisioning ephemeral build agents that are destroyed after use, reducing operational toil and minimizing the attack surface for user data compared to long-lived instances or local environments.

## Pregunta 63

Contexto: [topics:104](#topics-104)
You are working with a government agency that requires you to archive application logs for seven years. You need to configure Stackdriver to export and store the logs while minimizing costs of storage. What should you do?

**A.** Create a Cloud Storage bucket and develop your application to send logs directly to the bucket.

**B.** Develop an App Engine application that pulls the logs from Stackdriver and saves them in BigQuery.

**C.** Create an export in Stackdriver and configure Cloud Pub/Sub to store logs in permanent storage for seven years.

**D.** Create a sink in Stackdriver, name it, create a bucket on Cloud Storage for storing archived logs, and then select the bucket as the log export destination.

**Respuesta de la fuente:** D

**Explicación:** To export logs from Stackdriver Logging (now Cloud Logging) to a permanent storage location, you must create a Log Sink.
Google Cloud Storage is the recommended destination for long-term log archiving due to its cost-effectiveness and durability.
Option D correctly describes creating a sink and directing it to a Cloud Storage bucket, whereas Option A bypasses the logging service, Option B suggests an expensive analysis tool (BigQuery) rather than storage, and Option C incorrectly identifies Pub/Sub as a storage solution.

## Pregunta 64

Contexto: [topics:104](#topics-104)
You support a trading application written in Python and hosted on App Engine flexible environment. You want to customize the error information being sent to
Stackdriver Error Reporting. What should you do?

**A.** Install the Stackdriver Error Reporting library for Python, and then run your code on a Compute Engine VM.

**B.** Install the Stackdriver Error Reporting library for Python, and then run your code on Google Kubernetes Engine.

**C.** Install the Stackdriver Error Reporting library for Python, and then run your code on App Engine flexible environment.

**D.** Use the Stackdriver Error Reporting API to write errors from your application to ReportedErrorEvent, and then generate log entries with properly formatted error messages in Stackdriver Logging.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 65

Contexto: [topics:104](#topics-104)
You need to define Service Level Objectives (SLOs) for a high-traffic multi-region web application. Customers expect the application to always be available and have fast response times. Customers are currently happy with the application performance and availability. Based on current measurement, you observe that the
90
percentile of latency is 120ms and the 95
percentile of latency is 275ms over a 28-day window. What latency SLO would you recommend to the team to th th publish?

**A.** 90 percentile — 100ms th 95 percentile — 250ms th

**B.** 90 percentile — 120ms th 95 percentile — 275ms th

**C.** 90 percentile — 150ms th 95 percentile — 300ms th

**D.** 90 percentile — 250ms th 95 percentile — 400ms th

**Respuesta de la fuente:** C

**Explicación:** SLOs should represent aspirational targets that are slightly stricter than current performance to drive continuous improvement, rather than merely reflecting existing metrics. Setting the SLO equal to or looser than current latency (options A, B, D) fails to provide a buffer for future degradation or incentivize optimization. Therefore, choosing 150ms and 300ms establishes a reasonable goal that accounts for variance while maintaining customer satisfaction.

## Pregunta 66

Contexto: [topics:104](#topics-104)
You support a large service with a well-defined Service Level Objective (SLO). The development team deploys new releases of the service multiple times a week.
If a major incident causes the service to miss its SLO, you want the development team to shift its focus from working on features to improving service reliability.
What should you do before a major incident occurs?

**A.** Develop an appropriate error budget policy in cooperation with all service stakeholders.

**B.** Negotiate with the product team to always prioritize service reliability over releasing new features.

**C.** Negotiate with the development team to reduce the release frequency to no more than once a week.

**D.** Add a plugin to your Jenkins pipeline that prevents new releases whenever your service is out of SLO.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because an error budget policy provides a data-driven mechanism to balance feature development with reliability goals.
When the error budget is exhausted, the team automatically shifts focus from new features to improving reliability, ensuring SLOs are met without arbitrary delays.
This approach aligns stakeholders on acceptable risk levels rather than enforcing rigid release frequencies or blocking pipelines manually.

## Pregunta 67

Contexto: [topics:104](#topics-104)
Your company is developing applications that are deployed on Google Kubernetes Engine (GKE). Each team manages a different application. You need to create the development and production environments for each team, while minimizing costs. Different teams should not be able to access other teams' environments.
What should you do?

**A.** Create one GCP Project per team. In each project, create a cluster for Development and one for Production. Grant the teams IAM access to their respective clusters.

**B.** Create one GCP Project per team. In each project, create a cluster with a Kubernetes namespace for Development and one for Production. Grant the teams IAM access to their respective clusters.

**C.** Create a Development and a Production GKE cluster in separate projects. In each cluster, create a Kubernetes namespace per team, and then configure Identity Aware Proxy so that each team can only access its own namespace.

**D.** Create a Development and a Production GKE cluster in separate projects. In each cluster, create a Kubernetes namespace per team, and then configure Kubernetes Role-based access control (RBAC) so that each team can only access its own namespace.

**Respuesta de la fuente:** D

**Explicación:** Separating Development and Production environments into different GCP projects ensures strict isolation and distinct billing controls, which helps minimize costs by allowing independent scaling policies.
Using Kubernetes namespaces within each cluster allows multiple teams to share the same cluster resources efficiently while maintaining logical separation of applications.
Kubernetes Role-Based Access Control (RBAC) is the correct mechanism to restrict users' access to specific namespaces within a cluster, ensuring teams cannot interfere with or view other teams' resources.

## Pregunta 68

Contexto: [topics:104](#topics-104)
Some of your production services are running in Google Kubernetes Engine (GKE) in the eu-west-1 region. Your build system runs in the us-west-1 region. You want to push the container images from your build system to a scalable registry to maximize the bandwidth for transferring the images to the cluster. What should you do?

**A.** Push the images to Google Container Registry (GCR) using the gcr.io hostname.

**B.** Push the images to Google Container Registry (GCR) using the us.gcr.io hostname.

**C.** Push the images to Google Container Registry (GCR) using the eu.gcr.io hostname.

**D.** Push the images to a private image registry running on a Compute Engine instance in the eu-west-1 region.

**Respuesta de la fuente:** C

**Explicación:** To maximize bandwidth and minimize latency when pulling images into the GKE cluster in eu-west-1, you should store the container images in a registry hosted within the same geographical region. The `eu.gcr.io` hostname directs storage to European Union data centers, ensuring low-latency access for the production clusters located in Europe, whereas US-based hostnames would incur higher cross-regional transfer costs and latency.

## Pregunta 69

Contexto: [topics:104](#topics-104)
You manage several production systems that run on Compute Engine in the same Google Cloud Platform (GCP) project. Each system has its own set of dedicated Compute Engine instances. You want to know how must it costs to run each of the systems. What should you do?

**A.** In the Google Cloud Platform Console, use the Cost Breakdown section to visualize the costs per system.

**B.** Assign all instances a label specific to the system they run. Configure BigQuery billing export and query costs per label.

**C.** Enrich all instances with metadata specific to the system they run. Configure Stackdriver Logging to export to BigQuery, and query costs based on the metadata.

**D.** Name each virtual machine (VM) after the system it runs. Set up a usage report export to a Cloud Storage bucket. Configure the bucket as a source in BigQuery to query costs based on VM name.

**Respuesta de la fuente:** B

**Explicación:** Labels are the recommended GCP best practice for organizing resources and filtering costs in billing reports.
By applying specific labels to each system's instances, you can export billing data to BigQuery and run SQL queries to accurately calculate and compare costs per label.

## Pregunta 70

Contexto: [topics:104](#topics-104)
You use Cloud Build to build and deploy your application. You want to securely incorporate database credentials and other application secrets into the build pipeline. You also want to minimize the development effort. What should you do?

**A.** Create a Cloud Storage bucket and use the built-in encryption at rest. Store the secrets in the bucket and grant Cloud Build access to the bucket.

**B.** Encrypt the secrets and store them in the application repository. Store a decryption key in a separate repository and grant Cloud Build access to the repository.

**C.** Use client-side encryption to encrypt the secrets and store them in a Cloud Storage bucket. Store a decryption key in the bucket and grant Cloud Build access to the bucket.

**D.** Use Cloud Key Management Service (Cloud KMS) to encrypt the secrets and include them in your Cloud Build deployment configuration. Grant Cloud Build access to the KeyRing.

**Respuesta de la fuente:** D

**Explicación:** Cloud Build has native integration with Cloud KMS to securely manage and access encrypted secrets within the build pipeline, eliminating the need for custom decryption logic. This approach minimizes development effort by allowing direct reference of encrypted credentials in the build configuration file (cloudbuild.yaml) without manual key management or storage bucket interactions.

## Pregunta 71

Contexto: [topics:104](#topics-104)
You support a popular mobile game application deployed on Google Kubernetes Engine (GKE) across several Google Cloud regions. Each region has multiple
Kubernetes clusters. You receive a report that none of the users in a specific region can connect to the application. You want to resolve the incident while following Site Reliability Engineering practices. What should you do first?

**A.** Reroute the user traffic from the affected region to other regions that don't report issues.

**B.** Use Stackdriver Monitoring to check for a spike in CPU or memory usage for the affected region.

**C.** Add an extra node pool that consists of high memory and high CPU machine type instances to the cluster.

**D.** Use Stackdriver Logging to filter on the clusters in the affected region, and inspect error messages in the logs.

**Respuesta de la fuente:** A

**Explicación:** In Site Reliability Engineering (SRE), the primary objective during an incident is to restore service availability and minimize user impact immediately. Rerouting traffic from the affected region to healthy regions achieves this restoration faster than investigating logs or adding resources, which are slower diagnostic or remediation steps.

## Pregunta 72

Contexto: [topics:104](#topics-104)
You are writing a postmortem for an incident that severely affected users. You want to prevent similar incidents in the future. Which two of the following sections should you include in the postmortem? (Choose two.)

**A.** An explanation of the root cause of the incident.

**B.** A list of employees responsible for causing the incident

**C.** A list of action items to prevent a recurrence of the incident

**D.** Your opinion of the incident's severity compared to past incidents

**E.** Copies of the design documents for all the services impacted by the incident

**Respuesta de la fuente:** A, C

**Explicación:** Effective postmortems are blameless analyses focused on learning and improvement rather than assigning fault.
Identifying the root cause (A) is essential to understand why the failure occurred, while listing actionable items (C) ensures concrete steps are taken to prevent recurrence.
Listing responsible employees (B) violates the principle of a blameless culture, and opinions (D) or raw design documents (E) do not directly contribute to preventing future incidents.

## Pregunta 73

Contexto: [topics:104](#topics-104)
You are ready to deploy a new feature of a web-based application to production. You want to use Google Kubernetes Engine (GKE) to perform a phased rollout to half of the web server pods.
What should you do?

**A.** Use a partitioned rolling update.

**B.** Use Node taints with NoExecute.

**C.** Use a replica set in the deployment specification.

**D.** Use a stateful set with parallel pod management policy.

**Respuesta de la fuente:** A

**Explicación:** A partitioned rolling update allows you to suspend updates for pods with an ordinal greater than the specified partition number.
This mechanism is specifically designed in Kubernetes (particularly within StatefulSets) to enable phased rollouts by updating only a subset of pods first.

## Pregunta 74

Contexto: [topics:104](#topics-104)
You are responsible for the reliability of a high-volume enterprise application. A large number of users report that an important subset of the application's functionality `" a data intensive reporting feature `" is consistently failing with an HTTP 500 error. When you investigate your application's dashboards, you notice a strong correlation between the failures and a metric that represents the size of an internal queue used for generating reports. You trace the failures to a reporting backend that is experiencing high I/O wait times. You quickly fix the issue by resizing the backend's persistent disk (PD). How you need to create an availability
Service Level Indicator (SLI) for the report generation feature. How would you define it?

**A.** As the I/O wait times aggregated across all report generation backends

**B.** As the proportion of report generation requests that result in a successful response

**C.** As the application's report generation queue size compared to a known-good threshold

**D.** As the reporting backend PD throughout capacity compared to a known-good threshold

**Respuesta de la fuente:** B

**Explicación:** An availability Service Level Indicator (SLI) specifically measures the proportion of successful requests relative to the total number of requests for a given feature. Options A, C, and D describe system metrics (I/O wait, queue size, disk capacity) which are useful for operational visibility but do not directly quantify user-facing availability.
Reference: Google SRE Workbook defines availability SLI as 'the proportion of requests that resulted in a successful response.'

## Pregunta 75

Contexto: [topics:104](#topics-104)
You have an application running in Google Kubernetes Engine. The application invokes multiple services per request but responds too slowly. You need to identify which downstream service or services are causing the delay. What should you do?

**A.** Analyze VPC flow logs along the path of the request.

**B.** Investigate the Liveness and Readiness probes for each service.

**C.** Create a Dataflow pipeline to analyze service metrics in real time.

**D.** Use a distributed tracing framework such as OpenTelemetry or Stackdriver Trace.

**Respuesta de la fuente:** D

**Explicación:** Distributed tracing frameworks like OpenTelemetry or Stackdriver Trace are specifically designed to track requests across multiple microservices, visualizing the end-to-end path and identifying latency bottlenecks in downstream dependencies.

VPC flow logs (A) show network traffic but not application-level delays, probes (B) check health status rather than performance timing, and Dataflow (C) is for large-scale data processing, not real-time distributed request tracing.

## Pregunta 76

Contexto: [topics:104](#topics-104)
You are creating and assigning action items in a postmodern for an outage. The outage is over, but you need to address the root causes. You want to ensure that your team handles the action items quickly and efficiently. How should you assign owners and collaborators to action items?

**A.** Assign one owner for each action item and any necessary collaborators.

**B.** Assign multiple owners for each item to guarantee that the team addresses items quickly.

**C.** Assign collaborators but no individual owners to the items to keep the postmortem blameless.

**D.** Assign the team lead as the owner for all action items because they are in charge of the SRE team.

**Respuesta de la fuente:** A

**Explicación:** According to SRE best practices, assigning a single owner ensures clear accountability and prevents tasks from being overlooked due to diffusion of responsibility.
Collaborators should be added as needed to support the owner, but multiple owners or no owners reduce efficiency and increase the risk of unresolved items.

## Pregunta 77

Contexto: [topics:104](#topics-104)
Your development team has created a new version of their service's API. You need to deploy the new versions of the API with the least disruption to third-party developers and end users of third-party installed applications. What should you do?

**A.** Introduce the new version of the API. Announce deprecation of the old version of the API. Deprecate the old version of the API. Contact remaining users of the old API. Provide best effort support to users of the old API. Turn down the old version of the API.

**B.** Announce deprecation of the old version of the API. Introduce the new version of the API. Contact remaining users on the old API. Deprecate the old version of the API. Turn down the old version of the API. Provide best effort support to users of the old API.

**C.** Announce deprecation of the old version of the API. Contact remaining users on the old API. Introduce the new version of the API. Deprecate the old version of the API. Provide best effort support to users of the old API. Turn down the old version of the API.

**D.** Introduce the new version of the API. Contact remaining users of the old API. Announce deprecation of the old version of the API. Deprecate the old version of the API. Turn down the old version of the API. Provide best effort support to users of the old API.

**Respuesta de la fuente:** A

**Explicación:** The correct sequence for API versioning is to introduce the new version first so consumers have an immediate migration path.
Announcing deprecation before deployment would disrupt users who cannot yet migrate, while delaying contact with remaining users until after deprecation misses the window for proactive support.
Option A correctly follows the industry standard lifecycle: deploy new version, announce deprecation, actively engage and support stragglers, and finally sunset the old API.

## Pregunta 78

Contexto: [topics:104](#topics-104)
You are running an application on Compute Engine and collecting logs through Stackdriver. You discover that some personally identifiable information (PII) is leaking into certain log entry fields. You want to prevent these fields from being written in new log entries as quickly as possible. What should you do?

**A.** Use the filter-record-transformer Fluentd filter plugin to remove the fields from the log entries in flight.

**B.** Use the fluent-plugin-record-reformer Fluentd output plugin to remove the fields from the log entries in flight.

**C.** Wait for the application developers to patch the application, and then verify that the log entries are no longer exposing PII.

**D.** Stage log entries to Cloud Storage, and then trigger a Cloud Function to remove the fields and write the entries to Stackdriver via the Stackdriver Logging API.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 79

Contexto: [topics:104](#topics-104)
You support a service that recently had an outage. The outage was caused by a new release that exhausted the service memory resources. You rolled back the release successfully to mitigate the impact on users. You are now in charge of the post-mortem for the outage. You want to follow Site Reliability Engineering practices when developing the post-mortem. What should you do?

**A.** Focus on developing new features rather than avoiding the outages from recurring.

**B.** Focus on identifying the contributing causes of the incident rather than the individual responsible for the cause.

**C.** Plan individual meetings with all the engineers involved. Determine who approved and pushed the new release to production.

**D.** Use the Git history to find the related code commit. Prevent the engineer who made that commit from working on production services.

**Respuesta de la fuente:** B

**Explicación:** Site Reliability Engineering (SRE) post-mortems emphasize a blameless culture to encourage transparency and effective problem solving. Focusing on identifying contributing causes and systemic failures, rather than assigning individual blame, prevents defensive behavior and helps uncover the root cause to prevent recurrence.

## Pregunta 80

Contexto: [topics:104](#topics-104)
You support a user-facing web application. When analyzing the application's error budget over the previous six months, you notice that the application has never consumed more than 5% of its error budget in any given time window. You hold a Service Level Objective (SLO) review with business stakeholders and confirm that the SLO is set appropriately. You want your application's SLO to more closely reflect its observed reliability. What steps can you take to further that goal while balancing velocity, reliability, and business needs? (Choose two.)

**A.** Add more serving capacity to all of your application's zones.

**B.** Have more frequent or potentially risky application releases.

**C.** Tighten the SLO match the application's observed reliability.

**D.** Implement and measure additional Service Level Indicators (SLIs) fro the application.

**E.** Announce planned downtime to consume more error budget, and ensure that users are not depending on a tighter SLO.

**Respuesta de la fuente:** D, E

**Explicación:** No conservada en esta captura.

## Pregunta 81

Contexto: [topics:104](#topics-104)
You support a service with a well-defined Service Level Objective (SLO). Over the previous 6 months, your service has consistently met its SLO and customer satisfaction has been consistently high. Most of your service's operations tasks are automated and few repetitive tasks occur frequently. You want to optimize the balance between reliability and deployment velocity while following site reliability engineering best practices. What should you do? (Choose two.)

**A.** Make the service's SLO more strict.

**B.** Increase the service's deployment velocity and/or risk.

**C.** Shift engineering time to other services that need more reliability.

**D.** Get the product team to prioritize reliability work over new features.

**E.** Change the implementation of your Service Level Indicators (SLIs) to increase coverage.

**Respuesta de la fuente:** B, C

**Explicación:** According to the Site Reliability Engineering (SRE) SLO decision matrix, when a service consistently meets its SLO and operates with low error budget consumption, the appropriate action is to increase deployment velocity or risk to improve engineering efficiency.

Additionally, since the service is already highly reliable and automated, shifting engineering resources to other services that require more reliability work optimizes overall organizational resource allocation.

## Pregunta 82

Contexto: [topics:104](#topics-104)
Your company follows Site Reliability Engineering principles. You are writing a postmortem for an incident, triggered by a software change that severely affected users. You want to prevent severe incident from happening in the future. What should you do?

**A.** Identify engineers responsible for the incident and escalate to the senior management.

**B.** Ensure that test cases that catch errors of this type are run successfully before new software releases.

**C.** Follow up with the employees who reviewed the changes and prescribe practices they should follow in the future.

**D.** Design a policy that will require on-call teams to immediately call engineers and management to discuss a plan of action if an incident occurs.

**Respuesta de la fuente:** B

**Explicación:** Site Reliability Engineering (SRE) emphasizes a blameless postmortem culture focused on systemic fixes rather than individual accountability. Adding automated test cases ensures that the specific defect pattern is caught before release, preventing recurrence through engineering controls rather than relying on human vigilance.

## Pregunta 83

Contexto: [topics:104](#topics-104)
Your organization uses a change advisory board (CAB) to approve all changes to an existing service. You want to revise this process to eliminate any negative impact on the software delivery performance. What should you do? (Choose two.)

**A.** Replace the CAB with a senior manager to ensure continuous oversight from development to deployment.

**B.** Let developers merge their own changes, but ensure that the team's deployment platform can roll back changes if any issues are discovered.

**C.** Move to a peer-review based process for individual changes that is enforced at code check-in time and supported by automated tests.

**D.** Batch changes into larger but less frequent software releases.

**E.** Ensure that the team's development platform enables developers to get fast feedback on the impact of their changes.

**Respuesta de la fuente:** C, E

**Explicación:** Replacing a Change Advisory Board (CAB) with peer reviews and automated testing (Option C) eliminates the bottleneck of manual approval while maintaining quality through immediate, code-level validation.
Enabling fast feedback on change impact (Option E) further supports high-velocity delivery by allowing developers to detect issues early in the pipeline rather than waiting for formal board meetings.
Options A, B, and D either introduce new bottlenecks, lack sufficient quality gates, or reduce deployment frequency, which contradicts the goal of improving software delivery performance.

## Pregunta 84

Contexto: [topics:104](#topics-104)
Your organization has a containerized web application that runs on-premises. As part of the migration plan to Google Cloud, you need to select a deployment strategy and platform that meets the following acceptance criteria:

1. The platform must be able to direct traffic from Android devices to an Android-specific microservice.
2. The platform must allow for arbitrary percentage-based traffic splitting
3. The deployment strategy must allow for continuous testing of multiple versions of any microservice.

What should you do?

**A.** Deploy the canary release of the application to Cloud Run. Use traffic splitting to direct 10% of user traffic to the canary release based on the revision tag.

**B.** Deploy the canary release of the application to App Engine. Use traffic splitting to direct a subset of user traffic to the new version based on the IP address.

**C.** Deploy the canary release of the application to Compute Engine. Use Anthos Service Mesh with Compute Engine to direct 10% of user traffic to the canary release by configuring the virtual service.

**D.** Deploy the canary release to Google Kubernetes Engine with Anthos Service Mesh. Use traffic splitting to direct 10% of user traffic to the new version based on the user-agent header configured in the virtual service.

**Respuesta de la fuente:** D

**Explicación:** Option D is the only choice that satisfies all three acceptance criteria using GKE and Anthos Service Mesh (Istio). Specifically, Istio Virtual Services allow routing based on the user-agent header to target Android devices, support arbitrary percentage-based traffic splitting for canary releases, and enable continuous testing of multiple service versions. Other options lack the capability to route based on headers (A, B) or do not provide the required flexible service mesh features out-of-the-box (C).

## Pregunta 85

Contexto: [topics:104](#topics-104)
Your team is running microservices in Google Kubernetes Engine (GKE). You want to detect consumption of an error budget to protect customers and define release policies. What should you do?

**A.** Create SLIs from metrics. Enable Alert Policies if the services do not pass.

**B.** Use the metrics from Anthos Service Mesh to measure the health of the microservices.

**C.** Create a SLO. Create an Alert Policy on select_slo_burn_rate.

**D.** Create a SLO and configure uptime checks for your services. Enable Alert Policies if the services do not pass.

**Respuesta de la fuente:** C

**Explicación:** To detect error budget consumption, you must define a Service Level Objective (SLO) which establishes the reliability target and the associated error budget.
Alerting on the `select_slo_burn_rate` metric is the standard practice for monitoring how quickly that budget is being consumed, allowing you to trigger release policies before the budget is exhausted.

## Pregunta 86

Contexto: [topics:104](#topics-104)
Your organization wants to collect system logs that will be used to generate dashboards in Cloud Operations for their Google Cloud project. You need to configure all current and future Compute Engine instances to collect the system logs, and you must ensure that the Ops Agent remains up to date. What should you do?

**A.** Use the gcloud CLI to install the Ops Agent on each VM listed in the Cloud Asset Inventory,

**B.** Select all VMs with an Agent status of Not detected on the Cloud Operations VMs dashboard. Then select Install agents.

**C.** Use the gcloud CLI to create an Agent Policy.

**D.** Install the Ops Agent on the Compute Engine image by using a startup script

**Respuesta de la fuente:** C

**Explicación:** To ensure coverage for both current and future Compute Engine instances, you must use an Agent Policy rather than manual installation methods. Agent Policies automatically apply the Ops Agent to VMs based on defined conditions (such as resource type) and can be configured to manage automatic updates, satisfying the requirement to keep the agent up to date.

## Pregunta 87

Contexto: [topics:104](#topics-104)
Your company has a Google Cloud resource hierarchy with folders for production, test, and development. Your cyber security team needs to review your company's Google Cloud security posture to accelerate security issue identification and resolution. You need to centralize the logs generated by Google Cloud services from all projects only inside your production folder to allow for alerting and near-real time analysis. What should you do?

**A.** Enable the Workflows API and route all the logs to Cloud Logging.

**B.** Create a central Cloud Monitoring workspace and attach all related projects.

**C.** Create an aggregated log sink associated with the production folder that uses a Pub/Sub topic as the destination.

**D.** Create an aggregated log sink associated with the production folder that uses a Cloud Logging bucket as the destination.

**Respuesta de la fuente:** C

**Explicación:** To centralize logs from a folder for alerting and near-real-time analysis, you must create an aggregated log sink at the folder level.
Using Cloud Logging Buckets (Option D) provides long-term storage but is not optimized for immediate external alerting pipelines like Pub/Sub.
Routing to a Pub/Sub topic (Option C) allows real-time streaming of logs to security systems such as SIEMs or custom analysis tools, satisfying the requirement for near-real-time processing.

## Pregunta 88

Contexto: [topics:104](#topics-104)
You are configuring the frontend tier of an application deployed in Google Cloud. The frontend tier is hosted in nginx and deployed using a managed instance group with an Envoy-based external HTTP(S) load balancer in front. The application is deployed entirely within the europe-west2 region, and only serves users based in the United Kingdom. You need to choose the most cost-effective network tier and load balancing configuration. What should you use?

**A.** Premium Tier with a global load balancer

**B.** Premium Tier with a regional load balancer

**C.** Standard Tier with a global load balancer

**D.** Standard Tier with a regional load balancer

**Respuesta de la fuente:** D

**Explicación:** The Standard network tier provides significantly lower bandwidth costs compared to the Premium tier, making it more cost-effective for traffic restricted to a single region. Since the application and users are confined to europe-west2 (United Kingdom), a regional external HTTP(S) load balancer is sufficient to handle traffic without incurring the higher fees associated with global anycast routing.

## Pregunta 89

Contexto: [topics:104](#topics-104)
You recently deployed your application in Google Kubernetes Engine (GKE) and now need to release a new version of the application. You need the ability to instantly roll back to the previous version of the application in case there are issues with the new version. Which deployment model should you use?

**A.** Perform a rolling deployment, and test your new application after the deployment is complete.

**B.** Perform A/B testing, and test your application periodically after the deployment is complete.

**C.** Perform a canary deployment, and test your new application periodically after the new version is deployed.

**D.** Perform a blue/green deployment, and test your new application after the deployment is complete.

**Respuesta de la fuente:** D

**Explicación:** Blue/green deployment maintains two identical environments (blue and green), allowing you to switch traffic instantly between the old and new versions. This strategy enables immediate rollback by simply redirecting traffic back to the previous environment, satisfying the requirement for instant recovery. In contrast, rolling or canary deployments update instances incrementally, making full rollbacks more complex and time-consuming.

## Pregunta 90

Contexto: [topics:104](#topics-104)
You are building and deploying a microservice on Cloud Run for your organization. Your service is used by many applications internally. You are deploying a new release, and you need to test the new version extensively in the staging and production environments. You must minimize user and developer impact. What should you do?

**A.** Deploy the new version of the service to the staging environment. Split the traffic, and allow 1% of traffic through to the latest version. Test the latest version. If the test passes, gradually roll out the latest version to the staging and production environments.

**B.** Deploy the new version of the service to the staging environment. Split the traffic, and allow 50% of traffic through to the latest version. Test the latest version. If the test passes, send all traffic to the latest version. Repeat for the production environment.

**C.** Deploy the new version of the service to the staging environment with a new-release tag without serving traffic. Test the new-release version. If the test passes, gradually roll out this tagged version. Repeat for the production environment.

**D.** Deploy a new environment with the green tag to use as the staging environment. Deploy the new version of the service to the green environment and test the new version. If the tests pass, send all traffic to the green environment and delete the existing staging environment. Repeat for the production environment.

**Respuesta de la fuente:** C

**Explicación:** To minimize impact while allowing for extensive testing, you should deploy the new revision with a specific tag (like 'new-release') that does not receive live traffic.
This ensures no users are affected during the initial testing phase in staging or production.
Once tests pass, you can gradually shift traffic from the stable version to the tagged revision using Cloud Run's traffic migration features.

## Pregunta 91

Contexto: [topics:104](#topics-104)
You work for a global organization and run a service with an availability target of 99% with limited engineering resources.
For the current calendar month, you noticed that the service has 99.5% availability. You must ensure that your service meets the defined availability goals and can react to business changes, including the upcoming launch of new features.
You also need to reduce technical debt while minimizing operational costs. You want to follow Google-recommended practices. What should you do?

**A.** Add N+1 redundancy to your service by adding additional compute resources to the service.

**B.** Identify, measure, and eliminate toil by automating repetitive tasks.

**C.** Define an error budget for your service level availability and minimize the remaining error budget.

**D.** Allocate available engineers to the feature backlog while you ensure that the service remains within the availability target.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because it directly addresses the requirements to reduce technical debt and minimize operational costs while working with limited engineering resources. According to Google SRE principles, eliminating toil through automation frees up engineers to focus on high-value tasks like feature development and paying down debt without increasing headcount or infrastructure spend.

## Pregunta 92

Contexto: [topics:104](#topics-104)
You are developing the deployment and testing strategies for your CI/CD pipeline in Google Cloud. You must be able to:
•	Reduce the complexity of release deployments and minimize the duration of deployment rollbacks.
•	Test real production traffic with a gradual increase in the number of affected users.

You want to select a deployment and testing strategy that meets your requirements. What should you do?

**A.** Recreate deployment and canary testing

**B.** Blue/green deployment and canary testing

**C.** Rolling update deployment and A/B testing

**D.** Rolling update deployment and shadow testing

**Respuesta de la fuente:** B

**Explicación:** Blue/green deployment satisfies the requirement to reduce complexity and minimize rollback duration by allowing instant traffic switching between two identical environments.
Canary testing meets the need to test with real production traffic while gradually increasing the number of affected users, limiting risk exposure.

## Pregunta 93

Contexto: [topics:104](#topics-104)
You are creating a CI/CD pipeline to perform Terraform deployments of Google Cloud resources. Your CI/CD tooling is running in Google Kubernetes Engine (GKE) and uses an ephemeral Pod for each pipeline run. You must ensure that the pipelines that run in the Pods have the appropriate Identity and Access Management (IAM) permissions to perform the Terraform deployments. You want to follow Google-recommended practices for identity management. What should you do? (Choose two.)

**A.** Create a new Kubernetes service account, and assign the service account to the Pods. Use Workload Identity to authenticate as the Google service account.

**B.** Create a new JSON service account key for the Google service account, store the key as a Kubernetes secret, inject the key into the Pods, and set the GOOGLE_APPLICATION_CREDENTIALS environment variable.

**C.** Create a new Google service account, and assign the appropriate IAM permissions.

**D.** Create a new JSON service account key for the Google service account, store the key in the secret management store for the CI/CD tool, and configure Terraform to use this key for authentication.

**E.** Assign the appropriate IAM permissions to the Google service account associated with the Compute Engine VM instances that run the Pods.

**Respuesta de la fuente:** A, C

**Explicación:** Workload Identity is the Google-recommended practice for authenticating GKE pods to Cloud resources because it eliminates the need to manage long-lived service account keys. Option A correctly describes binding a Kubernetes service account to a Google service account via Workload Identity, while Option C ensures the necessary IAM permissions are granted to that Google service account to perform Terraform deployments.

## Pregunta 94

Contexto: [topics:104](#topics-104)
You are the on-call Site Reliability Engineer for a microservice that is deployed to a Google Kubernetes Engine (GKE) Autopilot cluster. Your company runs an online store that publishes order messages to Pub/Sub, and a microservice receives these messages and updates stock information in the warehousing system. A sales event caused an increase in orders, and the stock information is not being updated quickly enough. This is causing a large number of orders to be accepted for products that are out of stock. You check the metrics for the microservice and compare them to typical levels:

[Imagen: sin descripción]

You need to ensure that the warehouse system accurately reflects product inventory at the time orders are placed and minimize the impact on customers. What should you do?
Imagen · question_text · sin descripción
![Imagen original](imagenes/7ba16ffa395dfefdcee7.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Microservice metrics Typical state Current state
Average CPU across all Pods 20% of Pod limit 30% of Pod limit
Average memory across all Pods 10% of Pod limit _| 10% of Pod limit
Pub/Sub subscription: Average oldest
unacknowledged message age
347 milliseconds
8074 milliseconds
Pub/Sub subscription: Average undelivered 5 messages 14705 messages
messages
Pub/Sub subscription: Average acknowledgment | 312 milliseconds | 354 milliseconds
latency
```

**A.** Decrease the acknowledgment deadline on the subscription.

**B.** Add a virtual queue to the online store that allows typical traffic levels.

**C.** Increase the number of Pod replicas.

**D.** Increase the Pod CPU and memory limits.

**Respuesta de la fuente:** C

**Explicación:** The metrics indicate a backlog of unacknowledged messages while CPU and memory utilization remain low, suggesting the service is I/O bound or constrained by concurrency rather than compute resources.
Increasing the number of Pod replicas (horizontal scaling) allows more messages to be processed in parallel, reducing the acknowledgment latency and ensuring stock updates occur in real-time.
In GKE Autopilot, scaling out is the primary mechanism for handling increased request volume when resource limits per pod are not being reached.

## Pregunta 95

Contexto: [topics:104](#topics-104)
Your team deploys applications to three Google Kubernetes Engine (GKE) environments: development, staging, and production. You use GitHub repositories as your source of truth. You need to ensure that the three environments are consistent. You want to follow Google-recommended practices to enforce and install network policies and a logging DaemonSet on all the GKE clusters in those environments. What should you do?

**A.** Use Google Cloud Deploy to deploy the network policies and the DaemonSet. Use Cloud Monitoring to trigger an alert if the network policies and DaemonSet drift from your source in the repository.

**B.** Use Google Cloud Deploy to deploy the DaemonSet and use Policy Controller to configure the network policies. Use Cloud Monitoring to detect drifts from the source in the repository and Cloud Functions to correct the drifts.

**C.** Use Cloud Build to render and deploy the network policies and the DaemonSet. Set up Config Sync to sync the configurations for the three environments.

**D.** Use Cloud Build to render and deploy the network policies and the DaemonSet. Set up a Policy Controller to enforce the configurations for the three environments.

**Respuesta de la fuente:** C

**Explicación:** Config Sync is Google's recommended GitOps solution for managing multi-cluster Kubernetes configurations from a single source of truth (GitHub). It continuously reconciles the cluster state with the desired state defined in the repository, automatically detecting and correcting drift to ensure consistency across development, staging, and production environments. While Cloud Build renders the manifests, Config Sync provides the persistent synchronization and enforcement mechanism required.

## Pregunta 96

Contexto: [topics:104](#topics-104)
You are using Terraform to manage infrastructure as code within a CI/CD pipeline. You notice that multiple copies of the entire infrastructure stack exist in your Google Cloud project, and a new copy is created each time a change to the existing infrastructure is made. You need to optimize your cloud spend by ensuring that only a single instance of your infrastructure stack exists at a time. You want to follow Google-recommended practices. What should you do?

**A.** Create a new pipeline to delete old infrastructure stacks when they are no longer needed.

**B.** Confirm that the pipeline is storing and retrieving the terraform.tfstate file from Cloud Storage with the Terraform gcs backend.

**C.** Verify that the pipeline is storing and retrieving the terraform.tfstate file from a source control.

**D.** Update the pipeline to remove any existing infrastructure before you apply the latest configuration.

**Respuesta de la fuente:** B

**Explicación:** Without a remote backend, Terraform stores state locally in each CI/CD execution, causing it to lose track of existing resources and create duplicate infrastructure. Configuring the Google Cloud Storage (GCS) backend ensures a shared, centralized state file that tracks current resources accurately, preventing unintended creations.

## Pregunta 97

Contexto: [topics:104](#topics-104)
You are creating Cloud Logging sinks to export log entries from Cloud Logging to BigQuery for future analysis. Your organization has a Google Cloud folder named Dev that contains development projects and a folder named Prod that contains production projects. Log entries for development projects must be exported to dev_dataset, and log entries for production projects must be exported to prod_dataset. You need to minimize the number of log sinks created, and you want to ensure that the log sinks apply to future projects. What should you do?

**A.** Create a single aggregated log sink at the organization level.

**B.** Create a log sink in each project.

**C.** Create two aggregated log sinks at the organization level, and filter by project ID.

**D.** Create an aggregated log sink in the Dev and Prod folders.

**Respuesta de la fuente:** D

**Explicación:** Aggregated log sinks at the folder level apply to all current and future projects within that resource hierarchy, satisfying the requirement for automatic inclusion of new projects. Creating separate sinks for the Dev and Prod folders allows routing logs to their respective BigQuery datasets (dev_dataset and prod_dataset) without requiring manual configuration for each individual project. Option C is incorrect because filtering by specific Project IDs does not automatically apply to future projects with unknown IDs, and Option A requires complex filtering or multiple destinations within a single sink.

## Pregunta 98

Contexto: [topics:104](#topics-104)
Your company runs services by using multiple globally distributed Google Kubernetes Engine (GKE) clusters. Your operations team has set up workload monitoring that uses Prometheus-based tooling for metrics, alerts, and generating dashboards. This setup does not provide a method to view metrics globally across all clusters. You need to implement a scalable solution to support global Prometheus querying and minimize management overhead. What should you do?

**A.** Configure Prometheus cross-service federation for centralized data access.

**B.** Configure workload metrics within Cloud Operations for GKE.

**C.** Configure Prometheus hierarchical federation for centralized data access.

**D.** Configure Google Cloud Managed Service for Prometheus.

**Respuesta de la fuente:** D

**Explicación:** Google Cloud Managed Service for Prometheus is a fully managed solution designed specifically to aggregate metrics from multiple GKE clusters globally without requiring complex federation configurations. It minimizes management overhead by handling infrastructure and scaling automatically, while providing centralized querying capabilities via PromQL.

## Pregunta 99

Contexto: [topics:104](#topics-104)
You need to build a CI/CD pipeline for a containerized application in Google Cloud. Your development team uses a central Git repository for trunk-based development. You want to run all your tests in the pipeline for any new versions of the application to improve the quality. What should you do?

**A.** 1. Install a Git hook to require developers to run unit tests before pushing the code to a central repository.
2. Trigger Cloud Build to build the application container. Deploy the application container to a testing environment, and run integration tests.
3. If the integration tests are successful, deploy the application container to your production environment, and run acceptance tests.

**B.** 1. Install a Git hook to require developers to run unit tests before pushing the code to a central repository. If all tests are successful, build a container.
2. Trigger Cloud Build to deploy the application container to a testing environment, and run integration tests and acceptance tests.
3. If all tests are successful, tag the code as production ready. Trigger Cloud Build to build and deploy the application container to the production environment.

**C.** 1. Trigger Cloud Build to build the application container, and run unit tests with the container.
2. If unit tests are successful, deploy the application container to a testing environment, and run integration tests.
3. If the integration tests are successful, the pipeline deploys the application container to the production environment. After that, run acceptance tests.

**D.** 1. Trigger Cloud Build to run unit tests when the code is pushed. If all unit tests are successful, build and push the application container to a central registry.
2. Trigger Cloud Build to deploy the container to a testing environment, and run integration tests and acceptance tests.
3. If all tests are successful, the pipeline deploys the application to the production environment and runs smoke tests

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it fully automates the entire testing and deployment process within Google Cloud Build, satisfying the requirement to run all tests in the pipeline.
It eliminates manual steps or developer-enforced hooks (as seen in A and B) by integrating unit, integration, acceptance, and smoke tests directly into the CI/CD workflow triggered by code pushes.
This ensures consistent quality checks across all environments without relying on external client-side configurations.

## Pregunta 100

Contexto: [topics:104](#topics-104)
The new version of your containerized application has been tested and is ready to be deployed to production on Google Kubernetes Engine (GKE). You could not fully load-test the new version in your pre-production environment, and you need to ensure that the application does not have performance problems after deployment. Your deployment must be automated. What should you do?

**A.** Deploy the application through a continuous delivery pipeline by using canary deployments. Use Cloud Monitoring to look for performance issues, and ramp up traffic as supported by the metrics.

**B.** Deploy the application through a continuous delivery pipeline by using blue/green deployments. Migrate traffic to the new version of the application and use Cloud Monitoring to look for performance issues.

**C.** Deploy the application by using kubectl and use Config Connector to slowly ramp up traffic between versions. Use Cloud Monitoring to look for performance issues.

**D.** Deploy the application by using kubectl and set the spec.updateStrategy.type field to RollingUpdate. Use Cloud Monitoring to look for performance issues, and run the kubectl rollback command if there are any issues.

**Respuesta de la fuente:** A

**Explicación:** Canary deployments (Option A) are the optimal choice because they allow for a gradual, automated rollout of traffic to the new version.
This approach enables real-time performance monitoring via Cloud Monitoring on a small subset of users before full exposure, mitigating risk when pre-production load testing is incomplete.
In contrast, Blue/Green (Option B) requires running two full environments and typically switches all traffic at once rather than ramping up based on metrics, while kubectl methods (Options C and D) lack the advanced automated canary analysis capabilities required.

## Pregunta 101

Contexto: [topics:104](#topics-104)
You are managing an application that runs in Compute Engine. The application uses a custom HTTP server to expose an API that is accessed by other applications through an internal TCP/UDP load balancer. A firewall rule allows access to the API port from 0.0.0.0/0. You need to configure Cloud Logging to log each IP address that accesses the API by using the fewest number of steps. What should you do first?

**A.** Enable Packet Mirroring on the VPC.

**B.** Install the Ops Agent on the Compute Engine instances.

**C.** Enable logging on the firewall rule.

**D.** Enable VPC Flow Logs on the subnet.

**Respuesta de la fuente:** C

**Explicación:** Enabling logging on the firewall rule is the most direct method because it captures metadata for every packet matched by the rule, including the source IP address.
Unlike VPC Flow Logs, which sample traffic and may miss connections, firewall logs provide complete visibility into allowed traffic without requiring agent installation or application changes.

## Pregunta 102

Contexto: [topics:104](#topics-104)
Your company runs an ecommerce website built with JVM-based applications and microservice architecture in Google Kubernetes Engine (GKE). The application load increases during the day and decreases during the night. Your operations team has configured the application to run enough Pods to handle the evening peak load. You want to automate scaling by only running enough Pods and nodes for the load. What should you do?

**A.** Configure the Vertical Pod Autoscaler, but keep the node pool size static.

**B.** Configure the Vertical Pod Autoscaler, and enable the cluster autoscaler.

**C.** Configure the Horizontal Pod Autoscaler, but keep the node pool size static.

**D.** Configure the Horizontal Pod Autoscaler, and enable the cluster autoscaler.

**Respuesta de la fuente:** D

**Explicación:** The goal is to automate scaling for both Pods and nodes to match variable load. The Horizontal Pod Autoscaler (HPA) adjusts the number of Pod replicas based on observed CPU or memory usage. However, if the underlying node pool size is static, scaled-up Pods may become pending if insufficient resources are available.

Enabling the Cluster Autoscaler allows GKE to automatically add or remove nodes based on resource pressure caused by the HPA scaling events. Together, HPA manages Pod count while the Cluster Autoscaler ensures enough node capacity exists for those Pods.

## Pregunta 103

Contexto: [topics:104](#topics-104)
Your organization wants to increase the availability target of an application from 99.9% to 99.99% for an investment of $2,000. The application's current revenue is $1,000,000. You need to determine whether the increase in availability is worth the investment for a single year of usage. What should you do?

**A.** Calculate the value of improved availability to be $900, and determine that the increase in availability is not worth the investment.

**B.** Calculate the value of improved availability to be $1,000, and determine that the increase in availability is not worth the investment.

**C.** Calculate the value of improved availability to be $1,000, and determine that the increase in availability is worth the investment.

**D.** Calculate the value of improved availability to be $9,000, and determine that the increase in availability is worth the investment.

**Respuesta de la fuente:** A

**Explicación:** The increase in availability is 0.09% (99.99% - 99.9%). Applying this percentage to the $1,000,000 annual revenue yields a financial value of $900 ($1,000,000 * 0.0009). Since the cost of the investment ($2,000) exceeds the calculated value ($900), the upgrade is not financially justified for a single year.

## Pregunta 104

Contexto: [topics:104](#topics-104)
A third-party application needs to have a service account key to work properly. When you try to export the key from your cloud project, you receive an error: “The organization policy constraint iam.disableServiceAccounKeyCreation is enforced.” You need to make the third-party application work while following Google-recommended security practices.

What should you do?

**A.** Enable the default service account key, and download the key.

**B.** Remove the iam.disableServiceAccountKeyCreation policy at the organization level, and create a key.

**C.** Disable the service account key creation policy at the project's folder, and download the default key.

**D.** Add a rule to set the iam.disableServiceAccountKeyCreation policy to off in your project, and create a key.

**Respuesta de la fuente:** D

**Explicación:** The correct action is to add a rule at the project level to exempt it from the organization policy, allowing key creation only where needed.
This adheres to Google-recommended security practices by maintaining the strict constraint across the rest of the organization while granting minimal necessary access.
Overriding at the organization level (Option B) is broader and riskier than a targeted project-level exception.

## Pregunta 105

Contexto: [topics:104](#topics-104)
Your team is writing a postmortem after an incident on your external facing application. Your team wants to improve the postmortem policy to include triggers that indicate whether an incident requires a postmortem. Based on Site Reliability Engineering (SRE) practices, what triggers should be defined in the postmortem policy? (Choose two.)

**A.** An external stakeholder asks for a postmortem

**B.** Data is lost due to an incident.

**C.** An internal stakeholder requests a postmortem.

**D.** The monitoring system detects that one of the instances for your application has failed.

**E.** The CD pipeline detects an issue and rolls back a problematic release.

**Respuesta de la fuente:** A, B

**Explicación:** According to Google's Site Reliability Engineering practices, postmortems are triggered by objective evidence of significant impact or loss. Data loss is a critical failure that mandates a detailed investigation to prevent recurrence. Additionally, any external stakeholder request for a postmortem serves as a valid trigger, acknowledging the incident's impact on customer trust and experience.

Other options like instance failures or automated rollbacks are often handled by resilience mechanisms without requiring manual post-incident analysis unless specific thresholds are breached.

## Pregunta 106

Contexto: [topics:104](#topics-104)
You are implementing a CI/CD pipeline for your application in your company’s multi-cloud environment. Your application is deployed by using custom Compute Engine images and the equivalent in other cloud providers. You need to implement a solution that will enable you to build and deploy the images to your current environment and is adaptable to future changes. Which solution stack should you use?

**A.** Cloud Build with Packer

**B.** Cloud Build with Google Cloud Deploy

**C.** Google Kubernetes Engine with Google Cloud Deploy

**D.** Cloud Build with kpt

**Respuesta de la fuente:** A

**Explicación:** The requirement to build and deploy images in a multi-cloud environment necessitates a tool capable of creating identical VM images across different cloud providers. Packer is the industry-standard tool for defining machine images as code and building them for multiple platforms from a single source configuration, satisfying the multi-cloud adaptability constraint.

Cloud Build provides the CI/CD orchestration to automate the build process. Options B, C, and D focus on GCP-specific deployment or Kubernetes, lacking the cross-cloud image generation capability required by the scenario.

## Pregunta 107

Contexto: [topics:104](#topics-104)
Your application's performance in Google Cloud has degraded since the last release. You suspect that downstream dependencies might be causing some requests to take longer to complete. You need to investigate the issue with your application to determine the cause. What should you do?

**A.** Configure Error Reporting in your application.

**B.** Configure Google Cloud Managed Service for Prometheus in your application.

**C.** Configure Cloud Profiler in your application.

**D.** Configure Cloud Trace in your application.

**Respuesta de la fuente:** D

**Explicación:** Cloud Trace is the appropriate tool for investigating performance degradation caused by downstream dependencies because it captures end-to-end request latency and traces execution flow across distributed services. This allows you to identify specific bottlenecks and delays in the call chain that metrics or error reporting alone cannot pinpoint.

## Pregunta 108

Contexto: [topics:104](#topics-104)
You are creating a CI/CD pipeline in Cloud Build to build an application container image. The application code is stored in GitHub. Your company requires that production image builds are only run against the main branch and that the change control team approves all pushes to the main branch. You want the image build to be as automated as possible. What should you do? (Choose two.)

**A.** Create a trigger on the Cloud Build job. Set the repository event setting to ‘Pull request’.

**B.** Add the OWNERS file to the Included files filter on the trigger.

**C.** Create a trigger on the Cloud Build job. Set the repository event setting to ‘Push to a branch’

**D.** Configure a branch protection rule for the main branch on the repository.

**E.** Enable the Approval option on the trigger.

**Respuesta de la fuente:** C, D

**Explicación:** Option C is correct because setting the Cloud Build trigger to 'Push to a branch' ensures the build automatically starts when changes are merged into the main branch.
Option D is correct because configuring branch protection rules on GitHub enforces that all pushes (merges) to the main branch require prior approval from designated reviewers, satisfying the change control requirement.

## Pregunta 109

Contexto: [topics:104](#topics-104)
You built a serverless application by using Cloud Run and deployed the application to your production environment. You want to identify the resource utilization of the application for cost optimization. What should you do?

**A.** Use Cloud Trace with distributed tracing to monitor the resource utilization of the application.

**B.** Use Cloud Profiler with Ops Agent to monitor the CPU and memory utilization of the application.

**C.** Use Cloud Monitoring to monitor the container CPU and memory utilization of the application.

**D.** Use Cloud Ops to create logs-based metrics to monitor the resource utilization of the application.

**Respuesta de la fuente:** C

**Explicación:** Cloud Run automatically integrates with Cloud Monitoring to provide built-in metrics for container CPU and memory utilization without requiring manual agent installation. These specific resource metrics are essential for identifying usage patterns to optimize costs, whereas Cloud Trace is for latency analysis and Cloud Profiler is generally not supported or necessary for basic resource tracking in this context.

## Pregunta 110

Contexto: [topics:104](#topics-104)
Your company is using HTTPS requests to trigger a public Cloud Run-hosted service accessible at the https://booking-engine-abcdef.a.run.app URL. You need to give developers the ability to test the latest revisions of the service before the service is exposed to customers. What should you do?

**A.** Run the gcloud run deploy booking-engine --no-traffic --tag dev command. Use the https://dev--booking-engine-abcdef.a.run.app URL for testing.

**B.** Run the gcloud run services update-traffic booking-engine --to-revisions LATEST=1 command. Use the https://booking-engine-abcdef.a.run.app URL for testing.

**C.** Pass the curl –H “Authorization:Bearer $(gcloud auth print-identity-token)” auth token. Use the https://booking-engine-abcdef.a.run.app URL to test privately.

**D.** Grant the roles/run.invoker role to the developers testing the booking-engine service. Use the https://booking-engine-abcdef.private.run.app URL for testing.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because deploying with the `--no-traffic` flag prevents the new revision from receiving live production traffic, while the `--tag dev` option creates a unique URL (e.g., dev--booking-engine.a.run.app) for isolated testing. This ensures developers can validate the latest code without impacting end-users or requiring complex permission changes on the main service endpoint.

## Pregunta 111

Contexto: [topics:104](#topics-104)
You are configuring connectivity across Google Kubernetes Engine (GKE) clusters in different VPCs. You notice that the nodes in Cluster A are unable to access the nodes in Cluster B. You suspect that the workload access issue is due to the network configuration. You need to troubleshoot the issue but do not have execute access to workloads and nodes. You want to identify the layer at which the network connectivity is broken. What should you do?

**A.** Install a toolbox container on the node in Cluster Confirm that the routes to Cluster B are configured appropriately.

**B.** Use Network Connectivity Center to perform a Connectivity Test from Cluster A to Cluster B.

**C.** Use a debug container to run the traceroute command from Cluster A to Cluster B and from Cluster B to Cluster A. Identify the common failure point.

**D.** Enable VPC Flow Logs in both VPCs, and monitor packet drops.

**Respuesta de la fuente:** B

**Explicación:** The question explicitly states you do not have execute access to workloads or nodes, which rules out Options A and C as they require running commands inside containers. While VPC Flow Logs (Option D) record traffic after it occurs, they do not proactively test connectivity paths to identify where a break exists. Network Connectivity Center (referenced as Network Connectivity Center in Option B, though technically often associated with Network Intelligence Center tests) allows you to simulate and validate network connectivity between endpoints without needing direct access to the nodes, making it the correct choice for identifying the failure layer.

## Pregunta 112

Contexto: [topics:104](#topics-104)
You manage an application that runs in Google Kubernetes Engine (GKE) and uses the blue/green deployment methodology. Extracts of the Kubernetes manifests are shown below:

[Imagen: sin descripción]

The Deployment app-green was updated to use the new version of the application. During post-deployment monitoring, you notice that the majority of user requests are failing. You did not observe this behavior in the testing environment. You need to mitigate the incident impact on users and enable the developers to troubleshoot the issue. What should you do?
Imagen · question_text · sin descripción
![Imagen original](imagenes/6786d8fe597b532d5af3.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
apiVersion: apps/vi
kind: Deployment
metadata
name: app-green
labels
app: my-app
version: green
<other fields snipped>
apiVersion: apps/vi
kind: Deployment
metadata:
name: app-blue
labels:
app: my-app
version: blue
<other fields snipped>
apiversion: vi
kinc Service
metadata
name
app-sve
selector:
app: my-app
version: green
<other fields snipped>
spe!
apivVersion: networking. k8s.io/v1
kind: Ingress
metadata
name: app-ingress
spec:
defaultBackend:
service
name
app-svc
<other fields snipped>
```

**A.** Update the Deployment app-blue to use the new version of the application.

**B.** Update the Deployment app-green to use the previous version of the application.

**C.** Change the selector on the Service app-svc to app: my-app.

**D.** Change the selector on the Service app-svc to app: my-app, version: blue.

**Respuesta de la fuente:** D

**Explicación:** In a blue/green deployment, traffic switching is achieved by updating the Service selector to point to the desired deployment version. Since the green deployment (new version) is causing failures, changing the selector to target the blue deployment (stable version) immediately restores user access and mitigates impact.

This action keeps the failing green deployment running with a different label or no traffic, allowing developers to troubleshoot the issue without affecting production users.

## Pregunta 113

Contexto: [topics:104](#topics-104)
You are running a web application deployed to a Compute Engine managed instance group. Ops Agent is installed on all instances. You recently noticed suspicious activity from a specific IP address. You need to configure Cloud Monitoring to view the number of requests from that specific IP address with minimal operational overhead. What should you do?

**A.** Configure the Ops Agent with a logging receiver. Create a logs-based metric.
B Create a script to scrape the web server log. Export the IP address request metrics to the Cloud Monitoring API.

**C.** Update the application to export the IP address request metrics to the Cloud Monitoring API.

**D.** Configure the Ops Agent with a metrics receiver.

**Respuesta de la fuente:** A

**Explicación:** The Ops Agent collects logs from the instances, and Cloud Monitoring allows you to create metrics based on log data.
Creating a logs-based metric is the standard method to quantify specific log entries (like requests from an IP) without modifying application code or managing custom scripts.
This approach minimizes operational overhead by leveraging existing logging infrastructure and built-in Cloud Monitoring features.

## Pregunta 114

Contexto: [topics:104](#topics-104)
Your organization is using Helm to package containerized applications. Your applications reference both public and private charts. Your security team flagged that using a public Helm repository as a dependency is a risk. You want to manage all charts uniformly, with native access control and VPC Service Controls. What should you do?

**A.** Store public and private charts in OCI format by using Artifact Registry.

**B.** Store public and private charts by using GitHub Enterprise with Google Workspace as the identity provider.

**C.** Store public and private charts by using Git repository. Configure Cloud Build to synchronize contents of the repository into a Cloud Storage bucket. Connect Helm to the bucket by using https://[bucket].storage-googleapis.com/[helmchart] as the Helm repository.

**D.** Configure a Helm chart repository server to run in Google Kubernetes Engine (GKE) with Cloud Storage bucket as the storage backend.

**Respuesta de la fuente:** A

**Explicación:** Artifact Registry supports Helm charts natively via the OCI distribution specification, allowing both public and private charts to be stored in a single, secure repository.
It provides integrated Identity and Access Management (IAM) for granular access control and is fully supported by VPC Service Controls to enforce network perimeters.
Other options like Cloud Storage or GitHub lack native VPC Service Controls enforcement or built-in Helm-specific IAM granularity required by the prompt.

## Pregunta 115

Contexto: [topics:104](#topics-104)
You use Terraform to manage an application deployed to a Google Cloud environment. The application runs on instances deployed by a managed instance group. The Terraform code is deployed by using a CI/CD pipeline. When you change the machine type on the instance template used by the managed instance group, the pipeline fails at the terraform apply stage with the following error message:

[Imagen: sin descripción]

You need to update the instance template and minimize disruption to the application and the number of pipeline runs.

What should you do?
Imagen · question_text · sin descripción
![Imagen original](imagenes/ed38f94edc634e8946b9.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Error waiting for Deleting Instance Template: The instance_template resource
‘project /my-project/global/instanceTemplates/my-it-2022010101010100000000001"
is already being used by ‘projects/my-project/regions/us-
centrall/instanceGroupManagers/my-mig’
```

**A.** Delete the managed instance group, and recreate it after updating the instance template.

**B.** Add a new instance template, update the managed instance group to use the new instance template, and delete the old instance template.

**C.** Remove the managed instance group from the Terraform state file, update the instance template, and reimport the managed instance group.

**D.** Set the create_before_destroy meta-argument to true in the lifecycle block on the instance template.

**Respuesta de la fuente:** D

**Explicación:** Google Cloud instance templates are immutable resources, meaning updates require Terraform to destroy and recreate the resource. By setting `create_before_destroy = true` in the lifecycle block, Terraform provisions the new template before destroying the old one, preventing a state breakage that occurs when instances reference a non-existent template during replacement. This approach allows the managed instance group to adopt the new template smoothly without requiring manual state manipulation or multiple pipeline runs.

## Pregunta 116

Contexto: [topics:104](#topics-104)
Your company operates in a highly regulated domain that requires you to store all organization logs for seven years. You want to minimize logging infrastructure complexity by using managed services. You need to avoid any future loss of log capture or stored logs due to misconfiguration or human error. What should you do?

**A.** Use Cloud Logging to configure an aggregated sink at the organization level to export all logs into a BigQuery dataset.

**B.** Use Cloud Logging to configure an aggregated sink at the organization level to export all logs into Cloud Storage with a seven-year retention policy and Bucket Lock.

**C.** Use Cloud Logging to configure an export sink at each project level to export all logs into a BigQuery dataset

**D.** Use Cloud Logging to configure an export sink at each project level to export all logs into Cloud Storage with a seven-year retention policy and Bucket Lock.

**Respuesta de la fuente:** B

**Explicación:** An aggregated sink at the organization level minimizes infrastructure complexity by centralizing log collection from all projects into a single configuration. Cloud Storage with Bucket Lock ensures regulatory compliance and prevents data loss by making the retention policy immutable, protecting logs against accidental or malicious deletion due to misconfiguration or human error.

## Pregunta 117

Contexto: [topics:104](#topics-104)
You are building the CI/CD pipeline for an application deployed to Google Kubernetes Engine (GKE). The application is deployed by using a Kubernetes Deployment, Service, and Ingress. The application team asked you to deploy the application by using the blue/green deployment methodology. You need to implement the rollback actions. What should you do?

**A.** Run the kubectl rollout undo command.

**B.** Delete the new container image, and delete the running Pods.

**C.** Update the Kubernetes Service to point to the previous Kubernetes Deployment.

**D.** Scale the new Kubernetes Deployment to zero.

**Respuesta de la fuente:** C

**Explicación:** In a blue/green deployment strategy, two separate environments (blue and green) run simultaneously, and traffic is directed via the Kubernetes Service selector.
To perform a rollback, you simply update the Service's selector labels to point back to the previous Deployment (e.g., from green to blue).
This immediately switches live traffic to the stable version without waiting for pod rollouts or deleting resources.

## Pregunta 118

Contexto: [topics:104](#topics-104)
You are building and running client applications in Cloud Run and Cloud Functions. Your client requires that all logs must be available for one year so that the client can import the logs into their logging service. You must minimize required code changes. What should you do?

**A.** Update all images in Cloud Run and all functions in Cloud Functions to send logs to both Cloud Logging and the client's logging service. Ensure that all the ports required to send logs are open in the VPC firewall.

**B.** Create a Pub/Sub topic, subscription, and logging sink. Configure the logging sink to send all logs into the topic. Give your client access to the topic to retrieve the logs.

**C.** Create a storage bucket and appropriate VPC firewall rules. Update all images in Cloud Run and all functions in Cloud Functions to send logs to a file within the storage bucket.

**D.** Create a logs bucket and logging sink. Set the retention on the logs bucket to 365 days. Configure the logging sink to send logs to the bucket. Give your client access to the bucket to retrieve the logs.

**Respuesta de la fuente:** D

**Explicación:** Using Cloud Logging sinks with Logs Buckets is the native GCP mechanism for retaining logs beyond the default window without modifying application code. By configuring a sink to export logs to a bucket with 365-day retention, you satisfy the client's storage requirement while ensuring zero changes to the Cloud Run or Cloud Functions source code.

## Pregunta 119

Contexto: [topics:104](#topics-104)
You are building and running client applications in Cloud Run and Cloud Functions. Your client requires that all logs must be available for one year so that the client can import the logs into their logging service. You must minimize required code changes. What should you do?

**A.** Deploy Falco or Twistlock on GKE to monitor for vulnerabilities on your running Pods.

**B.** Configure Identity and Access Management (IAM) policies to create a least privilege model on your GKE clusters.

**C.** Use Binary Authorization to attest images during your CI/CD pipeline.

**D.** Enable Container Analysis in Artifact Registry, and check for common vulnerabilities and exposures (CVEs) in your container images.

**Respuesta de la fuente:** C

**Explicación:** Binary Authorization is the correct answer because it enforces a 'shift left' security strategy by verifying image attestations within the CI/CD pipeline, ensuring that only trusted and approved container images are deployed to GKE clusters.

Option C specifically addresses the requirement to implement guardrails for trusted images, whereas options A, B, and D focus on runtime monitoring, access control, or post-build vulnerability scanning, which do not directly enforce the deployment of verified images during the build stage.

## Pregunta 120

Contexto: [topics:104](#topics-104)
You have an application that runs in Google Kubernetes Engine (GKE). The application consists of several microservices that are deployed to GKE by using Deployments and Services. One of the microservices is experiencing an issue where a Pod returns 403 errors after the Pod has been running for more than five hours. Your development team is working on a solution, but the issue will not be resolved for a month. You need to ensure continued operations until the microservice is fixed. You want to follow Google-recommended practices and use the fewest number of steps. What should you do?

**A.** Create a cron job to terminate any Pods that have been running for more than five hours.

**B.** Add a HTTP liveness probe to the microservice's deployment.

**C.** Monitor the Pods, and terminate any Pods that have been running for more than five hours.

**D.** Configure an alert to notify you whenever a Pod returns 403 errors.

**Respuesta de la fuente:** B

**Explicación:** A liveness probe allows Kubernetes to automatically detect when a container has entered an unhealthy state, such as returning HTTP 403 errors after five hours. Upon detection, the kubelet kills the container and restarts it, effectively resetting the application's state without manual intervention. This approach aligns with Google-recommended practices for self-healing applications using the fewest steps compared to manual termination or cron jobs.

## Pregunta 121

Contexto: [topics:104](#topics-104)
You want to share a Cloud Monitoring custom dashboard with a partner team. What should you do?

**A.** Provide the partner team with the dashboard URL to enable the partner team to create a copy of the dashboard.

**B.** Export the metrics to BigQuery. Use Looker Studio to create a dashboard, and share the dashboard with the partner team.

**C.** Copy the Monitoring Query Language (MQL) query from the dashboard, and send the ML query to the partner team.

**D.** Download the JSON definition of the dashboard, and send the JSON file to the partner team.

**Respuesta de la fuente:** D

**Explicación:** To share a custom dashboard's structure and layout with an external party without granting access to the underlying data, you should export the dashboard as a JSON file.
This allows the recipient to import the definition into their own Google Cloud project, creating a replica of the dashboard that queries their specific resources.
Sharing the URL (A) only provides view-only access within your project, while MQL (C) and BigQuery exports (B) do not preserve the full dashboard configuration.

## Pregunta 122

Contexto: [topics:104](#topics-104)
You are building an application that runs on Cloud Run. The application needs to access a third-party API by using an API key. You need to determine a secure way to store and use the API key in your application by following Google-recommended practices. What should you do?

**A.** Save the API key in Secret Manager as a secret. Reference the secret as an environment variable in the Cloud Run application.

**B.** Save the API key in Secret Manager as a secret key. Mount the secret key under the /sys/api_key directory, and decrypt the key in the Cloud Run application.

**C.** Save the API key in Cloud Key Management Service (Cloud KMS) as a key. Reference the key as an environment variable in the Cloud Run application.

**D.** Encrypt the API key by using Cloud Key Management Service (Cloud KMS), and pass the key to Cloud Run as an environment variable. Decrypt and use the key in Cloud Run.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Secret Manager is the recommended service for storing and managing sensitive data like API keys, offering centralized security and access control.
Cloud Run natively supports injecting secrets as environment variables or mounting them as files without requiring manual decryption logic.
Option A correctly utilizes this native integration to securely pass the key to the application.

## Pregunta 123

Contexto: [topics:104](#topics-104)
You are currently planning how to display Cloud Monitoring metrics for your organization’s Google Cloud projects. Your organization has three folders and six projects:

[Imagen: sin descripción]

You want to configure Cloud Monitoring dashboards to only display metrics from the projects within one folder. You need to ensure that the dashboards do not display metrics from projects in the other folders. You want to follow Google-recommended practices. What should you do?
Imagen · question_text · sin descripción
![Imagen original](imagenes/eaf0ae5a8be91051fd0b.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Folders Projects
Development : app-one dev
* app-one-staging
Seana + _app-two-staging
Production *app-one-prod
app-two-prod
```

**A.** Create a single new scoping project.

**B.** Create new scoping projects for each folder.

**C.** Use the current app-one-prod project as the scoping project.

**D.** Use the current app-one-dev, app-one-staging, and app-one-prod projects as the scoping project for each folder.

**Respuesta de la fuente:** B

**Explicación:** To scope monitoring metrics to a specific folder, you must designate a scoping project within that folder.
Google best practices recommend using a dedicated, empty 'scoping project' rather than an existing workload project to avoid data mixing and permission conflicts.
Since the organization has three distinct folders requiring isolated views, creating new scoping projects for each folder (Option B) ensures proper separation of concerns.

## Pregunta 124

Contexto: [topics:104](#topics-104)
Your company’s security team needs to have read-only access to Data Access audit logs in the _Required bucket. You want to provide your security team with the necessary permissions following the principle of least privilege and Google-recommended practices. What should you do?

**A.** Assign the roles/logging.viewer role to each member of the security team.

**B.** Assign the roles/logging.viewer role to a group with all the security team members.

**C.** Assign the roles/logging.privateLogViewer role to each member of the security team.

**D.** Assign the roles/logging.privateLogViewer role to a group with all the security team members.

**Respuesta de la fuente:** D

**Explicación:** The roles/logging.privateLogViewer role is specifically designed to grant read-only access to Data Access audit logs, which are classified as private logs and require this more restrictive permission compared to the broader logging.viewer role.
Assigning the role to a Google Group rather than individual users adheres to Google-recommended practices for identity management, allowing for efficient and centralized permission updates while maintaining the principle of least privilege.

## Pregunta 125

Contexto: [topics:104](#topics-104)
Your team is building a service that performs compute-heavy processing on batches of data. The data is processed faster based on the speed and number of CPUs on the machine. These batches of data vary in size and may arrive at any time from multiple third-party sources. You need to ensure that third parties are able to upload their data securely. You want to minimize costs, while ensuring that the data is processed as quickly as possible. What should you do?

**A.** Provide a secure file transfer protocol (SFTP) server on a Compute Engine instance so that third parties can upload batches of data, and provide appropriate credentials to the server.
Create a Cloud Function with a google.storage.object.finalize Cloud Storage trigger. Write code so that the function can scale up a Compute Engine autoscaling managed instance group
Use an image pre-loaded with the data processing software that terminates the instances when processing completes.

**B.** Provide a Cloud Storage bucket so that third parties can upload batches of data, and provide appropriate Identity and Access Management (IAM) access to the bucket.
Use a standard Google Kubernetes Engine (GKE) cluster and maintain two services: one that processes the batches of data, and one that monitors Cloud Storage for new batches of data.
Stop the processing service when there are no batches of data to process.

**C.** Provide a Cloud Storage bucket so that third parties can upload batches of data, and provide appropriate Identity and Access Management (IAM) access to the bucket.
Create a Cloud Function with a google.storage.object.finalize Cloud Storage trigger. Write code so that the function can scale up a Compute Engine autoscaling managed instance group.
Use an image pre-loaded with the data processing software that terminates the instances when processing completes.

**D.** Provide a Cloud Storage bucket so that third parties can upload batches of data, and provide appropriate Identity and Access Management (IAM) access to the bucket.
Use Cloud Monitoring to detect new batches of data in the bucket and trigger a Cloud Function that processes the data.
Set a Cloud Function to use the largest CPU possible to minimize the runtime of the processing.

**Respuesta de la fuente:** C

**Explicación:** Cloud Storage provides a cost-effective and secure ingestion point for third-party data using IAM controls.
Cloud Functions act as event-driven triggers to scale Compute Engine instances, which offer the high CPU performance required for compute-heavy tasks without the latency limits of Cloud Functions.
This architecture minimizes costs by running VMs only when needed and processing completes, unlike option D where scaling up Cloud Function resources is expensive and hits execution time limits.

## Pregunta 126

Contexto: [topics:104](#topics-104)
You are reviewing your deployment pipeline in Google Cloud Deploy. You must reduce toil in the pipeline, and you want to minimize the amount of time it takes to complete an end-to-end deployment. What should you do? (Choose two.)

**A.** Create a trigger to notify the required team to complete the next step when manual intervention is required.

**B.** Divide the automation steps into smaller tasks.

**C.** Use a script to automate the creation of the deployment pipeline in Google Cloud Deploy.

**D.** Add more engineers to finish the manual steps.

**E.** Automate promotion approvals from the development environment to the test environment.

**Respuesta de la fuente:** B, E

**Explicación:** Dividing automation steps into smaller tasks (B) enables parallel execution in Google Cloud Deploy, directly reducing end-to-end deployment time. Automating promotion approvals from development to test (E) eliminates manual waiting periods and reduces operational toil by removing the need for human intervention during early pipeline stages.

## Pregunta 127

Contexto: [topics:104](#topics-104)
You work for a global organization and are running a monolithic application on Compute Engine. You need to select the machine type for the application to use that optimizes CPU utilization by using the fewest number of steps. You want to use historical system metrics to identify the machine type for the application to use. You want to follow Google-recommended practices. What should you do?

**A.** Use the Recommender API and apply the suggested recommendations.

**B.** Create an Agent Policy to automatically install Ops Agent in all VMs.

**C.** Install the Ops Agent in a fleet of VMs by using the gcloud CLI.

**D.** Review the Cloud Monitoring dashboard for the VM and choose the machine type with the lowest CPU utilization.

**Respuesta de la fuente:** A

**Explicación:** The Google Cloud Recommender service analyzes historical system metrics to provide data-driven suggestions for optimizing resource usage, such as rightsizing Compute Engine instances.
Using the Recommender API directly addresses the requirement to leverage historical data for CPU optimization while following Google-recommended practices with minimal manual steps.

## Pregunta 128

Contexto: [topics:104](#topics-104)
You deployed an application into a large Standard Google Kubernetes Engine (GKE) cluster. The application is stateless and multiple pods run at the same time. Your application receives inconsistent traffic. You need to ensure that the user experience remains consistent regardless of changes in traffic and that the resource usage of the cluster is optimized.

What should you do?

**A.** Configure a cron job to scale the deployment on a schedule

**B.** Configure a Horizontal Pod Autoscaler.

**C.** Configure a Vertical Pod Autoscaler

**D.** Configure cluster autoscaling on the node pool.

**Respuesta de la fuente:** B

**Explicación:** The Horizontal Pod Autoscaler (HPA) automatically adjusts the number of pod replicas based on observed metrics like CPU utilization or custom traffic indicators. This dynamic scaling ensures sufficient capacity during traffic spikes for a consistent user experience while reducing resources during low demand to optimize cluster usage, which is ideal for stateless applications.

## Pregunta 129

Contexto: [topics:104](#topics-104)
You need to deploy a new service to production. The service needs to automatically scale using a managed instance group and should be deployed across multiple regions. The service needs a large number of resources for each instance and you need to plan for capacity. What should you do?

**A.** Monitor results of Cloud Trace to determine the optimal sizing.

**B.** Use the n2-highcpu-96 machine type in the configuration of the managed instance group.

**C.** Deploy the service in multiple regions and use an internal load balancer to route traffic.

**D.** Validate that the resource requirements are within the available project quota limits of each region.

**Respuesta de la fuente:** D

**Explicación:** The question explicitly asks how to 'plan for capacity' given high resource requirements. Validating that these requirements fit within project quota limits (Option D) is the critical prerequisite step; without sufficient quotas, the managed instance group cannot scale as intended. Other options address monitoring, specific machine types, or routing, but do not directly solve the capacity planning constraint imposed by quotas.

## Pregunta 130

Contexto: [topics:104](#topics-104)
You are analyzing Java applications in production. All applications have Cloud Profiler and Cloud Trace installed and configured by default. You want to determine which applications need performance tuning. What should you do? (Choose two.)

**A.** Examine the wall-clock time and the CPU time of the application. If the difference is substantial increase the CPU resource allocation.

**B.** Examine the wall-clock time and the CPU time of the application. If the difference is substantial, increase the memory resource allocation.

**C.** Examine the wall-clock time and the CPU time of the application. If the difference is substantial, increase the local disk storage allocation.

**D.** Examine the latency time the wall-clock time and the CPU time of the application. If the latency time is slowly burning down the error budget, and the difference between wall-clock time and CPU time is minimal mark the application for optimization.

**E.** Examine the heap usage of the application. If the usage is low, mark the application for optimization.

**Respuesta de la fuente:** D, E

**Explicación:** Option D is correct because a minimal difference between wall-clock and CPU time indicates the application is CPU-bound rather than waiting on I/O; if this latency erodes the error budget, code optimization (not just resource scaling) is required.

Option E is correct because low heap usage in a Java application suggests inefficient object management or under-utilization of allocated memory, indicating that performance tuning at the code level is needed to improve efficiency.

## Pregunta 131

Contexto: [topics:104](#topics-104)
Your organization stores all application logs from multiple Google Cloud projects in a central Cloud Logging project. Your security team wants to enforce a rule that each project team can only view their respective logs and only the operations team can view all the logs. You need to design a solution that meets the security team s requirements while minimizing costs. What should you do?

**A.** Grant each project team access to the project _Default view in the central logging project. Grant togging viewer access to the operations team in the central logging project.

**B.** Create Identity and Access Management (IAM) roles for each project team and restrict access to the _Default log view in their individual Google Cloud project. Grant viewer access to the operations team in the central logging project.

**C.** Create log views for each project team and only show each project team their application logs. Grant the operations team access to the _AllLogs view in the central logging project.

**D.** Export logs to BigQuery tables for each project team. Grant project teams access to their tables. Grant logs writer access to the operations team in the central logging project.

**Respuesta de la fuente:** C

**Explicación:** Log views provide a cost-effective way to create fine-grained access controls over logs within a central bucket without the overhead of exporting data. By creating custom log views filtered by project for each team, you restrict their visibility to only their own application logs while granting the operations team access to the _AllLogs view for full visibility.

## Pregunta 132

Contexto: [topics:104](#topics-104)
Your company uses Jenkins running on Google Cloud VM instances for CI/CD. You need to extend the functionality to use infrastructure as code automation by using Terraform. You must ensure that the Terraform Jenkins instance is authorized to create Google Cloud resources. You want to follow Google-recommended practices. What should you do?

**A.** Confirm that the Jenkins VM instance has an attached service account with the appropriate Identity and Access Management (IAM) permissions.

**B.** Use the Terraform module so that Secret Manager can retrieve credentials.

**C.** Create a dedicated service account for the Terraform instance. Download and copy the secret key value to the GOOGLE_CREDENTIALS environment variable on the Jenkins server.

**D.** Add the gcloud auth application-default login command as a step in Jenkins before running the Terraform commands.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud best practices prioritize identity-based access over secret key management for VM instances.
Attaching a service account with appropriate IAM permissions allows the Jenkins VM to automatically authenticate without managing static credentials or environment variables.
This approach eliminates the security risks associated with storing private keys and ensures secure, automatic authentication for Terraform operations.

## Pregunta 133

Contexto: [topics:104](#topics-104)
You encounter a large number of outages in the production systems you support. You receive alerts for all the outages, the alerts are due to unhealthy systems that are automatically restarted within a minute. You want to set up a process that would prevent staff burnout while following Site Reliability Engineering (SRE) practices. What should you do?

**A.** Eliminate alerts that are not actionable

**B.** Redefine the related SLO so that the error budget is not exhausted

**C.** Distribute the alerts to engineers in different time zones

**D.** Create an incident report for each of the alerts

**Respuesta de la fuente:** A

**Explicación:** In SRE, alerts should only be generated for issues that require human intervention to resolve.
Since the systems automatically restart within a minute, no manual action is needed, making these alerts noise rather than signal.
Suppressing non-actionable alerts reduces alert fatigue and prevents staff burnout without compromising system reliability.

## Pregunta 134

Contexto: [topics:104](#topics-104)
As part of your company's initiative to shift left on security, the InfoSec team is asking all teams to implement guard rails on all the Google Kubernetes Engine (GKE) clusters to only allow the deployment of trusted and approved images. You need to determine how to satisfy the InfoSec team's goal of shifting left on security. What should you do?

**A.** Enable Container Analysis in Artifact Registry, and check for common vulnerabilities and exposures (CVEs) in your container images

**B.** Use Binary Authorization to attest images during your CI/CD pipeline

**C.** Configure Identity and Access Management (IAM) policies to create a least privilege model on your GKE clusters.

**D.** Deploy Falco or Twistlock on GKE to monitor for vulnerabilities on your running Pods

**Respuesta de la fuente:** B

**Explicación:** Binary Authorization is the specific GCP service designed to enforce admission control policies that allow only trusted and signed container images to run on GKE clusters.
By integrating attestation into the CI/CD pipeline, you implement 'shift left' security by verifying image integrity before deployment, rather than scanning after the fact or relying on runtime monitoring.

## Pregunta 135

Contexto: [topics:104](#topics-104)
Your company operates in a highly regulated domain. Your security team requires that only trusted container images can be deployed to Google Kubernetes Engine (GKE). You need to implement a solution that meets the requirements of the security team while minimizing management overhead. What should you do?

**A.** Configure Binary Authorization in your GKE clusters to enforce deploy-time security policies.

**B.** Grant the roles/artifactregistry.writer role to the Cloud Build service account. Confirm that no employee has Artifact Registry write permission.

**C.** Use Cloud Run to write and deploy a custom validator. Enable an Eventarc trigger to perform validations when new images are uploaded.

**D.** Configure Kritis to run in your GKE clusters to enforce deploy-time security policies.

**Respuesta de la fuente:** A

**Explicación:** Binary Authorization is the native Google Cloud service designed to enforce deploy-time security policies on GKE, ensuring only authorized container images (verified by signatures or attestations) are deployed. It meets the requirement for strict control in regulated domains while minimizing management overhead compared to custom solutions like Kritis or Eventarc-based validators.

## Pregunta 136

Contexto: [topics:104](#topics-104)
Your CTO has asked you to implement a postmortem policy on every incident for internal use. You want to define what a good postmortem is to ensure that the policy is successful at your company. What should you do? (Choose two.)

**A.** Ensure that all postmortems include what caused the incident, identify the person or team responsible for causing the incident, and how to prevent a future occurrence of the incident.

**B.** Ensure that all postmortems include what caused the incident, how the incident could have been worse, and how to prevent a future occurrence of the incident.

**C.** Ensure that all postmortems include the severity of the incident, how to prevent a future occurrence of the incident, and what caused the incident without naming internal system components.

**D.** Ensure that all postmortems include how the incident was resolved and what caused the incident without naming customer information.

**E.** Ensure that all postmortems include all incident participants in postmortem authoring and share postmortems as widely as possible.

**Respuesta de la fuente:** C, E

**Explicación:** Effective postmortems must focus on systemic improvements rather than individual blame, making Option A incorrect due to its emphasis on identifying the person responsible.
Option C is correct because it highlights root cause analysis and prevention while appropriately protecting sensitive internal system details.
Option E is correct as it promotes a collaborative, blame-free culture by involving all participants in authoring and widely sharing lessons learned.

## Pregunta 137

Contexto: [topics:104](#topics-104)
You are developing reusable infrastructure as code modules. Each module contains integration tests that launch the module in a test project. You are using GitHub for source control. You need to continuously test your feature branch and ensure that all code is tested before changes are accepted. You need to implement a solution to automate the integration tests. What should you do?

**A.** Use a Jenkins server for CI/CD pipelines. Periodically run all tests in the feature branch.

**B.** Ask the pull request reviewers to run the integration tests before approving the code.

**C.** Use Cloud Build to run the tests. Trigger all tests to run after a pull request is merged.

**D.** Use Cloud Build to run tests in a specific folder. Trigger Cloud Build for every GitHub pull request.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it implements continuous integration by triggering automated tests on every pull request, ensuring code is validated before merging. Running tests via Cloud Build upon PR creation provides immediate feedback and prevents untested changes from entering the main branch, unlike Option C which runs them post-merge.

## Pregunta 138

Contexto: [topics:104](#topics-104)
Your company processes IoT data at scale by using Pub/Sub, App Engine standard environment, and an application written in Go. You noticed that the performance inconsistently degrades at peak load. You could not reproduce this issue on your workstation. You need to continuously monitor the application in production to identify slow paths in the code. You want to minimize performance impact and management overhead. What should you do?

**A.** Use Cloud Monitoring to assess the App Engine CPU utilization metric.

**B.** Install a continuous profiling tool into Compute Engine. Configure the application to send profiling data to the tool.

**C.** Periodically run the go tool pprof command against the application instance. Analyze the results by using flame graphs.

**D.** Configure Cloud Profiler, and initialize the cloud.google.com/go/profiler library in the application.

**Respuesta de la fuente:** D

**Explicación:** Cloud Profiler is designed specifically for continuous, low-overhead profiling in production environments, meeting the requirement to minimize performance impact and management overhead.
It provides detailed CPU, memory, and mutex profiles that help identify slow code paths without the manual intervention or significant resource cost associated with tools like `pprof` or general monitoring metrics.

## Pregunta 139

Contexto: [topics:104](#topics-104)
Your company runs services by using Google Kubernetes Engine (GKE). The GKE dusters in the development environment run applications with verbose logging enabled. Developers view logs by using the kubectl logs command and do not use Cloud Logging. Applications do not have a uniform logging structure defined. You need to minimize the costs associated with application logging while still collecting GKE operational logs. What should you do?

**A.** Run the gcloud container clusters update --logging=SYSTEM command for the development cluster.

**B.** Run the gcloud container clusters update --logging=WORKLOAD command for the development cluster.

**C.** Run the gcloud logging sinks update _Default --disabled command in the project associated with the development environment.

**D.** Add the severity >= DEBUG resource.type = "k8s_container" exclusion filter to the _Default logging sink in the project associated with the development environment.

**Respuesta de la fuente:** A

**Explicación:** Setting the logging level to SYSTEM (Option A) stops the ingestion of verbose application logs into Cloud Logging while retaining essential GKE operational logs for monitoring. This directly minimizes costs associated with unnecessary workload log ingestion without impacting developers' ability to view local logs via kubectl.

## Pregunta 140

Contexto: [topics:104](#topics-104)
You have deployed a fleet of Compute Engine instances in Google Cloud. You need to ensure that monitoring metrics and logs for the instances are visible in Cloud Logging and Cloud Monitoring by your company's operations and cyber security teams. You need to grant the required roles for the Compute Engine service account by using Identity and Access Management (IAM) while following the principle of least privilege. What should you do?

**A.** Grant the logging.logWriter and monitoring.metricWriter roles to the Compute Engine service accounts.

**B.** Grant the logging.admin and monitoring.editor roles to the Compute Engine service accounts.

**C.** Grant the logging.editor and monitoring.metricWriter roles to the Compute Engine service accounts.

**D.** Grant the logging.logWriter and monitoring.editor roles to the Compute Engine service accounts.

**Respuesta de la fuente:** A

**Explicación:** To adhere to the principle of least privilege, you must grant only the specific permissions required for writing data rather than broad administrative or editing roles. The roles/logging.logWriter role allows the service account to write log entries, and roles/monitoring.metricWriter allows it to create custom metrics. Options B, C, and D include overly permissive roles (like logging.admin, monitoring.editor, or logging.editor) that exceed the necessary scope for simply sending logs and metrics.

## Pregunta 141

Contexto: [topics:104](#topics-104)
You are the Site Reliability Engineer responsible for managing your company's data services and products. You regularly navigate operational challenges, such as unpredictable data volume and high cost, with your company's data ingestion processes. You recently learned that a new data ingestion product will be developed in Google Cloud. You need to collaborate with the product development team to provide operational input on the new product. What should you do?

**A.** Deploy the prototype product in a test environment, run a load test, and share the results with the product development team.

**B.** When the initial product version passes the quality assurance phase and compliance assessments, deploy the product to a staging environment. Share error logs and performance metrics with the product development team.

**C.** When the new product is used by at least one internal customer in production, share error logs and monitoring metrics with the product development team.

**D.** Review the design of the product with the product development team to provide feedback early in the design phase.

**Respuesta de la fuente:** D

**Explicación:** Site Reliability Engineering (SRE) principles emphasize 'shifting left,' which involves integrating operational insights early in the software development lifecycle. Reviewing the design phase allows the SRE to address scalability, cost, and reliability concerns proactively before code is written or deployed, preventing expensive rework later.

## Pregunta 142

Contexto: [topics:104](#topics-104)
You are investigating issues in your production application that runs on Google Kubernetes Engine (GKE). You determined that the source of the issue is a recently updated container image, although the exact change in code was not identified. The deployment is currently pointing to the latest tag. You need to update your cluster to run a version of the container that functions as intended. What should you do?

**A.** Create a new tag called stable that points to the previously working container, and change the deployment to point to the new tag.

**B.** Alter the deployment to point to the sha256 digest of the previously working container.

**C.** Build a new container from a previous Git tag, and do a rolling update on the deployment to the new container.

**D.** Apply the latest tag to the previous container image, and do a rolling update on the deployment.

**Respuesta de la fuente:** B

**Explicación:** Container image tags like 'latest' are mutable references that can change to point to different underlying images, making them unreliable for ensuring a specific state.
Using the immutable SHA256 digest guarantees that the deployment pulls the exact previously working container image, regardless of future tag updates or registry changes.

## Pregunta 143

Contexto: [topics:104](#topics-104)
You need to create a Cloud Monitoring SLO for a service that will be published soon. You want to verify that requests to the service will be addressed in fewer than 300 ms at least 90% of the time per calendar month. You need to identify the metric and evaluation method to use. What should you do?

**A.** Select a latency metric for a request-based method of evaluation.

**B.** Select a latency metric for a window-based method of evaluation.

**C.** Select an availability metric for a request-based method of evaluation.

**D.** Select an availability metric for a window-based method of evaluation.

**Respuesta de la fuente:** A

**Explicación:** The requirement to ensure requests are addressed within 300 ms is a latency concern, excluding availability metrics (C and D).
Request-based SLOs measure the percentage of successful or fast requests relative to total requests, which directly aligns with the goal of meeting the threshold 'at least 90% of the time' in terms of request count.
Window-based evaluation measures uptime/uptime windows rather than individual request performance ratios, making option A the correct choice.

## Pregunta 144

Contexto: [topics:104](#topics-104)
You have an application that runs on Cloud Run. You want to use live production traffic to test a new version of the application, while you let the quality assurance team perform manual testing. You want to limit the potential impact of any issues while testing the new version, and you must be able to roll back to a previous version of the application if needed. How should you deploy the new version? (Choose two.)

**A.** Deploy the application as a new Cloud Run service.

**B.** Deploy a new Cloud Run revision with a tag and use the --no-traffic option.

**C.** Deploy a new Cloud Run revision without a tag and use the --no-traffic option.

**D.** Deploy the new application version and use the --no-traffic option. Route production traffic to the revision’s URL.

**E.** Deploy the new application version, and split traffic to the new version.

**Respuesta de la fuente:** B, D

**Explicación:** No conservada en esta captura.

## Pregunta 145

Contexto: [topics:104](#topics-104)
You recently noticed that one of your services has exceeded the error budget for the current rolling window period. Your company's product team is about to launch a new feature. You want to follow Site Reliability Engineering (SRE) practices. What should you do?

**A.** Notify the team about the lack of error budget and ensure that all their tests are successful so the launch will not further risk the error budget

**B.** Notify the team that their error budget is used up. Negotiate with the team for a launch freeze or tolerate a slightly worse user experience.

**C.** Escalate the situation and request additional error budget.

**D.** Look through other metrics related to the product and find SLOs with remaining error budget. Reallocate the error budgets and allow the feature launch.

**Respuesta de la fuente:** B

**Explicación:** According to standard SRE error budget policies, when a service exceeds its error budget, all non-critical changes and releases must be halted (a launch freeze) to prioritize reliability over new features. This aligns with option B, which advocates for freezing the launch to prevent further risk, whereas reallocating budgets (D) or arbitrarily requesting more budget (C) violates the contract defined by SLOs.

## Pregunta 146

Contexto: [topics:104](#topics-104)
You need to introduce postmortems into your organization. You want to ensure that the postmortem process is well received. What should you do? (Choose two.)

**A.** Encourage new employees to conduct postmortems to team through practice.

**B.** Create a designated team that is responsible for conducting all postmortems.

**C.** Encourage your senior leadership to acknowledge and participate in postmortems.

**D.** Ensure that writing effective postmortems is a rewarded and celebrated practice.

**E.** Provide your organization with a forum to critique previous postmortems.

**Respuesta de la fuente:** C, D

**Explicación:** Senior leadership participation (C) signals that the organization values transparency and continuous improvement, which is critical for establishing a blameless culture. Rewarding effective postmortems (D) creates positive incentives that encourage engagement rather than resentment, ensuring the process is well-received by staff.

## Pregunta 147

Contexto: [topics:104](#topics-104)
You need to enforce several constraint templates across your Google Kubernetes Engine (GKE) clusters. The constraints include policy parameters, such as restricting the Kubernetes API. You must ensure that the policy parameters are stored in a GitHub repository and automatically applied when changes occur. What should you do?

**A.** Set up a GitHub action to trigger Cloud Build when there is a parameter change. In Cloud Build, run a gcloud CLI command to apply the change.

**B.** When there is a change in GitHub. use a web hook to send a request to Anthos Service Mesh, and apply the change.

**C.** Configure Anthos Config Management with the GitHub repository. When there is a change in the repository, use Anthos Config Management to apply the change.

**D.** Configure Config Connector with the GitHub repository. When there is a change in the repository, use Config Connector to apply the change.

**Respuesta de la fuente:** C

**Explicación:** Anthos Config Management is the designated tool for declaratively managing Kubernetes configurations and enforcing policy constraints via OPA Gatekeeper (Policy Controller) across GKE clusters.
It natively supports synchronization from version control systems like GitHub, ensuring that changes to constraint templates are automatically detected and applied to maintain compliance.

## Pregunta 148

Contexto: [topics:104](#topics-104)
You are the Operations Lead for an ongoing incident with one of your services. The service usually runs at around 70% capacity. You notice that one node is returning 5xx errors for all requests. There has also been a noticeable increase in support cases from customers. You need to remove the offending node from the load balancer pool so that you can isolate and investigate the node. You want to follow Google-recommended practices to manage the incident and reduce the impact on users. What should you do?

**A.** 1. Communicate your intent to the incident team.
2. Perform a load analysis to determine if the remaining nodes can handle the increase in traffic offloaded from the removed node, and scale appropriately.
3. When any new nodes report healthy, drain traffic from the unhealthy node, and remove the unhealthy node from service.

**B.** 1. Communicate your intent to the incident team.
2. Add a new node to the pool, and wait for the new node to report as healthy.
3. When traffic is being served on the new node, drain traffic from the unhealthy node, and remove the old node from service.

**C.** 1. Drain traffic from the unhealthy node and remove the node from service.
2. Monitor traffic to ensure that the error is resolved and that the other nodes in the pool are handling the traffic appropriately.
3. Scale the pool as necessary to handle the new load.
4. Communicate your actions to the incident team.

**D.** 1. Drain traffic from the unhealthy node and remove the old node from service.
2. Add a new node to the pool, wait for the new node to report as healthy, and then serve traffic to the new node.
3. Monitor traffic to ensure that the pool is healthy and is handling traffic appropriately.
4. Communicate your actions to the incident team.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud incident management best practices prioritize communication to the incident team as the first step to maintain situational awareness.
Since the service runs at 70% capacity, removing one node may push remaining nodes beyond safe limits; therefore, performing a load analysis to determine if scaling is needed before draining traffic ensures stability and prevents cascading failures.
Option A correctly sequences communication, assessment/scaling, and then isolation of the unhealthy node.

## Pregunta 149

Contexto: [topics:104](#topics-104)
You are configuring your CI/CD pipeline natively on Google Cloud. You want builds in a pre-production Google Kubernetes Engine (GKE) environment to be automatically load-tested before being promoted to the production GKE environment. You need to ensure that only builds that have passed this test are deployed to production. You want to follow Google-recommended practices. How should you configure this pipeline with Binary Authorization?

**A.** Create an attestation for the builds that pass the load test by requiring the lead quality assurance engineer to sign the attestation by using their personal private key.

**B.** Create an attestation for the builds that pass the load test by using a private key stored in Cloud Key Management Service (Cloud KMS) with a service account JSON key stored as a Kubernetes Secret.

**C.** Create an attestation for the builds that pass the load test by using a private key stored in Cloud Key Management Service (Cloud KMS) authenticated through Workload Identity.

**D.** Create an attestation for the builds that pass the load test by requiring the lead quality assurance engineer to sign the attestation by using a key stored in Cloud Key Management Service (Cloud KMS).

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google recommends using Workload Identity to authenticate workloads running in GKE to other Google Cloud services like Cloud KMS. This approach eliminates the need for managing and storing long-lived service account keys (as in Option B) or relying on manual human intervention (as in Options A and D), ensuring a secure, automated, and native CI/CD pipeline.

## Pregunta 150

Contexto: [topics:104](#topics-104)
You are deploying an application to Cloud Run. The application requires a password to start. Your organization requires that all passwords are rotated every 24 hours, and your application must have the latest password. You need to deploy the application with no downtime. What should you do?

**A.** Store the password in Secret Manager and send the secret to the application by using environment variables.

**B.** Store the password in Secret Manager and mount the secret as a volume within the application.

**C.** Use Cloud Build to add your password into the application container at build time. Ensure that Artifact Registry is secured from public access.

**D.** Store the password directly in the code. Use Cloud Build to rebuild and deploy the application each time the password changes.

**Respuesta de la fuente:** B

**Explicación:** Mounting secrets as volumes is the recommended method for frequent rotation because Cloud Run fetches the latest secret value from Secret Manager every time the file is read.
In contrast, environment variables are resolved only at container startup, meaning instances would hold stale passwords until they restart or are replaced.
Using volumes ensures the application always accesses the current password without requiring a deployment or restart.

## Pregunta 151

Contexto: [topics:104](#topics-104)
Your company runs applications in Google Kubernetes Engine (GKE) that are deployed following a GitOps methodology. Application developers frequently create cloud resources to support their applications. You want to give developers the ability to manage infrastructure as code, while ensuring that you follow Google-recommended practices. You need to ensure that infrastructure as code reconciles periodically to avoid configuration drift. What should you do?

**A.** Install and configure Config Connector in Google Kubernetes Engine (GKE).

**B.** Configure Cloud Build with a Terraform builder to execute terraform plan and terraform apply commands.

**C.** Create a Pod resource with a Terraform docker image to execute terraform plan and terraform apply commands.

**D.** Create a Job resource with a Terraform docker image to execute terraform plan and terraform apply commands.

**Respuesta de la fuente:** A

**Explicación:** Config Connector is the Google-recommended solution for managing GCP resources via GitOps in GKE, as it uses Kubernetes controllers to continuously reconcile the actual cloud infrastructure with the desired state defined in manifests.
This continuous reconciliation process directly prevents configuration drift by ensuring that any out-of-band changes are automatically corrected to match the declared intent.

## Pregunta 152

Contexto: [topics:104](#topics-104)
You are designing a system with three different environments: development, quality assurance (QA), and production. Each environment will be deployed with Terraform and has a Google Kubernetes Engine (GKE) cluster created so that application teams can deploy their applications. Anthos Config Management will be used and templated to deploy infrastructure level resources in each GKE cluster. All users (for example, infrastructure operators and application owners) will use GitOps. How should you structure your source control repositories for both Infrastructure as Code (IaC) and application code?

**A.** • Cloud Infrastructure (Terraform) repository is shared: different directories are different environments
• GKE Infrastructure (Anthos Config Management Kustomize manifests) repository is shared: different overlay directories are different environments
• Application (app source code) repositories are separated: different branches are different features

**B.** • Cloud Infrastructure (Terraform) repository is shared: different directories are different environments
• GKE Infrastructure (Anthos Config Management Kustomize manifests) repositories are separated: different branches are different environments
• Application (app source code) repositories are separated: different branches are different features

**C.** • Cloud Infrastructure (Terraform) repository is shared: different branches are different environments
• GKE Infrastructure (Anthos Config Management Kustomize manifests) repository is shared: different overlay directories are different environments
• Application (app source code) repository is shared: different directories are different features

**D.** • Cloud Infrastructure (Terraform) repositories are separated: different branches are different environments
• GKE Infrastructure (Anthos Config Management Kustomize manifests) repositories are separated: different overlay directories are different environments
• Application (app source code) repositories are separated: different branches are different

**Respuesta de la fuente:** A

**Explicación:** Google Cloud GitOps best practices recommend using folder structures to differentiate environments (variants) in both Terraform and Anthos Config Management, rather than branching, to ensure configuration differences are explicit and visible.
For application source code, separate repositories with feature branches follow standard development workflows, keeping IaC state management distinct from frequent code changes.

## Pregunta 153

Contexto: [topics:104](#topics-104)
You are configuring Cloud Logging for a new application that runs on a Compute Engine instance with a public IP address. A user-managed service account is attached to the instance. You confirmed that the necessary agents are running on the instance but you cannot see any log entries from the instance in Cloud Logging. You want to resolve the issue by following Google-recommended practices. What should you do?

**A.** Export the service account key and configure the agents to use the key.

**B.** Update the instance to use the default Compute Engine service account.

**C.** Add the Logs Writer role to the service account.

**D.** Enable Private Google Access on the subnet that the instance is in.

**Respuesta de la fuente:** C

**Explicación:** The logging agent on the Compute Engine instance uses the attached service account to authenticate with Cloud Logging. Since logs are not appearing, the service account likely lacks the necessary IAM permissions. Adding the Logs Writer role grants the specific permission required to write log entries while adhering to least-privilege principles.

## Pregunta 154

Contexto: [topics:104](#topics-104)
As a Site Reliability Engineer, you support an application written in Go that runs on Google Kubernetes Engine (GKE) in production. After releasing a new version of the application, you notice the application runs for about 15 minutes and then restarts. You decide to add Cloud Profiler to your application and now notice that the heap usage grows constantly until the application restarts. What should you do?

**A.** Increase the CPU limit in the application deployment.

**B.** Add high memory compute nodes to the cluster.

**C.** Increase the memory limit in the application deployment.

**D.** Add Cloud Trace to the application, and redeploy.

**Respuesta de la fuente:** C

**Explicación:** The symptoms describe a memory leak causing the container to exceed its resource limits and be terminated (OOMKilled). Increasing the memory limit provides immediate relief by allowing the application more headroom before hitting the ceiling, which is the direct remediation for a resource exhaustion event in Kubernetes. While fixing the code leak is ideal, increasing the limit is the correct infrastructure action among the choices to stop the restarts.

## Pregunta 155

Contexto: [topics:104](#topics-104)
You are deploying a Cloud Build job that deploys Terraform code when a Git branch is updated. While testing, you noticed that the job fails. You see the following error in the build logs:

Initializing the backend...

Error: Failed to get existing workspaces: querying Cloud Storage failed: googleapi: Error 403

You need to resolve the issue by following Google-recommended practices. What should you do?

**A.** Change the Terraform code to use local state.

**B.** Create a storage bucket with the name specified in the Terraform configuration.

**C.** Grant the roles/owner Identity and Access Management (IAM) role to the Cloud Build service account on the project.

**D.** Grant the roles/storage.objectAdmin Identity and Access Management (1AM) role to the Cloud Build service account on the state file bucket.

**Respuesta de la fuente:** D

**Explicación:** The 403 error indicates that the Cloud Build service account lacks permission to access the Cloud Storage backend for Terraform state. To resolve this while adhering to the principle of least privilege, grant the roles/storage.objectAdmin IAM role to the Cloud Build service account on the specific state bucket, rather than using overly broad roles like Owner.

## Pregunta 156

Contexto: [topics:104](#topics-104)
Your company runs applications in Google Kubernetes Engine (GKE). Several applications rely on ephemeral volumes. You noticed some applications were unstable due to the DiskPressure node condition on the worker nodes. You need to identify which Pods are causing the issue, but you do not have execute access to workloads and nodes. What should you do?

**A.** Check the node/ephemeral_storage/used_bytes metric by using Metrics Explorer.

**B.** Check the container/ephemeral_storage/used_bytes metric by using Metrics Explorer.

**C.** Locate all the Pods with emptyDir volumes. Use the df -h command to measure volume disk usage.

**D.** Locate all the Pods with emptyDir volumes. Use the df -sh * command to measure volume disk usage.

**Respuesta de la fuente:** B

**Explicación:** The constraint of not having execute access rules out options C and D, which require running shell commands like `df` on nodes. Between the remaining Metrics Explorer options, the `node/ephemeral_storage/used_bytes` metric (A) only shows aggregate disk usage per node, failing to identify specific offenders. The `container/ephemeral_storage/used_bytes` metric (B) provides granular data on ephemeral storage consumption per container, allowing you to pinpoint exactly which Pods are causing the DiskPressure condition.

## Pregunta 157

Contexto: [topics:104](#topics-104)
You are designing a new Google Cloud organization for a client. Your client is concerned with the risks associated with long-lived credentials created in Google Cloud. You need to design a solution to completely eliminate the risks associated with the use of JSON service account keys while minimizing operational overhead. What should you do?

**A.** Apply the constraints/iam.disableServiceAccountKevCreation constraint to the organization.

**B.** Use custom versions of predefined roles to exclude all iam.serviceAccountKeys.* service account role permissions.

**C.** Apply the constraints/iam.disableServiceAccountKeyUpload constraint to the organization.

**D.** Grant the roles/iam.serviceAccountKeyAdmin IAM role to organization administrators only.

**Respuesta de la fuente:** A

**Explicación:** The `constraints/iam.disableServiceAccountKeyCreation` organization policy constraint prevents the creation of user-managed long-lived service account keys (JSON files) across the specified scope. This directly addresses the risk of long-lived credentials while minimizing operational overhead by enforcing the restriction centrally without requiring custom role modifications or manual key deletion.

## Pregunta 158

Contexto: [topics:104](#topics-104)
You are designing a deployment technique for your applications on Google Cloud. As part of your deployment planning, you want to use live traffic to gather performance metrics for new versions of your applications. You need to test against the full production load before your applications are launched. What should you do?

**A.** Use A/B testing with blue/green deployment.

**B.** Use canary testing with continuous deployment.

**C.** Use canary testing with rolling updates deployment.

**D.** Use shadow testing with continuous deployment.

**Respuesta de la fuente:** D

**Explicación:** Shadow testing involves routing a duplicate copy of live production traffic to the new version without affecting end-user responses, allowing you to test against the full production load safely. This method gathers performance metrics on real-world data while ensuring zero impact on the actual user experience, unlike canary or A/B testing which route real users to the new version.

## Pregunta 159

Contexto: [topics:104](#topics-104)
Your Cloud Run application writes unstructured logs as text strings to Cloud Logging. You want to convert the unstructured logs to JSON-based structured logs. What should you do?

**A.** Modify the application to use Cloud Logging software development kit (SDK), and send log entries with a jsonPayload field.

**B.** Install a Fluent Bit sidecar container, and use a JSON parser.

**C.** Install the log agent in the Cloud Run container image, and use the log agent to forward logs to Cloud Logging.

**D.** Configure the log agent to convert log text payload to JSON payload.

**Respuesta de la fuente:** A

**Explicación:** Cloud Run captures stdout/stderr automatically, so installing agents (Options C and D) is unnecessary and often unsupported. Option B adds architectural complexity that isn't required for standard logging. The correct approach is to modify the application code to emit structured JSON logs directly via the Cloud Logging SDK, ensuring the data is natively structured at the source.

## Pregunta 160

Contexto: [topics:104](#topics-104)
Your company is planning a large marketing event for an online retailer during the holiday shopping season. You are expecting your web application to receive a large volume of traffic in a short period. You need to prepare your application for potential failures during the event. What should you do? (Choose two.)

**A.** Configure Anthos Service Mesh on the application to identify issues on the topology map.

**B.** Ensure that relevant system metrics are being captured with Cloud Monitoring, and create alerts at levels of interest.

**C.** Review your increased capacity requirements and plan for the required quota management.

**D.** Monitor latency of your services for average percentile latency.

**E.** Create alerts in Cloud Monitoring for all common failures that your application experiences.

**Respuesta de la fuente:** B, C

**Explicación:** To prevent failures during high traffic, you must ensure sufficient resource availability by reviewing capacity and adjusting quotas (C). Additionally, proactively monitoring system metrics with configured alerts (B) allows for immediate detection and response to anomalies before they cause outages.

## Pregunta 161

Contexto: [topics:104](#topics-104)
Your company recently migrated to Google Cloud. You need to design a fast, reliable, and repeatable solution for your company to provision new projects and basic resources in Google Cloud. What should you do?

**A.** Use the Google Cloud console to create projects.

**B.** Write a script by using the gcloud CLI that passes the appropriate parameters from the request. Save the script in a Git repository.

**C.** Write a Terraform module and save it in your source control repository. Copy and run the terraform apply command to create the new project.

**D.** Use the Terraform repositories from the Cloud Foundation Toolkit. Apply the code with appropriate parameters to create the Google Cloud project and related resources.

**Respuesta de la fuente:** D

**Explicación:** The requirement for a fast, reliable, and repeatable solution points to Infrastructure as Code (IaC).
While generic Terraform (Option C) offers repeatability, the Cloud Foundation Toolkit (CFT) in Option D provides pre-built, opinionated modules that enforce Google Cloud best practices for project structure, networking, and security.
This reduces development time and ensures consistency across environments better than custom scripts or manual console actions.

## Pregunta 162

Contexto: [topics:104](#topics-104)
You are configuring a CI pipeline. The build step for your CI pipeline integration testing requires access to APIs inside your private VPC network. Your security team requires that you do not expose API traffic publicly. You need to implement a solution that minimizes management overhead. What should you do?

**A.** Use Cloud Build private pools to connect to the private VPC.

**B.** Use Spinnaker for Google Cloud to connect to the private VPC.

**C.** Use Cloud Build as a pipeline runner. Configure Internal HTTP(S) Load Balancing for API access.

**D.** Use Cloud Build as a pipeline runner. Configure External HTTP(S) Load Balancing with a Google Cloud Armor policy for API access.

**Respuesta de la fuente:** A

**Explicación:** Cloud Build private pools run build steps in dedicated workers located within your VPC, providing direct network access to private resources like internal APIs.

This solution eliminates the need for public exposure of traffic, satisfying security requirements while maintaining a fully managed service that minimizes infrastructure overhead compared to self-hosted runners or complex load balancer configurations.

## Pregunta 163

Contexto: [topics:104](#topics-104)
You are leading a DevOps project for your organization. The DevOps team is responsible for managing the service infrastructure and being on-call for incidents. The Software Development team is responsible for writing, submitting, and reviewing code. Neither team has any published SLOs. You want to design a new joint-ownership model for a service between the DevOps team and the Software Development team. Which responsibilities should be assigned to each team in the new joint-ownership model?

**A.** [Imagen: sin descripción]
Imagen · choices[0].text · sin descripción
![Imagen original](imagenes/697efd640666d15d8b6c.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
DevOps team responsibilities ‘Software Development team responsibilities
* Manage the service infrastructure
* Be on-call for incidents
+ Perform code reviews
+ Submit code to be reviewed by the DevOps team
+ Publish the SLOs that the DevOps team must meet
```

**B.** [Imagen: sin descripción]
Imagen · choices[1].text · sin descripción
![Imagen original](imagenes/53ffd92848bf3bcda98d.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
vOps team responsibilities Software Development team responsibilities
| + Submit code to be reviewed by the DevOps team
+ Be on-call for incidents
+ Publish the SLOs that the DevOps team must meet
+ Manage the serviee infrastructure
«+ Perform code reviews
```

**C.** [Imagen: sin descripción]
Imagen · choices[2].text · sin descripción
![Imagen original](imagenes/b9b027cf2892db3d7046.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Ops tak hared responsibilities fee Deatoparent Soame
‘esponsibilities responsibilities
+ Perform code reviews:
+ Be on-call for incidents on a
rotation basis * Submit code to be reviewed
« Adopt and publish SLOs for
the service
+ Manage the service
infrastructure
```

**D.** [Imagen: sin descripción]
Imagen · choices[3].text · sin descripción
![Imagen original](imagenes/04c6898e37a970435479.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
Software Development team
hared responsibilities responsibilities
‘+ Perform code reviews
Mai ths service: + Be on-call for incidents on a
en rotation basis + Submit code to be reviewed
fkastodure: + Adopt and publish SLOs for
the service
```

**Respuesta de la fuente:** C

**Explicación:** The correct answer is C because it best reflects the principles of a joint-ownership DevOps model by assigning infrastructure management to Ops while establishing shared accountability for reliability and code quality. Specifically, it places 'adoption and publication of SLOs' under shared responsibilities, bridging the gap between development velocity and operational stability, whereas other options may silo these critical functions. This structure ensures that both teams are invested in service level objectives rather than leaving them undefined or assigned to only one group.

## Pregunta 164

Contexto: [topics:104](#topics-104)
You recently migrated an ecommerce application to Google Cloud. You now need to prepare the application for the upcoming peak traffic season. You want to follow Google-recommended practices. What should you do first to prepare for the busy season?

**A.** Migrate the application to Cloud Run, and use autoscaling.

**B.** Create a Terraform configuration for the application's underlying infrastructure to quickly deploy to additional regions.

**C.** Load test the application to profile its performance for scaling.

**D.** Pre-provision the additional compute power that was used last season, and expect growth.

**Respuesta de la fuente:** C

**Explicación:** Google-recommended practices emphasize data-driven decision-making for capacity planning.
Load testing simulates peak traffic to identify performance bottlenecks and determine the optimal scaling thresholds before configuring auto-scaling policies or migrating architectures.
This ensures that any subsequent changes, such as moving to Cloud Run or adjusting resources, are based on actual application behavior rather than assumptions.

## Pregunta 165

Contexto: [topics:104](#topics-104)
You are monitoring a service that uses n2-standard-2 Compute Engine instances that serve large files. Users have reported that downloads are slow. Your Cloud Monitoring dashboard shows that your VMs are running at peak network throughput. You want to improve the network throughput performance. What should you do?

**A.** Add additional network interface controllers (NICs) to your VMs.

**B.** Deploy a Cloud NAT gateway and attach the gateway to the subnet of the VMs.

**C.** Change the machine type for your VMs to n2-standard-8.

**D.** Deploy the Ops Agent to export additional monitoring metrics.

**Respuesta de la fuente:** C

**Explicación:** In Google Cloud, network throughput limits for General Purpose machines like the n2-series are directly tied to the number of vCPUs.
The n2-standard-2 instance has a lower maximum egress bandwidth compared to the n2-standard-8.
Upgrading to n2-standard-8 increases the available vCPUs, thereby raising the network throughput ceiling and resolving the bottleneck.

## Pregunta 166

Contexto: [topics:104](#topics-104)
Your organization is starting to containerize with Google Cloud. You need a fully managed storage solution for container images and Helm charts. You need to identify a storage solution that has native integration into existing Google Cloud services, including Google Kubernetes Engine (GKE), Cloud Run, VPC Service Controls, and Identity and Access Management (IAM). What should you do?

**A.** Use Docker to configure a Cloud Storage driver pointed at the bucket owned by your organization.

**B.** Configure an open source container registry server to run in GKE with a restrictive role-based access control (RBAC) configuration.

**C.** Configure Artifact Registry as an OCI-based container registry for both Helm charts and container images.

**D.** Configure Container Registry as an OCI-based container registry for container images.

**Respuesta de la fuente:** C

**Explicación:** Artifact Registry is the fully managed Google Cloud service designed to store both OCI-based container images and Helm charts, satisfying the specific requirement for a unified solution.

Option D (Container Registry) is deprecated and does not support Helm charts, while options A and B involve self-managed infrastructure that lacks native integration with GKE, Cloud Run, VPC Service Controls, and IAM.

## Pregunta 167

Contexto: [topics:104](#topics-104)
You need to define SLOs for a high-traffic web application. Customers are currently happy with the application performance and availability. Based on current measurement, the 90th percentile of latency is 160 ms and the 95th percentile of latency is 300 ms over a 28-day window. What latency SLO should you publish?

**A.** 90th percentile - 150 ms
95th percentile - 290 ms

**B.** 90th percentile - 160 ms
95th percentile - 300 ms

**C.** 90th percentile - 190 ms
95th percentile - 330 ms

**D.** 90th percentile - 300 ms
95th percentile - 450 ms

**Respuesta de la fuente:** C

**Explicación:** SLOs must be set slightly below current performance metrics to create a meaningful error budget.
Setting the SLO equal to or higher than current measurements (Options B and C) provides no buffer for normal variance or incidents, violating the principle of leaving room for improvement.
Option A is too aggressive relative to the measured 90th/95th percentiles, likely causing immediate breach, while Option D is overly relaxed.
The correct approach in this context aligns with standard SRE practices where the SLO represents a target slightly easier than current peak performance but strictly better than the baseline, however, among the choices, B is technically the 'current state' which is often used as a baseline before tightening, but standard exam logic for 'what should you publish' when customers are happy usually implies locking in that good performance. Wait, let's re-evaluate based on SRE best practices.

Actually, re-reading the question: Customers are *happy*. The 95th is 300ms. If we set SLO at 300ms (B), any slight degradation breaches it. If we set it at 330ms (C), we have a buffer. Standard SRE advice (e.g., Google SRE Book) is to set SLOs based on user tolerance, not just current stats. However, if users are happy with the current 28-day window, the SLO should reflect that satisfaction with a safety margin. Setting it *higher* (slower latency allowed) than current best metrics provides that margin. Therefore, C is the intended answer to allow for an error budget.

## Pregunta 168

Contexto: [topics:104](#topics-104)
Your company runs applications in Google Kubernetes Engine (GKE). Application developers frequently create cloud resources to support their applications. You need to give developers the ability to manage infrastructure as code while adhering to Google-recommended practices. You want to manage infrastructure as code through Kubernetes Custom Resource Definitions (CRDs) and ensure that your chosen setup can be supported by the Google Cloud Support Portal. What should you do?

**A.** Configure Cloud Build with a Terraform builder to execute the terraform plan and terraform apply commands.

**B.** Install and configure Crossplane in GKE.

**C.** Configure a GitHub Action with a Terraform builder to execute the terraform plan and terraform apply commands as part of the pull request process.

**D.** Install and configure Config Connector in GKE.

**Respuesta de la fuente:** D

**Explicación:** Config Connector is the Google-recommended solution for managing Google Cloud resources using Kubernetes Custom Resource Definitions (CRDs).
It enables developers to provision infrastructure via native Kubernetes objects, ensuring seamless integration with GKE.
Unlike third-party tools like Crossplane or Terraform pipelines, Config Connector is fully supported by the Google Cloud Support Portal.

## Pregunta 169

Contexto: [topics:104](#topics-104)
Your company runs services on Google Cloud. Each team runs their applications in a dedicated project. New teams and projects are created regularly. Your security team requires that all logs are processed by a security information and event management (SIEM) system. The SIEM ingests logs by using Pub/Sub. You must ensure that all existing and future logs are scanned by the SIEM. What should you do?

**A.** Create an organization-level aggregated sink with a siem log bucket as the destination. Set an inclusion filter to include all logs.

**B.** Create a folder-level aggregated sink with a siem Pub/Sub topic as the destination. Set an inclusion filter to include all logs. Repeat for each folder.

**C.** Create an organization-level aggregated sink with a siem Pub/Sub topic as the destination. Set an inclusion filter to include all logs.

**D.** Create a project-level logging sink with a siem Pub/Sub topic as the destination. Set an inclusion filter to include all logs. Repeat for each project.

**Respuesta de la fuente:** C

**Explicación:** An organization-level aggregated sink captures logs from all current and future projects automatically, satisfying the requirement to cover new teams without manual intervention. The SIEM specifically ingests via Pub/Sub, making a Pub/Sub topic the correct destination rather than a log bucket. This approach avoids the operational overhead of configuring individual project-level or folder-level sinks.

## Pregunta 170

Contexto: [topics:104](#topics-104)
Your company allows teams to self-manage Google Cloud projects, including project-level Identity and Access Management (IAM). You are concerned that the team responsible for the Shared VPC project might accidentally delete the project, so a lien has been placed on the project. You need to design a solution to restrict Shared VPC project deletion to those with the resourcemanager.projects.updateLiens permission at the organization level. What should you do?

**A.** Instruct teams to only perform IAM permission management as code with Terraform.

**B.** Enable VPC Service Controls for the container.googleapis.com API service.

**C.** Revoke the resourcemanager.projects.updateLiens permission from all users associated with the project.

**D.** Enable the compute.restrictXpnProjectLienRemoval organization policy constraint.

**Respuesta de la fuente:** D

**Explicación:** The compute.restrictXpnProjectLienRemoval organization policy constraint specifically controls who can remove liens on Shared VPC host projects, preventing unauthorized deletion. By enabling this constraint, you ensure that only principals with the resourcemanager.projects.updateLiens permission at the organization level can remove the lien and subsequently delete the project.

## Pregunta 171

Contexto: [topics:104](#topics-104)
Your company runs an ecommerce business. The application responsible for payment processing has structured JSON logging with the following schema:

[Imagen: sin descripción]

Capture and access of logs from the payment processing application is mandatory for operations, but the jsonPayload.user_email field contains personally identifiable information (PII). Your security team does not want the entire engineering team to have access to PII. You need to stop exposing PII to the engineering team and restrict access to security team members only. What should you do?
Imagen · question_text · sin descripción
![Imagen original](imagenes/274c5921622d95286082.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
LogName
4	1	2	1	2	0	39	60	105	13	-1	
5	1	2	1	2	1	39	60	105	13	96.349190	resource
httpReques
4	1	2	1	4	0	39	106	143	17	-1	
5	1	2	1	4	1	39	106	143	17	83.483444	jsonPayload
“user_email"
method : 2.4,
code : ...,
jy
```

**A.** Apply the conditional role binding resource.name.extract("locations/global/buckets/{bucket}/") == "_Default" to the _Default bucket.

**B.** Apply a jsonPayload.user_email restricted field to the _Default bucket. Grant the Log Field Accessor role to the security team members.

**C.** Apply a jsonPayload.user_email exclusion filter to the _Default bucket.

**D.** Modify the application to toggle inclusion of user_email when the LOG_USER_EMAIL environment variable is set to true. Restrict the engineering team members who can change the production environment variable by using the CODEOWNERS file.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Google Cloud Logging supports Field Level Access Control (Field ACL), which allows specific log fields to be restricted.
By applying a restriction to the `jsonPayload.user_email` field, only users with the Logs Viewer role plus the Restricted Log Fields Permission can access that specific PII data.
The engineering team retains access to general logs, while security team members granted the appropriate permissions can view the sensitive field.

## Pregunta 172

Contexto: [topics:104](#topics-104)
Your organization is running multiple Google Kubernetes Engine (GKE) clusters in a project. You need to design a highly-available solution to collect and query both domain-specific workload metrics and GKE default metrics across all clusters, while minimizing operational overhead. What should you do?

**A.** Use Prometheus operator to install Prometheus in every cluster and scrape the metrics. Configure remote-write to one central Prometheus. Query the central Prometheus instance.

**B.** Enable managed collection on every GKE cluster. Query the metrics in BigQuery.

**C.** Use Prometheus operator to install Prometheus in every cluster and scrape the metrics. Ensure that a Thanos sidecar is enabled on every Prometheus instance. Configure Thanos in the central cluster. Query the central Thanos instance.

**D.** Enable managed collection on every GKE cluster. Query the metrics in Cloud Monitoring.

**Respuesta de la fuente:** D

**Explicación:** The requirement to minimize operational overhead points directly to managed services rather than self-hosted solutions like Prometheus or Thanos. GKE Managed Prom integration automatically collects default metrics and allows for domain-specific workload metrics via custom configuration, forwarding them all to Cloud Monitoring. Querying these metrics in Cloud Monitoring provides a highly available, centralized interface without the need to manage storage, scaling, or high availability for the monitoring infrastructure itself.

## Pregunta 173

Contexto: [topics:104](#topics-104)
Your company stores a large volume of infrequently used data in Cloud Storage. The projects in your company's CustomerService folder access Cloud Storage frequently, but store very little data. You want to enable Data Access audit logging across the company to identify data usage patterns. You need to exclude the CustomerService folder projects from Data Access audit logging. What should you do?

**A.** Enable Data Access audit logging for Cloud Storage at the organization level, and configure exempted principals to include users of the CustomerService folder.

**B.** Enable Data Access audit logging for Cloud Storage at the organization level, with no additional configuration.

**C.** Enable Data Access audit logging for Cloud Storage for all projects and folders other than the CustomerService folder.

**D.** Enable Data Access audit logging for Cloud Storage for all projects and folders, and configure exempted principals to include users of the CustomerService folder.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 174

Contexto: [topics:104](#topics-104)
You have an application running in production on Cloud Run. Your team recently finished developing a new version (revision B) of the application. You want to test the new revision on 10% of your clients by using the least amount of effort. What should you do?

**A.** Deploy the new revision to the existing service without traffic allocated. Tag the revision and share the URL with 10% of your clients.

**B.** Create a new service, and deploy the new revisions on the new service. Deploy a new revision of the old application where the application routes a percentage of the traffic to the new service.

**C.** Create a new service, and deploy the new revision on that new service. Create a load balancer to split the traffic between the old service and the new service.

**D.** Deploy the new revision to the existing service without traffic allocated. Split the traffic between the old revision and the new revision.

**Respuesta de la fuente:** D

**Explicación:** Cloud Run natively supports traffic splitting between revisions within a single service, allowing you to direct a specific percentage (e.g., 10%) of traffic to the new revision instantly. This approach requires only a single deployment command and avoids the overhead of creating additional services or configuring external load balancers.

## Pregunta 175

Contexto: [topics:104](#topics-104)
You are designing a new multi-tenant Google Kubernetes Engine (GKE) cluster for a customer. Your customer is concerned with the risks associated with long-lived credentials use. The customer requires that each GKE workload has the minimum Identity and Access Management (IAM) permissions set following the principle of least privilege (PoLP). You need to design an IAM impersonation solution while following Google-recommended practices. What should you do?

**A.** 1. Create a Google service account.
2. Create a node pool, and set the Google service account as the default identity.
3. Ensure that workloads can only run on the designated node pool by using node selectors, taints, and tolerations.
4. Repeat for each workload.

**B.** 1. Create a Google service account.
2. Create a node pool without taints, and set the Google service account as the default identity.
3. Grant IAM permissions to the Google service account.

**C.** 1. Create a Google service account.
2. Create a Kubernetes service account in a Workload Identity-enabled cluster.
3. Link the Google service account with the Kubernetes service account by using the roles/iam.workloadIdentityUser role and iam.gke.io/gcp-service-account annotation.
4. Map the Kubernetes service account to the workload.
5. Repeat for each workload.

**D.** 1. Create a Google service account.
2. Create a service account key for the Google service account.
3. Create a Kubernetes secret with a service account key.
4. Ensure that workload mounts the secret and set the GOOGLE_APPLICATION_CREDENTIALS environment variable to point at the mount path.
5. Repeat for each workload.

**Respuesta de la fuente:** C

**Explicación:** Option C implements Workload Identity, which is the Google-recommended practice for mapping Kubernetes service accounts to Google Cloud service accounts without using long-lived credentials. This approach eliminates the security risks of storing and rotating service account keys while enabling fine-grained, per-workload IAM permissions aligned with the principle of least privilege.

## Pregunta 176

Contexto: [topics:104](#topics-104)
You are configuring a Cl pipeline in Cloud Build When you test the pipeline, the following cloudbuild.yaml definition results in 5 minutes each on the foo step and bar step

[Imagen: sin descripción]

The foo step and bar step are independent of each other. The baz step needs both the foo and bar steps to be completed before starting. You want to use parallelism to reduce build times What should you do?
Imagen · question_text · sin descripción
![Imagen original](imagenes/68cf2c408abeaacf6987.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
steps:
- name: foo
id: foo
- name: bar
id: bar
- name: baz
id: baz
```

**A.** Modify the build script to add -
options:
machineType: 'E2_HIGHCPU_8'

**B.** Modify the build script to add -
options:
machineType: 'E2_HIGHCPU_32'

**C.** Change the build script to:
[Imagen: sin descripción]
Imagen · choices[2].text · sin descripción
![Imagen original](imagenes/4b187b7afa7e46166760.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
steps
= name: foo
id: foo
waitFor: ["-"]
- name: bar
id: bar
- name: baz
id: baz:
waitFor:
foo
~ bar
```

**D.** Change the build script to:
[Imagen: sin descripción]
Imagen · choices[3].text · sin descripción
![Imagen original](imagenes/36645fd224228b51dbe2.png)
OCR: automatic_unverified · Revisión visual pendiente.
```text
steps:
~ name:
foo
id: foo
waitFor: [*-"]
- name: bar
id: bar
waitFor: [*="]
- name: baz
id: baz:
waitFor:
- foo
- bar
```

**Respuesta de la fuente:** D

**Explicación:** Cloud Build executes steps sequentially by default. To run independent steps (foo and bar) in parallel, you must specify their dependencies explicitly using the 'needs' field for the dependent step (baz). Setting 'baz' to need both 'foo' and 'bar' allows 'foo' and 'bar' to start immediately without waiting for each other, thereby reducing total build time. Changing machine types does not enable parallel execution of separate steps.

## Pregunta 177

Contexto: [topics:104](#topics-104)
You receive a Cloud Monitoring alert indicating potential malicious activity on a node in your Google Kubernetes Engine (GKE) cluster. The alert suggests a possible compromised container running on that node. You need to isolate this node to prevent further compromise while investigating the issue. You also want to minimize disruption to applications running on the cluster. What should you do?

**A.** Taint the suspicious node to prevent Pods that have interacted with it from being scheduled on other nodes in the cluster

**B.** Scale down the deployment associated with the compromised container to zero other nodes

**C.** Restart the node to disrupt the malicious activity, and force all Pods to be restructured on other nodes.

**D.** Cordon the node to prevent new Pods from being scheduled, the drain the node to safely remove existing Pods and reschedule them to other nodes.

**Respuesta de la fuente:** D

**Explicación:** Cordoning the node marks it as unschedulable, preventing new Pods from being assigned to the potentially compromised instance.
Draining the node then gracefully evicts existing Pods, allowing Kubernetes to reschedule them on healthy nodes.
This approach isolates the threat while maintaining application availability with minimal disruption.

## Pregunta 178

Contexto: [topics:104](#topics-104)
Your company has an application deployed on Google Kubernetes Engine (GKE) consisting of 12 microservices. Multiple teams are working concurrently on various features across three envi-ronments: Dev, Staging, and Prod. Developers report dependency test failures and delayed re-leases due to deployments from multiple feature branches in the shared Dev GKE cluster.

You need to implement a cost-effective solution for developers to test their microservice features in a stable development environment isolated from other development activities. What should you do?

**A.** Automate CI pipelines by using Cloud Build for container image creation and Kubernetes manifest updates from main branch merge requests. Integrate with Config Sync to test new im-ages in dynamically created namespaces on the Dev GKE cluster with autoscaling enabled. Im-plement a post-test namespace cleanup routine.

**B.** Automate CI pipelines by using Cloud Build to create container images and update Kuber-netes manifests for each commit. Use Cloud Deploy for progressive delivery to Dev, Staging, and Prod GKE clusters. Enable Config Sync for consistent Kubernetes configurations across en-vironments.

**C.** Use Cloud Build to automate CI pipelines and update Kubernetes manifest files from feature branch commits. Integrate with Config Sync to test new images in dynamically created namespaces on the Dev GKE cluster with autoscaling enabled. Implement a post-test namespace cleanup routine.

**D.** Use Cloud Build to automate CI pipelines and update Kubernetes manifest files from feature branch commits. Integrate with Config Sync to test new images in dynamically created GKE Dev clusters for each feature branch, which are deleted upon merge request.

**Respuesta de la fuente:** C

**Explicación:** Option C addresses the need for isolation by testing from feature branch commits in dynamically created namespaces within the shared Dev cluster. This approach is cost-effective compared to creating full clusters (Option D) and solves the concurrency conflicts described, whereas Option A restricts testing to the main branch, defeating the purpose of early feature validation.

## Pregunta 179

Contexto: [topics:104](#topics-104)
You are troubleshooting a failed deployment in your CI/CD pipeline. The deployment logs indicate that the application container failed to start due to a missing environment variable. You need to identify the root cause and implement a solution within your CI/CD workflow to prevent this issue from recurring. What should you do?

**A.** Use a canary deployment strategy.

**B.** Implement static code analysis in the CI pipeline.

**C.** Run integration tests in the CI pipeline.

**D.** Enable Cloud Audit Logs for the deployment.

**Respuesta de la fuente:** C

**Explicación:** Integration tests validate application behavior within an environment that mimics production configurations, including required environment variables.
By running these tests in the CI pipeline, missing variables are detected before deployment, preventing runtime failures.

## Pregunta 180

Contexto: [topics:104](#topics-104)
You work for a company that offers a free photo processing application. You are designing the infrastructure for the backend service that processes the photos. The service:
•	Uses Cloud Storage to store both unprocessed and processed photos.
•	Can resume processing photos in the event of a failure.
•	Is not suitable for containerization.

There is no SLO for the time taken to process a photo. You need to choose the most cost-effective solution for running the service. What should you do?

**A.** Deploy the service by using Cloud Run.

**B.** Deploy the service by using standard VMs with a 3-year committed use discount.

**C.** Deploy the service by using GKE.

**D.** Deploy the service by using Spot VMs.

**Respuesta de la fuente:** D

**Explicación:** Spot VMs are the most cost-effective option because they utilize unused compute capacity at significantly lower prices than standard VMs.

Since the service can resume processing after a failure and has no strict latency SLO, it is fault-tolerant enough to handle the preemption risks associated with Spot instances.

## Pregunta 181

Contexto: [topics:104](#topics-104)
You manage a critical API running on Cloud Run that serves an average of 10,000 requests per minute. You need to define service level objectives (SLOs) for availability and latency to ensure that the API meets user expectations, which include 99.9% availability and a maximum latency of 200 milliseconds for 95% of requests. You also need to ensure these SLOs are actively monitored and measured. What should you do?

**A.** Configure Cloud Monitoring to send alerts when average API latency exceeds 150 ms or the error rate surpasses 0.1%.

**B.** Prioritize latency as the only SLO, targeting 100 ms for 99% of requests.

**C.** Set SLOs for 99% availability at 99% and 500 ms latency for 90% of requests. Use Cloud Monitoring to track SLOs and alert on violations.

**D.** Set SLOs for the API by using availability and latency service level indicators. Use Cloud Monitoring to track SLOs and alert on violations.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it aligns with SRE best practices by defining Service Level Indicators (SLIs) for the specified metrics (availability and latency) to form the SLOs.
It also correctly identifies Cloud Monitoring as the tool to track these SLIs and configure alerts on violations, ensuring active measurement.

## Pregunta 182

Contexto: [topics:104](#topics-104)
You are running a web application that connects to an AlloyDB cluster by using a private IP address in your default VPC. You need to run a database schema migration in your CI/CD pipeline by using Cloud Build before deploying a new version of your application. You want to follow Google-recommended security practices. What should you do?

**A.** Set up a Cloud Build private pool to access the database through a static external IP address. Configure the database to only allow connections from this IP address. Execute the schema migration script in the private pool.

**B.** Create a service account that has permission to access the database. Configure Cloud Build to use this service account and execute the schema migration script in a private pool.

**C.** Add the database username and password to Secret Manager. When running the schema migration script, retrieve the username and password from Secret Manager.

**D.** Add the database username and encrypted password to the application configuration file. Use these credentials in Cloud Build to execute the schema migration script.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 183

Contexto: [topics:104](#topics-104)
You use Artifact Registry to store container images built with Cloud Build. You need to ensure that all existing and new images are continuously scanned for vulnerabilities. You also want to track who pushed each image to the registry. What should you do?

**A.** Configure Artifact Registry to automatically scan new images and periodically re-scan all images. Use Cloud Audit Logs to track image uploads and identify the user who pushed each image.

**B.** Configure Artifact Registry to send vulnerability scan results to a Cloud Storage bucket. Use a separate script to parse results and notify a security team.

**C.** Configure Artifact Registry to automatically re-scan images daily. Enable Cloud Audit Logs to track these scans, and use Logs Explorer to identify vulnerabilities.

**D.** Configure Artifact Registry to automatically trigger vulnerability scans for new image tags, and view scan results. Use Cloud Audit Logs to track image tag creation events.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Artifact Registry's vulnerability scanning can be configured to automatically scan new images upon push and periodically re-scan existing ones, fulfilling the continuous scanning requirement for all images. Additionally, Cloud Audit Logs record administrative activities, including `storage.objects.create` events, which allow you to identify the specific user or service account that pushed each image.

## Pregunta 184

Contexto: [topics:104](#topics-104)
You manage a retail website for your company. The website consists of several microservices running in a GKE Standard node pool with node autoscaling enabled. Each microservice has resource limits and a Horizontal Pod Autoscaler configured. During a busy period, you receive alerts for one of the microservices. When you check the Pods, half of them have the status OOMKilled, and the number of Pods is at the minimum autoscaling limit. You need to resolve the issue. What should you do?

**A.** Update the node pool to use a machine type with more memory.

**B.** Increase the maximum number of nodes in the node pool.

**C.** Increase the maximum replica limit of the Horizontal Pod Autoscaler.

**D.** Increase the memory resource limit of the microservice.

**Respuesta de la fuente:** D

**Explicación:** The pods are being OOMKilled because they exceed their configured memory limits.
Since the replica count is already at the minimum, scaling out is not the issue; rather, the individual pod resource constraints are too low for the workload's actual memory requirements.
Increasing the memory limit allows the application to function within its allocated resources without being terminated.

## Pregunta 185

Contexto: [topics:104](#topics-104)
You are configuring a Cl pipeline. The build step for your Cl pipeline integration testing requires access to APIs inside your private VPC network. Your security team requires that you do not expose API traffic publicly. You need to implement a solution that minimizes management overhead. What should you do?

**A.** Use Cloud Build private pools to connect to the private VPC.

**B.** Use Cloud Build to create a Compute Engine instance in the private VPC. Run the integration tests on the VM by using a startup script.

**C.** Use Cloud Build as a pipeline runner. Configure a cross-region internal Application Load Balancer for API access.

**D.** Use Cloud Build as a pipeline runner. Configure a global external Application Load Balancer with a Google Cloud Armor policy for API access.

**Respuesta de la fuente:** A

**Explicación:** Cloud Build Private Pools allow build steps to run within a private VPC network, providing direct access to internal APIs without exposing traffic publicly. This solution minimizes management overhead compared to manually provisioning and maintaining Compute Engine instances.

## Pregunta 186

Contexto: [topics:104](#topics-104)
You are deploying a new version of your application to a multi-zone Google Kubernetes Engine (GKE) cluster. The deployment is progressing smoothly, but you notice that some Pods in a specific zone are experiencing higher error rates. You need to selectively roll back the update for the Pods experiencing errors with minimal impact to users. What should you do?

**A.** Scale down the Pods in the affected zone. Redeploy the new version of the application.

**B.** Drain the affected nodes. Redeploy the new version of the application to the remaining nodes.

**C.** Modify the Deployment to use the Pod template from the previous version of your application. Perform a rolling update to replace the Pods in the affected zone.

**D.** Use the kubectl rollout undo command to roll back the entire deployment. Redeploy the new version of the application, excluding the affected zone.

**Respuesta de la fuente:** C

**Explicación:** The correct approach is to modify the Deployment manifest to reference the previous ReplicaSet (previous revision), which initiates a controlled rolling update. This method selectively replaces only the failing Pods with the known-good configuration while maintaining overall service availability, avoiding the disruption caused by scaling down or draining nodes.

## Pregunta 187

Contexto: [topics:104](#topics-104)
You work for a healthcare company and regulations require you to create all resources in a United States-based region. You attempted to create a secret in Secret Manager but received the following error message:

Constraint constraints/gcp.resourceLocations violated for [orgpolicy:projects/000000] attempting to create a secret in [global]

You need to resolve the error while remaining compliant with regulations. What should you do?

**A.** Remove the organization policy referenced in the error message.

**B.** Create the secret with an automatic replication policy.

**C.** Create the secret with a user-managed replication policy.

**D.** Add the global region to the organization policy referenced in the error message.

**Respuesta de la fuente:** C

**Explicación:** The error occurs because the secret was attempted to be created with automatic replication in the 'global' location, which violates the organization policy restricting resources to US regions.

By selecting a user-managed replication policy, you explicitly define specific regions (e.g., us-central1) where the secret's replicas are stored.

This ensures the resource remains compliant with the regulatory requirement to exist only in United States-based locations while satisfying the constraint.

## Pregunta 188

Contexto: [topics:104](#topics-104)
You are responsible for creating development environments for your company's development team. You want to create environments with identical IDEs for all developers while ensuring that these environments are not exposed to public networks. You need to choose the most cost-effective solution without impacting developer productivity. What should you do?

**A.** Create multiple Compute Engine VM instances with a public IP address and use a Public NAT gateway. Configure an instance schedule to shut down the VMs.

**B.** Create multiple Compute Engine VM instances without a public IP address. Configure an instance schedule to shut down the VMs.

**C.** Create a Cloud Workstations private cluster. Create a workstation configuration with an idieTimeour parameter.

**D.** Create a Cloud Workstations private cluster. Create a workstation configuration with a runningTimeout parameter.

**Respuesta de la fuente:** C

**Explicación:** Cloud Workstations are the ideal service for creating identical, managed development environments. Using a private cluster ensures the environments are not exposed to public networks, satisfying the security requirement.
The idleTimeout parameter is the correct choice because it shuts down workstations only when they are inactive, which minimizes costs while preventing disruption to active developers, whereas runningTimeout could force shutdowns during active work, impacting productivity.

## Pregunta 189

Contexto: [topics:104](#topics-104)
Your company uses Cloud Deploy with multiple delivery pipelines for deploying applications to different environments. Your development team currently lacks access to any of these pipelines. You need to grant the team access to only the development delivery pipeline, while following Google-recommended practices. What should you do?

**A.** In the Google Cloud console, grant the development team the roles/clouddeploy.operator role. Add deny conditions to all pipelines other than the development delivery pipeline.

**B.** In the Google Cloud console, create a custom IAM role with all clouddeploy.automations.* permissions and an allow policy for only the development delivery pipeline. Grant this IAM role to the development team.

**C.** Grant the development team the roles/clouddeploy.operator role in a policy file. Apply the policy file to the development target.

**D.** Grant the development team the roles/clouddeploy.developer role in a policy file. Apply this policy file to the development delivery pipeline.

**Respuesta de la fuente:** D

**Explicación:** The roles/clouddeploy.developer predefined role provides the necessary permissions for developers to manage and deploy within a specific delivery pipeline.
Applying this role directly to the development delivery pipeline resource ensures the principle of least privilege by restricting access only to that specific environment, rather than granting broader operator permissions.

## Pregunta 190

Contexto: [topics:104](#topics-104)
Your company has recently experienced several production service issues. You need to create a Cloud Monitoring dashboard to troubleshoot the issues, and you want to use the dashboard to distinguish between failures in your own service and those caused by a Google Cloud service that you use. What should you do?

**A.** Create a log-based metric to track cloud service errors, and display the metric on the dashboard.

**B.** Create a logs widget to display system errors from Cloud Logging on the dashboard.

**C.** Create an alerting policy for the system error metrics.

**D.** Enable Personalized Service Health annotations on the dashboard.

**Respuesta de la fuente:** D

**Explicación:** Personalized Service Health annotations overlay the status of underlying Google Cloud services onto your monitoring dashboard. This feature explicitly highlights periods when Google service issues occur, allowing you to quickly distinguish between failures caused by your own application logic and those resulting from platform-level outages.

## Pregunta 191

Contexto: [topics:104](#topics-104)
Your company wants to implement a CD pipeline in Cloud Deploy for a web service deployed to GKE. The web service currently does not have any automated testing. The Quality Assurance team must manually verify any new releases of the web service before any production traffic is processed. You need to design the CD pipeline. What should you do?

**A.** Create a single pipeline stage, and use a standard deployment strategy.

**B.** Create a single pipeline stage, and use a canary deployment strategy.

**C.** Create two pipeline stages, and use a canary deployment strategy.

**D.** Create two pipeline stages, and use a standard deployment strategy.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 192

Contexto: [topics:104](#topics-104)
You manage your company’s primary revenue-generating application. You have an error budget policy in place that freezes production deployments when the application is close to breaching its SLO. A number of issues have recently occurred, and the application has exhausted its error budget. You need to deploy a new release to the application that includes a feature urgently required by your largest customer. You have been told that the release has passed all unit tests. What should you do?

**A.** Delay the deployment of the feature until the error budget is replenished.

**B.** Re-run the unit tests, and start the deployment of the feature if the tests pass.

**C.** Start the deployment of the feature immediately.

**D.** Deploy the feature to a subset of users, and gradually roll out to all users if there are no errors reported.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 193

Contexto: [topics:104](#topics-104)
You work for a company that manages highly sensitive user data. You are designing the Google Kubernetes Engine (GKE) infrastructure for your company, including several applications that will be deployed in development and production environments. Your design must protect data from unauthorized access from other applications, while minimizing the amount of management overhead required. What should you do?

**A.** Create one cluster for the organization with separate namespaces for each application and environment combination.

**B.** Create one cluster for each application with separate namespaces for production and development environments.

**C.** Create one cluster for each environment (development and production) with each application in its own namespace within each cluster.

**D.** Create one cluster for the organization with separate namespaces for each application.

**Respuesta de la fuente:** C

**Explicación:** Separating clusters by environment (development vs. production) isolates sensitive production data from less secure development workloads, satisfying the security requirement without the excessive overhead of per-application clustering.
Using namespaces within each cluster provides logical isolation between applications while keeping resource management and networking simpler than managing multiple independent clusters.

## Pregunta 194

Contexto: [topics:104](#topics-104)
You are developing a Node.js utility on a workstation in Cloud Workstations by using Code OSS. The utility is a simple web page, and you have already confirmed that all necessary firewall rules are in place. You tested the application by starting it on port 3000 on your workstation in Cloud Workstations, but you need to be able to access the web page from your local machine. You need to follow Google-recommended security practices. What should you do?

**A.** Use a browser running on a bastion host VM.

**B.** Run the gcloud compute start-iap-tunnel command to the Cloud Workstations VM.

**C.** Allow public IP addresses in the Cloud Workstations configuration.

**D.** Click the preview link in the Code OSS panel.

**Respuesta de la fuente:** D

**Explicación:** The Google-recommended practice for accessing web applications running in Cloud Workstations is to use the built-in preview feature in Code OSS.
This method provides a secure, authenticated tunnel via Identity-Aware Proxy (IAP) without exposing public IPs or requiring manual tunnel configuration.
Options involving bastion hosts, manual IAP tunnels, or public IPs either bypass native IDE integration or violate security best practices by increasing the attack surface.

## Pregunta 195

Contexto: [topics:104](#topics-104)
Your team is preparing to launch a new API in Cloud Run. The API uses an OpenTelemetry agent to send distributed tracing data to Cloud Trace to monitor the time each request takes. The team has noticed inconsistent trace collection. You need to resolve the issue. What should you do?

**A.** Use an HTTP health check.

**B.** Configure CPU to be always-allocated.

**C.** Increase the CPU limit in Cloud Run from 2 to 4.

**D.** Configure CPU to be allocated only during request processing.

**Respuesta de la fuente:** B

**Explicación:** By default, Cloud Run suspends CPU allocation when no requests are being processed, which can interrupt background tasks like the OpenTelemetry agent flushing trace data to Cloud Trace.
Enabling always-on CPU allocation ensures the agent has continuous processing power to reliably send distributed tracing data, resolving the inconsistent collection issue.

## Pregunta 196

Contexto: [topics:104](#topics-104)
You are deploying a new application on Google Kubernetes Engine (GKE) that processes personally identifiable information (PII). You need to configure Cloud Logging to collect logs from your application while ensuring that sensitive user information is not exposed. What should you do?

**A.** Implement log sampling to reduce the volume of logs collected.

**B.** Configure Cloud Data Loss Prevention to scan logs in real-time and redact PII before it's stored in Cloud Logging.

**C.** Disable Cloud Logging for the application to prevent sensitive data from being logged.

**D.** Store all logs in an encrypted Cloud Storage bucket with restricted access.

**Respuesta de la fuente:** B

**Explicación:** Cloud Data Loss Prevention (DLP) is the specialized Google Cloud service designed to detect and redact sensitive information like PII from data streams. By configuring DLP with Cloud Logging sinks, you can automatically sanitize logs at ingestion time, ensuring that personally identifiable information is removed before being stored or analyzed. Other options either reduce log volume without addressing privacy (A), eliminate necessary observability (C), or store the sensitive data securely but still expose it within the logs (D).

## Pregunta 197

Contexto: [topics:104](#topics-104)
You recently created a Cloud Build pipeline for deploying Terraform code stored in a GitHub repository. You make Terraform code changes in short-lived branches and sometimes use tags during development. You tag releases with a semantic version when they are ready for deployment. You require your pipeline to apply the Terraform code whenever there is a new release, and you need to minimize operational overhead. What should you do?

**A.** Create a build trigger with the \d+\.\d+\.\d+ tag pattern.

**B.** Create a build trigger with the \d+\.\d+\.\d+ branch pattern.

**C.** Create a build trigger with the .* tag pattern.

**D.** Create a build trigger with the .* branch pattern.

**Respuesta de la fuente:** A

**Explicación:** The requirement specifies triggering deployments only for new releases identified by semantic version tags (e.g., 1.2.3). The regular expression \d+\.\d+\.\d+ accurately matches this specific numeric format. Using this pattern on a tag trigger ensures the pipeline runs exclusively for valid release tags, ignoring other branches or non-versioned tags to minimize unnecessary operational overhead.

## Pregunta 198

Contexto: [topics:104](#topics-104)
You manage a microservice that provides a public-facing API (Service A). Service A is time-critical and has a response SLO of 500 ms. Service A makes synchronous calls to internal API (Service B) that is known to become unreliable under heavy load, resulting in connection timeout errors or 500 errors. Service B is used to collect request information for the transactions processed by Service A. You need to mitigate the impact of Service B issues on your Service A users. What should you do?

**A.** Increase the size of the queue in front of the thread pool used by Service A instances.

**B.** Implement retry logic with exponential back-offs when calling Service B.

**C.** Implement a circuit breaker to store the request data in a database.

**D.** Implement rate limiting in Service A to limit the number of requests to Service B.

**Respuesta de la fuente:** C

**Explicación:** A circuit breaker pattern prevents Service A from wasting time waiting for unresponsive calls to Service B, thereby protecting the 500 ms response SLO.
Storing request data in a database serves as a graceful degradation strategy, ensuring transaction information is preserved even when Service B fails.

## Pregunta 199

Contexto: [topics:104](#topics-104)
Your company is migrating its production systems to Google Cloud. You need to implement site reliability engineering (SRE) practices during the migration to minimize customer impact from potential future incidents. Which two SRE practices should you implement? (Choose two.)

**A.** Create up-to-date playbooks with instructions for debugging and mitigating issues.

**B.** Ensure that all teams can modify the production environment to resolve issues.

**C.** Create an alerting mechanism for your SRE team based on your system's internal behavior.

**D.** Automate common tasks to analyze key impact information and intelligently suggest mitigating actions for the on-call team.

**E.** Ensure that full autonomy and permissions are only granted to the on-call team.

**Respuesta de la fuente:** A, D

**Explicación:** SRE practices focus on reducing toil and minimizing the impact of incidents through preparation and automation. Playbooks provide clear, up-to-date instructions for debugging and mitigation, significantly reducing Mean Time To Recovery (MTTR) during outages. Automating common analysis tasks and suggesting mitigations further reduces manual effort and accelerates incident resolution, aligning with the core SRE goal of maintaining reliability with minimal human intervention.

## Pregunta 200

Contexto: [topics:104](#topics-104)
You are deploying a new web application on Cloud Run in your Google Cloud project. You expect traffic to range from 10 requests per second during off-peak hours to 1000 requests per second during peak hours. You want to use autoscaling to efficiently handle the changes in traffic while ensuring that the autoscaler does not exceed your project's resource quotas. What should you do?

**A.** Manually adjust the number of instances based on observed traffic patterns throughout the day.

**B.** Define appropriate resource limits for the Cloud Run service, and ensure your project has sufficient resource quotas to accommodate the desired scaling range.

**C.** Configure the autoscaler to scale based on CPU utilization with a target of 80%.

**D.** Configure the autoscaler to scale based on request count, with a target of 500 requests per instance.

**Respuesta de la fuente:** B

**Explicación:** Cloud Run automatically scales based on incoming request volume, making manual adjustment or custom metric targets (Options A, C, D) unnecessary or misaligned with default behavior.
Option B is correct because setting resource limits ensures each instance has defined boundaries, while verifying project quotas prevents scaling failures when demand peaks, directly addressing the requirement to respect quota constraints.

## Pregunta 201

Contexto: [topics:104](#topics-104)
Your company is actively developing a new web service following site reliability engineering (SRE) practices. You are leading the company's SRE team and preparing the service for production. You must ensure that the team follows Google-recommended SRE practices during this productionalization process. Which two actions should you take next? (Choose two.)

**A.** Establish monitoring and alerting systems.

**B.** Start to document infrastructure system guidelines.

**C.** Collaborate with the product team to design the service.

**D.** Implement redundancy measures.

**E.** Provide early engagement consulting to discuss architecture and design choices in detail.

**Respuesta de la fuente:** A, E

**Explicación:** No conservada en esta captura.

## Pregunta 202

Contexto: [topics:104](#topics-104)
Your company uses a CI/CD pipeline with Cloud Build and Artifact Registry to deploy container images to Google Kubernetes Engine (GKE). Images are tagged with the latest commit hash and promoted to production after successful testing in the development and pre-production environments. A recent production deployment caused the application to fail due to untested integration functionality, requiring a disruptive manual rollback. During the rollback, you noticed many old and unused container images accumulating in Artifact Registry. You need to improve rollout and rollback management and clean up the old container images. What should you do?

**A.** Set up a rollback pipeline in Cloud Build, and implement an Artifact Registry cleanup policy.

**B.** Adopt Cloud Deploy for managing deployments, and implement an Artifact Registry cleanup policy.

**C.** Deploy Cloud Service Mesh across the GKE clusters, and manually clean up Artifact Registry images.

**D.** Adopt Cloud Deploy for managing deployments, and schedule a Cloud Build job for container image cleanup.

**Respuesta de la fuente:** Sin clave explícita

**Explicación:** Cloud Deploy provides native rollout and rollback capabilities for GKE, replacing the manual rollback process mentioned in the scenario. Artifact Registry cleanup policies are the recommended method to automatically manage image retention and remove old, unused images without requiring custom Cloud Build jobs.

## Pregunta 203

Contexto: [topics:104](#topics-104)
Your team has an application built by using a Dockerfile. The build is executed from Cloud Build, and the resulting artifacts are stored in Artifact Registry. Your team is reporting that builds are slow. You need to increase build speed, while following Google-recommended practices. What should you do?

**A.** Use the --cache-from parameter, and point to Artifact Registry. Add the most frequently modified files to the later stages of the build process.

**B.** Use the --cache-from parameter, and point to Artifact Registry. Add the most frequently modified files to the earlier stages of the build process.

**C.** Cache the container layers of the build process to Cloud Storage. Add the most frequently modified files to the earlier stages of the build process.

**D.** Cache the container layers of the build process to Cloud Storage. Add the most frequently modified files to the later stages of the build process.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 204

Contexto: [topics:104](#topics-104)
You use Google Cloud Managed Service for Prometheus with managed collection to gather metrics from your service running on Google Kubernetes Engine (GKE). After deploying the service, there is no metric data appearing in Cloud Monitoring and you have not encountered any error messages. You need to troubleshoot this issue. What should you do?

**A.** Determine if your service has exceeded its quota for writes to the Cloud Monitoring API.

**B.** Verify that your PodMonitoring configuration references a valid port.

**C.** Check if the Grafana service is installed on your GKE cluster.

**D.** Confirm that your service has the monitoring.servicesViewer IAM role.

**Respuesta de la fuente:** B

**Explicación:** Google Cloud Managed Service for Prometheus (GMP) managed collection discovers targets via PodMonitoring or ClusterPodMonitoring resources. If these resources reference an invalid port, the scraping fails silently without generating visible error messages in standard logs, resulting in missing metrics. Verifying the port configuration is the correct troubleshooting step.

## Pregunta 205

Contexto: [topics:104](#topics-104)
You manage applications deployed on Google Kubernetes Engine (GKE) clusters across multiple Google Cloud projects. You require a centralized and scalable solution to collect and query Prometheus metrics from these clusters by using a flexible query language. You want to follow Google-recommended practices. What should you do?

**A.** Install Prometheus server on an admin cluster with cluster autoscaler enabled, and expose the Prometheus endpoint for queries.

**B.** Configure the Ops Agent to collect metrics, and run queries in Metrics Explorer.

**C.** Configure Google Cloud Managed Service for Prometheus with managed collection, and run queries in Metrics Explorer.

**D.** Deploy a Prometheus server as a sidecar to your applications on each cluster, and run queries in Cloud Monitoring.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 206

Contexto: [topics:104](#topics-104)
You have multiple applications running on Google Kubernetes Engine (GKE) and Cloud Run. You plan to use BigQuery as your central log repository. You need to centralize log collection and analysis to gain a comprehensive view of your system’s health and performance, while minimizing configuration complexity and costs. What should you do?

**A.** Configure each application to write logs directly to BigQuery by using the BigQuery API.

**B.** Use Datadog to collect logs from GKE and Cloud Run, then forward the logs to BigQuery.

**C.** Configure Cloud Logging to collect logs from GKE and Cloud Run, and create a sink to export the logs to BigQuery.

**D.** Manually download log files from GKE and Cloud Run, then upload them to BigQuery by using the Google Cloud console.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 207

Contexto: [topics:104](#topics-104)
You are building an ecommerce web application that will be deployed to Google Cloud. You need to periodically test the checkout process in production to ensure its functionality and confirm that you are receiving automated notifications for failures. You also want to minimize administrative effort and follow Google-recommended practices. What should you do?

**A.** Use Workflows to create a workflow verifying the functionality, and trigger the workflow periodically by using Cloud Tasks.

**B.** Implement a Cloud Run function for synthetic monitoring with an alerting policy.

**C.** Create an alerting policy in Cloud Logging to monitor for failed logs during the checkout process.

**D.** Configure an uptime check with an alerting policy.

**Respuesta de la fuente:** B

**Explicación:** The correct answer is B because Cloud Functions provide a serverless, low-maintenance environment for executing synthetic transactions (testing the checkout process) on a schedule. Combining this with an alerting policy ensures automated notifications upon failure, satisfying both functional verification and monitoring requirements while minimizing administrative effort.

## Pregunta 208

Contexto: [topics:104](#topics-104)
Your company is building an AI-powered Java web application. You need to create a secure and managed cloud-based Java integrated development environment (IDE) for your company’s developers. You must ensure that the required GPUs are attached to their development instances, and you want to follow Google-recommended practices. What should you do?

**A.** Create a dedicated Google Cloud project for development with sufficient GPU quota. Grant developers access to use Cloud Shell Editor within the project.

**B.** Use Cloud Workstations to create a dedicated workstation with an attached GPU for each developer. Grant the Cloud Workstations User role to the users.

**C.** Create a separate Google Cloud project with a GPU-equipped VM for each developer, and grant each developer Editor access to their project.

**D.** Deploy a GKE cluster with GPUs attached. Create a namespace for each developer, and grant the namespace access to the corresponding developer.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 209

Contexto: [topics:104](#topics-104)
You are deploying a containerized application to Cloud Run. The application needs a password to connect to the database to fetch data. The password must be rotated each week to meet your company’s security requirements. You need to implement an easy- to-manage password rotation policy. What should you do?

**A.** 1. Deploy the container to Cloud Run.
2. Create a new container each week with the new database password set as an environment variable in a Dockerfile.
3. Deploy the new container to Cloud Run, and migrate the traffic to the new version.

**B.** 1. Create a secret in Secret Manager to hold the password.
2. Deploy the container to Cloud Run, and use the latest version of the secret as an environment variable.
3. Create a new version of the secret with the new password in Secret Manager each week.

**C.** 1. Deploy the container to Cloud Run.
2. Create a new container each week with the new database password set as a secret during the build phase.
3. Deploy the new container to Cloud Run, and migrate the traffic to the new version.

**D.** 1. Create a secret in Secret Manager to hold the password.
2. Deploy the container to Cloud Run, and use the latest version of the secret as a mounted volume.
3. Create a new version of the secret in Secret Manager each week.

**Respuesta de la fuente:** D

**Explicación:** Using Cloud Secret Manager allows for centralized management and easy rotation of secrets without rebuilding container images.
Mounting the secret as a volume (Option D) is preferred over environment variables because it keeps sensitive data out of process environment listings and aligns with security best practices for handling credentials in containers.
Baking passwords into Dockerfiles or build steps (Options A and C) creates immutable secrets that are difficult to rotate and pose significant security risks.

## Pregunta 210

Contexto: [topics:104](#topics-104)
You are responsible for the reliability of a custom-built, distributed file storage service that your company uses internally. This service handles thousands of file uploads and downloads daily. You need to define a service level indicator (SLI) to measure the reliability of your service usage and configure alerts to be notified of potential issues. Which SLI should you use to measure the reliability of the service?

**A.** Average request latency of API calls (e.g., get, put, list)

**B.** Number of successful file uploads and downloads per minute

**C.** Average size of objects stored in your service

**D.** Ratio of successful API calls to the total number of attempted API calls

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 211

Contexto: [topics:104](#topics-104)
You are using Jenkins to orchestrate your CI/CD pipelines deploying your applications to GKE and on-premises VMs. After expanding your on-premises infrastructure, all resource utilization is normal but you notice that initiating on-premises deployments is taking longer than expected. You need to accelerate the initiation of on-premises deployments. What should you do?

**A.** Upgrade your on-premises VMs to have faster CPUs and more memory.

**B.** Implement a blue-green deployment strategy for your on-premises VMs.

**C.** Increase the number of Jenkins executor threads.

**D.** Configure Jenkins to use an artifact repository in your on-premises environment.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 212

Contexto: [topics:104](#topics-104)
You are setting up a CI/CD pipeline to containerize an application. You must ensure that you only push containers to Artifact Registry if there are no critical vulnerabilities. You also want to reduce the effort required to maintain the pipeline. What should you do?

**A.** Create a script using a VM to build and push the container to Artifact Registry. After pushing the container, use automatic scanning in Artifact Analysis to check for critical vulnerabilities. Delete the container if critical vulnerabilities are detected.

**B.** Use Cloud Build to build the container. Use On-Demand Scanning in Artifact Analysis to check for critical vulnerabilities before pushing the image to Artifact Registry.

**C.** Install Jenkins on a VM and create a pipeline to build the container. Use On-Demand Scanning in Artifact Analysis to check for critical vulnerabilities before pushing the container to Artifact Registry.

**D.** Use Cloud Build to build the container. After pushing the container to Artifact Registry, use automatic scanning in Artifact Analysis to check for critical vulnerabilities. Delete the container if critical vulnerabilities are detected.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 213

Contexto: [topics:104](#topics-104)
You have multiple applications exposed on a load balancer, and you are monitoring blocked requests by Google Cloud Armor. You need to create a dashboard to monitor requests for https://mountkirk.com/api only. You want to identify the parameters that are being blocked. What should you do?

**A.** 1. Create a log-based counter metric with filters for configuredAction=ALLOW and requestUrl=~"^https://mountkirk.com/api".
2. Create a dashboard in Cloud Monitoring with the new metric, with an aggregation on matchedFieldName.

**B.** 1. Create a log-based metric with the Boolean metric type with the filter configuredAction=BLOCKED.
2. Create a dashboard in Cloud Monitoring with the new metric, with an aggregation on matchedFieldName.

**C.** 1. Create a log-based counter metric with filters for configuredAction=BLOCKED and requestUrl=~"^https://mountkirk.com/api".
2. Create a dashboard in Cloud Monitoring with the new metric, with an aggregation on matchedFieldName.

**D.** 1. Create a dashboard in Cloud Monitoring by using the networksecurity.googleapis.com metric with the https/request_count type.
2. Filter the blocked parameter as true.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 214

Contexto: [topics:104](#topics-104)
You have an application deployed to Cloud Run. A new version of the application has recently been deployed using the canary deployment strategy. Your Site Reliability Engineering (SRE) teammate informs you that an SLO has been exceeded for this application. You need to make the application healthy as quickly as possible. What should you do first?

**A.** Configure traffic splitting to send 100% of the traffic to the latest revision.

**B.** Configure traffic splitting to send 100% of the traffic to the previous revision.

**C.** Create a new revision using the last known good version of the application.

**D.** Identify the cause of the latency by using Cloud Trace.

**Respuesta de la fuente:** B

**Explicación:** The primary goal is to restore service health as quickly as possible after an SLO violation.
Since the canary deployment introduced instability, immediately reverting traffic to the previous stable revision eliminates the faulty code from the production path.
This rollback action is significantly faster and less risky than diagnosing the issue or deploying a new fix.

## Pregunta 215

Contexto: [topics:104](#topics-104)
Your company is trying to centralize all monitoring and alerting capabilities. Your VPC network has an internally exposed webhook you can call to trigger alerts. You need to integrate your Google Cloud alerts to call this webhook. You want to minimize costs while following Google-recommended practices. What should you do?

**A.** Configure a new Pub/Sub notification channel with a new topic. Create a pull subscription to consume the events.

**B.** Configure a new Pub/Sub notification channel with a new topic. Create a push subscription with the webhook as a subscriber to get the events.

**C.** Configure a new webhook notification channel. Edit your alerting policies to use the new notification channel to propagate the events.

**D.** Configure a new Pub/Sub notification channel with a new topic. Create a new Cloud Run function with direct VPC egress to write the events to the internal endpoint. Create a push subscription with the Cloud Run function as a subscriber to get the events.

**Respuesta de la fuente:** D

**Explicación:** Google Cloud Monitoring notification channels support email, SMS, PagerDuty, Slack, and Opsgenie, but do not natively support generic webhooks. To call an internal webhook, you must use a Pub/Sub push subscription as the integration bridge.
Option D is correct because it uses a serverless Cloud Run function to receive events from Pub/Sub and forward them to the internal endpoint via direct VPC egress, ensuring security and minimizing cost by only incurring charges for actual invocations. Options A, B, and C are incorrect because B requires public access for push subscriptions (which violates internal-only constraints), A uses pull subscriptions which are more complex to manage for this use case, and C is not a valid native configuration.

## Pregunta 216

Contexto: [topics:104](#topics-104)
Your company uses a Google Kubernetes Engine (GKE) cluster for each environment staging and production. You need to configure cluster release channels following Google-recommended practices. You want to maximize cluster stability over availability of the latest features. What should you do?

**A.** Configure the production cluster to use the Stable release channel, and configure the staging cluster to use the Regular release channel.

**B.** Configure the production cluster to use the Extended release channel, and configure the staging cluster to use the Rapid release channel.

**C.** Configure the production cluster to use the Stable release channel, and configure the staging cluster to use the Stable release channel.

**D.** Configure the production cluster to use the Regular release channel, and configure the staging cluster to use the Regular release channel.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 217

Contexto: [topics:104](#topics-104)
You recently created a project to deploy multiple applications on Compute Engine VM instances, across multiple regions.

While you expect the total number of instances will not decrease, you anticipate that you might need to alter the allocation of instances across regions in the future. You want to minimize running costs for this multi-year project. What should you do?

**A.** Create a resource-based committed use discount for a 3-year term.

**B.** Create a compute flexible committed use discount for a 3-year term with reservations.

**C.** Create a compute flexible committed use discount for a 3-year term.

**D.** Create a resource-based committed use discount for a 1-year term.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 218

Contexto: [topics:104](#topics-104)
You are investigating an ongoing anomaly involving a high number of requests. You created a custom dashboard on Cloud Monitoring and identified that the requests are originating by a single type of client. You want to enable your company’s development team to further investigate the issue by using your custom dashboard. You want to follow Google-recommended practices. What should you do?

**A.** Export the custom dashboard as a JSON file and share the file with the development team.

**B.** Export the dashboard time series data in CSV format. Instruct the development team to use BigQuery to analyze the data.

**C.** Grant the development team the roles/monitoringViewer IAM role at the project level and share the custom dashboard URL with the development team.

**D.** Grant the development team the roles/viewer IAM role at the project level and share the custom dashboard URL with the development team.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 219

Contexto: [topics:104](#topics-104)
You have an external application that sends encrypted files to a Cloud Storage bucket. These files are encrypted with an HMAC-SHA256 key, and contain sensitive data that needs to be loaded into BigQuery for analysis every day after midnight. You need to build a secure and automated solution to decrypt these files and load them into BigQuery. You want to follow Google-recommended practices, while minimizing the required development effort. What should you do?

**A.** 1. Import the encryption key into the same Cloud Storage bucket.
2. Create a Cloud Build pipeline that decrypts the file before loading the file into BigQuery.
3. Create a Cloud Scheduler trigger that runs every day at the required time.

**B.** 1. Create a Cloud Key Management Service (Cloud KMS) key ring and import the encryption key.
2. Create an Artifact Registry repository, and push the image containing the script to the Artifact Registry repository.
3. Create a Cloud Run job that executes the image on a schedule.
4. Grant the Cloud Run service agent the Cloud KMS CryptoKey Encrypter/Decrypter role.

**C.** 1. Create a Cloud Key Management Service (Cloud KMS) key ring and import the encryption key.
2. Create a Cloud Build trigger that uses Cloud KMS to decrypt the file before loading the file into BigQuery.
3. Create a Cloud Scheduler trigger that runs every day at the required time.

**D.** 1. Import the encryption key into the same Cloud Storage bucket.
2. Create a script that pulls the key from Cloud Storage and decrypts the file.
3. Create an Artifact Registry repository containerize the script and push the container to the Artifact Registry repository.
4. Create a Cloud Run job that executes on a schedule.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 220

Contexto: [topics:104](#topics-104)
You are onboarding your company’s marketing department to Google Cloud. The marketing department is managing the development, but you want to monitor all spending and be alerted if the marketing budget is exceeded. What should you do?

**A.** Create all Google Cloud projects. Create one budget alert for each project with the total budget split by the number of projects as the limit.

**B.** Create all Google Cloud projects under a new marketing folder. Create one budget alert for each project with the total budget as the limit.

**C.** Create all Google Cloud projects under a new marketing folder. Create one budget alert at folder level with the total budget as the limit.

**D.** Create all the Google Cloud projects. Create one budget alert for each project with the total budget as the limit.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 221

Contexto: [topics:104](#topics-104)
You are establishing a centralized platform to monitor your applications. Your applications are currently running on Kubernetes clusters on-premises and in the cloud across multiple Google Cloud projects. You want to enable developers to monitor both infrastructure and application metrics using OpenTelemetry across on-premises and Google Cloud environments. At the same time, you want to keep the operation easy to support and integrate all metrics into a single place. What should you do?

**A.** Implement a sidecar OpenTelemetry Collector alongside each Pod in all Kubernetes clusters (on-premises and GKE). Configure these collectors to export Prometheus-formatted metrics. Use dedicated Prometheus instances in each Kubernetes cluster and Thanos in a central GKE cluster. Install Grafana on a GKE cluster, and use Grafana to monitor the applications.

**B.** Create a scoping project and add all the Google Cloud projects to it. Use Bindplane to streamline OpenTelemetry metric collection for the on-premises Kubernetes clusters into Cloud Monitoring.

**C.** Create a new Google Cloud project to use as a scoping project and add all the other Google Cloud projects to it. Instrument the applications running on-premises to export the metrics to Cloud Monitoring as user-defined metrics. Use Cloud Monitoring to monitor the applications.

**D.** Enable Google Cloud Managed Service for Prometheus collections by using the OpenTelemetry Collector on the Google Kubernetes Engine (GKE) clusters, and enable non-managed Prometheus for the on-premises Kubernetes clusters. Install Grafana on a GKE cluster, and use Grafana to monitor the applications.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Google Cloud Build Plane (Bindplane) is designed specifically to simplify OpenTelemetry data collection across hybrid environments, including on-premises and multiple GCP projects.
It allows for centralized management of telemetry data ingestion into Cloud Monitoring without requiring complex custom configurations for each cluster or project.

## Pregunta 222

Contexto: [topics:104](#topics-104)
You are investigating slow Apigee responses for API calls to the orders proxy in the Production environment. The proxy uses multiple services running in Google Kubernetes Engine (GKE) with Cloud Service Mesh. You need to determine the root cause of the latency issues without impacting the performance of the other exposed services. What should you do?

**A.** Enable distributed tracing in the Production environment. Use Cloud Trace to check each span, and identify the service causing increased latency.

**B.** Use Cloud Monitoring with the Apigee target latencies metric to identify the service causing increased latency.

**C.** Use Cloud Logging to view the logs from different backends to identify the service causing increased latency.

**D.** Enable distributed tracing on Apigee with the configuration to trace only the orders proxy. Use Cloud Trace to check each span, and identify the service causing increased latency.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 223

Contexto: [topics:104](#topics-104)
Your company has applications running in a private VPC without internet access. There are internal APIs that are only accessible within your VPC network. You need to monitor the availability of these internal APIs with a solution that follows Google-recommended practices to minimize the amount of manual effort and maintenance required. What should you do?

**A.** Deploy the application on a Google Kubernetes Engine (GKE) instance configured with a liveness and readiness probe.

**B.** Configure private uptime checks.

**C.** Create a Cloud Run function with a VPC connector to ping the internal endpoints. Configure public uptime checks against the Cloud Run function.

**D.** Create a synthetic monitor, and use Cloud VPN to access the private endpoints.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 224

Contexto: [topics:104](#topics-104)
You are configuring a Cloud Deploy pipeline to deploy an application to Google Kubernetes Engine (GKE). The application is deployed as a Deployment. You need to configure the Deployment so that there are two replicas in the development environment and five replicas in the production environment. You must ensure that all other configuration parameters are consistent between environments. You also need to minimize developmental overhead when updating the manifests in the future. How should you configure the skaffold.yaml file?

**A.** Create multiple profiles, and configure the manifests.kustomize section.

**B.** Create a single profile, and configure the manifests.kustomize section.

**C.** Create multiple profiles, and configure the manifests.rawYaml section.

**D.** Create a single profile, and configure the manifests.rawYaml section.

**Respuesta de la fuente:** A

**Explicación:** Skaffold profiles allow you to define environment-specific configurations, such as different replica counts for development and production, while keeping the base manifest consistent.
Using Kustomize within Skaffold enables these patches to be applied declaratively without duplicating entire YAML files, thereby minimizing future maintenance overhead.

## Pregunta 225

Contexto: [topics:104](#topics-104)
You are designing a secure Cloud Build pipeline for a web application that requires access to a package manager. The package manager credentials are highly sensitive and need to be protected from unauthorized access. You need to design a solution to securely retrieve credentials at build time following Google-recommended practices. You also want to keep maintenance overhead to a minimum. What should you do?

**A.** Grant the roles/cloudkms.cryptoKeyDecrypter role to the Cloud Build service account. Store Cloud Key Management Service (Cloud KMS) encrypted data in a build config file. Specify the secret under the secrets field.

**B.** Grant the roles/cloudkms.cryptoKeyDecrypter role to the Cloud Build service account. Store Cloud Key Management Service (Cloud KMS) encrypted data in a build config file. Specify the secret under the availableSecrets.inline field.

**C.** Grant the roles/secretmanager.secretAccessor role to the Cloud Build service account used for the build. Specify the secret under the availableSecrets.secretManager field.

**D.** Use base64-encrypted data in a web application’s source control repository. Decrypt and use the secret during the build.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 226

Contexto: [topics:104](#topics-104)
You are working on a Google Cloud project that has been in production for several months, and you need to update an IAM policy to grant additional permissions to a team member. You need to proactively identify any potential risks associated with these IAM policy changes before applying them to the production environment. What should you do?

**A.** Implement the IAM policy changes. Use the recent change recommendations to monitor for any unintended consequences.

**B.** Use the change risk recommendations to assess the potential impact of the IAM policy changes, and identify any associated risks before applying them.

**C.** Grant the new team member the Project Owner role. Reevaluate permissions after their task is complete.

**D.** Use the Cloud deprecation and breaking changes general recommender to assess the impact of the IAM policy changes on any potentially deprecated or soon-to-be-changed services.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 227

Contexto: [topics:104](#topics-104)
Your company is implementing supply chain security controls for its containerized applications running in Google Kubernetes Engine (GKE). You need to be able to trace container images used in production back to their source and build processes. Your solution must follow Google-recommended practices for software supply chain security. What should you do?

**A.** Store all build artifacts in Artifact Registry, and enable automatic vulnerability scanning.

**B.** Enable the Container Analysis API. Configure Cloud Build to use only official base images, and enable automatic vulnerability scanning.

**C.** Use Container-Optimized OS for all GKE node pools, enable Binary Authorization in the GKE cluster, and enable automatic security updates.

**D.** Enable the Container Analysis API. Configure Cloud Build to generate and sign provenance attestations for each build. Configure Binary Authorization to verify the attestations before deployment.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 228

Contexto: [topics:104](#topics-104)
Your team manages a critical service with a 99.9% availability SLO. The error budget for the quarter has been nearly depleted due to several incidents. Your team is planning on releasing new features next week. You need to ensure that you do not exceed the error budget while following Google-recommended practices. What should you do?

**A.** Release the features but implement an automatic rollback if new errors occur.

**B.** Release the features sequentially for each subset of users to minimize potential impact on the SLO.

**C.** Postpone the feature release and focus on reliability improvements until the error budget refreshes.

**D.** Postpone the feature release and focus on building a backlog of features to deploy until the error budget refreshes.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 229

Contexto: [topics:104](#topics-104)
You have a CI/CD pipeline set up in Cloud Build that builds container images. These containers are stored in Artifact Registry. You need to ensure that only images built by the Cloud Build pipeline in your production project are deployed to your Google Kubernetes Engine (GKE) cluster. You want to minimize the amount of manual effort required for implementation and maintenance. What should you do?

**A.** Enable Binary Authorization on the GKE cluster. Create a Cloud Run function triggered by Artifact Registry INSERT events to verify that pushed containers have the projects/PROJECT_ID/attestors/built-by-cloud-build attestor.

**B.** Configure Artifact Registry to only allow the Cloud Build service account to push containers.

**C.** Enable Binary Authorization on the GKE cluster. Create a Cloud Key Management Service (Cloud KMS) keyring and the built-by-cloud-build attestor. After Cloud Build pushes the container, use the key to create an attestation. Update the Binary Authorization policy to require the projects/PROJECT_ID/attestors/built-by-cloud-build attestor.

**D.** Enable Binary Authorization on the GKE cluster. Configure the Binary Authorization policy to require the projects/PROJECT_ID/attestors/built-by-cloud-build attestor.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 230

Contexto: [topics:104](#topics-104)
You are designing a containerized CI pipeline to minimize reliance on public upstream container registries and improve build reproducibility and security. You need to design a pipeline to cache all containerized dependencies while minimizing the required amount of manual effort and maintenance. What should you do?

**A.** 1. Create a remote Docker repository for each upstream registry in Artifact Registry.
2. Access the container images in the CI pipeline through the remote repository.

**B.** 1. Create a standard Docker repository for each upstream registry in Artifact Registry.
2. Upload the containers used in the build pipelines to the appropriate repositories.

**C.** 1. Create a standard Docker repository for each upstream registry in Artifact Registry.
2. Create a central virtual Docker repository to serve the standard repositories.
3. Access the container images in the CI pipeline through the central repository.

**D.** 1. Create a remote Docker repository for each upstream registry in Artifact Registry.
2. Create a central virtual Docker repository to serve the remote repositories.
3. Access the container images in the CI pipeline through the central repository.

**Respuesta de la fuente:** D

**Explicación:** Remote repositories automatically cache content from upstream registries on demand, eliminating the manual upload effort required by standard repositories.
A virtual repository aggregates multiple remote repositories into a single endpoint, simplifying CI pipeline configuration to access any cached image through one URL.
This architecture satisfies the requirements for caching dependencies, improving reproducibility, and minimizing maintenance overhead.

## Pregunta 231

Contexto: [topics:104](#topics-104)
You manage a critical, user-facing application and have configured a service level objective (SLO) in Cloud Monitoring to track 99% availability over a 30-day rolling window. Recently, a series of minor issues have increased latency, causing the error budget to be consumed at an accelerated rate. You need to be proactively notified when the service is at risk of violating its SLO before the error budget is fully depleted. What should you do?

**A.** Configure a log-based metric in Cloud Monitoring that tracks the rate of application error logs. Create an alerting policy on this metric that triggers when the error rate shows a significant anomalous deviation from its historical baseline.

**B.** Create a custom dashboard in Cloud Monitoring that visualizes the SLO compliance percentage and the remaining error budget. Configure the dashboard to send a scheduled daily report through email.

**C.** In Cloud Monitoring, create an alerting policy based on the SLO’s error budget burn rate. Configure the alert to trigger when the current consumption rate is projected to exhaust the budget before the end of the 30-day compliance period.

**D.** In Metrics Explorer, create an alerting policy based on the average request latency for the application’s load balancer. Configure the alert to trigger if latency exceeds a predefined threshold.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 232

Contexto: [topics:104](#topics-104)
You are designing a CI/CD pipeline to deploy a containerized application from your GitHub repository to Artifact Registry. The build process needs to trigger whenever a new tag is created. The build must be approved by the gcp-developers-admins@mountkirk.com Google group. You need to avoid using static credentials or federating with any other system to meet your company’s security requirements. How should you set up the CI/CD pipeline?

**A.** 1. Create a GitHub trigger in Cloud Build to execute a build whenever a new tag is created.
2. Create a Cloud Build approval.
3. Grant the roles/cloudbuild.builds.approver role to the gcp-developers-admins@mountkirk.com Google group, and grant the roles/artifactregistry.writer role to the service account used by the trigger.

**B.** 1. Use GitHub Actions to create a workflow to containerize the application and push the container to Artifact Registry when a new tag is created.
2. Create a GitHub team with the same members as the gcp-developers-admins@mountkirk.com Google group, and add the team as a mandatory approval.
3. On the Google Cloud project, create a service account and a service account key.
4. Use the key on the workflow to authenticate with Google Cloud.
5. Grant the roles/artifactregistry.writer role to the service account.

**C.** 1. Create an SSH key and add it as a deploy key on GitHub.
2. Create a Cloud Build trigger that uses the SSH key to pull the repository.
3. Create a Cloud Build approval.
4. Grant the roles/cloudbuild.builds.editor role to the gcp-developers-admins@mountkirk.com Google group, and grant the roles/artifactregistry.writer role to the service account used by the trigger.

**D.** 1. Use GitHub Actions to create a workflow to containerize the application and push the container to Artifact Registry when a new tag is created.
2. Create a GitHub team with the same members as the gcp-developers-admins@mountkirk.com Google group, and add the team as a mandatory approval.
3. Create a workload identity pool on Google Cloud to authorize the identity of the GitHub workflow.
4. Grant the roles/artifactregistry.writer role to the workload identity pool authorized entity.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 233

Contexto: [topics:104](#topics-104)
You are managing a Google Cloud environment for 20 different business units with 50 production projects and 50 development projects residing directly under the organization node. This flat structure makes it difficult to apply security policies consistently across all production projects and to track the aggregated costs of the production and development environments separately. You need to restructure the resource hierarchy to solve these issues. What should you do?

**A.** Create folders for the production and development environments, and move the projects into these folders.

**B.** Create a folder for each business unit, and move the corresponding projects into these folders.

**C.** Apply labels for each environment to each project to identify the environment.

**D.** Create a common services project for each business unit.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 234

Contexto: [topics:104](#topics-104)
You are managing a complex microservices application running on Google Kubernetes Engine (GKE). You recently instrumented your services with OpenTelemetry to generate traces. During a performance investigation in Cloud Trace, you notice a transaction with high latency. The trace waterfall lacks the detail needed to identify the root cause, but you suspect the issue is within the business logic of the service. This service sends structured logs to Cloud Logging. You need to quickly analyze the logs that correspond to the high-latency request. What should you do?

**A.** In the Cloud Trace waterfall view, identify the trace ID of a slow request. Then, in the Logs Explorer, write a query to filter for log entries that contain that specific trace ID.

**B.** Configure a log-based metric in Cloud Logging to count the occurrences of error messages. Then, create an alerting policy on this metric to be notified of future issues, and analyze the logs associated with those alerts.

**C.** Export all logs from Cloud Logging to BigQuery. Write a SQL query to join the trace data with the log data on the trace ID field, and then filter for the specific transaction to find the related log entries.

**D.** Ensure your application’s logging configuration includes the trace ID from the OpenTelemetry context in each structured log entry. Then, in the Cloud Trace details view for a slow request, click the “Show logs” option to view correlated logs directly alongside the trace’s span waterfall.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 235

Contexto: [topics:104](#topics-104)
You are managing a critical, high-traffic application running on Google Kubernetes Engine (GKE). You are preparing to release a new version of the application with significant changes to its payment processing workflow. You need to implement a deployment strategy that minimizes risk and automatically rolls back if the release proves to be unstable. What should you do?

**A.** Use Cloud Deploy to execute a canary deployment. Configure the delivery pipeline with a multi-phase canary deployment sequence, starting with a 5% traffic split. Define success criteria using application telemetry from Cloud Monitoring, and configure Cloud Deploy to automatically roll back the release if the new version fails verification.

**B.** Configure your GKE deployment manifest to use a blue-green strategy. Deploy the new version as a “green” deployment alongside the existing “blue” deployment. Once the “green” environment is live, update the service selector to gradually switch user traffic to the new version.

**C.** Edit the GKE Service manifest to include a new selector for the v2 pods Then, create a second GKE Deployment for the new version of the application. Slowly scale up the replica count of the new deployment while scaling down the old one to gradually shift traffic.

**D.** Configure the GKE Deployment to use the default rolling update strategy. Monitor logs and metrics in Cloud Monitoring during the update. If an issue is detected, use the kubectl rollout undo command to automatically revert the application to the previous stable version.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 236

Contexto: [topics:104](#topics-104)
Your team manages a high-traffic application that generates several terabytes of logs daily. You need to reduce Cloud Logging costs while retaining critical operational and security information. What should you do?

**A.** Configure exclusion filters for DEBUG logs, and configure export of ERROR logs to BigQuery.

**B.** Halve log retention period for the _Default logging bucket to 15 days.

**C.** Enable sampling for all log levels on the _Default logging bucket.

**D.** Create log-based metrics for key indicators, and configure logging exclusion filters for non- ERROR logs.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 237

Contexto: [topics:104](#topics-104)
You are designing the hosting architecture in Google Kubernetes Engine (GKE) for business-critical applications. These applications provide custom metrics for monitoring with Prometheus. You need to collect the application metrics for alerting and troubleshooting purposes. You want to minimize the amount of manual effort and maintenance required while following Google-recommended practices. What should you do?

**A.** Install Prometheus servers in the GKE clusters. Configure Prometheus to scrape and forward the custom metrics to the Cloud Monitoring API.

**B.** Install the OpenTelemetry collector in the GKE clusters. Configure it to collect and export the custom metrics to Cloud Monitoring.

**C.** Modify each application to use the Cloud Monitoring API to push the custom metrics.

**D.** Configure Google Cloud Managed Service for Prometheus collection in the GKE clusters to collect the custom metrics.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 238

Contexto: [topics:104](#topics-104)
Your company’s primary ecommerce application, running on Google Kubernetes Engine (GKE), is experiencing intermittent periods of high response latency. Users have reported that the checkout process is sometimes very slow. You need to identify the root cause of this performance degradation. What should you do?

**A.** Increase the number of replicas for the application’s GKE deployment and enable Horizontal Pod Autoscaling.

**B.** In Cloud Logging, create a logs-based metric that counts slow requests. Set up a Cloud Monitoring alert to be notified when the count exceeds a certain threshold.

**C.** Review the deployment history in Cloud Deploy, and roll back to a previous version of the application to see if the issue is resolved.

**D.** Use Cloud Trace to analyze the distributed traces of the checkout process. Examine the trace waterfalls to identify which service or operation is introducing the most latency.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 239

Contexto: [topics:104](#topics-104)
You are troubleshooting an issue with an application running in a Google Kubernetes Engine (GKE) cluster with Binary Authorization enabled. You need to run a temporary Pod for troubleshooting purposes by using an unsigned utility container image from Artifact Registry. When you attempt to apply the Pod configuration from a YAML file, the Binary Authorization policy prevents the deployment. You must use the most secure and auditable solution to run the Pod. What should you do?

**A.** Change enforcementMode in the Binary Authorization policy to ALWAYS_ALLOW.

**B.** Add the imaqe-policy.k8s.io/break-glass label to the Pod configuration.

**C.** Temporarily disable Binary Authorization on the GKE cluster.

**D.** Add the container image to the admissionWhitelistPatterns node in the Binary Authorization policy.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.