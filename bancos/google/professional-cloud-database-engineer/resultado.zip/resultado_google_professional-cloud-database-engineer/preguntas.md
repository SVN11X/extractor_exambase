# professional cloud database engineer

197 / 197 preguntas. Cobertura completa: True.

Respuestas de la fuente; revisión técnica pendiente. Las imágenes permanecen en sus campos de origen.

197 respuestas conservadas; 0 pendientes.

<a id="topics-723"></a>
## Contexto topics:723
name:
Topic 1


## Pregunta 1

Contexto: [topics:723](#topics-723)
You are developing a new application on a VM that is on your corporate network. The application will use Java Database Connectivity (JDBC) to connect to Cloud SQL for PostgreSQL. Your Cloud SQL instance is configured with IP address 192.168.3.48, and SSL is disabled. You want to ensure that your application can access your database instance without requiring configuration changes to your database. What should you do?

**A.** Define a connection string using your Google username and password to point to the external (public) IP address of your Cloud SQL instance.

**B.** Define a connection string using a database username and password to point to the internal (private) IP address of your Cloud SQL instance.

**C.** Define a connection string using Cloud SQL Auth proxy configured with a service account to point to the internal (private) IP address of your Cloud SQL instance.

**D.** Define a connection string using Cloud SQL Auth proxy configured with a service account to point to the external (public) IP address of your Cloud SQL instance.

**Respuesta de la fuente:** C

**Explicación:** The Cloud SQL Auth Proxy (Option C) is the correct choice because it provides an encrypted connection to the database using IAM-based authentication, eliminating the need to configure SSL on the instance or manage IP allowlists.

Option B is incorrect because connecting directly via private IP from a non-VPC corporate network requires manual firewall configuration and does not leverage the proxy's built-in security benefits.

## Pregunta 2

Contexto: [topics:723](#topics-723)
Your digital-native business runs its database workloads on Cloud SQL. Your website must be globally accessible 24/7. You need to prepare your Cloud SQL instance for high availability (HA). You want to follow Google-recommended practices. What should you do? (Choose two.)

**A.** Set up manual backups.

**B.** Create a PostgreSQL database on-premises as the HA option.

**C.** Configure single zone availability for automated backups.

**D.** Enable point-in-time recovery.

**E.** Schedule automated backups.

**Respuesta de la fuente:** D, E

**Explicación:** To align with Google-recommended practices for High Availability (HA) and disaster recovery in Cloud SQL, you should enable point-in-time recovery (D) to mitigate accidental data loss or corruption by restoring to any second within the retention period. Additionally, scheduling automated backups (E) ensures continuous protection of your database state without manual intervention. Manual backups (A) are not recommended for HA as they introduce human error and operational overhead, while single-zone configuration (C) fails to meet HA requirements during zone-level failures. On-premises replication (B) contradicts the cloud-native architecture required for seamless Cloud SQL HA integration.

## Pregunta 3

Contexto: [topics:723](#topics-723)
Your company wants to move to Google Cloud. Your current data center is closing in six months. You are running a large, highly transactional Oracle application footprint on VMWare. You need to design a solution with minimal disruption to the current architecture and provide ease of migration to Google Cloud. What should you do?

**A.** Migrate applications and Oracle databases to Google Cloud VMware Engine (VMware Engine).

**B.** Migrate applications and Oracle databases to Compute Engine.

**C.** Migrate applications to Cloud SQL.

**D.** Migrate applications and Oracle databases to Google Kubernetes Engine (GKE).

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Google Cloud VMware Engine (GCVE) enables a 'lift-and-shift' migration, preserving the existing vSphere-based architecture with minimal disruption. This directly addresses the requirement to maintain the current VMWare environment.

Option B (Compute Engine) requires significant re-architecting of virtual machines and handling complex Oracle licensing issues on standard infrastructure, increasing disruption. Options C and D are incorrect because Cloud SQL does not support Oracle databases, and GKE implies a containerization refactoring that contradicts the goal of minimal architectural change.

## Pregunta 4

Contexto: [topics:723](#topics-723)
Your customer has a global chat application that uses a multi-regional Cloud Spanner instance. The application has recently experienced degraded performance after a new version of the application was launched. Your customer asked you for assistance. During initial troubleshooting, you observed high read latency. What should you do?

**A.** Use query parameters to speed up frequently executed queries.

**B.** Change the Cloud Spanner configuration from multi-region to single region.

**C.** Use SQL statements to analyze SPANNER_SYS.READ_STATS* tables.

**D.** Use SQL statements to analyze SPANNER_SYS.QUERY_STATS* tables.

**Respuesta de la fuente:** C

**Explicación:** The issue is specifically high read latency, so you should analyze the SPANNER_SYS.READ_STATS* tables which provide detailed metrics on read operations, including latency and throughput. Option D is incorrect because QUERY_STATS* tables track SQL query execution statistics rather than low-level read operation performance.

## Pregunta 5

Contexto: [topics:723](#topics-723)
Your company has PostgreSQL databases on-premises and on Amazon Web Services (AWS). You are planning multiple database migrations to Cloud SQL in an effort to reduce costs and downtime. You want to follow Google-recommended practices and use Google native data migration tools. You also want to closely monitor the migrations as part of the cutover strategy. What should you do?

**A.** Use Database Migration Service to migrate all databases to Cloud SQL.

**B.** Use Database Migration Service for one-time migrations, and use third-party or partner tools for change data capture (CDC) style migrations.

**C.** Use data replication tools and CDC tools to enable migration.

**D.** Use a combination of Database Migration Service and partner tools to support the data migration strategy.

**Respuesta de la fuente:** A

**Explicación:** The question explicitly requires using Google-native data migration tools. Database Migration Service (DMS) is the native solution that supports both initial data load and continuous Change Data Capture (CDC) for PostgreSQL to Cloud SQL migrations, fulfilling all requirements without third-party dependencies.
Option B is incorrect because DMS natively supports CDC, making separate third-party tools unnecessary and contrary to the 'Google-native' constraint.

## Pregunta 6

Contexto: [topics:723](#topics-723)
You are setting up a Bare Metal Solution environment. You need to update the operating system to the latest version. You need to connect the Bare Metal Solution environment to the internet so you can receive software updates. What should you do?

**A.** Setup a static external IP address in your VPC network.

**B.** Set up bring your own IP (BYOIP) in your VPC.

**C.** Set up a Cloud NAT gateway on the Compute Engine VM.

**D.** Set up Cloud NAT service.

**Respuesta de la fuente:** C

**Explicación:** Google Cloud Bare Metal Solution documentation explicitly recommends setting up a NAT gateway on a Compute Engine VM to provide internet access for software updates, making C the correct answer. Option D is incorrect because managed Cloud NAT does not natively support the specific routing requirements or transitive endpoints needed for Bare Metal instances without the intermediary VM architecture described in option C.

## Pregunta 7

Contexto: [topics:723](#topics-723)
Your organization is running a MySQL workload in Cloud SQL. Suddenly you see a degradation in database performance. You need to identify the root cause of the performance degradation. What should you do?

**A.** Use Logs Explorer to analyze log data.

**B.** Use Cloud Monitoring to monitor CPU, memory, and storage utilization metrics.

**C.** Use Error Reporting to count, analyze, and aggregate the data.

**D.** Use Cloud Debugger to inspect the state of an application.

**Respuesta de la fuente:** B

**Explicación:** Cloud Monitoring provides essential metrics such as CPU utilization, memory usage, and storage I/O that are direct indicators of resource saturation causing performance degradation.
While Logs Explorer can reveal errors, monitoring system-level resources is the primary method for diagnosing general performance bottlenecks in Cloud SQL.

## Pregunta 8

Contexto: [topics:723](#topics-723)
You work for a large retail and ecommerce company that is starting to extend their business globally. Your company plans to migrate to Google Cloud. You want to use platforms that will scale easily, handle transactions with the least amount of latency, and provide a reliable customer experience. You need a storage layer for sales transactions and current inventory levels. You want to retain the same relational schema that your existing platform uses. What should you do?

**A.** Store your data in Firestore in a multi-region location, and place your compute resources in one of the constituent regions.

**B.** Deploy Cloud Spanner using a multi-region instance, and place your compute resources close to the default leader region.

**C.** Build an in-memory cache in Memorystore, and deploy to the specific geographic regions where your application resides.

**D.** Deploy a Bigtable instance with a cluster in one region and a replica cluster in another geographic region.

**Respuesta de la fuente:** B

**Explicación:** Cloud Spanner is the only option that supports both global multi-region deployment and a standard relational schema (SQL), directly satisfying the requirement to retain existing relational structures while scaling globally with low latency.
Firestore and Bigtable are NoSQL databases that do not support native relational schemas, eliminating options A and D.
Memorystore is an in-memory cache suitable for transient data but lacks the persistent, transactional storage required for sales records and inventory levels, ruling out option C.

## Pregunta 9

Contexto: [topics:723](#topics-723)
You host an application in Google Cloud. The application is located in a single region and uses Cloud SQL for transactional data. Most of your users are located in the same time zone and expect the application to be available 7 days a week, from 6 AM to 10 PM. You want to ensure regular maintenance updates to your Cloud SQL instance without creating downtime for your users. What should you do?

**A.** Configure a maintenance window during a period when no users will be on the system. Control the order of update by setting non-production instances to earlier and production instances to later.

**B.** Create your database with one primary node and one read replica in the region.

**C.** Enable maintenance notifications for users, and reschedule maintenance activities to a specific time after notifications have been sent.

**D.** Configure your Cloud SQL instance with high availability enabled.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because configuring a maintenance window allows Google Cloud to perform updates during off-peak hours (outside the 6 AM–10 PM user window), preventing downtime for active users. Option D (High Availability) is incorrect because, while it provides redundancy for failover, it does not eliminate the need for scheduled maintenance windows that may still cause brief disruptions or require careful scheduling; furthermore, HA incurs additional cost and complexity unnecessary when a suitable off-peak window exists.

## Pregunta 10

Contexto: [topics:723](#topics-723)
Your team recently released a new version of a highly consumed application to accommodate additional user traffic. Shortly after the release, you received an alert from your production monitoring team that there is consistently high replication lag between your primary instance and the read replicas of your Cloud SQL for MySQL instances. You need to resolve the replication lag. What should you do?

**A.** Identify and optimize slow running queries, or set parallel replication flags.

**B.** Stop all running queries, and re-create the replicas.

**C.** Edit the primary instance to upgrade to a larger disk, and increase vCPU count.

**D.** Edit the primary instance to add additional memory.

**Respuesta de la fuente:** A

**Explicación:** High replication lag in Cloud SQL for MySQL is primarily caused by the replica falling behind the primary due to heavy write loads or inefficient query execution. Optimizing slow queries reduces the processing time per transaction, while enabling parallel replication allows the replica to apply multiple transactions concurrently, directly addressing the bottleneck.

Options C and D are incorrect because adding resources to the primary instance does not improve the replica's ability to process the binary log; in fact, larger writes might worsen lag. Option B is a drastic measure that causes downtime and data loss risk, reserved only for broken replication states rather than performance tuning.

## Pregunta 11

Contexto: [topics:723](#topics-723)
Your organization operates in a highly regulated industry. Separation of concerns (SoC) and security principle of least privilege (PoLP) are critical. The operations team consists of:
Person A is a database administrator.
Person B is an analyst who generates metric reports.
Application C is responsible for automatic backups.
You need to assign roles to team members for Cloud Spanner. Which roles should you assign?

**A.** roles/spanner.databaseAdmin for Person A
roles/spanner.databaseReader for Person B
roles/spanner.backupWriter for Application C

**B.** roles/spanner.databaseAdmin for Person A
roles/spanner.databaseReader for Person B
roles/spanner.backupAdmin for Application C

**C.** roles/spanner.databaseAdmin for Person A
roles/spanner.databaseUser for Person B
roles/spanner databaseReader for Application C

**D.** roles/spanner.databaseAdmin for Person A
roles/spanner.databaseUser for Person B
roles/spanner.backupWriter for Application C

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it adheres to the Principle of Least Privilege. Person B only needs read access for reports, so `roles/spanner.databaseReader` is appropriate, whereas `databaseUser` (Options C and D) grants write permissions that are unnecessary. For Application C, `roles/spanner.backupWriter` is specifically designed for automated backup creation scripts and prevents deletion or modification, whereas `backupAdmin` (Option B) would grant excessive control to delete backups.

## Pregunta 12

Contexto: [topics:723](#topics-723)
You are designing an augmented reality game for iOS and Android devices. You plan to use Cloud Spanner as the primary backend database for game state storage and player authentication. You want to track in-game rewards that players unlock at every stage of the game. During the testing phase, you discovered that costs are much higher than anticipated, but the query response times are within the SLA. You want to follow Google-recommended practices. You need the database to be performant and highly available while you keep costs low. What should you do?

**A.** Manually scale down the number of nodes after the peak period has passed.

**B.** Use interleaving to co-locate parent and child rows.

**C.** Use the Cloud Spanner query optimizer to determine the most efficient way to execute the SQL query.

**D.** Use granular instance sizing in Cloud Spanner and Autoscaler.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Cloud Spanner costs are primarily driven by provisioned compute capacity (nodes or processing units). Using granular instance sizing allows you to right-size the infrastructure to actual workload demands, while Autoscaler dynamically adjusts this capacity based on usage metrics. This combination ensures high availability and performance without over-provisioning resources during low-traffic periods, directly addressing the cost issue described in the scenario.

## Pregunta 13

Contexto: [topics:723](#topics-723)
You recently launched a new product to the US market. You currently have two Bigtable clusters in one US region to serve all the traffic. Your marketing team is planning an immediate expansion to APAC. You need to roll out the regional expansion while implementing high availability according to Google-recommended practices. What should you do?

**A.** Maintain a target of 23% CPU utilization by locating:
cluster-a in zone us-central1-a
cluster-b in zone europe-west1-d
cluster-c in zone asia-east1-b

**B.** Maintain a target of 23% CPU utilization by locating:
cluster-a in zone us-central1-a
cluster-b in zone us-central1-b
cluster-c in zone us-east1-a

**C.** Maintain a target of 35% CPU utilization by locating:
cluster-a in zone us-central1-a
cluster-b in zone australia-southeast1-a
cluster-c in zone europe-west1-d
cluster-d in zone asia-east1-b

**D.** Maintain a target of 35% CPU utilization by locating:
cluster-a in zone us-central1-a
cluster-b in zone us-central2-a
cluster-c in zone asia-northeast1-b
cluster-d in zone asia-east1-b

**Respuesta de la fuente:** D

**Explicación:** To achieve high availability across the US and APAC regions, you must deploy clusters in both geographic areas; options A and C include Europe, which is outside the scope, while B lacks any APAC presence.
Option D correctly places two clusters in the US (us-central1, us-central2) and two in APAC (asia-northeast1, asia-east1), satisfying the multi-region HA requirement.
Additionally, maintaining a target of 35% CPU utilization is the recommended best practice for Bigtable to ensure headroom for traffic spikes and maintenance operations.

## Pregunta 14

Contexto: [topics:723](#topics-723)
Your ecommerce website captures user clickstream data to analyze customer traffic patterns in real time and support personalization features on your website. You plan to analyze this data using big data tools. You need a low-latency solution that can store 8 TB of data and can scale to millions of read and write requests per second. What should you do?

**A.** Write your data into Bigtable and use Dataproc and the Apache Hbase libraries for analysis.

**B.** Deploy a Cloud SQL environment with read replicas for improved performance. Use Datastream to export data to Cloud Storage and analyze with Dataproc and the Cloud Storage connector.

**C.** Use Memorystore to handle your low-latency requirements and for real-time analytics.

**D.** Stream your data into BigQuery and use Dataproc and the BigQuery Storage API to analyze large volumes of data.

**Respuesta de la fuente:** A

**Explicación:** Google Bigtable is a fully managed, scalable NoSQL database designed specifically for low-latency reads and writes across millions of requests per second, making it ideal for high-volume clickstream data. Cloud SQL (B) cannot handle such massive write throughput, Memorystore (C) has insufficient storage capacity for 8 TB, and while BigQuery (D) is powerful for analytics, it is generally less suited for the extreme low-latency, high-throughput write requirements described compared to Bigtable.

## Pregunta 15

Contexto: [topics:723](#topics-723)
Your company uses Cloud Spanner for a mission-critical inventory management system that is globally available. You recently loaded stock keeping unit (SKU) and product catalog data from a company acquisition and observed hotspots in the Cloud Spanner database. You want to follow Google-recommended schema design practices to avoid performance degradation. What should you do? (Choose two.)

**A.** Use an auto-incrementing value as the primary key.

**B.** Normalize the data model.

**C.** Promote low-cardinality attributes in multi-attribute primary keys.

**D.** Promote high-cardinality attributes in multi-attribute primary keys.

**E.** Use bit-reverse sequential value as the primary key.

**Respuesta de la fuente:** D, E

**Explicación:** To avoid hotspots in Cloud Spanner, you must ensure write traffic is distributed evenly across nodes. Promoting high-cardinality attributes (D) ensures unique values are spread out rather than concentrated, preventing sequential writes from targeting a single node. Additionally, using bit-reversed integer sequences (E) specifically disrupts the monotonic nature of auto-incrementing keys, distributing rows across the cluster to eliminate write hotspots. Option A is incorrect because auto-incrementing keys create severe hotspots by concentrating all new inserts on one node.

## Pregunta 16

Contexto: [topics:723](#topics-723)
You are managing multiple applications connecting to a database on Cloud SQL for PostgreSQL. You need to be able to monitor database performance to easily identify applications with long-running and resource-intensive queries. What should you do?

**A.** Use log messages produced by Cloud SQL.

**B.** Use Query Insights for Cloud SQL.

**C.** Use the Cloud Monitoring dashboard with available metrics from Cloud SQL.

**D.** Use Cloud SQL instance monitoring in the Google Cloud Console.

**Respuesta de la fuente:** B

**Explicación:** Query Insights for Cloud SQL is specifically designed to capture statistics about queries executed on the database instance, allowing you to identify long-running and resource-intensive SQL statements directly. In contrast, general instance monitoring (Options C and D) provides high-level infrastructure metrics like CPU or memory usage but lacks query-level granularity, while standard logs (Option A) are less effective for aggregated performance trend analysis.

## Pregunta 17

Contexto: [topics:723](#topics-723)
You are building an application that allows users to customize their website and mobile experiences. The application will capture user information and preferences. User profiles have a dynamic schema, and users can add or delete information from their profile. You need to ensure that user changes automatically trigger updates to your downstream BigQuery data warehouse. What should you do?

**A.** Store your data in Bigtable, and use the user identifier as the key. Use one column family to store user profile data, and use another column family to store user preferences.

**B.** Use Cloud SQL, and create different tables for user profile data and user preferences from your recommendations model. Use SQL to join the user profile data and preferences

**C.** Use Firestore in Native mode, and store user profile data as a document. Update the user profile with preferences specific to that user and use the user identifier to query.

**D.** Use Firestore in Datastore mode, and store user profile data as a document. Update the user profile with preferences specific to that user and use the user identifier to query.

**Respuesta de la fuente:** C

**Explicación:** Firestore in Native mode is the correct choice because it provides native client libraries for web and mobile applications, enabling real-time synchronization of user profile changes to downstream systems like BigQuery.
Option D (Datastore mode) lacks these modern client SDKs and real-time features, making it unsuitable for this specific mobile/web use case.
Options A and B are incorrect because Bigtable is optimized for massive IoT or time-series data rather than document-based user profiles, and Cloud SQL’s rigid relational schema conflicts with the requirement for a dynamic profile structure.

## Pregunta 18

Contexto: [topics:723](#topics-723)
Your application uses Cloud SQL for MySQL. Your users run reports on data that relies on near-real time; however, the additional analytics caused excessive load on the primary database. You created a read replica for the analytics workloads, but now your users are complaining about the lag in data changes and that their reports are still slow. You need to improve the report performance and shorten the lag in data replication without making changes to the current reports. Which two approaches should you implement? (Choose two.)

**A.** Create secondary indexes on the replica.

**B.** Create additional read replicas, and partition your analytics users to use different read replicas.

**C.** Disable replication on the read replica, and set the flag for parallel replication on the read replica. Re-enable replication and optimize performance by setting flags on the primary instance.

**D.** Disable replication on the primary instance, and set the flag for parallel replication on the primary instance. Re-enable replication and optimize performance by setting flags on the read replica.

**E.** Move your analytics workloads to BigQuery, and set up a streaming pipeline to move data and update BigQuery.

**Respuesta de la fuente:** B, C

**Explicación:** No conservada en esta captura.

## Pregunta 19

Contexto: [topics:723](#topics-723)
You are evaluating Cloud SQL for PostgreSQL as a possible destination for your on-premises PostgreSQL instances. Geography is becoming increasingly relevant to customer privacy worldwide. Your solution must support data residency requirements and include a strategy to: configure where data is stored control where the encryption keys are stored govern the access to data
What should you do?

**A.** Replicate Cloud SQL databases across different zones.

**B.** Create a Cloud SQL for PostgreSQL instance on Google Cloud for the data that does not need to adhere to data residency requirements. Keep the data that must adhere to data residency requirements on-premises. Make application changes to support both databases.

**C.** Allow application access to data only if the users are in the same region as the Google Cloud region for the Cloud SQL for PostgreSQL database.

**D.** Use features like customer-managed encryption keys (CMEK), VPC Service Controls, and Identity and Access Management (IAM) policies.

**Respuesta de la fuente:** D

**Explicación:** Option D correctly maps specific Google Cloud security features to the stated requirements: CMEK allows customers to control where encryption keys are stored, VPC Service Controls restrict data exfiltration to enforce storage boundaries, and IAM governs user access.
In contrast, Option A only addresses high availability across zones, not residency or key management; Option B requires a hybrid architecture that avoids the cloud solution for regulated data, which contradicts the goal of evaluating Cloud SQL as a destination; and Option C attempts to enforce residency via application logic based on user location, which is neither reliable nor a standard infrastructure control.

## Pregunta 20

Contexto: [topics:723](#topics-723)
Your customer is running a MySQL database on-premises with read replicas. The nightly incremental backups are expensive and add maintenance overhead. You want to follow Google-recommended practices to migrate the database to Google Cloud, and you need to ensure minimal downtime. What should you do?

**A.** Create a Google Kubernetes Engine (GKE) cluster, install MySQL on the cluster, and then import the dump file.

**B.** Use the mysqldump utility to take a backup of the existing on-premises database, and then import it into Cloud SQL.

**C.** Create a Compute Engine VM, install MySQL on the VM, and then import the dump file.

**D.** Create an external replica, and use Cloud SQL to synchronize the data to the replica.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because establishing an external replica allows for continuous replication of changes from the on-premises source to Cloud SQL, enabling a cutover with minimal downtime once synchronization is complete. This aligns with Google-recommended practices for migrating to managed services while avoiding the heavy maintenance overhead of IaaS options (A and C). Option B is incorrect because using mysqldump requires stopping writes during the export and import process, resulting in significant downtime compared to live replication.

## Pregunta 21

Contexto: [topics:723](#topics-723)
Your team uses thousands of connected IoT devices to collect device maintenance data for your oil and gas customers in real time. You want to design inspection routines, device repair, and replacement schedules based on insights gathered from the data produced by these devices. You need a managed solution that is highly scalable, supports a multi-cloud strategy, and offers low latency for these IoT devices. What should you do?

**A.** Use Firestore with Looker.

**B.** Use Cloud Spanner with Data Studio.

**C.** Use MongoD8 Atlas with Charts.

**D.** Use Bigtable with Looker.

**Respuesta de la fuente:** D

**Explicación:** Bigtable is a fully managed, wide-column NoSQL database optimized for low-latency reads and writes at massive scale, making it the ideal storage engine for high-volume IoT telemetry data. Looker provides the BI visualization layer that can connect to Bigtable to generate insights for maintenance scheduling.
The most tempting alternative, MongoDB Atlas (C), is explicitly ruled out because the question requires a *managed* solution within the context of this exam framework (likely GCP-focused given the other options like Spanner/Firestore); while Atlas is managed, Bigtable is the native GCP service designed specifically for this scale and latency profile. Additionally, Firestore (A) and Cloud Spanner (B) are not optimized for the high-throughput, time-series nature of IoT sensor data in the same way Bigtable is.

## Pregunta 22

Contexto: [topics:723](#topics-723)
Your application follows a microservices architecture and uses a single large Cloud SQL instance, which is starting to have performance issues as your application grows. in the Cloud Monitoring dashboard, the CPU utilization looks normal You want to follow Google-recommended practices to resolve and prevent these performance issues while avoiding any major refactoring. What should you do?

**A.** Use Cloud Spanner instead of Cloud SQL.

**B.** Increase the number of CPUs for your instance.

**C.** Increase the storage size for the instance.

**D.** Use many smaller Cloud SQL instances.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Google Cloud best practices recommend splitting large monolithic databases into smaller instances aligned with microservices to improve scalability and reduce contention, which can often be achieved without major application refactoring by routing connections appropriately. Option B is incorrect because the prompt explicitly states CPU utilization is normal, ruling out compute constraints, while Option A involves a significant architectural change that contradicts the constraint of avoiding major refactoring.

## Pregunta 23

Contexto: [topics:723](#topics-723)
You need to perform a one-time migration of data from a running Cloud SQL for MySQL instance in the us-central1 region to a new Cloud SQL for MySQL instance in the us-east1 region. You want to follow Google-recommended practices to minimize performance impact on the currently running instance. What should you do?

**A.** Create and run a Dataflow job that uses JdbcIO to copy data from one Cloud SQL instance to another.

**B.** Create two Datastream connection profiles, and use them to create a stream from one Cloud SQL instance to another.

**C.** Create a SQL dump file in Cloud Storage using a temporary instance, and then use that file to import into a new instance.

**D.** Create a CSV file by running the SQL statement SELECT...INTO OUTFILE, copy the file to a Cloud Storage bucket, and import it into a new instance.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because performing a serverless export to Cloud Storage allows Google Cloud to handle the backup process externally from the source instance's resources, thereby minimizing performance impact on the running database.
Dataflow (A) and Datastream (B) introduce unnecessary complexity and overhead for a one-time migration where continuous synchronization is not required.
Direct file exports via SELECT...INTO OUTFILE (D) consume significant CPU and I/O resources on the source instance, which contradicts the goal of minimizing performance impact.

## Pregunta 24

Contexto: [topics:723](#topics-723)
You are running a mission-critical application on a Cloud SQL for PostgreSQL database with a multi-zonal setup. The primary and read replica instances are in the same region but in different zones. You need to ensure that you split the application load between both instances. What should you do?

**A.** Use Cloud Load Balancing for load balancing between the Cloud SQL primary and read replica instances.

**B.** Use PgBouncer to set up database connection pooling between the Cloud SQL primary and read replica instances.

**C.** Use HTTP(S) Load Balancing for database connection pooling between the Cloud SQL primary and read replica instances.

**D.** Use the Cloud SQL Auth proxy for database connection pooling between the Cloud SQL primary and read replica instances.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 25

Contexto: [topics:723](#topics-723)
Your organization deployed a new version of a critical application that uses Cloud SQL for MySQL with high availability (HA) and binary logging enabled to store transactional information. The latest release of the application had an error that caused massive data corruption in your Cloud SQL for MySQL database. You need to minimize data loss. What should you do?

**A.** Open the Google Cloud Console, navigate to SQL > Backups, and select the last version of the automated backup before the corruption.

**B.** Reload the Cloud SQL for MySQL database using the LOAD DATA command to load data from CSV files that were used to initialize the instance.

**C.** Perform a point-in-time recovery of your Cloud SQL for MySQL database, selecting a date and time before the data was corrupted.

**D.** Fail over to the Cloud SQL for MySQL HA instance. Use that instance to recover the transactions that occurred before the corruption.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because binary logging enables Point-in-Time Recovery (PITR), which allows restoring the database to a specific moment just before the corruption, thereby minimizing data loss.
In contrast, Option A relies on automated backups that may have been taken long ago, resulting in significant data loss of valid transactions between the backup and the corruption event.
Option D is ineffective because HA replication mirrors the primary instance, so the corrupted data would already be present on the failover target.

## Pregunta 26

Contexto: [topics:723](#topics-723)
You plan to use Database Migration Service to migrate data from a PostgreSQL on-premises instance to Cloud SQL. You need to identify the prerequisites for creating and automating the task. What should you do? (Choose two.)

**A.** Drop or disable all users except database administration users.

**B.** Disable all foreign key constraints on the source PostgreSQL database.

**C.** Ensure that all PostgreSQL tables have a primary key.

**D.** Shut down the database before the Data Migration Service task is started.

**E.** Ensure that pglogical is installed on the source PostgreSQL database.

**Respuesta de la fuente:** C, E

**Explicación:** Google Cloud Database Migration Service uses the pglogical extension for logical replication when migrating from PostgreSQL, making its installation on the source a strict prerequisite. Additionally, pglogical requires that all tables have primary keys to uniquely identify rows during change data capture; without them, replication fails.

Option D is incorrect because DMS performs online migrations, meaning the source database must remain running and accessible throughout the process rather than being shut down.

## Pregunta 27

Contexto: [topics:723](#topics-723)
You are using Compute Engine on Google Cloud and your data center to manage a set of MySQL databases in a hybrid configuration. You need to create replicas to scale reads and to offload part of the management operation. What should you do?

**A.** Use external server replication.

**B.** Use Data Migration Service.

**C.** Use Cloud SQL for MySQL external replica.

**D.** Use the mysqldump utility and binary logs.

**Respuesta de la fuente:** C

**Explicación:** Cloud SQL for MySQL external replicas are specifically designed to create read-only replicas from an external (on-premises or VM-based) MySQL instance, enabling read scaling and management offloading through the managed Cloud SQL service.
Option A (External Server Replication) typically refers to replicating *from* Cloud SQL to an external server, which does not help scale reads on the cloud side for a source located in the data center.

## Pregunta 28

Contexto: [topics:723](#topics-723)
Your company is shutting down their data center and migrating several MySQL and PostgreSQL databases to Google Cloud. Your database operations team is severely constrained by ongoing production releases and the lack of capacity for additional on-premises backups. You want to ensure that the scheduled migrations happen with minimal downtime and that the Google Cloud databases stay in sync with the on-premises data changes until the applications can cut over. What should you do? (Choose two.)

**A.** Use Database Migration Service to migrate the databases to Cloud SQL.

**B.** Use a cross-region read replica to migrate the databases to Cloud SQL.

**C.** Use replication from an external server to migrate the databases to Cloud SQL.

**D.** Use an external read replica to migrate the databases to Cloud SQL.

**E.** Use a read replica to migrate the databases to Cloud SQL.

**Respuesta de la fuente:** A, C

**Explicación:** Database Migration Service (DMS) is the managed Google Cloud service designed to automate and manage database migrations with minimal downtime. Specifically, DMS uses continuous replication from external on-premises servers to keep the target Cloud SQL instances in sync during the migration process.

Option B is incorrect because cross-region read replicas are for replicating data between existing Cloud SQL instances within GCP, not for migrating from an external on-premises source.

## Pregunta 29

Contexto: [topics:723](#topics-723)
Your company is migrating the existing infrastructure for a highly transactional application to Google Cloud. You have several databases in a MySQL database instance and need to decide how to transfer the data to Cloud SQL. You need to minimize the downtime for the migration of your 500 GB instance. What should you do?

**A.** 1. Create a Cloud SQL for MySQL instance for your databases, and configure Datastream to stream your database changes to Cloud SQL.
2. Select the Backfill historical data check box on your stream configuration to initiate Datastream to backfill any data that is out of sync between the source and destination.
3. Delete your stream when all changes are moved to Cloud SQL for MySQL, and update your application to use the new instance.

**B.** 1. Create migration job using Database Migration Service.
2. Set the migration job type to Continuous, and allow the databases to complete the full dump phase and start sending data in change data capture (CDC) mode.
3. Wait for the replication delay to minimize, initiate a promotion of the new Cloud SQL instance, and wait for the migration job to complete.
4. Update your application connections to the new instance.

**C.** 1. Create migration job using Database Migration Service.
2. Set the migration job type to One-time, and perform this migration during a maintenance window.
3. Stop all write workloads to the source database and initiate the dump. Wait for the dump to be loaded into the Cloud SQL destination database and the destination database to be promoted to the primary database.
4. Update your application connections to the new instance.

**D.** 1. Use the mysqldump utility to manually initiate a backup of MySQL during the application maintenance window.
2. Move the files to Cloud Storage, and import each database into your Cloud SQL instance.
3. Continue to dump each database until all the databases are migrated.
4. Update your application connections to the new instance.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Database Migration Service (DMS) with Continuous migration uses Change Data Capture (CDC) to synchronize data in near real-time, allowing you to promote the destination database only when replication lag is minimal, thus achieving the lowest possible downtime. Option C is incorrect because a one-time dump requires stopping writes during the entire data load process, resulting in significant downtime. Options A and D are suboptimal: Datastream does not natively target Cloud SQL for MySQL homogeneous migrations, and manual mysqldump lacks the automated CDC capabilities needed to minimize downtime on a large transactional dataset.

## Pregunta 30

Contexto: [topics:723](#topics-723)
Your company uses the Cloud SQL out-of-disk recommender to analyze the storage utilization trends of production databases over the last 30 days. Your database operations team uses these recommendations to proactively monitor storage utilization and implement corrective actions. You receive a recommendation that the instance is likely to run out of disk space. What should you do to address this storage alert?

**A.** Normalize the database to the third normal form.

**B.** Compress the data using a different compression algorithm.

**C.** Manually or automatically increase the storage capacity.

**D.** Create another schema to load older data.

**Respuesta de la fuente:** C

**Explicación:** The Cloud SQL out-of-disk recommender specifically identifies instances at risk of running out of storage, and the official remediation is to increase the allocated disk size. Option A (normalization) often increases storage requirements due to additional tables and indexes, while Options B and D involve complex data migrations that are not immediate fixes for an impending capacity alert.

## Pregunta 31

Contexto: [topics:723](#topics-723)
You are managing a mission-critical Cloud SQL for PostgreSQL instance. Your application team is running important transactions on the database when another DBA starts an on-demand backup. You want to verify the status of the backup. What should you do?

**A.** Check the cloudsql.googleapis.com/postgres.log instance log.

**B.** Perform the gcloud sql operations list command.

**C.** Use Cloud Audit Logs to verify the status.

**D.** Use the Google Cloud Console.

**Respuesta de la fuente:** B

**Explicación:** According to Google Cloud documentation for troubleshooting backups, the Cloud Console only reports success or failure upon completion and does not show intermediate status updates like 'RUNNING'.
In contrast, the `gcloud sql operations list` command explicitly lists active operations and their current states, allowing you to verify if the backup is still in progress.

## Pregunta 32

Contexto: [topics:723](#topics-723)
You support a consumer inventory application that runs on a multi-region instance of Cloud Spanner. A customer opened a support ticket to complain about slow response times. You notice a Cloud Monitoring alert about high CPU utilization. You want to follow Google-recommended practices to address the CPU performance issue. What should you do first?

**A.** Increase the number of processing units.

**B.** Modify the database schema, and add additional indexes.

**C.** Shard data required by the application into multiple instances.

**D.** Decrease the number of processing units.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Spanner recommends keeping CPU utilization below 65%; if it exceeds this threshold, the immediate remediation is to increase processing units (compute capacity) or enable autoscaling. Schema modifications like adding indexes are optimization steps for inefficient queries but should only be considered after ensuring adequate compute resources to handle current load. Modifying schema without confirming resource constraints can be premature and does not directly address the alert of high CPU utilization.

## Pregunta 33

Contexto: [topics:723](#topics-723)
Your company uses Bigtable for a user-facing application that displays a low-latency real-time dashboard. You need to recommend the optimal storage type for this read-intensive database. What should you do?

**A.** Recommend solid-state drives (SSD).

**B.** Recommend splitting the Bigtable instance into two instances in order to load balance the concurrent reads.

**C.** Recommend hard disk drives (HDD).

**D.** Recommend mixed storage types.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Bigtable documentation explicitly recommends SSD storage for use cases requiring lower latency and higher throughput, such as real-time serving, user-facing applications, and mobile app recommendations.

Option B is incorrect because splitting instances is an architectural scaling strategy that does not address the specific requirement to select an optimal *storage type* (SSD vs. HDD).

## Pregunta 34

Contexto: [topics:723](#topics-723)
Your organization has a critical business app that is running with a Cloud SQL for MySQL backend database. Your company wants to build the most fault-tolerant and highly available solution possible. You need to ensure that the application database can survive a zonal and regional failure with a primary region of us-central1 and the backup region of us-east1. What should you do?

**A.** 1. Provision a Cloud SQL for MySQL instance in us-central1-a.
2. Create a multiple-zone instance in us-west1-b.
3. Create a read replica in us-east1-c.

**B.** 1. Provision a Cloud SQL for MySQL instance in us-central1-a.
2. Create a multiple-zone instance in us-central1-b.
3. Create a read replica in us-east1-b.

**C.** 1. Provision a Cloud SQL for MySQL instance in us-central1-a.
2. Create a multiple-zone instance in us-east-b.
3. Create a read replica in us-east1-c.

**D.** 1. Provision a Cloud SQL for MySQL instance in us-central1-a.
2. Create a multiple-zone instance in us-east1-b.
3. Create a read replica in us-central1-b.

**Respuesta de la fuente:** B

**Explicación:** To achieve high availability within the primary region (us-central1), Cloud SQL requires a High Availability instance configured across multiple zones in that same region; Option B correctly places both the primary zone (us-central1-a) and the HA secondary zone (us-central1-b) within us-central1. For disaster recovery against regional failure, a read replica must be provisioned in the designated backup region (us-east1), which Option B satisfies by placing the replica in us-east1-b. Options A, C, and D fail because they either place the HA secondary in a different region or mismatch the primary/backup regions specified in the requirements.

## Pregunta 35

Contexto: [topics:723](#topics-723)
You are building an Android game that needs to store data on a Google Cloud serverless database. The database will log user activity, store user preferences, and receive in-game updates. The target audience resides in developing countries that have intermittent internet connectivity. You need to ensure that the game can synchronize game data to the backend database whenever an internet network is available. What should you do?

**A.** Use Firestore.

**B.** Use Cloud SQL with an external (public) IP address.

**C.** Use an in-app embedded database.

**D.** Use Cloud Spanner.

**Respuesta de la fuente:** A

**Explicación:** Firestore is the correct choice because it natively supports offline persistence and automatic data synchronization for mobile clients, allowing the game to function during intermittent connectivity and sync changes when the network is restored.
Cloud SQL requires constant connectivity for transactional consistency and does not offer native offline client-side syncing mechanisms suitable for this scenario.

## Pregunta 36

Contexto: [topics:723](#topics-723)
You released a popular mobile game and are using a 50 TB Cloud Spanner instance to store game data in a PITR-enabled production environment. When you analyzed the game statistics, you realized that some players are exploiting a loophole to gather more points to get on the leaderboard. Another DBA accidentally ran an emergency bugfix script that corrupted some of the data in the production environment. You need to determine the extent of the data corruption and restore the production environment. What should you do? (Choose two.)

**A.** If the corruption is significant, use backup and restore, and specify a recovery timestamp.

**B.** If the corruption is significant, perform a stale read and specify a recovery timestamp. Write the results back.

**C.** If the corruption is significant, use import and export.

**D.** If the corruption is insignificant, use backup and restore, and specify a recovery timestamp.

**E.** If the corruption is insignificant, perform a stale read and specify a recovery timestamp. Write the results back.

**Respuesta de la fuente:** A, E

**Explicación:** According to Google Cloud Spanner documentation on Point-in-Time Recovery (PITR), significant corruption requires restoring the entire database to a past timestamp using backup and restore, making A correct. For insignificant or localized corruption, performing a stale read of specific rows from before the incident and writing them back is the recommended surgical approach, making E correct.
Option B is incorrect because using stale reads for significant, large-scale corruption across a 50 TB instance is inefficient and impractical compared to a full restore.

## Pregunta 37

Contexto: [topics:723](#topics-723)
You are starting a large CSV import into a Cloud SQL for MySQL instance that has many open connections. You checked memory and CPU usage, and sufficient resources are available. You want to follow Google-recommended practices to ensure that the import will not time out. What should you do?

**A.** Close idle connections or restart the instance before beginning the import operation.

**B.** Increase the amount of memory allocated to your instance.

**C.** Ensure that the service account has the Storage Admin role.

**D.** Increase the number of CPUs for the instance to ensure that it can handle the additional import operation.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud SQL documentation for MySQL imports explicitly recommends closing idle connections or restarting the instance to free up resources and prevent timeouts during large data loads.
While CPU and memory are currently sufficient, open connections can lock tables or consume connection slots, interfering with the import process even if compute resources appear available.

## Pregunta 38

Contexto: [topics:723](#topics-723)
You are migrating your data center to Google Cloud. You plan to migrate your applications to Compute Engine and your Oracle databases to Bare Metal Solution for Oracle. You must ensure that the applications in different projects can communicate securely and efficiently with the Oracle databases. What should you do?

**A.** Set up a Shared VPC, configure multiple service projects, and create firewall rules.

**B.** Set up Serverless VPC Access.

**C.** Set up Private Service Connect.

**D.** Set up Traffic Director.

**Respuesta de la fuente:** A

**Explicación:** Shared VPC is the recommended architecture for connecting multiple service projects (hosting Compute Engine) to a host project containing Bare Metal Solution resources, as it allows centralized network management and direct internal connectivity without cross-project VPC peering complexity. Firewall rules are essential in this setup to strictly control traffic flow from the application subnets to the database instances, ensuring security and efficiency.

Option B is incorrect because Serverless VPC Access connects serverless workloads (like Cloud Run or App Engine) to a VPC, not Compute Engine VMs.

## Pregunta 39

Contexto: [topics:723](#topics-723)
You are running an instance of Cloud Spanner as the backend of your ecommerce website. You learn that the quality assurance (QA) team has doubled the number of their test cases. You need to create a copy of your Cloud Spanner database in a new test environment to accommodate the additional test cases. You want to follow Google-recommended practices. What should you do?

**A.** Use Cloud Functions to run the export in Avro format.

**B.** Use Cloud Functions to run the export in text format.

**C.** Use Dataflow to run the export in Avro format.

**D.** Use Dataflow to run the export in text format.

**Respuesta de la fuente:** C

**Explicación:** Cloud Spanner exports are executed as Apache Beam pipelines on Cloud Dataflow, making options A and B incorrect. Additionally, the Avro format is required for exporting entire databases (including multiple tables) or subsets of data with schema preservation, whereas text/CSV formats only support single-table exports.

## Pregunta 40

Contexto: [topics:723](#topics-723)
You need to redesign the architecture of an application that currently uses Cloud SQL for PostgreSQL. The users of the application complain about slow query response times. You want to enhance your application architecture to offer sub-millisecond query latency. What should you do?

**A.** Configure Firestore, and modify your application to offload queries.

**B.** Configure Bigtable, and modify your application to offload queries.

**C.** Configure Cloud SQL for PostgreSQL read replicas to offload queries.

**D.** Configure Memorystore, and modify your application to offload queries.

**Respuesta de la fuente:** D

**Explicación:** Cloud Memorystore (Redis) is an in-memory data store specifically designed to deliver sub-millisecond query latency by serving requests from memory rather than disk.
Read replicas (Option C) distribute load but still rely on disk-based storage, making consistent sub-millisecond performance difficult to guarantee compared to an in-memory cache.

## Pregunta 41

Contexto: [topics:723](#topics-723)
You need to migrate existing databases from Microsoft SQL Server 2016 Standard Edition on a single Windows Server 2019 Datacenter Edition to a single Cloud SQL for SQL Server instance. During the discovery phase of your project, you notice that your on-premises server peaks at around 25,000 read IOPS. You need to ensure that your Cloud SQL instance is sized appropriately to maximize read performance. What should you do?

**A.** Create a SQL Server 2019 Standard on Standard machine type with 4 vCPUs, 15 GB of RAM, and 800 GB of solid-state drive (SSD).

**B.** Create a SQL Server 2019 Standard on High Memory machine type with at least 16 vCPUs, 104 GB of RAM, and 200 GB of SSD.

**C.** Create a SQL Server 2019 Standard on High Memory machine type with 16 vCPUs, 104 GB of RAM, and 4 TB of SSD.

**D.** Create a SQL Server 2019 Enterprise on High Memory machine type with 16 vCPUs, 104 GB of RAM, and 500 GB of SSD.

**Respuesta de la fuente:** C

**Explicación:** Google Cloud SQL for SQL Server SSD performance scales with disk size, providing approximately 120 IOPS per GB. To support a peak of 25,000 read IOPS, the storage must be sufficiently large; option C provides 4 TB (4,096 GB), yielding roughly 491,520 max IOPS capacity, which easily covers the requirement.

Option A (800 GB) and Option B (200 GB) provide insufficient storage volume to guarantee the necessary high IOPS throughput under GCP's performance scaling rules. Option D is incorrect because upgrading to Enterprise Edition does not change the underlying disk IOPS limits, which are determined by storage size rather than software licensing.

## Pregunta 42

Contexto: [topics:723](#topics-723)
You are managing a small Cloud SQL instance for developers to do testing. The instance is not critical and has a recovery point objective (RPO) of several days. You want to minimize ongoing costs for this instance. What should you do?

**A.** Take no backups, and turn off transaction log retention.

**B.** Take one manual backup per day, and turn off transaction log retention.

**C.** Turn on automated backup, and turn off transaction log retention.

**D.** Turn on automated backup, and turn on transaction log retention.

**Respuesta de la fuente:** C

**Explicación:** Automated backups satisfy the multi-day RPO with zero operational overhead, whereas manual backups (B) introduce unnecessary labor costs for a managed service. Transaction log retention enables Point-in-Time Recovery (PITR), which is costly and unnecessary given the relaxed RPO; turning it off reduces storage expenses without violating the requirement. Option A is incorrect because taking no backups risks exceeding the defined RPO.

## Pregunta 43

Contexto: [topics:723](#topics-723)
You manage a meeting booking application that uses Cloud SQL. During an important launch, the Cloud SQL instance went through a maintenance event that resulted in a downtime of more than 5 minutes and adversely affected your production application. You need to immediately address the maintenance issue to prevent any unplanned events in the future. What should you do?

**A.** Set your production instance's maintenance window to non-business hours.

**B.** Migrate the Cloud SQL instance to Cloud Spanner to avoid any future disruptions due to maintenance.

**C.** Contact Support to understand why your Cloud SQL instance had a downtime of more than 5 minutes.

**D.** Use Cloud Scheduler to schedule a maintenance window of no longer than 5 minutes.

**Respuesta de la fuente:** A

**Explicación:** To prevent future unplanned disruptions, you must configure the maintenance window to align with non-business hours, ensuring that Google Cloud's necessary updates occur when user impact is minimized.
Option B is incorrect because migrating to Cloud Spanner is a disproportionate and unnecessary architectural change for addressing routine maintenance timing issues.

## Pregunta 44

Contexto: [topics:723](#topics-723)
You are designing a highly available (HA) Cloud SQL for PostgreSQL instance that will be used by 100 databases. Each database contains 80 tables that were migrated from your on-premises environment to Google Cloud. The applications that use these databases are located in multiple regions in the US, and you need to ensure that read and write operations have low latency. What should you do?

**A.** Deploy 2 Cloud SQL instances in the us-central1 region with HA enabled, and create read replicas in us-east1 and us-west1.

**B.** Deploy 2 Cloud SQL instances in the us-central1 region, and create read replicas in us-east1 and us-west1.

**C.** Deploy 4 Cloud SQL instances in the us-central1 region with HA enabled, and create read replicas in us-central1, us-east1, and us-west1.

**D.** Deploy 4 Cloud SQL instances in the us-central1 region, and create read replicas in us-central1, us-east1 and us-west1.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because it enables High Availability (HA) in the primary region (us-central1) to protect against hardware failures, while deploying read replicas in us-east1 and us-west1 reduces read latency for applications located in those specific regions.

Option C is incorrect because deploying four instances in the primary region is unnecessary overhead; Cloud SQL HA typically consists of a primary and one standby. Furthermore, adding a read replica in us-central1 alongside an already available primary/HA pair offers redundant local read access that does not address the multi-region latency requirement as effectively as cross-regional replicas do.

## Pregunta 45

Contexto: [topics:723](#topics-723)
You work in the logistics department. Your data analysis team needs daily extracts from Cloud SQL for MySQL to train a machine learning model. The model will be used to optimize next-day routes. You need to export the data in CSV format. You want to follow Google-recommended practices. What should you do?

**A.** Use Cloud Scheduler to trigger a Cloud Function that will run a select * from table(s) query to call the cloudsql.instances.export API.

**B.** Use Cloud Scheduler to trigger a Cloud Function through Pub/Sub to call the cloudsql.instances.export API.

**C.** Use Cloud Composer to orchestrate an export by calling the cloudsql.instances.export API.

**D.** Use Cloud Composer to execute a select * from table(s) query and export results.

**Respuesta de la fuente:** B

**Explicación:** Option B is the recommended Google Cloud architecture because it correctly uses Cloud Scheduler to trigger a Cloud Function via Pub/Sub, which then invokes the cloudsql.instances.export API. This approach leverages managed services for scheduling and execution while adhering to best practices for decoupling tasks through message queues.
Option A is incorrect because a SQL SELECT statement alone cannot invoke the Cloud SQL Admin API; an application layer (like Cloud Functions) is required to make the REST call to initiate the export.

## Pregunta 46

Contexto: [topics:723](#topics-723)
You are choosing a database backend for a new application. The application will ingest data points from IoT sensors. You need to ensure that the application can scale up to millions of requests per second with sub-10ms latency and store up to 100 TB of history. What should you do?

**A.** Use Cloud SQL with read replicas for throughput.

**B.** Use Firestore, and rely on automatic serverless scaling.

**C.** Use Memorystore for Memcached, and add nodes as necessary to achieve the required throughput.

**D.** Use Bigtable, and add nodes as necessary to achieve the required throughput.

**Respuesta de la fuente:** D

**Explicación:** Bigtable is a fully managed, wide-column NoSQL database designed specifically for high-throughput, low-latency workloads involving massive scale (100 TB+) and millions of requests per second.
Unlike Cloud SQL (relational) or Firestore (document), Bigtable scales linearly by adding nodes to meet strict sub-10ms latency requirements for IoT time-series data.
Memorystore is an in-memory cache, not a persistent storage solution capable of retaining 100 TB of historical data.

## Pregunta 47

Contexto: [topics:723](#topics-723)
You are designing a payments processing application on Google Cloud. The application must continue to serve requests and avoid any user disruption if a regional failure occurs. You need to use AES-256 to encrypt data in the database, and you want to control where you store the encryption key. What should you do?

**A.** Use Cloud Spanner with a customer-managed encryption key (CMEK).

**B.** Use Cloud Spanner with default encryption.

**C.** Use Cloud SQL with a customer-managed encryption key (CMEK).

**D.** Use Bigtable with default encryption.

**Respuesta de la fuente:** A

**Explicación:** The requirement to avoid user disruption during a regional failure mandates a multi-region capable service, which points to Cloud Spanner rather than Cloud SQL (which is region-specific and requires manual failover). Additionally, the need to control where encryption keys are stored requires Customer-Managed Encryption Keys (CMEK) instead of default Google-managed keys. Therefore, using Cloud Spanner with CMEK satisfies both the high availability and key management requirements.

## Pregunta 48

Contexto: [topics:723](#topics-723)
You are managing a Cloud SQL for MySQL environment in Google Cloud. You have deployed a primary instance in Zone A and a read replica instance in Zone B, both in the same region. You are notified that the replica instance in Zone B was unavailable for 10 minutes. You need to ensure that the read replica instance is still working. What should you do?

**A.** Use the Google Cloud Console or gcloud CLI to manually create a new clone database.

**B.** Use the Google Cloud Console or gcloud CLI to manually create a new failover replica from backup.

**C.** Verify that the new replica is created automatically.

**D.** Start the original primary instance and resume replication.

**Respuesta de la fuente:** C

**Explicación:** Google Cloud SQL for MySQL automatically manages read replicas; if a replica becomes unavailable due to zone issues or failures, the system typically handles recovery or recreation without manual intervention. Therefore, verifying that the new replica is created automatically (C) is the correct approach to ensure it is working again. Options A and B suggest unnecessary manual actions like cloning or failover from backup, which are not required for standard replica availability checks. Option D is incorrect because the primary instance was not stated as offline, and replication status is managed on the replica side, not by starting/stopping the primary.

## Pregunta 49

Contexto: [topics:723](#topics-723)
You are migrating an on-premises application to Google Cloud. The application requires a high availability (HA) PostgreSQL database to support business-critical functions. Your company's disaster recovery strategy requires a recovery time objective (RTO) and recovery point objective (RPO) within 30 minutes of failure. You plan to use a Google Cloud managed service. What should you do to maximize uptime for your application?

**A.** Deploy Cloud SQL for PostgreSQL in a regional configuration. Create a read replica in a different zone in the same region and a read replica in another region for disaster recovery.

**B.** Deploy Cloud SQL for PostgreSQL in a regional configuration with HA enabled. Take periodic backups, and use this backup to restore to a new Cloud SQL for PostgreSQL instance in another region during a disaster recovery event.

**C.** Deploy Cloud SQL for PostgreSQL in a regional configuration with HA enabled. Create a cross-region read replica, and promote the read replica as the primary node for disaster recovery.

**D.** Migrate the PostgreSQL database to multi-regional Cloud Spanner so that a single region outage will not affect your application. Update the schema to support Cloud Spanner data types, and refactor the application.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it combines regional High Availability for automatic failover within the region with a cross-region read replica that can be promoted to meet the specific 30-minute RTO/RPO requirements for disaster recovery.

Option B is incorrect because periodic backups result in data loss (poor RPO) and longer restoration times (poor RTO) that typically exceed the 30-minute window. Option A lacks the explicit HA configuration needed for automatic primary failover, and Option D requires significant application refactoring which contradicts the goal of maximizing uptime with minimal change during migration.

## Pregunta 50

Contexto: [topics:723](#topics-723)
Your team is running a Cloud SQL for MySQL instance with a 5 TB database that must be available 24/7. You need to save database backups on object storage with minimal operational overhead or risk to your production workloads. What should you do?

**A.** Use Cloud SQL serverless exports.

**B.** Create a read replica, and then use the mysqldump utility to export each table.

**C.** Clone the Cloud SQL instance, and then use the mysqldump utlity to export the data.

**D.** Use the mysqldump utility on the primary database instance to export the backup.

**Respuesta de la fuente:** A

**Explicación:** Cloud SQL serverless exports offload the export workload to a temporary instance, ensuring zero impact on the production database's performance and minimizing operational overhead.
Using mysqldump directly (D) or via replicas/clones (B, C) requires manual management, introduces resource contention risks, and violates the requirement for minimal risk and overhead.

## Pregunta 51

Contexto: [topics:723](#topics-723)
You are deploying a new Cloud SQL instance on Google Cloud using the Cloud SQL Auth proxy. You have identified snippets of application code that need to access the new Cloud SQL instance. The snippets reside and execute on an application server running on a Compute Engine machine. You want to follow Google-recommended practices to set up Identity and Access Management (IAM) as quickly and securely as possible. What should you do?

**A.** For each application code, set up a common shared user account.

**B.** For each application code, set up a dedicated user account.

**C.** For the application server, set up a service account.

**D.** For the application server, set up a common shared user account.

**Respuesta de la fuente:** C

**Explicación:** Google recommends using a Service Account to authenticate the Cloud SQL Auth Proxy, as it provides secure, machine-to-machine identity management without requiring shared human credentials. This approach integrates with Compute Engine's default service account functionality for seamless and secure authentication. Option B is incorrect because creating dedicated database user accounts for each code snippet violates least-privilege principles regarding application architecture and complicates credential rotation.

## Pregunta 52

Contexto: [topics:723](#topics-723)
Your organization is running a low-latency reporting application on Microsoft SQL Server. In addition to the database engine, you are using SQL Server Analysis Services (SSAS), SQL Server Reporting Services (SSRS), and SQL Server Integration Services (SSIS) in your on-premises environment. You want to migrate your Microsoft SQL Server database instances to Google Cloud. You need to ensure minimal disruption to the existing architecture during migration. What should you do?

**A.** Migrate to Cloud SQL for SQL Server.

**B.** Migrate to Cloud SQL for PostgreSQL.

**C.** Migrate to Compute Engine.

**D.** Migrate to Google Kubernetes Engine (GKE).

**Respuesta de la fuente:** C

**Explicación:** Cloud SQL for SQL Server does not support the full SQL Server ecosystem, specifically excluding Analysis Services (SSAS), Reporting Services (SSRS), and Integration Services (SSIS). To maintain minimal disruption to an architecture that relies on these integrated components, you must migrate the entire stack to Google Compute Engine, which allows you to run the full Microsoft SQL Server suite as you would on-premises. Migrating to Cloud SQL (A) is incorrect because it drops support for SSAS/SSRS/SSIS, forcing a significant architectural rewrite.

## Pregunta 53

Contexto: [topics:723](#topics-723)
An analytics team needs to read data out of Cloud SQL for SQL Server and update a table in Cloud Spanner. You need to create a service account and grant least privilege access using predefined roles. What roles should you assign to the service account?

**A.** roles/cloudsql.viewer and roles/spanner.databaseUser

**B.** roles/cloudsql.editor and roles/spanner.admin

**C.** roles/cloudsql.client and roles/spanner.databaseReader

**D.** roles/cloudsql.instanceUser and roles/spanner.databaseUser

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 54

Contexto: [topics:723](#topics-723)
You are responsible for designing a new database for an airline ticketing application in Google Cloud. This application must be able to:
Work with transactions and offer strong consistency.
Work with structured and semi-structured (JSON) data.
Scale transparently to multiple regions globally as the operation grows.
You need a Google Cloud database that meets all the requirements of the application. What should you do?

**A.** Use Cloud SQL for PostgreSQL with both cross-region read replicas.

**B.** Use Cloud Spanner in a multi-region configuration.

**C.** Use Firestore in Datastore mode.

**D.** Use a Bigtable instance with clusters in multiple regions.

**Respuesta de la fuente:** B

**Explicación:** Cloud Spanner is the only option that provides globally distributed strong consistency for all transactions (ACID compliance) while natively supporting structured and semi-structured JSON data.
Unlike Cloud SQL, Spanner scales transparently across regions without manual sharding; unlike Firestore Datastore mode, it offers strong consistency for all queries rather than just ancestor queries.

## Pregunta 55

Contexto: [topics:723](#topics-723)
You are writing an application that will run on Cloud Run and require a database running in the Cloud SQL managed service. You want to secure this instance so that it only receives connections from applications running in your VPC environment in Google Cloud. What should you do?

**A.** 1. Create your instance with a specified external (public) IP address.
2. Choose the VPC and create firewall rules to allow only connections from Cloud Run into your instance.
3. Use Cloud SQL Auth proxy to connect to the instance.

**B.** 1. Create your instance with a specified external (public) IP address.
2. Choose the VPC and create firewall rules to allow only connections from Cloud Run into your instance.
3. Connect to the instance using a connection pool to best manage connections to the instance.

**C.** 1. Create your instance with a specified internal (private) IP address.
2. Choose the VPC with private service connection configured.
3. Configure the Serverless VPC Access connector in the same VPC network as your Cloud SQL instance.
4. Use Cloud SQL Auth proxy to connect to the instance.

**D.** 1. Create your instance with a specified internal (private) IP address.
2. Choose the VPC with private service connection configured.
3. Configure the Serverless VPC Access connector in the same VPC network as your Cloud SQL instance.
4. Connect to the instance using a connection pool to best manage connections to the instance.

**Respuesta de la fuente:** D

**Explicación:** To restrict Cloud SQL connections to your VPC, you must assign a private (internal) IP address and use Serverless VPC Access to enable connectivity from the serverless environment. The most tempting alternative, C, is incorrect because when connecting via Private IP through Serverless VPC Access, the application connects directly over TCP; it does not require (and typically should not use) the Cloud SQL Auth Proxy, which is designed for public IP or authorized network scenarios.

## Pregunta 56

Contexto: [topics:723](#topics-723)
You are troubleshooting a connection issue with a newly deployed Cloud SQL instance on Google Cloud. While investigating the Cloud SQL Proxy logs, you see the message Error 403: Access Not Configured. What should you do?

**A.** Check the app.yaml value cloud_sql_instances for a misspelled or incorrect instance connection name.

**B.** Check whether your service account has cloudsql.instances.connect permission.

**C.** Enable the Cloud SQL Admin API.

**D.** Ensure that you are using an external (public) IP address interface.

**Respuesta de la fuente:** C

**Explicación:** The 'Error 403: Access Not Configured' message specifically indicates that the Cloud SQL Admin API is not enabled for the project, which is a prerequisite for the Cloud SQL Proxy to function. While missing permissions (Option B) result in a '403 Forbidden' or 'Not Authorized' error, and incorrect instance names (Option A) lead to connection failures or invalid argument errors, neither produces the 'Access Not Configured' status.
Reference: Google Cloud Documentation on troubleshooting Cloud SQL Auth Proxy.

## Pregunta 57

Contexto: [topics:723](#topics-723)
You are working on a new centralized inventory management system to track items available in 200 stores, which each have 500 GB of data. You are planning a gradual rollout of the system to a few stores each week. You need to design an SQL database architecture that minimizes costs and user disruption during each regional rollout and can scale up or down on nights and holidays. What should you do?

**A.** Use Oracle Real Application Cluster (RAC) databases on Bare Metal Solution for Oracle.

**B.** Use sharded Cloud SQL instances with one or more stores per database instance.

**C.** Use a Biglable cluster with autoscaling.

**D.** Use Cloud Spanner with a custom autoscaling solution.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Cloud Spanner is the only fully managed relational database among the choices that supports horizontal scaling without manual intervention when paired with the recommended Autoscaler solution, meeting the requirement to scale up or down dynamically. While Bigtable (C) is NoSQL and thus excluded by the 'SQL' constraint, and Oracle RAC (A) lacks the required automatic scaling capabilities, Cloud SQL (B) requires instance restarts for vertical scaling changes, causing unacceptable user disruption during the rollout.

## Pregunta 58

Contexto: [topics:723](#topics-723)
Your organization has strict policies on tracking rollouts to production and periodically shares this information with external auditors to meet compliance requirements. You need to enable auditing on several Cloud Spanner databases. What should you do?

**A.** Use replication to roll out changes to higher environments.

**B.** Use backup and restore to roll out changes to higher environments.

**C.** Use Liquibase to roll out changes to higher environments.

**D.** Manually capture detailed DBA audit logs when changes are rolled out to higher environments.

**Respuesta de la fuente:** C

**Explicación:** To satisfy strict compliance and auditing requirements for production rollouts, you must use a version-controlled system that records exactly what changes were made, when, and by whom. Liquibase is the only option listed that provides this type of database change management and source control integration, creating an auditable trail suitable for external review.

Option D is incorrect because manual processes are error-prone and fail to meet modern cloud automation and compliance standards. Options A and B describe data movement techniques rather than structured change management tools capable of generating the detailed audit artifacts required.

## Pregunta 59

Contexto: [topics:723](#topics-723)
Your organization has a production Cloud SQL for MySQL instance. Your instance is configured with 16 vCPUs and 104 GB of RAM that is running between 90% and 100% CPU utilization for most of the day. You need to scale up the database and add vCPUs with minimal interruption and effort. What should you do?

**A.** Issue a gcloud sql instances patch command to increase the number of vCPUs.

**B.** Update a MySQL database flag to increase the number of vCPUs.

**C.** Issue a gcloud compute instances update command to increase the number of vCPUs.

**D.** Back up the database, create an instance with additional vCPUs, and restore the database.

**Respuesta de la fuente:** A

**Explicación:** The correct action is to use the `gcloud sql instances patch` command with the `--cpu` flag, as this allows you to modify the resource configuration of a Cloud SQL instance directly and efficiently.
Option D is incorrect because creating a new instance and restoring data involves significant downtime and manual effort, violating the requirement for minimal interruption. Option C targets Compute Engine VMs rather than managed Cloud SQL instances, and Option B attempts to change infrastructure resources via database flags, which is technically invalid.

## Pregunta 60

Contexto: [topics:723](#topics-723)
You are configuring a brand new Cloud SQL for PostgreSQL database instance in Google Cloud. Your application team wants you to deploy one primary instance, one standby instance, and one read replica instance. You need to ensure that you are following Google-recommended practices for high availability. What should you do?

**A.** Configure the primary instance in zone A, the standby instance in zone C, and the read replica in zone B, all in the same region.

**B.** Configure the primary and standby instances in zone A and the read replica in zone B, all in the same region.

**C.** Configure the primary instance in one region, the standby instance in a second region, and the read replica in a third region.

**D.** Configure the primary, standby, and read replica instances in zone A, all in the same region.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud SQL High Availability requires a regional configuration where the primary and standby instances reside in different zones within the same region to ensure synchronous replication and automatic failover. Distributing the read replica to a third distinct zone (as in Option A) maximizes resilience against zone-specific failures without introducing the latency or complexity of cross-region replication. Options B and D fail because they place critical components in the same zone, creating a single point of failure, while Option C is incorrect because Cloud SQL HA is strictly a regional feature, not a multi-region one.

## Pregunta 61

Contexto: [topics:723](#topics-723)
You are running a transactional application on Cloud SQL for PostgreSQL in Google Cloud. The database is running in a high availability configuration within one region. You have encountered issues with data and want to restore to the last known pristine version of the database. What should you do?

**A.** Create a clone database from a read replica database, and restore the clone in the same region.

**B.** Create a clone database from a read replica database, and restore the clone into a different zone.

**C.** Use the Cloud SQL point-in-time recovery (PITR) feature. Restore the copy from two hours ago to a new database instance.

**D.** Use the Cloud SQL database import feature. Import last week's dump file from Cloud Storage.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Point-in-Time Recovery (PITR) allows you to restore the database to a specific moment before data corruption occurred, which directly addresses the goal of returning to a 'pristine' version. Options A and B are incorrect because High Availability configurations in Cloud SQL use failover replicas for uptime continuity, not necessarily read replicas suitable for cloning, and cloning may inherit recent corruption. Option D is incorrect because it implies a manual logical backup process rather than leveraging the automated physical backups inherent to HA setups, making it less efficient and precise than PITR.

## Pregunta 62

Contexto: [topics:723](#topics-723)
Your organization has a security policy to ensure that all Cloud SQL for PostgreSQL databases are secure. You want to protect sensitive data by using a key that meets specific locality or residency requirements. Your organization needs to control the key's lifecycle activities. You need to ensure that data is encrypted at rest and in transit. What should you do?

**A.** Create the database with Google-managed encryption keys.

**B.** Create the database with customer-managed encryption keys.

**C.** Create the database persistent disk with Google-managed encryption keys.

**D.** Create the database persistent disk with customer-managed encryption keys.

**Respuesta de la fuente:** B

**Explicación:** The requirement to control key lifecycle activities and meet specific locality/residency mandates necessitates using Customer-Managed Encryption Keys (CMEK), as Google-managed keys are controlled entirely by Google without user intervention. In Cloud SQL, encryption is configured at the instance level, which automatically applies CMEK to the underlying persistent disks and database data; therefore, specifying 'database with CMEK' correctly addresses the holistic security policy for both data at rest and transit within the service context, whereas managing just the disk (Option D) is a lower-level implementation detail not typically selected as the primary configuration scope in this framework.

## Pregunta 63

Contexto: [topics:723](#topics-723)
Your organization has an existing app that just went viral. The app uses a Cloud SQL for MySQL backend database that is experiencing slow disk performance while using hard disk drives (HDDs). You need to improve performance and reduce disk I/O wait times. What should you do?

**A.** Export the data from the existing instance, and import the data into a new instance with solid-state drives (SSDs).

**B.** Edit the instance to change the storage type from HDD to SSD.

**C.** Create a high availability (HA) failover instance with SSDs, and perform a failover to the new instance.

**D.** Create a read replica of the instance with SSDs, and perform a failover to the new instance

**Respuesta de la fuente:** A

**Explicación:** In Google Cloud SQL for MySQL, the choice between HDD and SSD storage is a permanent configuration set at instance creation and cannot be changed directly via editing or replication operations.
Therefore, options B, C, and D are invalid because you cannot convert an existing instance's disk type or force a replica/HA instance to use a different disk type than the primary.
The only supported method to switch storage types is to export the data from the HDD instance and import it into a newly created SSD instance (Option A).

## Pregunta 64

Contexto: [topics:723](#topics-723)
You are configuring a new application that has access to an existing Cloud Spanner database. The new application reads from this database to gather statistics for a dashboard. You want to follow Google-recommended practices when granting Identity and Access Management (IAM) permissions. What should you do?

**A.** Reuse the existing service account that populates this database.

**B.** Create a new service account, and grant it the Cloud Spanner Database Admin role.

**C.** Create a new service account, and grant it the Cloud Spanner Database Reader role.

**D.** Create a new service account, and grant it the spanner.databases.select permission.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because the application only needs read access for statistics, so granting the Cloud Spanner Database Reader role follows the principle of least privilege.
Additionally, Google recommends assigning predefined roles rather than individual permissions, making D incorrect, while B grants excessive admin rights and A violates isolation best practices.

## Pregunta 65

Contexto: [topics:723](#topics-723)
Your retail organization is preparing for the holiday season. Use of catalog services is increasing, and your DevOps team is supporting the Cloud SQL databases that power a microservices-based application. The DevOps team has added instrumentation through Sqlcommenter. You need to identify the root cause of why certain microservice calls are failing. What should you do?

**A.** Watch Query Insights for long running queries.

**B.** Watch the Cloud SQL instance monitor for CPU utilization metrics.

**C.** Watch the Cloud SQL recommenders for overprovisioned instances.

**D.** Watch Cloud Trace for application requests that are failing.

**Respuesta de la fuente:** D

**Explicación:** Cloud Trace provides end-to-end distributed tracing for microservices, allowing you to identify exactly which service calls are failing and where the error originates in the request chain. While Sqlcommenter aids in database-level debugging via Query Insights (Option A), it does not directly expose application-layer failure states or inter-service communication errors as effectively as Cloud Trace.
Reference: Google Cloud Operations Suite documentation on Cloud Trace for microservices debugging.

## Pregunta 66

Contexto: [topics:723](#topics-723)
You are designing a database architecture for a global application that stores information about public parks worldwide. The application uses the database for read-only purposes, and a centralized batch job updates the database nightly. You want to select an open source, SQL-compliant database. What should you do?

**A.** Use Bigtable with multi-region clusters.

**B.** Use Memorystore for Redis with multi-zones within a region.

**C.** Use Cloud SQL for PostgreSQL with cross-region replicas.

**D.** Use Cloud Spanner with multi-region configuration.

**Respuesta de la fuente:** C

**Explicación:** Cloud SQL for PostgreSQL is the correct choice because it runs an actual open-source database engine and supports standard SQL, meeting the explicit requirements. While Cloud Spanner (Option D) offers global distribution and SQL compatibility, it is a proprietary managed service that supports PostgreSQL dialects but is not itself an open-source database; furthermore, its high cost and complexity are unnecessary for a read-only workload with nightly batch updates.
Cross-region replicas in Cloud SQL provide the low-latency read access required for a global application while adhering to the open-source constraint.

## Pregunta 67

Contexto: [topics:723](#topics-723)
Your company is migrating their MySQL database to Cloud SQL and cannot afford any planned downtime during the month of December. The company is also concerned with cost, so you need the most cost-effective solution. What should you do?

**A.** Open a support ticket in Google Cloud to prevent any maintenance in that MySQL instance during the month of December.

**B.** Use Cloud SQL maintenance settings to prevent any maintenance during the month of December.

**C.** Create MySQL read replicas in different zones so that, if any downtime occurs, the read replicas will act as the primary instance during the month of December.

**D.** Create a MySQL regional instance so that, if any downtime occurs, the standby instance will act as the primary instance during the month of December.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Cloud SQL allows configuring a 'maintenance deny period' of up to 90 days, effectively preventing scheduled maintenance during December without incurring extra infrastructure costs. Options C and D are incorrect because provisioning read replicas or regional instances adds significant expense, violating the cost-effectiveness requirement. Option A is invalid as maintenance windows are configured via the console/API, not through manual support tickets.

## Pregunta 68

Contexto: [topics:723](#topics-723)
Your online delivery business that primarily serves retail customers uses Cloud SQL for MySQL for its inventory and scheduling application. The required recovery time objective (RTO) and recovery point objective (RPO) must be in minutes rather than hours as a part of your high availability and disaster recovery design. You need a high availability configuration that can recover without data loss during a zonal or a regional failure. What should you do?

**A.** Set up all read replicas in a different region using asynchronous replication.

**B.** Set up all read replicas in the same region as the primary instance with synchronous replication.

**C.** Set up read replicas in different zones of the same region as the primary instance with synchronous replication, and set up read replicas in different regions with asynchronous replication.

**D.** Set up read replicas in different zones of the same region as the primary instance with asynchronous replication, and set up read replicas in different regions with synchronous replication.

**Respuesta de la fuente:** C

**Explicación:** Option C is the intended answer because it aligns with standard high-availability design patterns that combine synchronous replication within a region (for zero RPO during zonal failures) and asynchronous replication across regions (to avoid latency issues while providing disaster recovery). In this specific exam context, 'synchronous' implies the failover mechanism for local HA, ensuring data consistency for zone outages, while cross-region async provides regional resilience. Option A is incorrect because relying solely on asynchronous read replicas in a different region does not guarantee zero data loss (RPO=0) or fast RTO for zonal failures, as async replication inherently introduces potential data lag.

## Pregunta 69

Contexto: [topics:723](#topics-723)
Your hotel booking company is expanding into Country A, where personally identifiable information (PII) must comply with regional data residency requirements and audits. You need to isolate customer data in Country A from the rest of the customer data. You want to design a multi-tenancy strategy to efficiently manage costs and operations. What should you do?

**A.** Apply a schema data management pattern.

**B.** Apply an instance data management pattern.

**C.** Apply a table data management pattern.

**D.** Apply a database data management pattern.

**Respuesta de la fuente:** B

**Explicación:** Data residency requirements mandate that PII remains within specific geographic boundaries. In cloud architectures (like Google Cloud Spanner or SQL), the location is defined at the instance level, as databases, tables, and schemas cannot be individually assigned to different regions within a single instance.
Therefore, applying an instance data management pattern ensures strict physical isolation of Country A's data by deploying a dedicated instance in that region.

## Pregunta 70

Contexto: [topics:723](#topics-723)
You work for a financial services company that wants to use fully managed database services. Traffic volume for your consumer services products has increased annually at a constant rate with occasional spikes around holidays. You frequently need to upgrade the capacity of your database. You want to use Cloud Spanner and include an automated method to increase your hardware capacity to support a higher level of concurrency. What should you do?

**A.** Use linear scaling to implement the Autoscaler-based architecture

**B.** Use direct scaling to implement the Autoscaler-based architecture.

**C.** Upgrade the Cloud Spanner instance on a periodic basis during the scheduled maintenance window.

**D.** Set up alerts that are triggered when Cloud Spanner utilization metrics breach the threshold, and then schedule an upgrade during the scheduled maintenance window.

**Respuesta de la fuente:** A

**Explicación:** Cloud Spanner Autoscaler offers three scaling methods: stepwise, linear, and direct. Linear scaling is explicitly recommended for workloads with gradual changes or occasional large peaks (like holiday spikes), as it calculates the minimum capacity needed to stay below a utilization threshold without fixed step limits.
Direct scaling would increase capacity immediately upon any breach, which is less suitable for predictable annual growth patterns than linear scaling's optimization approach. Options C and D are incorrect because they involve manual or semi-manual intervention, contradicting the requirement for an automated method.

## Pregunta 71

Contexto: [topics:723](#topics-723)
Your organization has a busy transactional Cloud SQL for MySQL instance. Your analytics team needs access to the data so they can build monthly sales reports. You need to provide data access to the analytics team without adversely affecting performance. What should you do?

**A.** Create a read replica of the database, provide the database IP address, username, and password to the analytics team, and grant read access to required tables to the team.

**B.** Create a read replica of the database, enable the cloudsql.iam_authentication flag on the replica, and grant read access to required tables to the analytics team.

**C.** Enable the cloudsql.iam_authentication flag on the primary database instance, and grant read access to required tables to the analytics team.

**D.** Provide the database IP address, username, and password of the primary database instance to the analytics, team, and grant read access to required tables to the team.

**Respuesta de la fuente:** B

**Explicación:** To protect the performance of the busy primary transactional instance, you must route analytics queries to a read replica rather than the primary database. Option B is superior to A because it uses IAM authentication, which eliminates the security risk and administrative overhead of managing static database passwords by leveraging Google Cloud's centralized identity management. Options C and D are incorrect as they direct traffic to the primary instance, risking performance degradation.

## Pregunta 72

Contexto: [topics:723](#topics-723)
Your organization stores marketing data such as customer preferences and purchase history on Bigtable. The consumers of this database are predominantly data analysts and operations users. You receive a service ticket from the database operations department citing poor database performance between 9 AM-10 AM every day. The application team has confirmed no latency from their logs. A new cohort of pilot users that is testing a dataset loaded from a third-party data provider is experiencing poor database performance. Other users are not affected. You need to troubleshoot the issue. What should you do?

**A.** Isolate the data analysts and operations user groups to use different Bigtable instances.

**B.** Check the Cloud Monitoring table/bytes_used metric from Bigtable.

**C.** Use Key Visualizer for Bigtable.

**D.** Add more nodes to the Bigtable cluster.

**Respuesta de la fuente:** C

**Explicación:** The Key Visualizer is the recommended tool for diagnosing Bigtable performance issues, specifically to identify hot spots caused by uneven row key distribution. Since only a new cohort of users is affected, it is highly likely their access patterns are creating a hotspot on specific nodes, which Key Visualizer can visualize and help optimize.

Adding more nodes (D) does not resolve hotspots if the data is still skewed, and isolating users (A) or checking storage metrics (B) does not directly address the root cause of performance degradation related to query patterns.

## Pregunta 73

Contexto: [topics:723](#topics-723)
Your company is developing a new global transactional application that must be ACID-compliant and have 99.999% availability. You are responsible for selecting the appropriate Google Cloud database to serve as a datastore for this new application. What should you do?

**A.** Use Firestore.

**B.** Use Cloud Spanner.

**C.** Use Cloud SQL.

**D.** Use Bigtable.

**Respuesta de la fuente:** B

**Explicación:** Cloud Spanner is the only option that natively supports strong ACID consistency at a global scale with a 99.999% availability SLA for multi-region instances.
Firestore is eventually consistent by default (though it offers strong reads/transactions, it is NoSQL and not traditionally defined as fully ACID-compliant in the same relational sense) and Bigtable lacks full transactional support across regions, while Cloud SQL cannot provide global 99.999% availability.

## Pregunta 74

Contexto: [topics:723](#topics-723)
You want to migrate your PostgreSQL database from another cloud provider to Cloud SQL. You plan on using Database Migration Service and need to assess the impact of any known limitations. What should you do? (Choose two.)

**A.** Identify whether the database has over 512 tables.

**B.** Identify all tables that do not have a primary key.

**C.** Identity all tables that do not have at least one foreign key.

**D.** Identify whether the source database is encrypted using pgcrypto extension.

**E.** Identify whether the source database uses customer-managed encryption keys (CMEK).

**Respuesta de la fuente:** B, E

**Explicación:** Option B is correct because tables without primary keys require manual migration of UPDATE and DELETE statements during CDC, representing a significant limitation. Option E is correct because if the source uses Customer-Managed Encryption Keys (CMEK) that DMS cannot access, the data remains inaccessible for migration.

Option D is incorrect because Cloud SQL supports the pgcrypto extension, so its presence does not block migration. Option A is irrelevant as there is no strict 512-table limit cited in known limitations, and Option C is unnecessary since foreign keys are not a prerequisite for DMS.

## Pregunta 75

Contexto: [topics:723](#topics-723)
Your organization is running a Firestore-backed Firebase app that serves the same top ten news stories on a daily basis to a large global audience. You want to optimize content delivery while decreasing cost and latency. What should you do?

**A.** Enable serializable isolation in the Firebase app.

**B.** Deploy a US multi-region Firestore location.

**C.** Build a Firestore bundle, and deploy bundles to Cloud CDN.

**D.** Create a Firestore index on the news story date.

**Respuesta de la fuente:** C

**Explicación:** Firestore bundles are specifically designed to package and deliver multiple documents efficiently over the network, reducing request count and data overhead.
By deploying these bundles to Cloud CDN, you leverage edge caching to serve static or semi-static content (like daily top news) from locations closer to users, thereby minimizing both latency and cost compared to direct database queries.
Option B is incorrect because while a multi-region location improves availability, it does not inherently reduce the per-request latency or cost for read-heavy scenarios as effectively as edge caching does.

## Pregunta 76

Contexto: [topics:723](#topics-723)
You need to migrate a 1 TB PostgreSQL database from a Compute Engine VM to Cloud SQL for PostgreSQL. You want to ensure that there is minimal downtime during the migration. What should you do?

**A.** Export the data from the existing database, and load the data into a new Cloud SQL database.

**B.** Use Migrate for Compute Engine to complete the migration.

**C.** Use Datastream to complete the migration.

**D.** Use Database Migration Service to complete the migration.

**Respuesta de la fuente:** D

**Explicación:** Google Cloud Database Migration Service (DMS) is specifically designed for migrating databases like PostgreSQL with minimal downtime by performing an initial full load followed by continuous change data capture (CDC) to synchronize ongoing changes until cutover.

Option A involves a static export/import which requires significant downtime for a large dataset, while Option B migrates entire VMs rather than the database layer, and Option C (Datastream) is primarily used for migrating to BigQuery or Spanner.

## Pregunta 77

Contexto: [topics:723](#topics-723)
You have a large Cloud SQL for PostgreSQL instance. The database instance is not mission-critical, and you want to minimize operational costs. What should you do to lower the cost of backups in this environment?

**A.** Set the automated backups to occur every other day to lower the frequency of backups.

**B.** Change the storage tier of the automated backups from solid-state drive (SSD) to hard disk drive (HDD).

**C.** Select a different region to store your backups.

**D.** Reduce the number of automated backups that are retained to two (2).

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Cloud SQL charges for backup storage based on the amount of data retained; reducing the retention period from the default of seven days to two directly lowers the volume of stored backups, thereby minimizing costs.
Options A and B are incorrect because automated backups are an all-or-nothing feature (you cannot change frequency or underlying storage tier), and Option C is ineffective as backup storage costs are determined by data volume, not region selection.

## Pregunta 78

Contexto: [topics:723](#topics-723)
You are the primary DBA of a Cloud SQL for PostgreSQL database that supports 6 enterprise applications in production. You used Cloud SQL Insights to identify inefficient queries and now need to identify the application that is originating the inefficient queries. You want to follow Google-recommended practices. What should you do?

**A.** Shut down and restart each application.

**B.** Write a utility to scan database query logs.

**C.** Write a utility to scan application logs.

**D.** Use query tags to add application-centric database monitoring.

**Respuesta de la fuente:** D

**Explicación:** Google Cloud SQL supports Query Tags via the `sqlcommenter` library to annotate queries with application context, such as API routes or service names. This allows Cloud SQL Insights to filter and group inefficient queries by their originating application, directly addressing the need to identify the source without manual log parsing. Option B is incorrect because manually scanning database logs does not inherently map queries to specific applications without prior instrumentation, making it an inefficient and non-standard approach.

## Pregunta 79

Contexto: [topics:723](#topics-723)
You are designing a database strategy for a new web application. You plan to start with a small pilot in one country and eventually expand to millions of users in a global audience. You need to ensure that the application can run 24/7 with minimal downtime for maintenance. What should you do?

**A.** Use Cloud Spanner in a regional configuration.

**B.** Use Cloud Spanner in a multi-region configuration.

**C.** Use Cloud SQL with cross-region replicas.

**D.** Use highly available Cloud SQL with multiple zones.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Cloud Spanner supports starting with a single-region configuration, which aligns with the initial 'small pilot in one country' requirement while providing the necessary horizontal scalability and high availability for future global expansion. Option B is incorrect because deploying a multi-region configuration from the start introduces unnecessary latency and cost for a localized pilot; Cloud Spanner allows you to upgrade to multi-region later by contacting support, making A the more prudent architectural starting point.

## Pregunta 80

Contexto: [topics:723](#topics-723)
Your company is shutting down their on-premises data center and migrating their Oracle databases using Oracle Real Application Clusters (RAC) to Google Cloud. You want minimal to no changes to the applications during the database migration. What should you do?

**A.** Migrate the Oracle databases to Cloud Spanner.

**B.** Migrate the Oracle databases to Compute Engine.

**C.** Migrate the Oracle databases to Cloud SQL.

**D.** Migrate the Oracle databases to Bare Metal Solution for Oracle.

**Respuesta de la fuente:** D

**Explicación:** Bare Metal Solution offers certified support for Oracle RAC on dedicated physical hardware, ensuring zero application changes are required during migration.
Cloud SQL does not support Oracle engines (only MySQL, PostgreSQL, and SQL Server), making option C technically invalid.
Option B is incorrect because running Oracle RAC on standard Compute Engine virtual machines lacks the necessary certified configuration for minimal-change migration.

## Pregunta 81

Contexto: [topics:723](#topics-723)
Your company wants you to migrate their Oracle, MySQL, Microsoft SQL Server, and PostgreSQL relational databases to Google Cloud. You need a fully managed, flexible database solution when possible. What should you do?

**A.** Migrate all the databases to Cloud SQL.

**B.** Migrate the Oracle, MySQL, and Microsoft SQL Server databases to Cloud SQL, and migrate the PostgreSQL databases to Compute Engine.

**C.** Migrate the MySQL, Microsoft SQL Server, and PostgreSQL databases to Compute Engine, and migrate the Oracle databases to Bare Metal Solution for Oracle.

**D.** Migrate the MySQL, Microsoft SQL Server, and PostgreSQL databases to Cloud SQL, and migrate the Oracle databases to Bare Metal Solution for Oracle.

**Respuesta de la fuente:** D

**Explicación:** Cloud SQL is a fully managed service that supports MySQL, Microsoft SQL Server, and PostgreSQL, making it the ideal choice for these databases to minimize operational overhead.
Oracle Database is not supported on Cloud SQL; therefore, Bare Metal Solution for Oracle is the correct Google Cloud offering to host Oracle workloads with high performance and compatibility.
Option A and B are incorrect because Cloud SQL does not support Oracle. Option C is suboptimal because Compute Engine requires manual OS and database management, failing the requirement for a 'fully managed' solution where possible.

## Pregunta 82

Contexto: [topics:723](#topics-723)
You are managing a Cloud SQL for PostgreSQL instance in Google Cloud. You need to test the high availability of your Cloud SQL instance by performing a failover. You want to use the cloud command. What should you do?

**A.** Use gcloud sql instances failover <PrimaryInstanceName>.

**B.** Use gcloud sql instances failover <ReplicaInstanceName>.

**C.** Use gcloud sql instances promote-replica <PrimaryInstanceName>.

**D.** Use gcloud sql instances promote-replica <ReplicaInstanceName>.

**Respuesta de la fuente:** A

**Explicación:** To manually test high availability for a Cloud SQL instance with an automatic failover replica, you must use the 'failover' command targeting the primary instance. This forces a controlled switch from the primary to its secondary HA replica.
Options C and D are incorrect because 'promote-replica' is used for read replicas or manual promotions, not HA failovers. Option B is incorrect because the failover operation is initiated on the primary instance's configuration, not the replica.

## Pregunta 83

Contexto: [topics:723](#topics-723)
You use Python scripts to generate weekly SQL reports to assess the state of your databases and determine whether you need to reorganize tables or run statistics. You want to automate this report but need to minimize operational costs and overhead. What should you do?

**A.** Create a VM in Compute Engine, and run a cron job.

**B.** Create a Cloud Composer instance, and create a directed acyclic graph (DAG).

**C.** Create a Cloud Function, and call the Cloud Function using Cloud Scheduler.

**D.** Create a Cloud Function, and call the Cloud Function from a Cloud Tasks queue.

**Respuesta de la fuente:** C

**Explicación:** Cloud Functions provide a serverless environment that charges only for execution time, minimizing cost and eliminating the overhead of managing VMs (A) or orchestration clusters like Cloud Composer (B).

Between the remaining options, Cloud Scheduler is designed specifically for recurring time-based triggers (like a weekly report), whereas Cloud Tasks is intended for asynchronous task queues triggered by events rather than fixed schedules.

## Pregunta 84

Contexto: [topics:723](#topics-723)
Your company is using Cloud SQL for MySQL with an internal (private) IP address and wants to replicate some tables into BigQuery in near-real time for analytics and machine learning. You need to ensure that replication is fast and reliable and uses Google-managed services. What should you do?

**A.** Develop a custom data replication service to send data into BigQuery.

**B.** Use Cloud SQL federated queries.

**C.** Use Database Migration Service to replicate tables into BigQuery.

**D.** Use Datastream to capture changes, and use Dataflow to write those changes to BigQuery.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because Datastream is Google's managed Change Data Capture (CDC) service designed for near-real-time replication, and it integrates with Dataflow to write changes to BigQuery. This satisfies the requirement for Google-managed services while ensuring low latency.

Option C is incorrect because Database Migration Service (DMS) is primarily used for one-time or cutover migrations rather than continuous near-real-time CDC streaming to BigQuery as its primary supported pattern in this context. Option A violates the "Google-managed" constraint, and Option B (federated queries) offers lower throughput and higher latency compared to replication.

## Pregunta 85

Contexto: [topics:723](#topics-723)
You are designing a physician portal app in Node.js. This application will be used in hospitals and clinics that might have intermittent internet connectivity. If a connectivity failure occurs, the app should be able to query the cached data. You need to ensure that the application has scalability, strong consistency, and multi-region replication. What should you do?

**A.** Use Firestore and ensure that the PersistenceEnabled option is set to true.

**B.** Use Memorystore for Memcached.

**C.** Use Pub/Sub to synchronize the changes from the application to Cloud Spanner.

**D.** Use Table.read with the exactStaleness option to perform a read of rows in Cloud Spanner.

**Respuesta de la fuente:** A

**Explicación:** Cloud Firestore's offline persistence feature (enabled via `PersistenceEnabled`) automatically caches data locally, allowing the application to query data during intermittent connectivity failures as required. This solution also inherently provides automatic scalability and multi-region replication for high availability.

Option C (Pub/Sub with Spanner) is incorrect because Pub/Sub is an asynchronous messaging service that does not guarantee immediate strong consistency for read operations, making it unsuitable for the strict consistency requirements of a physician portal during active sessions.

## Pregunta 86

Contexto: [topics:723](#topics-723)
You manage a production MySQL database running on Cloud SQL at a retail company. You perform routine maintenance on Sunday at midnight when traffic is slow, but you want to skip routine maintenance during the year-end holiday shopping season. You need to ensure that your production system is available 24/7 during the holidays. What should you do?

**A.** Define a maintenance window on Sundays between 12 AM and 1 AM, and deny maintenance periods between November 1 and January 15.

**B.** Define a maintenance window on Sundays between 12 AM and 5 AM, and deny maintenance periods between November 1 and February 15.

**C.** Build a Cloud Composer job to start a maintenance window on Sundays between 12 AM and 1AM, and deny maintenance periods between November 1 and January 15.

**D.** Create a Cloud Scheduler job to start maintenance at 12 AM on Sundays. Pause the Cloud Scheduler job between November 1 and January 15.

**Respuesta de la fuente:** A

**Explicación:** Answer A is correct because Cloud SQL maintenance windows are strictly one hour in duration, matching the 12 AM to 1 AM slot, whereas Option B incorrectly suggests a 5-hour window. Additionally, deny maintenance periods can last up to 90 days; the November 1 to January 15 range in Option A is approximately 75 days (valid), while the November 1 to February 15 range in Option B exceeds the limit. Options C and D are incorrect because Cloud Composer and Cloud Scheduler cannot override or schedule built-in database maintenance, which must be configured directly in the Cloud SQL instance settings.

## Pregunta 87

Contexto: [topics:723](#topics-723)
You want to migrate an on-premises 100 TB Microsoft SQL Server database to Google Cloud over a 1 Gbps network link. You have 48 hours allowed downtime to migrate this database. What should you do? (Choose two.)

**A.** Use a change data capture (CDC) migration strategy.

**B.** Move the physical database servers from on-premises to Google Cloud.

**C.** Keep the network bandwidth at 1 Gbps, and then perform an offline data migration.

**D.** Increase the network bandwidth to 2 Gbps, and then perform an offline data migration.

**E.** Increase the network bandwidth to 10 Gbps, and then perform an offline data migration.

**Respuesta de la fuente:** A, E

**Explicación:** To migrate 100 TB within a 48-hour downtime window, an offline-only strategy using the existing 1 Gbps link (Choice C) is impossible as it requires ~27 days for transfer.
Choice E increases bandwidth to 10 Gbps, allowing the bulk data transfer to complete in approximately 22-30 hours.
Combined with Choice A (CDC), this hybrid approach transfers the majority of data offline while synchronizing incremental changes during the remaining downtime, satisfying the 48-hour constraint.

## Pregunta 88

Contexto: [topics:723](#topics-723)
You need to provision several hundred Cloud SQL for MySQL instances for multiple project teams over a one-week period. You must ensure that all instances adhere to company standards such as instance naming conventions, database flags, and tags. What should you do?

**A.** Automate instance creation by writing a Dataflow job.

**B.** Automate instance creation by setting up Terraform scripts.

**C.** Create the instances using the Google Cloud Console UI.

**D.** Create clones from a template Cloud SQL instance.

**Respuesta de la fuente:** B

**Explicación:** Terraform is the industry-standard Infrastructure as Code (IaC) tool for Google Cloud, allowing you to define instance specifications, naming conventions, and tags in reusable configuration files. This ensures consistency across hundreds of instances while automating the provisioning process efficiently.

Dataflow is designed for data processing pipelines, not infrastructure provisioning, making it the incorrect tool for this task.

## Pregunta 89

Contexto: [topics:723](#topics-723)
Your organization is migrating 50 TB Oracle databases to Bare Metal Solution for Oracle. Database backups must be available for quick restore. You also need to have backups available for 5 years. You need to design a cost-effective architecture that meets a recovery time objective (RTO) of 2 hours and recovery point objective (RPO) of 15 minutes. What should you do?

**A.** 1 Create the database on a Bare Metal Solution server with the database running on flash storage.
2. Keep a local backup copy on all flash storage.
3. Keep backups older than one day stored in Actifio OnVault storage.

**B.** 1 Create the database on a Bare Metal Solution server with the database running on flash storage.
2. Keep a local backup copy on standard storage.
3. Keep backups older than one day stored in Actifio OnVault storage.

**C.** 1. Create the database on a Bare Metal Solution server with the database running on flash storage.
2. Keep a local backup copy on standard storage.
3. Use the Oracle Recovery Manager (RMAN) backup utility to move backups older than one day to a Coldline Storage bucket.

**D.** 1. Create the database on a Bare Metal Solution server with the database running on flash storage.
2. Keep a local backup copy on all flash storage.
3. Use the Oracle Recovery Manager (RMAN) backup utility to move backups older than one day to an Archive Storage bucket.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Actifio OnVault is the integrated, purpose-built solution for Bare Metal Solution backups, offering the performance required to meet the strict RTO/RPO while handling long-term retention efficiently.
Storing recent local backups on standard storage (rather than flash) provides a cost-effective buffer that balances speed and expense without over-provisioning expensive NVMe capacity.
Option D is incorrect because moving backups via RMAN to generic Archive Storage lacks the integrated recovery orchestration and performance guarantees of Actifio, making it harder to consistently meet the 2-hour RTO.

## Pregunta 90

Contexto: [topics:723](#topics-723)
You are a DBA on a Cloud Spanner instance with multiple databases. You need to assign these privileges to all members of the application development team on a specific database:

Can read tables, views, and DDL -

Can write rows to the tables -

Can add columns and indexes -

Cannot drop the database -
What should you do?

**A.** Assign the Cloud Spanner Database Reader and Cloud Spanner Backup Writer roles.

**B.** Assign the Cloud Spanner Database Admin role.

**C.** Assign the Cloud Spanner Database User role.

**D.** Assign the Cloud Spanner Admin role.

**Respuesta de la fuente:** C

**Explicación:** The Cloud Spanner Database User role (Option C) is the correct choice because it grants permissions to read/write data and perform DDL operations like adding columns or indexes, without granting administrative privileges to drop the database.
Options B (Database Admin) and D (Admin) are incorrect as they provide excessive privileges, including the ability to drop the database, violating the least-privilege requirement.
Option A is incorrect because Reader roles cannot write data or modify schema.

## Pregunta 91

Contexto: [topics:723](#topics-723)
Your project is using Bigtable to store data that should not be accessed from the public internet under any circumstances, even if the requestor has a valid service account key. You need to secure access to this data. What should you do?

**A.** Use Identity and Access Management (IAM) for Bigtable access control.

**B.** Use VPC Service Controls to create a trusted network for the Bigtable service.

**C.** Use customer-managed encryption keys (CMEK).

**D.** Use Google Cloud Armor to add IP addresses to an allowlist.

**Respuesta de la fuente:** B

**Explicación:** VPC Service Controls create a security perimeter that restricts access to Bigtable resources only from within trusted VPC networks, preventing data exfiltration even if valid credentials (like service account keys) are compromised or used from outside the perimeter.
Option A is incorrect because IAM controls identity-based permissions but does not inherently block access attempts originating from the public internet if the requester possesses valid credentials.

## Pregunta 92

Contexto: [topics:723](#topics-723)
Your organization has a ticketing system that needs an online marketing analytics and reporting application. You need to select a relational database that can manage hundreds of terabytes of data to support this new application. Which database should you use?

**A.** Cloud SQL

**B.** BigQuery

**C.** Cloud Spanner

**D.** Bigtable

**Respuesta de la fuente:** B

**Explicación:** BigQuery is the correct choice because it is a fully managed serverless data warehouse specifically designed for analytics and reporting on massive datasets (hundreds of terabytes). While Cloud Spanner is a relational database, BigQuery offers superior scalability and cost-efficiency for read-heavy analytical workloads compared to transactional databases. Option C is incorrect because, although Spanner supports SQL and scales well, it is optimized for low-latency transactions rather than large-scale analytics.

## Pregunta 93

Contexto: [topics:723](#topics-723)
You are designing for a write-heavy application. During testing, you discover that the write workloads are performant in a regional Cloud Spanner instance but slow down by an order of magnitude in a multi-regional instance. You want to make the write workloads faster in a multi-regional instance. What should you do?

**A.** Place the bulk of the read and write workloads closer to the default leader region.

**B.** Use staleness of at least 15 seconds.

**C.** Add more read-write replicas.

**D.** Keep the total CPU utilization under 45% in each region.

**Respuesta de la fuente:** A

**Explicación:** Cloud Spanner designates one region as the default leader for a multi-regional instance, which handles commit coordination. Placing write-heavy workloads closer to this leader region minimizes network latency and ensures optimal write performance.
Option B is incorrect because staleness settings apply only to read queries, not writes. Option C is invalid because you cannot arbitrarily add more read-write replicas in Spanner (you configure regions at instance creation), and Option D refers to a best practice for high-priority CPU usage thresholds rather than the architectural fix for write latency.

## Pregunta 94

Contexto: [topics:723](#topics-723)
Your company wants to migrate an Oracle-based application to Google Cloud. The application team currently uses Oracle Recovery Manager (RMAN) to back up the database to tape for long-term retention (LTR). You need a cost-effective backup and restore solution that meets a 2-hour recovery time objective (RTO) and a 15-minute recovery point objective (RPO). What should you do?

**A.** Migrate the Oracle databases to Bare Metal Solution for Oracle, and store backups on tapes on-premises.

**B.** Migrate the Oracle databases to Bare Metal Solution for Oracle, and use Actifio to store backup files on Cloud Storage using the Nearline Storage class.

**C.** Migrate the Oracle databases to Bare Metal Solution for Oracle, and back up the Oracle databases to Cloud Storage using the Standard Storage class.

**D.** Migrate the Oracle databases to Compute Engine, and store backups on tapes on-premises.

**Respuesta de la fuente:** B

**Explicación:** Bare Metal Solution (BMS) is the correct hosting environment because it supports Oracle licensing and performance requirements, whereas Compute Engine does not support full Oracle database functionality. Actifio (now Google Cloud Backup and DR) provides efficient backup management to Cloud Storage, which meets the RTO/RPO goals while avoiding on-premises tape dependencies. Nearline storage is selected over Standard storage to reduce long-term retention costs, directly addressing the 'cost-effective' requirement in the prompt.

## Pregunta 95

Contexto: [topics:723](#topics-723)
You are migrating a telehealth care company's on-premises data center to Google Cloud. The migration plan specifies:
PostgreSQL databases must be migrated to a multi-region backup configuration with cross-region replicas to allow restore and failover in multiple scenarios.
MySQL databases handle personally identifiable information (PII) and require data residency compliance at the regional level.
You want to set up the environment with minimal administrative effort. What should you do?

**A.** Set up Cloud Logging and Cloud Monitoring with Cloud Functions to send an alert every time a new database instance is created, and manually validate the region.

**B.** Set up different organizations for each database type, and apply policy constraints at the organization level.

**C.** Set up Pub/Sub to ingest data from Cloud Logging, send an alert every time a new database instance is created, and manually validate the region.

**D.** Set up different projects for PostgreSQL and MySQL databases, and apply organizational policy constraints at a project level.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it leverages Google Cloud's organizational policy constraints at the project level to enforce data residency and compliance requirements automatically. This approach ensures that MySQL instances are restricted to specific regions without manual intervention, satisfying the 'minimal administrative effort' requirement by preventing non-compliant configurations proactively.

The most tempting alternative, Option B, is incorrect because creating separate organizations for different database types is excessive overhead; Google Cloud recommends using a single organization with folders and projects to manage hierarchy and policies efficiently.

## Pregunta 96

Contexto: [topics:723](#topics-723)
You have a Cloud SQL instance (DB-1) with two cross-region read replicas (DB-2 and DB-3). During a business continuity test, the primary instance (DB-1) was taken offline and a replica (DB-2) was promoted. The test has concluded and you want to return to the pre-test configuration. What should you do?

**A.** Bring DB-1 back online.

**B.** Delete DB-1, and re-create DB-1 as a read replica in the same region as DB-1.

**C.** Delete DB-2 so that DB-1 automatically reverts to the primary instance.

**D.** Create DB-4 as a read replica in the same region as DB-1, and promote DB-4 to primary.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it facilitates a proper 'failback' procedure by creating a new primary instance in the original region. This ensures the architecture returns to its pre-test state with a primary in that specific location, whereas options A and C leave DB-2 as the primary or result in a single-instance configuration lacking the required replica redundancy. Option B is incorrect because deleting the original primary results in data loss of any writes made during the test period and does not cleanly restore the exact previous topology.

## Pregunta 97

Contexto: [topics:723](#topics-723)
Your team is building a new inventory management application that will require read and write database instances in multiple Google Cloud regions around the globe. Your database solution requires 99.99% availability and global transactional consistency. You need a fully managed backend relational database to store inventory changes. What should you do?

**A.** Use Bigtable.

**B.** Use Firestore.

**C.** Use Cloud SQL for MySQL

**D.** Use Cloud Spanner.

**Respuesta de la fuente:** D

**Explicación:** Cloud Spanner is the only GCP service that provides a fully managed relational database with strong global transactional consistency and multi-region availability meeting the 99.99% SLA requirement.
Bigtable and Firestore are NoSQL databases, violating the explicit requirement for a relational backend.
Cloud SQL supports high availability but does not provide native global multi-region distribution with strong transactional consistency across all instances.

## Pregunta 98

Contexto: [topics:723](#topics-723)
You are the database administrator of a Cloud SQL for PostgreSQL instance that has pgaudit disabled. Users are complaining that their queries are taking longer to execute and performance has degraded over the past few months. You need to collect and analyze query performance data to help identity slow-running queries. What should you do?

**A.** View Cloud SQL operations to view historical query information.

**B.** White a Logs Explorer query to identify database queries with high execution times.

**C.** Review application logs to identify database calls.

**D.** Use the Query Insights dashboard to identify high execution times.

**Respuesta de la fuente:** D

**Explicación:** Query Insights is the dedicated Google Cloud feature designed to automatically analyze SQL queries for performance issues, such as high execution times and latency, without requiring changes to the database configuration like enabling pgaudit.
Option B is incorrect because standard Cloud Logging does not capture detailed query statistics or execution plans by default unless specific audit logging features are enabled, which contradicts the premise that pgaudit is disabled.

## Pregunta 99

Contexto: [topics:723](#topics-723)
You are configuring a brand new PostgreSQL database instance in Cloud SQL. Your application team wants to have an optimal and highly available environment with automatic failover to avoid any unplanned outage. What should you do?

**A.** Create one regional Cloud SQL instance with a read replica in another region.

**B.** Create one regional Cloud SQL instance in one zone with a standby instance in another zone in the same region.

**C.** Create two read-write Cloud SQL instances in two different zones with a standby instance in another region.

**D.** Create two read-write Cloud SQL instances in two different regions with a standby instance in another zone.

**Respuesta de la fuente:** B

**Explicación:** Cloud SQL High Availability (HA) is achieved by configuring a regional instance that maintains an automatic failover replica in a different zone within the same region. This setup ensures synchronous replication and automatic promotion of the standby to primary if the main instance fails, meeting the requirement for optimal HA without manual intervention.

Option A is incorrect because read replicas are read-only by default and do not support automatic failover; promoting them requires manual steps, leading to potential downtime.

## Pregunta 100

Contexto: [topics:723](#topics-723)
During an internal audit, you realized that one of your Cloud SQL for MySQL instances does not have high availability (HA) enabled. You want to follow Google-recommended practices to enable HA on your existing instance. What should you do?

**A.** Create a new Cloud SQL for MySQL instance, enable HA, and use the export and import option to migrate your data.

**B.** Create a new Cloud SQL for MySQL instance, enable HA, and use Cloud Data Fusion to migrate your data.

**C.** Use the gcloud instances patch command to update your existing Cloud SQL for MySQL instance.

**D.** Shut down your existing Cloud SQL for MySQL instance, and enable HA.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because you can enable High Availability on an existing Cloud SQL for MySQL instance by patching its configuration (setting availability-type to REGIONAL) while it remains online, avoiding data migration or significant downtime.
Options A and B are incorrect because they involve unnecessary and complex data migration steps instead of simply updating the instance settings.
Option D is incorrect because you cannot modify the instance configuration, such as enabling HA, while the instance is shut down; the instance must be running to accept updates.

## Pregunta 101

Contexto: [topics:723](#topics-723)
You are managing a set of Cloud SQL databases in Google Cloud. Regulations require that database backups reside in the region where the database is created. You want to minimize operational costs and administrative effort. What should you do?

**A.** Configure the automated backups to use a regional Cloud Storage bucket as a custom location.

**B.** Use the default configuration for the automated backups location.

**C.** Disable automated backups, and create an on-demand backup routine to a regional Cloud Storage bucket.

**D.** Disable automated backups, and configure serverless exports to a regional Cloud Storage bucket.

**Respuesta de la fuente:** A

**Explicación:** By default, Cloud SQL stores automated backups in a multi-region bucket, which violates the regulation requiring backups to reside in the same region as the database.
To comply while minimizing administrative effort, you must explicitly configure the backup location to a regional Cloud Storage bucket (or select the regional option in the console), rather than disabling automation or relying on default settings.

## Pregunta 102

Contexto: [topics:723](#topics-723)
Your ecommerce application connecting to your Cloud SQL for SQL Server is expected to have additional traffic due to the holiday weekend. You want to follow Google-recommended practices to set up alerts for CPU and memory metrics so you can be notified by text message at the first sign of potential issues. What should you do?

**A.** Use a Cloud Function to pull CPU and memory metrics from your Cloud SQL instance and to call a custom service to send alerts.

**B.** Use Error Reporting to monitor CPU and memory metrics and to configure SMS notification channels.

**C.** Use Cloud Logging to set up a log sink for CPU and memory metrics and to configure a sink destination to send a message to Pub/Sub.

**D.** Use Cloud Monitoring to set up an alerting policy for CPU and memory metrics and to configure SMS notification channels.

**Respuesta de la fuente:** D

**Explicación:** Cloud Monitoring is the designated Google Cloud service for collecting metrics like CPU and memory usage and creating alerting policies with specific notification channels, including SMS.

Options A, B, and C are incorrect because they propose building custom solutions or using services (Error Reporting, Logging) that do not natively support direct SMS notifications based on infrastructure metric thresholds.

## Pregunta 103

Contexto: [topics:723](#topics-723)
You finished migrating an on-premises MySQL database to Cloud SQL. You want to ensure that the daily export of a table, which was previously a cron job running on the database server, continues. You want the solution to minimize cost and operations overhead. What should you do?

**A.** Use Cloud Scheduler and Cloud Functions to run the daily export.

**B.** Create a streaming Datatlow job to export the table.

**C.** Set up Cloud Composer, and create a task to export the table daily.

**D.** Run the cron job on a Compute Engine instance to continue the export.

**Respuesta de la fuente:** A

**Explicación:** Cloud Scheduler and Cloud Functions provide a serverless, event-driven architecture that minimizes both operational overhead and cost by charging only for execution time, unlike running a persistent Compute Engine instance (Option D).

Cloud Composer (Option C) is a managed Airflow service designed for complex workflow orchestration, which introduces unnecessary management overhead and cost for a simple daily export task.

Dataflow (Option B) is intended for large-scale batch and streaming data processing pipelines, making it over-engineered and costly for a single table's daily export.

## Pregunta 104

Contexto: [topics:723](#topics-723)
Your organization needs to migrate a critical, on-premises MySQL database to Cloud SQL for MySQL. The on-premises database is on a version of MySQL that is supported by Cloud SQL and uses the InnoDB storage engine. You need to migrate the database while preserving transactions and minimizing downtime. What should you do?

**A.** 1. Use Database Migration Service to connect to your on-premises database, and choose continuous replication.
2. After the on-premises database is migrated, promote the Cloud SQL for MySQL instance, and connect applications to your Cloud SQL instance.

**B.** 1. Build a Cloud Data Fusion pipeline for each table to migrate data from the on-premises MySQL database to Cloud SQL for MySQL.
2. Schedule downtime to run each Cloud Data Fusion pipeline.
3. Verify that the migration was successful.
4. Re-point the applications to the Cloud SQL for MySQL instance.

**C.** 1. Pause the on-premises applications.
2. Use the mysqldump utility to dump the database content in compressed format.
3. Run gsutil –m to move the dump file to Cloud Storage.
4. Use the Cloud SQL for MySQL import option.
5. After the import operation is complete, re-point the applications to the Cloud SQL for MySQL instance.

**D.** 1 Pause the on-premises applications.
2. Use the mysqldump utility to dump the database content in CSV format.
3. Run gsutil –m to move the dump file to Cloud Storage.
4. Use the Cloud SQL for MySQL import option.
5. After the import operation is complete, re-point the applications to the Cloud SQL for MySQL instance.

**Respuesta de la fuente:** A

**Explicación:** Database Migration Service (DMS) with continuous replication is the only option that preserves transactions and minimizes downtime by keeping the on-premises database and Cloud SQL in sync during the migration process.
Options B, C, and D all require pausing applications or scheduling significant downtime, which violates the requirement to minimize disruption.

## Pregunta 105

Contexto: [topics:723](#topics-723)
Your company is developing a global ecommerce website on Google Cloud. Your development team is working on a shopping cart service that is durable and elastically scalable with live traffic. Business disruptions from unplanned downtime are expected to be less than 5 minutes per month. In addition, the application needs to have very low latency writes. You need a data storage solution that has high write throughput and provides 99.99% uptime. What should you do?

**A.** Use Cloud SQL for data storage.

**B.** Use Cloud Spanner for data storage.

**C.** Use Memorystore for data storage.

**D.** Use Bigtable for data storage.

**Respuesta de la fuente:** B

**Explicación:** Cloud Spanner is the correct choice because it provides globally distributed strong consistency and SQL support, which aligns with the "global" ecommerce requirement and the need for relational data modeling (shopping carts). While Bigtable offers high throughput, it lacks native SQL join capabilities required for complex ecommerce logic and has a lower default SLA (99.95% vs 99.99%).

## Pregunta 106

Contexto: [topics:723](#topics-723)
Your organization has hundreds of Cloud SQL for MySQL instances. You want to follow Google-recommended practices to optimize platform costs. What should you do?

**A.** Use Query Insights to identify idle instances.

**B.** Remove inactive user accounts.

**C.** Run the Recommender API to identify overprovisioned instances.

**D.** Build indexes on heavily accessed tables.

**Respuesta de la fuente:** C

**Explicación:** The Google Cloud Recommender API provides data-driven insights specifically designed to optimize costs by identifying overprovisioned resources that are using more CPU, memory, or disk than necessary.
While Query Insights (A) focuses on query performance and indexing (D) improves throughput rather than directly reducing instance configuration costs, the Recommender is the designated Google-recommended tool for cost optimization via right-sizing.
Option B addresses security hygiene, not platform cost optimization.

## Pregunta 107

Contexto: [topics:723](#topics-723)
Your organization is running a critical production database on a virtual machine (VM) on Compute Engine. The VM has an ext4-formatted persistent disk for data files. The database will soon run out of storage space. You need to implement a solution that avoids downtime. What should you do?

**A.** In the Google Cloud Console, increase the size of the persistent disk, and use the resize2fs command to extend the disk.

**B.** In the Google Cloud Console, increase the size of the persistent disk, and use the fdisk command to verify that the new space is ready to use

**C.** In the Google Cloud Console, create a snapshot of the persistent disk, restore the snapshot to a new larger disk, unmount the old disk, mount the new disk, and restart the database service.

**D.** In the Google Cloud Console, create a new persistent disk attached to the VM, and configure the database service to move the files to the new disk.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Google Cloud Persistent Disks can be resized online without detaching the disk, and using `resize2fs` extends the ext4 filesystem to fill the new space without requiring a VM reboot or database restart.
Option B is incorrect because `fdisk` is a partitioning tool; it does not resize the filesystem itself, so the additional space would remain unusable by the operating system.

## Pregunta 108

Contexto: [topics:723](#topics-723)
You want to migrate your on-premises PostgreSQL database to Compute Engine. You need to migrate this database with the minimum downtime possible. What should you do?

**A.** Perform a full backup of your on-premises PostgreSQL, and then, in the migration window, perform an incremental backup.

**B.** Create a read replica on Cloud SQL, and then promote it to a read/write standalone instance.

**C.** Use Database Migration Service to migrate your database.

**D.** Create a hot standby on Compute Engine, and use PgBouncer to switch over the connections.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because the target environment is Compute Engine (IaaS), requiring manual setup of PostgreSQL replication rather than using managed services like Cloud SQL. Options B and C are invalid because they rely on managed database products (Cloud SQL/AlloyDB) instead of raw VMs on Compute Engine. Option A involves a full backup followed by an incremental, which typically requires a longer maintenance window for restoration compared to streaming replication with a hot standby. Using a hot standby with PgBouncer allows for minimal downtime by keeping data synchronized in near-real-time and rapidly switching connection pools during the cutover.

## Pregunta 109

Contexto: [topics:723](#topics-723)
You have an application that sends banking events to Bigtable cluster-a in us-east. You decide to add cluster-b in us-central1. Cluster-a replicates data to cluster-b. You need to ensure that Bigtable continues to accept read and write requests if one of the clusters becomes unavailable and that requests are routed automatically to the other cluster. What deployment strategy should you use?

**A.** Use the default app profile with single-cluster routing.

**B.** Use the default app profile with multi-cluster routing.

**C.** Create a custom app profile with multi-cluster routing.

**D.** Create a custom app profile with single-cluster routing.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google Bigtable instances created with a single cluster default to single-cluster routing for backward compatibility.
Since the scenario involves adding a second cluster after initial creation, the default profile remains locked to single-cluster behavior and does not automatically switch to multi-cluster routing.
To achieve automatic failover and load balancing across clusters (multi-cluster routing), you must explicitly create a custom app profile configured for this purpose, as modifying the default profile is generally discouraged in favor of creating new profiles.

## Pregunta 110

Contexto: [topics:723](#topics-723)
Your organization works with sensitive data that requires you to manage your own encryption keys. You are working on a project that stores that data in a Cloud SQL database. You need to ensure that stored data is encrypted with your keys. What should you do?

**A.** Export data periodically to a Cloud Storage bucket protected by Customer-Supplied Encryption Keys.

**B.** Use Cloud SQL Auth proxy.

**C.** Connect to Cloud SQL using a connection that has SSL encryption.

**D.** Use customer-managed encryption keys with Cloud SQL.

**Respuesta de la fuente:** D

**Explicación:** The requirement is to encrypt stored data using your own keys, which directly maps to using Customer-Managed Encryption Keys (CMEK) with Cloud SQL. Options B and C only secure data in transit via TLS/SSL, while Option A involves exporting data rather than securing the database itself.

## Pregunta 111

Contexto: [topics:723](#topics-723)
Your team is building an application that stores and analyzes streaming time series financial data. You need a database solution that can perform time series-based scans with sub-second latency. The solution must scale into the hundreds of terabytes and be able to write up to 10k records per second and read up to 200 MB per second. What should you do?

**A.** Use Firestore.

**B.** Use Bigtable

**C.** Use BigQuery.

**D.** Use Cloud Spanner.

**Respuesta de la fuente:** B

**Explicación:** Google Bigtable is a wide-column NoSQL database specifically designed for low-latency time-series data and massive scalability, directly matching the requirements of sub-second latency, hundreds of terabytes storage, and high throughput (10k writes/s, 200 MB reads/s).
BigQuery is optimized for analytical queries on large datasets rather than the low-latency transactional access and real-time scanning required here, making it unsuitable for this specific workload.

## Pregunta 112

Contexto: [topics:723](#topics-723)
You are designing a new gaming application that uses a highly transactional relational database to store player authentication and inventory data in Google Cloud. You want to launch the game in multiple regions. What should you do?

**A.** Use Cloud Spanner to deploy the database.

**B.** Use Bigtable with clusters in multiple regions to deploy the database

**C.** Use BigQuery to deploy the database

**D.** Use Cloud SQL with a regional read replica to deploy the database.

**Respuesta de la fuente:** A

**Explicación:** Cloud Spanner is the correct choice because it is a globally distributed, strongly consistent relational database service designed for high-volume transactional (OLTP) workloads across multiple regions.
Bigtable and BigQuery are not suitable as they serve non-relational/NoSQL and analytical (OLAP) purposes respectively, while Cloud SQL lacks native multi-region write scalability and strong consistency guarantees.

## Pregunta 113

Contexto: [topics:723](#topics-723)
You are designing a database strategy for a new web application in one region. You need to minimize write latency. What should you do?

**A.** Use Cloud SQL with cross-region replicas.

**B.** Use high availability (HA) Cloud SQL with multiple zones.

**C.** Use zonal Cloud SQL without high availability (HA).

**D.** Use Cloud Spanner in a regional configuration.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because disabling High Availability (HA) in Cloud SQL eliminates the overhead of synchronous replication to a standby instance. In an HA configuration, write operations must wait for acknowledgment from the secondary node across zones, which inherently increases latency compared to a single-zone instance where writes commit immediately to the local disk.

Option D (Cloud Spanner) is incorrect because it uses distributed consensus protocols (Paxos) across multiple nodes, which introduces higher latency than a simple single-node write. Options A and B also incur replication overhead, making them suboptimal for minimizing latency.

## Pregunta 114

Contexto: [topics:723](#topics-723)
You are running a large, highly transactional application on Oracle Real Application Cluster (RAC) that is multi-tenant and uses shared storage. You need a solution that ensures high-performance throughput and a low-latency connection between applications and databases. The solution must also support existing Oracle features and provide ease of migration to Google Cloud. What should you do?

**A.** Migrate to Compute Engine.

**B.** Migrate to Bare Metal Solution for Oracle.

**C.** Migrate to Google Kubernetes Engine (GKE)

**D.** Migrate to Google Cloud VMware Engine

**Respuesta de la fuente:** B

**Explicación:** Oracle Real Application Clusters (RAC) requires specific hardware capabilities, such as Shared Disk Systems and specialized interconnects, which are explicitly supported by Bare Metal Solution for Oracle. Compute Engine does not support Oracle licensing or RAC configurations due to licensing restrictions and lack of native shared storage integration.
Reference: Google Cloud Bare Metal Solution documentation on Oracle RAC support.

## Pregunta 115

Contexto: [topics:723](#topics-723)
You are choosing a new database backend for an existing application. The current database is running PostgreSQL on an on-premises VM and is managed by a database administrator and operations team. The application data is relational and has light traffic. You want to minimize costs and the migration effort for this application. What should you do?

**A.** Migrate the existing database to Firestore.

**B.** Migrate the existing database to Cloud SQL for PostgreSQL.

**C.** Migrate the existing database to Cloud Spanner.

**D.** Migrate the existing database to PostgreSQL running on Compute Engine.

**Respuesta de la fuente:** B

**Explicación:** Cloud SQL for PostgreSQL is a managed service that is fully compatible with the existing PostgreSQL database, ensuring the lowest migration effort due to identical schema and query support. It also minimizes costs compared to Cloud Spanner, which is over-engineered for light traffic, or Compute Engine, which requires manual OS and DB maintenance.
Firestore is incorrect because it is a NoSQL document database, requiring significant application code changes and data modeling efforts.

## Pregunta 116

Contexto: [topics:723](#topics-723)
Your organization is currently updating an existing corporate application that is running in another public cloud to access managed database services in Google Cloud. The application will remain in the other public cloud while the database is migrated to Google Cloud. You want to follow Google-recommended practices for authentication. You need to minimize user disruption during the migration. What should you do?

**A.** Use workload identity federation to impersonate a service account.

**B.** Ask existing users to set their Google password to match their corporate password.

**C.** Migrate the application to Google Cloud, and use Identity and Access Management (IAM).

**D.** Use Google Workspace Password Sync to replicate passwords into Google Cloud.

**Respuesta de la fuente:** A

**Explicación:** Workload identity federation allows external workloads (in another cloud) to access Google Cloud resources using short-lived tokens, eliminating the need to manage and rotate service account keys. This approach minimizes security risk and avoids user disruption by handling authentication transparently between systems without requiring credential changes.

Option B and D involve changing or syncing user passwords, which causes significant user disruption. Option C contradicts the requirement to keep the application in the other public cloud.

## Pregunta 117

Contexto: [topics:723](#topics-723)
You are configuring the networking of a Cloud SQL instance. The only application that connects to this database resides on a Compute Engine VM in the same project as the Cloud SQL instance. The VM and the Cloud SQL instance both use the same VPC network, and both have an external (public) IP address and an internal (private) IP address. You want to improve network security. What should you do?

**A.** Disable and remove the internal IP address assignment.

**B.** Disable both the external IP address and the internal IP address, and instead rely on Private Google Access.

**C.** Specify an authorized network with the CIDR range of the VM.

**D.** Disable and remove the external IP address assignment.

**Respuesta de la fuente:** D

**Explicación:** Since the VM and Cloud SQL instance reside in the same VPC, they can communicate securely via their internal IP addresses without traversing the public internet. Disabling the external IP address removes unnecessary attack surface exposed to the internet, directly improving network security. Option C is incorrect because Authorized Networks are designed for external access over HTTPS/SSL; using them for resources already within the same private VPC bypasses the inherent security benefits of the private network.

## Pregunta 118

Contexto: [topics:723](#topics-723)
You are managing two different applications: Order Management and Sales Reporting. Both applications interact with the same Cloud SQL for MySQL database. The Order Management application reads and writes to the database 24/7, but the Sales Reporting application is read-only. Both applications need the latest data. You need to ensure that the Performance of the Order Management application is not affected by the Sales Reporting application. What should you do?

**A.** Create a read replica for the Sales Reporting application.

**B.** Create two separate databases in the instance, and perform dual writes from the Order Management application.

**C.** Use a Cloud SQL federated query for the Sales Reporting application.

**D.** Queue up all the requested reports in PubSub, and execute the reports at night.

**Respuesta de la fuente:** A

**Explicación:** Creating a read replica is the standard architectural pattern to offload read-heavy workloads, such as reporting, from the primary database instance. This ensures that resource-intensive SELECT queries from the Sales Reporting application do not compete with the 24/7 write operations of the Order Management application for CPU or I/O on the primary node.

Option B is incorrect because it introduces unnecessary complexity and potential data consistency issues by requiring dual writes within the application logic, which is not needed when a read replica provides immediate (near-real-time) data synchronization.

## Pregunta 119

Contexto: [topics:723](#topics-723)
You are the DBA of an online tutoring application that runs on a Cloud SQL for PostgreSQL database. You are testing the implementation of the cross-regional failover configuration. The database in region R1 fails over successfully to region R2, and the database becomes available for the application to process data. During testing, certain scenarios of the application work as expected in region R2, but a few scenarios fail with database errors. The application-related database queries, when executed in isolation from Cloud SQL for PostgreSQL in region R2, work as expected. The application performs completely as expected when the database fails back to region R1. You need to identify the cause of the database errors in region R2. What should you do?

**A.** Determine whether the versions of Cloud SQL for PostgreSQL in regions R1 and R2 are different.

**B.** Determine whether the database patches of Cloud SQI for PostgreSQL in regions R1 and R2 are different.

**C.** Determine whether the failover of Cloud SQL for PostgreSQL from region R1 to region R2 is in progress or has completed successfully.

**D.** Determine whether Cloud SQL for PostgreSQL in region R2 is a near-real-time copy of region R1 but not an exact copy.

**Respuesta de la fuente:** D

**Explicación:** Cross-region failover in Cloud SQL involves asynchronous replication, meaning the replica (Region R2) is a near-real-time copy but may lag slightly behind the primary (Region R1). This data gap can cause application queries dependent on very recent transactions to fail with errors in R2, even though the instance itself is online. Options A and B are incorrect because Cloud SQL manages version compatibility and patching automatically for HA pairs, and Option C is invalid because the scenario states the failover completed successfully.

## Pregunta 120

Contexto: [topics:723](#topics-723)
Your company wants to migrate its MySQL, PostgreSQL, and Microsoft SQL Server on-premises databases to Google Cloud. You need a solution that provides near-zero downtime, requires no application changes, and supports change data capture (CDC). What should you do?

**A.** Use the native export and import functionality of the source database.

**B.** Create a database on Google Cloud, and use database links to perform the migration.

**C.** Create a database on Google Cloud, and use Dataflow for database migration.

**D.** Use Database Migration Service.

**Respuesta de la fuente:** D

**Explicación:** Database Migration Service (DMS) is the purpose-built Google Cloud solution for migrating on-premises databases like MySQL, PostgreSQL, and SQL Server with minimal downtime.
It natively supports Change Data Capture (CDC) to continuously replicate data changes during migration, satisfying the near-zero downtime requirement without requiring application code modifications.
Options A and B involve manual or legacy methods that typically require significant downtime and do not offer automated CDC capabilities.

## Pregunta 121

Contexto: [topics:723](#topics-723)
You are managing a Cloud SQL for PostgreSQL instance in Google Cloud. You have a primary instance in region 1 and a read replica in region 2. After a failure of region 1, you need to make the Cloud SQL instance available again. You want to minimize data loss and follow Google-recommended practices. What should you do?

**A.** Restore the Cloud SQL instance from the automatic backups in region 3.

**B.** Restore the Cloud SQL instance from the automatic backups in another zone in region 1.

**C.** Check "Lag Bytes" in the monitoring dashboard for the primary instance in the read replica instance. Check the replication status using pg_catalog.pg_last_wal_receive_lsn(). Then, fail over to region 2 by promoting the read replica instance.

**D.** Check your instance operational log for the automatic failover status. Look for time, type, and status of the operations. If the failover operation is successful, no action is necessary. Otherwise, manually perform gcloud sql instances failover <PrimaryInstanceName>.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because promoting an existing cross-region read replica is the recommended disaster recovery procedure to minimize downtime and data loss compared to restoring from backups. Checking replication lag ensures you understand potential data loss before promotion, which is a critical best practice.
Options A and B involve restoring from backups, which results in significant RTO/RPO penalties compared to failover. Option D refers to automatic high availability (within-region) failover mechanisms or manual commands that do not address the specific scenario of promoting a cross-region replica after a regional failure.

## Pregunta 122

Contexto: [topics:723](#topics-723)
You need to issue a new server certificate because your old one is expiring. You need to avoid a restart of your Cloud SQL for MySQL instance. What should you do in your Cloud SQL instance?

**A.** Issue a rollback, and download your server certificate.

**B.** Create a new client certificate, and download it.

**C.** Create a new server certificate, and download it.

**D.** Reset your SSL configuration, and download your server certificate.

**Respuesta de la fuente:** C

**Explicación:** According to Google Cloud SQL documentation, rotating an expiring server certificate is done by generating a new server certificate for the instance.
This action allows the certificate to be updated without requiring a restart of the Cloud SQL instance.
Option D is incorrect because resetting the SSL configuration or enabling SSL enforcement typically triggers a mandatory instance restart.

## Pregunta 123

Contexto: [topics:723](#topics-723)
Your company is migrating all legacy applications to Google Cloud. All on-premises applications are using legacy Oracle 12c databases with Oracle Real Application Cluster (RAC) for high availability (HA) and Oracle Data Guard for disaster recovery. You need a solution that requires minimal code changes, provides the same high availability you have today on-premises, and supports a low latency network for migrated legacy applications. What should you do?

**A.** Migrate the databases to Cloud Spanner.

**B.** Migrate the databases to Cloud SQL, and enable a standby database.

**C.** Migrate the databases to Compute Engine using regional persistent disks.

**D.** Migrate the databases to Bare Metal Solution for Oracle.

**Respuesta de la fuente:** D

**Explicación:** Bare Metal Solution for Oracle is the correct choice because it allows you to run Oracle RAC exactly as configured on-premises, requiring zero code changes and maintaining identical high availability architecture.
Options like Cloud SQL or Compute Engine do not support Oracle RAC natively, which would necessitate significant refactoring of the application logic to handle different HA mechanisms.

## Pregunta 124

Contexto: [topics:723](#topics-723)
Your company is evaluating Google Cloud database options for a mission-critical global payments gateway application. The application must be available 24/7 to users worldwide, horizontally scalable, and support open source databases. You need to select an automatically shardable, fully managed database with 99.999% availability and strong transactional consistency. What should you do?

**A.** Select Bare Metal Solution for Oracle.

**B.** Select Cloud SQL.

**C.** Select Bigtable.

**D.** Select Cloud Spanner.

**Respuesta de la fuente:** D

**Explicación:** Cloud Spanner is the only Google Cloud database that combines horizontal scalability across multiple regions with strong transactional consistency (ACID compliance) and a 99.995%+ uptime SLA, making it ideal for global payments.

The primary distractor, Cloud SQL, fails because it does not offer automatic sharding or multi-region active-active scaling required for true horizontal scalability and 99.999% availability in this context.

Bigtable is eliminated as it lacks multi-row ACID transactions, while Bare Metal Solution is not a managed service.

## Pregunta 125

Contexto: [topics:723](#topics-723)
You are a DBA of Cloud SQL for PostgreSQL. You want the applications to have password-less authentication for read and write access to the database. Which authentication mechanism should you use?

**A.** Use Identity and Access Management (IAM) authentication.

**B.** Use Managed Active Directory authentication.

**C.** Use Cloud SQL federated queries.

**D.** Use PostgreSQL database's built-in authentication.

**Respuesta de la fuente:** A

**Explicación:** IAM database authentication allows Cloud SQL clients to connect using short-lived tokens generated via the `google-cloud-cli` or client libraries, eliminating the need for static passwords.
PostgreSQL built-in authentication (D) relies on standard password-based methods like md5 or scram-sha-256, which do not meet the password-less requirement.
Managed Active Directory (B) is primarily supported for Cloud SQL for SQL Server, not PostgreSQL, and federated queries (C) pertain to BigQuery data access rather than direct application connectivity.

## Pregunta 126

Contexto: [topics:723](#topics-723)
You are migrating your 2 TB on-premises PostgreSQL cluster to Compute Engine. You want to set up your new environment in an Ubuntu virtual machine instance in Google Cloud and seed the data to a new instance. You need to plan your database migration to ensure minimum downtime. What should you do?

**A.** 1. Take a full export while the database is offline.
2. Create a bucket in Cloud Storage.
3. Transfer the dump file to the bucket you just created.
4. Import the dump file into the Google Cloud primary server.
B.1. Take a full export while the database is offline.
2. Create a bucket in Cloud Storage.
3. Transfer the dump file to the bucket you just created.
4. Restore the backup into the Google Cloud primary server.

**C.** 1. Take a full backup while the database is online.
2. Create a bucket in Cloud Storage.
3. Transfer the backup to the bucket you just created.
4. Restore the backup into the Google Cloud primary server.
5. Create a recovery.conf file in the $PG_DATA directory.
6. Stop the source database.
7. Transfer the write ahead logs to the bucket you created before.
8. Start the PostgreSQL service.
9. Wait until Google Cloud primary server syncs with the running primary server.

**D.** 1. Take a full export while the database is online.
2. Create a bucket in Cloud Storage.
3. Transfer the dump file and write-ahead logs to the bucket you just created.
4. Restore the dump file into the Google Cloud primary server.
5. Create a recovery.conf file in the $PG_DATA directory.
6. Stop the source database.
7. Transfer the write-ahead logs to the bucket you created before.
8. Start the PostgreSQL service.
9. Wait until the Google Cloud primary server syncs with the running primary server.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it utilizes pg_basebackup to take a consistent online full backup while the database remains running, minimizing initial downtime. It then employs Write-Ahead Logs (WALs) and recovery configuration to replicate incremental changes, ensuring a near-zero downtime cutover when the source is finally stopped and synced.

Option B is incorrect because taking a full export requires the database to be offline, resulting in significant downtime that violates the requirement for minimum disruption.

## Pregunta 127

Contexto: [topics:723](#topics-723)
You have deployed a Cloud SQL for SQL Server instance. In addition, you created a cross-region read replica for disaster recovery (DR) purposes. Your company requires you to maintain and monitor a recovery point objective (RPO) of less than 5 minutes. You need to verify that your cross-region read replica meets the allowed RPO. What should you do?

**A.** Use Cloud SQL instance monitoring.

**B.** Use the Cloud Monitoring dashboard with available metrics from Cloud SQL.

**C.** Use Cloud SQL logs.

**D.** Use the SQL Server Always On Availability Group dashboard.

**Respuesta de la fuente:** B

**Explicación:** Cloud Monitoring provides specific metrics like `replica_count` and replication lag that allow you to verify the Recovery Point Objective (RPO) and set alerts for thresholds such as 5 minutes.
Option D is incorrect because Cloud SQL abstracts the underlying SQL Server infrastructure; users do not have direct access to SQL Server Management Studio (SSMS) or the Always On Availability Group dashboard to monitor replication status directly.

## Pregunta 128

Contexto: [topics:723](#topics-723)
You want to migrate an on-premises mission-critical PostgreSQL database to Cloud SQL. The database must be able to withstand a zonal failure with less than five minutes of downtime and still not lose any transactions. You want to follow Google-recommended practices for the migration. What should you do?

**A.** Take nightly snapshots of the primary database instance, and restore them in a secondary zone.

**B.** Build a change data capture (CDC) pipeline to read transactions from the primary instance, and replicate them to a secondary instance.

**C.** Create a read replica in another region, and promote the read replica if a failure occurs.

**D.** Enable high availability (HA) for the database to make it regional.

**Respuesta de la fuente:** D

**Explicación:** Enabling High Availability (HA) in Cloud SQL creates a regional configuration with an automated standby replica, satisfying the zonal failure resilience and <5 minute downtime requirements while ensuring zero data loss through synchronous replication.
Option B is incorrect because building a manual CDC pipeline contradicts Google-recommended practices for managed services like Cloud SQL, which provide built-in HA solutions that are simpler and more reliable.

## Pregunta 129

Contexto: [topics:723](#topics-723)
You are migrating an on-premises application to Compute Engine and Cloud SQL. The application VMs will live in their own project, separate from the Cloud SQL instances which have their own project. What should you do to configure the networks?

**A.** Create a new VPC network in each project, and use VPC Network Peering to connect the two together.

**B.** Create a Shared VPC that both the application VMs and Cloud SQL instances will use.

**C.** Use the default networks, and leverage Cloud VPN to connect the two together.

**D.** Place both the application VMs and the Cloud SQL instances in the default network of each project.

**Respuesta de la fuente:** B

**Explicación:** Shared VPC is the recommended architecture for connecting compute resources in one project to managed services like Cloud SQL in another project within the same organization. It establishes a host-project model where service projects can create VMs in subnets owned by the host, ensuring direct connectivity without IP overlap or peering limits.

Option A (VPC Peering) is incorrect because it introduces complexity with static route propagation and potential IP address conflicts, whereas Shared VPC provides native, low-latency connectivity designed specifically for this multi-project resource separation.

## Pregunta 130

Contexto: [topics:723](#topics-723)
Your DevOps team is using Terraform to deploy applications and Cloud SQL databases. After every new application change is rolled out, the environment is torn down and recreated, and the persistent database layer is lost. You need to prevent the database from being dropped. What should you do?

**A.** Set Terraform deletion_protection to true.

**B.** Rerun terraform apply.

**C.** Create a read replica.

**D.** Use point-in-time-recovery (PITR) to recover the database.

**Respuesta de la fuente:** A

**Explicación:** Option A is the correct choice because setting `prevent_destroy` (often referred to conceptually as deletion protection in exam contexts) in the resource's lifecycle block explicitly prevents Terraform from destroying the Cloud SQL instance during a `terraform destroy` or an update that requires recreation. This ensures the persistent database layer is retained even if the rest of the infrastructure is torn down.

Option B is incorrect because simply rerunning `terraform apply` will not prevent destruction if the configuration changes dictate that the resource must be replaced or removed. Options C and D are reactive measures (creating replicas or recovering data) rather than preventive controls against accidental deletion during infrastructure management.

## Pregunta 131

Contexto: [topics:723](#topics-723)
Your company's mission-critical, globally available application is supported by a Cloud Spanner database. Experienced users of the application have read and write access to the database, but new users are assigned read-only access to the database. You need to assign the appropriate Cloud Spanner Identity and Access Management (IAM) role to new users being onboarded soon. What roles should you set up?

**A.** roles/spanner.databaseReader

**B.** roles/spanner.databaseUser

**C.** roles/spanner.viewer

**D.** roles/spanner.backupWriter

**Respuesta de la fuente:** A

**Explicación:** The requirement specifies read-only access for new users. `roles/spanner.databaseReader` grants permission to read data from a database without allowing modifications, aligning with this need.

`roles/spanner.databaseUser` is incorrect because it includes write permissions. `roles/spanner.viewer` is incorrect as it is an instance-level role that allows viewing metadata but does not grant the ability to read database content.

## Pregunta 132

Contexto: [topics:723](#topics-723)
Your company is migrating from an on-premises database to a single-region Spanner instance. The current database supports 40,000 reads each second, and 7,000 writes each second, at 1 KB row sizes at peak. You need to determine the most cost-effective size for the Spanner instance to handle the equivalent current workload. What should you do?

**A.** Select a 4-node Spanner instance.

**B.** Select a 6-node Spanner instance.

**C.** Select a 1-node Spanner instance.

**D.** Recommend a multi-region Spanner instance.

**Respuesta de la fuente:** A

**Explicación:** Cloud Spanner provides roughly 10,000 read operations per second and 2,000 write operations per second per node for single-region instances.
For 40,000 reads/sec, you need 4 nodes (40,000 / 10,000 = 4).
For 7,000 writes/sec, you need 3.5 nodes (7,000 / 2,000 = 3.5), which rounds up to 4 nodes.
Therefore, a 4-node instance satisfies both read and write requirements most cost-effectively.

## Pregunta 133

Contexto: [topics:723](#topics-723)
You are building a data warehouse on BigQuery. Sources of data include several MySQL databases located on-premises. You need to transfer data from these databases into BigQuery for analytics. You want to use a managed solution that has low latency and is easy to set up. What should you do?

**A.** Use Datastream to connect to your on-premises database and create a stream. Have Datastream write to Cloud Storage. Then use Dataflow to process the data into BigQuery.

**B.** Use Cloud Data Fusion and scheduled workflows to extract data from MySQL. Transform this data into the appropriate schema, and load this data into your BigQuery database.

**C.** Use Database Migration Service to replicate data to a Cloud SQL for MySQL instance. Create federated tables in BigQuery on top of the replicated instances to transform and load the data into your BigQuery database.

**D.** Create extracts from your on-premises databases periodically, and push these extracts to Cloud Storage. Upload the changes into BigQuery, and merge them with existing tables.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 134

Contexto: [topics:723](#topics-723)
You want to migrate an existing on-premises application to Google Cloud. Your application supports semi-structured data ingested from 100,000 sensors, and each sensor sends 10 readings per second from manufacturing plants. You need to make this data available for real-time monitoring and analysis. What should you do?

**A.** Deploy the database using Cloud SQL.

**B.** Use BigQuery, and load data in batches.

**C.** Deploy the database using Bigtable.

**D.** Deploy the database using Cloud Spanner.

**Respuesta de la fuente:** C

**Explicación:** Cloud Bigtable is a wide-column NoSQL database optimized for low-latency, high-throughput access to massive datasets, making it ideal for ingesting millions of writes per second from IoT sensors.
Its support for time-series data and semi-structured formats directly addresses the need for real-time monitoring of high-velocity sensor readings.
In contrast, BigQuery is primarily designed for large-scale analytics with batch or streaming loads that introduce slight latency, while Cloud SQL and Spanner are relational databases not optimized for this specific volume of high-frequency writes.

## Pregunta 135

Contexto: [topics:723](#topics-723)
Your company is launching a gaming application that uses a Firestore database. You need to identify an easy-to-manage and cost-effective solution to automate the scheduling of Firestore data exports. What should you do?

**A.** Create a new Compute Engine, and set up a cron Job to run the gcloud firestore export command.

**B.** Use Dataflow to create a custom pipeline to extract data from Firestore, transform it into the desired format, and load it into a Cloud Storage bucket at regular intervals.

**C.** Use Cloud Scheduler to trigger a Cloud Function that executes the Firestore export process.

**D.** Use the Firebase Admin SDK to programmatically schedule and manage exports.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it leverages a serverless architecture (Cloud Scheduler and Cloud Functions) which is inherently easy to manage and cost-effective, as you only pay for the compute resources used during execution without maintaining underlying infrastructure.
Option A is incorrect because managing a Compute Engine instance involves higher operational overhead and continuous costs even when idle, contradicting the requirement for an easy-to-manage, cost-effective solution.

## Pregunta 136

Contexto: [topics:723](#topics-723)
Your company is launching a new globally distributed application with strict requirements for low latency, strong consistency, zero downtime, and high availability (HA). You need to configure a scalable database solution to support anticipated rapid growth and optimal application performance. What should you do?

**A.** Create a Spanner instance across regions for optimal performance.

**B.** Implement Bigtable with replication across multiple regions and configure to prioritize data accuracy.

**C.** Create a Cloud SQL instance in HA mode with a cross-region read replica.

**D.** Create an AlloyDB instance in HA mode with a cross-region read replica.

**Respuesta de la fuente:** A

**Explicación:** Google Cloud Spanner is the only database in the options that natively provides strong consistency, zero downtime scaling, and high availability across regions without manual failover or read-replica lag. Bigtable offers eventual consistency by default (though strong reads exist, it lacks Spanner's transactional ACID compliance), while Cloud SQL and AlloyDB rely on asynchronous replication for cross-region setups, which introduces latency and potential data loss during failures.

## Pregunta 137

Contexto: [topics:723](#topics-723)
Your rapidly growing ecommerce company is migrating their analytics workloads to AlloyDB for PostgreSQL. You anticipate a significant increase in reporting queries as the business scales. You need a read pool strategy to scale your analytics operations in anticipation of future growth while minimizing costs. What should you do?

**A.** Direct all complex, long-running analytics queries to the primary instance, and only use read pools for short, frequent reports.

**B.** Change the instance sizes of the read nodes in the read pool.

**C.** Begin with minimal read pools and iteratively expand or shrink them based on real-time load monitoring to optimize resource allocation.

**D.** Assign all reporting queries to a single, large read pool to maximize the combined compute resources available for analytics.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because it aligns with the goal of minimizing costs by avoiding overprovisioning; you start with minimal resources and scale based on actual observed load rather than speculation. Option D is tempting but incorrect because assigning all queries to a single large pool upfront likely incurs unnecessary costs for idle capacity during lower-traffic periods, violating the cost-minimization requirement.

## Pregunta 138

Contexto: [topics:723](#topics-723)
You are deploying a Cloud SQL for MySQL database to serve a non-critical application. The database size is 10 GB and will be updated every night with data stored in a Cloud Storage bucket. The database serves read-only traffic from the application during the day. The data locality requirement of this application mandates that data must reside in a single region. You want to minimize the cost of running this database while maintaining an RTO of 1 day. What should you do?

**A.** Create a Cloud SQL for MySQL instance with high availability (HA) enabled. Configure automated backups of the Cloud SQL instance, and use the default backup location.

**B.** Create a Cloud SQL for MySQL instance with high availability (HA) disabled. Create a read replica in the same zone.

**C.** Create a Cloud SQL for MySQL instance with high availability (HA) disabled. Create a read replica in a second region.

**D.** Create a Cloud SQL for MySQL instance with high availability (HA) disabled. Configure automated backups of the Cloud SQL instance, and use a custom backup location to store backups in a Cloud Storage bucket in the same region.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because it disables expensive High Availability (HA) features for a non-critical workload while ensuring compliance with the single-region data locality requirement via a custom backup location.
Automated backups satisfy the 1-day Recovery Time Objective (RTO) at a lower cost than maintaining an active read replica or HA instance.

## Pregunta 139

Contexto: [topics:723](#topics-723)
You are planning to migrate a 10 TB relational database from an on-premises environment to Cloud SQL for PostgreSQL. The database contains sensitive customer information. You want to follow Google-recommended practices to keep data secure during the migration. What should you do? (Choose two.)

**A.** Configure Cloud SQL for automatic patching, and enable binary logging.

**B.** Establish a Private Service Connect connection between your on-premises environment and the Cloud SQL instance.

**C.** Use an external IP address for the Cloud SQL instance, and configure firewall rules.

**D.** Set up Identity and Access Management (IAM) roles to restrict access with Cloud SQL with an internal IP address.

**E.** Leverage Storage Transfer Service with client-side encryption.

**Respuesta de la fuente:** B, D

**Explicación:** Option B is correct because Private Service Connect enables secure, private connectivity from on-premises to Cloud SQL without exposing the instance to the public internet. Option D is correct because combining IAM roles for strict access control with an internal IP address ensures data remains within the VPC perimeter and limits administrative privileges. Option C is incorrect as using external IPs exposes the database to the internet, violating security best practices for sensitive data.

## Pregunta 140

Contexto: [topics:723](#topics-723)
You are running a Cloud SQL for PostgreSQL 13 Enterprise Edition instance. During an audit, you discovered that the write-ahead logs used for point-in-time recovery (PITR) are stored on disk. You need to store PITR logs in a Cloud Storage bucket going forward. How should you do this without compromising recoverability or losing the current PITR logs?

**A.** Clone the instance. Create a new instance with PITR retention set to 30 days.

**B.** Change the transaction logs (WAL) retention period.

**C.** Upgrade to Enterprise Plus Edition.

**D.** Disable PITR, then enable PITR.

**Respuesta de la fuente:** C

**Explicación:** Cloud SQL for PostgreSQL Enterprise Edition stores Point-in-Time Recovery (PITR) logs locally on disk by default. To store these logs in Cloud Storage, you must upgrade to the Enterprise Plus edition, which supports remote WAL archiving.
Option A is incorrect because cloning creates a new instance but does not inherently change the log storage backend from disk to Cloud Storage unless the underlying edition capabilities support it.

## Pregunta 141

Contexto: [topics:723](#topics-723)
You are the DBA working at a large bank in Europe. Your business-critical banking application runs on Oracle 12.2 in your on-premises data center. You decided to modernize your on-premises Oracle database by migrating to AlloyDB. You must meet the following requirements:

•	Remain on-premises and maintain open-source portability.
•	Meet regulatory requirements for data residency.
•	Support both OLTP and OLAP workloads.
•	Maintain high availability (HA) mode and automatic failover.

What should you do?

**A.** Deploy AlloyDB Omni in a standalone VM on-premises, and set up disaster recovery (DR) in AlloyDB for PostgreSQL.

**B.** Migrate to AlloyDB for PostgreSQL by using Database Migration Service.

**C.** Deploy Kubernetes-based AlloyDB Omni database cluster on-premises. Enable HA by using the AlloyDB Omni Kubernetes operator, and migrate your Oracle database to Omni.

**D.** Deploy AlloyDB Omni as a docker-based container in your on-premises VM, enable HA for it, and migrate your Oracle database to the Omni container.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because deploying AlloyDB Omni on Kubernetes satisfies the requirement to remain on-premises while maintaining open-source portability and leveraging native Kubernetes operators for High Availability (HA) and automatic failover.
Options A and D are incorrect because standalone VMs or simple Docker containers do not provide the robust, automated HA and failover capabilities required by enterprise standards compared to a Kubernetes-based cluster with an operator.
Option B is invalid because migrating directly to cloud-hosted AlloyDB for PostgreSQL violates the strict data residency and on-premises requirements.

## Pregunta 142

Contexto: [topics:723](#topics-723)
You have an application that performs numerous reads and writes all day running in a single Bigtable cluster. A new batch analytics job needs to read the same data and you want to make sure that the new job does not affect the existing workload. What should you do?

**A.** Scale up the Bigtable instance by manually adding more nodes.

**B.** Add a new cluster to the existing instance, and enable multi-cluster routing in the app profile.

**C.** Add a new cluster to the existing instance, and isolate the workloads with two app profiles.

**D.** Scale up the Bigtable instance by enabling Autoscaling.

**Respuesta de la fuente:** C

**Explicación:** To isolate workloads in Google Cloud Bigtable, you must add a new cluster to the existing instance and configure distinct App Profiles for each workload. App Profiles allow you to direct specific traffic (like the new batch analytics job) to a dedicated cluster, preventing it from competing for resources with the existing read/write application.
Option B is incorrect because multi-cluster routing is designed for high availability and read scaling across regions, not for strict workload isolation between different types of jobs. Options A and D address capacity scaling but do not prevent the new batch job from impacting the primary application's performance.

## Pregunta 143

Contexto: [topics:723](#topics-723)
You are setting up a new AlloyDB instance and want users to be able to use their existing Identity and Access Management (IAM) identities to connect to AlloyDB. You have performed the following steps:

•	Manually enabled IAM authentication on the AlloyDB instance
•	Granted the alloydb.databaseUser and ser-viceusage.serviceUsageconsumer IAM roles to the users
•	Created new AlloyDB database users based on corresponding IAM identities

Users are able to connect but are reporting that they are not able to SELECT from application tables. What should you do?

**A.** Grant the new database users access privileges to the appropriate tables.

**B.** Grant the alloydb.client IAM role to each user.

**C.** Grant the alloydb.viewer IAM role to each user.

**D.** Grant the alloydb.alloydbreplica IAM role to each user.

**Respuesta de la fuente:** A

**Explicación:** IAM authentication only verifies user identity to establish a database connection; it does not automatically grant database-level permissions like SELECT.
You must explicitly grant SQL privileges (e.g., USAGE on the schema and SELECT on tables) to the newly created database users to allow them to query application tables.
Other options involve Cloud IAM roles for managing AlloyDB resources or viewing configurations, which do not control internal database object access.

## Pregunta 144

Contexto: [topics:723](#topics-723)
You are using Memorystore for Redis to cache frequently accessed data and improve your application's performance. Recently, your application is experiencing sudden spikes in latency when interacting with the Memorystore for Redis instance. Upon checking the logs, you discover a high number of "evicted keys" messages. You want to reduce the occurrences of latency spikes and their impact on the application. What should you do?

**A.** Increase the time to live (TTL) value of all the keys within the cache.

**B.** Redeploy your application to the same zone as the Memorystore instance.

**C.** Scale the Memorystore instance to a larger memory size.

**D.** Enable read replicas. Deploy additional read replica instances to distribute read workloads.

**Respuesta de la fuente:** C

**Explicación:** High evicted keys indicate that the cache memory is full, forcing Redis to remove existing data to accommodate new entries. This constant eviction and subsequent cache misses cause increased latency as the application must fetch data from slower backend sources. Scaling the instance to a larger memory size increases the capacity limit, reducing the frequency of evictions and stabilizing performance.

Increasing TTL (A) would exacerbate the issue by keeping keys longer, leading to more frequent evictions. Redeploying for locality (B) addresses network latency, not cache pressure. Read replicas (D) distribute read load but do not increase the memory capacity available in the primary node where evictions occur.

## Pregunta 145

Contexto: [topics:723](#topics-723)
You are migrating an on-premises database to Spanner. There are a few tables, each with a few hundred records that do not have a primary key on the source database. You need to migrate all of the tables over to the news database while avoiding hot-spotting issues. What should you do?

**A.** Load the data into Spanner, and designate a primary key later based on business need.

**B.** Use the GENERATE_UUID() function to generate universally unique identifier (UUID) values with the STRING(36) data type when you do the migration.

**C.** During the migration, swap the order of keys so that the column that contains the monotonically increasing or decreasing value is the first key par.

**D.** Migrate the tables with no primary key to maintain consistency with source.

**Respuesta de la fuente:** B

**Explicación:** Cloud Spanner requires every table to have a primary key defined at creation time, making options A and D invalid. To avoid write hot-spotting caused by monotonically increasing keys, using GENERATE_UUID() ensures that rows are distributed randomly across the cluster, providing an even spread of data. Option C is incorrect because placing a monotonically increasing column first in the key order concentrates writes on a single node, exacerbating the hot-spotting issue.

## Pregunta 146

Contexto: [topics:723](#topics-723)
You are the DBA of your organization. You provided a cloned instance from the production Cloud SQL for PostgreSQL database to the developers for testing purposes. After the creation of the clone, your developers notice missing data in one of the recently altered tables. What should you do to ensure that all data is included?

**A.** Take a back up of the production database, and restore it to another Cloud SQL for PostgreSQL instance. Provide access to the new instance to the developers.

**B.** Check for missing roles and privileges in the cloned Cloud SQL instance. Grant missing privileges to the developers.

**C.** Clone the current production database, and restore it to an earlier point-in-time (PITR). Provide access to the cloned instance to the developers.

**D.** Dump the production database to a file. Modify the dumped file to ALTER TABLE to SET LOGGED on tables that were unlogged in production. Reload the data in the new Cloud SQL for PostgreSQL instance.

**Respuesta de la fuente:** D

**Explicación:** In PostgreSQL, unlogged tables are not persisted in WAL logs and therefore do not replicate or clone their data, leading to missing information in the cloned instance.
Option D is correct because it involves dumping the database and explicitly altering those tables to be LOGGED before reloading, ensuring all data is captured in the new environment.
The other options fail because standard cloning (C) and backups (A) inherently exclude unlogged table contents due to how PostgreSQL handles recovery.

## Pregunta 147

Contexto: [topics:723](#topics-723)
Your company is developing a 24/7, global, real-time analytics platform that needs to store and process large amounts of versioned time-series data. You need to design a platform that is highly scalable to accommodate traffic spikes and ensure high availability for mission-critical operations. What should you do?

**A.** Implement a single-cluster Bigtable instance with autoscaling enabled and row key design.

**B.** Implement a multi-cluster Bigtable instance with autoscaling enabled and optimal schema design.

**C.** Implement a multi-cluster Bigtable instance across multiple regions with replication.

**D.** Implement AlloyDB for PostgreSQL to handle the analytical workload using read replica.

**Respuesta de la fuente:** C

**Explicación:** Bigtable is the appropriate service for high-throughput, versioned time-series data. To meet the strict requirements for global availability and mission-critical resilience, a multi-cluster instance deployed across multiple regions with replication is necessary, as this provides true geo-redundancy that a single-region setup cannot guarantee.

## Pregunta 148

Contexto: [topics:723](#topics-723)
You have a non-critical business application running on Google Kubernetes Engine (GKE) in the app-dev VPC. You have created an AlloyDB cluster with Private Service Access (PSA) and no public IP address in the db-dev VPC. You want your application to securely connect to AlloyDB in a cost-effective way. What should you do?

**A.** Set up a high availability VPN between the app-dev and db-dev VPCs. Connect the application directly to AlloyDB.

**B.** Connect by using the private IP address of the AlloyDB cluster directly from the application.

**C.** Connect by using AlloyDB Auth Proxy installed in the GKE cluster.

**D.** Install a SOCKS proxy in a VM in the db-dev VPC. Install AlloyDB Auth Proxy in your GKE cluster, and connect to the AlloyDB cluster through the SOCKS server and port.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because the AlloyDB Auth Proxy provides a secure, encrypted connection using IAM authentication without requiring complex network peering or public IPs. It runs as a sidecar in GKE, handling TLS encryption and auth locally, which satisfies both security and cost-effectiveness requirements by avoiding VPN costs.

Option B is incorrect because although Private Service Access (PSA) allows private connectivity, the app and database are in different VPCs that lack established peering or shared service connection configuration for direct IP routing between them. Direct private IP access requires specific VPC network alignment that isn't guaranteed across separate dev VPCs without additional networking setup.

## Pregunta 149

Contexto: [topics:723](#topics-723)
You are migrating your critical production database from Amazon RDS for MySQL to Cloud SQL for MySQL by using Google Cloud's Database Migration Service. You want to keep disruption to your production database to a minimum and, at the same time, optimize migration performance. What should you do?

**A.** Create and start multiple Database Migration Service jobs to migrate your database to the target Cloud SQL for MySQL instance.

**B.** Upgrade the Amazon RDS for MySQL primary instance to an instance with more vCPUs and memory, and then run Google Cloud's Database Migration Service.

**C.** Create a single Database Migration Service migration job with initial load parallelism configured to maximum on the source Amazon RDS for MySQL read replica.

**D.** Create a single Database Migration Service migration job with initial Load Parallelism configured to Maximum on the Amazon RDS for MySQL primary instance.

**Respuesta de la fuente:** C

**Explicación:** To minimize disruption to the primary production database, you must perform the migration from a read replica rather than the primary instance, which eliminates options A and D. Option C is correct because it leverages this replica for safety while configuring maximum initial load parallelism to optimize performance, satisfying both constraints. Option B is incorrect because scaling up the source instance does not utilize Cloud SQL Migration Service features to reduce load impact or accelerate the transfer as effectively.

## Pregunta 150

Contexto: [topics:723](#topics-723)
You currently have a MySQL database running on Cloud SQL with a read replica in a different zone for non-mission critical analytics workloads. You want to enable high availability (HA) for the analytic workloads while keeping costs low. What should you do?

**A.** Increase the size of the read replica instance and enable HA.

**B.** Enable HA on the current read replica.

**C.** Create a new HA instance in the same zone as the primary.

**D.** Create a new HA instance in a different region than the primary.

**Respuesta de la fuente:** B

**Explicación:** Enabling High Availability (HA) directly on the existing read replica (Option B) provides a failover replica within the same region, ensuring service continuity without the overhead of provisioning and managing a new instance.
This approach is the most cost-effective solution because it leverages the already-paid-for resources while meeting the HA requirement for analytics workloads.
Options A and C fail to address the HA configuration itself, and Option D introduces unnecessary cross-region costs and complexity.

## Pregunta 151

Contexto: [topics:723](#topics-723)
You are planning the migration of a large Oracle database to AlloyDB for PostgreSQL. The database contains a large amount of application logic written as stored procedures that needs to be migrated to the target database. You want to minimize both migration effort and downtime for the migration. What should you do?

**A.** Use Ora2pg for schema and code conversion and data migration.

**B.** Use Ora2pg for schema and code conversion. Use the oracle_fdw extension in AlloyDB and replicate data from source to destination by using CREATE TABLE AS SELECT statements.

**C.** Use Database Migration Service. Set up a conversion workspace for schema and code conversion. Create a migration job to perform backfill and change data capture to replicate data from source to destination.

**D.** Use Database Migration Service. Set up a legacy conversion workspace for schema and code conversion. Create a migration job to perform backfill and change data capture to replicate data from source to destination.

**Respuesta de la fuente:** C

**Explicación:** Option C is correct because Google Cloud Database Migration Service (DMS) provides a managed end-to-end solution that handles schema/code conversion via workspaces and ensures minimal downtime through Continuous Data Replication (CDR) using Change Data Capture (CDC). This aligns with the goal of minimizing effort by offloading migration orchestration to a managed service rather than manually executing tools like Ora2pg. Option A is incorrect because while Ora2pg handles conversion, it does not natively provide automated CDC-based replication for minimal downtime without significant custom scripting or integration effort.

## Pregunta 152

Contexto: [topics:723](#topics-723)
Your company uses a custom application to service thousands of users. The application is running on a Compute Engine and a Cloud SQL for PostgreSQL database. The company requires database passwords to be changed every 60 days. You need to ensure that the credentials used by the web application to connect to the database are managed securely. What should you do?

**A.** 1. Store the credentials in an encrypted text file in the application.
2. Use Cloud Key Management Service (Cloud KMS) to store the key for decrypting the text file.
3. Modify the application to decrypt the text file and retrieve the credentials on startup.
4. Update the text file every 60 days.

**B.** 1. Store the credentials to the database in Secret Manager.
2. Modify the application to retrieve the credentials from Secret Manager on startup.
3. Configure the rotation interval to 60 days.

**C.** 1. Store the credentials in a text file in a Cloud Storage bucket.
2. Modify the application to download the text file and retrieve the credentials on startup.
3. Update the text file every 60 days.

**D.** 1. Configure IAM database authentication for the application to connect to the database.
2. Create an IAM user and map it to a separate database user for each application user.
3. Require users to update their passwords every 60 days.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because Cloud Secret Manager is the managed service designed specifically for securely storing and rotating secrets like database credentials. It supports automated or manual rotation policies, ensuring the 60-day requirement is met without embedding secrets in code or files.

Options A and C are incorrect because storing secrets in text files (even encrypted ones) requires custom logic for decryption and updates, increasing security risk and operational complexity. Option D is incorrect because IAM database authentication does not inherently satisfy the specific requirement for periodic password rotation of credentials used by a single web application service account.

## Pregunta 153

Contexto: [topics:723](#topics-723)
You are a DBA at a retail company. The production databases are running in Cloud SQL for MySQL Enterprise Plus edition, version 8.0.34, in the us-centrall region. You need to set up and test disaster recovery (DR) with zero data loss in the us-west1 region. What should you do?

**A.** Use advanced DR by setting up a cascading read replica in the us-west1 region, and designate it as the failover DR replica. Test switchover by using the gcloud switchover command.

**B.** Create a cross-region read replica, version 8.0.37, in the us-west1 region. Designate it as the failover DR replica, and test switchover by using the gcloud switchover command.

**C.** Create a cross-region read replica version 8.0.34, in the us-west1 region. Designate it as the failover DR replica, and test switchover by using the gcloud switchover command.

**D.** Create a cross-region read replica, version 8.0.34, in the us-west1 region. Test switchover by using the gcloud promote-replica with failover command.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because the primary mechanism for promoting a designated failover replica in Cloud SQL is the 'promote-replica' operation, which ensures an ordered switchover with zero data loss by leveraging the secondary's binary log position. Options A, B, and C are incorrect because they suggest using the generic 'switchover' command or creating replicas with mismatched/unsupported configurations; specifically, 'gcloud sql failover' or promoting via the correct API endpoint is required for DR replication, not a standard read replica switchover which may cause data loss.

## Pregunta 154

Contexto: [topics:723](#topics-723)
You are designing the backup and recovery strategy of a Cloud SQL for MySQL database that serves a write heavy application. You need to be able to restore the database to any point in time within the past five days while minimizing the performance impact of database backups. What should you do?

**A.** Enable automatic backup and point in time recovery. Configure the backup window during periods of low database traffic. Set backup and transaction log retention to at least five days.

**B.** Schedule hourly on-demand backups and enable point in time recovery. Delete any delete backups that were taken over five days ago.

**C.** Schedule a database export job to run every hour from a read replica instance. Retain the export dumps for at least five days.

**D.** Schedule a database export job to run every hour. Use serverless export. Retain the export dumps for at least five days.

**Respuesta de la fuente:** A

**Explicación:** Option A is correct because Cloud SQL's built-in automatic backups and binary logs (transaction logs) provide native Point-in-Time Recovery (PITR) capabilities.
By configuring the backup window during low-traffic periods, you minimize I/O contention and performance impact on the write-heavy application.
Setting retention to five days ensures compliance with the recovery window requirement while relying on the optimized, server-managed backup mechanism rather than manual exports.

## Pregunta 155

Contexto: [topics:723](#topics-723)
Your company’s rapidly growing ecommerce application uses Cloud SQL for MySQL. Performance issues are surfacing during peak traffic periods. You need to ensure that the database can handle the load while minimizing downtime. What should you do?

**A.** Use read replicas for query offloading, configure automatic failover, and test failover procedures regularly.

**B.** Vertically scale the primary instance by significantly increasing compute resources, such as vCPUs and memory.

**C.** Increase storage size on the existing instance and implement client-side caching for frequently accessed data.

**D.** Migrate to a Cloud SQL for PostgreSQL database for better performance during high load.

**Respuesta de la fuente:** A

**Explicación:** Using read replicas offloads query traffic from the primary instance, effectively handling peak loads without requiring a full migration or vertical scaling limits. Configuring automatic failover ensures high availability with minimal downtime in case of primary instance failure, which aligns with the requirement to minimize disruption. Vertical scaling (Option B) often incurs significant downtime for provisioning and has upper hardware limits, making it less optimal for rapid, continuous growth compared to horizontal scaling.

## Pregunta 156

Contexto: [topics:723](#topics-723)
Your organization’s databases are running in Cloud SQL. Due to data residency regulations, your organization mandates that backups are stored in a specific region. You are also required to make sure that the databases have monthly full backups, which are retained until your Cloud SQL instance is deleted, along with daily backups. What should you do?

**A.** Schedule automated backups for Cloud SQL with a retention period of 365 days.

**B.** Schedule daily and monthly on-demand backups.

**C.** Schedule automated backups, and create on-demand monthly backups to custom backup locations.

**D.** Create an Organization Policy Service resource location constraint. Schedule automated backups with the retention period of 30 days.

**Respuesta de la fuente:** C

**Explicación:** Cloud SQL automated backups cannot be retained indefinitely; they have a maximum retention period (typically 365 days). To meet the requirement of retaining monthly full backups until deletion, you must create on-demand backups for those specific months. Additionally, to satisfy data residency regulations ensuring backups stay in a specific region, you should configure custom backup locations or ensure the regional constraint is applied to these on-demand exports.

## Pregunta 157

Contexto: [topics:723](#topics-723)
Your company is rapidly expanding its user base across North America, nearly doubling in the last 6 months. This expansion causes a substantial increase in query volume on your mission-critical Cloud SQL database. This has led to noticeable performance issues and slower query response times. You suspect that your Cloud SQL instance may not be able to handle the incremental load. You need to identify the root cause of this performance bottleneck and ensure that your database can scale with your growing user base. What should you do?

**A.** Migrate the database to Spanner.

**B.** Evaluate the application connection pooling configuration settings.

**C.** Review Cloud SQL System Insights for the instance, and analyze CPU, memory, and storage utilization metrics.

**D.** Create two Cloud SQL instances, and split the workload between them.

**Respuesta de la fuente:** C

**Explicación:** The correct approach is to first gather data before making architectural changes. Cloud SQL System Insights provides specific metrics on CPU, memory, and storage utilization, allowing you to pinpoint whether the bottleneck is resource exhaustion or inefficient queries.

While migrating to Spanner (A) or splitting workloads (D) are scaling strategies, they are premature and costly without first confirming that the current instance has hit its hard limits. Evaluating connection pooling (B) addresses a specific configuration issue but does not provide the holistic resource utilization view needed to confirm general capacity constraints.

## Pregunta 158

Contexto: [topics:723](#topics-723)
You want to migrate an on-premises MySQL database to Cloud SQL. The on-premises database currently has 16 cores and 64 GB of RAM and averages 75% CPU utilization to support an application with over 100.000 tables. You need to specify the most cost-effective machine size you need when migrating to Cloud SQL for MySQL. What should you do?

**A.** Select a Cloud SQL for MySQL database with a machine configuration of 12 cores and 48 GB of RAM.

**B.** Select a Cloud SQL for MySQL database with a machine configuration of 16 cores and 64 GB of RAM.

**C.** Select a Cloud SQL for MySQL database with a machine configuration of 32 cores and 256 GB of RAM.

**D.** Select a Cloud SQL for MySQL database with a machine configuration of 64 cores and 768 GB of RAM.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 159

Contexto: [topics:723](#topics-723)
You have a regional Spanner instance with no autoscaler that is serving a production workload. You observed a surge in write activities to the database during an ongoing promotional event. You received an alert that the database is close to the storage limit. Based on the storage utilization trend, the database will run out of storage in the next few hours. You want to resolve this issue as soon as possible. What should you do?

**A.** Create a custom instance configuration and add a custom read-only replica to the Spanner instance.

**B.** Increase the compute capacity of the Spanner instance.

**C.** Move the Spanner instance to a multi-regional configuration.

**D.** Archive and delete historical data from the database.

**Respuesta de la fuente:** B

**Explicación:** In Cloud Spanner, storage is not a separate resource but is directly tied to compute capacity (node hours). Increasing the compute capacity of the instance immediately increases the available storage quota, providing the fastest resolution to the imminent outage. Other options like archiving data take too long to implement during an emergency, and adding read-only replicas does not increase write or total storage capacity.

## Pregunta 160

Contexto: [topics:723](#topics-723)
Your organization deploys a high-volume, low-latency sensor data ingestion system. Resilience is crucial, and the workload is expected to grow significantly over time. You need to design a database tier on Google Cloud to ensure faster performance and high availability, while following Google-recommended practices. What should you do?

**A.** Deploy multiple Bigtable clusters, shard data manually across them, and set up the application logic for fault tolerance.

**B.** Deploy a single-zone Bigtable cluster and optimize the application code for maximum write throughput.

**C.** Deploy a single-region Bigtable instance and increase the nodes to maximize data durability.

**D.** Provision a multi-zone Bigtable cluster, configure replication, perform an application stress-test, and set up performance monitoring.

**Respuesta de la fuente:** D

**Explicación:** Google Bigtable is fully managed and automatically handles sharding and replication across zones within an instance, making manual sharding (A) unnecessary and anti-pattern. A single-zone deployment (B) lacks the high availability required by the prompt, while increasing nodes in a single-region context without specifying multi-zone redundancy does not guarantee the same level of fault tolerance as an explicit multi-zone configuration. Option D correctly aligns with Google-recommended practices for high-availability workloads by leveraging Bigtable's built-in multi-zone replication for resilience and including performance monitoring to manage the expected growth.

## Pregunta 161

Contexto: [topics:723](#topics-723)
Your company is migrating a legacy on-premises Oracle database to Cloud SQL for PostgreSQL. As a part of the migration, you need to convert schema and other database code objects, such as procedures, functions, and triggers, from Oracle to PostgreSQL. The database migration needs to be accomplished with minimal application code changes and manual intervention. What is the Google-recommended approach you should do?

**A.** Manually rewrite both the Oracle schema and queries to be compatible with PostgreSQL syntax and semantics.

**B.** Use a schema conversion tool to automatically convert the Oracle schema to PostgreSQL schema, then manually rewrite all queries.

**C.** Migrate the data directly from Oracle to PostgreSQL without any conversion. Rely on application-level compatibility layers to handle any syntax or semantic differences.

**D.** Use Database Migration Service code conversion workspace, then review and refactor as needed.

**Respuesta de la fuente:** D

**Explicación:** Option D is correct because the Database Migration Service (DMS) code conversion workspace automates the transformation of schema objects and code artifacts from Oracle to PostgreSQL, directly satisfying the requirement for minimal manual intervention.
Manual approaches like A and B contradict the goal of minimizing effort, while C fails to address the necessary syntax and semantic conversions required by the target database.

## Pregunta 162

Contexto: [topics:723](#topics-723)
You are using Memorystore for Redis to cache frequently accessed data and improve your application’s performance. In the event of a complete regional outage, the application will failover to another region. You want to ensure that the Memorystore instance in the new region does not start from an empty cache after failover. What should you do?

**A.** Use Memorystore Standard Tier. Disable read replicas.

**B.** Use Memorystore Standard Tier. Configure at least one read replica.

**C.** Schedule exports of the Memorystore instance. Specify a dual-region Cloud Storage bucket as the export destination.

**D.** Enable Redis RDB snapshots for Memorystore.

**Respuesta de la fuente:** C

**Explicación:** To survive a complete regional outage, data must be stored outside the affected region. Scheduling exports to a dual-region Cloud Storage bucket ensures the cache state persists across regions and can be imported into a new instance in the failover region.

Option D (RDB snapshots) typically stores backups within the same region as the instance or relies on local disk, making them inaccessible during a total regional failure.

## Pregunta 163

Contexto: [topics:723](#topics-723)
Your organization runs a high-volume, low-latency application on Bigtable. You need to reduce costs without compromising performance. What should you do?

**A.** Reduce replication factor across clusters.

**B.** Consolidate multiple small clusters into a single large cluster.

**C.** Analyze application access patterns to strategically redesign the schema and adjust the node count.

**D.** Switch to a lower-performance storage type for all clusters.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 164

Contexto: [topics:723](#topics-723)
Your company is using a multi-region Spanner instance. The instance stores data from an application which does a lot of writes without reading the data. You are noticing a lot of latency regression. You want to reduce latency and improve performance. What should you do?

**A.** Enable leader-aware routing in the client library.

**B.** Add additional indexes to the table.

**C.** Disable leader-aware routing in the client library.

**D.** Increase the number of Spanner nodes.

**Respuesta de la fuente:** A

**Explicación:** Leader-aware routing optimizes write performance by directing requests to the node currently acting as the leader for that specific row. Since the application performs many writes, enabling this feature reduces latency by avoiding unnecessary cross-region replication hops during the write path.

Increasing nodes (D) increases throughput capacity but does not address the specific network latency caused by non-optimal routing in a multi-region setup.

## Pregunta 165

Contexto: [topics:723](#topics-723)
You are designing a new ecommerce application on Google Cloud. You expect high and bursty write volumes during peak sales periods. You need to configure Spanner to ensure consistent database performance during this sales period. What should you do?

**A.** Implement sharding to distribute the write load across multiple Spanner instances.

**B.** Configure read-only transactions to improve read performance during peak periods.

**C.** Use interleaved tables to reduce the number of cross-node transactions.

**D.** Enable autoscaling in the Spanner instance, and set the maximum number of nodes to match the peak write volume.

**Respuesta de la fuente:** D

**Explicación:** Google Cloud Spanner is a fully managed database that automatically distributes data; manual sharding (Option A) is neither possible nor necessary. While interleaved tables (Option C) optimize specific query patterns and storage, they do not directly address capacity constraints for bursty write volumes. Read-only transactions (Option B) only affect read performance, not the required write throughput. Therefore, enabling autoscaling and setting appropriate node limits ensures the instance dynamically provisions enough compute resources to handle peak write loads while maintaining consistent performance.

## Pregunta 166

Contexto: [topics:723](#topics-723)
Your application uses a Cloud SQL for MySQL instance. Recently, you have noticed performance degradation during peak hours, leading to slow response times and frustrated users. You suspect that inefficient queries might be contributing to these issues. You want to pinpoint and analyze these problematic queries and pass them to the application team for optimizations. What should you do?

**A.** Use the underprovisioned instance recommender.

**B.** Increase the Cloud SQL instance read_buffer_size flag.

**C.** Enable and use Query Insights.

**D.** Create a Cloud Monitoring alert based on the database/mysql/queries metric.

**Respuesta de la fuente:** C

**Explicación:** Query Insights is the specific Cloud SQL feature designed to track, aggregate, and visualize slow or frequent queries, allowing you to pinpoint inefficient database operations for optimization.
Option A addresses instance sizing rather than query logic, while Option B modifies a buffer size without identifying the root cause of performance issues.
Option D creates alerts based on volume metrics but does not provide the detailed query analysis needed to optimize specific SQL statements.

## Pregunta 167

Contexto: [topics:723](#topics-723)
You are migrating your on-premises PostgreSQL database to Spanner. You need to identify a solution for handling existing integer-based table primary keys. You want minimal changes to the applications while also following Google-recommended practices. What should you do?

**A.** Use application generated sequential integer values as primary keys.

**B.** Update default primary key values to max(primary_key) + 1.

**C.** Use a UUID function that generates UUID Version 4 values as primary keys.

**D.** Generate values by using BIT_REVERSED_POSITIVE sequences.

**Respuesta de la fuente:** D

**Explicación:** Cloud Spanner documentation recommends using the BIT_REVERSED_POSITIVE sequence type for integer primary keys to ensure even distribution of write operations across nodes and avoid hotspots caused by sequential key generation.
Using simple sequential integers (A) or manual max+1 logic (B) creates write hotspots, degrading performance, while UUIDs (C) often require schema changes that violate the goal of minimal application modification.

## Pregunta 168

Contexto: [topics:723](#topics-723)
You have a Cloud SQL for MySQL instance with a table of product information including a column of product descriptions. Your application development team is building a customer facing chatbot and would like to find the product that most closely matches a freeform text description provided by the customer. How should you enable this functionality?

**A.** Create a stored procedure that uses a regular expression to match the customer’s search text to values in the product description column.

**B.** Create and populate a column of product description embeddings on the product table and perform an approximate nearest neighbor search using the customer’s search text.

**C.** Use the LIKE operator to match the customer’s search text to the product description and return similar rows.

**D.** Create a SQL script that compares the product description and the customer’s search text by using the SOUNDEX function.

**Respuesta de la fuente:** B

**Explicación:** Option B is correct because generating text embeddings and performing approximate nearest neighbor (ANN) search allows the system to identify semantically similar products based on meaning rather than exact character or phonetic matches. This vector-based approach is the standard method for semantic similarity tasks in modern RDBMS environments like Cloud SQL for MySQL, whereas regex (A), LIKE (C), and SOUNDEX (D) are limited to syntactic or phonetic matching and cannot effectively handle freeform natural language variations.

## Pregunta 169

Contexto: [topics:723](#topics-723)
You have a Cloud SQL for MySQL Enterprise instance with four read replicas. Your next scheduled maintenance event is scheduled tomorrow at 6 PM. Your security team identifies an important security vulnerability. You are notified by your management at 8 PM today to update your primary instance and all four read replicas during approved business downtime today at 11 PM. What should you do?

**A.** Reschedule the upcoming scheduled maintenance to happen today at 11 PM.

**B.** Perform self-service maintenance on the selected read replicas.

**C.** Perform self-service maintenance on the primary instance during scheduled business downtime.

**D.** Reschedule the upcoming scheduled maintenance of the primary instance to apply updates immediately.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 170

Contexto: [topics:723](#topics-723)
Your company has implemented a multi-regional, highly available (HA) PostgreSQL database cluster on Google Cloud by using Cloud SQL and regional persistent disks. You need to assess the effectiveness of your disaster recovery plan and validate the system's ability to recover from a regional outage. What should you do?

**A.** Promote the cross-region replica and verify that the application can still access the database.

**B.** Initiate a failover test to the HA standby instance and verify that the application can still access the database.

**C.** Create a backup of the database and restore it to a new Cloud SQL instance in a different region to test the backup and restore process.

**D.** Conduct a chaos engineering experiment by randomly terminating virtual machines in the primary region and observing the system's behavior.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 171

Contexto: [topics:723](#topics-723)
You are migrating an on-premises online transactional process (OLTP) PostgreSQL database to Google Cloud. You want to reduce the administrative overhead on database maintenance activities, such as vacuum and memory tuning. You are also planning to introduce analytic use cases in this database. You need the migration to have minimal schema and application changes. What should you do?

**A.** Use Spanner with PGAdapter.

**B.** Use Cloud SQL for PostgreSQL.

**C.** Use AlloyDB for PostgreSQL.

**D.** Deploy a self-managed PostgreSQL database on Compute Engine.

**Respuesta de la fuente:** C

**Explicación:** AlloyDB for PostgreSQL is the correct choice because it is fully managed (reducing maintenance overhead like vacuuming) and natively supports hybrid workloads that combine transactional (OLTP) and analytic (OLAP) queries without requiring schema changes. Unlike Cloud SQL, AlloyDB is specifically optimized for high-scale OLTP with integrated analytics capabilities, fulfilling both requirements simultaneously while maintaining PostgreSQL compatibility.

The most tempting alternative, Cloud SQL (B), is incorrect because, while it reduces administrative overhead, it is not primarily designed to handle heavy analytic workloads alongside OLTP transactions as efficiently as AlloyDB, often requiring separate data warehouses or complex federated query setups.

## Pregunta 172

Contexto: [topics:723](#topics-723)
You are developing a Python application that will connect to AlloyDB for PostgreSQL as the backend datastore. Your organization’s security requirements do not allow the use of usernames and passwords for database authentication. How should you develop your application?

**A.** Use any PostgreSQL-compatible Python client. Connect to the AlloyDB cluster by using Identity-Aware Proxy (IAP).

**B.** Use the AlloyDB Python connector. Use automated IAM authentication for connectivity.

**C.** Use the AlloyDB Python connector. Enforce SSL connectivity to AlloyDB by using the gcloud alloydb instance update command with the --ssl-mode=ENCRYPTED_ONLY option.

**D.** Use any PostgreSQL-compatible Python client. Use a service account name and credential as the username and password respectively during connection.

**Respuesta de la fuente:** B

**Explicación:** The AlloyDB Python connector supports automated IAM authentication, which allows the application to authenticate using service account credentials or the default Compute Engine metadata server instead of database usernames and passwords, directly satisfying the security requirement.

Option A is incorrect because Identity-Aware Proxy handles network access control but does not replace the need for database-level authentication credentials unless specifically configured with IAM DB Authentication, which the AlloyDB connector handles natively.

## Pregunta 173

Contexto: [topics:723](#topics-723)
You are creating new Cloud SQL for PostgreSQL instances in us-east1 and us-east4. You are assigning private IP addresses to the Cloud SQL instances starting with us-east1 so you can reach the instance without going through the internet or using external IP addresses. However, you keep getting a “Network association failed” error message. You are using a shared VPC network. What should you do to resolve the issue?

**A.** Use the Google Cloud console to assign private IP.

**B.** Enable the Service Networking API for the host and service projects.

**C.** Configure Private Services Access prior to assigning a private IP to Cloud SQL.

**D.** Assign the private IP by using the gcloud sql instances patch command.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 174

Contexto: [topics:723](#topics-723)
Your company is migrating one of its monolithic applications to a microservices architecture on Google Cloud. The new architecture involves a user authentication service that runs on Google Kubernetes Engine (GKE) and needs to access Cloud SQL for PostgreSQL instances. Your developers need to access the databases for local development and debugging purposes. You need to design a centralized, secure, and scalable database connectivity and access management strategy for both application service interfaces and developers. What should you do?

**A.** Configure the GKE and Compute Engine applications to use the Cloud SQL Auth Proxy for all database connections. Instruct developers to use their local clients with database-native user/password authentication.

**B.** Enable public IP addresses for all database instances and configure firewall rules to restrict access based on the source IP addresses of the GKE cluster, Compute Engine VMs, and developers’ machines.

**C.** For all service interfaces and developers, create unique database-native user and password credentials directly on each database instance, and store the credentials in a centralized secret management tool.

**D.** For GKE and Compute Engine services, create and grant dedicated IAM service accounts with least-privilege roles for Cloud SQL resources, and configure applications to use workload identity account credentials. For developers, use IAM authentication with Cloud SQL Auth Proxy for secure access.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 175

Contexto: [topics:723](#topics-723)
You are performing daily exports of native BAK files from Cloud SOL for SOL Server to Cloud Storage buckets by using gcloud sql export bak command at 6:00AM. You want to automate this routine using managed Google Cloud components so you can focus on other critical tasks of keeping your database healthy and performant. What should you do?

**A.** Enable retained backups for the instance.

**B.** Create a Cloud Run function to export with a Pub/Sub trigger. Create a Cloud Scheduler job to trigger the Cloud Run function daily.

**C.** Implement automated backups using the console and set the default retention to 7 days.

**D.** Create a cron job to export and configure Pub/Sub as the target. Set a recurring schedule of 0 6 * * * for the job.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 176

Contexto: [topics:723](#topics-723)
You have several on-premises Percona Server for MySQL 8.0 instances used for mission-critical applications. The workload is read-heavy with 80%+ reads and each instance has several TBs of data. You want to migrate to Google Cloud with minimal downtime and the fewest changes possible.

What should you do?

**A.** Use Database Migration Service to migrate to Alloy DB.

**B.** Use Datastream to migrate to Cloud SQL Enterprise

**C.** Use the spanner-migration-tool to migrate to Spanner.

**D.** Use Database Migration Service to migrate to Cloud SQL Enterprise Plus.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 177

Contexto: [topics:723](#topics-723)
You are migrating your company’s critical ecommerce platform from an on-premises PostgreSQL database (utilizing PostgreSQL stored procedures) to a highly available solution on Google Cloud. The platform requires an extremely low downtime (Recovery Time Objective (RTO) – 5 minutes) and minimal data loss (Recovery Point Objective – 30 seconds). The platform serves a global customer base with peak traffic distributed across multiple continents, though the primary transactional data resides in a single geographic region for regulatory compliance. You need to design a cloud database solution that meets the RTO/RPO requirements while optimizing for global read access and local transactional integrity. What should you do?

**A.** Implement a single-instance Spanner deployment configured for multi-regional data replication.

**B.** Deploy an AlloyDB cluster in the primary region with a high-availability instance configuration, and establish cross-region read replicas in another region for global read scaling.

**C.** Deploy a single-region AlloyDB cluster with a primary instance and a read replica in the same zone.

**D.** Implement a multi-regional Cloud SQL for PostgreSQL deployment with read replicas in different regions, and configure asynchronous replication for cross-region data consistency.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 178

Contexto: [topics:723](#topics-723)
Your e-learning platform runs on a Cloud SQL for PostgreSQL instance (16 VCPUs, 60 GB memory and 1TB SSD) serving users in North America. Your analytics team runs complex reporting queries that often consume 80% of CPU resources, causing slow response times for student transactions during peak hours. Current workload includes 8,000 transactions per second with 60% reads and 40% writes. The reporting queries involve JOIN operations across multiple large tables with millions of rows requiring highly efficient analytical processing. The platform also experiences sudden spikes in analytical reporting demand, requiring an elastic scaling of read capacity. You need to improve the query performance for your analytics team to run their reports efficiently without impacting transactional users. You also need to plan for future traffic growth. What should you do?

**A.** Upgrade to Cloud SAL for PostgreSQL Enterprise Edition and route transaction and analytical queries to the primary instance.

**B.** Migrate to AlloyDB for PostgreSQL and upgrade the machine type of the primary instance to 32 vCPU. Create materialized views for common analytical queries.

**C.** Migrate to AlloyDB for PostgreSQL with a 16 vCPU primary instance and enable columnar engine for analytical workloads, using read pools for query isolation.

**D.** Upgrade the Cloud SQL for PostgreSQL instance to db-n1-highmem-32 and implement connection pooling with PgBouncer to handle increased load.

**Respuesta de la fuente:** C

**Explicación:** AlloyDB for PostgreSQL is designed specifically to decouple analytical workloads from transactional ones using its columnar store engine, which accelerates complex reporting queries without consuming CPU resources on the primary instance.
Read pools provide scalable, read-only capacity that can elastically handle sudden spikes in analytical demand while isolating these heavy queries from student transactions.
Option B is incorrect because simply upgrading the primary machine type and using materialized views does not offer the same level of query isolation or elastic read scaling as AlloyDB's dedicated columnar engine and read pools.

## Pregunta 179

Contexto: [topics:723](#topics-723)
Your retail company is currently using DynamoDB to store product catalog data. Due to increasing data volumes and the need for better scalability, cost efficiency, and AI features; you have decided to migrate your data to Bigtable. You want a cost-effective migration, with minimal downtime and minimal effort, while ensuring data consistency between the two databases. What should you do?

**A.** Export the DynamoDB data to CSV files, upload them to Cloud Storage, and use the cbt CLI to import the data into Bigtable.

**B.** Create a Dataflow pipeline using the DynamoDBIO and BigtableIO connectors to stream data from DynamoDB to Bigtable in near real time.

**C.** Develop a custom script using the DynamoDB and Bigtable APIs to directly transfer data between the two databases.

**D.** Use Dataproc to export the data from DynamoDB and load it into Bigtable.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 180

Contexto: [topics:723](#topics-723)
You are designing a solution to implement a cache to track all the products which are browsed by users on an ecommerce website, using a key-value database. Your solution needs to have the ability to connect to the database from multiple VPC networks, while having a managed service, high throughput, low latency, strong security, and private communication. What should you do?

**A.** Choose Bigtable and connect using Private Google Access API endpoint(s).

**B.** Choose Memorystore for Redis Cluster and Private Service Connect for networking connectivity.

**C.** Choose a Memorystore for Redis instance and Private Service Access for networking connectivity.

**D.** Choose a Redis instance on a VM in the Shared VPC network.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 181

Contexto: [topics:723](#topics-723)
You are running a mission-critical application on Google Kubernetes Engine (GKE) and you are using private IP to connect to Cloud SQL for PostgreSQL in us-central1. You want to maximize database uptime without making any major changes to the application in case of a planned event, such as maintenance. What should you do?

**A.** Enable Automated backups and configure the retention period to 365 days.

**B.** Create a cross-region read replica in us-south1.

**C.** Upgrade to the Cloud SAL Enterprise Plus edition.

**D.** Set up notifications about upcoming maintenance sent to your email at least one week before maintenance is scheduled.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 182

Contexto: [topics:723](#topics-723)
Your IoT monitoring platform ingests sensor data from 100,000 devices, generating 2 million writes per second during peak hours and 500,000 writes per second during off-peak hours. Each record is 1KB with a row key format: deviceId#timestamp. Your current 12-node Bigtable cluster experiences hotspotting on specific device ranges, with three nodes handling majority ofthe traffic while others remain underutilized. Read queries typically access the last 24 hours of data for specific devices. Storage costs are becoming a concern as you retain two years of historical data (500TB total). You need to optimize performance, eliminate hotspotting, and reduce storage costs while maintaining read latency under 10ms. What should you do?

**A.** Implement row key sting wth hash prefix, configure automsted sealing with an optimal min max threshold setting, and migrate data older than 6 months to Cloud Storage.

**B.** Split the table by device type, use separate Bigtable instances for different geographic regions, and implement read replicas for query optimization.

**C.** Change the row key format to deviceId#timestamp, implement automated scaling with an optimal min max threshold setting based on CPU utilization, and migrate data older than 6 months to Cloud Storage

**D.** Increase cluster size to 20 nodes, implement row key salting with hash prefix, and enable compression on all column families.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 183

Contexto: [topics:723](#topics-723)
You are migrating your 10 TB on-premises PostgreSQL database to Cloud SQL for PostgreSQL by using Database Migration Service. During the migration, there will be schema changes in the source database. You need to ensure any schema changes are replicated, while keeping disruption to the ongoing migration to a minimum.

What should you do?

**A.** Make the schema changes in the destination by using the pglogical.replicate_ddl_command PostgreSQL extension.

**B.** Make the schema changes in the source by using the pglogical.replicate_ddl_command PostgreSQL extension.

**C.** Make the schema changes in both source and destination after stopping writes in source.

**D.** Stop the Database Migration Service migration job. Make the schema changes in the source. Restart the Database Migration Service migration job.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 184

Contexto: [topics:723](#topics-723)
You are implementing fine grained access (FGA) control on your Cloud SQL resources. You want to follow the principle of least privilege while maintaining centralized control for administrators.

What should you do?

**A.** Create tags at the project level.

**B.** Create tags at the organization level.

**C.** Create labels at the project level.

**D.** Create labels at the organization level.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 185

Contexto: [topics:723](#topics-723)
You run a 24x7 online travel agency using Spanner. Your company provides services to book hotels, flights, and local attractions which are fulfilled by your partners. You need to enable your partners to access their respective booking data for reconciliation and analysis in real time. You need a solution that provides your partners secure access, the ability to run ad hoc SQL read queries with minimal to no disruption to your existing reservation platform. You want to keep costs to a minimum.

What should you do?

**A.** Create a view for each partner by using federated queries in BigQuery, and grant each partner IAM access on their view.

**B.** Use a change stream to replicate data into BigQuery for ad hoc reporting needs.

**C.** Batch export each partner’s data as a CSV file into separate Cloud Storage buckets.

**D.** Create a view on Spanner for each partner, and grant each partner IAM access on their view.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 186

Contexto: [topics:723](#topics-723)
You work at a retail company using Cloud SQL for MySQL to store transactional data. You need to combine the transactional data with customer behavior information from BigQuery to make real-time sales predictions using machine learning. You want to accomplish this without incurring the overhead costs of moving the data out of their respective data stores.

What should you do?

**A.** Use Datastream to build ETL/ELT pipelines to move data from Cloud SQL to BigQuery. Use BigQuery ML for predictions.

**B.** Use BigQuery ML for predictions, and combine federated queries to Cloud SQL.

**C.** Refactor the application to simultaneously write data to both MySQL and BigQuery. Use BigQuery to generate predictions.

**D.** Extract data from BigQuery into Cloud SQL, and use Vertex AI to generate predictions.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 187

Contexto: [topics:723](#topics-723)
Your company is planning to migrate their 5 TB on-premises MySQL database to Cloud SQL for MySQL. You need a Google-recommended approach for schema and data migration. You must keep downtime to a minimum while ensuring continuous data replication.

What should you do?

**A.** Use Dataflow to set up a custom ETL pipeline to extract data from the on-premises database, and load the data into Cloud SQL.

**B.** Use Database Migration Service to migrate data from the on-premises database to Cloud SQL, then promote the Cloud SQL instance as the primary after migration is complete.

**C.** Use the mysqldump utility to create a backup of the on-premises database, and restore that backup into a new Cloud SQL instance.

**D.** Manually export the data from the on-premises database CSV format, and import this data into a new Cloud SQL instance.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 188

Contexto: [topics:723](#topics-723)
You have a single global application that uses clickstream data stored in a Bigtable instance. The application’s users are spread across North America, Asia, and Europe. You want to reduce user latency, while keeping costs to a minimum.

What should you do?

**A.** Create one instance of Bigtable with three clusters in one central region across three zones. Set up a single app profile with multi-cluster routing.

**B.** Create three instances of Bigtable, each one in a region in North America, Asia, and Europe. Set up three app profiles, one for each region with single-cluster routing.

**C.** Create one instance of Bigtable with three clusters in a region in North America, Asia, and Europe. Set up three app profiles, one for each region with single-cluster routing.

**D.** Create one instance of Bigtable with three clusters in a region in North America, Asia, and Europe. Set up a single app profile with multi-cluster routing.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 189

Contexto: [topics:723](#topics-723)
You are building a point of sale (POS) application to deploy in your retail company’s stores. The application needs to run on a mobile device, but with the ability to keep catalog, pricing, and product data current with frequent updates from a central location. The network at the stores may not be reliable, so the application must be able to run without connectivity. You want to minimize development time and costs.

What should you do?

**A.** Create a native solution, supporting Android and iOS, by using SQLite, and develop a synchronization API with a central AlloyDB database.

**B.** Create a Firebase application with Firestore as the database.

**C.** Create a native solution using AlloyDB Omni in the mobile device and synchronizing with AlloyDB in Google Cloud.

**D.** Create a web application with Cloud Run and Cloud SQL.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 190

Contexto: [topics:723](#topics-723)
Your company is adopting AlloyDB for a business-critical application with the following requirements:
•	RTO: Under 4 hours
•	RPO: 6 hours (maximum data loss tolerance)
•	Daily backups with a 7-day retention period

You need to design a solution to meet these requirements.

What should you do?

**A.** Make a daily backup and store on Cloud Storage.

**B.** Set a longer retention period for automatic backups.

**C.** Disable automatic backups and manually export data to Cloud Storage.

**D.** Configure automatic backups and enable continuous backup and recovery.

**Respuesta de la fuente:** D

**Explicación:** No conservada en esta captura.

## Pregunta 191

Contexto: [topics:723](#topics-723)
You are a database administrator for a rapidly growing startup running on Google Cloud. As your company expands, the Cloud SQL for PostgreSQL database workload is increasing exponentially. You need to implement a proactive strategy to continuously assess and optimize the cost of your database solution while ensuring it meets performance requirements.

What should you do?

**A.** Set up budget alerts in Cloud Billing to notify you when spending exceeds predefined thresholds.

**B.** Implement a combination of automated scripts to analyze usage patterns and Cloud Monitoring custom metrics to track performance. Manage scaling based on defined thresholds.

**C.** Use Query Insights to identify and address performance bottlenecks, then adjust instance sizes based on recommendations.

**D.** Review Cloud Billing reports every month, and adjust instance sizes based on observed usage patterns.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 192

Contexto: [topics:723](#topics-723)
You have a transactional system on PostgreSQL that is being overwhelmed with analytic queries during the work day. You want to move this workload to AlloyDB for PostgreSQL and need to find the most cost-effective solution that supports the transactional and analytic workloads with minimal downtime.

What should you do?

**A.** Define a primary instance for the transactional workload and a small read pool instance that you scale up when the read pool instance is over 80% CPU busy for the analytic workload.

**B.** Define a large primary instance to accommodate the transactional and analytic workloads.

**C.** Define a primary instance for the transactional workload and a small read pool that you scale out before the work day starts and scale back at night for the analytic workload.

**D.** Define a primary instance for the transactional workload, and a large read pool instance for the analytic workload.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 193

Contexto: [topics:723](#topics-723)
You are migrating your on-premises Oracle database to Cloud SQL for PostgreSQL by using Database Migration Service. You observed one of your important production tables DML changes are not getting replicated on the target. All other tables are getting migrated to the target without any errors.

What could be the problem and what should you do to resolve it?

**A.** The Oracle table does not have a primary key created. Create a primary key on the table.

**B.** The table has a column of type NCLODrop the column.

**C.** Supplemental logging has not been enabled for the database. Enable supplemental logging.

**D.** The table is an index-organized table. Change it to a normal heap-organized table.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 194

Contexto: [topics:723](#topics-723)
Your Cloud SQL for PostgreSQL database supporting a financial application has been experiencing “deadlock detected” errors during end-of-month processing. You notice that CPU utilization spikes to 90% during these periods, and several long-running queries are consuming significant resources. You need to identify the specific queries causing the deadlocks and implement monitoring to solve similar issues before they cause application failures.

What should you do?

**A.** Use Cloud SQL System Insights to identify long-running queries and number of deadlocks that occurred in the database. Enable a log_lock_waits flag to determine if lock waits are causing poor performance. Set up Cloud Monitoring alerts for higher CPU utilization and connection count.

**B.** Optimize SQL queries by adding appropriate indexes to frequently accessed columns and rewriting complex joins to use LEFT JOIN instead of INNER JOIN, where applicable.

**C.** Implement connection pooling at the application layer to reduce the number of direct database connections and optimize shared_buffers and work_mem parameters in Cloud SQL for PostgreSQL to improve query execution efficiency.

**D.** Increase the deadlock_timeout parameter on the Cloud SQL for PostgreSQL instance. Export logs to Cloud Logging, and create log-based metrics to track deadlock occurrences.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.

## Pregunta 195

Contexto: [topics:723](#topics-723)
You run a toy sales ecommerce application on Spanner. The application contains details about the various product listings such as name, category, description, and review(s). Your leadership wants to enable customers to ask free-form questions about the product catalog. You want to implement this functionality in the easiest, quickest, and least expensive way possible.

What should you do?

**A.** Create a Spanner full-text search index. Find the product information or review against the user’s question in a SQL query. Return the response back to the application.

**B.** Create, train and deploy a custom ML model(s). Fetch toy details from Spanner and invoke ML predictions from the application layer to return the response.

**C.** Register an existing Generative AI Vertex model in Spanner. Use the ML.PREDICT function to supply the model with a user query along with the product information in a SQL query. Return the response back to the application.

**D.** Generate vector embeddings for product information in Spanner. Find the vector with the smallest distance between the users’ query and existing product information or review by using the EUCLIDEAN DISTANCE() function in Spanner. Return the closest product information or review.

**Respuesta de la fuente:** C

**Explicación:** No conservada en esta captura.

## Pregunta 196

Contexto: [topics:723](#topics-723)
Your company has a critical application running on-premises on PostgreSQL. The application requires minimal migration downtime and the ability to withstand regional outages. You are considering a Cloud SQL Enterprise Plus edition instance on PostgreSQL. You need to ensure that the migration will meet your requirements with minimal effort.

What should you do?

**A.** Use the PostgreSQL interface for Spanner.

**B.** Configure cross-region replicas, and test failover.

**C.** Select standard storage options, and conduct regular database backups.

**D.** Focus on provisioning large compute instances for optimal performance during failover.

**Respuesta de la fuente:** B

**Explicación:** No conservada en esta captura.

## Pregunta 197

Contexto: [topics:723](#topics-723)
You migrated a large, query-intensive data warehouse from an on-premises PostgreSQL setup to AlloyDB. Initial performance after the migration is acceptable, but you want to optimize for even faster analytical queries while being cost-effective.

What should you do?

**A.** Use Query Insights to optimize query performance and the data model for AlloyDB’s columnar storage.

**B.** Increase the number of compute nodes for AlloyDB to maximize parallelization and raw processing power.

**C.** Focus on client-side query optimization in the reporting tool.

**D.** Migrate to BigQuery for transactional workloads.

**Respuesta de la fuente:** A

**Explicación:** No conservada en esta captura.